package biz.cms_TMoneyReceiver;

import java.util.HashMap;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class TMoneyReceiverProtocol {
	
	private static Logger logger = Logger.getLogger(TMoneyReceiverProtocol.class);
	
	public static int LENGTH_BY_RECORD = 300;
	
	public int getRcvTMoneyReceiverIrtDATA(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret = 0;
		
		int nlens[] = {4,3,8,4,1,1,8,3};
		String strHeaders[] = {
			"TLGM_LEN",
			"WORK_CD",
			"COMPANY_CD",
			"TLGM_CD",
			"DEAL_TP",
				
			"SNDRCV_FG",
			"FILE_NM",
			"RES_CD"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		if( Pattern.matches("[0-9]+", (String)hm.get("TLGM_CD")) ) {
			ret = Integer.parseInt((String)hm.get("TLGM_CD"));
		}
		
		return ret;
	}
	
	public HashMap<String, String> getReceiver0600(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {10,3,20,16};
		String strHeaders[] = {
			"TRANS_TIME",
			"MANAGE_INFO",
			"SENDER_NM",
			"SENDER_PW"	
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getReceiver0620(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3};
		String strHeaders[] = {
			"BLOCK_NO",
			"SEQUENCE_NO"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getReceiver0630(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {8,12,4};
		String strHeaders[] = {
			"FILE_NAME",
			"FILE_SIZE",
			"TLGM_BYTE_NUM"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getReceiver0320(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3,4};
		String strHeaders[] = {
			"BLOCK_NO",
			"SEQUENCE_NO",
			"DATA_BYTE_LEN"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		hm.put("DATA", new String(rcvBuf.getBytes(), 11, Integer.parseInt((String)hm.get("DATA_BYTE_LEN"))));
		
		return hm;
	}
}