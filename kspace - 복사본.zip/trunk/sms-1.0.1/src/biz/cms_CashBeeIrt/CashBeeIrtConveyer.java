package biz.cms_CashBeeIrt;

import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.BasicStringFilter;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

public class CashBeeIrtConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;

	COMMLog df = null;
	
//	public CashBeeIrtConveyer(COMMLog df) {
//		this.df = df;
//	}
	
	public CashBeeIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}
	
	public String getCashBeeCHRGCnclCompletedInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		CashBeeIrtProtocol protocol = new CashBeeIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBEE_FILTER)));
			
			hm.put("DATA_LEN", "0300");
			//hm.put("DEAL_TYPE", (String)hm.get("DEAL_TYPE"));
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));
			//hm.put("DEAL_REQ_YMD", (String)hm.get("DEAL_REQ_YMD"));
			//hm.put("DEAL_REQ_HMS", (String)hm.get("DEAL_REQ_HMS"));
			//hm.put("DEAL_SNO", (String)hm.get("DEAL_SNO"));
			hm.put("RES_CD", "0000");
			hm.put("RES_MSG", " ");
			hm.put("PUBCO_INFOCHNG_YN", "00");
			//hm.put("ADJT_YMD", (String)hm.get("ADJT_YMD"));
			hm.put("FILLER", " ");
			//hm.put("CARD_NO", (String)hm.get("CARD_NO"));
			//hm.put("DEAL_BEF_RAMT", (String)hm.get("DEAL_BEF_RAMT"));
			//hm.put("DEAL_REQ_AMT", (String)hm.get("DEAL_REQ_AMT"));
			//hm.put("DEAL_AFT_RAMT", (String)hm.get("DEAL_AFT_RAMT"));
			//hm.put("PAY_FLAG", (String)hm.get("PAY_FLAG"));
			//hm.put("CHRG_FEE_AMT", (String)hm.get("CHRG_FEE_AMT"));
			//hm.put("CHRG_FEE_RATE", (String)hm.get("CHRG_FEE_RATE"));
			//hm.put("IDEP", (String)hm.get("IDEP"));
			//hm.put("NTEP", (String)hm.get("NTEP"));
			//hm.put("IDCENTER", (String)hm.get("IDCENTER"));
			//hm.put("ALGEP", (String)hm.get("ALGEP"));
			//hm.put("MLDA", (String)hm.get("MLDA"));
			//hm.put("BALEP", (String)hm.get("BALEP"));
			//hm.put("NT_CARDLSAM", (String)hm.get("NT_CARDLSAM"));
			//hm.put("IDLSAM", (String)hm.get("IDLSAM"));
			//hm.put("SIGN3_VAL", (String)hm.get("SIGN3_VAL"));
			//hm.put("SVR_APPROVAL_NO", (String)hm.get("SVR_APPROVAL_NO"));
			//hm.put("DEAL_REQ_DATE", (String)hm.get("TRAN_REQ_DATE"));
			//hm.put("DEAL_REQ_TIME", (String)hm.get("TRAN_REQ_TIME"));
			//hm.put("DEAL_SNO", (String)hm.get("TRAN_SNO"));
			//hm.put("SIGN2_VAL", (String)hm.get("SIGN2_VAL"));
			//hm.put("DEAL_RESULT", (String)hm.get("DEAL_RESULT"));
			
			if( ((String)hm.get("DEAL_TYPE")).equals("08") ) {			// 충전취소 결과 요청 포맷
				sendMsg = makeSendDataCashBeeCHRGCnclResultInq(hm);
			}else if( ((String)hm.get("DEAL_TYPE")).equals("10") ) {	// 충전취소 실패 요청 포맷
				sendMsg = makeSendDataCashBeeCHRGCnclFailInq(hm);
			}
			
			df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("DEAL_TYPE") + "]:[" + sendMsg + "]");

			if( actSock.send(sendMsg) ) {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("CashBee server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<cashbee] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			
			if( ((String)hm.get("DEAL_TYPE")).equals("08") ) {			// 충전취소 결과 응답 포맷
				hmRecv = protocol.getParseCashBeeCHRGCnclResultRsp(recvBuf);
				hmRecv.put("NTSAM", " ");
				hmRecv.put("DEAL_RESULT", " ");
			}else if( ((String)hm.get("DEAL_TYPE")).equals("10") ) {	// 충전취소 실패 응답 포맷
				hmRecv = protocol.getParseCashBeeCHRGCnclFailRsp(recvBuf);
				hmRecv.put("IDEP", " ");
				hmRecv.put("NTEP", " ");
				hmRecv.put("IDCENTER", " ");
				hmRecv.put("ALGEP", " ");
				hmRecv.put("MLDA", " ");
				hmRecv.put("BALEP", " ");
				hmRecv.put("SIGN3_VAL", " ");
//				hmRecv.put("EVT_CHRG_AMT", " ");
			}
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataCashBeeCHRGCnclCompletedRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataCashBeeCHRGCnclCompletedRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,4,16
					  ,20,10,10,10,1
					  ,10,4,16,10,2
					  ,2,10,10,16,10
					  ,10,8,16,8,6
					  ,10,8,1};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"RES_CD",
			"RES_MSG",
			
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
			
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDEP",
			"NTEP",
			"IDCENTER",
			
			"ALGEP",
			"MLDA",
			"NT_CARDLSAM",
			"IDLSAM",
			"NTSAM",
			
			"BALEP",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"SIGN2_VAL",
			"DEAL_RESULT"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGCnclCompletedRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeCHRGCnclResultInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,2,2,10,10,10
					  ,16,8,16,8,6
					  ,10,8,23};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
					
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
					
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
					
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDEP",
			"NTEP",
			
			"IDCENTER",
			"ALGEP",
			"MLDA",
			"BALEP",
			"NT_CARDLSAM",
			
			"IDLSAM",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"SIGN2_VAL",
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGCnclResultInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeCHRGCnclFailInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,8,10,16,8,6
					  ,10,1,70};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
						
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
						
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDLSAM",
			"NT_CARDLSAM",
			
			"SIGN2_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"DEAL_RESULT",
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGCnclFailInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getCashBeeRTPaymentSnd(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		CashBeeIrtProtocol protocol = new CashBeeIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBEE_MST_FILTER)));

			//hm.put("COMMAND_TY", (String)hm.get("COMMAND_TY"));
			StringBuffer sb = new StringBuffer();
			//byte bytes[] = COMMBiz.intToBytes(334);
			hm.put("LENGTH", "  ");
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));
			//hm.put("SNO", (String)hm.get("SNO"));
			//hm.put("SAM_FLAG", (String)hm.get("SAM_FLAG"));
			//hm.put("SAM_ID", (String)hm.get("SAM_ID"));
			//hm.put("CARD_NO", (String)hm.get("CARD_NO"));
			//hm.put("CARD_TRAN_SNO", (String)hm.get("CARD_TRAN_SNO"));
			//hm.put("WORK_FLAG", (String)hm.get("WORK_FLAG"));
			//hm.put("PAY_YMDHMS", (String)hm.get("PAY_YMDHMS"));
			//hm.put("PAY_BEF_RAMT", (String)hm.get("PAY_BEF_RAMT"));
			//hm.put("PAY_REQ_AMT", (String)hm.get("PAY_REQ_AMT"));
			//hm.put("PAY_AFT_RAMT", (String)hm.get("PAY_AFT_RAMT"));
			//hm.put("PAY_BEF_SAM_RAMT", (String)hm.get("PAY_BEF_SAM_RAMT"));
			//hm.put("PAY_AFT_SAM_RAMT", (String)hm.get("PAY_AFT_SAM_RAMT"));
			//hm.put("CARD_FLAG", (String)hm.get("CARD_FLAG"));
			//hm.put("PAY_FLAG", (String)hm.get("PAY_FLAG"));
			//hm.put("MEMCARD_EXP_DATE", (String)hm.get("MEMCARD_EXP_DATE"));
			//hm.put("MEMCARD_NO", (String)hm.get("MEMCARD_NO"));
			//hm.put("FIRST_CHRG_FLAG", (String)hm.get("FIRST_CHRG_FLAG"));
			//hm.put("RFU", (String)hm.get("RFU"));
			//hm.put("PAY_FEE_RATE", (String)hm.get("PAY_FEE_RATE"));
			//hm.put("PAY_FEE_AMT", (String)hm.get("PAY_FEE_AMT"));
			//hm.put("SAM_DEAL_SNO", (String)hm.get("SAM_DEAL_SNO"));
			//hm.put("SAM_DEAL_CNT", (String)hm.get("SAM_DEAL_CNT"));
			//hm.put("SAM_ALGM_ID", (String)hm.get("SAM_ALGM_ID"));
			//hm.put("SAM_KEYSET_VER", (String)hm.get("SAM_KEYSET_VER"));
			//hm.put("CARD_DEPOSIT", (String)hm.get("CARD_DEPOSIT"));
			//hm.put("PENALTY_AMT", (String)hm.get("PENALTY_AMT"));
			//hm.put("CHRG_APPROVAL_NO", (String)hm.get("CHRG_APPROVAL_NO"));
			//hm.put("CARD_PUB_ID", (String)hm.get("CARD_PUB_ID"));
			//hm.put("SIGN", (String)hm.get("SIGN"));
			//hm.put("NCSAM", (String)hm.get("NCSAM"));
			//hm.put("NISAM", (String)hm.get("NISAM"));
			//hm.put("TOTSAM", (String)hm.get("TOTSAM"));
			//hm.put("IDCENTER", (String)hm.get("IDCENTER"));
			//hm.put("MPSAM", (String)hm.get("MPSAM"));
			//hm.put("MAXIDCENTER", (String)hm.get("MAXIDCENTER"));
			//hm.put("BALIDCENTER", (String)hm.get("BALIDCENTER"));
			//hm.put("FRU", (String)hm.get("FRU"));
			//hm.put("RESEND_FLAG", (String)hm.get("RESEND_FLAG"));
			//hm.put("RESULT", (String)hm.get("RESULT"));
			//hm.put("ERR_CD", (String)hm.get("ERR_CD"));
			hm.put("FILLER", " ");
			hm.put("NEWLN_CHAR", String.format("%1x", 0x0A));
			
			sendMsg = makeSendDataCashBeeRTPaymentSnd(hm);
			
			df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "]:[COMMAND_TYPE:" + (String)hm.get("COMMAND_TY") + "]:[" + sendMsg + "]");
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문 길이 0x014E(334) 설정
			sendBytes[2] = (byte)0x01;
			sendBytes[3] = (byte)0x4e;
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("CashBee server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<cashbee] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			
			hmRecv = protocol.getParseCashBeeRTPaymentRcvRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataCashBeeRTPaymentRcvRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataCashBeeRTPaymentRcvRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,2,16
					  ,20,14,2,16,14
					  ,2};
		String strHeaders[] = {
			"INQ_TYPE",
			"COMMAND_TY",
			"MEMBER_ID",
			"SAM_FLAG",
			"SAM_ID",
			
			"CARD_NO",
			"CARD_DEAL_YMDHMS",
			"RES_CD",
			"RES_MSG",
			"RES_YMDHMS",
			
			"PUBCO_INFOCHNG_YN"			
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make Send Data CashBeeRTPaymentRcvRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeRTPaymentSnd(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,10,2
					  ,16,20,10,3,14
					  ,10,10,10,10,10
					  ,2,1,4,16,1
					  ,3,4,10,10,10
					  ,2,2,10,10,14
					  ,7,16,10,5,10
					  ,2,10,10,10,8
					  ,1,1,2,8,1};
		String strHeaders[] = {
			"COMMAND_TY",
			"LENGTH",
			"MEMBER_ID",
			"SNO",
			"SAM_FLAG",
			
			"SAM_ID",
			"CARD_NO",
			"CARD_TRAN_SNO",
			"WORK_FLAG",
			"PAY_YMDHMS",
			
			"PAY_BEF_RAMT",
			"PAY_REQ_AMT",
			"PAY_AFT_RAMT",
			"PAY_BEF_SAM_RAMT",
			"PAY_AFT_SAM_RAMT",
			
			"CARD_FLAG",
			"PAY_FLAG",
			"MEMCARD_EXP_DATE",
			"MEMCARD_NO",
			"FIRST_CHRG_FLAG",
			
			"RFU",
			"PAY_FEE_RATE",
			"PAY_FEE_AMT",
			"SAM_DEAL_SNO",
			"SAM_DEAL_CNT",
			
			"SAM_ALGM_ID",
			"SAM_KEYSET_VER",
			"CARD_DEPOSIT",
			"PENALTY_AMT",
			"CHRG_APPROVAL_NO",
			
			"CARD_PUB_ID",
			"SIGN",
			"NCSAM",
			"NISAM",
			"TOTSAM",
			
			"IDCENTER",
			"MPSAM",
			"MAXIDCENTER",
			"BALIDCENTER",
			"FRU",
			
			"RESEND_FLAG",
			"RESULT",
			"ERR_CD",
			"FILLER",
			"NEWLN_CHAR"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeRTPaymentSnd : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getCashBeeRFNDCompletedInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		CashBeeIrtProtocol protocol = new CashBeeIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBEE_FILTER)));
			
			hm.put("DATA_LEN", "0300");
			//hm.put("DEAL_TYPE", (String)hm.get("DEAL_TYPE"));
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));
			//hm.put("DEAL_REQ_YMD", (String)hm.get("DEAL_REQ_YMD"));
			//hm.put("DEAL_REQ_HMS", (String)hm.get("DEAL_REQ_HMS"));
			//hm.put("DEAL_SNO", (String)hm.get("DEAL_SNO"));
			hm.put("RES_CD", "0000");
			hm.put("RES_MSG", " ");
			hm.put("PUBCO_INFOCHNG_YN", "00");
			//hm.put("ADJT_YMD", (String)hm.get("ADJT_YMD"));
			hm.put("FILLER", " ");
			//hm.put("CARD_NO", (String)hm.get("CARD_NO"));
			//hm.put("DEAL_BEF_RAMT", (String)hm.get("DEAL_BEF_RAMT"));
			//hm.put("DEAL_REQ_AMT", (String)hm.get("DEAL_REQ_AMT"));
			//hm.put("DEAL_AFT_RAMT", (String)hm.get("DEAL_AFT_RAMT"));
			//hm.put("PAY_FLAG", (String)hm.get("PAY_FLAG"));
			//hm.put("RFND_FEE_AMT", (String)hm.get("CHRG_FEE_AMT"));
			//hm.put("RFND_FEE_RATE", (String)hm.get("CHRG_FEE_RATE"));
			//hm.put("IDEP", (String)hm.get("IDEP"));
			//hm.put("NTEP", (String)hm.get("NTEP"));
			//hm.put("IDCENTER", (String)hm.get("IDCENTER"));
			//hm.put("ALGEP", (String)hm.get("ALGEP"));
			//hm.put("BALEP_OLD", (String)hm.get("BALEP_OLD"));
			//hm.put("BALEP", (String)hm.get("BALEP"));
			//hm.put("NT_CARDLSAM", (String)hm.get("NT_CARDLSAM"));
			//hm.put("IDLSAM", (String)hm.get("IDLSAM"));
			//hm.put("SIGN3_VAL", (String)hm.get("SIGN3_VAL"));
			//hm.put("SVR_APPROVAL_NO", (String)hm.get("SVR_APPROVAL_NO"));
			//hm.put("DEAL_REQ_DATE", (String)hm.get("TRAN_REQ_DATE"));
			//hm.put("DEAL_REQ_TIME", (String)hm.get("TRAN_REQ_TIME"));
			//hm.put("DEAL_SNO", (String)hm.get("TRAN_SNO"));
			//hm.put("SIGN2_VAL", (String)hm.get("SIGN2_VAL"));
			//hm.put("DEAL_RESULT", (String)hm.get("DEAL_RESULT"));
			
			if( ((String)hm.get("DEAL_TYPE")).equals("14") ) {			// 환불 결과 요청 포맷
				sendMsg = makeSendDataCashBeeRFNDResultInq(hm);
			}else if( ((String)hm.get("DEAL_TYPE")).equals("16") ) {	// 환불 실패 요청 포맷
				sendMsg = makeSendDataCashBeeRFNDFailInq(hm);
			}
			
			df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("DEAL_TYPE") + "]:[" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("CashBee server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<cashbee] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			
			if( ((String)hm.get("DEAL_TYPE")).equals("14") ) {			// 환불 결과 요청 포맷
				hmRecv = protocol.getParseCashBeeRFNDResultRsp(recvBuf);
				hmRecv.put("NTSAM", " ");
				hmRecv.put("DEAL_RESULT", " ");
			}else if( ((String)hm.get("DEAL_TYPE")).equals("16") ) {	// 환불 실패 요청 포맷
				hmRecv = protocol.getParseCashBeeRFNDFailRsp(recvBuf);
				hmRecv.put("IDEP", " ");
				hmRecv.put("NTEP", " ");
				hmRecv.put("IDCENTER", " ");
				hmRecv.put("ALGEP", " ");
				hmRecv.put("BALEP_OLD", " ");
				hmRecv.put("BALEP", " ");
				hmRecv.put("SIGN3_VAL", " ");
			}
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataCashBeeRFNDCompletedRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataCashBeeRFNDCompletedRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,4,16
					  ,20,10,10,10,1
					  ,10,4,16,10,2
					  ,2,10,10,10,16
					  ,8,10,16,8,6
					  ,10,8,1};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"RES_CD",
			"RES_MSG",
			
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
			
			"RFND_FEE_AMT",
			"RFND_FEE_RATE",
			"IDEP",
			"NTEP",
			"IDCENTER",
			
			"ALGEP",
			"BALEP_OLD",
			"BALEP",
			"NT_CARDLSAM",
			"IDLSAM",
			
			"SIGN3_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"SIGN2_VAL",
			"DEAL_RESULT"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeRFNDCompletedRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeRFNDResultInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,2,2,10,10,10
					  ,16,8,16,8,6
					  ,10,8,23};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
				
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
				
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
				
			"PAY_FLAG",
			"RFND_FEE_AMT",
			"RFND_FEE_RATE",
			"IDEP",
			"NTEP",
			
			"IDCENTER",
			"ALGEP",
			"BALEP_OLD",
			"BALEP",
			"NT_CARDLSAM",
			
			"IDLSAM",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"SIGN2_VAL",
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeRFNDResultInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeRFNDFailInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,8,10,16,8,6
					  ,10,1,70};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
					
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
					
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
					
			"PAY_FLAG",
			"RFND_FEE_AMT",
			"RFND_FEE_RATE",
			"IDLSAM",
			"NT_CARDLSAM",
			
			"SIGN2_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"DEAL_RESULT",
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeRFNDFailInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getCashBeeCHRGCancelInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		CashBeeIrtProtocol protocol = new CashBeeIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBEE_FILTER)));
			
			hm.put("DATA_LEN", "0300");
			//hm.put("DEAL_TYPE", (String)hm.get("DEAL_TYPE"));
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));
			//hm.put("DEAL_REQ_YMD", (String)hm.get("DEAL_REQ_YMD"));
			//hm.put("DEAL_REQ_HMS", (String)hm.get("DEAL_REQ_HMS"));
			//hm.put("DEAL_SNO", (String)hm.get("DEAL_SNO"));
			hm.put("RES_CD", "0000");
			hm.put("RES_MSG", " ");
			hm.put("PUBCO_INFOCHNG_YN", "00");
			//hm.put("ADJT_YMD", (String)hm.get("ADJT_YMD"));
			hm.put("FILLER", " ");
			//hm.put("CARD_NO", (String)hm.get("CARD_NO"));
			//hm.put("DEAL_BEF_RAMT", (String)hm.get("DEAL_BEF_RAMT"));
			//hm.put("DEAL_REQ_AMT", (String)hm.get("DEAL_REQ_AMT"));
			//hm.put("DEAL_AFT_RAMT", (String)hm.get("DEAL_AFT_RAMT"));
			//hm.put("PAY_FLAG", (String)hm.get("PAY_FLAG"));
			//hm.put("CHRG_FEE_AMT", (String)hm.get("CHRG_FEE_AMT"));
			//hm.put("CHRG_FEE_RATE", (String)hm.get("CHRG_FEE_RATE"));
			//hm.put("ALGEP", (String)hm.get("ALGEP"));
			//hm.put("BALEP", (String)hm.get("BALEP"));
			//hm.put("IDCENTER", (String)hm.get("IDCENTER"));
			//hm.put("IDEP", (String)hm.get("IDEP"));
			//hm.put("NTEP", (String)hm.get("NTEP"));
			//hm.put("REP", (String)hm.get("REP"));
			//hm.put("BEF_IDSAM", (String)hm.get("BEF_IDSAM"));
			//hm.put("BEF_MLDA", (String)hm.get("BEF_MLDA"));
			//hm.put("BEF_NTEP", (String)hm.get("BEF_NTEP"));
			//hm.put("SIGN1_VAL", (String)hm.get("SIGN1_VAL"));
			//hm.put("RFU", (String)hm.get("RFU"));
			//hm.put("L_MEMBER_NO", (String)hm.get("L_MEMBER_NO"));
			//hm.put("ODEAL_CHRG_YMDHMS", (String)hm.get("ODEAL_CHRG_YMDHMS"));
			//hm.put("ODEAL_CHRG_SIGN2", (String)hm.get("ODEAL_CHRG_SIGN2"));
			
			sendMsg = makeSendDataCashBeeCHRGCancelInq(hm);
			
			df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("DEAL_TYPE") + "]:[" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("CashBee server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<cashbee] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			
			hmRecv = protocol.getParseCashBeeCHRGCancelRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataCashBeeCHRGCancelRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataCashBeeCHRGCancelRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,4,16
					  ,20,10,10,10,1
					  ,10,4,16,10,8
					  ,10,16,8,6,10
					  ,6};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"RES_CD",
			"RES_MSG",
				
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
				
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDSAM",
			"NT_CARDLSAM",
			"SIGN2",
			
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			"DEAL_SNO",
			
			"EVT_CHRG_AMT"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGCancelRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeCHRGCancelInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,2,10
					  ,2,16,10,16,16
					  ,10,10,8,8,16
					  ,14,8,9};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
			
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"ALGEP",
			"BALEP",
			
			"IDCENTER",
			"IDEP",
			"NTEP",
			"REP",
			"BEF_IDSAM",
			
			"BEF_MLDA",
			"BEF_NTEP",
			"SIGN1_VAL",
			"RFU",
			"L_MEMBER_NO",
			
			"ODEAL_CHRG_YMDHMS",
			"ODEAL_CHRG_SIGN2",
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGCancelInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getCashBeeCHRGCompletedInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		CashBeeIrtProtocol protocol = new CashBeeIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBEE_FILTER)));
			
			hm.put("DATA_LEN", "0300");
			//hm.put("DEAL_TYPE", (String)hm.get("DEAL_TYPE"));
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));
			//hm.put("DEAL_REQ_YMD", (String)hm.get("DEAL_REQ_YMD"));
			//hm.put("DEAL_REQ_HMS", (String)hm.get("DEAL_REQ_HMS"));
			//hm.put("DEAL_SNO", (String)hm.get("DEAL_SNO"));
			hm.put("RES_CD", "0000");
			hm.put("RES_MSG", " ");
			hm.put("PUBCO_INFOCHNG_YN", "00");
			//hm.put("ADJT_YMD", (String)hm.get("ADJT_YMD"));
			hm.put("FILLER", " ");
			//hm.put("CARD_NO", (String)hm.get("CARD_NO"));
			//hm.put("DEAL_BEF_RAMT", (String)hm.get("DEAL_BEF_RAMT"));
			//hm.put("DEAL_REQ_AMT", (String)hm.get("DEAL_REQ_AMT"));
			//hm.put("DEAL_AFT_RAMT", (String)hm.get("DEAL_AFT_RAMT"));
			//hm.put("PAY_FLAG", (String)hm.get("PAY_FLAG"));
			//hm.put("CHRG_FEE_AMT", (String)hm.get("CHRG_FEE_AMT"));
			//hm.put("CHRG_FEE_RATE", (String)hm.get("CHRG_FEE_RATE"));
			//hm.put("IDEP", (String)hm.get("IDEP"));
			//hm.put("NTEP", (String)hm.get("NTEP"));
			//hm.put("IDCENTER", (String)hm.get("IDCENTER"));
			//hm.put("ALGEP", (String)hm.get("ALGEP"));
			//hm.put("MLDA", (String)hm.get("MLDA"));
			//hm.put("NT_CARDLSAM", (String)hm.get("NT_CARDLSAM"));
			//hm.put("IDLSAM", (String)hm.get("IDLSAM"));
			//hm.put("NTSAM", (String)hm.get("NTSAM"));
			//hm.put("BALEP", (String)hm.get("BALEP"));
			//hm.put("SIGN3_VAL", (String)hm.get("SIGN3_VAL"));
			//hm.put("SVR_APPROVAL_NO", (String)hm.get("SVR_APPROVAL_NO"));
			//hm.put("DEAL_REQ_DATE", (String)hm.get("TRAN_REQ_DATE"));
			//hm.put("DEAL_REQ_TIME", (String)hm.get("TRAN_REQ_TIME"));
			//hm.put("DEAL_SNO", (String)hm.get("TRAN_SNO"));
			//hm.put("SIGN2_VAL", (String)hm.get("SIGN2_VAL"));
			//hm.put("DEAL_RESULT", (String)hm.get("DEAL_RESULT"));
			//hm.put("FILLER", (String)hm.get("FILLER"));
			
			if( ((String)hm.get("DEAL_TYPE")).equals("02") || ((String)hm.get("DEAL_TYPE")).equals("20") ) {			// 충전/지불취소 결과 요청 포맷
				sendMsg = makeSendDataCashBeeCHRGResultInq(hm);
			}else if( ((String)hm.get("DEAL_TYPE")).equals("04") || ((String)hm.get("DEAL_TYPE")).equals("22") ) {	// 충전/지불취소 실패 요청 포맷
				hm.put("EVT_CHRG_AMT", " ");
				sendMsg = makeSendDataCashBeeCHRGFailInq(hm);
			}
			
			df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("DEAL_TYPE") + "]:[" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("CashBee server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<cashbee] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:" + recvBuf.substring(4, 6) + "]:[" + recvBuf + "]");
			
			if( ((String)hm.get("DEAL_TYPE")).equals("02") || ((String)hm.get("DEAL_TYPE")).equals("20") ) {			// 충전/지불취소 결과 요청 포맷
				hmRecv = protocol.getParseCashBeeCHRGResultRsp(recvBuf);
				hmRecv.put("EVT_CHRG_AMT", " ");
				hmRecv.put("DEAL_RESULT", " ");
			}else if( ((String)hm.get("DEAL_TYPE")).equals("04") || ((String)hm.get("DEAL_TYPE")).equals("22") ) {	// 충전/지불취소 실패 요청 포맷
				hmRecv = protocol.getParseCashBeeCHRGFailRsp(recvBuf);
				hmRecv.put("IDEP", " ");
				hmRecv.put("NTEP", " ");
				hmRecv.put("IDCENTER", " ");
				hmRecv.put("ALGEP", " ");
				hmRecv.put("MLDA", " ");
				hmRecv.put("BALEP", " ");
				hmRecv.put("SIGN3_VAL", " ");
			}
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataCashBeeCHRGCompletedRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataCashBeeCHRGCompletedRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,4,16
					  ,20,10,10,10,1
					  ,10,4,16,10,2
					  ,2,10,10,16,10
					  ,10,8,16,8,6
					  ,10,8,6,1};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"RES_CD",
			"RES_MSG",
			
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
			
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDEP",
			"NTEP",
			"IDCENTER",
			
			"ALGEP",
			"MLDA",
			"NT_CARDLSAM",
			"IDLSAM",
			"NTSAM",
			
			"BALEP",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"SIGN2_VAL",
			"EVT_CHRG_AMT",
			"DEAL_RESULT"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGCompletedRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeCHRGResultInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,2,2,10,10,16
					  ,10,10,8,16,8
					  ,6,10,8,13};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
			
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDEP",
			"NTEP",
			
			"IDCENTER",
			"ALGEP",
			"MLDA",
			"NT_CARDLSAM",
			"IDLSAM",
			
			"NTSAM",
			"BALEP",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			
			"DEAL_REQ_TIME",
			"DEAL_SNO",
			"SIGN2_VAL",
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGResultInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeCHRGFailInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,8,10,16,8,6
					  ,10,6,1,64};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
				
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
				
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
				
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDLSAM",
			"NT_CARDLSAM",
			
			"SIGN2_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",			
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"EVT_CHRG_AMT",
			"DEAL_RESULT",
			"FILLER"			
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGFailInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getCashBeeCHRGInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		CashBeeIrtProtocol protocol = new CashBeeIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBEE_FILTER)));
			
			hm.put("DATA_LEN", "0300");
			//hm.put("DEAL_TYPE", (String)hm.get("DEAL_TYPE"));
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));
			//hm.put("DEAL_REQ_YMD", (String)hm.get("DEAL_REQ_YMD"));
			//hm.put("DEAL_REQ_HMS", (String)hm.get("DEAL_REQ_HMS"));
			//hm.put("DEAL_SNO", (String)hm.get("DEAL_SNO"));
			//hm.put("DEAL_SNO", (String)hm.get("DEAL_SNO"));
			hm.put("RES_CD", "0000");
			hm.put("RES_MSG", " ");
			hm.put("PUBCO_INFOCHNG_YN", "00");
			//hm.put("ADJT_YMD", (String)hm.get("ADJT_YMD"));
			hm.put("FILLER", " ");
			//hm.put("CARD_NO", (String)hm.get("CARD_NO"));
			//hm.put("DEAL_BEF_RAMT", (String)hm.get("DEAL_BEF_RAMT"));
			//hm.put("DEAL_REQ_AMT", (String)hm.get("DEAL_REQ_AMT"));
			//hm.put("DEAL_AFT_RAMT", (String)hm.get("DEAL_AFT_RAMT"));
			//hm.put("PAY_FLAG", (String)hm.get("PAY_FLAG"));
			//hm.put("CHRG_FEE_AMT", (String)hm.get("CHRG_FEE_AMT"));
			//hm.put("CHRG_FEE_RATE", (String)hm.get("CHRG_FEE_RATE"));
			//hm.put("ALGEP", (String)hm.get("ALGEP"));
			//hm.put("BALEP", (String)hm.get("BALEP"));
			//hm.put("IDCENTER", (String)hm.get("IDCENTER"));
			//hm.put("IDEP", (String)hm.get("IDEP"));
			//hm.put("NTEP", (String)hm.get("NTEP"));
			//hm.put("REP", (String)hm.get("REP"));
			//hm.put("SIGN1_VAL", (String)hm.get("SIGN1_VAL"));
			//hm.put("RFU", (String)hm.get("RFU"));
			//hm.put("MLDA", (String)hm.get("MLDA"));
			//hm.put("L_MEMBER_NO", (String)hm.get("L_MEMBER_NO"));
			//hm.put("ORG_TRAN_YMDHMS", (String)hm.get("ORG_TRAN_YMDHMS"));
			//hm.put("ORG_SIGN", (String)hm.get("ORG_SIGN"));
			//hm.put("ORG_SAM_DEAL_SNO", (String)hm.get("ORG_SAM_DEAL_SNO"));
			
			if( ((String)hm.get("DEAL_TYPE")).equals("00") || ((String)hm.get("DEAL_TYPE")).equals("18") ) {	// 충전/지불취소 요청
				sendMsg = makeSendDataCashBeeCHRGInq(hm);
			}else if( ((String)hm.get("DEAL_TYPE")).equals("12") ) {	// 환불 요청
				sendMsg = makeSendDataCashBeeREFUNDInq(hm);
			}
			
			df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("DEAL_TYPE") + "]:[" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] ERROR");
				
				throw new Exception("CashBee server is no response");
			}

			recvBuf = (String)actSock.receive();
			df.CommLogger("[sms<cashbee] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
						
			hmRecv = protocol.getParseCashBeeCHRGRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataCashBeeCHRGRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataCashBeeCHRGRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,4,16
					  ,20,10,10,10,1
					  ,10,4,16,10,8
					  ,10,16,8,6,10
					  ,6};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"RES_CD",
			"RES_MSG",
			
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
			
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDSAM",
			"NT_CARDLSAM",
			"SIGN2_VAL",
			
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			"DEAL_SNO",
			
			"EVT_CHRG_AMT"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeREFUNDInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,2,10
					  ,2,16,10,16,8
					  ,8,10,16,57};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
			
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"ALGEP",
			"BALEP",
			
			"IDCENTER",
			"IDEP",
			"NTEP",
			"REP",
			"SIGN1_VAL",
			
			"RFU",
			"MLDA",
			"L_MEMBER_NO",
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeREFUNDInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeCHRGInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,2,10
					  ,2,16,10,16,8
					  ,8,10,16,14,8
					  ,10,25};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
			
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"ALGEP",
			"BALEP",
			
			"IDCENTER",
			"IDEP",
			"NTEP",
			"REP",
			"SIGN1_VAL",
			
			"RFU",
			"MLDA",
			"L_MEMBER_NO",
			"ORG_TRAN_YMDHMS",
			"ORG_SIGN",
			
			"ORG_SAM_DEAL_SNO",
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getCashBeeCHKPPAMTInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		CashBeeIrtProtocol protocol = new CashBeeIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBEE_FILTER)));
			
			hm.put("DATA_LEN", "0300");
			hm.put("DEAL_GB_CD", "50");
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));
			//hm.put("DEAL_REQ_YMD", (String)hm.get("DEAL_REQ_YMD"));
			//hm.put("DEAL_REQ_HMS", (String)hm.get("DEAL_REQ_HMS"));
			//hm.put("DEAL_SNO", (String)hm.get("DEAL_SNO"));
			//hm.put("RES_CD", (String)hm.get("RES_CD"));
			//hm.put("RES_MSG", (String)hm.get("RES_MSG"));
			hm.put("PUBCO_INFOCHNG_YN", "00");
			//hm.put("ADJT_YMD", (String)hm.get("ADJT_YMD"));
			hm.put("FILLER", " ");
			hm.put("BRANCH_NO", (String)hm.get("BRANCH_NO"));
			hm.put("RECHRGABLE_AMT", (String)hm.get("RECHRGABLE_AMT"));
			hm.put("RESULT", (String)hm.get("RESULT"));
			
//			sendMsg = makeSendDataCashBeeCHKPPAMTInq(hm);
//			
//			df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("DEAL_GB_CD") + "]:[" + sendMsg + "]");
//			
//			if( actSock.send(sendMsg) ) {
//				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] OK");
//			}else {
//				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] ERROR");
//
//				throw new Exception("CashBee server is no response");
//			}
//			
//			recvBuf = ((String)actSock.receive());
//			df.CommLogger("[sms<cashbee] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
//			
//			hmRecv = protocol.getParseCashBeeCHKPPAMTRsp(recvBuf);
//			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
//			dataMsg = ret + makeSendDataCashBeeCHKPPAMTRsp(hmRecv);
			dataMsg = ret + makeSendDataCashBeeCHKPPAMTRsp(hm);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataCashBeeCHKPPAMTRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,10,8,6,10
				      ,4,16,8,10,10
				      ,2};
		String strHeaders[] = {
			"INQ_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			"DEAL_SNO",
			
			"RES_CD",
			"RES_MSG",
			"ADJT_YMD",
			"BRANCH_NO",
			"RECHRGABLE_AMT",
			
			"RESULT"	
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHKPPAMTRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeCHKPPAMTInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,10,10,2,198};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_GB_CD",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
			
			"FILLER",
			"BRANCH_NO",
			"RECHRGABLE_AMT",
			"RESULT",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getCashBeeTMNLINSTALLInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		CashBeeIrtProtocol protocol = new CashBeeIrtProtocol();
		CashBeeIrtDAO dao = new CashBeeIrtDAO();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		List<Object> list = null;
		Map<String, String> map = null;
		String strBizCoNo = "";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBEE_MST_FILTER)));
			
//			// Set Work Start Time(업무시작시간설정)
//			df.setStartTime();
//			df.setConnectionInfo(actSock.getSocket().getInetAddress()
//					.getHostAddress().toString(), 
//					String.valueOf(actSock.getSocket().getPort()), "CashBeeIRT-TMNLSetup");
			
			//hm.put("COMMAND_TY", (String)hm.get("COMMAND_TY"));		// Command
			//hm.put("LENGTH", String.format("%2x", (int)252));				// Length
			hm.put("LENGTH", "  ");
//			StringBuffer sb = new StringBuffer();
//			byte bytes[] = COMMBiz.intToBytes(252);
//			if( bytes[0] == (byte)0 ) bytes[0] = (char)'0';
//			if( bytes[1] == (byte)0 ) bytes[0] = (char)'0';
//			sb.append((char)bytes[0] == '' ? 0 : (char)bytes[0] );
//			sb.append((char)bytes[1]);
//			hm.put("LENGTH", sb.toString());
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));		// 단말기번호
			//hm.put("DATA_FLAG", (String)hm.get("DATA_FLAG"));			// 업무구분
			//hm.put("LSAM_ID", (String)hm.get("LSAM_ID"));				// LSAM ID
			//hm.put("NEW_LSAM_ID", (String)hm.get("NEW_LSAM_ID"));		// 교체 LSAM ID
			//hm.put("MEMBER_NM", (String)hm.get("MEMBER_NM"));			// 가맹점명
			//hm.put("TEL_NO", (String)hm.get("TEL_NO"));				// 전화번호
			hm.put("POST_CD", (String)hm.get("POST_CD").trim());		// 우편번호
			hm.put("ADDRESS", (String)hm.get("ADDRESS").trim());		// 주소
			//hm.put("SETUP_YMDHMS", (String)hm.get("SETUP_YMDHMS"));	// 설치일자
			//hm.put("ERR_CD", (String)hm.get("ERR_CD"));				// 오류코드
			//hm.put("ERR_MSG", (String)hm.get("ERR_MSG"));				// 오류메시지
			
			list = dao.getBizCoNo((String)hmComm.get("COM_CD"), (String)hmComm.get("STORE_CD"));
			if( list.size() > 0 ) {
				map = (Map<String, String>)list.get(0);
				strBizCoNo = map.get("BIZCO_NO");						
			}
			hm.put("BIZCO_NO", strBizCoNo);								// 사업자번호
			hm.put("FILLER", " ");										// FILLER
			
			sendMsg = makeSendDataCashBeeTMNLINSTALLInq(hm);

			df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("COMMAND_TY") + "]:[" + sendMsg + "]");
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문 길이 0x00FC(252) 설정
			sendBytes[2] = (byte)0x00;
			sendBytes[3] = (byte)0xfc;
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>cashbee] SEND[" + sendBytes.length + "] OK");
			}else {
				df.CommLogger("[sms>cashbee] SEND[" + sendBytes.length + "] ERROR");

				throw new Exception("CashBee server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<cashbee] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			
			hmRecv = protocol.getParseCashBeeTMNLINSTALLRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			
			if( ((String)hmRecv.get("ERR_CD")).equals("00") ) {
				df.CommLogger(" >>>>>>>>>>>>>>>>>>> INSERT TMNALINSTALL Table ");
				hmRecv.put("COM_CD", (String)hmComm.get("COM_CD"));
				hmRecv.put("STORE_CD", (String)hmComm.get("STORE_CD"));
				hmRecv.put("POS_NO", (String)hmComm.get("POS_NO"));
				dao.insTMNALINSTALL(hmRecv, df);
			}
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataCashBeeTMNLINSTALLRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataCashBeeTMNLINSTALLInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,1,16
					  ,16,40,20,6,100
					  ,8,2,16,10,7};
		String strHeaders[] = {
			"COMMAND_TY",
			"LENGTH",
			"MEMBER_ID",
			"DATA_FLAG",
			"LSAM_ID",
			
			"NEW_LSAM_ID",
			"MEMBER_NM",
			"TEL_NO",
			"POST_CD",
			"ADDRESS",
			
			"SETUP_YMDHMS",
			"ERR_CD",
			"ERR_MSG",
			"BIZCO_NO",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeTMNLINSTALLRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,1,16
					  ,16,40,20,6,100
					  ,8,2,16};
		String strHeaders[] = {
			"INQ_TYPE",
			"COMMAND_TY",
			"MEMBER_ID",
			"DATA_FLAG",
			"LSAM_ID",
			
			"NEW_LSAM_ID",
			"MEMBER_NM",
			"TEL_NO",
			"POST_CD",
			"ADDRESS",
			
			"SETUP_YMDHMS",
			"ERR_CD",
			"ERR_MSG"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeTMNLINSTALLRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
}