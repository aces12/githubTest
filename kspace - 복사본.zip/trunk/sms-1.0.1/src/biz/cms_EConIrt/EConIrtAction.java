package biz.cms_EConIrt;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.net.Socket;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.util.StringUtil;

import oracle.sql.DATE;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class EConIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(EConIrtAction.class);
	EConIrtDAO dao = new EConIrtDAO();
	EConIrtProtocol protocol = new EConIrtProtocol();
	
	/**
	 * Receive data from SC through 9033 PORT(SC로부터 데이타를 9033 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(ActionSocket actionSocket) throws Exception {
		// TODO Auto-generated method stub
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		StringBuffer sb = null;
		
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		
		EConIrtProtocol protocol = new EConIrtProtocol();
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			logger.info("[INFO] EConIRT::rcvBuf::[" + rcvBuf + "]");
			
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			logger.info("[INFO] EConIrt::hmCommon::["+hmCommon+"]");
			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}

			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			logger.info("[INFO] EConIRT::rcvDataBuf::["+rcvDataBuf+"]");
			inq_type = COMMBiz.getInqTypeCHG(protocol.getRcvEConIrtDATA(rcvDataBuf));
			
			boolean bIsExtended = false;
			
			logger.info("[INFO] EConIRT::inq_type::["+inq_type+"]");
			switch(inq_type) {
				case 2189:	// E1(2189): 쿠폰 발행 요청(금액권)
					logger.info("ECon Issue Request START");
					
					//전문길이 체크 (71bytes)
					if (rcvDataBuf.length() == 91) {
						bIsExtended = false;
						hmData = protocol.getParseEConIssReq(rcvDataBuf);
						
						logger.info("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
						logger.info("[INFO] EConIRT::hmData::["+hmData+"]");
						
						//쿠폰발행시작
						dataMsg = EConIssueFunc(hmCommon, hmData);
						logger.info("[INFO] EConIRT::dataMsg::["+dataMsg+"]");
					} else {
						logger.info("[ERROR] IRT Length unmatched");
						hmData.put("RSLT_CD", "10");
						hmData.put("RSLT_MSG", "IRT 전문길이 오류");
						
						dao.insEConIssLog(hmCommon, hmData);	//로그테이블 이력 쌓기(ST_COUPONISS_LOG)
						return;
					}
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
					
				case 2191:	// E4(2191): 쿠폰 조회 요청
					logger.info("ECon Select Request START");
					
					if (rcvDataBuf.length() == 30) {
						hmData = protocol.getParseEConSelReq(rcvDataBuf);
						
						logger.info("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
						logger.info("[INFO] EConIRT::hmData::["+hmData+"]");
						
						//쿠폰조회시작
						dataMsg = EConSelFunc(hmCommon, hmData);
					} else {
						logger.info("[ERROR] IRT Length unmatched");
						hmData.put("RSLT_CD", "10");
						hmData.put("RSLT_MSG", "IRT 전문길이 오류");
						return;
					}
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
					
				case 2193:	// E6(2193): 쿠폰 승인/취소 요청
					logger.info("ECon Approve/Cancel Request START");
					logger.info(rcvDataBuf.length());
					if (rcvDataBuf.length() == 109) {
						hmData = protocol.getParseEConAppReq(rcvDataBuf);
						
						logger.info("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
						logger.info("[INFO] EConIRT::hmData::["+hmData+"]");
						
						//쿠폰 승인/취소
						dataMsg = EConApprFunc(hmCommon, hmData);
					} else {
						logger.info("[ERROR] IRT Length unmatched");
						hmData.put("RSLT_CD", "10");
						hmData.put("RSLT_MSG", "IRT 전문길이 오류");
						return;
					}
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
					
				case 2195:	// E8(2195): 쿠폰 발행취소 요청
					logger.info("ECon Issue Cancel Request START");
					logger.info(rcvDataBuf.length());
					if (rcvDataBuf.length() == 109) {
						hmData = protocol.getParseEConIssCnReq(rcvDataBuf);
						
						logger.info("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
						logger.info("[INFO] EConIRT::hmData::["+hmData+"]");
						
						dataMsg = EConIssCancelFunc(hmCommon, hmData); //쿠폰 발행취소 요청
					} else {
						logger.info("[ERROR] IRT Length unmatched");
						hmData.put("RSLT_CD", "10");
						hmData.put("RSLT_MSG", "IRT 전문길이 오류");
						return;
					}
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
						
				default:
					logger.info("[INFO] INQ Type Code::["+inq_type+"]::LEN::["+rcvBuf.length()+"]");
					ret = 99;
					break;
			}
		} catch (Exception e) {
			ret = 29; // 029=HOST APPL ERR
			retValue = "[ERROR]2:" + e.getMessage();
			logger.info("▶ " + retValue);
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			logger.info("dataMsg[" + dataMsg + "]");
			logger.info("sendMsg[" + sendMsg + "]");
					
			logger.info("================ 4-2) POS<-SMS 응답전문 ===================");
			logger.info("전문길이=[" + totalMsg.getBytes().length + "]");
			logger.info("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
			logger.info("전문내용=[" + totalMsg + "]");
			
			// Send Response Data (응답 데이타 전송)
			if (actionSocket.send(totalMsg)) {
				logger.info("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
			} else {
				logger.info("[pos<sms] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		} catch (Exception e) {
			retValue = "[ERROR]4" + e.getMessage();
			logger.info(retValue);
		} finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			logger.info("[INFO] EConIrtAction IRT FINISH.");
		}
	}
	
	
	//20180202 KSN -- ECon 발행 로직
	private String EConIssueFunc(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		
		int cpAmt	    = 0;
		int reqCnt		= Integer.parseInt(hmData.get("ISSUE_REQ_CNT"));
		int cpRate 	    = Integer.parseInt(hmData.get("COUPON_AMT"));
		int trAmt  	    = Integer.parseInt(hmData.get("TRADE_AMT"));
		int cpStdAmt    = Integer.parseInt(hmData.get("COUPON_STD_AMT"));
		int duration    = Integer.parseInt(hmData.get("COUPON_DURATION"));
		long chkDigit	= 0;
		
		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdftm = new SimpleDateFormat("yyyyMMddHHmmss");
		calendar.add(Calendar.DATE, duration);
		
		String cpNo 	= ""; // 발행쿠폰번호
		String prefix 	= hmData.get("COUPON_TP"); // 쿠폰유형
		String flag 	= hmData.get("ISSUE_SYS"); // 플래그
		String rdNum 	= ""; // 랜덤숫자
		String rsltCd   = "00";
		String ret		= "00";
		String rsltMsg  = "정상";
		String dataMsg  = "";
		String startDt  = sdf.format(new Date());
		String expireDt = sdf.format(calendar.getTime());
		String pluCd 	= "";
		String issDt	= sdf.format(new Date());
		String issTm	= sdftm.format(new Date()).substring(8, 14);
		
		if(!"310".equals(prefix) && !"320".equals(prefix) && !"330".equals(prefix) && !"340".equals(prefix)){ //쿠폰유형 체크
			logger.info("[ERROR] unknown coupon type.");
			rsltCd = "10";
			rsltMsg = "알 수 없는 쿠폰 유형";
			
			try{
				hmData.put("SEQ_NO", "0");
				hmData.put("RSLT_CD", rsltCd);
				hmData.put("RSLT_MSG", rsltMsg);
				
				dao.insEConIssLog(hmCom, hmData);
			}catch(Exception e){
				logger.info("[ERROR] 로그 등록 INSERT 오류");
				ret = "29";
			}
		}else{
			if(!"1".equals(flag) && !"2".equals(flag) && !"3".equals(flag) && !"4".equals(flag)){
				logger.info("[ERROR] unknown system.");
				rsltCd = "20";
				rsltMsg = "알 수 없는 발행요청 시스템";
				
				try{
					hmData.put("SEQ_NO", "0");
					hmData.put("RSLT_CD", rsltCd);
					hmData.put("RSLT_MSG", rsltMsg);
					
					dao.insEConIssLog(hmCom, hmData);
				}catch(Exception e){
					logger.info("[ERROR] 로그 등록 INSERT 오류");
					ret = "29";
				}
			}else{
				try{
					for(int i = 0; i < reqCnt; i++){// 발행요청 개수만큼
						//0. SEQ_NO SETTING --공통
						hmData.put("SEQ_NO", String.valueOf(i));
						
						//1. 쿠폰번호 발행 --공통
						Random rd = new Random();
						rdNum = String.valueOf(rd.nextInt(10));
						
						cpNo = prefix
							 + hmCom.get("STORE_CD").substring(1, 5)
							 + hmCom.get("SYS_YMD").substring(4, 8)
							 + flag 
							 + hmCom.get("SYS_HMS").substring(3, 6)
							 + rdNum
							 + hmCom.get("SYS_HMS").substring(0, 3);
						
						chkDigit = Long.parseLong(cpNo) % 8;
						cpNo = cpNo	+ String.valueOf(chkDigit);
						
						hmData.put("ISSUE_CPN_NO", cpNo);
						
						//2. 쿠폰금액 지정 (율/금액 구분) -- 금액형/할인형
						if(trAmt >= cpStdAmt){	//2-1) 쿠폰발행대상 거래인지 체크
							if("310".equals(prefix)){	//2-2) 쿠폰유형체크
								if("2".equals(hmData.get("COUPON_AMT_TP"))){	//2-3) 쿠폰 금액/율 구분 체크 -- 율인 경우, COUPON_AMT 계산해줘야 함
									cpAmt = (cpStdAmt * cpRate) / 100;
								}else{
									cpAmt = cpRate;
								}
							}else if("340".equals(prefix)){
								//cpAmt = cpRate;
							}else if("320".equals(prefix)){ //교환권
								//plu_cd
							}
						}else{
							logger.info("[ERROR] 쿠폰 발행기준금액 미달");
							rsltCd = "30";
							rsltMsg = "쿠폰 발행기준금액 미달";
						}
						logger.info("[INFO] cpAmtTp::["+hmData.get("COUPON_AMT_TP")+"]::trAmt::["+trAmt+"]::cpStdAmt::["+cpStdAmt+"]::cpRate::["+cpRate+"]::cpAmt::["+cpAmt+"]");
						
						hmData.put("COUPON_RM_AMT", String.format("%012d", cpAmt));
						
						//3. 쿠폰사용기간 지정 --공통
						hmData.put("START_DT", startDt);
						hmData.put("EXPIRE_DT", expireDt);
						
						//4. 쿠폰 마스터테이블 insert -- 쿠폰발행요청 시스템이 POS가 아닌 경우에만 해당
						if(!"1".equals(flag)){
							if("00".equals(rsltCd)){
								try{
									logger.info("[INFO] 쿠폰 마스터테이블 INSERT");
									//dao.insEConMaster(hmCom, hmData);
								}catch(Exception e){
									ret = "29";
									logger.info("[ERROR] 쿠폰 마스터 등록 INSERT 오류");
								}
							}
						}
						
						//5. 쿠폰발행 이력 쌓기 --공통
						try{
							hmData.put("RSLT_CD", rsltCd);
							hmData.put("RSLT_MSG", rsltMsg);
							
							dao.insEConIssLog(hmCom, hmData);
						}catch(Exception e){
							ret = "29";
							logger.info("[ERROR] 로그 등록 INSERT 오류");
							rsltCd = "99";
							rsltMsg = "로그 등록 INSERT 오류";
						}
					}
					
				}catch(Exception e){
					try{
						hmData.put("RSLT_CD", rsltCd);
						hmData.put("RSLT_MSG", rsltMsg);
						
						dao.insEConIssLog(hmCom, hmData);
					}catch(Exception e1){
						ret = "29";
						logger.info("[ERROR] 로그 등록 INSERT 오류 :: "+e1.getMessage());
						rsltCd = "99";
						rsltMsg = "로그 등록 INSERT 오류";
					}
					logger.info("[ERROR] EConIrtAction::"+e.getMessage());
				}finally{
					//6. POS로 내려줄 데이터 만들기
					if("1".equals(flag)){
						hmData.put("INQ_TYPE", "E3");
						hmData.put("RESP_CD", rsltCd);
						hmData.put("RESP_MSG", rsltMsg);
						hmData.put("ISSUE_DT", issDt);
						hmData.put("ISSUE_TM", issTm);
						
						logger.info(hmData);
						
						dataMsg = ret + makeSendDataEConIssRsp(hmData);
					}
				}
			}
		}
		
		return dataMsg;
	}
	
	
	//20180205 KSN -- ECon 조회 요청/응답
	//쿠폰 조회 요청
	private String EConSelFunc(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		logger.info("[INFO] EConIRT::hmCom::["+hmCom+"]");
		logger.info("[INFO] EConIRT::hmData::["+hmData+"]");
		
		String cpStsId  = "0";
		String rsltCd   = "00";
		String rsltMsg  = "정상";
		String ret 		= "00";
		String dataMsg  = "";
		
		HashMap<String, String> econMap = new HashMap<String, String>();
		
		try{
			List econInfo = (List)dao.selEConInfo(hmData, hmCom);
			
			logger.info("[INFO] econInfo.size::["+econInfo.size()+"]");
			if(econInfo.size() > 0){
				for(int i = 0; i<econInfo.size(); i++){
					econMap = (HashMap<String, String>) econInfo.get(i);
					logger.info(econMap);
					
					cpStsId = econMap.get("COUPON_STS_ID");
					
					if("9".equals(cpStsId)){
						logger.info("[INFO] 유효기간이 만료된 쿠폰입니다.");
						rsltCd = "40";
						rsltMsg = "유효기간이 만료된 쿠폰입니다.";
					}else if ("1".equals(cpStsId)){
						logger.info("[INFO] 사용완료된 쿠폰입니다.");
						rsltCd = "50";
						rsltMsg = "사용완료된 쿠폰입니다.";
					}else if ("0".equals(cpStsId)){
						logger.info("[INFO] 사용가능 쿠폰입니다.");
					}else if ("3".equals(cpStsId)){
						logger.info("[INFO] 발행취소된 쿠폰입니다.");
						rsltCd = "80";
						rsltMsg = "발행취소된 쿠폰입니다.";
					}else{
						logger.info("[ERROR] 쿠폰상태값 오류입니다. 시스템 담당자에게 문의하세요.");
						rsltCd = "60";
						rsltMsg = "쿠폰상태값 오류입니다. 시스템 담당자에게 문의하세요.";
					}
				}
			}else{
				//유효하지 않은 쿠폰번호 오류
				logger.info("[ERROR] 쿠폰이 존재하지 않습니다. 쿠폰번호를 확인해주세요. ["+hmData.get("COUPON_NO")+"]");
				rsltCd = "70";
				rsltMsg = "쿠폰이 존재하지 않습니다.";
				
				econMap.put("COUPON_NO", hmData.get("COUPON_NO"));
				econMap.put("COUPON_TP", "");
				econMap.put("COUPON_AMT_TP", "");
				econMap.put("COUPON_AMT", "");
				econMap.put("COUPON_RM_AMT", "");
				econMap.put("COUPON_PLU_CD", "");
				
				econMap.put("COUPON_STS_ID", "");
				econMap.put("COUPON_USE_EXPR_AMT", "");
				econMap.put("OTH_STORE_YN", "");
				econMap.put("STORE_CD", "");
				econMap.put("CP_AMTMNG_YN", "");
			}
			
		}catch(Exception e){
			ret = "29";
		}finally{
			//6. POS로 내려줄 데이터 만들기
			econMap.put("INQ_TYPE", "E5");
			econMap.put("RESP_CD", rsltCd);
			econMap.put("RESP_MSG", rsltMsg);
			
			logger.info(econMap);
			dataMsg = ret + makeSendDataEConSelRsp(econMap);
		}
		
		return dataMsg;
	}
	
	
	//20180129 KSN 쿠폰 발행 응답
	private String makeSendDataEConIssRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 2, 64, 8, 8,
			20, 12, 12, 20, 
			8, 6
		};//162
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			, // 응답메시지
			"START_DT"			, // 사용가능시작일
			"EXPIRE_DT"			, // 사용가능종료일
			
			"ISSUE_CPN_NO"		, // 쿠폰번호
			"COUPON_AMT"		, // 금액(율)
			"COUPON_RM_AMT"		, // 쿠폰잔액 (금액권 or 금액할인권)
			"COUPON_PLU_CD"		, // 교환상품코드
			"ISSUE_DT"			, // 쿠폰발행일자
			
			"ISSUE_TM"	 		  // 쿠폰발행시간
		};
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//20180205 KSN 쿠폰 조회 응답
	private String makeSendDataEConSelRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 2, 64, 20, 3,
			1, 12, 12, 20, 1,
			12, 1, 5, 1
		};//156
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			, // 응답메시지
			"COUPON_NO"			, // 쿠폰번호
			"COUPON_TP"			, // 쿠폰유형
			
			"COUPON_AMT_TP"		, // 금액/율 구분
			"COUPON_AMT"		, // 금액(율)
			"COUPON_RM_AMT"		, // 쿠폰잔여금액
			"COUPON_PLU_CD"		, // 교환상품코드
			"COUPON_STS_ID"		, // 쿠폰상태값
			
			"COUPON_USE_EXPR_AMT" , // 쿠폰사용기준금액
			"OTH_STORE_YN"		, // 타점사용가능여부
			"STORE_CD"	  		, // 쿠폰발행점포
			"CP_AMTMNG_YN"		  // 쿠폰잔액관리여부
		};
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	//20180205 -- 쿠폰 승인/취소 요청
	private String EConApprFunc(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		
		String cpStsId  = "0";
		String rsltCd   = "00";
		String ret		= "00";
		String rsltMsg  = "정상";
		String dataMsg  = "";
		String cpNo 	= hmData.get("COUPON_NO");
		String othYn	= "N";
		String storeCd	= hmCom.get("STORE_CD");
		String tradeDt  = hmData.get("TRADE_DT");
		
		int tradeAmt  = Integer.parseInt(hmData.get("TRADE_AMT"));
		int remainAmt = 0;
		
		boolean apprEcon = true;
		
		HashMap<String, String> econMap = new HashMap<String, String>();
		
		try{
			List econInfo = (List)dao.selEConInfo(hmData, hmCom); //20180512 쿠폰 중복발번 임시대응
			
			if(econInfo.size() > 0){
				for(int i = 0; i<econInfo.size(); i++){
					econMap = (HashMap<String, String>) econInfo.get(i);
					
					cpStsId = econMap.get("COUPON_STS_ID");
					othYn   = econMap.get("OTH_STORE_YN");
					remainAmt = Integer.parseInt(econMap.get("COUPON_RM_AMT"));
					
					if("N".equals(othYn)){ //타점 사용불가 쿠폰
						if(!storeCd.equals(econMap.get("STORE_CD"))){ //store_cd 체크
							logger.info("쿠폰을 사용할 수 없는 점포입니다.");
							apprEcon = false;
							rsltCd  = "80";
							rsltMsg = "쿠폰을 사용할 수 없는 점포입니다.";
						}
					}
					
					if(apprEcon){
						if("00".equals(hmData.get("TRADE_TP"))){ //승인
							if("0".equals(cpStsId)){
								if("310".equals(cpNo.substring(0, 3))){
									if(tradeAmt <= remainAmt){
										Random rd = new Random();
										econMap.put("AUTH_NO", String.valueOf(rd.nextInt(100000000)));
										econMap.put("AUTH_DT", sdf.format(new Date()).substring(0, 8));
										econMap.put("AUTH_TM", sdf.format(new Date()).substring(8, 14));
										
										//2. 잔여금액계산
										if("Y".equals(econMap.get("CP_AMTMNG_YN"))){
											remainAmt = remainAmt - tradeAmt;	
										}else{
											remainAmt = 0;
										}
										
										//3. update mst table (잔액, 쿠폰상태값)
										econMap.put("COUPON_RM_AMT", String.valueOf(remainAmt));	
										if(remainAmt == 0){
											econMap.put("COUPON_STS_ID", "1");
										}
										
										try{
											dao.updEConMst(econMap);
										}catch(Exception e){
											ret = "29";
											logger.info(e.getMessage());
										}
									}else{
										logger.info("[INFO] 잔액이 부족합니다. 사용가능 금액 ["+remainAmt+"원]");
										rsltCd  = "90";
										rsltMsg = "잔액이 부족합니다. 사용가능 금액 ["+remainAmt+"원]";
									}
								}else{
									rsltCd  = "99";
									rsltMsg = "금액형 쿠폰이 아닙니다.";
								}
							}else{
								if("1".equals(cpStsId)){
									logger.info("[ERROR] 사용완료 된 쿠폰입니다.");
									rsltCd = "65";
									rsltMsg = "사용완료 된 쿠폰입니다.";
								}else if("9".equals(cpStsId)){
									logger.info("[ERROR] 기간만료 된 쿠폰입니다.");
									rsltCd = "40";
									rsltMsg = "기간만료 된 쿠폰입니다.";
								}else{
									logger.info("[ERROR] 사용할 수 없는 쿠폰입니다.");
									rsltCd = "75";
									rsltMsg = "사용할 수 없는 쿠폰입니다.";
								}
							}
						}else if("01".equals(hmData.get("TRADE_TP"))){	//취소
							if("310".equals(cpNo.substring(0, 3))){	//금액형
								Random rd = new Random();
								econMap.put("AUTH_NO", String.valueOf(rd.nextInt(100000000)));
								econMap.put("AUTH_DT", sdf.format(new Date()).substring(0, 8));
								econMap.put("AUTH_TM", sdf.format(new Date()).substring(8, 14));
								
								//2. 잔여금액계산
								if("Y".equals(econMap.get("CP_AMTMNG_YN"))){
									remainAmt = remainAmt + tradeAmt;
								}else{
									remainAmt = Integer.parseInt(econMap.get("COUPON_AMT"));
								}
								econMap.put("COUPON_RM_AMT", String.valueOf(remainAmt));
								
								//3. update mst table (잔액, 쿠폰상태값)
								if(tradeDt.compareTo(econMap.get("START_DT")) >= 0 && tradeDt.compareTo(econMap.get("EXPIRE_DT")) <= 0){
									if(remainAmt > 0){
										econMap.put("COUPON_STS_ID", "0");
										
										try{
											dao.updEConMst(econMap);
										}catch(Exception e){
											ret = "29";
											logger.info(e.getMessage());
										}
									}
								}else{
									logger.info("[ERROR] 기간만료 쿠폰. 취소처리가 불가합니다.");	//오류 리턴
									rsltCd = "40";
									rsltMsg = "기간만료 쿠폰. 취소처리가 불가합니다.";
								}
							}
						}else{
							logger.info("[ERROR] 거래유형오류");	//오류 리턴
							rsltCd = "45";
							rsltMsg = "거래유형오류";
						}
					}
				}
			}else{
				//유효하지 않은 쿠폰번호 오류
				logger.info("[ERROR] 쿠폰이 존재하지 않습니다. 쿠폰번호를 확인해주세요. ["+hmData.get("COUPON_NO")+"]");
				rsltCd = "99";
				rsltMsg = "쿠폰번호를 확인해주세요.["+hmData.get("COUPON_NO")+"]";
			}
			
		}catch(Exception e){
			ret = "29";
			logger.info(e.getMessage());
		}finally{
			//6. POS로 내려줄 데이터 만들기
			econMap.put("INQ_TYPE", "E7");
			econMap.put("RESP_CD", rsltCd);
			econMap.put("RESP_MSG", rsltMsg);
			econMap.put("TRADE_TP", hmData.get("TRADE_TP"));
			
			if(!"00".equals(rsltCd)){
				econMap.put("AUTH_NO", "");
				econMap.put("AUTH_DT", "");
				econMap.put("AUTH_TM", "");
			}
			
			dataMsg = ret + makeSendDataEConAppRsp(econMap);
		}
		
		return dataMsg;
	}
	
	
	//20180205 KSN 쿠폰 조회 응답
	private String makeSendDataEConAppRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 2, 64, 2, 20,
			8, 8, 12, 10, 8,
			6, 20
		};//109
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			, // 응답메시지
			"TRADE_TP"			, // 거래유형
			"COUPON_NO"			, // 쿠폰번호
			
			"START_DT"			, // 사용가능시작일
			"EXPIRE_DT"			, // 사용가능종료일
			"COUPON_RM_AMT"		, // 쿠폰잔여금액
			"AUTH_NO"			, // 승인번호
			"AUTH_DT"			, // 승인일자

			"AUTH_TM"			, // 승인시간
			"EVT_CD"			  // 이벤트코드
		};
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//20180323 KSN 쿠폰발행취소 처리
	private String EConIssCancelFunc(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		
		String cpStsId  = ""; //쿠폰 발행취소 상태값
		String rsltCd   = "00";
		String ret		= "00";
		String rsltMsg  = "";
		String dataMsg  = "";
		String cpNo 	= hmData.get("COUPON_NO");
		
		HashMap<String, String> econMap = new HashMap<String, String>();
		
		try{
			List econInfo = (List)dao.selEConIssInfo(hmData);
			logger.info("econInfo Size::" + econInfo.size());
			
			if(econInfo.size() > 0){
				for(int i = 0; i<econInfo.size(); i++){
					econMap = (HashMap<String, String>) econInfo.get(i);
					
					cpNo    = econMap.get("COUPON_NO");
					cpStsId = econMap.get("COUPON_STS_ID");
					
					logger.info("cpNo::["+cpNo+"]::cpStsId::["+cpStsId+"]");
					
					if("0".equals(cpStsId)){ //미사용쿠폰
						econMap.put("COUPON_RM_AMT", "0");
						econMap.put("COUPON_STS_ID", "3");
						
						try{
							dao.updEConMst(econMap);
							rsltMsg = "환불거래 쿠폰은 사용할 수 없습니다.";
						}catch(Exception e){
							logger.info("[ERROR]"+e.getMessage());
						}
					}
					logger.info("cpNo::["+cpNo+"]::cpStsId::["+cpStsId+"]::rsltMsg::["+rsltMsg+"]");
				}
			}else{
				//유효하지 않은 쿠폰번호 오류
				logger.info("[ERROR] 발행쿠폰이 존재하지 않습니다. ["+hmData.get("COUPON_NO")+"]");
				rsltCd = "99";
				rsltMsg = "발행쿠폰이 존재하지 않습니다.";
			}
			
		}catch(Exception e){
			ret = "29";
			logger.info("[ERROR]"+e.getMessage());
		}finally{
			//6. POS로 내려줄 데이터 만들기
			econMap.put("INQ_TYPE", "E8");
			econMap.put("RESP_CD", rsltCd);
			econMap.put("RESP_MSG", rsltMsg);
			
			if("99".equals(rsltCd)){
				econMap.put("TRAN_YMD", hmCom.get("TRAN_YMD"));
				econMap.put("STORE_CD", hmCom.get("STORE_CD"));
				econMap.put("POS_NO", hmCom.get("POS_NO"));
				econMap.put("TRAN_NO", hmCom.get("TRAN_NO"));
				econMap.put("COUPON_NO", cpNo);
			}
			
			logger.info("[INFO]econMap::["+econMap+"]");
			
			dataMsg = ret + makeSendDataEConIssCnRsp(econMap);
			
			logger.info("[INFO]dataMsg::["+dataMsg+"]");
		}
		return dataMsg;
	}
	
	
	//20180205 KSN 쿠폰 조회 응답
	private String makeSendDataEConIssCnRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 8, 5, 4, 4,
			20, 2, 64
		};//109
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"TRAN_YMD"			, // 쿠폰발행일자
			"STORE_CD"			, // 발행점포
			"POS_NO"			, // 발행포스번호
			"TRAN_NO"			, // 발행거래번호
			
			"COUPON_NO"			, // 쿠폰번호
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시디
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
}



