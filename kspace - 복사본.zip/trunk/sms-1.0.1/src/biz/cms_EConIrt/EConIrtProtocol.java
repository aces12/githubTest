package biz.cms_EConIrt;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.regex.Pattern;

import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class EConIrtProtocol {
	
	private static Logger logger = Logger.getLogger(EConIrtAction.class);
	
	/***
	 * getRcvEConIrtDATA
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	
	public String getRcvEConIrtDATA(String rcvBuf){		
		HashMap<String, String> hm = new HashMap<String, String>();
		
		logger.info("EConIrtDATA::rcvBuf::["+rcvBuf+"]");
		
		int nlens[]= {2};
		String strHeaders[] = { "INQ_TYPE" };		
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		logger.info("EConIrtDATA::hm::["+hm+"]");
		
		return (String)hm.get("INQ_TYPE");
	}
	
	
	//20180122 KSN 쿠폰 발행 요청
	public HashMap<String, String> getParseEConIssReq(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 
			2, 1, 3, 20, 1,
			12, 12, 12, 5, 3,
			20
		};//91
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"ISSUE_SYS"			, // 발행요청시스템
			"COUPON_TP"			, // 쿠폰유형
			"EVT_CD"			, // 행사코드
			"COUPON_AMT_TP"		, // 금액/율 구분
			
			"COUPON_AMT"		, // 금액(율)
			"COUPON_STD_AMT"	, // 쿠폰발행기준금액
			"TRADE_AMT"			, // 거래금액
			"ISSUE_REQ_CNT"		, // 발행요청개수
			"COUPON_DURATION"	, // 쿠폰사용기간
			
			"COUPON_PLU_CD"		  // 쿠폰교환상품코드
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
	
	
	//20180202 KSN 쿠폰 조회 요청
	public HashMap<String, String> getParseEConSelReq(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 
			2, 20, 8
		};//30
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"COUPON_NO"			, // 쿠폰번호
			"TRADE_DT"			  // 조회요청일자
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
	
	
	//20180205 KSN 쿠폰 승인/취소 요청
	public HashMap<String, String> getParseEConAppReq(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 
			2, 2, 8, 6, 20,
			12, 20, 8, 5, 4,
			4, 10, 8
		};//115
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"TRADE_TP"			, // 거래유형
			"TRADE_DT"			, // 요청일자
			"TRADE_TM"			, // 요청시간
			"COUPON_NO"			, // 쿠폰번호
			
			"TRADE_AMT"			, // 사용요청금액
			"COUPON_PLU_CD"		, // 교환상품코드
			"ORG_TRAN_YMD"		, // 원거래일자
			"ORG_STORE_CD"		, // 원거래 점포코드
			"ORG_POS_NO"		, // 원거래 포스번호
			
			"ORG_TRAN_NO"		, // 원거래번호
			"ORG_AUTH_NO"		, // 원거래승인번호
			"ORG_AUTH_DT"		  // 원거래승인일자
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
	
	//20180205 KSN 쿠폰 승인/취소 요청
	public HashMap<String, String> getParseEConIssCnReq(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 
			2, 8, 5, 4, 4,
			20, 2, 64
		};//109
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"TRAN_YMD"			, // 쿠폰발행일자
			"STORE_CD"			, // 발행점포
			"POS_NO"			, // 발행포스번호
			"TRAN_NO"			, // 발행거래번호
			
			"COUPON_NO"			, // 쿠폰번호
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
}