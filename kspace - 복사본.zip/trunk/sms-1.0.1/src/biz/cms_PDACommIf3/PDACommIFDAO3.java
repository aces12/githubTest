package biz.cms_PDACommIf3;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sun.org.apache.xalan.internal.xsltc.compiler.Pattern;

import biz.comm.COMMBiz_PDA;
import biz.comm.COMMLog;
import kr.fujitsu.com.ffw.model.Closer;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;
 
public class PDACommIFDAO3 extends GenericDAO {

	private static String LOGISTIC_FIRST_CODE   = "A14";
	private static int ROWS_COUNT_SIZE = 10;

	

	public String selUserInfo_WMS(String userID, String userPW, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap(); 
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String IDMSG = "";
		connect("CRYDEV");
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_WMS_USER_INFO));
			sql.setString(++i, userID.trim());
			sql.setString(++i, userPW.trim());
			df.CommLogger("SQL:" + sql.debug());
			//	SELECT USER_ID FROM CR_SYSUSER_MST
			//WHERE USER_ID = ? AND CUBEONE.ENC_VARCHAR2_INS(?,10,'PWD') = PWD
			list = executeQuery(sql);
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				IDMSG = (String)map.get("RESULT");
				if( userID.length() > 0 ) {
					map.put("USER_ID", IDMSG);
				}else{
					map.put("USER_ID", " ");
				}
				
			}else {
				map.put("USER_ID", " ");
				ret = "09";
			}
			
			hm.put("INQ_TYPE", "10");
			if(IDMSG.equals("1")){
				hm.put("USER_PWD", userPW);
				
			}
			df.CommLogger(IDMSG);
			//df.CommLogger(userID + (String)map.get("USER_NM"));
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			rollback();
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e.getMessage());
			ret = "20";
			rollback();
			throw e;
		}finally {
			sql.close();
			end();
			dataMsg = ret;
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String selUserInfo_WMS2(String userID, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap(); 
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String IDMSG = "";
		connect("COMDEV");
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_WMS_USER_NM));
			sql.setString(++i, userID.trim());
			
			df.CommLogger("SQL:" + sql.debug());
			//	SELECT USER_ID FROM CR_SYSUSER_MST
			//WHERE USER_ID = ? AND CUBEONE.ENC_VARCHAR2_INS(?,10,'PWD') = PWD
			list = executeQuery(sql);
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				IDMSG = (String)map.get("RESULT");
				if( userID.length() > 0 ) {
					hm.put("USER_NM", IDMSG);
					hm.put("USER_ID", userID);
					map.put("USER_PWD", (String)hm.get("USER_PWD"));
					hm.put("USER_LEVEL", " ");
					hm.put("USER_TYPE"," ");
				}else{
					hm.put("USER_NM", " ");
				}
				
			}else {
				hm.put("USER_ID", " ");
				ret = "09";
			}
			
			hm.put("INQ_TYPE", "10");
		
			df.CommLogger(IDMSG);
			//df.CommLogger(userID + (String)map.get("USER_NM"));
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			rollback();
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e.getMessage());
			ret = "20";
			rollback();
			throw e;
		}finally {
			sql.close();
			end();
			dataMsg = ret + makeUserInfoSendData(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}	
	
	/***************************************************************************
	 * selUserInfoLogistic 물류 사용자 조회2 - XCOSMOS ID조회 
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selUserInfoLogistic2(String userID, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap(); 
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String userNM = "";
		connect("CMGNS");
		String OriginID = userID;
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTIC_USER_INFO2));
			sql.setString(++i, userID.trim());
			df.CommLogger("SQL:" + sql.debug());
			
			list = executeQuery(sql);
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				// USER_ID, USER_NM 
				userNM = (String)map.get("USER_NM");
				if( userNM.length() > 0 ) {
					map.put("USER_NM", userNM);
				}else{
					map.put("USER_NM", "");
				}
				userID = (String)map.get("USER_ID");
				if( userID.length() > 0 ) {
					map.put("USER_ID", userID);
				}else{
					map.put("USER_ID", "");
				}
				
			}else {
				map.put("USER_NM", " ");
				map.put("USER_ID", " ");
				ret = "09";
			}
			
			hm.put("INQ_TYPE", "10");
			hm.put("USER_ID", userID);
			hm.put("ORIGIN", OriginID);
			hm.put("USER_NM", (String)map.get("USER_NM"));
			if(userNM.length() > 3){
				df.CommLogger(userID + (String)map.get("USER_NM"));
			}
			else{
				df.CommLogger("null");
			}
			
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			rollback();
			throw e;
		}finally {
			sql.close();
			end();
			//dataMsg = ret + makeUserInfoSendData(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selUserInfoLogistic 물류 사용자 조회2 - XCOSMOS PW조회 
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selUserInfoLogistic3(String userID, String userPW,HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap(); 
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String IDMSG = "";
		connect("CMSEC");
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTIC_USER_INFO3));
			sql.setString(++i, userID.trim());
			sql.setString(++i, userPW.trim());
			df.CommLogger("SQL:" + sql.debug());
			//	SELECT USER_ID FROM CR_SYSUSER_MST
			//WHERE USER_ID = ? AND CUBEONE.ENC_VARCHAR2_INS(?,10,'PWD') = PWD
			list = executeQuery(sql);
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				IDMSG = (String)map.get("USER_ID");
				if( userID.length() > 0 ) {
					map.put("USER_ID", IDMSG);
				}else{
					map.put("USER_ID", " ");
				}
				
			}else {
				map.put("USER_ID", " ");
				ret = "09";
			}
			
			hm.put("INQ_TYPE", "10");
			if(IDMSG.equals("1")){
				hm.put("USER_PWD", userPW);
				hm.put("USER_LEVEL", "1");
				hm.put("USER_TYPE", "2");
			}
			df.CommLogger(IDMSG);
			//df.CommLogger(userID + (String)map.get("USER_NM"));
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			rollback();
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e.getMessage());
			ret = "20";
			rollback();
			throw e;
		}finally {
			sql.close();
			end();
			dataMsg = ret + makeUserInfoSendData2(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeUserInfoSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeUserInfoSendData2(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 13, 60, 50,2,2};
		String strHeaders[] = {
				"INQ_TYPE",   	// "10": Search User(사용자 조회)
				"ORIGIN",		// User ID(사용자ID)
				"USER_PWD",    	// User Password(사용자 비밀번호)
				"USER_NM",		// User Name(사용자 이름)
				"USER_LEVEL",
				"USER_TYPE"
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger(strHeaders[i].toString() + (String)hm.get(strHeaders[i].toString()) );
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * selUserInfoLogistic 물류 사용자 조회2 - XCOSMOS PW조회 
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selUserInfoLogistic4(String userID, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap(); 
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		 
		connect("REDRMD");
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTIC_USER_INFO4));
			sql.setString(++i, userID.trim());
			df.CommLogger("SQL:" + sql.debug());
			String idfalt = userID;
			//	SELECT USER_ID FROM CR_SYSUSER_MST
			//WHERE USER_ID = ? AND CUBEONE.ENC_VARCHAR2_INS(?,10,'PWD') = PWD
			list = executeQuery(sql);
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				//	SELECT EMPNO, EMPNM SYS001
				//WHERE EMPNO = ?
				userID = (String)map.get("ACCTUT");
				if( userID.length() > 0 ) {
					map.put("USER_ID", userID);
				}else{
					map.put("USER_ID", idfalt);
				}
				
			}else {
				map.put("USER_ID", idfalt);
				ret = "09";
			}
			
			hm.put("INQ_TYPE", "10");
			hm.put("USER_ID", userID);
			df.CommLogger(userID);
			//df.CommLogger(userID + (String)map.get("USER_NM"));
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			rollback();
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			sql.close();
			end();
			dataMsg = ret + makeUserInfoSendData(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selUserInfoLogistic 물류 사용자 조회 
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selUserInfoLogistic(String comCD, String storeCD, String userID, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap(); 
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		 
		connect("REDRMD");
		try {
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTIC_USER_INFO));
			
			sql.setString(++i, storeCD.trim());
			sql.setString(++i, userID.trim());
			sql.setString(++i, comCD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			df.CommLogger("SQL:" + sql.debug());
//			df.CommLogger("SQL:" + sql.debug());
			
			list = executeQuery(sql);
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				String userPW = (String)map.get("NO_PASSWORD");
				if( userPW.length() > 0 ) {
					map.put("USER_PWD", userPW);
				}else{
					map.put("USER_PWD", "");
				}
				String userNM = (String)map.get("EMPNM");
				if( userNM.length() > 0 ) {
					map.put("USER_NM", userNM);
				}else{
					map.put("USER_NM", "");
				}
				String userTY = (String)map.get("GBN");
				if( userTY.length() > 0 ) {
					map.put("USER_LEVEL", userTY);
				}else{
					map.put("USER_LEVEL", "");
				}
				map.put("USER_TYPE", "2");
			}else {
				map.put("USER_PWD", " ");
				map.put("USER_NM", " ");
				map.put("USER_LEVEL", " ");
				map.put("USER_TYPE", " ");
				ret = "09";
			}
			
			hm.put("INQ_TYPE", "10");
			hm.put("USER_ID", userID);
			hm.put("USER_PWD", (String)map.get("USER_PWD"));
			hm.put("USER_NM", (String)map.get("USER_NM"));
			hm.put("USER_LEVEL", (String)map.get("USER_LEVEL"));
			hm.put("USER_TYPE", (String)map.get("USER_TYPE"));
			df.CommLogger(userID + (String)map.get("USER_PWD"));
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			dataMsg = ret + makeUserInfoSendData(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}

	/***************************************************************************
	 * makeUserInfoSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeUserInfoSendData(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 13, 60, 50, 2, 2 };
		String strHeaders[] = {
				"INQ_TYPE",   	// "10": Search User(사용자 조회)
				"USER_ID",		// User ID(사용자ID)
				"USER_PWD",    	// User Password(사용자 비밀번호)
				"USER_NM",		// User Name(사용자 이름)
				"USER_LEVEL",	// User Level(사용자 레벨)
				"USER_TYPE"	// User Level(사용자 레벨)
		};

		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger(strHeaders[i].toString() + (String)hm.get(strHeaders[i].toString()) );
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	/***************************************************************************
	 * getLogisticInventory2Req
	 * : 물류 센터코드 요청
	
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selCenterInfos(HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int total_cnt = 0;
		connect("REDRMD");

		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_SEL_CENTER_INFO));
		
			
			//df.CommLogger("sql=" + sql.debug());
			list = executeQuery(sql);
			if(list.size()<=0)
			{
				ret = "09";
			}
			sql.close();
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeCenterCDForServer(hm,list,df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		return dataMsg;
	}
	/***************************************************************************
	 * getLogisticInventory2Req
	 * : 물류 재고 조사 요청
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticInventory2Req(String pCOM_CD, String pCENTER_CD, HashMap<String, String> hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map<String, String> map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int total_cnt = 0;
		connect("REDRMD");
		
		try {
			begin();
			
			total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
//			df.CommLogger("▶ROWS_COUNT=" + (String)hm.get("ROWS_COUNT").toString().trim());
			
			String CENTER_CD = (String)hm.get("CENTER_CD" + Integer.toString(0)).toString().trim();
			String SILSA_DT = (String)hm.get("SILSA_DT" + Integer.toString(0)).toString().trim();
			
//			df.CommLogger("▶CENTER_CD=" + CENTER_CD);
//			df.CommLogger("▶SILSA_DT=" + SILSA_DT);
			// ITEM별 재고조사 처리
			//
			for(int idx = 0;idx < total_cnt;idx++) {
				i = 0;
				String SILSA_QTY = (String)hm.get("SILSA_QTY" + Integer.toString(idx)).toString().trim();
//				df.CommLogger("▶SILSA_QTY=" + (String)hm.get("SILSA_QTY" + Integer.toString(idx)).toString().trim());
				list = null;
				
				int nSILSA_QTY = Integer.parseInt(SILSA_QTY);
				
//				df.CommLogger("▶1111");
				sql.clearParameter();
//				df.CommLogger("▶2222");
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.PR_LOGISTICS_INVENTORY2_ITEM));
//				df.CommLogger("▶3333");
				sql.setString(++i, CENTER_CD);																	/* 센터코드 */
//				df.CommLogger("▶4444");
				sql.setString(++i, SILSA_DT);																	/* 실사일자 */
//				df.CommLogger("▶5555");
				sql.setString(++i, (String)hm.get("BRAND_CD" + Integer.toString(idx)).toString().trim());		/* 브랜드코드 */
//				df.CommLogger("▶6666");
				sql.setString(++i, (String)hm.get("PLU_CD" + Integer.toString(idx)).toString().trim());			/* PLU_CD */
//				df.CommLogger("▶7777");
				sql.setString(++i, (String)hm.get("PLU_CD" + Integer.toString(idx)).toString().trim());			/* PLU_CD */
//				df.CommLogger("▶8888");
				sql.setInt	 (++i, nSILSA_QTY);																	/* 실사수량 */
//				df.CommLogger("▶9999");
				sql.setString(++i, pCOM_CD);																	/* 사업장코드 */
				
//				df.CommLogger("▶0000");
				int rows = executeUpdate(sql);
				sql.close();
			}
			i = 0;
			sql.clearParameter();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.PR_LOGISTICS_INVENTORY2_STATEMENT));
			sql.setString(++i, CENTER_CD);		/* 센터코드 */
			sql.setString(++i, SILSA_DT);		/* 실사일자 */
			sql.setString(++i, pCOM_CD);		/* 사업장코드 */
			
//			df.CommLogger("▶sql=" + sql.debug());
			int rows2 = executeUpdate(sql);
			
			sql.close();
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback Code=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Rollback Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			hm.put("RESULT_CD", ret);
			dataMsg = ret + makeLogisticInventory2UpdateReq(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeLogisticInventory2UpdateReq(HashMap<String, String> hm, List<Object> list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map<String, String> map = new HashMap<String, String>();
		int hdr_lens[] = {
			2,
			10
		};
		String hdr_StrHeaders[] = {
			"INQ_TYPE",
			"RESULT_CD"
		};
		
		try
		{
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()+"0"), hdr_lens[0]);
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[1].toString()), hdr_lens[1]);
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticInventory2UpdateReq Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * getLogisticSellDateHistReq
	 * : 입고 유통기한 이력 요청 (NEW)
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticSellDateHistReq(String pCOM_CD, String pCENTER_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map<String, String> map = new HashMap<String, String>();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int total_cnt = 0;
		
		connect("REDRMD");
		
		try {
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTICS_PURCHASE_HIST_REQ));
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
			sql.setString(++i, pCENTER_CD.trim() );                         /* 센터코드 */
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());	/* 상품코드 */

			// LOGISTIC_FIRST_CODE
//			df.CommLogger("▶ SQL : " + sql.debug() );
			
			list = executeQuery(sql);
			
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticSellDateHistReq(hm,list,df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	public String insPDAVersion(String pCOM_CD, String pSTORE_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int iRtn = 0;
		String dataMsg = "";
		String ret = "00";
		List list = null;
		Map map = new HashMap(); 
		connect("CMGNS");
		try {
			begin();

			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.INS_PDAVERSION_MGR));
			sql.setString(++i, pCOM_CD.toString().trim());											// CO_CD
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD"));									// BIZLOC_ORG_CD
			sql.setString(++i, (String)hm.get("PDA_NO"));											// PDA_NO
			sql.setString(++i, (String)hm.get("IP_ADDR"));											// TRAN_NO
			sql.setString(++i, (String)hm.get("VERSION"));											// TOT_SALE_AMT
			
			iRtn = executeUpdate(sql);
//			df.CommLogger(String.valueOf(iRtn));
			if(iRtn == 1){
			//hm.put("INQ_TYPE", "76");
			//hm.put("RESULT_CD", "00");
			}
			else{
				hm.put("INQ_TYPE", "76");
				hm.put("RESULT_CD", "00");
			}
			sql.close();// sql 닫기
			sql.clearParameter();//파라미터 비우기
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PDAVERSION_MGR));
			//df.CommLogger(sql.debug());
			list = executeQuery(sql);
			//카운팅 값
			
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				String RESULT = (String)map.get("RESULT_CD");
				if( RESULT.length() > 0 ) {
					hm.put("INQ_TYPE", "76");
					hm.put("RESULT_CD", RESULT);
				}else{
					hm.put("RESULT_CD", "00");
				}
			}
			else
			{
				ret = "09";
			}
			sql.close();
			
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e.getStackTrace());
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeSaleInfoChkSendData(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeSaleInfoChkSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeSaleInfoChkSendData(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 5 };
		String strHeaders[] = {
				"INQ_TYPE",   	// 버전체크
				"RESULT_CD"//결과
				
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger(strHeaders[i].toString() + (String)hm.get(strHeaders[i].toString()) );
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	private String makeLogisticSellDateHistReq(HashMap<String, String> hm, List list, COMMLog df) throws Exception{
		StringBuffer sb = new StringBuffer();
		Map<String, String> map = new HashMap<String, String>();
		int hdr_lens[] = {  2,  2,  8,  8, 10  };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	//INQ_TYPE = 75,
				"HISTCOUNT",	//히스토리 카운트
				"MPILJA",		//확정일자
				"SELLDATE",		//유통기한
				"SELLDATE_SEQ"	//확정수량
		};
		
		int total_cnt = list.size();
		
		try {
			if( total_cnt > 0 ) {
				map = (Map<String, String>)list.get(0);
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);	// INQ_TYPE
				StringUtil.appendSpace(sb, Integer.toString(total_cnt), hdr_lens[1]);					// HISTCOUNT
				for(int i = 0;i < total_cnt;i++) {
					map = (Map<String, String>)list.get(i);
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 2]), hdr_lens[ 2]);		// MPILJA
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 3]), hdr_lens[ 3]);		// SELLDATE
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 4]), hdr_lens[ 4]);		// SELLDATE_SEQ
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);	// INQ_TYPE
				StringUtil.appendSpace(sb, Integer.toString(total_cnt), hdr_lens[1]);					// HISTCOUNT
				StringUtil.appendSpace(sb, " ", hdr_lens[ 2]);			// MPILJA
				StringUtil.appendSpace(sb, " ", hdr_lens[ 3]);			// SELLDATE
				StringUtil.appendSpace(sb, " ", hdr_lens[ 4]);			// SELLDATE_SEQ
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeLogisticSellDateHistReq : " + e.getMessage());
			throw e;
		}
		
		return sb.toString();
	}
	
	/***************************************************************************
	 * getLogisticPurReq
	 * : 입고 매입 요청 (NEW)
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticPurReq(String pCOM_CD, String pCENTER_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map<String, String> map = new HashMap<String, String>();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int total_cnt = 0;
		
		connect("REDRMD");
		
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTICS_PURCHASE_NEW_REQ));
			//df.CommLogger(pCOM_CD+pCENTER_CD+(String)hm.get(("NPYJIL").toString().trim())+(String)hm.get("PLU_CD").toString().trim());
			sql.setString(++i, pCOM_CD.trim());                                    /* 회사코드 */
			sql.setString(++i, (String)hm.get("NPYJIL").toString().trim());	/* 납품예정일 */
			sql.setString(++i, pCENTER_CD.trim());                         /* 센터코드 */
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim()); /* 거래처코드 */
			sql.setString(++i, pCENTER_CD.trim());                         /* 센터코드 */
			// LOGISTIC_FIRST_CODE
			//df.CommLogger("▶ SQL : " + sql.debug() );
			
			list = executeQuery(sql);
			
//			total_cnt = list.size();
//			
//			if( total_cnt <= 0 ) {
//				hm.put("CUST_NM", " ");
//				hm.put("COUNT", "0");
//				hm.put("PLU_CD0", " ");
//				hm.put("PLU_NM0", " ");
//				hm.put("BJ_QTY0", "0");
//				hm.put("CIRC_TMLMT0", " ");
//				hm.put("BJJPNO0", " ");
//				hm.put("BJSEQNO0", " ");
//				hm.put("SEQNO0", " ");
//				hm.put("MPILJA0", " ");
//				hm.put("JPGB0", " ");
//			}
			
			
			
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticPurReq(hm,list,df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * getLogisticPurReq
	 * : 입고 매입 요청 (NEW)20141105
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticPurReq2(String pCOM_CD, String pCENTER_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map<String, String> map = new HashMap<String, String>();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int total_cnt = 0;
		
		connect("REDRMD");
		
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTICS_PURCHASE_NEW_REQ3));
			
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
			sql.setString(++i, (String)hm.get("NPYJIL").toString().trim());	/* 납품예정일 */
			sql.setString(++i, pCENTER_CD.trim() );                         /* 센터코드 */
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim()); /* 거래처코드 */
			
			// LOGISTIC_FIRST_CODE
//			df.CommLogger("▶ SQL : " + sql.debug() );
			
			list = executeQuery(sql);
			
//			total_cnt = list.size();
//			
//			if( total_cnt <= 0 ) {
//				hm.put("CUST_NM", " ");
//				hm.put("COUNT", "0");
//				hm.put("PLU_CD0", " ");
//				hm.put("PLU_NM0", " ");
//				hm.put("BJ_QTY0", "0");
//				hm.put("CIRC_TMLMT0", " ");
//				hm.put("BJJPNO0", " ");
//				hm.put("BJSEQNO0", " ");
//				hm.put("SEQNO0", " ");
//				hm.put("MPILJA0", " ");
//				hm.put("JPGB0", " ");
//			}
			
			
			
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error2 : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticPurReq2(hm,list,df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	private String makeLogisticPurReq2(HashMap<String, String> hm, List list, COMMLog df) throws Exception{
		StringBuffer sb = new StringBuffer();
		Map<String, String> map = new HashMap<String, String>();
		int hdr_lens[] = {  2, 50, 10, 30, 50,
						   10, 10,  8, 20,  5,
						    8,  5,10  };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	//INQ_TYPE = 0,
                "CUST_NM",		//거래처명
                "COUNT",		//상품리스트건수
                "PLU_CD",		//상품코드
                "PLU_NM",		//상품명
                
                "BJ_QTY",		//발주수량
                "CIRC_TMLMT",	//마스터 유통기한
                "BJJPNO",		//발주전표일자
                "BJSEQNO",		//발주번호
                "SEQNO",		//발주순번
                
                "MPILJA",		//확정일자
                "JPGB",			//전표구분
                "SUPPLYER"		//센터코드
                
		};
		
		int total_cnt = list.size();
				
		try {
			if( total_cnt > 0 ) {
				map = (Map<String, String>)list.get(0);
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);	// INQ_TYPE
				StringUtil.appendSpace(sb, (String)map.get("CUST_NM"), hdr_lens[1]);					// CUST_NM
				StringUtil.appendSpace(sb, Integer.toString(total_cnt), hdr_lens[2]);					// COUNT
				for(int i = 0;i < total_cnt;i++) {
					map = (Map<String, String>)list.get(i);
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 3]), hdr_lens[ 3]);		// PLU_CD
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 4]), hdr_lens[ 4]);		// PLU_NM
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 5]), hdr_lens[ 5]);		// BJ_QTY
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 6]), hdr_lens[ 6]);		// CIRC_TMLMT
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 7]), hdr_lens[ 7]);		// BJJPNO
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 8]), hdr_lens[ 8]);		// BJSEQNO
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 9]), hdr_lens[ 9]);		// SEQNO
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[10]), hdr_lens[10]);		// MPILJA
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[11]), hdr_lens[11]);		// JPGB
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[12]), hdr_lens[12]);		// SUPPLYER
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);	// INQ_TYPE
				StringUtil.appendSpace(sb, " ", hdr_lens[1]);											// CUST_NM
				StringUtil.appendSpace(sb, Integer.toString(total_cnt), hdr_lens[2]);					// COUNT
				StringUtil.appendSpace(sb, " ", hdr_lens[ 3]);											// PLU_CD
				StringUtil.appendSpace(sb, " ", hdr_lens[ 4]);											// PLU_NM
				StringUtil.appendSpace(sb, " ", hdr_lens[ 5]);											// BJ_QTY
				StringUtil.appendSpace(sb, " ", hdr_lens[ 6]);											// CIRC_TMLMT
				StringUtil.appendSpace(sb, " ", hdr_lens[ 7]);											// BJJPNO
				StringUtil.appendSpace(sb, " ", hdr_lens[ 8]);											// BJSEQNO
				StringUtil.appendSpace(sb, " ", hdr_lens[ 9]);											// SEQNO
				StringUtil.appendSpace(sb, " ", hdr_lens[10]);											// MPILJA
				StringUtil.appendSpace(sb, " ", hdr_lens[11]);											// JPGB
				StringUtil.appendSpace(sb, " ", hdr_lens[12]);											// SUPPLYER
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeLogisticPurReq2 : " + e.getMessage());
			throw e;
		}
		
		return sb.toString();
	}
	
	private String makeLogisticPurReq(HashMap<String, String> hm, List list, COMMLog df) throws Exception{
		StringBuffer sb = new StringBuffer();
		Map<String, String> map = new HashMap<String, String>();
		int hdr_lens[] = {  2, 50, 10, 30, 100,
						   10, 10,  8, 20,  5,
						    8,  5  };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	//INQ_TYPE = 0,
                "CUST_NM",		//거래처명
                "COUNT",		//상품리스트건수
                "PLU_CD",		//상품코드
                "PLU_NM",		//상품명
                
                "BJ_QTY",		//발주수량
                "CIRC_TMLMT",	//마스터 유통기한
                "BJJPNO",		//발주전표일자
                "BJSEQNO",		//발주번호
                "SEQNO",		//발주순번
                
                "MPILJA",		//확정일자
                "JPGB"			//전표구분
                
                
		};
		
		int total_cnt = list.size();
				
		try {
			if( total_cnt > 0 ) {
				map = (Map<String, String>)list.get(0);
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);	// INQ_TYPE
				StringUtil.appendSpace(sb, (String)map.get("CUST_NM"), hdr_lens[1]);					// CUST_NM
				StringUtil.appendSpace(sb, Integer.toString(total_cnt), hdr_lens[2]);					// COUNT
				for(int i = 0;i < total_cnt;i++) {
					map = (Map<String, String>)list.get(i);
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 3]), hdr_lens[ 3]);		// PLU_CD
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 4]), hdr_lens[ 4]);		// PLU_NM
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 5]), hdr_lens[ 5]);		// BJ_QTY
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 6]), hdr_lens[ 6]);		// CIRC_TMLMT
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 7]), hdr_lens[ 7]);		// BJJPNO
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 8]), hdr_lens[ 8]);		// BJSEQNO
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[ 9]), hdr_lens[ 9]);		// SEQNO
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[10]), hdr_lens[10]);		// MPILJA
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[11]), hdr_lens[11]);		// JPGB
					
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);	// INQ_TYPE
				StringUtil.appendSpace(sb, " ", hdr_lens[1]);											// CUST_NM
				StringUtil.appendSpace(sb, Integer.toString(total_cnt), hdr_lens[2]);					// COUNT
				StringUtil.appendSpace(sb, " ", hdr_lens[ 3]);											// PLU_CD
				StringUtil.appendSpace(sb, " ", hdr_lens[ 4]);											// PLU_NM
				StringUtil.appendSpace(sb, " ", hdr_lens[ 5]);											// BJ_QTY
				StringUtil.appendSpace(sb, " ", hdr_lens[ 6]);											// CIRC_TMLMT
				StringUtil.appendSpace(sb, " ", hdr_lens[ 7]);											// BJJPNO
				StringUtil.appendSpace(sb, " ", hdr_lens[ 8]);											// BJSEQNO
				StringUtil.appendSpace(sb, " ", hdr_lens[ 9]);											// SEQNO
				StringUtil.appendSpace(sb, " ", hdr_lens[10]);											// MPILJA
				StringUtil.appendSpace(sb, " ", hdr_lens[11]);											// JPGB
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeLogisticPurReq : " + e.getMessage());
			throw e;
		}
		
		return sb.toString();
	}

	/***************************************************************************
	 * getLogisticPurchaseReq
	 * : 물류 매입 등록 ( 상품정보 요청 )
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticPurchaseReq(String pCOM_CD, String pCENTER_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		List histList = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int total_cnt = 0;
		connect("REDRMD");
		
		try {
//			df.CommLogger("▶ COM_CD : " + pCOM_CD);
//			df.CommLogger("▶ PLU_CD : " + (String)hm.get("PLU_CD").toString().trim());
			
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTICS_PURCHASE_REQ));
			 
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			sql.setString(++i, pCENTER_CD.trim() );                         /* 센터코드 */  
			sql.setString(++i, (String)hm.get("BJJPNO").toString().trim()); /* 매입일자 (전표일자) */
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim()); /* 품목코드 */
			// LOGISTIC_FIRST_CODE
//			df.CommLogger("▶ SQL : " + sql.debug() );
			
			list = executeQuery(sql);
			sql.close();
			total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			if( total_cnt <= 0 )
			{
				hm.put("PLU_CD", " ");
				hm.put("PLU_NM", " ");
				hm.put("CENTER_CD", " ");
				hm.put("CENTER_NM", " ");
				hm.put("STYLENO", " ");
				hm.put("BJSEQNO", " ");
				hm.put("SEQNO", " ");
				hm.put("JPGB", " ");
				hm.put("BJJPNO", " ");
				hm.put("INSYMD", " ");
				hm.put("PLU_CD_BOX", " ");
				hm.put("PMCODE", " ");
				hm.put("PMNM", " ");
				hm.put("DWCD", " ");
				hm.put("IPSU", " ");
				hm.put("PBGB", " ");
				hm.put("WJQTY", " ");
				hm.put("TAXGB", " ");
				hm.put("WJQTY", " ");
				hm.put("SELLDATE", " ");
				hm.put("WGDG", " ");
				hm.put("MPILJA", " ");
				hm.put("BJWGAEK", " ");
				hm.put("BJMGAEK", " ");
				hm.put("COLOR", " ");
				hm.put("SIZE", " ");
				hm.put("WJWGAEK", " ");
				hm.put("WJMGAEK", " ");
				
				ret = "09";
			}
			
			i = 0;
			sql.clearParameter();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTICS_PURCHASE_HIST_REQ));
			
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
			sql.setString(++i, pCENTER_CD.trim() );                         /* 센터코드 */  
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim()); /* 품목코드 */
			// LOGISTIC_FIRST_CODE
//			df.CommLogger("▶ SQL : " + sql.debug() );
			
			histList = executeQuery(sql);
			sql.close();
			
			if( histList.size() <= 0 )
			{
				hm.put("SELLDATE_HIST_TMLMT", " ");
				hm.put("SELLDATE_HIST_COUNT", "00");
				hm.put("SELLDATE_HIST_MPILJA0", " ");
				hm.put("SELLDATE_HIST_SELLDATE0", " ");
				hm.put("SELLDATE_HIST_SALLDATE_SEQ0", " ");
			}
			
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticPurchaseReq(hm,list,histList,df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeLogisticPurchaseReq : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 물류 매입 등록 ( 상품정보 요청 ) 응답
	 */
	private String makeLogisticPurchaseReq(HashMap hm, List list, List histList, COMMLog df) throws Exception{
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2,30,50,10,50,6,20,10,2,20,20,30,10,50,10,10,2,10,2,10,20,10,20,10,10,10,10,10,10 };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	//INQ_TYPE = 0,
                "PLU_CD",		// 상품바코드
                "PLU_NM",		// 상품명
                "CENTER_CD",   	// 물류 센터(발주처) 코드
                "CENTER_NM",   	// 물류 센터(발주처) 명
                "STYLENO",   	// 스타일코드
                "BJSEQNO",   	// 발주전표번호
                "SEQNO",   		// 순번
                "JPGB",   		// 전표구분
                "BJJPNO",   	// 발주일자
                "INSYMD",   	// 전표일자
                "PLU_CD_BOX",   // 상품바코드 BOX
                "PMCODE",   	// 분류코드
                "PMNM",   		// 분류명
                "DWCD",   		// 상품단위
                "IPSU",   		// 입수
                "PBGB",   		// 브랜드면과세구분
                "BJQTY",   		// 발주수량
                "TAXGB",   		// 과세구분
                "WJQTY",   		// 매입확정수량
                "SELLDATE",   	// 유통일자
                "WGDG",   		// 매입원가
                "MPILJA",   	// 매입확정구분
                "BJWGAEK",   	// 발주원가금액
                "BJMGAEK",   	// 발주매가금액
                "COLOR",   		// 컬러
                "SIZE",   		// 사이즈
                "WJWGAEK",   	// 확정출고금액
                "WJMGAEK"   	// 확정판매금액
		};

		int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
		int total_cnt = list.size();
		//df.CommLogger("▶ ROWS_COUNT : "+Integer.toString(total_cnt));
		// INQ_TYPE
		StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);

		try {
			if( total_cnt > 0 ) {
				map = (Map)list.get(0);
				
				for (int i = 1; i < hdr_lens.length; i++) {
//					df.CommLogger("▶ " + hdr_StrHeaders[i].toString() + " : " + (String)map.get(hdr_StrHeaders[i].toString()) );
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[i].toString()), hdr_lens[i]);
				}
			}else {
				for (int i = 1; i < hdr_lens.length; i++) {
					StringUtil.appendSpace(sb, "", hdr_lens[i]);
				}
			}
			df.CommLogger("▶ total_cnt="+Integer.toString(histList.size()));
			total_cnt = histList.size();
			if( total_cnt > 0 ) {
				hm.put("SELLDATE_HIST_COUNT", Integer.toString(total_cnt));
				for(int i = 0;i < total_cnt;i++) {
					map = (Map)histList.get(i);
					if(i == 0 ) hm.put("SELLDATE_HIST_TMLMT", (String)map.get("CIRC_TMLMT"));
					hm.put("SELLDATE_HIST_MPILJA"+Integer.toString(i), (String)map.get("MPILJA").toString());
					hm.put("SELLDATE_HIST_SELLDATE"+Integer.toString(i), (String)map.get("SELLDATE").toString());
					hm.put("SELLDATE_HIST_SALLDATE_SEQ"+Integer.toString(i), (String)map.get("SELLDATE_SEQ").toString());
				}				
			}else {
				
			}
			StringUtil.appendSpace(sb, (String)hm.get("SELLDATE_HIST_TMLMT"), 10);
			StringUtil.appendSpace(sb, (String)hm.get("SELLDATE_HIST_COUNT"), 2);
			int histCnt = Integer.parseInt((String)hm.get("SELLDATE_HIST_COUNT"));
			df.CommLogger("▶ histCnt="+Integer.toString(histCnt));
			if( histCnt > 0 ) {
				for(int i = 0;i < histCnt;i++) {
					StringUtil.appendSpace(sb, (String)hm.get("SELLDATE_HIST_MPILJA"+Integer.toString(i)), 8);
					StringUtil.appendSpace(sb, (String)hm.get("SELLDATE_HIST_SELLDATE"+Integer.toString(i)), 8);
					StringUtil.appendSpace(sb, (String)hm.get("SELLDATE_HIST_SALLDATE_SEQ"+Integer.toString(i)), 2);
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get("SELLDATE_HIST_MPILJA0"), 8);
				StringUtil.appendSpace(sb, (String)hm.get("SELLDATE_HIST_SELLDATE0"), 8);
				StringUtil.appendSpace(sb, (String)hm.get("SELLDATE_HIST_SALLDATE_SEQ0"), 2);
			}
			
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeLogisticPurchaseReq : " + e.getMessage());
			throw e;
		}
		
		
		
		return sb.toString();
	}
	
	/***************************************************************************
	 * getLogisticPurchaseReq
	 * : 물류 매입 등록 ( 상품정보 수정 요청 )
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticPurchaseUpdate(String pCOM_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int total_cnt = 0;
		connect("REDRMD");
		
		try {
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTICS_PURCHASE_UPDATE));
			sql.setString(++i, (String)hm.get("CENTER_CD").toString().trim());
			sql.setString(++i, (String)hm.get("BJJPNO").toString().trim());
			sql.setString(++i, (String)hm.get("BJSEQNO").toString().trim());
			sql.setString(++i, (String)hm.get("SEQNO").toString().trim());
			sql.setString(++i, (String)hm.get("MPILJA").toString().trim());
			//sql.setString(++i, (String)hm.get("WJQTY").toString().trim());
			sql.setInt(++i, Integer.parseInt((String)hm.get("WJQTY").toString().trim()) );
			sql.setString(++i, (String)hm.get("JPGB").toString().trim());
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			sql.setString(++i, (String)hm.get("SELLDATE").toString().trim());
//			df.CommLogger( "▶ SQL : "+ sql.debug());
			int nResult = executeUpdate(sql);
			hm.put("RESULT_CD", Integer.toString(nResult));
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getMessage());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticPurchaseUpdate(hm);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeLogisticPurchaseUpdate : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 물류 매입 등록 ( 상품정보 수정 요청 ) 응답
	 */
	private String makeLogisticPurchaseUpdate(HashMap hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 10 };
		String strHeaders[] = {
				"INQ_TYPE", 
                "RESULT_CD"
		};

		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * getLogisticSalesReq
	 * : 물류매출조회 요청
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticSalesReq(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int total_cnt = 0;
		connect("REDRMD");
		
		try {
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTICS_SALSE_REQ2));
			sql.setString(++i, pSTORE_CD);											/* 센터코드 추가 */
			sql.setString(++i, (String)hm.get("ORDER_NO").toString().trim());		/* RED화면일자랑 맞춤 */

			//sql.setString(++i, (String)hm.get("JPILJA").toString().trim());
			sql.setString(++i, (String)hm.get("CAR_NO").toString().trim());
//			sql.setString(++i, (String)hm.get("INCOM_DT").toString().trim());
//			sql.setString(++i, (String)hm.get("PLU_RANGE_DATE").toString().trim());
			sql.setString(++i, pCOM_CD);                                    		/* 회사코드 */
			
			df.CommLogger("▶ SQL  : " + sql.debug());
			
			list = executeQuery(sql);
			total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			if( list.size() <= 0 )
			{
				hm.put("ORDER_NO", " ");
				hm.put("STORE_NM", " ");
				hm.put("PLU_CD", " ");
				hm.put("PLU_NM", " ");
				hm.put("WJQTY", " ");
				
				ret = "09";
			}
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticSalesReq(hm, list, df);
			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeLogisticSalesReq : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 물류 매출조회 응답
	 */
	private String makeLogisticSalesReq(HashMap hm, List list, COMMLog df) throws Exception{
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 20, 50, 20, 50, 10 };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",
                "ORDER_NO", 
                "STORE_NM", 
                "PLU_CD", 
                "PLU_NM", 
                "WJQTY"
		};

		try
		{
			int total_cnt = list.size();
//			df.CommLogger("▶ total_cnt:"+Integer.toString(total_cnt));
			// ROWS_COUNT Length is 10.
			StringUtil.appendSpace(sb, Integer.toString(total_cnt), ROWS_COUNT_SIZE);

			if( total_cnt > 0 ) {
				for(int i = 0;i < total_cnt;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[1].toString()), hdr_lens[1]);
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[2].toString()), hdr_lens[2]);
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[3].toString()), hdr_lens[3]);
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[4].toString()), hdr_lens[4]);
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[5].toString()), hdr_lens[5]);
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				StringUtil.appendSpace(sb, "", hdr_lens[1]);
				StringUtil.appendSpace(sb, "", hdr_lens[2]);
				StringUtil.appendSpace(sb, "", hdr_lens[3]);
				StringUtil.appendSpace(sb, "", hdr_lens[4]);
				StringUtil.appendSpace(sb, "", hdr_lens[5]);
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticOutcom Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * selPluInfoForServer
	 * : 물류 상품조회
	 * @param pCOM_CD
	 * @param STORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 * 센터코드 추가
	 */
	public String selPluInfoForServer(String pCOM_CD, String STORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int total_cnt = 0;
		connect("REDRMD");
		
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_PLU_INFO2));
			//sql.setString(++i, pCOM_CD);
			
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());
			sql.setString(++i, STORE_CD);
			df.CommLogger("sql=" + sql.debug());
			list = executeQuery(sql);
			hm.put("INQ_TYPE","71");
			if(list.size()<=0)
			{
				ret = "09";
			}
		
/*
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				String PLU_CD = (String)map.get("PLU_CD");
				String PLU_NM = (String)map.get("PLU_NM");
				String GDS_CD = (String)map.get("GDS_CD");
				String ORD_ACQ_QTY = (String)map.get("ORD_ACQ_QTY");
				String CRLTMLMT_NM = (String)map.get("CRLTMLMT_NM");
				String CIRC_TMLMT = (String)map.get("CIRC_TMLMT");
				String STCK_MGR_NM = (String)map.get("STCK_MGR_NM");
				String SALE_QTY = (String)map.get("SALE_QTY");
				String ARRSTND_NM = (String)map.get("ARRSTND_NM");
				String WM_CENT_MSMT_NM = (String)map.get("WM_CENT_MSMT_NM");
				String STR_SAL_PRC = (String)map.get("STR_SAL_PRC");
				
				PLU_CD = PLU_CD.equals(null) ? " " : PLU_CD.trim(); 
				PLU_NM = PLU_NM.equals(null) ? " " : PLU_NM.trim();
				GDS_CD = GDS_CD.equals(null) ? " " : GDS_CD.trim();
				ORD_ACQ_QTY = ORD_ACQ_QTY.equals(null) ? " " : ORD_ACQ_QTY.trim();
				CRLTMLMT_NM = CRLTMLMT_NM.equals(null) ? " " : CRLTMLMT_NM.trim();
				CIRC_TMLMT = CIRC_TMLMT.equals(null) ? " " : CIRC_TMLMT.trim();
				STCK_MGR_NM = STCK_MGR_NM.equals(null) ? " " : STCK_MGR_NM.trim();
				SALE_QTY = SALE_QTY.equals(null) ? " " : SALE_QTY.trim();
				ARRSTND_NM = ARRSTND_NM.equals(null) ? " " : ARRSTND_NM.trim();
				WM_CENT_MSMT_NM = WM_CENT_MSMT_NM.equals(null) ? " " : WM_CENT_MSMT_NM.trim();
				STR_SAL_PRC = STR_SAL_PRC.equals(null) ? " " : STR_SAL_PRC.trim();
				
				hm.put("PLU_CD", PLU_CD);
				hm.put("PLU_NM", PLU_NM);
				hm.put("GDS_CD", GDS_CD);
				hm.put("ORD_ACQ_QTY", ORD_ACQ_QTY);
				hm.put("CRLTMLMT_NM", CRLTMLMT_NM);
				hm.put("CIRC_TMLMT", CIRC_TMLMT);
				hm.put("STCK_MGR_NM", STCK_MGR_NM);
				hm.put("SALE_QTY", SALE_QTY);
				hm.put("ARRSTND_NM", ARRSTND_NM);
				hm.put("WM_CENT_MSMT_NM", WM_CENT_MSMT_NM);
				hm.put("STR_SAL_PRC", STR_SAL_PRC);
			}
			else
			{
				hm.put("PLU_CD", " ");
				hm.put("PLU_NM", " ");
				hm.put("GDS_CD", " ");
				hm.put("ORD_ACQ_QTY", " ");
				hm.put("CRLTMLMT_NM", " ");
				hm.put("CIRC_TMLMT", " ");
				hm.put("STCK_MGR_NM", " ");
				hm.put("SALE_QTY", " ");
				hm.put("ARRSTND_NM", " ");
				hm.put("WM_CENT_MSMT_NM", " ");
				hm.put("STR_SAL_PRC", " ");
				ret = "09";
			}
*/
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makePluInfoForServer(hm,list,df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 *  : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 물류 센터코드 응답
	 */
	private String makeCenterCDForServer(HashMap hm, List list, COMMLog df) throws Exception{
		StringBuffer sb = new StringBuffer();
		Map<String, String> map = new HashMap<String, String>();
		int hdr_lens[] = {  2, 2, 50,10 };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	//INQ_TYPE = 0,
                "COUNT",		//리스트 건수
                "ACCTUTNM",
                "SUPPLYER"
		};
		
		int total_cnt = list.size();
				
		try {
			if( total_cnt > 0 ) {
				map = (Map<String, String>)list.get(0);
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);	// INQ_TYPE
				StringUtil.appendSpace(sb, Integer.toString(total_cnt), hdr_lens[1]);					// COUNT
				for(int i = 0;i < total_cnt;i++) {
					map = (Map<String, String>)list.get(i);
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[2]), hdr_lens[2]);		// CENTER_NM
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[3]), hdr_lens[3]);		// CENTER_CD
					
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);	// INQ_TYPE
				StringUtil.appendSpace(sb, Integer.toString(total_cnt), hdr_lens[1]);					// COUNT
				StringUtil.appendSpace(sb, " ", hdr_lens[2]);											// CENTER_NM
				StringUtil.appendSpace(sb, " ", hdr_lens[3]);
				
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeCenterCDForServer : " + e.getMessage());
			throw e;
		}
		
		return sb.toString();
	}
	/***************************************************************************
	 * makePluInfoForServer : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 물류 상품조회 응답
	 */
	private String makePluInfoForServer(HashMap hm, List list,COMMLog df) throws Exception{
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		/*int hdr_lens[] = { 
				2,
                10,
                20,
                10,
                50,
                10,
                10,
                10,
                6,
                2,
                10,
                10,
                10,
                10,
                10,
                10,
                10,
                10,
                10,
                6,
                10,
                20,
                20,
                20,
                20,
                10,
                20,
                10,
                20,
                10,
                6,
                10,
                10 };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	//INQ_TYPE = 0,
				"SAUPJANGCD",
                "DPCODE",
                "GEOGB",
                "DPNM",
                "DWCD",
                "IPSU",
                "IPSU2",
                "BARYN",
                "BJGB",
                "PMCODE",
                "WGDG",
                "LAST_SABUN",
                "WIDTH",
                "LENGTH",
                "HEIGHT",
                "DANGA1",
                "DANGA2",
                "DANGA3",
                "BANPUM_GBN",
                "HJ_MGAMT",
                "Lead_Time",
                "Standard",
                "BP_DATE_S",
                "BP_DATE_E",
                "TAX_ZERO",
                "Box_Barcode",
                "Box_Qty",
                "Box_Barcode2",
                "Box_Qty2",
                "Order_Gb",
                "Capacity",
                "Capacity_Code"
		};*/
		int hdr_lens[] = {
				2,
				30,
				50,
				10,
				10,
				50,
				2,
				30,
				10,
				30,
				10,
				10,
				10
		};
		String hdr_StrHeaders[] = {
				"INQ_TYPE", // 2
				"DPCODE",	// 30
				"DPNM",		// 50
				"LOC_NO",	// 10
				"CUST_CD",	// 10
				"COO_NM",   // 50
				"JPBJ_GB",  // 2
				"BOX_BARCODE",//30 
				"BOX_QTY",//10
				"BOX_BARCODE2",//30
				"BOX_QTY2",//10
				"DWCD",//10
				"IPSU",//10
				
		};
		StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
		if(list.size()>0)
		{
			df.CommLogger("a");
			map = (Map)list.get(0);
			for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
				df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
				StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
			}
		}
		else
		{
			for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
				StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
			}
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * selLogisticInventoryReq
	 * : 물류재고조정 조회
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selLogisticInventoryReq(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
//			int nPage = Integer.parseInt( (String)hm.get("PAGE").toString().trim() );
//			int nCount = Integer.parseInt( (String)hm.get("COUNT").toString().trim() );
//			int nToRowNo = ( nCount *  nPage ) - 1;
//			int nFromRowNo = ( nToRowNo - nCount ) + 1;
			
//			df.CommLogger("▶ nPage: " + nPage);
//			df.CommLogger("▶ nCount: " + nCount);
			//df.CommLogger("▶ nFromRowNo: " + nFromRowNo);
			//df.CommLogger("▶ nToRowNo: " + nToRowNo);
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTICS_INVENTORY));
			sql.setString(++i, (String)hm.get("PAGE").toString().trim()); /* PAGE */
			sql.setString(++i, (String)hm.get("COUNT").toString().trim()); /* COUNT */
			
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                   /* 회사코드 */
			//sql.setString(++i, LOGISTIC_FIRST_CODE + pSTORE_CD);
			sql.setString(++i, pSTORE_CD.toString().trim());				/* 센터코드 */
			
			//sql.setInt(++i, nFromRowNo);
			//sql.setInt(++i, nToRowNo);
			
			//df.CommLogger("▶ SQL: " + sql.get().toString());
//			df.CommLogger("▶ SQL DEBUG: " + sql.debug());
			
			list = executeQuery(sql);
			
			if( list.size() <= 0 ) {
				hm.put("INQ_TYPE", " ");
				hm.put("CO_CD", " ");
				hm.put("ORG_CD", " ");
				hm.put("WM_CENT_CD", " ");
				hm.put("WM_CENT_NM", " ");
				hm.put("PTN_CD", " ");
				hm.put("WM_VEN_CD", " ");
				hm.put("VEN_NM", " ");
				hm.put("ITEM_CD", " ");
				hm.put("CATE_CD", " ");
				hm.put("TAX_TP", " ");
				hm.put("PLU_CD", " ");
				hm.put("PLU_NM", " ");
				hm.put("IN_BOX_CD", " ");
				hm.put("IN_BOX_QTY", " ");
				hm.put("OUT_BOX_CD", " ");
				hm.put("OUT_BOX_QTY", " ");
				hm.put("INV_QTY", " ");
				hm.put("LEAD_QTY", " ");
				hm.put("RET_QTY", " ");
				hm.put("SELLDATE", " ");
				hm.put("ILJA", " ");

				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticInventoryReq(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeLogisticInventoryReq : 물류재고조정 조회
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeLogisticInventoryReq(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = {
				2,
                10,
                10,
                10,
                50,
                10,
                10,
                50,
                30,
                10,
                2,
                30,
                50,
                30,
                10,
                30,
                10,
                10,
                10,
                10,
                20,
                20
                         };
		
		String hdr_StrHeaders[] = {
				  "INQ_TYPE"                     ,  /*   */
	              "CO_CD"                        ,  /* [PK]회사코드  */
			      "ORG_CD"                       ,  /* [PK]조직코드  */
			      "WM_CENT_CD"                   ,  /* 물류센터코드  */
			      "WM_CENT_NM"                   ,  /* 물류센터명  */
			      "PTN_CD"                       ,  /* [PK]파트너코드  */
			      "WM_VEN_CD"                    ,  /* 물류거래처코드  */
			      "VEN_NM"                       ,  /* 거래처명  */
			      "ITEM_CD"                      ,  /* [PK]품목코드  */
			      "CATE_CD"                      , /* 카테고리 코드 */
			      "TAX_TP"                       , /* TAX 구분 */
			      "PLU_CD"                       , /* 상품 바코드*/
			      "PLU_NM"                       , /* 상품명*/
			      "IN_BOX_CD"                    , /* 상품 박스 내부 바코드 */
			      "IN_BOX_QTY"                   , /* 상품 박스 내부 수량 */
			      "OUT_BOX_CD"                   , /* 상품 박스 외부 바코드*/
			      "OUT_BOX_QTY"                  , /* 상품 박스 외부 수량*/
			      "INV_QTY"                      , /* 물류총재고 */
			      "LEAD_QTY"                     , /* 가용재고 */
			      "RET_QTY"                      , /* 반품재고 */
			      "SELLDATE"                     , /* 유통일자 */
			      "ILJA"                           /* 최신 입고일*/
		};
		
		try
		{
			// ROWS_COUNT Length is 10.
			int total_cnt = list.size();
			StringUtil.appendSpace(sb, Integer.toString(total_cnt), ROWS_COUNT_SIZE);
//			df.CommLogger("▶ total_cnt:"+Integer.toString(total_cnt));
			
			if( total_cnt > 0 ) {
				for(int i = 0;i < total_cnt;i++ ) {
					map = (Map)list.get(i);
					/* [PK]회사코드  */
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					
					String ACCTUT = (String)map.get("ACCTUT").toString().trim(); 	// 센터코드
					String DPCODE = (String)map.get("DPCODE").toString().trim();	// 상품코드
					String DPNM = (String)map.get("DPNM").toString().trim();		//상품명
					String PMCODE = (String)map.get("PMCODE").toString().trim();	// 분류상품코드
					String PMNM = (String)map.get("PMNM").toString().trim();		// 분류상품명
					String PBCODE = (String)map.get("PBCODE").toString().trim(); 	// 브랜드코드
					String IPSU = (String)map.get("IPSU2").toString().trim();		// 입수
					String ALLQTY = (String)map.get("ALLQTY").toString().trim(); 	// 총재고
					String JANG_JAGEO = (String)map.get("JANG_JAGEO").toString().trim(); // 가용재고
					String REBP = (String)map.get("REBP").toString().trim(); 		// 반품재고
					String WGDG = (String)map.get("WGDG").toString().trim(); 		// 매입원가
					String MGDG = (String)map.get("MGDG").toString().trim(); 		// 매가
					String DWCD = (String)map.get("DWCD").toString().trim(); 		// 단위
					String TAXGB = (String)map.get("PBGB").toString().trim();		//부가세 적용여부
					
					int nCol = 0;
		            //"CO_CD"                        ,  /* [PK]회사코드  */
		            StringUtil.appendSpace(sb, IPSU, hdr_lens[++nCol]);
				    //"ORG_CD"                       ,  /* [PK]조직코드  */
		            StringUtil.appendSpace(sb, ".", hdr_lens[++nCol]);
				    //"WM_CENT_CD"                   ,  /* 물류센터코드  */
		            StringUtil.appendSpace(sb, ACCTUT, hdr_lens[++nCol]);
				    //"WM_CENT_NM"                   ,  /* 물류센터명  */
		            StringUtil.appendSpace(sb, ".", hdr_lens[++nCol]);
				    //"PTN_CD"                       ,  /* [PK]파트너코드  */
		            StringUtil.appendSpace(sb, ".", hdr_lens[++nCol]);
				    //"WM_VEN_CD"                    ,  /* 물류거래처코드  */
		            StringUtil.appendSpace(sb, ".", hdr_lens[++nCol]);
				    //"VEN_NM"                       ,  /* 거래처명  */
		            StringUtil.appendSpace(sb, PMNM, hdr_lens[++nCol]);
				    //"ITEM_CD"                      ,  /* [PK]품목코드  */
		            StringUtil.appendSpace(sb, PBCODE, hdr_lens[++nCol]);
				    //"CATE_CD"                      , /* 카테고리 코드 */
		            StringUtil.appendSpace(sb, PMCODE, hdr_lens[++nCol]);
				    //"TAX_TP"                       , /* TAX 구분 */
		            StringUtil.appendSpace(sb, TAXGB, hdr_lens[++nCol]);
				    //"PLU_CD"                       , /* 상품 바코드*/
		            StringUtil.appendSpace(sb, DPCODE, hdr_lens[++nCol]);
				    //"PLU_NM"                       , /* 상품명*/
		            StringUtil.appendSpace(sb, DPNM, hdr_lens[++nCol]);
//				      "IN_BOX_CD"                    , /* 상품 박스 내부 바코드 */
		            StringUtil.appendSpace(sb, ".", hdr_lens[++nCol]);
//				      "IN_BOX_QTY"                   , /* 상품 박스 내부 수량 */
		            StringUtil.appendSpace(sb, WGDG, hdr_lens[++nCol]);
//				      "OUT_BOX_CD"                   , /* 상품 박스 외부 바코드*/
		            StringUtil.appendSpace(sb, DWCD, hdr_lens[++nCol]);
//				      "OUT_BOX_QTY"                  , /* 상품 박스 외부 수량*/
		            StringUtil.appendSpace(sb, MGDG, hdr_lens[++nCol]);
//				      "INV_QTY"                      , /* 물류총재고 */
		            StringUtil.appendSpace(sb, ALLQTY, hdr_lens[++nCol]);
//				      "LEAD_QTY"                     , /* 가용재고 */
		            StringUtil.appendSpace(sb, JANG_JAGEO, hdr_lens[++nCol]);
//				      "RET_QTY"                      , /* 반품재고 */
		            StringUtil.appendSpace(sb, REBP, hdr_lens[++nCol]);
//				      "SELLDATE"                     , /* 유통일자 */
		            StringUtil.appendSpace(sb, ".", hdr_lens[++nCol]);
//				      "ILJA"                           /* 최신 입고일*/
		            StringUtil.appendSpace(sb, ".", hdr_lens[++nCol]);
					

/*
					for(int nCol = 1; nCol<hdr_StrHeaders.length; nCol++)
					{
						if( hdr_StrHeaders[nCol].toString().equals("WM_CENT_CD") )
						{
							StringUtil.appendSpace(sb, ACCTUT, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("PLU_CD") )
						{
							StringUtil.appendSpace(sb, DPCODE, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("PLU_NM") )
						{
							StringUtil.appendSpace(sb, DPNM, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("CATE_CD") )
						{
							StringUtil.appendSpace(sb, PMCODE, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("VEN_NM") )
						{
							StringUtil.appendSpace(sb, PMNM, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("ITEM_CD") )
						{
							StringUtil.appendSpace(sb, PBCODE, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("INV_QTY") )
						{
							StringUtil.appendSpace(sb, ALLQTY, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("LEAD_QTY") )
						{
							StringUtil.appendSpace(sb, JANG_JAGEO, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("RET_QTY") )
						{
							StringUtil.appendSpace(sb, REBP, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("TAX_TP") )
						{
							StringUtil.appendSpace(sb, IPSU, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("IN_BOX_QTY") )
						{
							StringUtil.appendSpace(sb, WGDG, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("OUT_BOX_QTY") )
						{
							StringUtil.appendSpace(sb, MGDG, hdr_lens[nCol]);
						}
						else if( hdr_StrHeaders[nCol].toString().equals("OUT_BOX_CD") )
						{
							StringUtil.appendSpace(sb, DWCD, hdr_lens[nCol]);
						}
						else
						{
							StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
						}
					}
*/
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1; nCol<hdr_StrHeaders.length; nCol++)
				{
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticInventoryReq Error : " + e);
			throw e;
		}
		
		return sb.toString();
	}
	
	/***************************************************************************
	 * selLogisticInventoryReq
	 * : 물류재고조정 조회 수정
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setLogisticInventoryUpdateReq(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception 
	{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
			int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			df.CommLogger((String)hm.get("INPUT_DT0").toString().trim());
//			df.CommLogger("▶ START : setLogisticInventoryUpdateReq COUNT["+Integer.toString(total_cnt)+"]");
			
			// 발주번호 구해오기
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.GET_LOGISTICS_INVENTORY_SEQ2));
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			sql.setString(++i, (String)hm.get("CENTER_CD"+ Integer.toString(0)).toString().trim());
			
			df.CommLogger((String)hm.get("CENTER_CD"+Integer.toString(0).toString().trim()));
			list = executeQuery(sql);
			sql.close();
			
			map = (Map)list.get(0);
			String strSEQ = (String)map.get("BJSEQ").toString().trim();
			df.CommLogger(strSEQ);
			//일련번호 에러 수정 dek
			
			int parsevalue =0;
			boolean charchk = java.util.regex.Pattern.matches("^[A-Z]", strSEQ.substring(0, 1));
			if(charchk == true){

				parsevalue = Integer.parseInt(strSEQ.substring(1,5));
				strSEQ = strSEQ.substring(0, 1);
				strSEQ = "0" + String.valueOf(parsevalue+1);
				
			}
			else{
				parsevalue = Integer.parseInt(strSEQ);
				strSEQ = String.valueOf(parsevalue+1);
				
			}
			
			switch(strSEQ.length()){
			case 1:
				strSEQ="0000" + strSEQ;
				break;
			case 2:
				strSEQ="000" + strSEQ;
				break;
			case 3:
				strSEQ="00" + strSEQ;
				break;
			case 4:
				strSEQ="0" + strSEQ;
				break;
			default:
				break;
			}
			
			//
			df.CommLogger("▶ SEQ  1: " + strSEQ);
			
			
			// 발주 처리
			//
			for(int idx = 0;idx < total_cnt;idx++ ) {
				i=0;
				String QTY = (String)hm.get("QTY" + Integer.toString(idx)).toString().trim();
				String WGDG = (String)hm.get("WGDG" + Integer.toString(idx)).toString().trim();
				String MGDG = (String)hm.get("MGDG" + Integer.toString(idx)).toString().trim();
				String IPSU = (String)hm.get("IPSU" + Integer.toString(idx)).toString().trim();
				/* PDA 재고조정 수정 시작(20140530/조충연) */
				list = null;
				/* PDA 재고조정 수정 끝(20140530/조충연) */
				if(QTY.length()<=0) QTY = "0";
				if(WGDG.length()<=0) WGDG = "0";
				if(MGDG.length()<=0) MGDG = "0";
				if(IPSU.length()<=0) IPSU = "0";
//				df.CommLogger("▶ STEP  : 0");
//				df.CommLogger("▶ QTY  : "+QTY);
//				df.CommLogger("▶ WGDG  : "+WGDG);
//				df.CommLogger("▶ MGDG  : "+MGDG);
//				df.CommLogger("▶ IPSU  : "+IPSU);
				
				int nQTY = Integer.parseInt(QTY);
				int nWGDG = Integer.parseInt(WGDG);
				int nSum = nQTY*nWGDG;
				int nMGDG = Integer.parseInt(MGDG);
				int nPRICE = nMGDG * nQTY;
				int nVAT = nSum / 10;
				int nIPSU = Integer.parseInt(IPSU);
				
				/* PDA 재고조정 수정 시작(20140530/조충연) */
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_LOGISTICS_INVENTORY_NOW));
				sql.setString(++i, (String)hm.get("CENTER_CD" + Integer.toString(idx)).toString().trim());						/* 센터코드 */
				sql.setString(++i, (String)hm.get("PLU_CD" + Integer.toString(idx)).toString().trim());							/* 상품코드 */
				sql.setString(++i, ((String)hm.get("INPUT_DT" + Integer.toString(idx)).toString().trim()).substring(0, 6));		/* 입력월 */
				sql.setString(++i, pCOM_CD);
//				sql.setString(++i, "100002");	/* 사업장코드 */
				
				df.CommLogger("▶ SQL2 : " + sql.debug());
				
				list = executeQuery(sql);
				sql.close();
				i = 0;
				
				map = (Map)list.get(0);
				String STCK_NOW = (String)map.get("STCK_NOW").toString().trim();
//				df.CommLogger("▶ STCK_NOW  : " + STCK_NOW);
				
				if(STCK_NOW.length() <= 0) STCK_NOW = "0";
				int nSTCKNOW = Integer.parseInt(STCK_NOW);
				
				int nINFQTY = nQTY - nSTCKNOW;
//				df.CommLogger("▶ nINFQTY  : " + Integer.toString(Math.abs(nINFQTY)));
				
				String GBN = nINFQTY > 0 ? "12" : "11"; 
				/* PDA 재고조정 수정 끝(20140530/조충연) */
				
//				df.CommLogger("▶ STEP  : 1");
				// Detail Update
				//
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.PR_LOGISTICS_INVENTORY_DTL));
				
				// @V_Acctut=?,
				// @V_Brand=?,
				// @V_Dte=?,
				// @V_DpCode=?,
				// @seq=?
				// @V_DwCd=?,
				// @V_Ipsu=?,
				// @amt2=?,
				// @amt3=?,
				// @amt4=?,
				// @amt5=?,
				// @cnt=?,
				// @V_MGDG=?,
				// @V_VAT=?,
				// @SAUPJANGCD=?
				// @XITEM=?
//				df.CommLogger("▶ STEP  : 2-0 CENTER_CD = "+(String)hm.get("CENTER_CD"+ Integer.toString(idx)).toString().trim());
//				df.CommLogger("▶ STEP  : 2-1 BRAND_CD = "+(String)hm.get("BRAND_CD"+ Integer.toString(idx)).toString().trim());
//				df.CommLogger("▶ STEP  : 2-2 INPUT_DT = "+(String)hm.get("INPUT_DT"+ Integer.toString(idx)).toString().trim());
//				df.CommLogger("▶ STEP  : 2-3 PLU_CD = "+(String)hm.get("PLU_CD"+ Integer.toString(idx)).toString().trim());
//				df.CommLogger("▶ STEP  : 2-4 UNIT = "+(String)hm.get("UNIT"+ Integer.toString(idx)).toString().trim());

				sql.setString(++i, (String)hm.get("CENTER_CD"+ Integer.toString(idx)).toString().trim());
				/* PDA 재고조정 수정 시작(20140530/조충연) */
				sql.setString(++i, GBN);
				/* PDA 재고조정 수정 끝(20140530/조충연) */
				sql.setString(++i, (String)hm.get("BRAND_CD"+ Integer.toString(idx)).toString().trim());
				sql.setString(++i, (String)hm.get("INPUT_DT"+ Integer.toString(idx)).toString().trim());
				sql.setString(++i, strSEQ);
				sql.setString(++i, (String)hm.get("PLU_CD"+ Integer.toString(idx)).toString().trim());
				sql.setString(++i, (String)hm.get("UNIT"+ Integer.toString(idx)).toString().trim());
				sql.setInt(++i, nIPSU);
				/* PDA 재고조정 수정 시작(20140530/조충연) */
				//sql.setInt(++i, nQTY);
				sql.setInt(++i, Math.abs(nINFQTY));
				/* PDA 재고조정 수정 끝(20140530/조충연) */
				sql.setInt(++i, nWGDG);
				sql.setInt(++i, nSum);
				sql.setInt(++i, nPRICE);
				sql.setInt(++i, idx+1);
				sql.setInt(++i, nMGDG);
				sql.setInt(++i, nVAT);
				sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//				sql.setString(++i, "100002");                                    /* 회사코드 */
				sql.setString(++i, (String)hm.get("PLU_CD"+ Integer.toString(idx)).toString().trim());
				
//				df.CommLogger("▶ STEP  : 3");
				
				df.CommLogger("▶ SQL3 : " + sql.debug());
				
				int rows = executeUpdate(sql);
//				df.CommLogger("▶ rows : " + Integer.toString(rows));
				sql.close();
			}
			// Header Update
			//
			i=0;
			String IPSU = (String)hm.get("IPSU" + Integer.toString(0)).toString().trim();
			if(IPSU.length()<=0) IPSU = "0";
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.PR_LOGISTICS_INVENTORY_HD));
			sql.setString(++i, (String)hm.get("CENTER_CD"+ Integer.toString(0)).toString().trim());
			sql.setString(++i, (String)hm.get("BRAND_CD"+ Integer.toString(0)).toString().trim());
			sql.setString(++i, (String)hm.get("INPUT_DT"+ Integer.toString(0)).toString().trim());
			sql.setString(++i, strSEQ);
			sql.setString(++i, (String)hm.get("PLU_CD"+ Integer.toString(0)).toString().trim());
			sql.setString(++i, IPSU);
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			sql.setString(++i, (String)hm.get("PLU_CD"+ Integer.toString(0)).toString().trim());
			
			df.CommLogger("▶ SQL4 : " + sql.debug());
			
			int rows2 = executeUpdate(sql);
//			df.CommLogger("▶ rows2 : " + Integer.toString(rows2));
			sql.close();
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback Code=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Rollback Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			hm.put("RESULT_CD", ret);
			dataMsg = ret + makeLogisticInventoryUpdateReq(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeLogisticInventoryUpdateReq
	 * : 물류재고조정 조회 수정
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String makeLogisticInventoryUpdateReq(HashMap hm, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "22": 
				"RESULT_CD" 		    // 결과 코드
		};
		
		try
		{
//			df.CommLogger("▶ START : makeLogisticInventoryUpdateReq" );
//			df.CommLogger("▶ INQ_TYPE : " + (String)hm.get(hdr_StrHeaders[0].toString()+"0"));
//			df.CommLogger("▶ RESULT_CD : " + (String)hm.get(hdr_StrHeaders[1].toString()));
			
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()+"0"), hdr_lens[0]);
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[1].toString()), hdr_lens[1]);
			df.CommLogger(sb.toString());
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticInventoryUpdateReq Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	/***************************************************************************
	 * getAppVersion
	 * : 버전 정보 요청
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getAppVersion(String pCOM_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
//			df.CommLogger("▶ PDA Version :"+(String)hm.get("VER").toString().trim());

			ret = "00";
			
//		}catch(SQLException e) {
//			rollback();
//			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
//			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
//			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeAppVersion(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeAppVersion : 버전 정보 요청 응답
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeAppVersion(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "22": 
				"RESULT_CD" 		    // 진열대 코드
		};
		
		try
		{
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
			StringUtil.appendSpace(sb, "1.0.0.1", hdr_lens[1]);
		}catch(Exception e) {
			df.CommLogger("▶ makeAppVersion Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	/***************************************************************************
	 * getLogisticOrderTimeCheckReq
	 * : 물류(매입 ) 마감 시간 확인
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticOrderTimeCheckReq(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		//ProcedureWrapper proc = new ProcedureWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.PR_ORDERTIME_CHECK));
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			
			list = executeQuery(sql);
			if( list.size() <= 0 ) {
				hm.put("TIME_STD", " ");
				hm.put("TIME_ORDER", " ");
				hm.put("RESULT", " ");
				hm.put("TIME_ORDER2", " ");
				hm.put("TIME_STD2", " ");
				
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticOrderTimeCheckReq(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeLogisticOrderTimeCheckReq : 물류(매입 ) 마감 시간 확인  응답
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeLogisticOrderTimeCheckReq(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
//		int hdr_lens[] = { 2, 5, 5, 6, 6 };
		int hdr_lens[] = { 2, 6, 6, 1, 6, 6 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "22": 
				"TIME_STD", 		    // 코드
				"TIME_ORDER", 		    // 코드
				"RESULT",   		    // 코드
				"TIME_ORDER2", 		    // 코드
				"TIME_STD2" 		    // 코드
		};

		try
		{
			int total_cnt = list.size();
//			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));

			if( total_cnt > 0 ) {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				map = (Map)list.get(0);
				for(int i = 1;i < hdr_StrHeaders.length;i++ ) {
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[i].toString()), hdr_lens[i]);
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int i = 1;i < hdr_StrHeaders.length;i++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[i]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticOrderTimeCheckReq Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	/***************************************************************************
	 * getLogisticStoreListReq
	 * : 물류 점포 리스트 요청 : IQ_LOGISTICS_STORE_LIST_REQ
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticStoreListReq(String pCOM_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.GET_LOGISTICS_STORE_LIST));
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			
			list = executeQuery(sql);
			
			if( list.size() <= 0 ) {
				hm.put("CODE", " ");
				hm.put("NAME", " ");
				
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticStoreListReq(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeLogisticStoreListReq 
	 * 물류 점포 리스트 요청 : IQ_LOGISTICS_STORE_LIST_REQ
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeLogisticStoreListReq(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10, 50 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	    // "90": 
				"CODE", 		    // 코드
				"NAME"
		};

		try
		{
			int total_cnt = list.size();
//			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			StringUtil.appendSpace(sb, Integer.toString(total_cnt), ROWS_COUNT_SIZE);

			if( total_cnt > 0 ) {
				for(int iRow = 0;iRow < total_cnt;iRow++ ) {
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					map = (Map)list.get(iRow);
					// CODE
//					df.CommLogger(hdr_StrHeaders[1].toString()+" : "+(String)map.get(hdr_StrHeaders[1].toString()));
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[1].toString()), hdr_lens[1]);
					// NAME
//					df.CommLogger(hdr_StrHeaders[2].toString()+" : "+(String)map.get(hdr_StrHeaders[2].toString()));
					StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[2].toString()), hdr_lens[2]);
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				StringUtil.appendSpace(sb, "", hdr_lens[1]);
				StringUtil.appendSpace(sb, "", hdr_lens[2]);
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticStoreListReq Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * getLogisticInReturnListReq_OLD
	 * : 물류 점포 반품 헤더  : IQ_LOGISTICS_RETURN_IN_REQ
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticInReturnListReq_OLD(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
			String CMD_TYPE = (String)hm.get("CMD_TYPE").toString().trim();
//			df.CommLogger("▶pCOM_CD : "+pCOM_CD.toString().trim());
//			df.CommLogger("▶pSTORE_CD : "+pSTORE_CD.toString().trim());
//			df.CommLogger("▶STORE_CD : "+(String)hm.get("STORE_CD").toString().trim());
//			df.CommLogger("▶CMD_TYPE : "+CMD_TYPE);
//			df.CommLogger("▶SLIP_NO : "+(String)hm.get("SLIP_NO").toString().trim());
//			df.CommLogger("▶JPILJA : "+(String)hm.get("JPILJA").toString().trim());
			
			if(CMD_TYPE.equals("H")) // Header
			{
//				df.CommLogger("▶Header : ");
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.GET_LOGISTICS_IN_RETURN_HD));
				sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//				sql.setString(++i, "100002");                                    /* 회사코드 */
				//sql.setString(++i, LOGISTIC_FIRST_CODE + pSTORE_CD);
				sql.setString(++i, pSTORE_CD.toString().trim()); // 센터코드
				sql.setString(++i, (String)hm.get("STORE_CD").toString().trim()); // 점포코드
				sql.setString(++i, (String)hm.get("JPILJA").toString().trim()); // 전표일자
			}
			else if(CMD_TYPE.equals("D")) // Detail
			{
//				df.CommLogger("▶Detail : ");
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.GET_LOGISTICS_IN_RETURN_DTL));
				sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//				sql.setString(++i, "100002");                                    /* 회사코드 */
				//sql.setString(++i, LOGISTIC_FIRST_CODE + pSTORE_CD);
				sql.setString(++i, pSTORE_CD.toString().trim());// 센터코드
				sql.setString(++i, (String)hm.get("SLIP_NO").toString().trim());// 전표번호
			}
			
//			df.CommLogger("▶SQL : "+sql.debug());
					
			list = executeQuery(sql);
			
			if( list.size() <= 0 ) {
				
				if(CMD_TYPE.equals("H")) // Header
				{
					hm.put("SLIP_NO", " ");
					hm.put("STORE_NM", " ");
					hm.put("STORE_CD", " ");
					hm.put("JPILJA", " ");
					hm.put("CENTER_CD", " ");
				} else if(CMD_TYPE.equals("D")) // Detail
				{
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("QTY", " ");
				}
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticInReturnListReq_OLD(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeLogisticStoreListReq 
	 * 물류 점포 리스트 요청 : IQ_LOGISTICS_RETURN_IN_REQ
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeLogisticInReturnListReq_OLD(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 20, 50, 10, 20, 10 };
		/*
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	    // "63": 
				"SLIP_NO", 		    // 전표번호
				"STORE_NM",			// 점포명
				"STORE_CD",			// 점포코드
				"JPILJA",			// 전표일자
				"CENTER_CD"			// 센터코드
		};
		*/

		try
		{
			int total_cnt = list.size();
//			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			StringUtil.appendSpace(sb, Integer.toString(total_cnt), ROWS_COUNT_SIZE);
			String CMD_TYPE = (String)hm.get("CMD_TYPE").toString().trim();
//			df.CommLogger("▶CMD_TYPE : "+CMD_TYPE);
			
			if( total_cnt > 0 ) {
				for(int iRow = 0;iRow < total_cnt;iRow++ ) {
					int i=0;
					StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
					map = (Map)list.get(iRow);
					
					if(CMD_TYPE.equals("H")) // Header
					{
						String JPNO = (String)map.get("JPNO").toString().trim();
						String ACCTUTNM = (String)map.get("ACCTUTNM").toString().trim();
						String ACCTUT = (String)map.get("ACCTUT").toString().trim();
						String JPILJA = (String)map.get("JPILJA").toString().trim();
						String WH_ACCTUT = (String)map.get("WH_ACCTUT").toString().trim();
						
						// SLIP_NO
						StringUtil.appendSpace(sb, JPNO, hdr_lens[++i]);
						// STORE_NM
						StringUtil.appendSpace(sb, ACCTUTNM, hdr_lens[++i]);
						// STORE_CD
						StringUtil.appendSpace(sb, ACCTUT, hdr_lens[++i]);
						// JPILJA
						StringUtil.appendSpace(sb, JPILJA, hdr_lens[++i]);
						// CENTER_CD
						StringUtil.appendSpace(sb, WH_ACCTUT, hdr_lens[++i]);
					} else if(CMD_TYPE.equals("D")) // Detail
					{
						String PLU_CD = (String)map.get("DPCODE").toString().trim();
						String PLU_NM = (String)map.get("DPNM").toString().trim();
						String QTY = (String)map.get("WJQTY").toString().trim();

						// SLIP_NO
						StringUtil.appendSpace(sb, PLU_CD, hdr_lens[++i]);
						// STORE_NM
						StringUtil.appendSpace(sb, PLU_NM, hdr_lens[++i]);
						// QTY
						StringUtil.appendSpace(sb, QTY, hdr_lens[++i]);
					}
				}
			}else {
				int i=0;
				StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
				if(CMD_TYPE.equals("H")) // Header
				{
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
				} else if(CMD_TYPE.equals("D")) // Detail
				{
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticInReturnListReq Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	// ==> On Line ==> Off Line 으로 처리하시겠습니다. !!! 해서 다음 함수로 변경 합니다.
	// getLogisticInReturnListReq_OLD ==> getLogisticInReturnListReq
	// 2014.03.20
	/***************************************************************************
	 * getLogisticInReturnListReq
	 * : 물류 점포 리스트 요청 : IQ_LOGISTICS_RETURN_IN_REQ
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticInReturnListReq(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
//			df.CommLogger("▶pCOM_CD : "+pCOM_CD.toString().trim());
//			df.CommLogger("▶pSTORE_CD : "+pSTORE_CD.toString().trim());
//			df.CommLogger("▶JPILJA : "+(String)hm.get("JPILJA").toString().trim());
//			df.CommLogger("▶PAGE : "+(String)hm.get("PAGE").toString().trim());
//			df.CommLogger("▶COUNT : "+(String)hm.get("COUNT").toString().trim());
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.GET_LOGISTICS_IN_RETURN));
			sql.setString(++i, (String)hm.get("PAGE").toString().trim());  // 페이지
			sql.setString(++i, (String)hm.get("COUNT").toString().trim()); // 요청건수
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			//sql.setString(++i, LOGISTIC_FIRST_CODE + pSTORE_CD);
			sql.setString(++i, pSTORE_CD.toString().trim()); // 센터코드
			sql.setString(++i, (String)hm.get("JPILJA").toString().trim()); // 전표일자
			
//			df.CommLogger("▶SQL : "+sql.debug());
					
			list = executeQuery(sql);
			
			if( list.size() <= 0 ) {
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback getErrorCode=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Rollback getMessage=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticInReturnListReq(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeLogisticStoreListReq 
	 * 물류 점포 리스트 요청 : IQ_LOGISTICS_RETURN_IN_REQ
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeLogisticInReturnListReq(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = {  2, 30, 10, 50, 20
						 , 50, 10, 20, 10, 50
						 , 10, 10, 10, 10, 10
						 , 20, 10, 10, 10, 10
						 , 10, 10, 6 };

		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	    // "63": 
				"JPNO", 		    // 전표번호
				"ACCTUT",			// 점코드
				"ACCTUTNM",			// 점포명
				"DPCODE",			// 상품코드
				
				"DPNM",				// 상품명
				"JPILJA",			// 전표일자
				"JPSEQ",			// 전표순번
				"PMCODE",			// 상품그룹코드
				"PMNM",				// 상품그룹명
				
				"WJQTY",			// 확정수량
				"MGDANGA",			// 
				"BJMGAEK",			// 
				"WGDANGA",			// 
				"BJWGAEK",			//
				
				"SEQNO",			// 전표순번
				"DWCD",				// 단위
				"IPSU",				// 입수
				"ALLQTY",			// 총재고량
				"JQTY",				// 가용재고
				
				"REBP",				// 반품재고
				"MPWJGB",			// 
				"JPGB"				// 전표구분
		};


		try
		{
			int total_cnt = list.size();
//			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			StringUtil.appendSpace(sb, Integer.toString(total_cnt), ROWS_COUNT_SIZE);

			if( total_cnt > 0 ) {
				for(int iRow = 0;iRow < total_cnt;iRow++ ) {
					StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
					map = (Map)list.get(iRow);
					for (int i = 1; i < hdr_lens.length; i++) {
//						df.CommLogger("▶ " + hdr_StrHeaders[i].toString() + " : " + (String)map.get(hdr_StrHeaders[i].toString()) );
						StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[i].toString()), hdr_lens[i]);
					}
				}
			} else 
			{
				StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
				for (int i = 1; i < hdr_lens.length; i++) {
					StringUtil.appendSpace(sb, "", hdr_lens[i]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticInReturnListReq Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	/***************************************************************************
	 * setLogisticInReturnUpdateReq
	 * : 물류반품-입고 수정==>점포반품 : IQ_LOGISTICS_RETURN_IN_UPDATE_REQ
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setLogisticInReturnUpdateReq(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
			int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			
//			df.CommLogger("▶total_cnt DTL : "+total_cnt);
//			df.CommLogger("▶pCOM_CD : "+pCOM_CD.toString().trim());
//			df.CommLogger("▶STORE_CD : "+pSTORE_CD.toString().trim());
			
			String ACCTUT_ADD = "";
			String JPILJA_ADD = "";
			String JPNO_ADD = "";
			String MPILJA_ADD = "";
			String JPNO_OLD = "";

			//
			// 물류 반품[점포]  수량 수정 저장
			//
			for(int idx = 0;idx < total_cnt;idx++ ) {
//				df.CommLogger("▶idx : "+idx);
//				df.CommLogger("▶ ");
				String ACCTUT = (String)hm.get("ACCTUT"+ Integer.toString(idx)).toString().trim();
				String JPILJA = (String)hm.get("JPILJA"+ Integer.toString(idx)).toString().trim();
				String JPNO = (String)hm.get("JPNO"+ Integer.toString(idx)).toString().trim();
				String SEQNO = (String)hm.get("SEQNO"+ Integer.toString(idx)).toString().trim();
				String MPILJA = (String)hm.get("MPILJA"+ Integer.toString(idx)).toString().trim();
				String QTY = (String)hm.get("QTY"+ Integer.toString(idx)).toString().trim();
				
				df.CommLogger("▶ACCTUT : "+ACCTUT);
				df.CommLogger("▶JPILJA : "+JPILJA);
				df.CommLogger("▶JPNO : "+JPNO);
				df.CommLogger("▶SEQNO : "+SEQNO);
				df.CommLogger("▶MPILJA : "+MPILJA);
				df.CommLogger("▶QTY : "+QTY);
				
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.UPDATE_LOGISTICS_IN_RETURN_DTL));
				i=0;
				sql.setString(++i, ACCTUT); // 점포코드
				sql.setString(++i, JPILJA); // 전표일자
				sql.setString(++i, JPNO.substring(8,JPNO.length())); 	// 전표번호
				sql.setString(++i, SEQNO); 	// 
				sql.setString(++i, MPILJA); // 확정일자
				sql.setString(++i, QTY); 	// 수량
				sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//				sql.setString(++i, "100002");                                    /* 회사코드 */
				
				df.CommLogger("▶SQL : "+sql.debug());
				
				int rows = executeUpdate(sql);
				//df.CommLogger("▶ rows : " + Integer.toString(rows));
				sql.close();
				
				// 확정을 위한 작업
				if(JPNO_OLD.equals(JPNO)==false)
				{
					JPNO_OLD = JPNO;
					
					if(ACCTUT_ADD.length()==0)
					{
						ACCTUT_ADD 	= ACCTUT;
						JPILJA_ADD 	= JPILJA;
						JPNO_ADD 	= JPNO.substring(8,JPNO.length()); 	// 전표번호
						MPILJA_ADD 	= MPILJA;
					}
					else
					{
						ACCTUT_ADD 	+= "|" + ACCTUT;
						JPILJA_ADD 	+= "|" + JPILJA;
						JPNO_ADD 	+= "|" + JPNO.substring(8,JPNO.length()); 	// 전표번호
						MPILJA_ADD 	+= "|" + MPILJA;
					}
					
					df.CommLogger("▶JPNO_OLD : "+JPNO_OLD);
					df.CommLogger("▶ACCTUT_ADD : "+ACCTUT_ADD);
				}
			}
			
			//
			// 물류 반품[점포]  확정
			//
			String[] ACCTUT_LIST = ACCTUT_ADD.split("\\|");
			String[] JPILJA_LIST = JPILJA_ADD.split("\\|");
			String[] JPNO_LIST   = JPNO_ADD.split("\\|");
			String[] MPILJA_LIST = MPILJA_ADD.split("\\|");
			
			total_cnt = JPNO_LIST.length;
			df.CommLogger("▶total_cnt HD : "+total_cnt);
			df.CommLogger("▶ACCTUT_ADD : '"+ACCTUT_ADD+"'");
			df.CommLogger("▶JPILJA_ADD : '"+JPILJA_ADD+"'");
			df.CommLogger("▶JPNO_ADD : '"+JPNO_ADD+"'");
			df.CommLogger("▶MPILJA_ADD : '"+MPILJA_ADD+"'");
			for(int idx = 0;idx < total_cnt;idx++ ) {
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.UPDATE_LOGISTICS_IN_RETURN_HD));
				//SET @V_JPILJA 	= ? -- '20140319'
				//SET @V_ACCTUT	= ? -- 'W001'
				//SET @V_JPNO 	= ? -- '20140319B0001'
				//SET @SAUPJANGCD = ? -- '100002'
				//SET @V_MPILJA 	= ? -- '20140320'
				df.CommLogger("▶JPILJA : "+JPILJA_LIST[idx]);
				df.CommLogger("▶ACCTUT : "+ACCTUT_LIST[idx]);
				df.CommLogger("▶JPNO : "+JPNO_LIST[idx]);
				df.CommLogger("▶MPILJA : "+MPILJA_LIST[idx]);
				i=0;
				sql.setString(++i, JPILJA_LIST[idx]); 	// 전표일자
				sql.setString(++i, ACCTUT_LIST[idx]); 	// 점포코드
				sql.setString(++i, JPNO_LIST[idx]); 	// 전표번호
				sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//				sql.setString(++i, "100002");                                    /* 회사코드 */
				sql.setString(++i, MPILJA_LIST[idx]); // 확정일자
				
				df.CommLogger("▶SQL : "+sql.debug());
				
				int rows = executeUpdate(sql);
//				df.CommLogger("▶ rows : " + Integer.toString(rows));
				sql.close();
			}
			
			hm.put("RESULT_CD", "00");
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticInReturnUpdateReq(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeLogisticInReturnUpdateReq
	 * : 물류반품-출고==>거래처반품 수정: IQ_LOGISTICS_RETURN_OUT_UPDATE_REQ 
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String makeLogisticInReturnUpdateReq(HashMap hm, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "22": 
				"RESULT_CD" 		    // 결과 코드
		};
		
		try
		{
//			df.CommLogger("▶ START : makeLogisticInReturnUpdateReq" );
//			df.CommLogger("▶ INQ_TYPE : " + (String)hm.get(hdr_StrHeaders[0].toString()+"0"));
//			df.CommLogger("▶ RESULT_CD : " + (String)hm.get(hdr_StrHeaders[1].toString()));
			
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()+"0"), hdr_lens[0]);
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[1].toString()), hdr_lens[1]);
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticInReturnUpdateReq Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	/***************************************************************************
	 * makeLogisticInReturnUpdateReq 
	 * 물류반품-입고 수정==>점포반품 : IQ_LOGISTICS_RETURN_IN_UPDATE_REQ
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeLogisticInReturnUpdateReq_OLD(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 20, 50, 10, 20, 10 };
		/*
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	    // "63": 
				"SLIP_NO", 		    // 전표번호
				"STORE_NM",			// 점포명
				"STORE_CD",			// 점포코드
				"JPILJA",			// 전표일자
				"CENTER_CD"			// 센터코드
		};
		*/

		try
		{
			int total_cnt = list.size();
//			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			StringUtil.appendSpace(sb, Integer.toString(total_cnt), ROWS_COUNT_SIZE);
			String CMD_TYPE = (String)hm.get("CMD_TYPE").toString().trim();
//			df.CommLogger("▶CMD_TYPE : "+CMD_TYPE);
			
			if( total_cnt > 0 ) {
				for(int iRow = 0;iRow < total_cnt;iRow++ ) {
					int i=0;
					StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
					map = (Map)list.get(iRow);
					
					if(CMD_TYPE.equals("H")) // Header
					{
						String JPNO = (String)map.get("JPNO").toString().trim();
						String ACCTUTNM = (String)map.get("ACCTUTNM").toString().trim();
						String ACCTUT = (String)map.get("ACCTUT").toString().trim();
						String JPILJA = (String)map.get("JPILJA").toString().trim();
						String WH_ACCTUT = (String)map.get("WH_ACCTUT").toString().trim();
						
						// SLIP_NO
						StringUtil.appendSpace(sb, JPNO, hdr_lens[++i]);
						// STORE_NM
						StringUtil.appendSpace(sb, ACCTUTNM, hdr_lens[++i]);
						// STORE_CD
						StringUtil.appendSpace(sb, ACCTUT, hdr_lens[++i]);
						// JPILJA
						StringUtil.appendSpace(sb, JPILJA, hdr_lens[++i]);
						// CENTER_CD
						StringUtil.appendSpace(sb, WH_ACCTUT, hdr_lens[++i]);
					} else if(CMD_TYPE.equals("D")) // Detail
					{
						String PLU_CD = (String)map.get("DPCODE").toString().trim();
						String PLU_NM = (String)map.get("DPNM").toString().trim();
						String QTY = (String)map.get("WJQTY").toString().trim();

						// SLIP_NO
						StringUtil.appendSpace(sb, PLU_CD, hdr_lens[++i]);
						// STORE_NM
						StringUtil.appendSpace(sb, PLU_NM, hdr_lens[++i]);
						// QTY
						StringUtil.appendSpace(sb, QTY, hdr_lens[++i]);
					}
				}
			}else {
				int i=0;
				StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
				if(CMD_TYPE.equals("H")) // Header
				{
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
				} else if(CMD_TYPE.equals("D")) // Detail
				{
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
					StringUtil.appendSpace(sb, "", hdr_lens[++i]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticInReturnListReq Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	/***************************************************************************
	 * getLogisticInReturnOutReq
	 * : 물류반품-출고==>거래처반품 : IQ_LOGISTICS_RETURN_OUT_REQ
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticOutReturnReq(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
//			df.CommLogger("▶pCOM_CD : "+pCOM_CD.toString().trim());
//			df.CommLogger("▶pSTORE_CD : "+pSTORE_CD.toString().trim());
//			df.CommLogger("▶JMDATE : "+(String)hm.get("JMDATE").toString().trim());
//			df.CommLogger("▶PAGE : "+(String)hm.get("PAGE").toString().trim());
//			df.CommLogger("▶COUNT : "+(String)hm.get("COUNT").toString().trim());
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_LOGISTICS_OUT_RETURN));
			sql.setString(++i, (String)hm.get("PAGE").toString().trim());  // 페이지
			sql.setString(++i, (String)hm.get("COUNT").toString().trim()); // 요청건수
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			//sql.setString(++i, LOGISTIC_FIRST_CODE + pSTORE_CD);
			sql.setString(++i, pSTORE_CD.toString().trim()); // 센터코드
			sql.setString(++i, (String)hm.get("JMDATE").toString().trim()); // 전표일자
			
//			df.CommLogger("▶SQL : "+sql.debug());
					
			list = executeQuery(sql);
			
			if( list.size() <= 0 ) {
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback getErrorCode=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Rollback getMessage=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticInReturnOutReq(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeLogisticInReturnOutReq 
	 * 물류반품-출고==>거래처반품 : IQ_LOGISTICS_RETURN_OUT_REQ
	 * @param hm
	 * @param list
	 * @param df
	 * @return 전송메세지
	 */
	private String makeLogisticInReturnOutReq(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10, 50, 10, 20, 50, 10, 50, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 50 };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	    // "65": 
				"CUSTCD", 		    // 거래처코드
				"CUSTNM", 		    // 거래처명
				"ACCTUT",			// 센터코드
				"DPCODE", 		    // 상품코드
				"DPNM",				// 상품명
				"PMCODE",			// 그룹코드
				"PMNM",				// 그룹명
				"DWCD",				// 단위
				"IPSU",				// 입수
				"ALLQTY",			// 총재고
				"JQTY",				// 가용재고
				"REBP",				// 반품재고
				"LEAD_TIME",		// 리드타임
				"JMQTY",			// 주문수량
				"JUQTY",			// ?수량
				"JMAMT",			// 주문금액
				"MULQTY",			// ?수량
				"CHULQTY",			// ?수량
				"CHLGO_DANGA",		// 매입원가?
				"ACCTUT_QTY",		// ?수량
				"TDGBN",			// ?
				"JPCHK",			// ?
				"CATE_NM"
		};
		
		try
		{
			int total_cnt = list.size();
//			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			StringUtil.appendSpace(sb, Integer.toString(total_cnt), ROWS_COUNT_SIZE);
			
			if( total_cnt > 0 ) {
				for(int iRow = 0;iRow < total_cnt;iRow++ ) {
					StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
					map = (Map)list.get(iRow);
					for (int i = 1; i < hdr_lens.length; i++) {
//						df.CommLogger("▶ " + hdr_StrHeaders[i].toString() + " : " + (String)map.get(hdr_StrHeaders[i].toString()) );
						StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[i].toString()), hdr_lens[i]);
					}
				}
			} else 
			{
				StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
				for (int i = 1; i < hdr_lens.length; i++) {
					StringUtil.appendSpace(sb, "", hdr_lens[i]);
				}
			}
		}
		catch(Exception e) {
			df.CommLogger("▶ makeLogisticInReturnListReq Error : " + e);
			throw e;
		}
		return sb.toString();
	}
	/***************************************************************************
	 * getLogisticInReturnOutTimeReq
	 * : 물류==>거래처반품 가능시간 : IQ_LOGISTICS_OUT_RETURN_TIME_REQ
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticInReturnOutTimeReq(String pCOM_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
//			df.CommLogger("▶pCOM_CD : "+pCOM_CD.toString().trim());
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_LOGISTICS_OUT_RETURN_TIME));
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			
//			df.CommLogger("▶SQL : "+sql.debug());
					
			list = executeQuery(sql);
			
			if( list.size() <= 0 ) {
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback getErrorCode=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Rollback getMessage=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticInReturnOutTimeReq(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeLogisticInReturnOutTimeReq 
	 * 물류==>거래처반품 가능시간
	 * @param hm
	 * @param list
	 * @param df
	 * @return 전송메세지
	 */
	private String makeLogisticInReturnOutTimeReq(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10, 10, 10, 10, 10 };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	    // "": 
				"TIME_STD", 		    // ?
				"TIME_ORDER", 		    // ?
				"RESILT", 		    // ?
				"TIME_STD2", 		    // ?
				"TIME_ORDER2", 		    // /
		};
		
		try
		{
			int total_cnt = list.size();
//			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			StringUtil.appendSpace(sb, Integer.toString(total_cnt), ROWS_COUNT_SIZE);
			
			if( total_cnt > 0 ) {
				for(int iRow = 0;iRow < total_cnt;iRow++ ) {
					StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
					map = (Map)list.get(iRow);
					for (int i = 1; i < hdr_lens.length; i++) {
//						df.CommLogger("▶ " + hdr_StrHeaders[i].toString() + " : " + (String)map.get(hdr_StrHeaders[i].toString()) );
						StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[i].toString()), hdr_lens[i]);
					}
				}
			} else 
			{
				StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
				for (int i = 1; i < hdr_lens.length; i++) {
					StringUtil.appendSpace(sb, "", hdr_lens[i]);
				}
			}
		}
		catch(Exception e) {
			df.CommLogger("▶ makeLogisticInReturnListReq Error : " + e);
			throw e;
		}
		return sb.toString();
	}

	/***************************************************************************
	 * getLogisticInDropReq
	 * : 물류폐기  입고==>점포폐기 [센터파손폐기] : IQ_LOGISTICS_DROP_IN_REQ
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getLogisticInDropReq(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
//			df.CommLogger("▶pCOM_CD : "+pCOM_CD.toString().trim());
//			df.CommLogger("▶pSTORE_CD : "+pSTORE_CD.toString().trim());
//			df.CommLogger("▶PAGE : "+(String)hm.get("PAGE").toString().trim());
//			df.CommLogger("▶COUNT : "+(String)hm.get("COUNT").toString().trim());
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.GET_LOGISTICS_IN_DROP));
			sql.setString(++i, (String)hm.get("PAGE").toString().trim());  // 페이지
			sql.setString(++i, (String)hm.get("COUNT").toString().trim()); // 요청건수
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			//sql.setString(++i, LOGISTIC_FIRST_CODE + pSTORE_CD);
			sql.setString(++i, pSTORE_CD.toString().trim()); // 센터코드
			
//			df.CommLogger("▶SQL : "+sql.debug());
					
			list = executeQuery(sql);
			
			if( list.size() <= 0 ) {
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback getErrorCode=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Rollback getMessage=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLogisticInDropReq(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeLogisticInDropReq 
	 * 물류폐기  입고==>점포폐기 [센터파손폐기] : IQ_LOGISTICS_DROP_IN_REQ
	 * @param hm
	 * @param list
	 * @param df
	 * @return 전송메세지
	 */
	private String makeLogisticInDropReq(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10, 50, 10, 20, 50, 10, 50, 10, 10, 10, 10, 10, 10, 10 };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	    // "67": 
				"CUSTCD", 		    // 거래처코드
				"CUSTNM", 		    // 거래처명
				"ACCTUT",			// 센터코드
				"DPCODE", 		    // 상품코드
				"DPNAME",			// 상품명
				"PMCODE",			// 그룹코드
				"PMNM",				// 그룹명
				"QTY",				// 폐기수량
				"ALLQTY",			// 총재고
				"JANG_JAEGO",		// 가용재고
				"REBP",				// 반품재고
				"PBGB",				// 
				"NRML_UNTPRC",		// 
				"NRML_CST_UNTPRC"   // 매입원가
		};
		
		try
		{
			int total_cnt = list.size();
//			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			StringUtil.appendSpace(sb, Integer.toString(total_cnt), ROWS_COUNT_SIZE);
			
			if( total_cnt > 0 ) {
				for(int iRow = 0;iRow < total_cnt;iRow++ ) {
					StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
					map = (Map)list.get(iRow);
					for (int i = 1; i < hdr_lens.length; i++) {
//						df.CommLogger("▶ " + hdr_StrHeaders[i].toString() + " : " + (String)map.get(hdr_StrHeaders[i].toString()) );
						StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[i].toString()), hdr_lens[i]);
					}
				}
			} else 
			{
				StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE").toString().trim(), hdr_lens[0]);
				for (int i = 1; i < hdr_lens.length; i++) {
					StringUtil.appendSpace(sb, "", hdr_lens[i]);
				}
			}
		}
		catch(Exception e) {
			df.CommLogger("▶ makeLogisticInReturnListReq Error : " + e);
			throw e;
		}
		return sb.toString();
	}
	
	/***************************************************************************
	 * setLogisticOutReturnUpdateReq
	 * : 물류반품-출고 수정==>거래처반품 수정
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setLogisticOutReturnUpdateReq(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception 
	{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
			int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			
//			df.CommLogger("▶ START : setLogisticOutReturnUpdateReq COUNT["+Integer.toString(total_cnt)+"]");
	
			// 발주 처리
			//
			for(int idx = 0;idx < total_cnt;idx++ ) {
				i=0;
				String ACCTUT   = (String)hm.get("ACCTUT" + Integer.toString(idx)).toString().trim();		// 센터코드
				String PMCODE   = (String)hm.get("PMCODE" + Integer.toString(idx)).toString().trim();		// 분류상품코드
				String DPCODE   = (String)hm.get("DPCODE" + Integer.toString(idx)).toString().trim();		// 상품코드
				String QTY 	    = (String)hm.get("QTY" + Integer.toString(idx)).toString().trim();		    // 수량
				String JMQTY    = (String)hm.get("JMQTY" + Integer.toString(idx)).toString().trim();		// 수량
				String LEADTIME = (String)hm.get("LEADTIME" + Integer.toString(idx)).toString().trim();	    // 
				String CUSTCD   = (String)hm.get("CUSTCD" + Integer.toString(idx)).toString().trim();		// 거래처코드
//				df.CommLogger("▶ STEP  : 0");
//				df.CommLogger("▶ ACCTUT  : "+ACCTUT);
//				df.CommLogger("▶ PMCODE  : "+PMCODE);
//				df.CommLogger("▶ DPCODE  : "+DPCODE);
//				df.CommLogger("▶ QTY  : "+QTY);
//				df.CommLogger("▶ JMQTY  : "+JMQTY);
//				df.CommLogger("▶ LEADTIME  : "+LEADTIME);
//				df.CommLogger("▶ CUSTCD  : "+CUSTCD);
				
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.PR_LOGISTICS_OUT_RETURN));
				
//				df.CommLogger("▶ STEP  : 1");
				// Params
				//
//				SET @V_ACCTUT=?--'W001'
//				SET @V_PMCODE=?--'055101'
//				SET @V_DPCODE=?--'8801008017326'
//				SET @V_QTY=?--5
//				SET @V_JMQTY=?--5
//				SET @V_WHOUSE=?--'900001'
//				SET @SAUPJANGCD=?--'100002'
//				SET @V_LEADTIME=?--'1'
//				SET @V_CUSTCD=?--'100270'
				sql.setString(++i, ACCTUT);
				sql.setString(++i, PMCODE);
				sql.setString(++i, DPCODE);
				sql.setString(++i, QTY);
				sql.setString(++i, JMQTY);
				sql.setString(++i, pSTORE_CD.toString().trim());
				sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//				sql.setString(++i, "100002");                                    /* 회사코드 */
				sql.setString(++i, LEADTIME);
				sql.setString(++i, CUSTCD);
				
//				df.CommLogger("▶ STEP  : 2");
				
//				df.CommLogger("▶ SQL1 : " + sql.debug());
				
				int rows = executeUpdate(sql);
//				df.CommLogger("▶ rows : " + Integer.toString(rows));
				sql.close();
				
				hm.put("RESULT_CD", "00");
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback Code=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Rollback Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			hm.put("RESULT_CD", ret);
			dataMsg = ret + makeLogisticOutReturnUpdateReq(hm, df);// LogisticInventoryUpdateReq
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeLogisticOutReturnUpdateReq
	 * : 물류반품-출고==>거래처반품 수정: IQ_LOGISTICS_RETURN_OUT_UPDATE_REQ 
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String makeLogisticOutReturnUpdateReq(HashMap hm, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "22": 
				"RESULT_CD" 		    // 결과 코드
		};
		
		try
		{
//			df.CommLogger("▶ START : makeLogisticOutReturnUpdateReq" );
//			df.CommLogger("▶ INQ_TYPE : " + (String)hm.get(hdr_StrHeaders[0].toString()+"0"));
//			df.CommLogger("▶ RESULT_CD : " + (String)hm.get(hdr_StrHeaders[1].toString()));
			
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()+"0"), hdr_lens[0]);
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[1].toString()), hdr_lens[1]);
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticOutReturnUpdateReq Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * setLogisticInDropUpdateReq
	 * : 물류폐기  입고==>점포폐기 [센터파손폐기] 수정 : IQ_LOGISTICS_DROP_IN_UPDATE_REQ
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setLogisticInDropUpdateReq(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception 
	{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("REDRMD");
		try { 
			begin();
			
			int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			
//			df.CommLogger("▶ START : setLogisticOutReturnUpdateReq COUNT["+Integer.toString(total_cnt)+"]");
	
			int OrderNo = 1;
			int SeqNo = 0;
			// 발주 처리
			//
			for(int idx = 0;idx < total_cnt;idx++ ) {
				i=0;
				
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.PR_LOGISTICS_IN_DROP));
				// Params
				//
//				Storeno=?--'W001' --센터코드
//				OrderNo=?--'1' 주문번호 생성
//				SeqNo=?--'1' 순번 생성
//				Srcmkcd=?--* '5410126132038' -- Dpcode
//				Dpcode=?--* '5410126132038'--바코드
//				Qty=?--* 30.000 -- 폐기수량
//				Nrml_Untprc=?--* 1200--NRML_UNTPRC
//				Nrml_Cst_Untprc=?--* 709--NRML_CST_UNTPRC 매입원가
//				PBGB=?--* '0'
//				SAUPJANGCD=?--'100002'
				//df.CommLogger("▶ STEP  : 0");
//				df.CommLogger("▶ Storeno  : "+(String)hm.get("ACCTUT" + Integer.toString(idx)).toString().trim());
//				df.CommLogger("▶ OrderNo  : "+OrderNo);
//				df.CommLogger("▶ SeqNo  : "+SeqNo);
//				df.CommLogger("▶ Srcmkcd  : "+(String)hm.get("DPCODE" + Integer.toString(idx)).toString().trim());
//				df.CommLogger("▶ Dpcode  : "+(String)hm.get("DPCODE" + Integer.toString(idx)).toString().trim());
//				df.CommLogger("▶ QTY  : "+(String)hm.get("QTY" + Integer.toString(idx)).toString().trim());
//				df.CommLogger("▶ NRML_UNTPRC  : "+(String)hm.get("NRML_UNTPRC" + Integer.toString(idx)).toString().trim());
//				df.CommLogger("▶ NRML_CST_UNTPRC  : "+(String)hm.get("NRML_CST_UNTPRC" + Integer.toString(idx)).toString().trim());
//				df.CommLogger("▶ PBGB  : "+(String)hm.get("PBGB" + Integer.toString(idx)).toString().trim());
//				df.CommLogger("▶ pCOM_CD  : "+pCOM_CD);

				sql.setString(++i, (String)hm.get("ACCTUT"+ Integer.toString(idx)).toString().trim());
				sql.setInt(++i, OrderNo);
				sql.setInt(++i, SeqNo);
				sql.setString(++i, (String)hm.get("DPCODE"+ Integer.toString(idx)).toString().trim());
				sql.setString(++i, (String)hm.get("DPCODE"+ Integer.toString(idx)).toString().trim());
				sql.setString(++i, (String)hm.get("QTY"+ Integer.toString(idx)).toString().trim());
				sql.setString(++i, (String)hm.get("NRML_UNTPRC"+ Integer.toString(idx)).toString().trim());
				sql.setString(++i, (String)hm.get("NRML_CST_UNTPRC"+ Integer.toString(idx)).toString().trim());
				sql.setString(++i, (String)hm.get("PBGB"+ Integer.toString(idx)).toString().trim());
				sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//				sql.setString(++i, "100002");                                    /* 회사코드 */
				
//				df.CommLogger("▶ SQL : " + sql.debug());
				
				int rows = executeUpdate(sql);
//				df.CommLogger("▶ rows : " + Integer.toString(rows));
				sql.close();
				
				SeqNo++;
			}
			
			i = 0;
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.PR_LOGISTICS_IN_DROP_PASS));
			// Params
			// SET @V_Storeno = ?;
			// SET @V_OrderNo = ?;
			// SET @V_SAUPJANGCD = ?;
//			df.CommLogger("▶ Storeno  : " + (String)hm.get("ACCTUT" + Integer.toString(0)).toString().trim());
//			df.CommLogger("▶ OrderNo  : " + OrderNo);
//			df.CommLogger("▶ pCOM_CD  : " + pCOM_CD);
			
//			df.CommLogger("▶ SQL : " + sql.debug());
			
			sql.setString(++i, (String)hm.get("ACCTUT"+ Integer.toString(0)).toString().trim());
			sql.setInt(++i, OrderNo);
			sql.setString(++i, pCOM_CD);                                    /* 회사코드 */
//			sql.setString(++i, "100002");                                    /* 회사코드 */
			
//			df.CommLogger("▶ SQL : " + sql.debug());
			
			int rows = executeUpdate(sql);
			sql.close();
			
			hm.put("RESULT_CD", "00");
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback Code=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Rollback Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			hm.put("RESULT_CD", ret);
			dataMsg = ret + makeLogisticOutReturnUpdateReq(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeLogisticInDropUpdateReq
	 * : 물류폐기  입고==>점포폐기 [센터파손폐기] 수정 : IQ_LOGISTICS_DROP_IN_UPDATE_REQ
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String makeLogisticInDropUpdateReq(HashMap hm, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "22": 
				"RESULT_CD" 		    // 결과 코드
		};
		
		try
		{
//			df.CommLogger("▶ START : makeLogisticInDropUpdateReq" );
//			df.CommLogger("▶ INQ_TYPE : " + (String)hm.get(hdr_StrHeaders[0].toString()+"0"));
//			df.CommLogger("▶ RESULT_CD : " + (String)hm.get(hdr_StrHeaders[1].toString()));
			
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()+"0"), hdr_lens[0]);
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[1].toString()), hdr_lens[1]);
		}catch(Exception e) {
			df.CommLogger("▶ makeLogisticInDropUpdateReq Error : " + e);
			throw e;
		}

		return sb.toString();
	}
}
