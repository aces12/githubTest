package biz.cms_PDACommIf3;

import java.util.HashMap;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import org.apache.log4j.Logger;
import biz.comm.COMMBiz_PDA;
import biz.comm.COMMLog;

/** 
 * PDACommIFAction
 * 
 * blah..blah..A Class that has inherited ServerAction(ServerAction을 상속받은 클래스)
 * blah..blah..A class to receive and process Tran data through 9002 port(트란데이타를 9002포트로 수신 받아 처리하는 클래스) 
 * @created  on 1.0,  13/01/10
 * @created  by topco(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */ 
public class PDACommIFAction3 extends ServerAction {

	private static Logger logger = Logger.getLogger(PDACommIFAction3.class);

	/**
	 * Receive data from SC through 9001 PORT(SC로부터 데이타를 9001 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	@Override
	public void execute(ActionSocket actionSocket) throws Exception {
		// TODO Auto-generated method stub

		int 	ret = 0;
		int		inq_type = 0;
		String  sendMsg = "";
		String  dataMsg = "";
		String	rcvBuf = "";
		String 	rcvDataBuf = "";
		String  retValue = "OK!";
		HashMap hmCommon = new HashMap();
		HashMap hmData = new HashMap();
		PDACommIFDAO3 dao = new PDACommIFDAO3();
		PDACommIFProtocol3 protocol = new PDACommIFProtocol3();
		COMMLog df = new COMMLog();

		try {
			// Data received from SC(SC로부터 받은 Data)
			rcvBuf = (String)actionSocket.receive();

			// Server TEST Packet
			if(rcvBuf.toString().length()<54)
				return;
			
			// set work start time(업무시작시간  설정)
			df.setStartTime();
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),
								 String.valueOf(actionSocket.getSocket().getPort()),
								 logger,
								 "PDACommIF3");
			
			df.CommLogger("▶ 0: Receive Data : " + rcvBuf);
			
			hmCommon = COMMBiz_PDA.getData(rcvBuf, COMMBiz_PDA.CM_HEADER_PDA);
			// Compare to see if MsgType message type value is PDA(전문구분값이 PDA인지
			// 비교한다).
			if( !COMMBiz_PDA.getCommMsgType(hmCommon, COMMBiz_PDA.PDA) ) // COMMBiz_PDA.PDA
				return;
			// Get Tran Date(트란 일자를 가져온다.)
			String tranYmd = COMMBiz_PDA.getCommTranYMD(hmCommon);
		
			rcvDataBuf = rcvBuf.substring(COMMBiz_PDA.CM_LENS_PDA);
//			df.CommLogger("▶ 1: Receive INQ Data: " + rcvDataBuf);
			
			inq_type = protocol.getRcvPDAInqType(rcvDataBuf);
			
			switch( inq_type ) {
			// 12: Inquire User(물류 사용자 조회) :
			case 12: 
				df.execute("USER LOGISTIC LOGIN");
				hmData = protocol.getParseInqUser(rcvDataBuf); 
				dataMsg = dao.selUserInfoLogistic2(
						(String)hmData.get("USER_ID"),
						hmData, df);
				//df.CommLogger((String)hmData.get("USER_ID") + "1111");
				dataMsg = dao.selUserInfoLogistic3((String)hmData.get("USER_ID"), (String)hmData.get("USER_PWD"), hmData, df);
				dataMsg = dao.selUserInfoLogistic4((String)hmData.get("USER_ID"), hmData, df);
				df.CommLogger(dataMsg);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				
				dataMsg = dataMsg.substring(2);
				break;
			case 13:
				//신물류 로그인
				df.execute("USER LOGISTIC LOGIN");
				hmData = protocol.getParseInqUser(rcvDataBuf); 
				dataMsg = dao.selUserInfo_WMS((String)hmData.get("USER_ID"), (String)hmData.get("USER_PWD"), hmData, df);
				dataMsg = dao.selUserInfo_WMS2((String)hmData.get("USER_ID"),hmData,df);
				df.CommLogger(dataMsg);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				
				dataMsg = dataMsg.substring(2);
				break;
			case 22: // 버전 정보 요청 
				df.execute("IQ_MASTER_VER_REQ");
				hmData = protocol.getAppVersion(rcvDataBuf); 
				dataMsg = dao.getAppVersion((String)hmCommon.get("COM_CD"), hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;

			///
			/// 물류
			///	
			case 40: // 물류 재고 조사 요청
				df.execute("IQ_LOGISTICS_INV2_REQ");
				hmData = protocol.getLogisticInventory2Req(rcvDataBuf);
				dataMsg = dao.getLogisticInventory2Req(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 41: //물류 센터코드 조회
				df.execute("IQ_LOGISTICS_CENTER_REQ");
				hmData = protocol.getCenterCode(rcvDataBuf);
				dataMsg = dao.selCenterInfos(hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0,2),99);
				dataMsg = dataMsg.substring(2);
				break;
			case 60: // 물류 매입 등록 ( 상품정보 요청 )
				df.execute("IQ_LOGISTICS_PURCHASE_REQ");
				hmData = protocol.getLogisticPurchaseReq(rcvDataBuf);
				dataMsg = dao.getLogisticPurchaseReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 61: // 물류 매입 등록 ( 상품정보 수정 요청 )
				df.execute("IQ_LOGISTICS_PURCHASE_UPDATE_REQ");
				hmData = protocol.getLogisticPurchaseUpdate(rcvDataBuf);
				dataMsg = dao.getLogisticPurchaseUpdate(
						(String)hmCommon.get("COM_CD"),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 62: // 물류매출조회
				df.execute("IQ_LOGISTICS_SALES_REQ");
				hmData = protocol.getLogisticSalesReq(rcvDataBuf);
				dataMsg = dao.getLogisticSalesReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 63: // 물류==>점포반품
				df.execute("IQ_LOGISTICS_RETURN_IN_REQ");
				hmData = protocol.getLogisticInReturnListReq(rcvDataBuf);
				dataMsg = dao.getLogisticInReturnListReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 64: // 물류반품-입고 수정==>점포반품 수정
				df.execute("IQ_LOGISTICS_RETURN_IN_UPDATE_REQ");
				hmData = protocol.getLogisticInReturnUpdateReq(rcvDataBuf,df);
				dataMsg = dao.setLogisticInReturnUpdateReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 65: // 물류반품-출고==>거래처반품
				df.execute("IQ_LOGISTICS_RETURN_OUT_REQ");
				hmData = protocol.getLogisticOutReturnReq(rcvDataBuf);
				dataMsg = dao.getLogisticOutReturnReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 66: // 물류반품-출고 수정==>거래처반품 수정
				df.execute("IQ_LOGISTICS_RETURN_OUT_UPDATE_REQ");
				hmData = protocol.getLogisticOutReturnUpdateReq(rcvDataBuf,df);
				dataMsg = dao.setLogisticOutReturnUpdateReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 67: // 물류폐기  입고==>점포폐기 [센터파손폐기]
				df.execute("IQ_LOGISTICS_DROP_IN_REQ");
				hmData = protocol.getLogisticInDropReq(rcvDataBuf);
				dataMsg = dao.getLogisticInDropReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 68: // 물류폐기  입고==>점포폐기 [센터파손폐기] 수정
				df.execute("IQ_LOGISTICS_DROP_IN_UPDATE_REQ");
				hmData = protocol.getLogisticInDropUpdateReq(rcvDataBuf,df);
				dataMsg = dao.setLogisticInDropUpdateReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
				
//			case 69: // 물류패기-출고
//				df.execute("IQ_LOGISTICS_DROP_OUT_REQ");
//				// TODO :
//				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
//				dataMsg = dataMsg.substring(2);
//				break;
//			case 70: // 물류패기-출고 수정
//				df.execute("IQ_LOGISTICS_DROP_OUT_UPDATE_REQ");
//				// TODO : 
//				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
//				dataMsg = dataMsg.substring(2);
//				break;
				
			case 71: // 물류 상품조회
				df.execute("IQ_LOGISTICS_PLU_REQ");
				hmData = protocol.getPluInfoForServer(rcvDataBuf);
				dataMsg = dao.selPluInfoForServer(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df); 
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 72: // 물류재고조정 조회
				df.execute("IQ_LOGISTICS_INV_REQ");
				hmData = protocol.getLogisticInventoryReq(rcvDataBuf);
				dataMsg = dao.selLogisticInventoryReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 73: //물류재고조정 수정
				df.execute("IQ_LOGISTICS_INV_UPDATE_REQ");
				hmData = protocol.getLogisticInventoryUpdateReq(rcvDataBuf,df);
				dataMsg = dao.setLogisticInventoryUpdateReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 74: //입고 매입 요청(NEW)
				df.execute("IQ_LOGISTICS_PUR_REQ");
				df.CommLogger(rcvDataBuf);
				hmData = protocol.getLogisticPurReq(rcvDataBuf);
				dataMsg = dao.getLogisticPurReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				
				break;
			case 75: //입고 유통기한  이력 요청(NEW)
				df.execute("IQ_LOGISTICS_SALEDATE_HIST_REQ");
				hmData = protocol.getLogisticSellDateHistReq(rcvDataBuf);
				dataMsg = dao.getLogisticSellDateHistReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 76: //점포PDA버전체크
				df.execute("IQ_PDAVERSION");
				hmData = protocol.getPDAVersion(rcvDataBuf);
				dataMsg = dao.insPDAVersion(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 80: //물류(매입 ) 마감 시간 확인
				df.execute("IQ_LOGISTICS_ORDERTIME_CHECK_REQ");
				hmData = protocol.getLogisticOrderTimeCheckReq(rcvDataBuf);
				dataMsg = dao.getLogisticOrderTimeCheckReq(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(1),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			//
			// 81 ~ 89 : 점포에서 사용
			//
				
			// 90 부터 물류변경으로 추가된 항목 입니다.
			// ORACLE==>SQL
			//
			case 90: //물류 점포 리스트 요청
				df.execute("IQ_LOGISTICS_STORE_LIST_REQ");
				hmData = protocol.getLogisticStoreListReq(rcvDataBuf);
				dataMsg = dao.getLogisticStoreListReq(
						(String)hmCommon.get("COM_CD"),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 91: //물류==>거래처반품[반품출고] 가능시간 : 
				df.execute("IQ_LOGISTICS_OUT_RETURN_TIME_REQ");
				hmData = protocol.getLogisticInReturnOutTimeReq(rcvDataBuf);
				dataMsg = dao.getLogisticInReturnOutTimeReq(
						(String)hmCommon.get("COM_CD"),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			}
			
		} catch(Exception e) {
			ret = 20;
			retValue = "[ERROR]1:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}
		
		try {
			df.CommLogger("--- makeSendData_PDA:(" + dataMsg.getBytes().length + ")" + dataMsg);
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz_PDA.makeSendData_PDA(hmCommon, dataMsg.getBytes().length, ret);
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(sendMsg + dataMsg)) {
				df.CommLogger("▶ 2: SEND MSG: " + sendMsg + "/"
						+ sendMsg.getBytes().length);
				df.CommLogger("▶ 3: DATA MSG: " + dataMsg + "/"
						+ dataMsg.getBytes().length);	
			} else {
				df.CommLogger("▶ [ERROR]3: " + sendMsg + " ==>LEN: "
						+ sendMsg.getBytes().length);
			}
		} catch (Exception e) {
			retValue = "[ERROR]2" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		} finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("SYSINQ", retValue);
		}
	}
}
