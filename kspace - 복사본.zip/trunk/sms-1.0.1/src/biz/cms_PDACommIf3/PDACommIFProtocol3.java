package biz.cms_PDACommIf3;

import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz_PDA;
import biz.comm.COMMLog;

public class PDACommIFProtocol3 {
 
	private static Logger logger = Logger.getLogger(PDACommIFAction3.class);
	
	/***
	 * getRcvPDAInqData
	 * @param rcvBuf Receive MSG
	 * @return INQ_TYPE
	 */
	public int getRcvPDAInqType(String rcvBuf)
	{
		int ret = 0;
		
		HashMap hm = new HashMap();
		
		hm.put("INQ_TYPE", rcvBuf.substring(0, 2));
		
		if( Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE")) )
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		
		return ret;
	}
	
	/***
	 * getParseInqUser
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseInqUser(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 13, 60}; 
		
		String strHeaders[] = {
				"INQ_TYPE",
				"USER_ID",
				"USER_PWD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);

		return hm;
	}
    /***
	 * GetTotalSize
	 * : 프로토콜 전체 길이 구하기.
	 * @param nLens 프로토콜 길이
	 * @return int : 전체 길이
	 */
	private int GetTotalSize(int[] nLens)
	{
		int nResult = 0;
		try
		{
			for(int n=0; n<nLens.length; n++)
			{
				nResult += nLens[n];
			}
		}catch(Exception ex)
		{
			ex.toString();
		}
		
		return nResult;
	}
	/***
	 * getCenterCode
	 * : 물류 센터코드 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getCenterCode(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2};
		
		String strHeaders[] = {
				"INQ_TYPE"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * getLogisticInventory2Req
	 * : 물류 재고 조사 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getLogisticInventory2Req(String rcvBuf) throws Exception
	{
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 10, 20, 30, 10, 10};
		
		String strHeaders[] = {
			"INQ_TYPE",
			"CENTER_CD",
			"SILSA_DT",
			"PLU_CD",
			"SILSA_QTY",
			"BRAND_CD"
		};
		
		try 
		{
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
			int nPos = 0;
			hm.put("ROWS_COUNT", Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos += nlens[nCol];
					logger.info("["+strHeaders[nCol]+ Integer.toString(n)+"] = '" + rcvBuf.substring(nPos-nlens[nCol],nPos) + "'" );
					hm.put(strHeaders[nCol] + Integer.toString(n), rcvBuf.substring(nPos - nlens[nCol], nPos));
				}
			}
		}catch(Exception e) {
			throw e;
		}
		
		return hm;
	}
	/***
	 * getLogisticPurchaseReq
	 * : 물류 매입 등록 ( 상품정보 요청 )
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticPurchaseReq(String rcvBuf)
	{
		HashMap hm = new HashMap();
		int nlens[] = {2, 30, 20};

		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD",
				"BJJPNO"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * getLogisticPurchaseUpdate
	 * : 물류 매입 등록 ( 상품정보 수정 요청 )
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticPurchaseUpdate(String rcvBuf)
	{
		HashMap hm = new HashMap();
		int nlens[] = {2, 10, 20, 10, 10, 10, 10, 10, 10};

		String strHeaders[] = {
				"INQ_TYPE",
                "BJJPNO",
                "BJSEQNO",
                "SEQNO",
                "MPILJA",
                "CENTER_CD",
                "WJQTY",
                "JPGB",
                "SELLDATE"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLogisticSalesReq
	 * : 물류매출조회 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticSalesReq(String rcvBuf)
	{
		HashMap hm = new HashMap();
		int nlens[] = {2, 20, 10, 20};

		String strHeaders[] = {
				"INQ_TYPE",
				"ORDER_NO",
				"CAR_NO",
				"JPILJA"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLogisticInventoryReq
	 * : 물류재고조정 조회
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticInventoryReq(String rcvBuf)
	{
		HashMap hm = new HashMap();
		int nlens[] = {2, 30, 10, 10};

		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD",
				"PAGE",
				"COUNT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLogisticInventoryReq
	 * : 물류재고조정 조회 수정
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticInventoryUpdateReq(String rcvBuf, COMMLog df) throws Exception{
		HashMap hm = new HashMap();
		int nlens[] = {2, 10, 30, 10, 10, 10, 10, 10, 20, 10, 10};

		String strHeaders[] = {
				"INQ_TYPE",		
				"CENTER_CD",	// 센터코드
				"PLU_CD",		// 상품코드
				"QTY",			// 수량
				"CATEGORY_CD",	// 분류상품코드
				"BRAND_CD",		// 브랜드코드
				"IPSU",			// 입수
				"WGDG",			// 매입원가
				"INPUT_DT",		// 입력일자
				"UNIT",			// 단위
				"MGDG"			// 매가
		};
		
		try 
		{
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
			int nPos = 0;
			hm.put("ROWS_COUNT",Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos+=nlens[nCol];
					//df.CommLogger("["+strHeaders[nCol]+ Integer.toString(n)+"] = '" + rcvBuf.substring(nPos-nlens[nCol],nPos) + "'" );
					hm.put(strHeaders[nCol]+ Integer.toString(n), rcvBuf.substring(nPos-nlens[nCol],nPos) );
				}
			}
		}catch(Exception e) {
			throw e;
		}
		
		return hm;
	}
	
	/***
	 * getLogisticPurHistReq
	 * : 물류 매입 입고 내역 요청(NEW)
	 * @param rcvBuf : Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getLogisticPurHistReq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 30};
		
		String strHeaders[] = {
			"INQ_TYPE",
			"PLU_CD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLogisticPurReq
	 * : 물류 매입 입고 요청(NEW)
	 * @param rcvBuf : Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getLogisticPurReq2(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 10, 10, 30};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"CENTER_CD",
				"NPYJIL",
				"PLU_CD"
		};
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	public HashMap<String, String> getLogisticPurReq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 10, 10, 30};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"STORE_CD",
				"NPYJIL",
				"PLU_CD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getPDAVersion
	 * : 점포-PDA버전관리
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getPDAVersion(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 8, 8, 16, 12};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"STORE_CD",
				"PDA_NO",
				"IP_ADDR",
				"VERSION"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	/***
	 * getLogisticSaleDateHistReq
	 * : 매입 유통기한 이력 요청(NEW)
	 * @param rcvBuf : Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getLogisticSellDateHistReq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 30};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getPluInfoForServer
	 * : 물류 상품조회
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getPluInfoForServer(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 30};

		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * getAppVersion
	 * : 버전 정보 요청  : IQ_MASTER_VER_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getAppVersion(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"VER"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getCloseOrderTime
	 * : 발주가능 시간, 금액 조회
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getCloseOrderTime(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2};
		
		String strHeaders[] = {
				"INQ_TYPE"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLogisticOrderTimeCheckReq
	  * : 물류(매입 ) 마감 시간 확인
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticOrderTimeCheckReq(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2};
		
		String strHeaders[] = {
				"INQ_TYPE"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLogisticStoreListReq
	  * : 물류 점포 리스트 요청 : IQ_LOGISTICS_STORE_LIST_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticStoreListReq(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2,10,10,10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"COMMAND",
				"PAGE",
				"ROWS"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLogisticInReturnListReq
	  * : 물류반품-입고==>점포반품 : IQ_LOGISTICS_RETURN_IN_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticInReturnListReq_OLD(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2,2,30,10,20};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"CMD_TYPE",
				"SLIP_NO",
				"STORE_CD",
				"JPILJA"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	// ==> On Line ==> Off Line 으로 처리하시겠습니다. !!! 해서 다음 함수로 변경 합니다.
	// getLogisticInReturnListReq_OLD ==> getLogisticInReturnListReq
	// 2014.03.20
	/***
	 * getLogisticInReturnListReq
	  * : 물류반품-입고==>점포반품 : IQ_LOGISTICS_RETURN_IN_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticInReturnListReq(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2,10,10,10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"JPILJA",
				"PAGE",
				"COUNT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLogisticInReturnOutReq
	  * : 물류반품-출고==>거래처반품 : IQ_LOGISTICS_RETURN_OUT_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticOutReturnReq(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2,10,10,10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"JMDATE",		// 주문일자
				"PAGE",
				"COUNT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLogisticInReturnOutTimeReq
	  * : //물류==>거래처반품 가능시간 : IQ_LOGISTICS_OUT_RETURN_TIME_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticInReturnOutTimeReq(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2};
		
		String strHeaders[] = {
				"INQ_TYPE"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLogisticInDropReq
	  * : 물류폐기  입고==>점포폐기 [센터파손폐기] 수정 : IQ_LOGISTICS_DROP_IN_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticInDropReq(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2,10,10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PAGE",
				"COUNT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLogisticInReturnUpdateReq
	  * : 물류반품-입고 수정==>점포반품 : IQ_LOGISTICS_RETURN_IN_UPDATE_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticInReturnUpdateReq(String rcvBuf, COMMLog df) throws Exception{
		HashMap hm = new HashMap();
		int nlens[] = { 2, 6, 10, 20, 20, 10, 10 };
		String strHeaders[] = {
			"INQ_TYPE",
		    "ACCTUT",
			"JPILJA",
			"JPNO",
			"SEQNO",
			"MPILJA",
			"QTY"
		};
		
		try 
		{
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
			int nPos = 0;
			hm.put("ROWS_COUNT",Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos+=nlens[nCol];
					//df.CommLogger("["+strHeaders[nCol]+ Integer.toString(n)+"] = '" + rcvBuf.substring(nPos-nlens[nCol],nPos) + "'" );
					hm.put(strHeaders[nCol]+ Integer.toString(n), rcvBuf.substring(nPos-nlens[nCol],nPos) );
				}
			}
		}catch(Exception e) {
			throw e;
		}

		return hm;
	}
	
	/***
	 * getLogisticOutReturnReq
	 * : 물류반품-출고==>거래처반품 : IQ_LOGISTICS_RETURN_OUT_UPDATE_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLogisticOutReturnUpdateReq(String rcvBuf, COMMLog df) throws Exception{
		HashMap hm = new HashMap();
		int nlens[] = {2, 10, 10, 30, 10, 10, 10, 10 };

		String strHeaders[] = {
				"INQ_TYPE",		
				"ACCTUT",		// 센터코드
				"PMCODE",		// 분류상품코드
				"DPCODE",		// 상품코드
				"QTY",			// 수량
				"JMQTY",		// 수량
				"LEADTIME",		// 
				"CUSTCD"		// 거래처코드
		};
		
		try 
		{
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
			int nPos = 0;
			hm.put("ROWS_COUNT",Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos+=nlens[nCol];
					//df.CommLogger("["+strHeaders[nCol]+ Integer.toString(n)+"] = '" + rcvBuf.substring(nPos-nlens[nCol],nPos) + "'" );
					hm.put(strHeaders[nCol]+ Integer.toString(n), rcvBuf.substring(nPos-nlens[nCol],nPos) );
				}
			}
		}catch(Exception e) {
			throw e;
		}
		
		return hm;
	}

	public HashMap getLogisticInDropUpdateReq(String rcvBuf, COMMLog df) throws Exception{
		HashMap hm = new HashMap();
		int nlens[] = { 2, 10, 10, 30, 20, 10, 10, 10, 10 };

		String strHeaders[] = {
				"INQ_TYPE",		
				"CUSTCD", 		    // 거래처코드
				"ACCTUT",			// 센터코드
				"DPCODE", 		    // 상품코드
				"PMCODE",			// 그룹코드
				"QTY",				// 폐기수량
                "PBGB",             //
                "NRML_UNTPRC",
                "NRML_CST_UNTPRC"   // 매입원가
		};
		
		try 
		{
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
			int nPos = 0;
			hm.put("ROWS_COUNT",Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos+=nlens[nCol];
					//df.CommLogger("["+strHeaders[nCol]+ Integer.toString(n)+"] = '" + rcvBuf.substring(nPos-nlens[nCol],nPos) + "'" );
					hm.put(strHeaders[nCol]+ Integer.toString(n), rcvBuf.substring(nPos-nlens[nCol],nPos) );
				}
			}
		}catch(Exception e) {
			throw e;
		}
		return hm;
	}
}
