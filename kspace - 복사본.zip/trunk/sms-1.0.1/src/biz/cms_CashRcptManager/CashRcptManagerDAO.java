package biz.cms_CashRcptManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class CashRcptManagerDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(CashRcptManagerPollingAction.class);
	
	public int updSSGMONEYTRAN_RESET(String proc_id, Map<String, String> map) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("tran-sql", "UPD_CASHRCPTTRAN_RESET"));
			sql.setString(++i, proc_id);
			sql.setString(++i, (String)map.get("SYS_YMD"));
			sql.setString(++i, (String)map.get("STORE_CD"));
			sql.setString(++i, (String)map.get("POS_NO"));
			sql.setString(++i, (String)map.get("TRAN_NO"));
			sql.setString(++i, (String)map.get("COM_CD"));
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public List<Object> selCASHRCPTSPECADJTRPT(String com_cd, String store_cd, int day) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			
			calendar.add(Calendar.DATE, (-1)*day);
			String std_day = sdf.format(calendar.getTime());
			
//			logger.info("std_day="+std_day);
			
			calendar.add(Calendar.DATE, -1);
			String agree_ymd_st = sdf.format(calendar.getTime());
			
//			logger.info("agree_ymd_st="+agree_ymd_st);
						
			calendar.add(Calendar.DATE, -1);
			String tran_ymd_st = sdf.format(calendar.getTime());
			
//			logger.info("tran_ymd_st="+tran_ymd_st);
			
			sql.put(findQuery("tran-sql", "SEL_CASHRCPTSPECADJTRPT"));
			sql.setString(++i, agree_ymd_st);
			sql.setString(++i, tran_ymd_st);
			sql.setString(++i, std_day);
			sql.setString(++i, com_cd);
			sql.setString(++i, agree_ymd_st);
			sql.setString(++i, std_day);
			sql.setString(++i, tran_ymd_st);
			sql.setString(++i, std_day);
			sql.setString(++i, com_cd);
			sql.setString(++i, agree_ymd_st);
			sql.setString(++i, std_day);
			sql.setString(++i, store_cd);
			
			list = executeQuery(sql);
			
//			logger.info(sql.debug());
		}catch(Exception e) {
			logger.info("[ERROR]selCASHRCPTTRAN::" + e);
		}
		
		return list;
	}
	
	public List<Object> selCASHRCPTADJTRPT(String com_cd, String store_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("tran-sql", "SEL_CASHRCPTADJTRPT"));
			sql.setString(++i, com_cd);
			sql.setString(++i, com_cd);
			sql.setString(++i, store_cd);

//			logger.info(sql.debug());
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selCASHRCPTTRAN::" + e);
		}
		
		return list;
	}
	
	public List<Object> selCASHRCPTMSGID() throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("tran-sql", "SEL_CASHRCPT_MSGID"));
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selCASHRCPTMSGID::" + e);
		}
		
		return list;
	}
	
	public List<Object> selCASHRCPTTRAN_RETRANS_SPEC(String com_cd, String store_cd, int day) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			
			calendar.add(Calendar.DATE, (-1)*day);
			String std_day = sdf.format(calendar.getTime());
			
//			logger.info("std_day="+std_day);
			
			calendar.add(Calendar.DATE, -1);
			String agree_ymd_st = sdf.format(calendar.getTime());
			
//			logger.info("agree_ymd_st="+agree_ymd_st);
						
			calendar.add(Calendar.DATE, -1);
			String tran_ymd_st = sdf.format(calendar.getTime());
			
//			logger.info("tran_ymd_st="+tran_ymd_st);
			
			sql.put(findQuery("tran-sql", "SEL_CASHRCPTTRAN_RETRANS_SPEC"));
			sql.setString(++i, tran_ymd_st);
			sql.setString(++i, std_day);
			sql.setString(++i, store_cd);
			sql.setString(++i, com_cd);
			sql.setString(++i, agree_ymd_st);
			sql.setString(++i, std_day);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selCASHRCPTTRAN_RETRANS::" + e);
		}
		
		return list;
	}
	
	public List<Object> selCASHRCPTTRAN_RETRANS(String com_cd, String store_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("tran-sql", "SEL_CASHRCPTTRAN_RETRANS"));
			sql.setString(++i, store_cd);
			sql.setString(++i, com_cd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selCASHRCPTTRAN_RETRANS::" + e);
		}
		
		return list;
	}
	
	public List<Object> selCASHRCPTTRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("tran-sql", "SEL_CASHRCPTTRAN"));
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selCASHRCPTTRAN::" + e);
		}
		
		return list;
	}
	
	public int updCASHRCPTTRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int ret = 0;
		int i = 0;
		int sequence = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			// 통신서버 3대가 같은 row를 update 하려는 시도를 차단하기 위해
			// 1~3 범위로 순환되는 sequence 값을 조회해서 그 값이 (REG_YMDHMS % 3)와 같은
			// row들만 update 한다.
			// 통신서버 3대는 동시에 같은 row를 update 할 수 없게 된다.
//			sql.put(findQuery("tran-sql", "SEL_CASHRCPTGROUPSEQ"));
//			
//			list = executeQuery(sql);
//			sql.close();
//			if( list.size() > 0 ) sequence = Integer.parseInt((String)((Map<String, String>)list.get(0)).get("SEQ"));
			
			i = 0;
			sql.clearParameter();
			sql.put(findQuery("tran-sql", "UPD_CASHRCPTTRAN"));
			sql.setString(++i, proc_ymdhms);
			sql.setString(++i, com_cd);
//			sql.setInt(++i, sequence-1);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			ret = 0;
			rollback();
			logger.info("[ERROR]updCASHRCPTTRAN::" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int procCASHRCPT_APPRNO_INS(String COM_CD, HashMap<String, String> hm) {
		ProcedureWrapper proc = new ProcedureWrapper();
		int i = 0;
		
		int errCd = 0;
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			proc.put("SP_CASHRCPT_APPRNO_INS", 8);
			proc.setString(++i, COM_CD);
			proc.setString(++i, (String)hm.get("APPROVAL_START_NO").trim());
			proc.setString(++i, (String)hm.get("APPROVAL_END_NO").trim());
			proc.setString(++i, (String)hm.get("APPLY_DATE").trim());
			proc.setString(++i, (String)hm.get("NTA_STATEMENT1").trim());
			proc.setString(++i, (String)hm.get("NTA_STATEMENT2").trim());
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// RES_CD
			
			ProcedureResultSet prs = super.executeUpdateProcedure(proc);
			
			errCd = prs.getInt(7);		// 실시간 전송내역
		}catch(Exception e) {
			rollback();
			logger.info("[Error] " + e.getMessage());
		}finally {
			end();
		}
		
		return errCd;
	}
	
	public List<Object> selSVCFILEDAILY(String stdYmd, String svcID, String cmdTp, String comCD) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SVCCRTDAILY"));
			sql.setString(++i, stdYmd);
			sql.setString(++i, svcID);
			sql.setString(++i, cmdTp);
			sql.setString(++i, comCD);
			
			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		} 
		
		return list;
	}
	
	public int updSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			//df.CommLogger("▶ SEL Error : " + e);
			//df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			rollback();	
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
}
