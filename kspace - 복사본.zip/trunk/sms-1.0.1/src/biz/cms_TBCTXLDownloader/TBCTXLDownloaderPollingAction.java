package biz.cms_TBCTXLDownloader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

import org.apache.log4j.Logger;

import biz.comm.SFTPManager;

import com.sshtools.j2ssh.sftp.SftpFile;

/**
 * Receive data from SC through 9013 PORT(SC로부터 데이타를 9013 PORT로 받음).
 * 
 * @param ActionSocket
 * @return
 * @throws Exception
 */
public class TBCTXLDownloaderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(TBCTXLDownloaderPollingAction.class);
	
	private String ubcn_ftp_ip = "";
	private int ubcn_ftp_port = 0;
	private String ubcn_ftp_id = "";
	private String ubcn_ftp_pwd = "";
	
	public static void main(String args[]) throws Exception {
		TBCTXLDownloaderPollingAction action = new TBCTXLDownloaderPollingAction();
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[1]]=" + args[1] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd           = nvl(args[1].replaceFirst("-cmd:"  ,""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "ubcn";
			
			if("10".equals(cmd)){
				action.execute("1");
			}else if("01".equals(cmd)){
				TBCTXLDownloaderInst inst = new TBCTXLDownloaderInst(destPath);
		    	inst.start();
			}
			
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(String actionMode) {
		logger.info("===== TBCTXLDownloaderPollingAction START =====");
		
		SFTPManager sFtpMgr = null;
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK = false;
		boolean isTotDownOK = false;
		String FileNm = "";
		
		try{	
			this.ubcn_ftp_ip = PropertyUtil.findProperty("communication-property", "UBCN_FTP_SERVER_IP"); //ubcn ftp 정보 set
			this.ubcn_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "UBCN_FTP_SERVER_PORT"));
			this.ubcn_ftp_id = PropertyUtil.findProperty("communication-property", "UBCN_FTP_SERVER_ID");
			this.ubcn_ftp_pwd = PropertyUtil.findProperty("communication-property", "UBCN_FTP_SERVER_PWD");
			
			logger.info("[INFO] Trying UBCN SFTP Connection...");
			try{		
				sFtpMgr = new SFTPManager(ubcn_ftp_ip, ubcn_ftp_port, ubcn_ftp_id, ubcn_ftp_pwd);
				logger.info("[INFO] TRY Connected to " + ubcn_ftp_ip + ":" + ubcn_ftp_port);
			}catch(Exception e){
				logger.info("[INFO] exception occur"+e.getMessage());
				logger.info("[INFO] SFTP Connect fail exception occur.");
				return;
			}
			
			logger.info("[INFO] SFTP Connection is Success.");
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "ubcn";
			
			File destDir = new File(destPath);
			
			if( !destDir.exists() ) {
				destDir.mkdir();
				logger.info("[INFO] Try to make dir" );
			}
			isDownOK = false;
			
			sFtpMgr.cd("BatchFile" + File.separator + "RTL"); // 경로변경
		    logger.info("[INFO] TBCTXLDownloaderPollingAction ::: change directory succ.");
			
			//3.파일조회
			String targetFileNm = "";
			int fileCnt = 0;
		    List<Object> fileList = sFtpMgr.ls();
		    if(fileList.size() > 0){
			    for(Object sfiles : fileList){
			    	logger.info("[INFO] TBCTXLDownloaderPollingAction::fileCnt111::["+fileCnt+"]");
			    	SftpFile sf = (SftpFile) sfiles;
			    	if(!(sf.isFile()||(sf.isLink()))){
			    		logger.info("[INFO] TBCTXLDownloaderPollingAction::sf is not file or link.");
			    		fileCnt++;
			    		continue;
			    	}
			    	
			    	//유비씨엔 파일형식 : EMT.171117105949427982 (년(2)/월(2)/일(2)/시(2)/분(2)/초(2)/마이크로초(3)/SEQ(3)
			    	if(!sf.getFilename().startsWith("EMT.")){
			    		logger.info("[INFO] TBCTXLDownloaderPollingAction::sf is not startwith EMT.");
			    		fileCnt++;
			    		continue;
			    	}
			    	
			    	targetFileNm = sf.getFilename();
					bos = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + targetFileNm));
					logger.info("[INFO] TBCReceiverPollingAction::targetFileNm::["+targetFileNm+"]");
					
			    	while (iRetry < 2) {
						logger.info("[INFO] TBCReceiverPollingAction::iRetry::["+iRetry+"]");
				    	if ((isDownOK = sFtpMgr.get(targetFileNm, bos))) {
				    		logger.info("[INFO] Download file succ.");
				          break;
				        }
				        iRetry++;
			        }
					logger.info("[INFO] TBCReceiverPollingAction::isDownOK::["+isDownOK+"]");
					
					bos.flush();
			        bos.close();
				    bos = null;
				    System.gc();
				    
				    if(isDownOK){
				    	logger.info("[INFO] successfully downloaded file ["+targetFileNm+"]");
				    	if( sFtpMgr.rm(targetFileNm) ) {
							logger.info("[INFO] Succeeded remove file.");
						}else {
							logger.info("[INFO] Failed to remove.");
						}
				    }
			    	
			    	fileCnt++;
			    	logger.info("[INFO] TBCTXLDownloaderPollingAction::fileCnt_loopend::["+fileCnt+"]");
			    	
			    }
			    
			    if( (fileList.size()) == fileCnt ){
		    		isTotDownOK = true;
		    		logger.info("[INFO] TBCTXLDownloaderPollingAction::isTotDownOK::["+isTotDownOK+"]");
		    	}
			    
			    logger.info("[INFO] TBCReceiverPollingAction::6");
			    if(isTotDownOK){
			    	logger.info("[INFO] TBCReceiverPollingAction::TBC DATA INSERT START"); //트란데이터 insert (TranRcv참조)
			    	TBCTXLDownloaderInst inst = new TBCTXLDownloaderInst(destPath);
			    	inst.start();
			    }
		    	
		    }else{
		    	logger.info("[INFO] TBCTXLDownloaderPollingAction::FILE_SIZE::["+fileList.size()+"]::FILE IS NOT EXIST.");
		    }
			
		    
		}catch(Exception e){
			logger.info("[ERROR] TBCTXLDownloaderPollingAction::ERR OCCUR.");
			logger.info("[ERROR] TBCTXLDownloaderPollingAction::ERR_MSG::["+e.getMessage()+"]");
			logger.info("[ERROR] TBCTXLDownloaderPollingAction::ERR_TRACE::["+e.getStackTrace()+"]");
		}finally{
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {
				logger.info("[ERROR] ERR_MSG::["+e.getMessage()+"]");
			}
			
			logger.info("===== TBCTXLDownloaderPollingAction END =====");
		}
		
	}
	
	public void getTXLFile(){
		
	}
}