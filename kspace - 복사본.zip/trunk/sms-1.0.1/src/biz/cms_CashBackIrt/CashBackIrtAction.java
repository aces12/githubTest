package biz.cms_CashBackIrt;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.net.Socket;
import java.net.SocketTimeoutException;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.core.config.repository.telegram.MessageForm;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

/* ******************************************************************************************************
 *******************************************************************************************************/
public class CashBackIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(CashBackIrtAction.class);
		
	private String cashback_server_ip = "";
	private int cashback_server_port = 0;
	
	/**
	 * Receive data from SC through 9022 PORT(SC로부터 데이타를 9022 PORT (internal14030)로 받음).
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 * @author neo0531
	 */

	
	public void execute(ActionSocket actionSocket) throws Exception {		
		int ret = 0;
		int inq_type = 0;	
		//캐쉬백 van_cd 추가 lys
		int van_cd = 0;

		int job_cd = 0;
		String sendMsg = "";
		String dataMsg = "";
		String totalRcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		StringBuffer sb = null;
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		COMMLog df = new COMMLog();
		CashBackIrtDAO dao = new CashBackIrtDAO();
		
		Socket extClntSock = null;
		CashBackIrtConveyer CashBackConveyer = null;

		//캐쉬백 VAN 추가	lys
		//this.cashback_server_ip = PropertyUtil.findProperty("communication-property", "CASHBACK_SERVER_IP");
		//this.cashback_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CASHBACK_SERVER_PORT"));
		
		//오현태담당님 요청사항 lys
		//logger.info("cashback_server_ip : "+cashback_server_ip+" / cashback_server_port : "+cashback_server_port);
		
		try {	// Data received from SC(SC로부터 받은 데이타)
			totalRcvBuf = ((String) actionSocket.receive());
			//오현태담당님 요청사항 lys
			//logger.info("totalRcvBuf=====:"+ totalRcvBuf);
			

			if( totalRcvBuf.length() < COMMBiz.CM_LENS + 2 ) return; 
			
			//오현태담당님 요청사항 lys
			logger.info("totalRcvBuf=====:"+ totalRcvBuf);
			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,	"CASHBACK");
			
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(totalRcvBuf, COMMBiz.CM_HEADER);			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 확인한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}						
			logger.info("MSG_LEN : " + hmCommon.get("MSG_LEN"));
			rcvDataBuf = totalRcvBuf.substring(COMMBiz.CM_LENS);			// 플랫폼 헤더 제외 IRT 전문
			inq_type = protocol.getCashBackIrtInq(rcvDataBuf);
			

			//캐쉬백 VAN 추가 lys
			if(inq_type == CashBackData.POSREQ95
					|| inq_type == CashBackData.POSREQ96
					|| inq_type == CashBackData.POSREQ97
					|| inq_type == CashBackData.POSREQ98) {
			
				van_cd = protocol.getCahBackVanCdIng(rcvDataBuf);
			}
			
			df.CommLogger("******** van_cd :  " + van_cd);
			
			//청호:21, 한네트:22
//			if(van_cd == CashBackData.VAN_CHUNGHO) {
//				
//				this.cashback_server_ip = PropertyUtil.findProperty("communication-property", "CASHBACK_SERVER_IP");
//				this.cashback_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CASHBACK_SERVER_PORT"));
//			
//			} else if(van_cd == CashBackData.VAN_HANNET) {
			if(van_cd == CashBackData.VAN_HANNET) {
				
				Socket conTest = null;
				
				this.cashback_server_ip = PropertyUtil.findProperty("communication-property", "CASHBACK_HANNET_SERVER_IP");
				this.cashback_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CASHBACK_HANNET_SERVER_PORT"));
				
//				try {
//					conTest = new Socket(this.cashback_server_ip, this.cashback_server_port);
//					logger.info("cashback_server_ip : " + cashback_server_ip 
//									+ " / cashback_server_port : "+cashback_server_port
//									+ " / conTest.isConnected() : " + conTest.isConnected());
//					
//					if(!conTest.isConnected()) {
//						
//						df.CommLogger("▶  [ERROR] not connected : " + this.cashback_server_ip);
//						this.cashback_server_ip = PropertyUtil.findProperty("communication-property", "CASHBACK_HANNET_SERVER_IP_2");
//						this.cashback_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CASHBACK_HANNET_SERVER_PORT_2"));
//					}
//
//				} catch (Exception e) {
//					
//					this.cashback_server_ip = PropertyUtil.findProperty("communication-property", "CASHBACK_HANNET_SERVER_IP_2");
//					this.cashback_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CASHBACK_HANNET_SERVER_PORT_2"));
//					
//					df.CommLogger("▶  [ERROR] not connected : " + this.cashback_server_ip + " / " + e.getMessage());
//				}
//				finally {
//
//					conTest.close();
//				}
			}
			else {
				
				this.cashback_server_ip = PropertyUtil.findProperty("communication-property", "CASHBACK_SERVER_IP");
				this.cashback_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CASHBACK_SERVER_PORT"));
			}
			
			logger.info("van_cd : " + van_cd + " / cashback_server_ip : "+cashback_server_ip+" / cashback_server_port : "+cashback_server_port);
			//캐쉬백 VAN end
			//신규 inq_type "C3" 이면 분기하여 접속정보 설정 
			if (inq_type == CashBackData.POSREQ_C3){
				this.cashback_server_ip = PropertyUtil.findProperty("communication-property", "CASHBACK_COMMON_SERVER_IP");
				this.cashback_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CASHBACK_COMMON_SERVER_PORT"));

				logger.info(" cashback_common_server_ip : "+cashback_server_ip+" / cashback_common_server_port : "+cashback_server_port);
			} 
			
			
			switch(inq_type) {//95: 캐시백출금요청 ,96 캐시백출금취소, 97 캐시백 수수료조회, 98 캐시백 키교환  				
			
				case CashBackData.POSREQ_C3:{//neo0531 공동망서비스
					//job_code 3100: 구매환불 수취조회, 4000:구매    4100:구매환불 4200 :인출 
					df.execute("cashback common request");	
					job_cd = protocol.getCashBackIrtJobCd(rcvDataBuf);
					logger.info("getCashBackIrtJobCd job_cd["+ job_cd + "]");
					switch(job_cd){	//neo0531 cash back 공동망 					
						case 3100:{ //구매환불 수취 조회									
							hmData = protocol.getParseCashbackPosReq_Common(rcvDataBuf);
							logger.info("getParseCashbackPosReq_Common 3100");
							sb = null;
							sb = new StringBuffer(totalRcvBuf);
							
							logger.info("POSREQ3100[pos>sms] RECV[size:" + totalRcvBuf.getBytes().length + "]:[job_cd:" + job_cd + "]:["+ sb.toString() + "]");
							
							extClntSock = new Socket(cashback_server_ip, cashback_server_port);
							CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
							
							logger.info("getCashBackRsp3100");
							dataMsg = CashBackConveyer.getCashBackRsp3100(hmCommon, hmData );

							ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
							dataMsg = dataMsg.substring(2);
							break;								
						}
						case 4000:{ //구매
							hmData = protocol.getParseCashbackPosReq_Common(rcvDataBuf);
							logger.info("getParseCashbackPosReq_Common 4000");
							sb = null;
							sb = new StringBuffer(totalRcvBuf);
							
							logger.info("POSREQ4000[pos>sms] RECV[size:" + totalRcvBuf.getBytes().length + "]:[job_cd:" + job_cd + "]:["+ sb.toString() + "]");
							
							extClntSock = new Socket(cashback_server_ip, cashback_server_port);
							
							CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
							
							dataMsg = CashBackConveyer.getCashBackRsp4000(hmCommon, hmData );
							logger.info("getCashBackRsp4000");

							ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
							dataMsg = dataMsg.substring(2);
							
							break;
						}
						case 4100:{ //구매환불
							hmData = protocol.getParseCashbackPosReq_Common(rcvDataBuf);
							logger.info("getParseCashbackPosReq_Common 4100");
							sb = null;
							sb = new StringBuffer(totalRcvBuf);
							
							logger.info("POSREQ4100[pos>sms] RECV[size:" + totalRcvBuf.getBytes().length + "]:[job_cd:" + job_cd + "]:["+ sb.toString() + "]");
							
							extClntSock = new Socket(cashback_server_ip, cashback_server_port);
							CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
							
							dataMsg = CashBackConveyer.getCashBackRsp4100(hmCommon, hmData );
							logger.info("getCashBackRsp4100");

							ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
							dataMsg = dataMsg.substring(2);							
							break;
						}
	
						case 4200:{ //인출
							hmData = protocol.getParseCashbackPosReq_Common(rcvDataBuf);
							logger.info("getParseCashbackPosReq_Common 4200");
							sb = null;
							sb = new StringBuffer(totalRcvBuf);
							
							logger.info("POSREQ4200[pos>sms] RECV[size:" + totalRcvBuf.getBytes().length + "]:[job_cd:" + job_cd + "]:["+ sb.toString() + "]");
							
							extClntSock = new Socket(cashback_server_ip, cashback_server_port);
							CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
							
							dataMsg = CashBackConveyer.getCashBackRsp4200(hmCommon, hmData );
							logger.info("getCashBackRsp4200");

							ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
							dataMsg = dataMsg.substring(2);							
							break;
						}
						case 6100:{ //구매환불 결과조회
							hmData = protocol.getParseCashbackPosReq_Common(rcvDataBuf);
							logger.info("getParseCashbackPosReq_Common");
							sb = null;
							sb = new StringBuffer(totalRcvBuf);
							
							logger.info("POSREQ6100[pos>sms] RECV[size:" + totalRcvBuf.getBytes().length + "]:[job_cd:" + job_cd + "]:["+ sb.toString() + "]");
							
							extClntSock = new Socket(cashback_server_ip, cashback_server_port);
							CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
							
							dataMsg = CashBackConveyer.getCashBackRsp6100(hmCommon, hmData );
							logger.info("getCashBackRsp6100");

							ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
							dataMsg = dataMsg.substring(2);							
							break;
						}
						default :{
							
							break;
						}
						
						
					}//switch(job_cd)

					break;
				}//case CashBackData.POSREQ_C3:
			
				case CashBackData.POSREQ95:{//95: 캐시백출금요청
					df.execute("cashback withdraw request");	
					logger.info("===== in switch case =====");
//					CashBackData.VariousEncryptedData = 
//							protocol.getCashBackIrtVariousEncryptedDataLength(hmCommon,CashBackData.POSREQ95);
					
					if(van_cd == 0) {
						hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ95);
					}
					else {
						hmData = protocol.getParseCashbackPosReq_New(rcvDataBuf,CashBackData.POSREQ95);
					}
										
					logger.info("hmData PLU_NM :" + hmData.get("PLU_NM"));
					logger.info("hmData ENC_DATA_LENGTH :" + hmData.get("ENC_DATA_LENGTH"));
					
					logger.info("getParseCashbackPosReq");
					sb = null;
					sb = new StringBuffer(totalRcvBuf);
					//캐쉬백 van 추가 lys
					//df.CommLogger("POSREQ95[pos>sms] RECV[" + totalRcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");
					df.CommLogger("POSREQ95[pos>sms] RECV[" + totalRcvBuf.getBytes().length 
							+ "]:[INQ_TYPE:" + inq_type + "]:[" 
							+ "]:[VAN_CD:" + van_cd + "]:["
							+ sb.toString() + "]");
					/*	//배민수담당요청 기존 IRT 전송시 처리 하지 않게 처리함 
					extClntSock = new Socket(cashback_server_ip, cashback_server_port);
					CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
					
					dataMsg = CashBackConveyer.getCashBackRsp95(hmCommon, hmData );
					logger.info("getCashBackRsp95");

					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					*///배민수담당요청 기존 IRT 전송시 처리 하지 않게 처리함
					ret = 29;
					break;				
				}
				case CashBackData.POSREQ96:{//96: 계좌출금조회
					df.execute("cashback withdraw search");	
					
//					CashBackData.VariousEncryptedData = 
//							protocol.getCashBackIrtVariousEncryptedDataLength(hmCommon,CashBackData.POSREQ96);
					logger.info("getCashBackIrtVariousEncryptedDataLength : " + CashBackData.VariousEncryptedData);
					
					if(van_cd == 0) {
						hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ96);
					} else {
						hmData = protocol.getParseCashbackPosReq_New(rcvDataBuf,CashBackData.POSREQ96);
					}
										
					sb = null;
					sb = new StringBuffer(totalRcvBuf);
					//캐쉬백 van 추가 lys
					//df.CommLogger("POSREQ96[pos>sms] RECV[" + totalRcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");
					df.CommLogger("POSREQ96[pos>sms] RECV[" 
								+ totalRcvBuf.getBytes().length 
								+ "]:[INQ_TYPE:" + inq_type + "]:[" 
								+ "]:[VAN_CD:" + van_cd + "]:["
								+ sb.toString() + "]");

					extClntSock = new Socket(cashback_server_ip, cashback_server_port);
					CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
					
					dataMsg = CashBackConveyer.getCashBackRsp96(hmCommon, hmData );
										
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;				
				}
				case CashBackData.POSREQ97:{//97: 수수료 조회
					df.execute("cashback FEE search");	
					logger.info("===== in switch case =====");
//					CashBackData.VariousEncryptedData = 
//							protocol.getCashBackIrtVariousEncryptedDataLength(hmCommon,CashBackData.POSREQ97);
//					logger.info("CashBackData.VariousEncryptedData: "+CashBackData.VariousEncryptedData);
//					logger.info("getCashBackIrtVariousEncryptedDataLength : " + CashBackData.VariousEncryptedData);
					
					if(van_cd == 0) {
						hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ97);
					} else {
						hmData = protocol.getParseCashbackPosReq_New(rcvDataBuf,CashBackData.POSREQ97);
					}
										
					logger.info("getParseCashbackPosReq success");
					logger.info("ENC_DATA_LENGTH: "+hmData.get("ENC_DATA_LENGTH"));
					logger.info("ENCRYPTED_DATA: "+hmData.get("ENCRYPTED_DATA"));
					sb = null;
					sb = new StringBuffer(totalRcvBuf);					
					//캐쉬백 van 추가 lys
					//df.CommLogger("POSREQ97[pos>sms] RECV[" + totalRcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");
					df.CommLogger("POSREQ97[pos>sms] RECV[" 
									+ totalRcvBuf.getBytes().length 
									+ "]:[INQ_TYPE:" + inq_type
									+ "]:[VAN_CD:" + van_cd + "]:["
									+ "]:[" + sb.toString() + "]");
					
					extClntSock = new Socket(cashback_server_ip, cashback_server_port);
					CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
					
					dataMsg = CashBackConveyer.getCashBackRsp97(hmCommon, hmData );
					logger.info("getCashBackRsp97");
										
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;				
				}	
				case CashBackData.POSREQ98:{//98:키교환
					df.execute("cashback key transfer");	
					
//					CashBackData.VariousEncryptedData = 
//							protocol.getCashBackIrtVariousEncryptedDataLength(hmCommon,CashBackData.POSREQ98);
//					logger.info("getCashBackIrtVariousEncryptedDataLength : " + CashBackData.VariousEncryptedData);
					
					if(van_cd == 0) {
						hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ98);
					} else {
						hmData = protocol.getParseCashbackPosReq_New(rcvDataBuf,CashBackData.POSREQ98);
					}
										
					sb = null;
					sb = new StringBuffer(totalRcvBuf);					
					//캐쉬백 van 추가 lys
					//df.CommLogger("POSREQ98[pos>sms] RECV[" + totalRcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");
					df.CommLogger("POSREQ98[pos>sms] RECV[" 
									+ totalRcvBuf.getBytes().length 
									+ "]:[INQ_TYPE:" + inq_type 
									+ "]:[VAN_CD:" + van_cd + "]:["
									+ "]:[" + sb.toString() + "]");
					
					extClntSock = new Socket(cashback_server_ip, cashback_server_port);
					CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
					
					dataMsg = CashBackConveyer.getCashBackRsp98(hmCommon, hmData );
										
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;				
				}
				case CashBackData.POSREQ99:{//99: 점포별 한도 금액 조회 
			
					
					df.execute("store limit Amt search");	
										
					
					hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ99);					
					logger.info("hmData1 ");								

					dataMsg = dao.getLimitBalance(hmCommon, hmData,df );//점포별 한도조회 
					logger.info("dataMsg2 ");
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
																			
//					ret = 00;
//					dataMsg = "9900999250000000000000000500000";
					break;				
				}
				case CashBackData.POSREQ91:{// "A1" > 91: 사후출금 조회
					df.execute("after_flag check");	
													
					hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ91);					
					logger.info("hmData3_");								

					dataMsg = dao.getAfterFlag(hmCommon, hmData,df );//점포별 한도조회 
					logger.info("dataMsg4_");
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
																			
					break;				
				}	
				
				default:
					df.CommLogger("▶ INQ Code(INQ 종별 코드):   [" + inq_type + "]" + totalRcvBuf.length());
					ret = 99;
					break;
			}
		
		}catch(SocketTimeoutException ste) {		  
			ret = 39; // 039=receive time out
			retValue = "[ERROR]39:" + ste.getMessage();
			logger.info("=====▶ " + retValue);
			df.CommLogger("▶ " + retValue);
			
		}catch (Exception e) 
		{
			ret = 29; // 029=HOST APPL ERR
			retValue = "[ERROR]2:" + e.getMessage();
			logger.error("=====▶ " + retValue);
			df.CommLogger("▶ " + retValue);
		}
		
		try {
			
//			//개쉬백 응답메세지 테스트용 20170217
//			if("10.149.207.118".equals(actionSocket.getSocket().getInetAddress().getHostAddress().toString())) {
//				
//				switch(inq_type) {//95: 캐시백출금요청 ,96 캐시백출금취소, 97 캐시백 수수료조회, 98 캐시백 키교환  
//					case CashBackData.POSREQ95:{//95: 캐시백출금요청
//						
//						
//						break;
//					}
//					case CashBackData.POSREQ96:{//96 캐시백출금취소
//											
//						break;
//					}
//					case CashBackData.POSREQ97:{//7 캐시백 수수료조회
//						
//						break;
//					}
//					case CashBackData.POSREQ98:{//98 캐시백 키교환
//						
//						break;
//					}
//				}
//			}
//			// end
			
			// Make Response Message Data(응답 전문데이타 만들기)
			logger.info(" ret=>"+ret);
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);			
			logger.info("sendMsg=>"+sendMsg);
			//캐쉬백 VAN 추가 lys
			String totalMsg = sendMsg + dataMsg;
			logger.info("totalMsg=>"+totalMsg);
			//String totalMsg = sendMsg + dataMsg + Integer.toString(van_cd);
					
			df.CommLogger("================ 4-2) POS<-SMS 응답전문 ===================");
			df.CommLogger("전문길이=[" + totalMsg.getBytes().length + "]");
			
			if (dataMsg !="" && dataMsg != null)
				df.CommLogger("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
			
			//캐쉬백 VAN 추가 lys
			//df.CommLogger("VAN_CD=[" + Integer.toString(van_cd) + "]");
			df.CommLogger("전문내용=[" + totalMsg + "]");
			
			// Send Response Data (응답 데이타 전송)
			if (actionSocket.send(totalMsg)) 
			{
				df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
			} 
			else 
			{
				df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		}
		catch (Exception e) 
		{
			retValue = "[ERROR]4" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}
		finally 
		{
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("CASHBACK", retValue);
			
			if (!extClntSock.isClosed()) 
			{
				extClntSock.close();
			}
		}
	}
	
}
	
	
	
	
	
	



