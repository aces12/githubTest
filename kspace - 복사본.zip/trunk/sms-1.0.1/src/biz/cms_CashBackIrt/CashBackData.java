package biz.cms_CashBackIrt;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import biz.cms_TranDivide.TranDivide_Define;
import java.util.Map;

import org.apache.log4j.Logger;

public class CashBackData {
	private static Logger logger = Logger.getLogger(CashBackIrtAction.class);

	static final int POSREQ95 = 95;
	static final int POSRSP95 = 195;
	static final int POSREQ96 = 96;
	static final int POSRSP96 = 196;
	static final int POSREQ97 = 97;
	static final int POSRSP97 = 197;
	static final int POSREQ98 = 98;
	static final int POSRSP98 = 198;
	static final int POSREQ99 = 99;
	static final int POSRSP99 = 199;
	static final int POSREQ91 = 91;


	static final int POSRSP_C3 = 2128;
	static final int POSREQ_C3 = 2128;
	
	//irt 고정부 사이즈 
	static final int COMHEADER   = 50;
	static final int POSREQ95FIX = 255;
	static final int POSRSP95FIX = 369;  
	static final int POSREQ96FIX = 261;
	static final int POSRSP96FIX = 251 ;  
	static final int POSREQ97FIX = 215;
	static final int POSRSP97FIX = 249;  
	static final int POSREQ98FIX = 205;
	static final int POSRSP98FIX = 233; 
	
	public static final int COMMONHFIX = 309; //공통부
	public static final int PGREQ95FIX = 233;
	public static final int PGREQ96FIX = 82;		
	public static final int PGREQ97FIX = 26;
	public static final int PGREQ98FIX = 8;
	
	static int VariousEncryptedData = 0;
	static int variousPGEncLen = 0;
	
	//캐쉬백 VAN 추가 lys
	static final int VAN_CHUNGHO = 21;
	static final int VAN_HANNET = 22;
	
//	static final int INQ101 = 88;
//	static final int INQ301 = 89;
//	static final int INQ901 = 87;
//	
//	static final int REQ101 = 101;
//	static final int REQ201 = 201;
//	static final int REQ301 = 301;
//	static final int REQ401 = 401;
//	static final int REQ901 = 901;
//	
//	static final int RSP100 = 100;
//	static final int RSP200 = 200;
//	static final int RSP300 = 300;
//	static final int RSP400 = 400;
//	static final int RSP900 = 900;
//	
//	static final int len_REQ101 = 101;
//	static final int len_REQ301 = 301;	
//	static final int len_REQ901 = 901;
//	
//	static final int len_REQ201 = 201;	
//	static final int len_REQ401 = 401;
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//POS ->SMS , SMS->POS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//withdraw requst POS 95 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	static int nlensPosReq95[] = { 
//			 2,4,4,1,8
//			,6,10,14,6,2
//			,40,200,3,10,40
//			,5,VariousEncryptedData
//			};

	public static void setEncLen(int n)
	{
		variousPGEncLen = n;
		logger.info("setEncLen" + variousPGEncLen);
	}
	
	public static int getEncLen()
	{
		logger.info("getEncLen" + variousPGEncLen);
		 return variousPGEncLen ;
		
	}
	
	static final int nlensPosReq95_New[] = { 
		2,4,4,1,8
		,6,10,14,6,2
		,40,100,3,10,40
		,5,5000,2
		};
	
	
	static final String strHeadersPosReq95_New[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			
			,"TRADE_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"INQ_UNIQ_NO" //
			,"SECURITY_YN" //
			
			,"MCH_SEND_UNIQ_NO" //
			,"FILLER" //
			,"BANK_CD" //
			,"TRADE_AMT" //
			,"PLU_NM" //
			
			,"ENC_DATA_LENGTH" //
			,"ENCRYPTED_DATA" //
			,"VAN_CD" //캐쉬백 VAN 추가 lys	

	};	
	
	static final int nlensPosReq95[] = { 
		2,4,4,1,8
		,6,10,14,6,2
		,40,100,3,10,40
		,5,5000
		};
	
	
	static final String strHeadersPosReq95[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			
			,"TRADE_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"INQ_UNIQ_NO" //
			,"SECURITY_YN" //
			
			,"MCH_SEND_UNIQ_NO" //
			,"FILLER" //
			,"BANK_CD" //
			,"TRADE_AMT" //
			,"PLU_NM" //
			
			,"ENC_DATA_LENGTH" //
			,"ENCRYPTED_DATA" //
	};	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//withdraw response POS 95 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//	public static int[] nlensPosRsp95(){
//		int nlensPosRsp95[] = { 
//				 2,4,4,1,8
//				,6,10,14,6,40
//				,100,4,100,30,8
//				,12,10,8,8,5
//				,VariousEncryptedData
//								};
//		return nlensPosRsp95;
//	};
	static final int nlensPosRsp95[] = { 
		2,4,4,1,8
		,6,10,14,6,40
		,100,4,100,30,8
		,12,10,8,8,5
		,5000
		};
	
	static final String strHeadersPosRsp95[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			
			,"TRADE_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"INQ_UNIQ_NO" //
			,"MCH_SEND_UNIQ_NO"//
			
			,"FILLER"
			,"RESP_CODE"//
			,"RESP_MSG"//
			,"TRANS_ID"//
			,"ADMIT_DATE"//
			
			,"ADMIT_NO"//
			,"TRADE_AMT"
			,"COM_AMT"//
			,"EVT_AMT"//			
			,"ENC_DATA_LENGTH" //
			
			,"ENCRYPTED_DATA" //

	};

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//withdraw requst POS 96 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	static final int nlensPosReq96_New[] = { 
		2,4,4,1,8
		,6,10,14,6,2
		,40,100,3,6,40
		,10,5,5000,2
		};
	
	
	static final String strHeadersPosReq96_New[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			
			,"TRADE_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"INQ_UNIQ_NO" //
			,"SECURITY_YN" //
			
			,"MCH_SEND_UNIQ_NO" //
			,"FILLER" //
			,"BANK_CD" //
			,"ORG_INQ_UNIQ_NO" //
			,"ORG_MCH_SEND_UNIQ_NO" //
			
			,"ORG_TRADE_AMT" //
			,"ENC_DATA_LENGTH" //
			,"ENCRYPTED_DATA" //
			,"VAN_CD" //캐쉬백 VAN 추가 lys

	};	
	
	static final int nlensPosReq96[] = { 
		2,4,4,1,8
		,6,10,14,6,2
		,40,100,3,6,40
		,10,5,5000
		};
	
	
	static final String strHeadersPosReq96[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			
			,"TRADE_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"INQ_UNIQ_NO" //
			,"SECURITY_YN" //
			
			,"MCH_SEND_UNIQ_NO" //
			,"FILLER" //
			,"BANK_CD" //
			,"ORG_INQ_UNIQ_NO" //
			,"ORG_MCH_SEND_UNIQ_NO" //
			
			,"ORG_TRADE_AMT" //
			,"ENC_DATA_LENGTH" //
			,"ENCRYPTED_DATA" //
	};
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//withdraw response POS 96 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlensPosRsp96[] = { 
			 2,4,4,1,8
			,6,100,4,100,8
			,10,5,5000
			};
	
	static final String strHeadersPosRsp96[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			
			,"TRADE_TIME" //			
			,"FILLER"
			,"RESP_CODE"//
			,"RESP_MSG"//
			,"CANCLE_DATE"
			,"CANCLE_AMT"//
						
			,"ENC_DATA_LENGTH" //
			,"ENCRYPTED_DATA" //

	};	
	

	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//withdraw requst POS 97 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	static final int nlensPosReq97_New[] = { 
		2,4,4,1,8
		,6,10,14,6,2
		,40,100,3,10,5
		,5000,2
		};

	
	static final String strHeadersPosReq97_New[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			
			,"TRADE_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"INQ_UNIQ_NO" //
			,"SECURITY_YN" //
			
			,"MCH_SEND_UNIQ_NO" //
			,"FILLER" //
			,"BANK_CD" //
			,"TRADE_AMT" //			
			,"ENC_DATA_LENGTH" //
			
			,"ENCRYPTED_DATA" //
			,"VAN_CD" //캐쉬백 VAN 추가 lys

	};	
	
	static final int nlensPosReq97[] = { 
		2,4,4,1,8
		,6,10,14,6,2
		,40,100,3,10,5
		,5000
		};

	
	static final String strHeadersPosReq97[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			
			,"TRADE_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"INQ_UNIQ_NO" //
			,"SECURITY_YN" //
			
			,"MCH_SEND_UNIQ_NO" //
			,"FILLER" //
			,"BANK_CD" //
			,"TRADE_AMT" //			
			,"ENC_DATA_LENGTH" //
			
			,"ENCRYPTED_DATA" //
	};
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//withdraw response POS 97 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlensPosRsp97[] = { 
			 2,4,4,1,8
			,6,100,4,100,8
			,5,5000
			};
	
	static final String strHeadersPosRsp97[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			
			,"TRADE_TIME" //
			,"FILLER"
			,"RESP_CODE"//
			,"RESP_MSG"//
			,"COM_AMT"//
			
			,"ENC_DATA_LENGTH" //
			,"ENCRYPTED_DATA" //

	};	
	
	

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//withdraw requst POS 98 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlensPosReq98_New[] = { 
		2,4,4,1,8
		,6,10,14,6,2
		,40,100,3,5,5000
		,2
		};
	
	static final String strHeadersPosReq98_New[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			
			,"TRADE_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"INQ_UNIQ_NO" //
			,"SECURITY_YN" //
			
			,"MCH_SEND_UNIQ_NO" //
			,"FILLER" //
			,"BANK_CD" //			
			,"ENC_DATA_LENGTH" //
			,"ENCRYPTED_DATA" //
			,"VAN_CD" //캐쉬백 VAN 추가 lys

	};	
	
	static final int nlensPosReq98[] = { 
		2,4,4,1,8
		,6,10,14,6,2
		,40,100,3,5,5000
		};
	
	static final String strHeadersPosReq98[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			
			,"TRADE_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"INQ_UNIQ_NO" //
			,"SECURITY_YN" //
			
			,"MCH_SEND_UNIQ_NO" //
			,"FILLER" //
			,"BANK_CD" //			
			,"ENC_DATA_LENGTH" //
			,"ENCRYPTED_DATA" //
	};
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//withdraw response POS 98 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlensPosRsp98[] = { 
			 2,4,4,1,8
			,6,100,4,100,5
			,5000
			};
	
	static final String strHeadersPosRsp98[] = { 
			"INQ_TYPE" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			,"TRADE_DATE" //
			,"TRADE_TIME" //			
			,"FILLER"						
			,"RESP_CODE"//
			,"RESP_MSG"//						
			,"ENC_DATA_LENGTH" //

			,"ENCRYPTED_DATA" //

	};	
	
	static final int nlensPosReqComm[] = { 
		 2,5,4,5,4
		,4,1,8,6,10
		,17,6,40,3,3
		,2,16,16,16,132
		,30,128,13,13,13
		,13,8,4,4,1
		,4
		};
	
	static final String strHeadersPosReqComm[] = { 
			 "INQ_TYPE" //
			,"STORE_CD" //
			,"POS_NO" //
			,"VERSION" //
			,"MSG_CD" //
			
			,"JOB_CD" //
			,"SENDRECV_FLAG" //
			,"POS_TRAN_YMD" //
			,"POS_TRAN_TIME" //
			,"MID" //
			
			,"TERMINAL_ID" //
			,"TERMINAL_SEQ" //			
			,"MCH_ORDER_NO" //
			,"ISS_BANK_CD" //			
			,"BUY_BANK_CD" //
			
			,"VAN_TYPE_CD" //
			,"PAY_AMT" //
			,"SERVICE_AMT" //
			,"VAT_AMT" //			
			,"ENC_INFO" //
			
			,"TRACK_INFO" //
			,"IC_CARD_SEQ" //
			,"MCH_MANG_NO" //13
			,"BUY_AUTH_UNIQ_NO"//13
			,"BUY_MCH_SEND_UNIQ_NO" //		13
			
			,"ORG_MCH_SEND_UNIQ_NO" //13			
			,"ORG_TRAN_YMD" //8
			,"ORG_POS_NO" //4
			,"ORG_TRAN_NO" //4
			,"CARD_INFO_YN" //1
			
			,"MEMB_JOB_CD" //4
	};
	
	
	static final int nlensPosRspComm[] = { 
		 2,4,4,1,8
		,6,3,200,13,16
		,16,16,16,16,16
		,16,20,16,1,16 
		,8,6
		};

	static final String strHeadersPosRspComm[] = { 
		"INQ_TYPE" //
		,"MSG_CD" //
		,"JOB_CD" //
		,"SENDRECV_FLAG" //
		,"POS_TRAN_YMD" //
		
		,"POS_TRAN_TIME" //
		,"RSP_CD" //
		,"RSP_MSG" //
		,"MCH_SEND_UNIQ_NO" //
		,"SERVICE_AMT" //
		
		,"VAT_AMT" //
		,"MCH_CHARGE_AMT" //
		,"ISSINS_CHARGE_AMT" //
		,"BUYINS_CHARGE_AMT" //
		,"VAN_CHARGE_AMT" //
		
		,"ATM_CHARGE_AMT" //
		,"PRT_ACCOUNT_NO" //
		,"AMT" //
		,"CASHBAG_TRAN_YN" //
		,"CASHBAG_TRAN_AMT" //
		
		,"ADMIT_DATE"
		,"ADMIT_TIME"
		};	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static final int nlensPosReq99[] = { 
			 2,5,2
			};

	
	static final String strHeadersPosReq99[] = { 
			"INQ_TYPE" //
			,"STORE_CODE" //
			,"SERVICE_TP" //	
	};	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//withdraw response POS 99 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static int nlensPosRsp99[] = { 
			 2,5,2,22
			};
	
	static final String strHeadersPosRsp99[] = { 
		"INQ_TYPE" //
		,"STORE_CODE" //
		,"SERVICE_TP" //
		,"LMT_RAMT"//점별 한도액 
	};	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlensPosReq91[] = { 
		 2, 13, 8, 5, 4
		 , 4
		 };
	
	static final String strHeadersPosReq91[] = { 
		"INQ_TYPE"
		, "OP_NO"
		, "TRAN_YMD"
		, "STORE_CD"
		, "POS_NO"
		, "TRAN_NO"
		};	
	
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//SMS->VEN    ,VEN ->SMS  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//COMMON HEADER /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static int nlensComHeader[] = { 
			 5,5,4,4,1
			,8,6,10,14,6
			,2,40,4,100,100
			};
	
	static final String strHeadersComHeader[] = { 
			 "VERSION" //
			,"LENGTH" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			
			,"TRADE_DATE" //			
			,"TRADE_TIME"//
			,"MID"//						
			,"TERMINAL_ID" //
			,"INQ_UNIQ_NO" //

			,"SECURITY_YN" //			
			,"MCH_SEND_UNIQ_NO"//
			,"RESP_CODE"//						
			,"RESP_MSG" //
			,"FILLER"//
			};	

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//SMS 95 계좌출금 계좌 이체 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static int[] nlensSms95(){
	int  nlensSms95[] = { 
			 5,5,4,4,1
				,8,6,10,14,6
				,2,40,4,100,100
				,3,10,40,30,8
				,12,8,30,15,12
				,60,5,VariousEncryptedData
				};
	return nlensSms95;
};
	
//	static int nlensSms95[] = { 
//			 5,5,4,4,1
//			,8,6,10,14,6
//			,2,40,4,100,100
//			,3,10,40,30,8
//			,12,8,30,15,12
//			,60,5,5
//			};
	
	static final String strHeadersSms95[] = { 
			 "VERSION" //
			,"LENGTH" //
			,"INQ_CODE" //p
			,"WORK_CODE" //p
			,"SEND_FLAG" //p
			
			,"TRADE_DATE" //p			
			,"TRADE_TIME"//p
			,"MID"//	p					
			,"TERMINAL_ID" //p
			,"INQ_UNIQ_NO" //p

			,"SECURITY_YN" //	p		
			,"MCH_SEND_UNIQ_NO"//p
			,"RESP_CODE"//						
			,"RESP_MSG" //	
			,"FILLER"//p
			,"BANK_CD" //p
			
			,"TRADE_AMT" //p
			,"PLU_NM" //p
			,"TRANS_ID" //
			,"ADMIT_DATE" //
			
			,"ADMIT_NO" //			
			,"COM_AMT"//
			,"CUS_NM"//						
			,"CUS_AUTH_NO" //
			,"CUS_TEL" //

			,"CUS_EMAIL" //			
			,"ENC_DATA_LENGTH" //p
			,"ENCRYPTED_DATA" //p						

			};		

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//SMS 96 계좌출금 취소 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static int[] nlensSms96(){
		int nlensSms96[] = { 
			 5,5,4,4,1
			,8,6,10,14,6
			,2,40,4,100,100
			,3,6,40,10,8
			,10,5,VariousEncryptedData
			};
	
		return nlensSms96;
	};
	
	
//	static int nlensSms96[] = { 
//			 5,5,4,4,1
//			,8,6,10,14,6
//			,2,40,4,100,100
//			,3,6,40,10,8
//			,10,5,5000
//			};
	
	static final String strHeadersSms96[] = { 
			 "VERSION" //
			,"LENGTH" //
			,"INQ_CODE" //p
			,"WORK_CODE" //p
			,"SEND_FLAG" //p
			
			,"TRADE_DATE" //p			
			,"TRADE_TIME"//p
			,"MID"//		p				
			,"TERMINAL_ID" //p
			,"INQ_UNIQ_NO" //p

			,"SECURITY_YN" //p			
			,"MCH_SEND_UNIQ_NO"//p
			,"RESP_CODE"//						
			,"RESP_MSG" //
			,"FILLER"//p
			,"BANK_CD" //p
			
			,"ORG_INQ_UNIQ_NO" //p
			,"ORG_MCH_SEND_UNIQ_NO" //p
			,"ORG_TRADE_AMT" //p
			,"CANCLE_DATE" //
			,"CANCLE_AMT" //
			
			,"ENC_DATA_LENGTH" //p
			,"ENCRYPTED_DATA" //	p					
			
			};		
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//SMS 97 수수료 조회/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static int[] nlensSms97(){
		int nlensSms97[] = { 
				 5,5,4,4,1
				,8,6,10,14,6
				,2,40,4,100,100
				,3,10,8,5,VariousEncryptedData
				};
		return nlensSms97;
	};
	
//	static int nlensSms97[] = { 
//			 5,5,4,4,1
//			,8,6,10,14,6
//			,2,40,4,100,100
//			,3,10,8,5,5000
//			};
	
	static final String strHeadersSms97[] = { 
			 "VERSION" //
			,"LENGTH" //
			,"INQ_CODE" //p
			,"WORK_CODE" //p
			,"SEND_FLAG" //p
			
			,"TRADE_DATE" //p			
			,"TRADE_TIME"//p
			,"MID"//		p				
			,"TERMINAL_ID" //p
			,"INQ_UNIQ_NO" //p

			,"SECURITY_YN" //			
			,"MCH_SEND_UNIQ_NO"//
			,"RESP_CODE"//						
			,"RESP_MSG" //
			,"FILLER"	//
			,"BANK_CD" //
			
			,"TRADE_AMT" //
			,"COM_AMT"
			,"ENC_DATA_LENGTH" //
			,"ENCRYPTED_DATA" //						
			};		
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//SMS 98 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static int[] nlensSms98(){
		int nlensSms98[] = { 
			 5,5,4,4,1
			,8,6,10,14,6
			,2,40,4,100,100
			,3,5,VariousEncryptedData
			};
		return nlensSms98;
	};
	
//	static int nlensSms98[] = { 
//			 5,5,4,4,1
//			,8,6,10,14,6
//			,2,40,4,100,100
//			,3,5,5000
//			};
	
	static final String strHeadersSms98[] = { 
			 "VERSION" //
			,"LENGTH" //
			,"INQ_CODE" //
			,"WORK_CODE" //
			,"SEND_FLAG" //
			
			,"TRADE_DATE" //			
			,"TRADE_TIME"//
			,"MID"//						
			,"TERMINAL_ID" //
			,"INQ_UNIQ_NO" //

			,"SECURITY_YN" //			
			,"MCH_SEND_UNIQ_NO"//
			,"RESP_CODE"//						
			,"RESP_MSG" //	
			,"FILLER"//
			
			,"BANK_CD" //			
			,"ENC_DATA_LENGTH" //
			,"ENCRYPTED_DATA" //						
			};			
	
	////sms to hannet OR hannet to sms 
	public static int[] nlensSms3100(){
		int nlensSms3100[] = { 
			 5,5,4,4,1			
			 ,8,6,10,17,6			
			 ,40,3,200 ,41 //여기까지 공통부
			,13			
			,3,3,2,12,12			
			,12,12,12,12,12			
			,132,30,16,20,13
			,4,14,20//,20,10,100			
			,8,13,13,1,1			
			,12,148//22			
			};
		return nlensSms3100;
	};
	
	static final String strHeadersSms3100[] = { 
			 "VERSION" //
			,"DATA_SIZE" //
			,"MSG_CD" //
			,"JOB_CD" //			
			,"SENDRECV_FLAG" //
			
			,"POS_TRAN_YMD" //
			,"POS_TRAN_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"TERMINAL_SEQ" //
			
			,"MCH_ORDER_NO" //
			,"RSP_CD"
			,"RSP_MSG"
			,"FILLER"///////////////////////여기까지 공통부			
			,"MCH_SEND_UNIQ_NO" //여기부터 3100,4100
			
			,"ISS_BANK_CD" //
			,"BUY_BANK_CD" //			
			,"VAN_TYPE_CD" //
			,"PAY_AMT" //
			,"SERVICE_AMT" //
			
			,"VAT_AMT" //
			,"MCH_CHARGE_AMT" //
			,"ISSINS_CHARGE_AMT" //
			,"BUYINS_CHARGE_AMT" //
			,"VAN_CHARGE_AMT" //	
			
			,"ENC_INFO" //
			,"TRACK_INFO" //
			,"IC_CARD_SEQ" //			
			,"PRT_ACCOUNT_NO" //
			,"MCH_MANG_NO" 
			
			,"MEMB_JOB_CD"
			,"TEL_NO"
			,"MEMB_NM"
			//,"REPR_NM" 
			//,"BIZCO_NO" 
			//,"MEMB_ADDR"
			
			,"ORG_TRAN_YMD" //
			,"ORG_MCH_SEND_UNIQ_NO" //
			,"BUY_MCH_SEND_UNIQ_NO" //
			,"CARD_INFO_YN"
			,"CASHBAG_TRAN_YN" //
			
			,"CASHBAG_TRAN_AMT" //
			,"FILLER"									
			};

	public static int[] nlensSms4000(){
		int nlensSms4000[] = { 
			 5,5,4,4,1			
			 ,8,6,10,17,6			
			 ,40,3,200 ,41 //여기까지 공통부			
			,13
			,3,3,2,12,12			
			,12,12,12,12,12			
			,132,30,16,20,13
			,4,14,20//,20,10,100			
			,1,12,183//57			
			};
		return nlensSms4000;
	};
	
	

	
	static final String strHeadersSms4000[] = { 
			 "VERSION" //
			,"DATA_SIZE" //
			,"MSG_CD" //
			,"JOB_CD" //			
			,"SENDRECV_FLAG" //
			
			,"POS_TRAN_YMD" //
			,"POS_TRAN_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"TERMINAL_SEQ" //
			
			,"MCH_ORDER_NO" //
			,"RSP_CD"
			,"RSP_MSG"
			,"FILLER"///////////////////////여기까지 공통부	
			,"MCH_SEND_UNIQ_NO" //여기부터 4000
			
			,"ISS_BANK_CD" //
			,"BUY_BANK_CD" //			
			,"VAN_TYPE_CD" //
			,"PAY_AMT" //
			,"SERVICE_AMT" //
			
			,"VAT_AMT" //
			,"MCH_CHARGE_AMT" //
			,"ISSINS_CHARGE_AMT" //
			,"BUYINS_CHARGE_AMT" //
			,"VAN_CHARGE_AMT" //	
			
			,"ENC_INFO" //
			,"TRACK_INFO" //
			,"IC_CARD_SEQ" //			
			,"PRT_ACCOUNT_NO" //
			,"MCH_MANG_NO" 
			
			,"MEMB_JOB_CD"
			,"TEL_NO"
			,"MEMB_NM"
			//,"REPR_NM" 
			//,"BIZCO_NO" 
			//,"MEMB_ADDR"
			
			,"CASHBAG_TRAN_YN" //			
			,"CASHBAG_TRAN_AMT" //
			,"FILLER"									
			};
	
	public static int[] nlensSms4100(){
		int nlensSms4100[] = { 
			 5,5,4,4,1			
			 ,8,6,10,17,6			
			 ,40,3,200 ,41 //여기까지 공통부
			,13			
			,3,3,2,12,12			
			,12,12,12,12,12			
			,132,30,16,20,13
			,4,14,20//,20,10,100			
			,8,13,13,1,1			
			,12,148//22				
			};
		return nlensSms4100;
	};
	
	static final String strHeadersSms4100[] = { 
			 "VERSION" //
			,"DATA_SIZE" //
			,"MSG_CD" //
			,"JOB_CD" //			
			,"SENDRECV_FLAG" //
			
			,"POS_TRAN_YMD" //
			,"POS_TRAN_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"TERMINAL_SEQ" //
			
			,"MCH_ORDER_NO" //
			,"RSP_CD"
			,"RSP_MSG"
			,"FILLER"///////////////////////여기까지 공통부			
			,"MCH_SEND_UNIQ_NO" //여기부터 3100,4100
			
			,"ISS_BANK_CD" //
			,"BUY_BANK_CD" //			
			,"VAN_TYPE_CD" //
			,"PAY_AMT" //
			,"SERVICE_AMT" //
			
			,"VAT_AMT" //
			,"MCH_CHARGE_AMT" //
			,"ISSINS_CHARGE_AMT" //
			,"BUYINS_CHARGE_AMT" //
			,"VAN_CHARGE_AMT" //	
			
			,"ENC_INFO" //
			,"TRACK_INFO" //
			,"IC_CARD_SEQ" //			
			,"PRT_ACCOUNT_NO" //
			,"MCH_MANG_NO" 
			
			,"MEMB_JOB_CD"
			,"TEL_NO"
			,"MEMB_NM"
			//,"REPR_NM" 
			//,"BIZCO_NO" 
			//,"MEMB_ADDR"
			
			,"ORG_TRAN_YMD" //
			,"ORG_MCH_SEND_UNIQ_NO" //			
			,"BUY_MCH_SEND_UNIQ_NO" //
			,"CARD_INFO_YN"
			,"CASHBAG_TRAN_YN" //
			
			,"CASHBAG_TRAN_AMT" //
			,"FILLER"									
			};	
	
	
//	,"MCH_MANG_NO" //13
//	,"BUY_MCH_SEND_UNIQ_NO" //		13	
//	,"ORG_MCH_SEND_UNIQ_NO" //13
//	
//	,"ORG_TRAN_YMD" //8
//	,"ORG_POS_NO" //4
//	,"ORG_TRAN_NO" //4
	
	
	
	
	public static int[] nlensSms4200(){
		int nlensSms4200[] = { 
			 5,5,4,4,1			
			 ,8,6,10,17,6			
			 ,40,3,200 ,41 //여기까지 공통부
			,13			
			,3,3,2,12,12
			,12,12,12,12,132
			,30,16,20,13 ,4
			,14,20,13,195		
			};
		return nlensSms4200;
	};
	
	static final String strHeadersSms4200[] = { 
			 "VERSION" //
			,"DATA_SIZE" //
			,"MSG_CD" //
			,"JOB_CD" //			
			,"SENDRECV_FLAG" //
			
			,"POS_TRAN_YMD" //
			,"POS_TRAN_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"TERMINAL_SEQ" //
			
			,"MCH_ORDER_NO" //
			,"RSP_CD"
			,"RSP_MSG"
			,"FILLER"///////////////////////여기까지 공통부
			,"MCH_SEND_UNIQ_NO" //여기부터 4200
			
			,"ISS_BANK_CD" //
			,"BUY_BANK_CD" //			
			,"VAN_TYPE_CD" //
			,"PAY_AMT" //			
			,"ATM_CHARGE_AMT" //
			
			,"MCH_CHARGE_AMT" //new
			,"ISSINS_CHARGE_AMT" //new
			,"BUYINS_CHARGE_AMT" //new
			,"VAN_CHARGE_AMT" //new			
			,"ENC_INFO" //
			
			,"TRACK_INFO" //
			,"IC_CARD_SEQ" //			
			,"PRT_ACCOUNT_NO" //
			,"MCH_MANG_NO" 			
			,"MEMB_JOB_CD"
			
			,"TEL_NO"
			,"MEMB_NM"
			//,"REPR_NM" 
			//,"BIZCO_NO" 
			//,"MEMB_ADDR"
			
			,"BUY_AUTH_UNIQ_NO"
			,"FILLER"									
			};

	
	public static int[] nlensSms6100(){
		int nlensSms6100[] = { 
			 5,5,4,4,1			
			 ,8,6,10,17,6			
			 ,40,3,200 ,41 //여기까지 공통부
			,13			
			,3,3,2,12,12			
			,12,12,12,12,12			
			,132,30,16,20,13
			,4,14,20//,20,10,100			
			,8,13,1,12,162//36				
			};
		return nlensSms6100;
	};
	
	static final String strHeadersSms6100[] = { 
			 "VERSION" //
			,"DATA_SIZE" //
			,"MSG_CD" //
			,"JOB_CD" //			
			,"SENDRECV_FLAG" //
			
			,"POS_TRAN_YMD" //
			,"POS_TRAN_TIME" //
			,"MID" //
			,"TERMINAL_ID" //
			,"TERMINAL_SEQ" //
			
			,"MCH_ORDER_NO" //
			,"RSP_CD"
			,"RSP_MSG"
			,"FILLER"///////////////////////여기까지 공통부			
			,"MCH_SEND_UNIQ_NO" //여기부터 3100,4100
			
			,"ISS_BANK_CD" //
			,"BUY_BANK_CD" //			
			,"VAN_TYPE_CD" //
			,"PAY_AMT" //
			,"SERVICE_AMT" //
			
			,"VAT_AMT" //
			,"MCH_CHARGE_AMT" //
			,"ISSINS_CHARGE_AMT" //
			,"BUYINS_CHARGE_AMT" //
			,"VAN_CHARGE_AMT" //	
			
			,"ENC_INFO" //
			,"TRACK_INFO" //
			,"IC_CARD_SEQ" //			
			,"PRT_ACCOUNT_NO" //
			,"MCH_MANG_NO" 
			
			,"MEMB_JOB_CD"
			,"TEL_NO"
			,"MEMB_NM"
			//,"REPR_NM" 
			//,"BIZCO_NO" 
			//,"MEMB_ADDR"
			

			
			,"ORG_TRAN_YMD" //
			,"ORG_MCH_SEND_UNIQ_NO" //
			,"CASHBAG_TRAN_YN" //			
			,"CASHBAG_TRAN_AMT" //
			,"FILLER"			
			
			};	
	

	public static HashMap getParseDataGTF(int nlens[], String strHeaders[], String rcvBuf) {
		int bInx = 0;
		int eInx = 0;
		HashMap hm = new HashMap();

		eInx = nlens[0];
		for (int i = 0; i < nlens.length; i++) {

			hm.put(strHeaders[i].toString(), rcvBuf.substring(bInx, eInx));
			// logger.info( strHeaders[i].toString() + "==>(" + bInx +","+ eInx + ")" + rcvBuf.substring(bInx, eInx));
			if (i < nlens.length-1) {
				bInx = eInx;
				eInx = eInx + nlens[i + 1];
			}
		}

		return hm;
	}
	
	
	public static HashMap getParseDataGTF(int nlens[], String strHeaders[], String rcvBuf, int nlensGood[], String strHeadersGood[]) {
		int bInx = 0;
		int eInx = 0;
		HashMap hm = new HashMap();

		eInx = nlens[0];
		for (int i = 0; i < nlens.length; i++) {

			hm.put(strHeaders[i].toString(), rcvBuf.substring(bInx, eInx));
			// logger.info( strHeaders[i].toString() + "==>(" + bInx +","+ eInx + ")" + rcvBuf.substring(bInx, eInx));
			if (i < nlens.length) {
				if (i == nlens.length - 1) {
					bInx = eInx;
					eInx = eInx + nlensGood[0];
				} else {
					bInx = eInx;
					eInx = eInx + nlens[i + 1];
				}
			}
		}
		 int reCnt = Integer.parseInt((String)hm.get("SEQUENCE_COUNT"));
		for (int j = 0; j < reCnt ; j++) {
			// eInx = nlensGood[0];
			for (int k = 0; k < nlensGood.length; k++) {
				hm.put(makeGHKey(strHeadersGood[k].toString(), j), rcvBuf.substring(bInx, eInx));
				// logger.info( strHeadersGood[k].toString() + "==>(" + bInx +","+ eInx + ")" + rcvBuf.substring(bInx, eInx));
				if (k < nlensGood.length) {
					if (k == nlensGood.length - 1) {
						bInx = eInx;
						eInx = eInx + nlensGood[0];
					} else {
						bInx = eInx;
						eInx = eInx + nlensGood[k + 1];
					}
				}
			}
		}
		return hm;
	}
	


	
	public static HashMap getParseDataGTFMultibyte(int nlens[], String strHeaders[], String rcvBuf) {
		int bInx = 0;
		int eInx = 0;
		HashMap hm = new HashMap();

		eInx = nlens[0];
		for (int i = 0; i < nlens.length; i++) {

			hm.put(strHeaders[i].toString(), new String(rcvBuf.getBytes(), bInx, eInx - bInx));
			// logger.info( strHeaders[i].toString() + "==>(" + bInx +","+ eInx + ")" + new String(rcvBuf.getBytes(), bInx, eInx - bInx));
			if (i < nlens.length-1) {
				bInx = eInx;
				eInx = eInx + nlens[i + 1];
			}
		}

		return hm;
		
	}
	
	public static HashMap getParseDataGTFMultibyte(int nlens[], String strHeaders[], String rcvBuf, int nlensGood[], String strHeadersGood[]) {
		int bInx = 0;
		int eInx = 0;
		HashMap hm = new HashMap();

		eInx = nlens[0];
		for (int i = 0; i < nlens.length; i++) {

			hm.put(strHeaders[i].toString(), new String(rcvBuf.getBytes(), bInx, eInx - bInx));
			// logger.info( strHeaders[i].toString() + "==>(" + bInx +","+ eInx + ")" + new String(rcvBuf.getBytes(), bInx, eInx - bInx));
			if (i < nlens.length) {
				if (i == nlens.length - 1) {
					bInx = eInx;
					eInx = eInx + nlensGood[0];
				} else {
					bInx = eInx;
					eInx = eInx + nlens[i + 1];
				}
			}
		}
		 int reCnt = Integer.parseInt((String)hm.get("SEQUENCE_COUNT"));
		for (int j = 0; j < reCnt; j++) {
			// eInx = nlensGood[0];
			for (int k = 0; k < nlensGood.length; k++) {
				hm.put(makeGHKey(strHeadersGood[k].toString(), j), new String(rcvBuf.getBytes(), bInx, eInx - bInx));
				// logger.info( strHeadersGood[k].toString() + "==>(" + bInx +","+ eInx + ")" + new String(rcvBuf.getBytes(), bInx, eInx - bInx));
				if (k < nlensGood.length) {
					if (k == nlensGood.length - 1) {
						bInx = eInx;
						eInx = eInx + nlensGood[0];
					} else {
						bInx = eInx;
						eInx = eInx + nlensGood[k + 1];
					}
				}
			}
		}
		return hm;
	}
	
	
	public static String makeGHKey(String strCol, int nOfGood) {

		return String.format("%s_%d", strCol, nOfGood);

	}
	
	


	static Map<String, String> getMap(String key, String Val){
		Map<String, String> data  = new HashMap<String, String>();
		data.put(key, Val);
		return data;
		
	}
	
	
	static final Object[][] TRANDIVIDE_0097 = {
			{"ITEM_LEN",	5}, 
			{"TR_ITEM_ID",	2},
			{"TR_ITEM_SEQ",	3}, // 명세 순번
			
			{"EDI",						2},
			{"VERSION",					10},
			{"DOCUMENT_CD",				3},
			{"BUY_SERIAL_NUM",			20},
			{"BUYER_CANCLE_CHECK",		1},
			{"TRADE_APPROVAL_NUM",		10},
			{"SELLER_BUSI_REGIST_NUM",	10},
			{"TERMINAL_ID",				10},
			{"SELL_TIME",				14},
			{"SELL_SUM_TOTAL",			4},
			{"SELL_SUM_MONEY",			9},
			{"REFUND_AMOUNT",			8},
			{"PAYMENT_TYPE",			1},
			{"CREDIT_CARD_NUM",			21},
			{"KOR_DOMESTIC_CITIZEN",	1},
			{"KOR_IDENTITY",			13},
			{"PASSPORT_ENC_YN",			1},
			{"PASSPORT_NAME",			40},
			{"PASSPORT_NUM",			24},
			{"PASSPORT_NATION",			3},
			{"PASSPORT_SEX",			1},
			{"PASSPORT_BIRTH",			6},
			{"PASSPORT_EXPIRE",			6},
			{"RESPONSE_CD",				3},
			{"RESPONSE_MESSAGE",		60},
			{"SHOP_NAME",				40},
			{"SEQUENCE_COUNT",			4},
			{"EXPORT_EXPIRY_DATE",		8},
			{"RCT_NO",					30},
			{"BEFORE_REFUND_YN",		1},
			{"PAYMENT_AMOUNT",			9},
			{"EXPORT_APPROVAL_NUM",		30},
			{"BEFORE_LIMIT_AMOUNT",		10},
			{"EXTRA",					100},				
		};
	
	static final Object[][] TRANDIVIDE_0098 = {		
			{"COMMODITY_NUM",	3},
			{"SCT_DIV",			1},
			{"COMMODITY_CD",	2},
			{"COMMODITY_CONT",	50},
			{"VOLUME",			4},
			{"UNIT_PRICE",		9},
			{"SELL_PRICE",		9},
			{"VAT",				8},
			{"SCT",				8},
			{"ET",				8},
			{"FFVST",			8},
			{"EXTRA",			16}	
				
	};
		static int getLength(String defName){
			if("TRANDIVIDE_0098".equals(defName)) {
				return TRANDIVIDE_0098.length;
			}else if("TRANDIVIDE_0097".equals(defName)) {
				return TRANDIVIDE_0097.length;
			}else
				return 0;
		}
	

}





