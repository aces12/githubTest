package biz.cms_RailPlusSender;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_CashBeeSender.CashBeeSenderDAO;
import biz.cms_CashBeeSender.CashBeeSenderFileTransfer;
import biz.cms_TMoneySender.TMoneySenderFileTransfer;
import biz.cms_TMoneySender.TMoneySenderPollingAction;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

public class RailPlusSenderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(RailPlusSenderPollingAction.class);
	
	public static void main(String args[]) throws Exception {
		RailPlusSenderPollingAction action = new RailPlusSenderPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[1]]=" + args[1] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			if( cmd.length() != 3 ) return;
			
			if( cmd.charAt(0) == '1' ) {
				System.out.println("creating RailPlus Payment tran file.");
				action.createRailPlusPAYTranFile();
			}
			/*
			if( cmd.charAt(1) == '1' ) {
				System.out.println("creating RailPlus Charge tran file.");
				action.createRailPlusCHGTranFile();
			}
			*/
			
			if( cmd.charAt(1) == '1' ) {
				System.out.println("creating RailPlus Refund tran file.");
				action.createRailPlusREFTranFile();
			}
			
			if( cmd.charAt(2) == '1' ) {
				System.out.println("transfering RailPlus tran files.");
				(new RailPlusSenderFileTransfer()).transfer();
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		RailPlusSenderDAO dao = new RailPlusSenderDAO();
		List<Object> list = null;
		int totalCnt = 0;
		
		try {
			int ret = -1;
			
			// actionMode : 0-POLLING_PERIOD에 주기적으로 무조건 수행, 1-ACTION_TIME에 한 번 수행
			if( actionMode == "1" ) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String stdYmd = sdf.format(new Date());
				String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
				
				//(금일 대사파일 생성 유무 조회)
				list = dao.selSVCFILEDAILY(stdYmd, "RPS", "%", com_cd);
				totalCnt = list.size();
				
				//금일 대사파일 생성 row가 없으면 생성
				if( totalCnt <= 0 ) {
					HashMap<String, String> hm = new HashMap<String, String>();
					hm.put("COM_CD", com_cd);
					hm.put("STD_YMD", stdYmd);
					hm.put("SVC_ID", "RPS");
					hm.put("CMD_TY", "00");
					
					ret = dao.insSVCFILEINFO(hm);
						
					if( ret > 0 ) {
						createRailPlusREFTranFile();
						Thread.sleep(50);
						
						createRailPlusPAYTranFile();
						Thread.sleep(50);
						
						try {
							(new RailPlusSenderFileTransfer()).transfer();
						}catch(Exception e) {
							logger.info("[ERROR]" + e.getMessage());
						}
						hm.put("CMD_TY", "01");
						ret = dao.updSVCFILEINFO(hm);
					}
				}
			}else if( actionMode == "0") {
				
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	public boolean createRailPlusPAYTranFile() {
		boolean bIsCreatedFile = false;
		
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
//			List<Object> list2 = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			RailPlusSenderDAO dao = new RailPlusSenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			//String toDay = sdf.format(calendar.getTime());
			//calendar.setTime(sdf.parse(toDay));
			calendar.setTime(new Date());
			String curDate = sdf.format(calendar.getTime());
			calendar.add(Calendar.DATE, -1);
			String adjDate = sdf.format(calendar.getTime());
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "railplus";
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			
			list = dao.getWITHMEBizCoNo(com_cd);
			String strWithMeBizCoNo = (String)((Map<String, String>)list.get(0)).get("BIZCO_NO");
			
			// 전송 파일명 체계(파일명)
			// 지불청구        : KPP0.0.WM.YYMMDD.0001
			// 지불반송        : KPP1.0.WM.YYMMDD.0001
			// 충전대사내역 : KCR0.0.WM.YYMMDD.0001
			// 환불청구        : KC03.0.WM.YYMMDD.0001
			// 환불반송        : KA05.0.WM.YYMMDD.0001
			// 가맹점별온라인충전정산결과 : 미정
			// 가맹점별지불거래정산결과    : 미정
			
			String JOB_TP = "PP0";      // 업무구분(지불청구)
			String RECORD_LEN = "400";  // 레코드길이 고정 값
			String strTRANFileNM = "KPP0.0.WM." + curDate.substring(2, 8) + ".0001";
			
			list = null;
			list = dao.selRAILPLUSPAYRETTRAN(com_cd, 0, card_key, double_card_key);
			int iPayCnt = list.size();
			
//			list2 = dao.sumRAILPLUSPAYRETAMT(com_cd, 0);
//			String deal_tot_amt = String.format("%012d", Integer.parseInt(((String)((Map<String, String>)list2.get(0)).get("PPCARD_TOT_AMT").trim())));
			
			String strRPSFCSTR_ID = PropertyUtil.findProperty("service-property", "RAILPLUS_FCSTR_ID");  // 레일플러스 가맹점ID
			
			// 거래내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_LEN", RECORD_LEN);
			hmHeader.put("JOB_TP", JOB_TP);
			hmHeader.put("RECORD_TP", "H");
			hmHeader.put("FILE_CRTD_YMDHMS", curDate);
			hmHeader.put("ADJ_YMD", adjDate.substring(0, 8));
			hmHeader.put("TRANS_CNT", String.format("%05d", iPayCnt));
			hmHeader.put("TRANS_AMT", "000000000000");					// 계산 된 값을 나중에 넣어 줌
			hmHeader.put("FILLER", " ");
			hmHeader.put("NEWLN_CHAR", String.format("%1c", 13));
			
			sbFile.append(makeHeaderOfFile(hmHeader));
			
			int iTotDealAmt = 0;
			for(int i = 0;i < iPayCnt;i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				hmData.put("RECORD_LEN", RECORD_LEN);  								// 레코드 길이
				hmData.put("JOB_TP", JOB_TP);  										// 업무구분
				hmData.put("RECORD_TP", "D");  										// 레코드 구분
				hmData.put("SEQ_NO", String.format("%05d", i + 1));  				// 레코드 일련번호
				hmData.put("FCSTR_ID", strRPSFCSTR_ID);								// 가맹점ID(FCSTR_ID)
				hmData.put("TRAN_ID", map.get("TRAN_ID"));  						// TRANSACTION ID
				hmData.put("DEAL_BRANCH_CD", map.get("DEAL_BRANCH_CD"));  			// 거래지점
				hmData.put("DEAL_BRANCH_NM", map.get("STORE_NM"));  				// 거래지점명
				hmData.put("TMNAL_ID", map.get("TMNAL_ID"));  						// 단말기 번호
				hmData.put("TRAN_DTM", map.get("TRAN_DTM"));  						// 거래일시
				hmData.put("CARD_TP_VAL", map.get("CARD_TP_VAL"));  				// 교통카드 구분코드
				hmData.put("RAILPLUS_HOLDER_TP", map.get("RAILPLUS_HOLDER_TP"));  	// 교통카드사용자 구분코드
				hmData.put("PUBCO_ID", map.get("PUBCO_ID"));  						// 발행사 ID
				hmData.put("ORG_DEAL_AMT", "0000000000");							// 원거래금액
				hmData.put("PAYMENT_DIS_RATE", "0000");								// 지불할인율
				hmData.put("PAYMENT_DIS_AMT", "0000000000");						// 지불할인금액
				hmData.put("PPCARD_NO", map.get("PPCARD_NO"));  					// ID_EP(교통카드번호)
				hmData.put("PPCARD_TRAN_SEQ_NO", map.get("PPCARD_TRAN_SEQ_NO"));  	// NT_EP(카드거래일련번호)
				hmData.put("PPCARD_REQ_AMT", String.format( "%010d"
												    , Integer.parseInt(((String)map.get("PPCARD_REQ_AMT")).trim())));	// 거래금액(MPDA)
				hmData.put("PPCARD_PRE_REM_AMT", String.format( "%010d"
															  , Integer.parseInt(((String)map.get("PPCARD_PRE_REM_AMT")).trim())));	// BAL_EP_BEFORE(거래전 카드잔액)
				hmData.put("PPCARD_REM_AMT", String.format( "%010d"
														  , Integer.parseInt(((String)map.get("PPCARD_REM_AMT")).trim())));	// BAL_EP(거래후 카드잔액)
				hmData.put("TRAN_TP", map.get("TRAN_TP"));  						// TRT(거래유형)
				hmData.put("ALGO_ID", map.get("ALGO_ID"));  						// ALG_EP(알고리즘ID)
				hmData.put("KEYSET_VER", map.get("KEYSET_VER"));  					// VK_EP(키셋버전)
				hmData.put("ELE_MONY_IDTY", map.get("ELE_MONY_IDTY"));  			// ID_CENTER(전자화폐식별자)
				hmData.put("PSAM_ID", map.get("PSAM_ID"));  						// ID_SAM
				hmData.put("SAM_BEF_REM_AMT", "0000000000");						// BAL_SAM_BEFORE(거래전 SAM잔액)
				hmData.put("SAM_AFT_REM_AMT", "0000000000");						// BAL_SAM(거래후 SAM잔액)
				hmData.put("PSAM_TRAN_SEQ_NO", map.get("PSAM_TRAN_SEQ_NO"));  		// NT_SAM(SAM 거래일련번호)
				hmData.put("PSAM_TOT_AMT_COLECT_SEQ_NO", String.format( "%010d"
																	  , Integer.parseInt(((String)map.get("PSAM_TOT_AMT_COLECT_SEQ_NO")).trim())));	// NC_SAM(SAM 총액거래수집건수)
				hmData.put("PSAM_SPBY_COLECT_CNT", String.format( "%05d"
																, Integer.parseInt(((String)map.get("PSAM_SPBY_COLECT_CNT")).trim())));	// NI_SAM(SAM 개별거래수집건수)
				hmData.put("PSAM_ACCM_TOT_AMT", String.format( "%010d"
															 , Integer.parseInt(((String)map.get("PSAM_ACCM_TOT_AMT")).trim())));	// TOT_SAM(SAM 누적거래총액)
				hmData.put("SIGN_VAL_IND", map.get("SIGN_VAL_IND"));  				// SIGN_IND
				hmData.put("ALIAS_NO", map.get("ALIAS_NO"));  						// Alias 번호
				hmData.put("CARDPLSTS_YN", map.get("CARDPLSTS_YN"));  				// 지불승인TIMEOUT여부
				hmData.put("PAY_REFUND_FEE", "0000000000");  						// 지불수수료
				hmData.put("FILLER", " ");  										// Filler
				hmData.put("NEWLN_CHAR", String.format("%1c", 13));					// 개행문자
								
				sbFile.append(makeDataOfRailPlusPAYFile(hmData));
				
				iTotDealAmt = iTotDealAmt + Integer.parseInt(((String)map.get("PPCARD_REQ_AMT")).trim());
			}
			sbFile.replace(34, 46, String.format( "%012d", iTotDealAmt));
			
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			hmTailer.put("RECORD_LEN", RECORD_LEN);
			hmTailer.put("JOB_TP", JOB_TP);
			hmTailer.put("RECORD_TP", "T");
			hmTailer.put("FILLER", " ");
			hmTailer.put("NEWLN_CHAR", String.format("%1c", 13));
			
			sbFile.append(makeTailerOfRailPlusTranFile(hmTailer));
			
			// 거래내역 파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRANFileNM);
			
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRANFileNM);
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					dao.updRAILPLUSPAYTRAN("1", com_cd, (String)map.get("TRAN_ID"));
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
	
	public boolean createRailPlusCHGTranFile() {
		boolean bIsCreatedFile = false;
		
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			List<Object> list2 = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			RailPlusSenderDAO dao = new RailPlusSenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			//String toDay = sdf.format(calendar.getTime());
			//calendar.setTime(sdf.parse(toDay));
			calendar.setTime(new Date());
			String curDate = sdf.format(calendar.getTime());
			calendar.add(Calendar.DATE, -1);
			String adjDate = sdf.format(calendar.getTime());
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "railplus";
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			
			list = dao.getWITHMEBizCoNo(com_cd);
			String strWithMeBizCoNo = (String)((Map<String, String>)list.get(0)).get("BIZCO_NO");
			
			// 전송 파일명 체계(파일명)
			// 지불청구        : KPP0.0.WD.YYMMDD.0001
			// 지불반송        : KPP1.0.WD.YYMMDD.0001
			// 충전대사내역 : KCR0.0.WD.YYMMDD.0001
			// 환불청구        : KC03.0.WD.YYMMDD.0001
			// 환불반송        : KA05.0.WD.YYMMDD.0001
			// 가맹점별온라인충전정산결과 : 미정
			// 가맹점별지불거래정산결과    : 미정
			
			String JOB_TP = "CR0";      // 업무구분(충전대사내역)
			
			String strTRANFileNM = "K" + JOB_TP + ".0.WD" + curDate.substring(2, 8) + "0001";
			
			list = null;
			list = dao.selRAILPLUSCHGTRAN(com_cd, card_key, double_card_key);
			int iChgCnt = list.size();
			
			list2 = dao.selRAILPLUSCHGCNT(com_cd);
			
			String strRPSFCSTR_ID = PropertyUtil.findProperty("service-property", "RAILPLUS_FCSTR_ID");  // 레일플러스 가맹점ID
			
			Map<String, String> map2 = (Map<String, String>)list2.get(0);
			
			// 거래내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_TP", "H");
			hmHeader.put("TRANS_CNT", String.format("%07d", iChgCnt));			
			hmHeader.put("CHG_CNT", map2.get("CHG_CNT"));
			hmHeader.put("CHG_AMT", map2.get("CHG_AMT"));
			hmHeader.put("CHG_FEE", map2.get("CHG_FEE"));
			hmHeader.put("CNC_CNT", map2.get("CNC_CNT"));
			hmHeader.put("CNC_AMT", map2.get("CNC_AMT"));
			hmHeader.put("CNC_FEE", map2.get("CNC_FEE"));
			hmHeader.put("REF_CNT", map2.get("REF_CNT"));
			hmHeader.put("REF_AMT", map2.get("REF_AMT"));
			hmHeader.put("REF_FEE", map2.get("REF_FEE"));
			hmHeader.put("ADJ_YMD", adjDate.substring(0, 8));
			hmHeader.put("FILE_CRTD_YMDHMS", curDate);			
			hmHeader.put("FILLER", " ");
			hmHeader.put("NEWLN_CHAR", String.format("%1x", 0x0A));
			
			sbFile.append(makeHeaderOfFile2(hmHeader));
			
			for(int i = 0;i < iChgCnt;i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				hmData.put("RECORD_TP", "D");  // 레코드구분
				hmData.put("SEQ_NO", String.format("%07d", i + 1));  // 일련번호
				hmData.put("TRAN_ID", map.get("TRAN_ID"));  // 트랜잭션 ID
				hmData.put("FCSTR_ID", strRPSFCSTR_ID);// 가맹점ID(FCSTR_ID)
				hmData.put("DEAL_BRANCH_CD", map.get("DEAL_BRANCH_CD"));  // 거래지점코드
				//hmData.put("DEAL_BRANCH_NM", map.get("DEAL_BRANCH_NM"));  // 거래지점명
				hmData.put("TMNAL_ID", map.get("TMNAL_ID"));  // 단말기 ID 
				hmData.put("PPCARD_NO", map.get("PPCARD_NO"));  // 선불카드 ID
				hmData.put("CARD_HOLDER_TP", map.get("CARD_HOLDER_TP"));  // 교통카드사용자 구분코드
				hmData.put("CARD_STAT_VAL", map.get("CARD_STAT_VAL"));  // 카드상태코드
				hmData.put("DEAL_DTM", map.get("DEAL_DTM"));  // 충전 요청일시
				//hmData.put("", map.get(""));  // 완료전문전송일시
				hmData.put("CARD_TRAN_SEQ_NO", map.get("CARD_TRAN_SEQ_NO"));  // 카드거래일련번호
				hmData.put("RAILPLUS_WORK_ID", map.get("RAILPLUS_WORK_ID"));  // 작업구분
				hmData.put("", map.get(""));  // 충전일시
				hmData.put("PPCARD_PRE_REM_AMT", String.format("%010d", Integer.parseInt(((String)map.get("PPCARD_PRE_REM_AMT")).trim())));  // 충전 전 잔액
				hmData.put("PPCARD_REQ_AMT", String.format("%010d", Integer.parseInt(((String)map.get("PPCARD_REQ_AMT")).trim())));  // 충전 요청 금액
				hmData.put("PPCARD_REM_AMT", String.format("%010d", Integer.parseInt(((String)map.get("PPCARD_REM_AMT")).trim())));  // 충전 후 잔액
				hmData.put("FEE", String.format("%010d", Integer.parseInt(((String)map.get("FEE")).trim())));  // 충전 수수료
				hmData.put("", map.get(""));  // HSM상태
				hmData.put("", map.get(""));  // 작업결과
				//hmData.put("FCSTR_ID", "FCSTR_ID");// 레일플러스 가맹점ID(FCSTR_ID)
				hmData.put("FILLER", " ");
				hmData.put("NEWLN_CHAR", String.format("%1x", 0x0A));				
				
				sbFile.append(makeDataOfRailPlusCHGFile(hmData));
			}
			
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			hmTailer.put("RECORD_TP", "T");
			hmTailer.put("FILLER", " ");
			hmTailer.put("NEWLN_CHAR", String.format("%1x", 0x0A));
			
			sbFile.append(makeTailerOfRailPlusTranFile2(hmTailer));
			
			// 거래내역 파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRANFileNM);
			
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRANFileNM);
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					dao.updRAILPLUSCHGTRAN("1", (String)map.get("COM_CD"), (String)map.get("TRAN_ID"));
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
	
	public boolean createRailPlusREFTranFile() {
		boolean bIsCreatedFile = false;
		
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
//			List<Object> list2 = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			RailPlusSenderDAO dao = new RailPlusSenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			//String toDay = sdf.format(calendar.getTime());
			//calendar.setTime(sdf.parse(toDay));
			calendar.setTime(new Date());
			String curDate = sdf.format(calendar.getTime());
			calendar.add(Calendar.DATE, -1);
			String adjDate = sdf.format(calendar.getTime());
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "railplus";
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			
			list = dao.getWITHMEBizCoNo(com_cd);
			String strWithMeBizCoNo = (String)((Map<String, String>)list.get(0)).get("BIZCO_NO");
			
			// 전송 파일명 체계(파일명)
			// 지불청구        : KPP0.0.WM.YYMMDD.0001
			// 지불반송        : KPP1.0.WM.YYMMDD.0001
			// 충전대사내역 : KCR0.0.WM.YYMMDD.0001
			// 환불청구        : KC03.0.WM.YYMMDD.0001
			// 환불반송        : KA05.0.WM.YYMMDD.0001
			// 가맹점별온라인충전정산결과 : 미정
			// 가맹점별지불거래정산결과    : 미정
			
			String JOB_TP = "GR0";      // 업무구분(환불청구)
			String RECORD_LEN = "400";  // 레코드길이 고정 값
			String strTRANFileNM = "KC03.0.WM." + curDate.substring(2, 8) + ".0001";
			
			list = null;
			list = dao.selRAILPLUSPAYRETTRAN(com_cd, 1, card_key, double_card_key);
			int iPayCnt = list.size();
			
//			list2 = dao.sumRAILPLUSPAYRETAMT(com_cd, 1);
//			String deal_tot_amt = String.format("%012d", Integer.parseInt(((String)((Map<String, String>)list2.get(0)).get("PPCARD_TOT_AMT").trim())));
			
			String strRPSFCSTR_ID = PropertyUtil.findProperty("service-property", "RAILPLUS_FCSTR_ID");  // 레일플러스 가맹점ID
			
			// 거래내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_LEN", RECORD_LEN);
			hmHeader.put("JOB_TP", JOB_TP);
			hmHeader.put("RECORD_TP", "H");
			hmHeader.put("FCSTR_ID", strRPSFCSTR_ID);// 가맹점ID(FCSTR_ID)
			hmHeader.put("FILE_CRTD_YMDHMS", curDate);
			hmHeader.put("ADJ_YMD", adjDate.substring(0, 8));
			hmHeader.put("TRANS_CNT", String.format("%05d", iPayCnt));
			hmHeader.put("TRANS_AMT", "000000000000"); 					// 계산 된 값을 나중에 넣어 줌
			hmHeader.put("FILLER", " ");
			hmHeader.put("NEWLN_CHAR", String.format("%1c", 13));
			
			sbFile.append(makeHeaderOfFile3(hmHeader));
			
			int iTotDealAmt = 0;
			for(int i = 0;i < iPayCnt;i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				hmData.put("RECORD_LEN", RECORD_LEN);  								// 레코드 길이
				hmData.put("JOB_TP", JOB_TP);  										// 업무구분
				hmData.put("RECORD_TP", "D");  										// 레코드 구분
				hmData.put("SEQ_NO", String.format("%04d", i + 1));  				// 레코드 일련번호
				hmData.put("TRAN_ID", map.get("TRAN_ID"));  						// TRANSACTION ID
				hmData.put("DEAL_BRANCH_CD", map.get("DEAL_BRANCH_CD"));  			// 거래지점
				hmData.put("DEAL_BRANCH_NM", map.get("STORE_NM"));  				// 거래지점명
				hmData.put("TMNAL_ID", map.get("TMNAL_ID"));  						// 단말기ID
				hmData.put("TMNAL_TP", "02");										// 단말기구분
				hmData.put("TRAN_DTM", map.get("TRAN_DTM"));  						// 거래일시
				hmData.put("RAILPLUS_HOLDER_TP", map.get("RAILPLUS_HOLDER_TP"));  	// 교통카드사용자 구분코드
				hmData.put("CARD_TP_VAL", map.get("CARD_TP_VAL"));					// 교통카드 구분코드
				hmData.put("PPCARD_NO", map.get("PPCARD_NO"));  					// ID_EP(교통카드번호)
				hmData.put("PPCARD_TRAN_SEQ_NO", map.get("PPCARD_TRAN_SEQ_NO"));  	// NT_EP(카드거래일련번호)
				hmData.put("TRAN_TP", map.get("TRAN_TP"));  						// TRT(거래유형)
				hmData.put("REFUND_TP", "01");										// 환불유형
				hmData.put("PAY_AMT", String.format( "%010d", 
													 Integer.parseInt(((String)map.get("PPCARD_REQ_AMT")).trim())));	// 환불금액(MLDA)
				hmData.put("PPCARD_PRE_REM_AMT", map.get("PPCARD_PRE_REM_AMT"));  	// BAL_EP_BEFORE(거래전 카드잔액)
				hmData.put("PPCARD_REM_AMT", map.get("PPCARD_REM_AMT"));  			// BAL_EP(거래후 카드잔액)
				hmData.put("REFUND_FEE", map.get("REFUND_FEE"));					// 환불수수료
				hmData.put("ELE_MONY_IDTY", map.get("ELE_MONY_IDTY"));  			// ID_CENTER(전자화폐식별자)
				hmData.put("KEYSET_VER", map.get("KEYSET_VER"));  					// VK_EP(키셋버전)
				hmData.put("PSAM_ID", map.get("PSAM_ID"));  						// ID_SAM
				hmData.put("PSAM_TRAN_SEQ_NO", map.get("PSAM_TRAN_SEQ_NO"));  		// NT_SAM(SAM 거래일련번호)
				hmData.put("PSAM_TOT_AMT_COLECT_SEQ_NO", map.get("PSAM_TOT_AMT_COLECT_SEQ_NO"));	// SAM총액거래수집건수
				hmData.put("PSAM_SPBY_COLECT_CNT", map.get("PSAM_SPBY_COLECT_CNT"));// SAM개별거래수집건수
				hmData.put("PSAM_ACCM_TOT_AMT", map.get("PSAM_ACCM_TOT_AMT"));		// SAM누적거래총액
				hmData.put("SIGN_VAL_IND", map.get("SIGN_VAL_IND"));  				// SIGN_IND
				hmData.put("FILLER", " ");  										// Filler
				hmData.put("NEWLN_CHAR", String.format("%1c", 13));					// 개행문자
				
				sbFile.append(makeDataOfRailPlusREFFile(hmData));
				
				iTotDealAmt = iTotDealAmt + Integer.parseInt(((String)map.get("PPCARD_REQ_AMT")).trim());
			}
			sbFile.replace(42, 54, String.format( "%012d", iTotDealAmt));
			
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			hmTailer.put("RECORD_LEN", RECORD_LEN);
			hmTailer.put("JOB_TP", JOB_TP);
			hmTailer.put("RECORD_TP", "T");
			hmTailer.put("FILLER", " ");
			hmTailer.put("NEWLN_CHAR", String.format("%1c", 13));					// 개행문자
			
			sbFile.append(makeTailerOfRailPlusTranFile(hmTailer));
			
			// 거래내역 파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRANFileNM);
			
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRANFileNM);
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					dao.updRAILPLUSPAYTRAN("1", com_cd, (String)map.get("TRAN_ID"));
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
	
	private String makeHeaderOfFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {3,3,1,14,8
					  ,5,12,353,1};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",			
			"FILE_CRTD_YMDHMS",
			"ADJ_YMD",
			
			"TRANS_CNT",
			"TRANS_AMT",
			"FILLER",
			"NEWLN_CHAR"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {	
			logger.info(strHeaders[i].toString() + "=" + hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeHeaderOfFile2(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,7,7,13,10
					  ,7,13,10,7,13
					  ,10,8,14,179,1};
		String strHeaders[] = {
			"RECORD_TP",
			"TRANS_CNT",
			"CHG_CNT",			
			"CHG_AMT",
			"CHG_FEE",
			
			"CNC_CNT",
			"CNC_AMT",
			"CNC_FEE",
			"REF_CNT",
			"REF_AMT",
			
			"REF_FEE",
			"ADJ_YMD",
			"FILE_CRTD_YMDHMS",
			"FILLER",
			"NEWLN_CHAR"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeHeaderOfFile3(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {3,3,1,8,14
					  ,8,5,12,345,1};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",
			"FCSTR_ID",			
			"FILE_CRTD_YMDHMS",
			
			"ADJ_YMD",			
			"TRANS_CNT",
			"TRANS_AMT",
			"FILLER",
			"NEWLN_CHAR"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeDataOfRailPlusPAYFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {3,3,1,5,8
					  ,20,10,40,10,14
					  ,1,2,7,10,4
					  ,10,20,10,10,10
					  ,10,3,3,3,3
					  ,16,10,10,10,10
					  ,5,10,8,10,1
					  ,10,79,1};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",
			"SEQ_NO",
			"FCSTR_ID", 
			
			"TRAN_ID",
			"DEAL_BRANCH_CD",
			"DEAL_BRANCH_NM",
			"TMNAL_ID",
			"TRAN_DTM",
			
			"CARD_TP_VAL",
			"RAILPLUS_HOLDER_TP",
			"PUBCO_ID",
			"ORG_DEAL_AMT", 
			"PAYMENT_DIS_RATE", 
			
			"PAYMENT_DIS_AMT",  
			"PPCARD_NO",  
			"PPCARD_TRAN_SEQ_NO",  
			"PPCARD_REQ_AMT",  
			"PPCARD_PRE_REM_AMT",  
			
			"PPCARD_REM_AMT",  
			"TRAN_TP",
			"ALGO_ID",
			"KEYSET_VER",
			"ELE_MONY_IDTY", 
			
			"PSAM_ID",
			"SAM_BEF_REM_AMT",
			"SAM_AFT_REM_AMT",
			"PSAM_TRAN_SEQ_NO",
			"PSAM_TOT_AMT_COLECT_SEQ_NO",
			
			"PSAM_SPBY_COLECT_CNT",
			"PSAM_ACCM_TOT_AMT",
			"SIGN_VAL_IND",
			"ALIAS_NO",
			"CARDPLSTS_YN",
			
			"PAY_REFUND_FEE",	
			"FILLER",
			"NEWLN_CHAR"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			logger.info(strHeaders[i].toString() + "=" + hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeDataOfRailPlusCHGFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,7,20,7,10
					  ,40,10,16,2,4
					  ,14,14,10,3,14
					  ,10,10,10,10,1
					  ,2,8,76,1};
		String strHeaders[] = {
			"RECORD_TP",
			"SEQ_NO",
			"TRAN_ID",
			"FCSTR_ID",
			"DEAL_BRANCH_CD",
			
			"DEAL_BRANCH_NM",			
			"TMNAL_ID",
			"PPCARD_NO",
			"CARD_HOLDER_TP",
			"CARD_STAT_VAL",
			
			"DEAL_DTM",			
			"",  // 완료전문전송일시
			"CARD_TRAN_SEQ_NO",
			"RAILPLUS_WORK_ID",
			"",  // 충전일시
			
			"PPCARD_PRE_REM_AMT",
			"PPCARD_REQ_AMT",
			"PPCARD_REM_AMT",
			"FEE",
			"",  // HSM상태
			
			"",  // 작업결과
			"",  // 레일플러스 가맹점ID(FCSTR_ID)
			"FILLER",
			"NEWLN_CHAR"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			System.out.println(strHeaders[i].toString()+"="+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeDataOfRailPlusREFFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {3,3,1,4,20
					  ,10,40,10,2,14
					  ,2,1,20,10,3
					  ,2,10,10,10,10
					  ,3,3,16,10,10
					  ,5,10,8,149,1};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",
			"SEQ_NO",
			"TRAN_ID",
			
			"DEAL_BRANCH_CD",
			"DEAL_BRANCH_NM",  				// 확인필요
			"TMNAL_ID",
			"TMNAL_TP",  					// 단말기구분			
			"TRAN_DTM",
			
			"RAILPLUS_HOLDER_TP",			// 교통카드 사용자 구분코드
			"CARD_TP_VAL",					// 교통카드 구분코드
			"PPCARD_NO",  					// ID_EP(교통카드번호)
			"PPCARD_TRAN_SEQ_NO",  			// NT_EP(카드거래일련번호)
			"TRAN_TP",  					// TRT(거래유형)
			
			"REFUND_TP",  					// 환불유형
			"PAY_AMT",  					// 환불금액(MLDA)			
			"PPCARD_PRE_REM_AMT",  			// BAL_EP_BEFORE(거래전 카드잔액)			
			"PPCARD_REM_AMT",  				// BAL_EP(거래후 카드잔액)
			"REFUND_FEE",					// 환불수수료
			
			"ELE_MONY_IDTY",  				// ID_CENTER(전자화폐식별자)			
			"KEYSET_VER",  					// VK_EP(키셋버전)
			"PSAM_ID",  					// ID_SAM
			"PSAM_TRAN_SEQ_NO",  			// NT_SAM(SAM 거래일련번호)
			"PSAM_TOT_AMT_COLECT_SEQ_NO",	// SAM총액거래수집건수
			
			"PSAM_SPBY_COLECT_CNT",			// SAM개별거래수집건수
			"PSAM_ACCM_TOT_AMT",			// SAM누적거래총액			
			"SIGN_VAL_IND",  				// SIGN_IND
			"FILLER",
			"NEWLN_CHAR"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeTailerOfRailPlusTranFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {3,3,1,392,1};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",
			"FILLER",
			"NEWLN_CHAR"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			System.out.println(strHeaders[i].toString()+"="+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeTailerOfRailPlusTranFile2(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,298,1};
		String strHeaders[] = {
			"RECORD_TP",
			"FILLER",
			"NEWLN_CHAR"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			System.out.println(strHeaders[i].toString()+"="+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
}
