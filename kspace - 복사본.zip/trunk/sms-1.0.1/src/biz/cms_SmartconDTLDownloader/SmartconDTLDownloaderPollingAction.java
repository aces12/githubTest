
///////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////SFTP 일경우////////////////////////////////////////////// 
///////////////////////////////////////////////////////////////////////////////////////////////////////
package biz.cms_SmartconDTLDownloader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;
import biz.comm.SFTPManager;


/** 
 * SMARTCONDTLDownloaderPollingAction
 * SMARTCON 일별승인내역 수신			 
 * @created  on 1.0, 
 * @created  by lsh 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by 
 */ 
public class SmartconDTLDownloaderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(SmartconDTLDownloaderPollingAction.class);
	
	private String smartcon_ftp_ip = "";
	private int smartcon_ftp_port = 0;
	private String smartcon_ftp_id = "";
	private String smartcon_ftp_pwd = "";
	String curActionMode = "T";
	static String curActionDate = "-1";
	
	public static void main(String args[]) throws Exception {	
		SmartconDTLDownloaderPollingAction action = new SmartconDTLDownloaderPollingAction();
		if (args == null || args.length < 1) {
			logger.info("------ master main args null");
		}
		System.out.println("[DEBUG] [args[0]]=" + args[0] );
		System.out.println("[DEBUG] [args[1]]=" + args[1] );
		
		String path          = nvl(args[0].replaceFirst("-path:",""));
		String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));		
		String date = ""; 
		if(args.length ==3 ){
			date = nvl(args[2].replaceFirst("-date:" , ""));
			curActionDate = date;
		}
		

		System.out.println("[DEBUG] [cmd.charAt(0)]=" + cmd.charAt(0) );
		System.out.println("[DEBUG] [cmd.charAt(1)]=" + cmd.charAt(1) );			
		System.out.println("[DEBUG] [args.length]=" + args.length);		
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		
		System.out.println("locator=true"  );
		
		if( cmd.length() != 2 ) return;
		
		System.out.println("cmd.length() is 2"  );
		
		if( cmd.charAt(0) == '1' ) {
			System.out.println("downloading file + inserting DB" );
			action.execute("1");
		}
		if( cmd.charAt(1) == '1' ) {
			System.out.println("inserting DB" );
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "smartcon";
			SmartconDTLDownloaderInst dailyInsert = new SmartconDTLDownloaderInst(destPath);
			dailyInsert.start();
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(String actionMode) {
		SFTPManager sFtpMgr = null;
		
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK = false;
		String FileNm = ""; //FileNm = targetFileNm;
		
		try {
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode != "1" ) return;

			this.smartcon_ftp_ip = PropertyUtil.findProperty("communication-property", "SMARTCON_FTP_SERVER_IP");
			this.smartcon_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SMARTCON_FTP_SERVER_PORT"));
			this.smartcon_ftp_id = PropertyUtil.findProperty("communication-property", "SMARTCON_FTP_SERVER_ID");
			this.smartcon_ftp_pwd = PropertyUtil.findProperty("communication-property", "SMARTCON_FTP_SERVER_PWD");	
			
			try{				
				sFtpMgr = new SFTPManager(smartcon_ftp_ip, smartcon_ftp_port, smartcon_ftp_id, smartcon_ftp_pwd);	
				logger.info("TRY Connected to " + smartcon_ftp_ip + ":" + smartcon_ftp_port);
			}catch(Exception e){
				logger.info("exception occur"+e.getMessage());
				logger.info(" SFTP Connect fail exception occur ");
				return;
			}					
			logger.info(" SFTP Connection is Success ");						
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "smartcon";//"";
			
			File destDir = new File(destPath);
			
			if( !destDir.exists() ) {
				destDir.mkdir();
				logger.info("[DEBUG] Try to make dir" );
			}
			isDownOK = false;

			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

			calendar.setTime(new Date());
			calendar.add(Calendar.DATE, -1);
			String stdDate = sdf.format(calendar.getTime());
			String targetFileNm ="";
			
			if(curActionDate != "-1")
				targetFileNm = "SMARTCON_WITHME_" + curActionDate + ".DAT";
			else
				targetFileNm = "SMARTCON_WITHME_" + stdDate + ".DAT";
			
			FileNm = targetFileNm; //exception 발생시 FileNm변수 활용
									
			iRetry = 0;			
			bos = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + targetFileNm));
			
			sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "summary"); // 경로변경(현재경로+summary폴더)
			while( iRetry < 2 ) {				
				if( isDownOK = sFtpMgr.get(targetFileNm, bos)) {		
					break;
				}
				iRetry++;
			}
			bos.flush();
			bos.close();
			bos = null;
			System.gc();
			
			if( isDownOK ) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm + "]");
				// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
				if( sFtpMgr.rename(targetFileNm, targetFileNm.concat(".ok")) ) {
					logger.info("[DEBUG] Succeeded to rename.");
					
					File file = new File(destPath + File.separator + targetFileNm);
					File fileOK = new File(destPath + File.separator + targetFileNm.concat(".ok"));
					file.renameTo(fileOK);//다운로드 완료시 파일명에 .ok 추가
				}else {
					logger.info("[DEBUG] Failed to rename.");	
				}
			}else {
				logger.info("[ERROR4] Can't get " + targetFileNm + " from FTP server");
									
				File file = new File(destPath + File.separator + targetFileNm);
				if( !file.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm + "]");
				}				
				logger.info("[ERROR2] Can't get file on FTP server");
			}		
			// 파일 읽어서 DB Insert
			SmartconDTLDownloaderInst dailyInsert = new SmartconDTLDownloaderInst(destPath);
			dailyInsert.start();				

		}catch(Exception e) {
			
			if(!isDownOK)//예외 발생시 !isDownOK삭제(ACTION_TIME 다중 발생시 생성되는 0byte파일 삭제)
			{
				File file = new File(destPath + File.separator + FileNm);
				if( !file.delete() ) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm + "]");
				}				
				logger.info("[ERROR] Exception, delete file: "+FileNm);
			}
			
			logger.info(e.getMessage());
		}finally {
			if( bos != null ) {
				try {
					bos.close();
					bos = null;
				}catch(Exception e) {}
			}
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {
			}
		}
	}
	
	
}



















