package biz.cms_CashBackDTLDownloader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import biz.comm.SFTPManager;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

public class CashBackDTLDownloaderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(CashBackDTLDownloaderPollingAction.class);
	
	private String cashBack_ftp_ip = "";
	private int cashBack_ftp_port = 0;
	private String cashBack_ftp_id = "";
	private String cashBack_ftp_pwd = "";
	
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		CashBackDTLDownloaderPollingAction action = new CashBackDTLDownloaderPollingAction();
		
		if(args == null || args.length < 1) {
			logger.info("------ master main args null");
		}
		
		System.out.println("[DEBUG] [args[0]]=" + args[0] );
		
		String path = nvl(args[0].replaceFirst("-path:"  ,""));
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		
		action.execute("1");

	}
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		SFTPManager sFtpMgr = null;
		
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK = false;
		String FileNm = ""; //FileNm = targetFileNm;
		
		try {
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode != "1" ) return;
			
			this.cashBack_ftp_ip = PropertyUtil.findProperty("communication-property", "CASHBACK_FTP_SERVER_IP");
			this.cashBack_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CASHBACK_FTP_SERVER_PORT"));
			this.cashBack_ftp_id = PropertyUtil.findProperty("communication-property", "CASHBACK_FTP_SERVER_ID");
			this.cashBack_ftp_pwd = PropertyUtil.findProperty("communication-property", "CASHBACK_FTP_SERVER_PWD");
			
			//로컬 테스트용	start
//			try {
//				
//				File testXml = new File("C:/CMBO/workspace/sms-1.0.1/xml/communication-property.xml");
//				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
//				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
//				Document document = documentBuilder.parse(testXml);
//				// normalize text representation
//				document.getDocumentElement ().normalize ();
//				System.out.println ("Root element of the doc is " + document.getDocumentElement().getNodeName());
//				
//				NodeList listOfPersons = document.getElementsByTagName("property");
//				int totalPersons = listOfPersons.getLength();
//				System.out.println("Total no of people : " + totalPersons);
//				
//				for(int s=0; s<listOfPersons.getLength() ; s++){
//	
//					Node firstPersonNode = listOfPersons.item(s);
//					Element firstPersonElement = (Element)firstPersonNode; 
//
//					if(firstPersonElement.getAttributes().item(0).getTextContent().equals("CASHBACK_FTP_SERVER_IP")) {
//						
//						cashBack_ftp_ip = firstPersonElement.getTextContent().trim();
//					}
//					if(firstPersonElement.getAttributes().item(0).getTextContent().equals("CASHBACK_FTP_SERVER_PORT")) {
//						
//						cashBack_ftp_port = Integer.parseInt(firstPersonElement.getTextContent().trim());
//					}
//					if(firstPersonElement.getAttributes().item(0).getTextContent().equals("CASHBACK_FTP_SERVER_ID")) {
//						
//						cashBack_ftp_id = firstPersonElement.getTextContent().trim();
//					}
//					if(firstPersonElement.getAttributes().item(0).getTextContent().equals("CASHBACK_FTP_SERVER_PWD")) {
//						
//						cashBack_ftp_pwd = firstPersonElement.getTextContent().trim();
//					}
//				}
//				
//			}catch (SAXParseException err) {
//				System.out.println ("** Parsing error" + ", line " + err.getLineNumber () + ", uri " + err.getSystemId ());
//				System.out.println(" " + err.getMessage ());
//
//			}catch (SAXException e) {
//				Exception x = e.getException ();
//				((x == null) ? e : x).printStackTrace ();
//
//			}catch (Throwable t) {
//				t.printStackTrace ();
//			}
//			
//			System.out.println("cashBack_ftp_ip : " + cashBack_ftp_ip);
//			System.out.println("cashBack_ftp_port : " + cashBack_ftp_port);
//			System.out.println("cashBack_ftp_id : " + cashBack_ftp_id);
//			System.out.println("cashBack_ftp_pwd : " + cashBack_ftp_pwd);
			
			
//			this.cashBack_ftp_ip = "202.3.22.13";
//			this.cashBack_ftp_port = 1500;
//			this.cashBack_ftp_id = "hannet";
//			this.cashBack_ftp_pwd = "with!21me";
//		//임시 테스트서버 GTF_FTP_SERVER_IP taxfree/taxfree!2#
////		this.cashBack_ftp_ip = PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_IP");
////		this.cashBack_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_PORT"));
////		this.cashBack_ftp_id = PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_ID");
////		this.cashBack_ftp_pwd = PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_PWD");
			//로컬 테스트용	end

			try{
				//logger.info("TRY Connected to " + cashBack_ftp_ip + ":" + cashBack_ftp_port  + ":" + cashBack_ftp_id + ":" + cashBack_ftp_pwd);
				sFtpMgr = new SFTPManager(cashBack_ftp_ip, cashBack_ftp_port, cashBack_ftp_id, cashBack_ftp_pwd);	
				
			}catch(Exception e){
				logger.info("exception occur : "+e.getMessage());
				logger.info(" SFTP Connect fail exception occur ");
				return;
			}					
			logger.info(" SFTP Connection is Success ");						
			
			//로컬테스트
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			//basePath = "D:";	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "hannet";
			
			File destDir = new File(destPath);
			
			if( !destDir.exists() ) {
				
				try {
				
					destDir.mkdir();	
				} catch (Exception ee) {
					// TODO: handle exception
					ee.getStackTrace();
				}
				
				logger.info("[DEBUG] Try to make dir" );
			}
			isDownOK = false;

			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

			calendar.setTime(new Date());
			calendar.add(Calendar.DATE, -1);
			String stdDate = sdf.format(calendar.getTime());
			String targetFileNm ="";
			
			targetFileNm = "CASHBACK_WITHME_" + stdDate + ".dat";
			
			FileNm = targetFileNm; //exception 발생시 FileNm변수 활용
									
			iRetry = 0;			
			bos = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + targetFileNm));
			
			//sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "summary"); // 경로변경(현재경로+summary폴더)
			while( iRetry < 2 ) {				
				if( isDownOK = sFtpMgr.get(targetFileNm, bos)) {		
					break;
				}
				iRetry++;
			}
			bos.flush();
			bos.close();
			bos = null;
			System.gc();
			
			if( isDownOK ) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm + "]");
				// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
				if( sFtpMgr.rename(targetFileNm, targetFileNm.concat(".ok")) ) {
					logger.info("[DEBUG] Succeeded to rename.");
					
					File file = new File(destPath + File.separator + targetFileNm);
					File fileOK = new File(destPath + File.separator + targetFileNm.concat(".ok"));
					file.renameTo(fileOK);//다운로드 완료시 파일명에 .ok 추가
				}else {
					logger.info("[DEBUG] Failed to rename.");	
				}
			}else {
				logger.info("[ERROR4] Can't get " + targetFileNm + " from FTP server");
									
				File file = new File(destPath + File.separator + targetFileNm);
				if( !file.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm + "]");
				}				
				logger.info("[ERROR2] Can't get file on FTP server");
			}		
			//파일 읽어서 DB Insert
			CashBackDownloaderInst dailyInsert = new CashBackDownloaderInst(destPath);
			dailyInsert.start();	

		}catch(Exception e) {
			
			if(!isDownOK)//예외 발생시 !isDownOK삭제(ACTION_TIME 다중 발생시 생성되는 0byte파일 삭제)
			{
				File file = new File(destPath + File.separator + FileNm);
				if( !file.delete() ) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm + "]");
				}				
				//logger.info("[ERROR] Exception, delete file: "+FileNm);
			}
			
			logger.info(e.getMessage());
		}finally {
			if( bos != null ) {
				try {
					bos.close();
					bos = null;
				}catch(Exception e) {}
			}
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {
			}
		}
	}

	private static String nvl(String param) {
		// TODO Auto-generated method stub
		return param != null ? param: "";
	}

}
