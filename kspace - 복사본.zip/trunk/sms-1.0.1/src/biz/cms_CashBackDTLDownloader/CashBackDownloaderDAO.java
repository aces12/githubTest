package biz.cms_CashBackDTLDownloader;

import java.io.File;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class CashBackDownloaderDAO extends GenericDAO{
private static Logger logger = Logger.getLogger(CashBackDownloaderDAO.class);
	
	
	public int  insCashBackDailyDTL    (Map<String, String> map) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			

			sql.put(findQuery("service-sql", "INS_CASHBACKVENDAILY_TRN"));			
			//로컬 테스트용	start
//			try {
//				
//				File testXml = new File("C:/CMBO/workspace/sms-1.0.1/xml/service-sql.xml");
//				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
//				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
//				Document document = documentBuilder.parse(testXml);
//				// normalize text representation
//				document.getDocumentElement ().normalize ();
//				//System.out.println ("Root element of the doc is " + document.getDocumentElement().getNodeName());
//				
//				NodeList listOfPersons = document.getElementsByTagName("query");
//				int totalPersons = listOfPersons.getLength();
//				//System.out.println("Total no of people : " + totalPersons);
//				
//				for(int s=0; s<listOfPersons.getLength() ; s++){
//	
//					Node firstPersonNode = listOfPersons.item(s);
//					Element firstPersonElement = (Element)firstPersonNode; 
//
//					if(firstPersonElement.getAttributes().item(0).getTextContent().equals("INS_CASHBACKVENDAILY_TRN")) {
//						
//						sql.put(firstPersonElement.getTextContent().trim());
//					}
//				}
//				
//				System.out.println("sql : " + sql.toString());
//				
//			}catch (SAXParseException err) {
//				System.out.println ("** Parsing error" + ", line " + err.getLineNumber () + ", uri " + err.getSystemId ());
//				System.out.println(" " + err.getMessage ());
//
//			}catch (SAXException e) {
//				Exception x = e.getException ();
//				((x == null) ? e : x).printStackTrace ();
//
//			}catch (Throwable t) {
//				t.printStackTrace ();
//			}
			//로컬 테스트용	send
			
			sql.setString(++i, (String)map.get("TRAN_YMD"));			//거래날짜
			sql.setString(++i, (String)map.get("STORE_CODE"));			//점포코드
			sql.setString(++i, (String)map.get("POS_NO"));				//포스번호
			sql.setString(++i, (String)map.get("TRAN_NO"));				//거래번호
			sql.setString(++i, (String)map.get("TRAN_SEQ"));			//거래순번
			
			sql.setString(++i, (String)map.get("MID"));					//가맹점ID
			sql.setString(++i, (String)map.get("TRAN_DIV"));			//거래구분'0'캐시백출금
			sql.setString(++i, (String)map.get("MCH_SEND_UNIQ_NO"));	//가맹점 주문번호
			sql.setString(++i, (String)map.get("TERMINAL_ID"));			//터미널아이디
			sql.setString(++i, (String)map.get("TRANS_ID"));			//청호PG거래번호
			sql.setString(++i, (String)map.get("TRAN_AMT"));			//거래금액
			
			sql.setString(++i, (String)map.get("ADMIT_NO"));			//승인번호		
			sql.setString(++i, (String)map.get("BANK_CD"));				//거래은행코드
			sql.setString(++i, (String)map.get("TRAN_TYPE"));			//'0' 승인 '1' 취소
			sql.setString(++i, (String)map.get("ADMIT_DATE"));			//승인일자
			sql.setString(++i, (String)map.get("CANCLE_DATE"));			//취소일자	
			
			sql.setString(++i, (String)map.get("FEE"));					//수수료
			sql.setString(++i, (String)map.get("INQ_UNIQ_NO")); 		//단말전문 일련번호
			sql.setString(++i, (String)map.get("CONFIRM_YN"));			//확정유무 Y 확정, N미확정
			
			logger.info("[SQL1][INS_CASHBACKVENDAILY_TRN]" + sql.debug() );
			System.out.println("[SQL1][INS_CASHBACKVENDAILY_TRN]" + sql.debug() );
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			logger.info("[ERROR1] " + e.getMessage());
			System.out.println("[ERROR1] " + e.getMessage());
			rollback();
			
		}finally {
			//transaction 종료
			end();
		}
		
		return rows;
	}
}
