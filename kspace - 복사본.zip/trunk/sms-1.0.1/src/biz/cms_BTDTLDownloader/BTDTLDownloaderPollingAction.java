package biz.cms_BTDTLDownloader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.SFTPManager;

/** 
 * BTDTLDownloaderPollingAction
 * 바통(다날) 일별승인내역 수신
 * @created  on 1.0,  11/03/17
 * @created  by khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by 
 */ 
public class BTDTLDownloaderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(BTDTLDownloaderPollingAction.class);
	
	private String bt_ftp_ip = "";
	private int bt_ftp_port = 0;
	private String bt_ftp_id = "";
	private String bt_ftp_pwd = "";
	
	public static void main(String args[]) throws Exception {
		BTDTLDownloaderPollingAction action = new BTDTLDownloaderPollingAction();
		if( args == null || args.length < 1 ) {
			logger.info("------ master main args null");
		}
		System.out.println("[DEBUG] [args[0]]=" + args[0] );
		
		String path          = nvl(args[0].replaceFirst("-path:"  ,""));
		String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		
		if( cmd.length() != 2 ) return;
		
		if( cmd.charAt(0) == '1' ) {
			System.out.println("downloading file + inserting DB" );
			action.execute("1");
		}
		if( cmd.charAt(1) == '1' ) {
			System.out.println("inserting DB" );
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "bartong";
			BTDTLDownloaderInst dailyInsert = new BTDTLDownloaderInst(destPath);
			dailyInsert.start();
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(String actionMode) {
		SFTPManager sFtpMgr = null;
		
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK = false;
		
		try {
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode != "1" ) return;
			
			this.bt_ftp_ip = PropertyUtil.findProperty("communication-property", "BT_FTP_SERVER_IP");
			this.bt_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "BT_FTP_SERVER_PORT"));
			this.bt_ftp_id = PropertyUtil.findProperty("communication-property", "BT_FTP_SERVER_ID");
			this.bt_ftp_pwd = PropertyUtil.findProperty("communication-property", "BT_FTP_SERVER_PWD");
			
			sFtpMgr = new SFTPManager(bt_ftp_ip, bt_ftp_port, bt_ftp_id, bt_ftp_pwd);
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "bartong";
			
			File destDir = new File(destPath);
			if( !destDir.exists() ) {
				destDir.mkdir();
			}
			
			isDownOK = false;
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			calendar.add(Calendar.DATE, -1);
			String stdDate = sdf.format(calendar.getTime());
			
			String targetFileNM = "bartong_" + stdDate + ".txt";
			iRetry = 0;
			bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + targetFileNM));
			
			while( iRetry < 2 ) {
				if( isDownOK = sFtpMgr.get(targetFileNM, bos)) {
					break;
				}
				iRetry++;
			}
			
			bos.flush();
			bos.close();
			bos = null;
			System.gc();
			
// 바통 파일 서버 오류로 임시로 22번포로 통신 ==> 쓰기 권한 부여는 불가능 하여 해당 부분 주석 -- 2016.06.23 oht
//			if( isDownOK ) {
//				logger.info("[DEBUG] successfuly downloaded file [" + targetFileNM + "]");
//				// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
//				if( sFtpMgr.rename(targetFileNM, targetFileNM.concat(".ok")) ) {
//					logger.info("[DEBUG] Succeeded to rename.");
//				}else {
//					logger.info("[DEBUG] Failed to rename.");
//				}
//			}else {
//				File file = new File(destPath + File.separator + targetFileNM);
//				if( !file.delete() ) {
//					logger.info("[ERROR1] Failed to delete empty file [" + targetFileNM + "]");
//				}
//				logger.info("[ERROR2] Can't get file on FTP server");
//			}
			
			// 파일 읽어서 DB Insert
			BTDTLDownloaderInst dailyInsert = new BTDTLDownloaderInst(destPath);
			dailyInsert.start();
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			if( bos != null ) {
				try {
					bos.close();
					bos = null;
				}catch(Exception e) {}
			}
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {}
		}
	}
}
