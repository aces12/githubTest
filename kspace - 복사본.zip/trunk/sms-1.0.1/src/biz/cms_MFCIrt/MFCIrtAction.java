package biz.cms_MFCIrt;

import java.net.Socket;
import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;

import org.apache.log4j.Logger;

import biz.cms_MFCIrt.MFCIrtProtocol;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;

@SuppressWarnings("unchecked")
public class MFCIrtAction extends ServerAction {

	private static Logger logger = Logger.getLogger(MFCIrtAction.class);
	
	private String mfc_server_ip = "";
	private int mfc_server_port = 0;
	
//	public String get(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		
	
	public void execute(ActionSocket actionSocket) throws Exception {
		logger.info("IRT Action excute");
				
		int ret = 0;
		int inq_type = 0;
		
		String sendMsg = "";
		String dataMsg = "";
		String totalRcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		String serviceVen = "";
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		MFCIrtProtocol MFCIrtProtocol = new MFCIrtProtocol();
		COMMLog df = new COMMLog();	
		
		Socket extClntSock = null;
		MFCIrtConveyer mfcConveyer = null;
				
//		logger.info("webcash_server_ip : "+webcash_server_ip);
		String cust_cd = "";
		try{
			totalRcvBuf = ((String) actionSocket.receive());
			logger.info("totalRcvBuf :"+ totalRcvBuf);
			
			if( totalRcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			df.setStartTime();
			
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,	"MealForChild");
			
			hmCommon = COMMBiz.getData(totalRcvBuf, COMMBiz.CM_HEADER);
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) { //COMMBiz.SYSINQ = 6
				return;
			}
			
			rcvDataBuf = totalRcvBuf.substring(COMMBiz.CM_LENS); //플랫폼 헤더 제외 IRT 전문
			inq_type = MFCIrtProtocol.getMFCIrtInq(rcvDataBuf);
			//logger.info("inq_type "+inq_type);
			
			if(inq_type == MFCIrtData.POSREQ_A4){//전문에 따라 업체코드 필드 산출
				cust_cd = rcvDataBuf.substring(227, 237).trim();
			}else if(inq_type == MFCIrtData.POSREQ_A5){
				cust_cd = rcvDataBuf.substring(263, 273).trim();
			}
			//logger.info("cust_cd "+cust_cd);
			
			if(getServiceVen("purmee", cust_cd)){	//case purmee
				//logger.info("case purmee");
				//PURMEE
				this.mfc_server_ip = PropertyUtil.findProperty("communication-property", "MFC_PURMEE_SERVER_IP");
				this.mfc_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "MFC_PURMEE_SERVER_PORT"));
				
				switch(inq_type) {//승인요청, 승인취소요청
				
				case MFCIrtData.POSREQ_A4: //승인
					//logger.info("case "+MFCIrtData.POSREQ_A4);
					hmData = MFCIrtProtocol.getParse(rcvDataBuf, MFCIrtData.POSREQ_A4);
					logger.info("[pos>sms] parse ok ");
					
					extClntSock = new Socket(mfc_server_ip, mfc_server_port);
					mfcConveyer = new MFCIrtConveyer(extClntSock, df);
					//logger.info("Conveyer setting");
					
					dataMsg = mfcConveyer.getMFCRspA4_purmee(hmCommon, hmData);
					//logger.info("get dataMsg ["+dataMsg+"]");
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					
					break;
				case MFCIrtData.POSREQ_A5: //승인취소
					//logger.info("case "+inq_type);
					hmData = MFCIrtProtocol.getParse(rcvDataBuf, MFCIrtData.POSREQ_A5);
					logger.info("[pos>sms] parse ok ");
					
					extClntSock = new Socket(mfc_server_ip, mfc_server_port);
					mfcConveyer = new MFCIrtConveyer(extClntSock, df);
					//logger.info("Conveyer setting");
					
					dataMsg = mfcConveyer.getMFCRspA5_purmee(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					
					break;
					} 
			}
			else if(getServiceVen("webcash", cust_cd)){ //case webcash
				//logger.info("case webcash");
				//WEBCASH
				this.mfc_server_ip = PropertyUtil.findProperty("communication-property", "MFC_WEBCASH_SERVER_IP");
				this.mfc_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "MFC_WEBCASH_SERVER_PORT"));				

				switch(inq_type) {//승인요청, 승인취소요청&통신망관리		
				
				case MFCIrtData.POSREQ_A4: //승인
					//logger.info("case "+MFCIrtData.POSREQ_A4);
					hmData = MFCIrtProtocol.getParse(rcvDataBuf, MFCIrtData.POSREQ_A4);
					logger.info("[pos>sms] parse ok ");
					
					extClntSock = new Socket(mfc_server_ip, mfc_server_port);
					mfcConveyer = new MFCIrtConveyer(extClntSock, df);
					//logger.info("Conveyer setting");
					
					dataMsg = mfcConveyer.getMFCRspA4_webcash(hmCommon, hmData);
					//logger.info("get dataMsg ["+dataMsg+"]");
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					
					break;
				case MFCIrtData.POSREQ_A5: //승인취소&통신망관리
					//logger.info("case "+inq_type);
					hmData = MFCIrtProtocol.getParse(rcvDataBuf, MFCIrtData.POSREQ_A5);
					logger.info("[pos>sms] parse ok ");
					
					extClntSock = new Socket(mfc_server_ip, mfc_server_port);
					mfcConveyer = new MFCIrtConveyer(extClntSock, df);
					//logger.info("Conveyer setting");
					
					dataMsg = mfcConveyer.getMFCRspA5_webcash(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					
					break;
				}
				}
		}catch(Exception e) {
			ret = 29;
			retValue = "[ERROR]2:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			if( extClntSock != null ) {
				extClntSock.close();
				}
			}

			try{// Make Response Message Data(응답 전문데이타 만들기)
				sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
								
				String totalMsg = sendMsg + dataMsg;
				
				// Send Response Data(응답 데이타 전송)
				if (actionSocket.send(totalMsg)) {
					df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] OK");
					df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + totalMsg + "]");
				} else {
					df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] ERROR");
				}
			}catch(Exception e) {
				retValue = "[ERROR] " + e.getMessage();
				df.CommLogger("▶ " + retValue);
			}finally {
				// IRT Work Finish Log(IRT 업무 종료 로그)
				df.close("MFCIRT", retValue);
			}
		}
	
	public Boolean getServiceVen(String ServiceVen, String cust_cd){
		Boolean verify = false;
		//logger.info("ServiceVen["+ServiceVen+ "]");
		//logger.info("cust_cd["+cust_cd+ "]");
		if("purmee".equals(ServiceVen)){
			for(int i=0;i<MFCIrtData.CUSTCODE_PURMEE.length;i++){
				//logger.info("MFCIrtData.CUSTCODE_PURMEE[i].toString() ["+MFCIrtData.CUSTCODE_PURMEE[i].toString() + "]");
				//logger.info("if문실행[" + cust_cd.equals(MFCIrtData.CUSTCODE_PURMEE[i].toString()) + "]");
				if(cust_cd.equals(MFCIrtData.CUSTCODE_PURMEE[i].toString())){
					//logger.info("if문실행[" + cust_cd.equals(MFCIrtData.CUSTCODE_PURMEE[i].toString()) + "]");
					verify = true;
					break;
				}
			}
		}else if("webcash".equals(ServiceVen)){
			for(int i=0;i<MFCIrtData.CUSTCODE_WEBCASH.length;i++){
				//logger.info("MFCIrtData.CUSTCODE_WEBCASH[i].toString() ["+MFCIrtData.CUSTCODE_WEBCASH[i].toString() + "]");
				if(cust_cd.equals(MFCIrtData.CUSTCODE_WEBCASH[i].toString())){
					verify = true;
					break;
				}
			}
		}
		return verify;
	}
}
