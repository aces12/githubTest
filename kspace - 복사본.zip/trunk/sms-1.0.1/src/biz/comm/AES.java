package biz.comm;

import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;

import org.apache.commons.net.util.Base64;

public class AES {
	private final String KEYNAME = "withmewithme1234";
	private final String ALGORITHM = "AES";
	
	public static final String AES_ECB_NOPADDING = "AES/ECB/NoPadding";
	
	public String encrypt(final String source) throws Exception {
		byte[] eArr = null;
		SecretKeySpec skeySpec = new SecretKeySpec(KEYNAME.getBytes(), ALGORITHM);
		Cipher cipher = Cipher.getInstance(AES_ECB_NOPADDING);
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		eArr = cipher.doFinal(this.addPadding(source.getBytes()));
		
		return fromHex(eArr);
	}
	
	public byte[] encryptToByteArray(final String source) throws Exception {
		byte[] eArr = null;
		SecretKeySpec skeySpec = new SecretKeySpec(KEYNAME.getBytes(), ALGORITHM);
		Cipher cipher = Cipher.getInstance(AES_ECB_NOPADDING);
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		eArr = cipher.doFinal(this.addPadding(source.getBytes()));
		
		return eArr;
	}
	
	public String GetEncryptString(String source) throws Exception {
		StringBuilder sbResult = new StringBuilder();
		byte[] eArr = null;
		SecretKeySpec skeySpec = new SecretKeySpec(KEYNAME.getBytes(), ALGORITHM);
		Cipher cipher = Cipher.getInstance(AES_ECB_NOPADDING);
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		eArr = cipher.doFinal(this.addPadding(source.getBytes()));
		for(byte b : eArr) {
			sbResult.append(String.format("%02x", b));
		}
		
		return sbResult.toString();
	}
	
	public String decrypt(final String source) throws Exception {
		Cipher cipher = Cipher.getInstance(AES_ECB_NOPADDING);
		byte[] eArr = null;
		SecretKeySpec skeySpec = new SecretKeySpec(KEYNAME.getBytes(), ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE, skeySpec);
		eArr = this.removePadding(cipher.doFinal(this.toBytes(source)));
		
		return new String(eArr);
	}
	
	public String decrypt123(final String source, String key) throws Exception {
		Cipher cipher = Cipher.getInstance(AES_ECB_NOPADDING);
		byte[] eArr = null;
		SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(), ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE, skeySpec);
		eArr = this.removePadding(cipher.doFinal(this.toBytes(source)));
		
		return new String(eArr);
	}
	
	private byte[] removePadding(final byte[] pBytes) {
        int pCount = pBytes.length;
        int index = 0;
        boolean loop = true;
        while (loop) {
        	if (index == pCount || pBytes[index] == 0x00) {
        		loop = false;
        		index--;
        	}
        	index++;
        }
        byte[] tBytes = new byte[index];
        System.arraycopy(pBytes, 0, tBytes, 0, index);
        
        return tBytes;
	}
	
	private byte[] toBytes(final String pSource) {
		StringBuffer buff = new StringBuffer(pSource);
		int bCount = buff.length() / 2;
		byte[] bArr = new byte[bCount];
		for(int bIndex = 0;bIndex < bCount;bIndex++) {
			bArr[bIndex] = (byte)Long.parseLong(buff.substring(2 * bIndex, (2 * bIndex) + 2), 16);
		}
		
		return bArr;
	}
	
	private byte[] addPadding(final byte[] pBytes) {
		int pCount = pBytes.length;
		int tCount = pCount + (16 - (pCount % 16));
		byte[] tBytes = new byte[tCount];
		System.arraycopy(pBytes, 0, tBytes, 0, pCount);
		for(int rIndex = pCount;rIndex < tCount;rIndex++) {
			tBytes[rIndex] = 0x00;
		}
		
		return tBytes;
	}
	
	private String fromHex(byte[] pBytes) {
		int pCount = pBytes.length;
		StringBuffer buff = new StringBuffer(pCount * 2);
		for(int pIndex = 0;pIndex < pCount;pIndex++) {
			if (((int)pBytes[pIndex] & 0xff) < 0x10) {
				buff.append(0);
			}
			buff.append(Long.toString((int)pBytes[pIndex] & 0xff, 16));
		}
		
		return buff.toString();
	}
	
	private static byte[] hexToByteArray(String hex) {

        if(hex == null || hex.length() == 0){
            return null;
        }
        
        //16진수 문자열을 byte로 변환
        byte[] byteArray = new byte[hex.length() /2 ];        

        for(int i=0; i<byteArray.length; i++){
            byteArray[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2*i+2), 16);
        }
        return byteArray;
    }
	
	public Key getAESKey(String secretkey) throws Exception {
	    String iv;
	    Key keySpec;

	    String key = secretkey;
	    iv = key.substring(0, 16);
	    byte[] keyBytes = new byte[16];
	    byte[] b = key.getBytes("UTF-8");

	    int len = b.length;
	    if (len > keyBytes.length) {
	       len = keyBytes.length;
	    }

	    System.arraycopy(b, 0, keyBytes, 0, len);
	    keySpec = new SecretKeySpec(keyBytes, "AES");

	    return keySpec;
	}
	
	// 복호화
	public String decAES(String enStr, String secretKey) throws Exception {
	    Key keySpec = getAESKey(secretKey);
	    String iv = secretKey;
	    Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
	    c.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(iv.getBytes("UTF-8")));
	    byte[] byteStr = Base64.decodeBase64(enStr.getBytes("UTF-8"));
	    String decStr = new String(c.doFinal(byteStr), "UTF-8");

	    return decStr;
	}


}
