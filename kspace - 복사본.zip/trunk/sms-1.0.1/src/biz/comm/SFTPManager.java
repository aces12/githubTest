package biz.comm;

import java.io.OutputStream;
import java.util.List;

import com.sshtools.j2ssh.SftpClient;
import com.sshtools.j2ssh.SshClient;
import com.sshtools.j2ssh.authentication.AuthenticationProtocolState;
import com.sshtools.j2ssh.authentication.PasswordAuthenticationClient;

public class SFTPManager {
	private SshClient client = null;
	private PasswordAuthenticationClient auth = null;
	private SftpClient sftp = null;
	
	public SFTPManager(String server, int port, String user, String pwd) throws Exception {
		try {
			client = new SshClient();
			client.setSocketTimeout(10000);
			client.connect(server, port);
			auth = new PasswordAuthenticationClient();
			auth.setUsername(user);
			auth.setPassword(pwd);
			int result = client.authenticate(auth);
			if( result != AuthenticationProtocolState.COMPLETE) {
				throw new Exception("Login to " + server + ":" + Integer.toString(port) + user + "/" + pwd + " failed");
			}
			sftp = client.openSftpClient();
		}catch(Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public List<Object> ls() throws Exception {
		List<Object> list = null;
		try {
			if(sftp != null) {
				list = sftp.ls();
			}
		}catch(Exception e) {
			throw e;
		}
		return list;
	}
	
	public boolean rename(String oldpath, String newpath) throws Exception {
		boolean bRtn = false;
		try {
			if(sftp != null) {
				sftp.rename(oldpath, newpath);
				bRtn = true;
			}
		}catch(Exception e) {
			throw e;
		}
		return bRtn;
	}
	
	public boolean put(String path) throws Exception {
		boolean bRtn = false;
		try {
			if(sftp != null) {
				sftp.put(path);
				bRtn = true;
			}
		}catch(Exception e) {
			throw e;
		}
		return bRtn;
	}
	
	public boolean get(String srcFile, OutputStream oStream) throws Exception {
		boolean bRtn = false;
		try {
			if(sftp != null) {
				sftp.get(srcFile, oStream);
				bRtn = true;
			}
		}catch(Exception e) {
			throw e;
		}
		
		return bRtn;
	}
	
	public boolean get(String srcFile, String destFile) throws Exception {
		boolean bRtn = false;
		try {
			if(sftp != null) {
				if(destFile == null)
					sftp.get(srcFile);
				else
					sftp.get(srcFile, destFile);
				bRtn = true;
			}
		}catch(Exception e) {
			throw e;
		}
		return bRtn;
	}
	
	public boolean lcd(String path) throws Exception
	{
		boolean bRtn = false;
		try {
			if(sftp != null) {
				sftp.lcd(path);
				bRtn = true;
			}
		}catch(Exception e) {
			throw e;
		}
		
		return bRtn;
	}
	
	public boolean cd(String path) throws Exception
	{
		boolean bRtn = false;
		try {
			if(sftp != null) {
				sftp.cd(path);
				bRtn = true;
			}
		}catch(Exception e) {
			throw e;
		}
		
		return bRtn;
	}
	
	public String pwd() throws Exception
	{
		String strRtn = "";
		try {
			if(sftp != null) {
				strRtn = sftp.pwd();
			}
		}catch(Exception e) {
			throw e;
		}
		
		return strRtn;
	}
	
	public boolean chmod(int permissions, String path) throws Exception {
		boolean bRtn = false;
		try {
			if(sftp != null) {
				sftp.chmod(permissions, path);
				bRtn = true;
			}
		}catch(Exception e) {
			throw e;
		}
		
		return bRtn;
	}
	
	public boolean isClosed() throws Exception {
		boolean bRtn = false;
		try {
			if(sftp !=null ) {
				bRtn = sftp.isClosed();
			}
		}catch(Exception e) {
			throw e;
		}
		
		return bRtn;
	}
	
	public boolean logout() throws Exception {
		boolean bRtn = false;
		try {
			if(sftp != null)
				sftp.quit();
			if(client != null)
				client.disconnect();
			bRtn = true;
		}catch(Exception e) {
			throw e;
		}
		
		return bRtn;
	}

	public boolean rm(String fileNM) throws Exception {
		boolean bRtn = false;
		
		try{
			if(sftp !=null ) {
				sftp.rm(fileNM);
				bRtn = true;
			}
		}catch(Exception e) {
			throw e;
		}
		
		return bRtn;
	}
}
