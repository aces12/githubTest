/*
 * TranAction.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */

package biz.cms_TranRcv;

import java.util.HashMap;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import org.apache.log4j.Logger;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;


/** 
 * TranAction
 * 
 * A Class that has inherited ServerAction(ServerAction을 상속받은 클래스)
 * A class to receive and process Tran data through 9002 port(트란데이타를 9002포트로 수신 받아 처리하는 클래스) 
 * @created  on 1.0,  11/03/17
 * @created  by oki(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */ 
public class TranRcvAction extends ServerAction {
    //Createlog4j instance( log4j의 인스턴스를 생성합니다).
    //At the moment, logger designate its own class name as PakageName.ClassName(이때 로거는 PakageName.ClassName으로 자신의 클래스명을 지정합니다)
	private static Logger logger = Logger.getLogger(TranRcvAction.class);

    /**
     * Receive Tran data from SC through 9002 PORT(SC로부터 트란데이타를 9002 PORT로 받음).
     * 
     * @param ActionSocket
     * @return 
     * @throws Exception
     */
	public void execute(ActionSocket actionSocket) throws Exception  {
		// TODO Auto-generated method stub
		int ret=0;
		String sendMsg="";
		String rcvBuf="";		
		String retValue = "OK!";
		HashMap hmCommon = new HashMap(); 
		HashMap hmData = new HashMap();
		TranRcvDAO dao = new TranRcvDAO();	
		COMMLog df = new COMMLog();
	
		try {
			// Tran Data received from SC(SC로부터 받은 트란 데이타) 
			rcvBuf=((String)actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
//			// Set Work Start Time(업무시작시간설정) 
//			df.setStartTime();		
//			df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),
//					             String.valueOf(actionSocket.getSocket().getPort()), logger, "TRAN" );
			
			df.CommLogger("▶ 1: Receive Data: " + rcvBuf);	
			// Save header of message data to hmCommon(전문데이타의 헤더부분을 hmCommon에 저장한다).
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			df.CommLogger("▶ 2: Receive Data: " + rcvBuf);
			// Compare to see if MsgType message type value is TRAN(MsgType 전문구분값이 TRAN 인지 비교한다).
			if ( !(COMMBiz.getCommMsgType(hmCommon, COMMBiz.TRAN)) ) {			
				return;
			}
			df.CommLogger("▶ 3: Receive Data: " + rcvBuf);
			// Save message part of message data to hmData(전문데이타의 메세지부분을 hmData에 저장한다).
			hmData = COMMBiz.getData(rcvBuf, COMMBiz.TR_HEADER);
			df.CommLogger("▶ 3.1: Receive Data: " + rcvBuf);	
			// Check type of transaction(거래종별 확인 하기)
			if (COMMBiz.getTranType(hmData) == COMMBiz.ERR) {
				df.CommLogger("▶ 4: Receive Data: " + rcvBuf);	
				// In the case of error, save it to COMMBiz.Err table(오류인경우 COMMBiz.Err 테이블에 저장하기).
//				ret = dao.setErrData(rcvBuf, df);
				ret = dao.setErrData(rcvBuf);
			} else { 
				// Save to STTRP010DT Table(STTRP010DT 저장함).
				df.CommLogger("▶ 5: Receive Data: " + rcvBuf);	
//				ret = dao.setData(hmData, rcvBuf, COMMBiz.TB_INS_STTRP010DT, df);
				ret = dao.setData(hmData, rcvBuf, COMMBiz.TB_INS_STTRP010DT);
			}
		
		} catch (Exception e) {
			//029=HOST APPL ERR
			ret = 29;
			retValue = "[ERROR]4: " + e.getMessage();
//			df.CommLogger("▶ "+ retValue);			
			logger.info("▶ "+ retValue);
		} finally {
			if( ret != 0 ) {
				dao.spSMSSEND("매출TRAN INSERT 오류", "cms_TranRcv");
			}
		}
		
		try {		
			// df.CommLogger("--- makeSendData:"+ret);
			// Make Response Message Data(응답 전문데이타 만들기) 
			sendMsg = COMMBiz.makeSendData(hmCommon,0, ret);		
			if (actionSocket.send(sendMsg)) {			
//				df.CommLogger("▶ SEND MSG: "+sendMsg + " ==>LEN: " + sendMsg.length());	
			} else {
//				df.CommLogger("▶[ERROR]5: "+sendMsg + " ==>LEN: " + sendMsg.length());
				logger.info("▶[ERROR]5: "+sendMsg + " ==>LEN: " + sendMsg.length());
			}
		} catch (Exception e) {
			retValue = "[ERROR]6: " + e.getMessage();
//			df.CommLogger("▶ "+ retValue);
			logger.info("▶ "+ retValue);
		} finally {
			// Tran Work Finish Log(트란업무 종료 로그) 
//			df.close("TRAN", retValue);
		}
	}
}
