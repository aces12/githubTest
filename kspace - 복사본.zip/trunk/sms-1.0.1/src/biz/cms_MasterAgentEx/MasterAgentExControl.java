package biz.cms_MasterAgentEx;

public class MasterAgentExControl {
	public synchronized void useThread() throws InterruptedException {
		//System.out.println( "lend :" + MasterCrtClientAction.getJobThread());
		if (MasterAgentExPOSOperator.getJobThread() <= 0) {
			//System.out.println(t.getName() + ": wating...");
			this.wait();
			//System.out.println(t.getName() + ": return...");
		}
		MasterAgentExPOSOperator.decrement();
	}
	
	public synchronized void returnThread() {
		MasterAgentExPOSOperator.increment();
		this.notify();
	}
}
