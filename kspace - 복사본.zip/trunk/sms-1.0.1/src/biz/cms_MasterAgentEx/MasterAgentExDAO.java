package biz.cms_MasterAgentEx;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class MasterAgentExDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(MasterAgentExPollingAction.class);
	
	public List<Object> selURGENTMSGLIST(Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "SEL_URGENTMSGLIST"));
			sql.setString(++i, (String)map.get("TRANS_YMD"));
			sql.setString(++i, (String)map.get("STORE_CD"));
			sql.setString(++i, (String)map.get("POS_NO"));
			sql.setString(++i, (String)map.get("TRANS_ID"));
			sql.setString(++i, (String)map.get("TRANS_SEQ"));
			sql.setString(++i, (String)map.get("COM_CD"));
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selURGENTMSGLIST::" + e);
		}
		
		return list;
	}
	
	// PROC_ID = "0":미송신, "1":송신중, "2":송신에러, "3":송신완료
	public int updTARGETMASTERLIST(Map<String, String> map, String PROC_ID) {
		SqlWrapper sql = new SqlWrapper();
		int i=0;
		int rows=-1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "UPD_TARGETMASTERLIST"));
			sql.setString(++i, PROC_ID);
			sql.setString(++i, (String)map.get("TRANS_YMD"));
			sql.setString(++i, (String)map.get("STORE_CD"));
			sql.setString(++i, (String)map.get("POS_NO"));
			sql.setString(++i, (String)map.get("TRANS_ID"));
			sql.setString(++i, (String)map.get("TRANS_SEQ"));
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]updTARGETMASTERLIST::" + e);
		}finally {
			end();
		}
		
		return rows;
	}
	
	/**
	 * 예약된 배신완료 조회
	 * @return : 조회목록
	 */
	public List<Object> selTARGETMASTERLIST(String strOTPVal) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "SEL_TARGETMASTERLIST"));
			sql.setString(++i, strOTPVal);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selTARGETMASTERLIST::" + e);
		}
		
		return list;
	}
	
	/**
	 * 배신완료 마스터 예약
	 * @return : 예약건수
	 */
	public int updMASTERTARGETSEL(String strOTPVal, String PROC_ID, int MaxTargetNum) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		int rows=-1;
		int sequence = 0;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			// 통신서버 3대가 같은 row를 update 하려는 시도를 차단하기 위해
			// 1~3 범위로 순환되는 sequence 값을 조회해서 그 값이 (REG_DTM % 3)와 같은
			// row들만 update 한다.
			// 통신서버 3대는 동시에 같은 row를 update 할 수 없게 된다.
//			sql.put(findQuery("master-sql", "SEL_MASTERDPLYSEQ"));
//			list = executeQuery(sql);
//			sql.close();
//			if( list.size() > 0 ) sequence = Integer.parseInt((String)((Map<String, String>)list.get(0)).get("SEQ"));
//			
			i = 0;
			sql.clearParameter();
						
			sql.put(findQuery("master-sql", "UPD_MASTERTARGETSEL"));
			sql.setString(++i, strOTPVal);
			sql.setString(++i, PROC_ID);
//			sql.setInt(++i, sequence - 1);
			sql.setInt(++i, MaxTargetNum);
			rows = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	/**
	 * 정기배신 마스터 파일 생성여부 조회
	 * @return : 마스터정보목록
	 */
	public List<Object> selMASTERAGENTDAILYEx(String transYmd) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "SEL_MASTERAGENTDAILYEx"));
			sql.setString(++i, transYmd);
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selMASTERAGENTDAILYEx::" + e);
		}
		
		return list;
	}
	
	/**
     * 정기마스터 배신정보 생성 프로시저 
     * @return Result code (결과코드)
     * @exception exception Description of Exception(예외사항설명)
     */
	public int procMSTINFOCRTEX(Map<String, String> map) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		String tran_ymd = (String)map.get("tran_ymd");
		String com_cd = (String)map.get("com_cd");
		String store_cd = (String)map.get("store_cd");
		String create_ty = (String)map.get("create_ty");
		int i=0;
		int ret=0;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
		
//			logger.info("[DEBUG] [procMSTINFOCRT] Begin");
			proc.put("SP_MSTINFO_CRT_EX", 6);
			proc.setString(++i, tran_ymd);	// tran_ymd
			proc.setString(++i, com_cd);	// com_cd
			proc.setString(++i, store_cd);	// store_cd
			proc.setString(++i, create_ty);	// create_ty
			proc.registerOutParameter(++i, DataTypes.INTEGER);
			proc.registerOutParameter(++i, DataTypes.VARCHAR);

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			ret = prs.getInt(5);
			String retMsg = prs.getString(6);
			logger.info("[DEBUG] [procMSTINFOCRT] ResultMsg:" + tran_ymd + "/" + com_cd + "/" + store_cd + "/" + create_ty);
			logger.info("[DEBUG] [procMSTINFOCRT] End");
		} catch (Exception e) {
			rollback();
//			System.out.println(e.getMessage());
			logger.info("[ERROR] procMSTINFOCRT::" + e);
			ret=-1;
		} finally {
			// 모든 trasaction을 종료하고 리소스를 반납합니다.
			end();
		}
		
		return ret;
	}
	
	/**
     * 수동배신 마스터파일 여부 조회 
     * @return Master Info List(마스터정보목록)
     * @exception exception Description of Exception(예외사항설명)
     */
	public List<Object> selMASTERAGENTMANUALEx(String transYmd) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "SEL_MASTERAGENTMANUALEx"));
			sql.setString(++i, transYmd);	// trans_ymd
			//logger.info("[DEBUG]selMASTERAGENTMANUAL::" + sql.debug());
			list = executeQuery(sql);
		} catch (Exception e) {
//			System.out.println(e.getMessage());
			logger.info("[ERROR]selMASTERAGENTMANUAL::" + e);
		} 
		
		return list;
	}
}
