package biz.cms_MasterAgentEx;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_MasterCrtEx.MasterCrtExClientAction;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

/** 
 * MasterAgentExPollingAction
 * 정기/수동(매출 Tran 데이터 분리) 
 * @created  on 1.0,  11/03/17
 * @created  by khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by 
 */ 
public class MasterAgentExPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(MasterAgentExPollingAction.class);
	
	private final int MAX_TARGET_NUM = 30;

	public static void main(String args[]) throws Exception {
		MasterAgentExPollingAction action = new MasterAgentExPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			action.execute("1");
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		try {
			MasterAgentExDAO dao = new MasterAgentExDAO();
			List<Object> list = null;
			int totalCount = 0; 
			int ret = -1;
			
			// 현재 날짜를 가져온다.
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			String today = sdf.format(calendar.getTime());
			
			// 오늘 일자에 내일의 정기마스터 파일을 만들기 위해 내일 날짜를 구한다.
			calendar.add(Calendar.DATE, 1);
			String tran_ymd = sdf.format(calendar.getTime());
			
			// actionMode="0":POLLING_PERIOD에 주기적으로 무조건 수행, "1":ACTION_TIME에 한 번 수행
			if( actionMode == "1" ) {
				//(금일 정기배신 마스터 생성 정보 유무 조회)
				list = dao.selMASTERAGENTDAILYEx(tran_ymd);
				totalCount = list.size();
				
//				System.out.println("totalCount=" + Integer.toString(totalCount));
				
				if( totalCount <= 0) {
					//마스터 생성 정보 생성
					Map<String, String> map = new HashMap<String, String>();
					map.put("tran_ymd", tran_ymd);
					map.put("com_cd", "%");
					map.put("store_cd", "%");
					map.put("create_ty", "ALL");
					
					ret = dao.procMSTINFOCRTEX(map);
					
//					System.out.println("ret = " + ret);
					
					if( ret == 0 ) {
						//마스터 생성 프로세스 구동
						MasterCrtExClientAction master = new MasterCrtExClientAction();
						
						//daemon-config 경로
						String basePath = PropertyUtil.findProperty("stsys-property", "SMS_ROOT");
						basePath = basePath + File.separator + "xml" + File.separator + "daemon-config.xml";
						
						master.setMaxThread(10);
						master.setTransYmd(tran_ymd);
						master.setCom("%");
						master.setStore("%");
						master.setPath(basePath);
						master.setDeploy(false);
						
						master.execute();
					}
				}
			}else if( actionMode == "0" ) {
				//(금일 정기배신 마스터 생성 정보 유무 조회)
				list = dao.selMASTERAGENTDAILYEx(tran_ymd);
				totalCount = list.size();
				
//				logger.info("금일정기배신마스터totalCount="+Integer.toString(totalCount));
				
				//내일자 정기배신 마스터가 생성된 이후에는 마스터 생성 정보가 존재해도 마스터를 생성하지 않는다.
				if( totalCount <= 0 ) {
					//(금일 수동배신 마스터 생성 정보 유무 조회)
					list = dao.selMASTERAGENTMANUALEx(today);
					totalCount = list.size();
					
//					logger.info("금일수동배신마스터totalCount="+Integer.toString(totalCount));
					
					if( totalCount > 0 ) {
						//마스터 생성 프로세스 구동
						MasterCrtExClientAction master = new MasterCrtExClientAction();
						
						//daemon-config 경로
						String basePath = PropertyUtil.findProperty("stsys-property", "SMS_ROOT");
						basePath = basePath + File.separator + "xml" + File.separator + "daemon-config.xml";
						
						master.setMaxThread(10);
						master.setTransYmd(today);
						master.setCom("%");
						master.setStore("%");
						master.setPath(basePath);
						master.setDeploy(false);
						
//						logger.info("마스터수동배신생성");
						
						master.execute();
					}
				}
				
				list.clear();
				Calendar cal = new GregorianCalendar(Locale.KOREA);
				SimpleDateFormat dateFormat = new SimpleDateFormat("MMddHHmmssSSSSS");
				String sOTPVal = dateFormat.format(cal.getTime()) + (Double.toString(Math.random())).substring(2, 9);
				

				// 배신준비완료된 POS List 예약
				ret = dao.updMASTERTARGETSEL(sOTPVal, "0", MAX_TARGET_NUM);
				
//				logger.info("예약된POS List 갯수:" + Integer.toString(ret));
				
				if( ret > 0 ) {
					// 예약된 POS List 조회
					list = dao.selTARGETMASTERLIST(sOTPVal);
					
//					logger.info("예약된POS List 조회:" + Integer.toString(list.size()));
										
					MasterAgentExPOSOperator op = new MasterAgentExPOSOperator();
					
					op.setMaxThread(MAX_TARGET_NUM);
					
					op.request(list);
				}
				else {
					// 배신준비완료된 POS List를 다 돈 이후에 송신실패된 건들만 다시 예약
					ret = dao.updMASTERTARGETSEL(sOTPVal, "2", MAX_TARGET_NUM);
					
//					logger.info("실패된POS List 예약 갯수:" + Integer.toString(ret));
					
					if( ret > 0 ) {
						// 예약된 POS List 조회
						list = dao.selTARGETMASTERLIST(sOTPVal);
											
						MasterAgentExPOSOperator op = new MasterAgentExPOSOperator();
						
						op.setMaxThread(MAX_TARGET_NUM);
						
						op.request(list);
					}
				}
			}
		}catch(Exception e) {
			logger.info("", e);
		}
	}

}
