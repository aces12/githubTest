package biz.cms_MasterAgentEx;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

public class MasterAgentExPOSOperator {
	private static Logger logger = Logger.getLogger(MasterAgentExPollingAction.class);
	public static MasterAgentExControl msControl = new MasterAgentExControl();
	private final int POS_PORT = 7002;
	
	private static int jobThread=0;
	private static int maxThread=0;
	
	public static void increment(){
		jobThread++;
	}

	public static void decrement(){
		jobThread--;
	}
	
	public static int getJobThread(){
		return jobThread;
	}
	
	public static int getMaxThread(){
		return maxThread;
	}
	
	public void setMaxThread(int maxThread){
		if( getMaxThread() == 0 ) {
			this.maxThread = maxThread;
			this.jobThread = maxThread;
		}
	}
	
	public void request(List<Object> list) {
		MasterAgentExDAO dao = new MasterAgentExDAO();
		Map<String, String> map = null;

		
		try {
			int total_cnt = list.size();

			for(int i = 0;i < total_cnt;i++) {
				map = (Map<String, String>)list.get(i);
				
				if( ((String)map.get("POS_IP")).length() == 0 ) {
					// "0":미송신, "1":송신중, "2":송신에러, "3":송신완료
					dao.updTARGETMASTERLIST(map, "3");
					continue;
				}
				logger.info("IP:"+(String)map.get("POS_IP")+" PORT:"+Integer.toString(POS_PORT));
				
				// create thread object
				MasterAgentExRunner runner = new MasterAgentExRunner(this);
				
				// set map object
				runner.setMap(map);
				
				// execute thread
				runner.start();
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
	}
}
