package biz.cms_POSIrt;

import java.net.Socket;
import java.util.HashMap;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

class Teststart {
	
	/**
	 * Receive data from SC through 9001 PORT(SC로부터 데이타를 9001 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public static void main(String[] a)  throws Exception {
		
		String server_ip = "";
		int server_port = 0;
		int ret = 0;
		int inq_type = 0;
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		String sendMsg = "";
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		POSIrtProtocol protocol = new POSIrtProtocol();
		COMMLog df = new COMMLog();
		
		Socket extClntSock = null;
		POSIrtConveyer conveyer = null;
		
		try {
			rcvBuf = "                                                  73012340001115417678151         2         3         4         5         6         7         8         120160426201515";
			inq_type = 73;
			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			inq_type = protocol.getRcvPOSIrtDATA(rcvDataBuf);
			switch( inq_type ) {
				// 11: 외상고객조회
				case 73:
						System.out.println("inq_type[" + inq_type + "]");
						System.out.println("rcvDataBuf[" + rcvDataBuf + "]");
					
					hmData = protocol.getParseStaffCheck(rcvDataBuf);
					
						System.out.println("hmData[" + hmData + "]");
					
					server_ip = "174.100.67.91"; //PropertyUtil.findProperty("communication-property", "STAFFCHK_COMM_IP");
						System.out.println("server_ip[" + server_ip + "]");
					server_port = 25201; //Integer.parseInt(PropertyUtil.findProperty("communication-property", "STAFFCHK_COMM_PORT"));	
						System.out.println("server_port[" + server_port + "]");				
					extClntSock = new Socket(server_ip, server_port);
						System.out.println("extClntSock[" + extClntSock + "]");		
					conveyer = new POSIrtConveyer(extClntSock, df);			
						System.out.println("conveyer[" + conveyer + "]");				 
					dataMsg = conveyer.getStaffCheck(hmCommon, hmData);
					
						System.out.println("dataMsg[" + dataMsg + "]");
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					System.out.println("ret[" + ret + "]");
					break;
					
				default:
					System.out.println("▶ INQ Type Code(INQ 종별 코드):   [" + inq_type + "]" + rcvBuf.length());
					ret = 99;
					break;
					
			}
		}catch(Exception e) {
			// 029=HOST APPL ERR
			ret = 29;
			retValue = "[ERROR] " + e.getMessage();
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			//sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			System.out.println("[sms>pos] SEND[" + (sendMsg+dataMsg).getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + (sendMsg+dataMsg) + "]");
			// Send Response Data(응답 데이타 전송)
		}catch(Exception e) {
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			System.out.println("retValue[" + retValue + "]");
		}
	}
}