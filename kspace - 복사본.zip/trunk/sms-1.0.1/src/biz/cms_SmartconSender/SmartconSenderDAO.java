package biz.cms_SmartconSender;

import java.util.List;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class SmartconSenderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(SmartconSenderPollingAction.class);
	

	@SuppressWarnings("unchecked")
	public List<Object> selSmartconMST() throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		String sqlDbg = "";
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SMARTCON_MST"));

			sqlDbg = sql.debug();
			list = executeQuery(sql);	
			
		} catch (Exception e) {
			logger.info("[SEL_SMARTCON_MST]" + sqlDbg );
			logger.error("[DEBUG] Try to transfer MST File" );
			throw e;
		} 
		
		return list;
	}
	
	
}