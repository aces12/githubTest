package biz.cms_SmartconSender;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import org.apache.log4j.Logger;


public class SmartconSenderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(SmartconSenderPollingAction.class);
	
	public static void main(String args[]) throws Exception {
		SmartconSenderPollingAction action = new SmartconSenderPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[1]]=" + args[1] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd			 = nvl(args[1].replaceFirst("-cmd:", ""));
			
			//neo0531 for test 
			//path = "C:\\CMBO\\workspace\\sms-1.0.1\\xml\\daemon-config.xml";					
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			if( cmd.length() != 3 ) return;			
				
			if( cmd.charAt(0) == '1' ) {
				System.out.println("[DEBUG] execute Create and Transfer MST" );
				logger.info("[DEBUG] execute Create and Transfer MST" );
				action.execute("1");
			}
			if( cmd.charAt(1) == '1' ) {
				System.out.println("[DEBUG] Try to create smartcon MST" );	
				logger.info("[DEBUG] Try to create smartcon MST" );
				SmartconSenderMakeTransferMST actionMakeTransferMst = new SmartconSenderMakeTransferMST();
				actionMakeTransferMst.bMakeMST = true ;
				actionMakeTransferMst.start();
			}
			Thread.sleep(50);
			if( cmd.charAt(2) == '1' ) {
				System.out.println("[DEBUG] Try to transfer MST File" );
				logger.info("[DEBUG] Try to transfer MST File" );
				SmartconSenderMakeTransferMST actionMakeTransferMst = new SmartconSenderMakeTransferMST();
				actionMakeTransferMst.bTransMST = true ;
				actionMakeTransferMst.start();			
			}			
		}catch(Exception e) {
			logger.error("[ERROR]" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	

	public void execute(String actionMode) {				
		try {
			logger.info("[DEBUG] execute(%s)" + actionMode);
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode != "1" ) return;		
											
			if (existMST()){
				logger.error("[ERROR] MST file of today is already exist");
				return;	
			}
			
			logger.info("execute before new SmartconSenderMakeTransferMST()");
			SmartconSenderMakeTransferMST actionMakeTransferMst = new SmartconSenderMakeTransferMST();
			actionMakeTransferMst.bMakeMST = true;
			actionMakeTransferMst.bTransMST = true;
			actionMakeTransferMst.start();			
	
		}catch(Exception e) {
			logger.error("[ERROR]" + e.getMessage());
		}
	}

	public boolean existMST() throws Exception{
		// neo0531 업로드 경로에 해당날짜 (현재 날짜 +1)의 마스터 파일 존재 하는지 확인 
		boolean retVal1,retVal2 = false;
		String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트

		//neo0531 for test 
		//basePath = "C:\\CMBO";
		
		String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "smartcon";
		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		calendar.setTime(new Date());
		calendar.add(Calendar.DATE, 1);
		String stdDate = sdf.format(calendar.getTime());
		
		String targetFileNm = "SMARTCON_WITHME_MST_" + stdDate + ".dat";
		
		File file = new File (destPath + File.separator +targetFileNm);		
		//retVal1 = file.isFile();
		retVal1 = file.exists();
		if (retVal1)
			logger.info("[DEBUG] existMST file");
		destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "smartcon" + File.separator + "backup";
				
		targetFileNm = targetFileNm + ".ok";
		
		File file2 = new File (destPath + File.separator +targetFileNm);	
		retVal2 = file2.exists();
		if (retVal2)
			logger.info("[DEBUG] existMST file");
		
		return (retVal1 == false && retVal2 == false)?false :true;
	}



} 

