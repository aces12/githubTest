package biz.cms_OneBarcode;

import java.security.Key;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.nio.charset.Charset;

import org.apache.commons.net.util.Base64;
 
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

public class OneBarcodeIrtConveyer {

	private Socket svrSock = null;
	private ActionSocket actSock = null;

	COMMLog df = null;
	
	public OneBarcodeIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}
	
	public String getOneBarcode(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		String sendMsg = "";		// 보낼 송신 전문
		String recvBuf = "";		// 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		
		int nrow = -1;				// STTRP110DT 원바코드 업데이트 결과 값
		
		OneBarcodeIrtProtocol protocol = new OneBarcodeIrtProtocol();
//		OneBarcodeIrtDAO  dao = new OneBarcodeIrtDAO();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		try {
			df.CommLogger("[OneBarcode - 0.1] ");
			// 필터 의미 => 받는전문 길이
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.ONEBARCODE_FILTER)));
			StringBuffer sb = new StringBuffer();	
			
			df.CommLogger("[OneBarcode - 1] ");
			// 모바일 보낼 전문 생성
			sb.append("00021");		// 보내는 전문길이
			df.CommLogger("[OneBarcode - 2]");
			
			
			StringUtil.appendSpace(sb, (String) hm.get("MOBILE_BARCODE").toString(),16);
			
			df.CommLogger("[OneBarcode - 3]");
			
			sendMsg = sb.toString();
			
			sb = new StringBuffer(sendMsg);
			
			df.CommLogger("[OneBarcode - Inquiry] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sendMsg + "]");
			
			// 모바일 통신 시작
			if (actSock.send(sendMsg)) {
				df.CommLogger("[OneBarcode - Inquiry] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[OneBarcode - Inquiry] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("OneBarcode Server is no response");
			}
			
			// 응답 받음
			recvBuf = ((String) actSock.receive());
			sb = null;
			sb = new StringBuffer(recvBuf);
			
			df.CommLogger("[OneBarcode - Inquiry]  RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			// 받은 전문 파싱
			hmRecv = protocol.getParseOneBarcodeRsp(recvBuf);	
			
			df.CommLogger("[OneBarcode - RESP_CD]  RECV[" + hmRecv.get("RESP_CD"));
			df.CommLogger("[OneBarcode - RESP_CD]  RECV[" + hmRecv.get("RESP_CD").toString());
			df.CommLogger("[OneBarcode - RESP_MSG]  RECV[" + hmRecv.get("RESP_MSG").toString());
			df.CommLogger("[OneBarcode - KT_MEMBER_NO]  RECV[" + hmRecv.get("KT_MEMBER_NO").toString());
			df.CommLogger("[OneBarcode - KT_MEMBER_YN]  RECV[" + hmRecv.get("KT_MEMBER_YN").toString());
			
			if ("00".equals(hmRecv.get("RESP_CD").toString())){
//				// STTRP110DT 원바코드 정보 갱신
//				nrow = dao.updOneBarcode(hm, df);	// 갱신 실패하면 처리????	
			}
			
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			
			throw e;
		}finally {
			actSock.close();
			
			// POS 보낼 전문 생성
			dataMsg = makeSendDataToPosRsp(hmRecv,df);			
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataToPosRsp(HashMap<String, String> hm, COMMLog df) throws UnsupportedEncodingException {
		StringBuffer sb = new StringBuffer();		
//		
//		String msg = (String)hm.get("RESP_MSG");
////		byte [] utf8 =  msg.getBytes("euc-kr");
////		String data = new String(utf8, "euc-kr");
//		
////		String data = toKorean( (String)hm.get("RESP_MSG"), 64);
//		
//		String data = new String(msg.getBytes("EUC-KR") , "EUC-KR");
//		df.CommLogger("msgUtf8 >>>> " + data);
		
		StringUtil.appendSpace(sb, "G4", 2);
		StringUtil.appendSpace(sb, hm.get("RESP_CD").toString(), 2);
		StringUtil.appendSpace(sb, (String)hm.get("RESP_MSG"), 64);
		StringUtil.appendSpace(sb, hm.get("KT_MEMBER_NO").toString(), 16);
		StringUtil.appendSpace(sb, hm.get("KT_MEMBER_YN").toString(), 1);
		
		
		df.CommLogger("makeSendDataToPosRsp" + sb.toString());
		
		return sb.toString();
	}
	
	
//	private String toKorean(String str, int size)  {
//
//	    if (str == null || "".equals(str)) {
//	      return "";
//	    }
//	    
//	    if(str.length() == size) {
//	    	String s = new String(str.getBytes("8859_1"), "EUC-KR");
//	    	if ( Character.getType(s.charAt(s.length()-1)) == 28 ) {
//	    		str = str.substring(0,size-1);
//	    	}
//	    }
//	    
//	    return new String(str.getBytes("8859_1"), "EUC-KR");
//	}
	
}
