package biz.cms_OneBarcode;


import java.util.HashMap;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import biz.cms_OneBarcode.OneBarcodeIrtAction;
import biz.comm.COMMBiz;

import biz.cms_OneBarcode.OneBarcodeData;

public class OneBarcodeIrtProtocol {
	private static Logger logger = Logger.getLogger(OneBarcodeIrtAction.class);
	
	public String getRcvOneBarcodeIrtDATA(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		String ret = "";
		int nlens[] = {2};
		String strHeaders[] = {		"INQ_TYPE"		};		// INQ Type(INQ 종별)
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		ret = (String)hm.get("INQ_TYPE");
		
		return ret;
	}

	// POS에서 받은 전문 파싱 
	public HashMap<String, String> getParseOneBarcode(String rcvBuf ){
		HashMap<String, String> hm = new HashMap<String, String>();	
		final int nlens[] = {2, 16};
		

		final String strHeaders[] = {"INQ_TYPE", "MOBILE_BARCODE"};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);

		
		return hm;
	}	
	
	/* 응답 전문 파싱 */
	public HashMap<String, String> getParseOneBarcodeRsp(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		
		hm = COMMBiz.getParseDataMultibyte(OneBarcodeData.nlens, OneBarcodeData.strHeaders, rcvBuf );
		
		return hm;
	}
}
