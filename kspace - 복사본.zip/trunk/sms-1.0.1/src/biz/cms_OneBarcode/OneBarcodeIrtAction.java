package biz.cms_OneBarcode;

import java.net.Socket;
import java.util.HashMap;

import org.apache.log4j.Logger;

//import biz.cms_OneBarcode.CashBeeIrtAction;
//import biz.cms_OneBarcode.CashBeeIrtConveyer;
import biz.cms_OneBarcode.OneBarcodeIrtProtocol;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;


public class OneBarcodeIrtAction extends ServerAction{
	private static Logger logger = Logger.getLogger(OneBarcodeIrtAction.class);
	
	private String server_ip = "";
	private int server_port = 0;
	

	/*
	 * port : 9039 (포트 오픈 하는곳 ?)
	 * @see kr.fujitsu.com.ffw.daemon.net.server.ServerAction#execute(kr.fujitsu.com.ffw.daemon.net.ActionSocket)
	 */
	
	public void execute(ActionSocket actionSocket) throws Exception {
		int ret = 0;
		
		String inq_type = "";
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
	
		
		Socket extClntSock = null;
		COMMLog df = new COMMLog();
		
	
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		
		OneBarcodeIrtProtocol protocol = new OneBarcodeIrtProtocol();
		OneBarcodeIrtConveyer conveyer = null;
		
		this.server_ip = PropertyUtil.findProperty("communication-property", "ONEBARCODE_COMM_IP");		
		this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "ONEBARCODE_COMM_PORT"));
		
		
		try {
			
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());
			
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress()
					.getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,
					"ONEBARCODE");
			
			df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
			
			// 공통헤더 정보 가져온다.
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			
			// 공통헤더 정보에서 irt 전문인지 확인 한다.(POS에서 06으로 보냄)
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}
			   
			// 바디를 정보 가져온다.
			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			
			logger.info("rcvDataBuf <<<  " + rcvDataBuf);
			
			// 통신구분자를 가져온다.
			inq_type = protocol.getRcvOneBarcodeIrtDATA(rcvDataBuf);
			
			
			logger.info("inq_type <<<  " + inq_type);
			
			if (inq_type.equals(OneBarcodeData.INQ_TYPE_REQ)){
				df.execute("OneBarcodeIrt-coupon Request");
				
				hmData = protocol.getParseOneBarcode(rcvDataBuf);
				
				// 모바일로 데이터를 보냄..
				extClntSock = new Socket(this.server_ip, this.server_port);
				
				conveyer= new OneBarcodeIrtConveyer(extClntSock, df);
				
				// POS 보낼 전문을 결과 값으로 받는다.(본문)
				dataMsg = conveyer.getOneBarcode(hmCommon, hmData);
				
				
				df.execute("dataMsg " + dataMsg);
			}
			
		}catch(Exception e) {
			ret = 29;
			retValue = "[ERROR]2:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			if( extClntSock != null ) {
				extClntSock.close();
			}
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			df.CommLogger("[sms>po`s] SEND[" + totalMsg.getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + totalMsg + "]");
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(totalMsg)) {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		}catch(Exception e) {
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("CashBeeIRT", retValue);
		}
	}
}
