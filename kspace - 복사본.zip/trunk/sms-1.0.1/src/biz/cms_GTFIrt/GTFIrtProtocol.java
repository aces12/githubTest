package biz.cms_GTFIrt;

import java.util.HashMap;
import java.util.regex.Pattern;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.AES;
import biz.comm.COMMBiz;

public class GTFIrtProtocol {
	
	private static Logger logger = Logger.getLogger(GTFIrtAction.class);
	
	
	/***
	 * getGTFIrtInq
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	
	public int getGTFIrtInq(String rcvBuf){		
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};
	
		String strHeaders[] = {"INQ_TYPE"  };			  // INQ Type(INQ 종별)    
							
		//////logger.info("▶ Receive Data: " + rcvBuf );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if (Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE"))){
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		return ret;
	}
	
	public int getGTFIrtLen(String rcvBuf){		
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};
	
		String strHeaders[] = {"INQ_TYPE"  };			  // INQ Type(INQ 종별)    
							
		//////logger.info("▶ Receive Data: " + rcvBuf );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if (Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE"))){
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		return ret;
	}
	 
	 
	/***
	 * getRcvGTAIrtDATA
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	
	public int getRcvGTAIrtDATA(String rcvBuf){		
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {5 , 2, 10, 3};
	
		String strHeaders[] = {      				
				"LENGTH", // 전문 길이
				"EDI", // 업무 구분
				"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))
				"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)  
			};		
		
		//////logger.info("▶ Receive Data: " + rcvBuf );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if (Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE"))){
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		return ret;
	}

	

	
	@SuppressWarnings("unchecked")
	public HashMap<String, String> getParseGTFRsp(String rcvBuf ){ 
		HashMap<String, String> hm = new HashMap<String, String>();

		hm = COMMBiz.getParseDataMultibyte(GTFData.nlensGTF, GTFData.strHeadersGTF, rcvBuf );//hm = GTFData.getParseDataGTFMultibyte(GTFData.nlens100, GTFData.strHeaders100, rcvBuf , GTFData.nlensG100, GTFData.strHeadersG100);
		
		return hm;
	}	
	
	
	@SuppressWarnings("unchecked")
	public HashMap<String, String> getParseGTFRsp(String rcvBuf , int jobType){ 
		HashMap<String, String> hm = new HashMap<String, String>();
			

		String len = rcvBuf.substring(0, 5);
		int length = Integer.parseInt(len);
	
		switch(jobType){
			case GTFData.RSP100:{
				if (length != 644){		//오류 코드 데이터 인경우 오류메시지 까지만 파싱하여 pos 로 송부 
					hm = COMMBiz.getParseDataMultibyte(GTFData.nlensGTFFault, GTFData.strHeadersGTFFault, rcvBuf );
					hm.put("SHOP_NAME","0000000000000000000000000000000000000000");
					hm.put("SEQUENCE_COUNT","0000");
					hm.put("EXPORT_EXPIRY_DATE","00000000");
					hm.put("RCT_NO","000000000000000000000000000000");
					hm.put("","");
					hm.put("BEFORE_REFUND_YN","0");
					hm.put("PAYMENT_AMOUNT","000000000");
					hm.put("EXPORT_APPROVAL_NUM","000000000000000000000000000000");
					hm.put("BEFORE_LIMIT_AMOUNT","0000000000");
					hm.put("MCH_SEND_UNIQ_NO","0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
					
					hm.put("COMMODITY_NUM","000");
					hm.put("SCT_DIV","0");
					hm.put("COMMODITY_CD","00");
					hm.put("COMMODITY_CONT","00000000000000000000000000000000000000000000000000");
					hm.put("VOLUME","0000");
					hm.put("","");
					hm.put("UNIT_PRICE","000000000");
					hm.put("SELL_PRICE","000000000");
					hm.put("VAT","00000000");
					hm.put("SCT","00000000");
					hm.put("ET","00000000");
					hm.put("","");						
					hm.put("FFVST","00000000");
					hm.put("EXTRA","0000000000000000");					
					
					hm.remove("KOR_DOMESTIC_CITIZEN");
					hm.remove("KOR_IDENTITY");				
					hm.remove("EXTRA");						
					
				}else{
					hm = COMMBiz.getParseDataMultibyte(GTFData.nlensGTF, GTFData.strHeadersGTF, rcvBuf );
					hm.remove("KOR_DOMESTIC_CITIZEN");
					hm.remove("KOR_IDENTITY");
					String tmp = hm.get("MCH_SEND_UNIQ_NO");
					//logger.info("▶ MCH_SEND_UNIQ_NO -substring before▶[" + tmp +"]" +"LENGTH="+tmp.length());
					String ttmp = tmp.substring(0, 21);
					//logger.info("▶ MCH_SEND_UNIQ_NO -substring after▶[" + ttmp +"]" +"LENGTH="+ttmp.length() );
					hm.put("MCH_SEND_UNIQ_NO", ttmp);
					hm.remove("EXTRA");								
				}			
				break;
			}

			case GTFData.RSP300:{
				if (length != 644){		//오류 코드 데이터 인경우 오류메시지 까지만 파싱하여 pos 로 송부 
					hm = COMMBiz.getParseDataMultibyte(GTFData.nlensGTFFault, GTFData.strHeadersGTFFault, rcvBuf );
					hm.put("SHOP_NAME","0000000000000000000000000000000000000000");
					hm.put("SEQUENCE_COUNT","0000");
					hm.put("EXPORT_EXPIRY_DATE","00000000");
					hm.put("RCT_NO","000000000000000000000000000000");
					
					hm.put("BEFORE_REFUND_YN","0");
					hm.put("PAYMENT_AMOUNT","000000000");
					hm.put("EXPORT_APPROVAL_NUM","000000000000000000000000000000");
					hm.put("BEFORE_LIMIT_AMOUNT","0000000000");
					hm.put("MCH_SEND_UNIQ_NO","0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
					
					hm.put("COMMODITY_NUM","000");
					hm.put("SCT_DIV","0");
					hm.put("COMMODITY_CD","00");
					hm.put("COMMODITY_CONT","00000000000000000000000000000000000000000000000000");
					hm.put("VOLUME","0000");
					
					hm.put("UNIT_PRICE","000000000");
					hm.put("SELL_PRICE","000000000");
					hm.put("VAT","00000000");
					hm.put("SCT","00000000");
					hm.put("ET","00000000");
										
					hm.put("FFVST","00000000");
					hm.put("EXTRA","0000000000000000");					
					
					hm.remove("KOR_DOMESTIC_CITIZEN");
					hm.remove("KOR_IDENTITY");
					hm.remove("RCT_NO");
					hm.remove("PAYMENT_AMOUNT");
					hm.remove("EXPORT_APPROVAL_NUM");
					hm.remove("BEFORE_LIMIT_AMOUNT");				
			
					hm.remove("EXTRA");					
					
				}else{				
					hm = COMMBiz.getParseDataMultibyte(GTFData.nlensGTF, GTFData.strHeadersGTF, rcvBuf );
					hm.remove("KOR_DOMESTIC_CITIZEN");
					hm.remove("KOR_IDENTITY");
					hm.remove("RCT_NO");
					hm.remove("PAYMENT_AMOUNT");
					hm.remove("EXPORT_APPROVAL_NUM");
					hm.remove("BEFORE_LIMIT_AMOUNT");				
					String tmp = hm.get("MCH_SEND_UNIQ_NO");				
					String ttmp = tmp.substring(0, 21);				
					hm.put("MCH_SEND_UNIQ_NO", ttmp);				
					hm.remove("EXTRA");
				}
				break;
			}
			case GTFData.RSP900:{
				hm = COMMBiz.getParseDataMultibyte(GTFData.nlens900GTF, GTFData.strHeaders900GTF, rcvBuf );
//				hm.remove("RESPONSE_CD");
//				hm.remove("RESPONSE_MESSAGE");
//				hm.remove("SHOP_NAME");
				
				return hm;
			}								
		}						
		return hm;
	}



	public HashMap<String, String> getParseCommH(String rcvBuf ){
		HashMap<String, String> hm = new HashMap<String, String>();	
		final int nlens[] = { 6,2,5,4,4,
				8,8,6,3,4				};
		

		final String strHeaders[] = { 
				"MSG_LEN",
				"MSG_TYPE",
				"STORE_CD",
				"POS_NO",
				"TRAN_NO",
				
				"TRAN_YMD",
				"SYS_YMD",
				"SYS_HMS",
				"ERR_CD",
				"COM_CD"				
				};
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);

		
		return hm;
	}	
	
	
	
	
	public HashMap<String, String> getParseGTF(String rcvBuf , int reqType) throws Exception{
		HashMap<String, String> hm = new HashMap<String, String>();	
		switch(reqType){
			case GTFData.REQ101:{// 승인요청
				//20170525 KSN 여권번호 암호화 적용 START
				if(rcvBuf.length() == 315){ //여권번호 평문전달인 경우
					hm = COMMBiz.getParseData(GTFData.nlens101, GTFData.strHeaders101, rcvBuf);
				}else if(rcvBuf.length() == 419){ //여권번호 암호화전달인 경우
					String passport_num = "";
					hm = COMMBiz.getParseData(GTFData.nlens101_enc, GTFData.strHeaders101_enc, rcvBuf); //복호화해서 hm에 다시 담아줘야함. (AES128)
					try{
						String passport_num_enc = (String)hm.get("PASSPORT_NUM");
						passport_num = (new AES()).c(passport_num_enc.trim()); //여권번호 AES128 복호화
						hm.put("PASSPORT_NUM", passport_num);
					}catch(Exception e){
						logger.error("GTFIrtProtocol.java ::: 101[pos>sms] decrypt fail, [rcvBuf length] : " + rcvBuf.length() +", [errmsg] : " + e.getMessage().toString());
					}
				}
				//20170525 KSN 여권번호 암호화 적용 END
				//hm = COMMBiz.getParseData(GTFData.nlens101, GTFData.strHeaders101, rcvBuf);	//hm = GTFData.getParseDataGTF(GTFData.nlens101, GTFData.strHeaders101, rcvBuf , GTFData.nlensG101,GTFData.strHeadersG101);
				break;
			}
			case GTFData.REQ301:{//취소요청
				hm = COMMBiz.getParseData(GTFData.nlens301, GTFData.strHeaders301, rcvBuf);	//hm = GTFData.getParseDataGTF(GTFData.nlens301, GTFData.strHeaders301, rcvBuf , GTFData.nlensG301,GTFData.strHeadersG301);
				break;
			}
			case GTFData.REQ901:{//개시요청
				hm = COMMBiz.getParseData(GTFData.nlens901, GTFData.strHeaders901, rcvBuf);	//hm = GTFData.getParseDataGTF(GTFData.nlens901, GTFData.strHeaders901, rcvBuf);
				break;
			}

		}
		return hm;
	}


	
}


























	
































