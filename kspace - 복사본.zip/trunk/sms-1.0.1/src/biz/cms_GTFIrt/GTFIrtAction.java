package biz.cms_GTFIrt;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.net.Socket;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.core.config.repository.telegram.MessageForm;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

/* ******************************************************************************************************
 *******************************************************************************************************/
public class GTFIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(GTFIrtAction.class);
		
	private String gtf_server_ip = "";
	private int gtf_server_port = 0;
	
	/**
	 * Receive data from SC through 9022 PORT(SC로부터 데이타를 9022 PORT (internal14030)로 받음).
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 * @author neo0531
	 */

	
	public void execute(ActionSocket actionSocket) throws Exception {		
		int ret = 0;
		int inq_type = 0;	
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		StringBuffer sb = null;
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		GTFIrtProtocol protocol = new GTFIrtProtocol();
		COMMLog df = new COMMLog();
		
		Socket extClntSock = null;
		GTFIrtConveyer GTFConveyer = null;

		this.gtf_server_ip = PropertyUtil.findProperty("communication-property", "GTF_SERVER_IP");
		this.gtf_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "GTF_SERVER_PORT"));
		
		try {	// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());				
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
					
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,	"GTFIRT");
			
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 확인한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}			
			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			inq_type = protocol.getGTFIrtInq(rcvDataBuf);
			
			switch(inq_type) {			
				// 101: 즉시환급승인요청 
				case GTFData.INQ101:{
					df.execute("Approval cash Rebate GTF");	
					
					hmData = protocol.getParseGTF(rcvDataBuf, GTFData.REQ101);					
					sb = null;
					sb = new StringBuffer(rcvBuf);					
					df.CommLogger("101[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");
					
					extClntSock = new Socket(gtf_server_ip, gtf_server_port);
					GTFConveyer = new GTFIrtConveyer(extClntSock, df);										
					
					//20170602 KSN 여권번호 암호화 적용 START
					boolean encYn = false;
					if(rcvDataBuf.length() == 419){ 
						encYn = true; 
					}else if(rcvDataBuf.length() == 315){
						encYn = false;
					}else{}
					dataMsg = GTFConveyer.getGTF101(hmCommon, hmData, encYn); 
					//dataMsg = GTFConveyer.getGTF101(hmCommon, hmData); 
					//20170602 KSN 여권번호 암호화 적용 END			
				
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					}break;				
				// 301: 즉시환급 취소요청
				case GTFData.INQ301:{
					df.execute("cancel cash Rebate GTF");
					hmData = protocol.getParseGTF(rcvDataBuf ,GTFData.REQ301);
					sb = null;
					sb = new StringBuffer(rcvBuf);					
					df.CommLogger("301[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");										
					
					extClntSock = new Socket(gtf_server_ip, gtf_server_port);
					GTFConveyer = new GTFIrtConveyer(extClntSock, df);
										
					dataMsg = GTFConveyer.getGTF301(hmCommon, hmData);
										
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					}break;

				// 901: 개시요청
				case GTFData.INQ901:{					
					df.execute("FIRST Start GTF Cash rebate");
					hmData = protocol.getParseGTF(rcvDataBuf ,GTFData.REQ901);
					sb = null;
					sb = new StringBuffer(rcvBuf);					
					df.CommLogger("901[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");										
					
					extClntSock = new Socket(gtf_server_ip, gtf_server_port);
					GTFConveyer = new GTFIrtConveyer(extClntSock, df);
					
					int rcvIrtDataLen = rcvDataBuf.length();

					dataMsg = GTFConveyer.getGTF901(hmCommon, hmData , rcvIrtDataLen);					
					
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);					
					}break;
							
				default:
					df.CommLogger("▶ INQ Code(INQ 종별 코드):   [" + inq_type + "]" + rcvBuf.length());
					ret = 99;
					break;
			}
		}
		catch (Exception e) 
		{
			ret = 29; // 029=HOST APPL ERR
			retValue = "[ERROR]2:" + e.getMessage();
			logger.error("=====▶ " + retValue);
			df.CommLogger("▶ " + retValue);
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
					
			df.CommLogger("================ 4-2) POS<-SMS 응답전문 ===================");
			df.CommLogger("전문길이=[" + totalMsg.getBytes().length + "]");
			df.CommLogger("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
			df.CommLogger("전문내용=[" + totalMsg + "]");
			
			// Send Response Data (응답 데이타 전송)
			if (actionSocket.send(totalMsg)) 
			{
				df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
			} 
			else 
			{
				df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		}
		catch (Exception e) 
		{
			retValue = "[ERROR]4" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}
		finally 
		{
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("GTFIRT", retValue);
			
			if (!extClntSock.isClosed()) 
			{
				extClntSock.close();
			}
		}
	}
	
}
	
	
	
	
	
	
	
////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////unit test code	////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////		
//
//		public void exeTest(String rcvBuf){//TestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTest
//	
//			int ret = 0;
//			int inq_type = 0;	
//			String sendMsg = "";
//			String dataMsg = "";
//			
//			String rcvDataBuf = "";
//			String retValue = "OK!";
//			StringBuffer sb = null;
//			HashMap<String, String> hmCommon = new HashMap<String, String>();
//			HashMap<String, String> hmData = new HashMap<String, String>();
//			GTFIrtProtocol protocol = new GTFIrtProtocol();
//			COMMLog df = new COMMLog();
//			
//			Socket extClntSock = null;
//			GTFIrtConveyer GTFConveyer = null;
//			
//			//Set Work Start Time(업무시작시간설정)
//			df.setStartTime();
//			//df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),String.valueOf(actionSocket.getSocket().getPort()), logger,"GTFIRT");
//			//df.execute("Approval cash Rebate GTF");
//			try {	// Data received from SC(SC로부터 받은 데이타)
//				if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
//				// Check MsgType(MsgType 확인)
//				/////////////////////////////////hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);				
//				String telegram = rcvBuf.substring(0,50);
//				hmCommon = protocol.getParseCommH(telegram);
//				// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 확인한다).
//				if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
//					return;
//				}
//				
//				rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
//				inq_type = protocol.getGTFIrtInq(rcvDataBuf);
//				switch(inq_type) {			
//					// 101: 즉시환급승인요청 
//					case GTFData.INQ101:{
//						//df.execute("Approval cash Rebate GTF");											
//						hmData = protocol.getParseGTF(rcvDataBuf,GTFData.REQ101);
//						sb = null;
//						sb = new StringBuffer(rcvBuf);					
//						//df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[DOC_CODE:" + inq_type + "]:[" + sb.toString() + "]");
//						
//						//extClntSock = new Socket(gtf_server_ip, gtf_server_port);
//						//GTFConveyer = new GTFIrtConveyer(extClntSock, df);
//	
//						int rcvIrtDataLen = rcvDataBuf.length();
//						dataMsg = testgetGTF101(hmCommon, hmData ,rcvIrtDataLen,df);
//						 
//						ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
//						dataMsg = dataMsg.substring(2);
//						}break;				
//					// 301: 즉시환급 취소요청
//					case GTFData.INQ301:{
//						df.execute("cancel cash Rebate GTF");
//						hmData = protocol.getParseGTF(rcvDataBuf ,GTFData.REQ301);
//						sb = null;
//						sb = new StringBuffer(rcvBuf);					
//						//df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + sb.toString() + "]");										
//						
//						//extClntSock = new Socket(gtf_server_ip, gtf_server_port);
//						//GTFConveyer = new GTFIrtConveyer(extClntSock, df);
//						
//						int rcvIrtDataLen = rcvDataBuf.length();
//						dataMsg = testgetGTF301(hmCommon, hmData, rcvIrtDataLen,df);
//						//dataMsg = GTFConveyer.getGTF301(hmCommon, hmData, rcvIrtDataLen);					
//	
//						ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
//						dataMsg = dataMsg.substring(2);
//						}break;
//	
//					// 901: 개시요청
//					case GTFData.INQ901:{
//						//df.execute("Start GTF Cash rebate");
//						hmData = protocol.getParseGTF(rcvDataBuf ,GTFData.REQ901);
//						sb = null;
//						sb = new StringBuffer(rcvBuf);					
//						//df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + sb.toString() + "]");										
//						
//						//extClntSock = new Socket(gtf_server_ip, gtf_server_port);
//						//GTFConveyer = new GTFIrtConveyer(extClntSock, df);
//						int rcvIrtDataLen = rcvDataBuf.length();
//	
//						//dataMsg = testgetGTF901(hmCommon, hmData , rcvIrtDataLen);
//						//dataMsg = GTFConveyer.getGTF901(hmCommon, hmData , rcvIrtDataLen);					
//	
//						ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
//						dataMsg = dataMsg.substring(2);					
//						}break;
//					
//					default:
//						//df.CommLogger("▶ INQ Code(INQ 종별 코드):   [" + inq_type
//						//		+ "]" + rcvBuf.length());
//						ret = 99;
//						break;
//				}
//			}
//			catch (Exception e) 
//			{
//				ret = 29; // 029=HOST APPL ERR
//				retValue = "[ERROR]2:" + e.getMessage();
//				//df.CommLogger("▶ " + retValue);
//			}
//			
//			try {
//				// Make Response Message Data(응답 전문데이타 만들기)
//				sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
//				String totalMsg = sendMsg + dataMsg;
//						
//				df.CommLogger("================ 4-2) POS<-SMS 응답전문 ===================");
//				df.CommLogger("전문길이=[" + totalMsg.getBytes().length + "]");
//				df.CommLogger("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
//				df.CommLogger("전문내용=[" + totalMsg + "]");
//				
//				System.out.println(totalMsg);
//				// Send Response Data (응답 데이타 전송)
//				//if (actionSocket.send(totalMsg)) 
//				//{
//				//	df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
//				//} 
//				//else 
//				//{
//				//	df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] ERROR");
//				//}
//			}
//			catch (Exception e) 
//			{
//				retValue = "[ERROR]4" + e.getMessage();
//				df.CommLogger("▶ " + retValue);
//			}
//			finally 
//			{
//				// IRT Work Finish Log(IRT 업무 종료 로그)
//				df.close("GTFIRT", retValue);
//				
//			}
//		}
//		
//	
//	
//	private String makeSendDataGTF(HashMap<String, String> hm,int jobType) {
//		StringBuffer sb = new StringBuffer();		
//		
//		switch(jobType){
//		case GTFData.REQ101:{
//			for (int i = 0; i < GTFData.nlens101GTF.length; i++) {
//				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders101GTF[i].toString()), GTFData.nlens101GTF[i]);
//			}						
//			break;
//		}
//		case GTFData.REQ301:{
//			for (int i = 0; i < GTFData.nlens301GTF.length; i++) {
//				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders301GTF[i].toString()), GTFData.nlens301GTF[i]);
//				}
//			break;
//		}
//		
//		case GTFData.REQ901:{
//			for (int i = 0; i < GTFData.nlens901GTF.length; i++) {
//				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders901GTF[i].toString()), GTFData.nlens901GTF[i]);
//				}				
//			break;
//		}				
//		case GTFData.RSP100:{
//			hm.put("RESPONSE_CD", "100");
//			hm.put("RESPONSE_MESSAGE", "정상처리되었습니다.                                        .");
//			hm.put("SHOP_NAME", "위드미 성수 푸조비즈빌딩점             .");
//			hm.put("EXPORT_EXPIRY_DATE", "20170102");
//			hm.put("PAYMENT_AMOUNT", "0000990000");
//			hm.put("EXPORT_APPROVAL_NUM", "303030303030303030303030303030");
//			hm.put("BEFORE_LIMIT_AMOUNT", "0010000000");
//			hm.put("MCH_SEND_UNIQ_NO", "212121212121212121212");
//			hm.put("SCT", "88888888");
//			hm.put("ET", "77777777");
//			hm.put("FFVST", "66666666");
//						
//			
//			for (int i = 0; i < GTFData.nlens100GTF.length; i++) {
//				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders100GTF[i].toString()), GTFData.nlens100GTF[i]);
//				}				
//			break;
//		}	
//	}		
//
//		return sb.toString();
//}		
//
//	
//	private String getDataLen(int rcvIrtDataLen){
//		int  sendGTFDataLen = rcvIrtDataLen -2 + 5 + 2 +10 + 21;  //토탈길이 - InqType(2) + 길이필드(5) +EDI(2) + version(10) + credit(21) 
//		String str_sendGTFDataLen = String.valueOf(sendGTFDataLen);
//		return str_sendGTFDataLen;
//	}
//	
//	private String getDataLen901(int rcvIrtDataLen){
//		int  sendGTFDataLen = rcvIrtDataLen -2 + 5 + 2 +10 ;  //토탈길이 - InqType(2) + 길이필드(5) +EDI(2) + version(10)  
//		String str_sendGTFDataLen = String.valueOf(sendGTFDataLen);
//		return str_sendGTFDataLen;
//	}
//	
//	public HashMap<String, String> getParseGTFRsp(String rcvBuf , int jobType){ 
//		HashMap<String, String> hm = new HashMap<String, String>();
//				
//		switch(jobType){
//			case GTFData.RSP100:{
//				hm = COMMBiz.getParseDataMultibyte(GTFData.nlens100GTF, GTFData.strHeaders100GTF, rcvBuf );//hm = GTFData.getParseDataGTFMultibyte(GTFData.nlens100, GTFData.strHeaders100, rcvBuf , GTFData.nlensG100, GTFData.strHeadersG100);
//				break;
//			}
//
//			case GTFData.RSP300:{
//				hm = COMMBiz.getParseDataMultibyte(GTFData.nlens300GTF, GTFData.strHeaders300GTF, rcvBuf );//hm = GTFData.getParseDataGTFMultibyte(GTFData.nlens300, GTFData.strHeaders300, rcvBuf , GTFData.nlensG300, GTFData.strHeadersG300);
//				break;
//			}
//			case GTFData.RSP900:{
//				hm = COMMBiz.getParseDataMultibyte(GTFData.nlens900GTF, GTFData.strHeaders900GTF, rcvBuf );//hm = GTFData.getParseDataGTFMultibyte(GTFData.nlens900, GTFData.strHeaders900, rcvBuf );
//				break;
//			}				
//					
//		}				
//		
//		return hm;
//	}
//
//	private String makeSendDataGTFRsp(HashMap<String, String> hm, int rspType) {
//		StringBuffer sb = new StringBuffer();				
//		switch(rspType){
//		case GTFData.RSP100:{
//			for (int i = 0; i < GTFData.nlens100.length; i++) {
//				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders100[i].toString()), GTFData.nlens100[i]);
//			}	
//			break;
//			}
//		case GTFData.RSP300:{			
//			for (int i = 0; i < GTFData.nlens300.length; i++) {
//				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders300[i].toString()), GTFData.nlens300[i]);
//			}				
//			break;
//			}
//		case GTFData.RSP900:{				
//			for (int i = 0; i < GTFData.nlens900.length; i++) {
//				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders900[i].toString()), GTFData.nlens900[i]);
//			}							
//			break;
//		}
//		default :{
//				//do nothing
//			}
//		}
//		return sb.toString();
//	}
//		
//	//test///////////////////////////////////////////////////////////////////////////
//public String testgetGTF101(HashMap<String, String> hmComm, HashMap<String, String> hm , int rcvIrtDataLen , COMMLog df) throws Exception {
//		
//		HashMap<String,String> hmRecv = new HashMap<String,String>();
//		
//		String sendMsg = "";		// GTF로 보낼 송신 전문
//		String recvBuf = "";		// GTF에서 받을 응답 전문
//		String dataMsg = "";		// POS로 보낼 응답 전문
//		String ret = "00";
//		StringBuffer sb = null;
//		
//		try {
//			//actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.GTF_FILTER)));	
//			//SMS->GTF SEND 에필요한 데이터 가공 
//			String tmpInq = hm.get("INQ_TYPE");
//			hm.remove("INQ_TYPE");
//			hm.put("LENGTH",  StringUtil.lPad(getDataLen(rcvIrtDataLen), 5, "0") );
//			hm.put("EDI","WM");
//			hm.put("VERSION","WM16050101");
//			hm.put("CREDIT_CARD_NUM","000000000000000000000");									
//			
//			sendMsg = makeSendDataGTF(hm,  GTFData.REQ101 );
//			
//			sb = new StringBuffer(sendMsg);			
//			//df.CommLogger("101[sms>gtf] to send[" + sb.length() + "]:[" + sb.toString() + "]");
//
//			//if (actSock.send(sendMsg)) {
//			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] OK");
//			//} else {
//			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] ERROR");
//			//	throw new Exception("GTF Server is no response");
//			//}
//			
//			//recvBuf = ((String) actSock.receive());
//			//GTF 에서 오는 승인응답 
//			//recvBuf ="00535WMWM16050101100BBBBBBBBBBBBBBBBBBBBNAAAAAAAAAAaaaaaaaaaaAAAAAAAAAAEEEEEEEEEEEEEE4444999999999888888882ZZZZZZZZZZZZZZZZZZZZZN4040404040404040404040404040404040404040242424242424242424242424333F7705311604101006060606060606060606060606060606060606060606060606060606060604040404040404040404040404040404040404040000188888888303030303030303030303030303030Y9999999993030303030303030303030303030301010101010212121212121212121212002122505050505050505050505050505050505050505050505050504444999999999aaaaaaaaa88888888ffffffff88888888ffffffff"; 
//			//for test neo0531
//			recvBuf = makeSendDataGTF(hm,  GTFData.RSP100 );
//			
//			
//			sb = null;
//			sb = new StringBuffer(recvBuf);			
//			df.CommLogger("[GTF>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
//			
//			hmRecv = getParseGTFRsp(recvBuf , GTFData.RSP100);					
//
//			hmRecv.remove("LENGTH");
//			hmRecv.put("INQ_TYPE", tmpInq);
//			hmRecv.remove("EDI");
//			hmRecv.remove("VERSION");
//			hmRecv.remove("CREDIT_CARD_NUM");
//
//			
////			df.CommLogger(" >>>>>>>>>>>>> INQ_TYPE : " + (String)hm.get("INQ_TYPE"));
////			df.CommLogger(" >>>>>>>>>>>>> TR_GB : " + (String)hm.get("TR_GB"));
//		}catch(Exception e) {
////			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
//			ret = "29";
//			throw e;
//		}finally {
//			//actSock.close();
//			dataMsg = ret + makeSendDataGTFRsp(hmRecv, GTFData.RSP100);			
//			df.CommLogger("★ make(to POS): " + dataMsg);
//		}
//		
//		return dataMsg;
//		}
//
//		
//	public String testgetGTF301(HashMap<String, String> hmComm, HashMap<String, String> hm , int rcvIrtDataLen , COMMLog df) throws Exception {
//	
//		HashMap<String,String> hmRecv = new HashMap<String,String>();
//		
//		String sendMsg = "";		// GTF로 보낼 송신 전문
//		String recvBuf = "";		// GTF에서 받을 응답 전문
//		String dataMsg = "";		// POS로 보낼 응답 전문
//		String ret = "00";
//		StringBuffer sb = null;
//		
//		try {
//			//actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.GTF_FILTER)));					
//			//		SMS->GTF SEND 에필요한 데이터 가공 
//			//SMS->GTF SEND 에필요한 데이터 가공 
//			String tmpInq = hm.get("INQ_TYPE");
//			hm.remove("INQ_TYPE");
//			hm.put("LENGTH",  StringUtil.lPad(getDataLen(rcvIrtDataLen), 5, "0") );
//			hm.put("EDI","WM");
//			hm.put("VERSION","WM16050101");
//			hm.put("CREDIT_CARD_NUM","000000000000000000000");									
//			
//			sendMsg = makeSendDataGTF(hm,  GTFData.REQ301 );
//			
//			sb = new StringBuffer(sendMsg);			
//			df.CommLogger("901[sms>gtf] to send[" + sb.length() + "]:[" + sb.toString() + "]");
//			
//			//if (actSock.send(sendMsg)) {
//			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] OK");
//			//} else {
//			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] ERROR");
//			//	throw new Exception("GTF Server is no response");
//			//}
//			
//			//recvBuf = ((String) actSock.receive());
//			//GTF 에서 오는 취소응답 
//			recvBuf ="00456WMWM16050101100BBBBBBBBBBBBBBBBBBBBNAAAAAAAAAAaaaaaaaaaaAAAAAAAAAAEEEEEEEEEEEEEE4444999999999888888882ZZZZZZZZZZZZZZZZZZZZZN4040404040404040404040404040404040404040242424242424242424242424333F7705311604101006060606060606060606060606060606060606060606060606060606060604040404040404040404040404040404040404040000188888888Y212121212121212121212002122505050505050505050505050505050505050505050505050504444999999999aaaaaaaaa88888888ffffffff88888888ffffffff"; 
//	
//			sb = null;
//			sb = new StringBuffer(recvBuf);			
//			df.CommLogger("[GTF>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
//			
//			hmRecv = getParseGTFRsp(recvBuf, GTFData.RSP300);							
//	
//			hmRecv.remove("LENGTH");
//			hmRecv.put("INQ_TYPE", tmpInq);
//			hmRecv.remove("EDI");
//			hmRecv.remove("VERSION");
//			hmRecv.remove("CREDIT_CARD_NUM");
//	
//			
//	//		df.CommLogger(" >>>>>>>>>>>>> INQ_TYPE : " + (String)hm.get("INQ_TYPE"));
//	//		df.CommLogger(" >>>>>>>>>>>>> TR_GB : " + (String)hm.get("TR_GB"));
//		}catch(Exception e) {
//	//		df.CommLogger("▶ [ERROR]1: " + e.getMessage());
//			ret = "29";
//			throw e;
//		}finally {
//			//actSock.close();
//			dataMsg = ret + makeSendDataGTFRsp(hmRecv, GTFData.RSP300);
//			df.CommLogger("★ make(to POS): " + dataMsg);
//		}
//		
//		return dataMsg;
//	}		
//	
//	
//	
//
//
//	public String testgetGTF901(HashMap<String, String> hmComm, HashMap<String, String> hm , int rcvIrtDataLen , COMMLog df) throws Exception {
//		
//		HashMap<String,String> hmRecv = new HashMap<String,String>();
//		
//		String sendMsg = "";		// GTF로 보낼 송신 전문
//		String recvBuf = "";		// GTF에서 받을 응답 전문
//		String dataMsg = "";		// POS로 보낼 응답 전문
//		String ret = "00";
//		StringBuffer sb = null;
//		
//		try {
//			//actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.GTF_FILTER)));					
//			//		SMS->GTF SEND 에필요한 데이터 가공 
//			String tmpInq = hm.get("INQ_TYPE");
//			hm.remove("INQ_TYPE");	
//			hm.put("LENGTH",   StringUtil.lPad(getDataLen901(rcvIrtDataLen), 5, "0") );
//			hm.put("EDI","WM");
//			hm.put("VERSION","WM16050101");
//									
//			sendMsg = makeSendDataGTF(hm, GTFData.REQ901 );
//			
//			sb = new StringBuffer(sendMsg);			
//			df.CommLogger("901[sms>gtf] to send[" + sb.length() + "]:[" + sb.toString() + "]");
//			
//			//if (actSock.send(sendMsg)) {
//			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] OK");
//			//} else {
//			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] ERROR");
//			//	throw new Exception("GTF Server is no response");
//			//}
//			
//			//recvBuf = ((String) actSock.receive());
//			//개시응답
//			recvBuf ="00157WMWM160501019001048198557WMTEST0001YYYY05DD143722100정상처리되었습니다.                                        .위드미 성수 푸조비즈빌딩점             ."; 
//
//			sb = null;
//			sb = new StringBuffer(recvBuf);			
//			df.CommLogger("[GTF>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
//			
//			hmRecv = getParseGTFRsp(recvBuf, GTFData.RSP900);							
//
//			hmRecv.remove("LENGTH");
//			hmRecv.put("INQ_TYPE", tmpInq);
//			hmRecv.remove("EDI");
//			hmRecv.remove("VERSION");
//			hmRecv.remove("CREDIT_CARD_NUM");
//			
//		}catch(Exception e) {
////				df.CommLogger("▶ [ERROR]1: " + e.getMessage());
//			ret = "29";
//			throw e;
//		}finally {
//			//actSock.close();
//			dataMsg = ret + makeSendDataGTFRsp(hmRecv, GTFData.RSP900);
//			df.CommLogger("★ make(to POS): " + dataMsg);
//		}
//		
//		return dataMsg;
//	}	
//	
//
//////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////unit test code	////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////
//	
//
//	
//	
//}
//
//
/////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////   TEST  CODE   ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////
////public class GTFIrtAction extends ServerAction {
////	private static Logger logger = Logger.getLogger(GTFIrtAction.class);
////		
////	private String gtf_server_ip = "";
////	private int gtf_server_port = 0;
////	
////	/**
////	 * Receive data from SC through 9022 PORT(SC로부터 데이타를 9022 PORT (internal14030)로 받음).
////	 * @param ActionSocket
////	 * @return
////	 * @throws Exception
////	 * @author neo0531
////	 */
////
////	
////	public void execute(ActionSocket actionSocket) throws Exception {		
////		int ret = 0;
////		int inq_type = 0;	
////		String sendMsg = "";
////		String dataMsg = "";
////		String rcvBuf = "";
////		String rcvDataBuf = "";
////		String retValue = "OK!";
////		StringBuffer sb = null;
////		HashMap<String, String> hmCommon = new HashMap<String, String>();
////		HashMap<String, String> hmData = new HashMap<String, String>();
////		GTFIrtProtocol protocol = new GTFIrtProtocol();
////		COMMLog df = new COMMLog();
////		
////		Socket extClntSock = null;
////		GTFIrtConveyer GTFConveyer = null;
////
////		this.gtf_server_ip = PropertyUtil.findProperty("communication-property", "GTF_SERVER_IP");
////		this.gtf_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "GTF_SERVER_PORT"));
////		
////		try {	// Data received from SC(SC로부터 받은 데이타)
////			rcvBuf = ((String) actionSocket.receive());	
////			logger.info("[pos>sms] RECV:[" + rcvBuf + "]");
////			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
////					
////			// Set Work Start Time(업무시작시간설정)
////			df.setStartTime();
////			
////			df.setConnectionInfo(actionSocket.getSocket().getInetAddress()
////					.getHostAddress().toString(),
////					String.valueOf(actionSocket.getSocket().getPort()), logger,
////					"GTFIRT");
////			
////	
////			// Check MsgType(MsgType 확인)
////			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);			
////			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 확인한다).
////			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
////				return;
////			}			
////			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
////			inq_type = protocol.getGTFIrtInq(rcvDataBuf);
////			
////			switch(inq_type) {			
////				// 101: 즉시환급승인요청 
////				case GTFData.INQ101:{
////					df.execute("Approval cash Rebate GTF");		
////					hmData = protocol.getParseGTF(rcvDataBuf,GTFData.REQ101);					
////					sb = null;
////					sb = new StringBuffer(rcvBuf);					
////					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");
////					
//////neo0531 for test	extClntSock = new Socket(gtf_server_ip, gtf_server_port);
//////neo0531 for test	GTFConveyer = new GTFIrtConveyer(extClntSock, df);
////
////					int rcvIrtDataLen = rcvDataBuf.length();
////					//neo0531 for test	dataMsg = GTFConveyer.getGTF101(hmCommon, hmData ,rcvIrtDataLen);
////					dataMsg = testgetGTF101(hmCommon, hmData ,rcvIrtDataLen , df);
////					
////					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
////					dataMsg = dataMsg.substring(2);
////					}break;				
////				// 301: 즉시환급 취소요청
////				case GTFData.INQ301:{
////					df.execute("cancel cash Rebate GTF");
////					hmData = protocol.getParseGTF(rcvDataBuf ,GTFData.REQ301);
////					sb = null;
////					sb = new StringBuffer(rcvBuf);					
////					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");										
////					
////	//neo0531 for test					extClntSock = new Socket(gtf_server_ip, gtf_server_port);
////	//neo0531 for test					GTFConveyer = new GTFIrtConveyer(extClntSock, df);
////					
////					int rcvIrtDataLen = rcvDataBuf.length();
////					//neo0531 for test dataMsg = GTFConveyer.getGTF301(hmCommon, hmData, rcvIrtDataLen);
////					dataMsg = testgetGTF301(hmCommon, hmData, rcvIrtDataLen , df);					
////
////					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
////					dataMsg = dataMsg.substring(2);
////					}break;
////
////				// 901: 개시요청
////				case GTFData.INQ901:{					
////					df.execute("Start GTF Cash rebate");
////					hmData = protocol.getParseGTF(rcvDataBuf ,GTFData.REQ901);
////					sb = null;
////					sb = new StringBuffer(rcvBuf);					
////					df.CommLogger("901[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");										
////
////					//테스트 아이피로 소켓 동작 되지 않음 
////					gtf_server_ip = "10.149.206.254";//for	test
////					//gtf_server_port = 21002;
////					
/////*neo0531 for test*///					extClntSock = new Socket(gtf_server_ip, gtf_server_port);
/////*neo0531 for test*///					GTFConveyer = new GTFIrtConveyer(extClntSock, df);
////					df.CommLogger("Create Conveyer");
////					int rcvIrtDataLen = rcvDataBuf.length();
////
////					//dataMsg = GTFConveyer.getGTF901(hmCommon, hmData , rcvIrtDataLen);					
////					dataMsg = testgetGTF901(hmCommon, hmData , rcvIrtDataLen , df);
////
////					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
////					dataMsg = dataMsg.substring(2);					
////					}break;
////							
////				default:
////					df.CommLogger("▶ INQ Code(INQ 종별 코드):   [" + inq_type
////							+ "]" + rcvBuf.length());
////					ret = 99;
////					break;
////			}
////		}
////		catch (Exception e) 
////		{
////			ret = 29; // 029=HOST APPL ERR
////			retValue = "[ERROR]2:" + e.getMessage();
////			logger.error("=====▶ " + retValue);
////			df.CommLogger("▶ " + retValue);
////		}
////		
////		try {
////			// Make Response Message Data(응답 전문데이타 만들기)
////			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
////			String totalMsg = sendMsg + dataMsg;
////					
////			df.CommLogger("================ 4-2) POS<-SMS 응답전문 ===================");
////			df.CommLogger("전문길이=[" + totalMsg.getBytes().length + "]");
////			df.CommLogger("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
////			df.CommLogger("전문내용=[" + totalMsg + "]");
////			
////			// Send Response Data (응답 데이타 전송)
////			if (actionSocket.send(totalMsg)) 
////			{
////				df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
////			} 
////			else 
////			{
////				df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] ERROR");
////			}
////		}
////		catch (Exception e) 
////		{
////			retValue = "[ERROR]4" + e.getMessage();
////			df.CommLogger("▶ " + retValue);
////		}
////		finally 
////		{
////			// IRT Work Finish Log(IRT 업무 종료 로그)
////			df.close("GTFIRT", retValue);
////			
////			if (!extClntSock.isClosed()) 
////			{
////				extClntSock.close();
////			}
////		}
////	}
////	
////	
////	
////	
////	
////	
////	
////	
////	
////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////unit test code	////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////		
////
////		public void exeTest(String rcvBuf){//TestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTestTest
////	
////			int ret = 0;
////			int inq_type = 0;	
////			String sendMsg = "";
////			String dataMsg = "";
////			
////			String rcvDataBuf = "";
////			String retValue = "OK!";
////			StringBuffer sb = null;
////			HashMap<String, String> hmCommon = new HashMap<String, String>();
////			HashMap<String, String> hmData = new HashMap<String, String>();
////			GTFIrtProtocol protocol = new GTFIrtProtocol();
////			COMMLog df = new COMMLog();
////			
////			Socket extClntSock = null;
////			GTFIrtConveyer GTFConveyer = null;
////			
////			//Set Work Start Time(업무시작시간설정)
////			df.setStartTime();
////			//df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),String.valueOf(actionSocket.getSocket().getPort()), logger,"GTFIRT");
////			//df.execute("Approval cash Rebate GTF");
////			try {	// Data received from SC(SC로부터 받은 데이타)
////				if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
////				// Check MsgType(MsgType 확인)
////				/////////////////////////////////hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);				
////				String telegram = rcvBuf.substring(0,50);
////				hmCommon = protocol.getParseCommH(telegram);
////				// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 확인한다).
////				if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
////					return;
////				}
////				
////				rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
////				inq_type = protocol.getGTFIrtInq(rcvDataBuf);
////				switch(inq_type) {			
////					// 101: 즉시환급승인요청 
////					case GTFData.INQ101:{
////						//df.execute("Approval cash Rebate GTF");											
////						hmData = protocol.getParseGTF(rcvDataBuf,GTFData.REQ101);
////						sb = null;
////						sb = new StringBuffer(rcvBuf);					
////						//df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[DOC_CODE:" + inq_type + "]:[" + sb.toString() + "]");
////						
////						//extClntSock = new Socket(gtf_server_ip, gtf_server_port);
////						//GTFConveyer = new GTFIrtConveyer(extClntSock, df);
////	
////						int rcvIrtDataLen = rcvDataBuf.length();
////						dataMsg = testgetGTF101(hmCommon, hmData ,rcvIrtDataLen,df);
////						 
////						ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
////						dataMsg = dataMsg.substring(2);
////						}break;				
////					// 301: 즉시환급 취소요청
////					case GTFData.INQ301:{
////						df.execute("cancel cash Rebate GTF");
////						hmData = protocol.getParseGTF(rcvDataBuf ,GTFData.REQ301);
////						sb = null;
////						sb = new StringBuffer(rcvBuf);					
////						//df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + sb.toString() + "]");										
////						
////						//extClntSock = new Socket(gtf_server_ip, gtf_server_port);
////						//GTFConveyer = new GTFIrtConveyer(extClntSock, df);
////						
////						int rcvIrtDataLen = rcvDataBuf.length();
////						dataMsg = testgetGTF301(hmCommon, hmData, rcvIrtDataLen,df);
////						//dataMsg = GTFConveyer.getGTF301(hmCommon, hmData, rcvIrtDataLen);					
////	
////						ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
////						dataMsg = dataMsg.substring(2);
////						}break;
////	
////					// 901: 개시요청
////					case GTFData.INQ901:{
////						//df.execute("Start GTF Cash rebate");
////						hmData = protocol.getParseGTF(rcvDataBuf ,GTFData.REQ901);
////						sb = null;
////						sb = new StringBuffer(rcvBuf);					
////						//df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + sb.toString() + "]");										
////						
////						//extClntSock = new Socket(gtf_server_ip, gtf_server_port);
////						//GTFConveyer = new GTFIrtConveyer(extClntSock, df);
////						int rcvIrtDataLen = rcvDataBuf.length();
////	
////						//dataMsg = testgetGTF901(hmCommon, hmData , rcvIrtDataLen);
////						//dataMsg = GTFConveyer.getGTF901(hmCommon, hmData , rcvIrtDataLen);					
////	
////						ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
////						dataMsg = dataMsg.substring(2);					
////						}break;
////					
////					default:
////						//df.CommLogger("▶ INQ Code(INQ 종별 코드):   [" + inq_type
////						//		+ "]" + rcvBuf.length());
////						ret = 99;
////						break;
////				}
////			}
////			catch (Exception e) 
////			{
////				ret = 29; // 029=HOST APPL ERR
////				retValue = "[ERROR]2:" + e.getMessage();
////				//df.CommLogger("▶ " + retValue);
////			}
////			
////			try {
////				// Make Response Message Data(응답 전문데이타 만들기)
////				sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
////				String totalMsg = sendMsg + dataMsg;
////						
////				df.CommLogger("================ 4-2) POS<-SMS 응답전문 ===================");
////				df.CommLogger("전문길이=[" + totalMsg.getBytes().length + "]");
////				df.CommLogger("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
////				df.CommLogger("전문내용=[" + totalMsg + "]");
////				
////				System.out.println(totalMsg);
////				// Send Response Data (응답 데이타 전송)
////				//if (actionSocket.send(totalMsg)) 
////				//{
////				//	df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
////				//} 
////				//else 
////				//{
////				//	df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] ERROR");
////				//}
////			}
////			catch (Exception e) 
////			{
////				retValue = "[ERROR]4" + e.getMessage();
////				df.CommLogger("▶ " + retValue);
////			}
////			finally 
////			{
////				// IRT Work Finish Log(IRT 업무 종료 로그)
////				df.close("GTFIRT", retValue);
////				
////			}
////		}
////		
////	
////	
////	private String makeSendDataGTF(HashMap<String, String> hm,int jobType) {
////		StringBuffer sb = new StringBuffer();		
////		
////		switch(jobType){
////		case GTFData.REQ101:{
////			for (int i = 0; i < GTFData.nlens101GTF.length; i++) {
////				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders101GTF[i].toString()), GTFData.nlens101GTF[i]);
////			}						
////			break;
////		}
////		case GTFData.REQ301:{
////			for (int i = 0; i < GTFData.nlens301GTF.length; i++) {
////				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders301GTF[i].toString()), GTFData.nlens301GTF[i]);
////				}
////			break;
////		}
////		
////		case GTFData.REQ901:{
////			for (int i = 0; i < GTFData.nlens901GTF.length; i++) {
////				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders901GTF[i].toString()), GTFData.nlens901GTF[i]);
////				}				
////			break;
////		}				
////		case GTFData.RSP100:{
////			hm.put("RESPONSE_CD", "100");
////			hm.put("RESPONSE_MESSAGE", "정상처리되었습니다.                                        .");
////			hm.put("SHOP_NAME", "위드미 성수 푸조비즈빌딩점             .");
////			hm.put("EXPORT_EXPIRY_DATE", "20170102");
////			hm.put("PAYMENT_AMOUNT", "0000990000");
////			hm.put("EXPORT_APPROVAL_NUM", "303030303030303030303030303030");
////			hm.put("BEFORE_LIMIT_AMOUNT", "0010000000");
////			hm.put("MCH_SEND_UNIQ_NO", "212121212121212121212");
////			hm.put("SCT", "88888888");
////			hm.put("ET", "77777777");
////			hm.put("FFVST", "66666666");
////
////			
////			
////			
////			for (int i = 0; i < GTFData.nlens100GTF.length; i++) {
////				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders100GTF[i].toString()), GTFData.nlens100GTF[i]);
////				}				
////			break;
////		}	
////	}		
////
////		return sb.toString();
////}		
////
////	
////	private String getDataLen(int rcvIrtDataLen){
////		int  sendGTFDataLen = rcvIrtDataLen -2 + 5 + 2 +10 + 21;  //토탈길이 - InqType(2) + 길이필드(5) +EDI(2) + version(10) + credit(21) 
////		String str_sendGTFDataLen = String.valueOf(sendGTFDataLen);
////		return str_sendGTFDataLen;
////	}
////	
////	private String getDataLen901(int rcvIrtDataLen){
////		int  sendGTFDataLen = rcvIrtDataLen -2 + 5 + 2 +10 ;  //토탈길이 - InqType(2) + 길이필드(5) +EDI(2) + version(10)  
////		String str_sendGTFDataLen = String.valueOf(sendGTFDataLen);
////		return str_sendGTFDataLen;
////	}
////	
////	public HashMap<String, String> getParseGTFRsp(String rcvBuf , int jobType){ 
////		HashMap<String, String> hm = new HashMap<String, String>();
////				
////		switch(jobType){
////			case GTFData.RSP100:{
////				hm = COMMBiz.getParseDataMultibyte(GTFData.nlens100GTF, GTFData.strHeaders100GTF, rcvBuf );//hm = GTFData.getParseDataGTFMultibyte(GTFData.nlens100, GTFData.strHeaders100, rcvBuf , GTFData.nlensG100, GTFData.strHeadersG100);
////				break;
////			}
////
////			case GTFData.RSP300:{
////				hm = COMMBiz.getParseDataMultibyte(GTFData.nlens300GTF, GTFData.strHeaders300GTF, rcvBuf );//hm = GTFData.getParseDataGTFMultibyte(GTFData.nlens300, GTFData.strHeaders300, rcvBuf , GTFData.nlensG300, GTFData.strHeadersG300);
////				break;
////			}
////			case GTFData.RSP900:{
////				hm = COMMBiz.getParseDataMultibyte(GTFData.nlens900GTF, GTFData.strHeaders900GTF, rcvBuf );//hm = GTFData.getParseDataGTFMultibyte(GTFData.nlens900, GTFData.strHeaders900, rcvBuf );
////				break;
////			}				
////					
////		}				
////		
////		return hm;
////	}
////
////	private String makeSendDataGTFRsp(HashMap<String, String> hm, int rspType) {
////		StringBuffer sb = new StringBuffer();				
////		switch(rspType){
////		case GTFData.RSP100:{
////			for (int i = 0; i < GTFData.nlens100.length; i++) {
////				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders100[i].toString()), GTFData.nlens100[i]);
////			}	
////			break;
////			}
////		case GTFData.RSP300:{			
////			for (int i = 0; i < GTFData.nlens300.length; i++) {
////				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders300[i].toString()), GTFData.nlens300[i]);
////			}				
////			break;
////			}
////		case GTFData.RSP900:{				
////			for (int i = 0; i < GTFData.nlens900.length; i++) {
////				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders900[i].toString()), GTFData.nlens900[i]);
////			}							
////			break;
////		}
////		default :{
////				//do nothing
////			}
////		}
////		return sb.toString();
////	}
////		
////	//test///////////////////////////////////////////////////////////////////////////
////public String testgetGTF101(HashMap<String, String> hmComm, HashMap<String, String> hm , int rcvIrtDataLen , COMMLog df) throws Exception {
////		
////		HashMap<String,String> hmRecv = new HashMap<String,String>();
////		
////		String sendMsg = "";		// GTF로 보낼 송신 전문
////		String recvBuf = "";		// GTF에서 받을 응답 전문
////		String dataMsg = "";		// POS로 보낼 응답 전문
////		String ret = "00";
////		StringBuffer sb = null;
////		
////		try {
////			//actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.GTF_FILTER)));	
////			//SMS->GTF SEND 에필요한 데이터 가공 
////			String tmpInq = hm.get("INQ_TYPE");
////			hm.remove("INQ_TYPE");
////			hm.put("LENGTH",  StringUtil.lPad(getDataLen(rcvIrtDataLen), 5, "0") );
////			hm.put("EDI","WM");
////			hm.put("VERSION","WM16050101");
////			hm.put("CREDIT_CARD_NUM","000000000000000000000");									
////			
////			sendMsg = makeSendDataGTF(hm,  GTFData.REQ101 );
////			
////			sb = new StringBuffer(sendMsg);			
////			//df.CommLogger("101[sms>gtf] to send[" + sb.length() + "]:[" + sb.toString() + "]");
////
////			//if (actSock.send(sendMsg)) {
////			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] OK");
////			//} else {
////			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] ERROR");
////			//	throw new Exception("GTF Server is no response");
////			//}
////			
////			//recvBuf = ((String) actSock.receive());
////			//GTF 에서 오는 승인응답 
////			//recvBuf ="00535WMWM16050101100BBBBBBBBBBBBBBBBBBBBNAAAAAAAAAAaaaaaaaaaaAAAAAAAAAAEEEEEEEEEEEEEE4444999999999888888882ZZZZZZZZZZZZZZZZZZZZZN4040404040404040404040404040404040404040242424242424242424242424333F7705311604101006060606060606060606060606060606060606060606060606060606060604040404040404040404040404040404040404040000188888888303030303030303030303030303030Y9999999993030303030303030303030303030301010101010212121212121212121212002122505050505050505050505050505050505050505050505050504444999999999aaaaaaaaa88888888ffffffff88888888ffffffff"; 
////			//for test neo0531
////			recvBuf = makeSendDataGTF(hm,  GTFData.RSP100 );
////			
////			
////			sb = null;
////			sb = new StringBuffer(recvBuf);			
////			df.CommLogger("[GTF>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
////			
////			hmRecv = getParseGTFRsp(recvBuf , GTFData.RSP100);					
////
////			hmRecv.remove("LENGTH");
////			hmRecv.put("INQ_TYPE", tmpInq);
////			hmRecv.remove("EDI");
////			hmRecv.remove("VERSION");
////			hmRecv.remove("CREDIT_CARD_NUM");
////
////			
//////			df.CommLogger(" >>>>>>>>>>>>> INQ_TYPE : " + (String)hm.get("INQ_TYPE"));
//////			df.CommLogger(" >>>>>>>>>>>>> TR_GB : " + (String)hm.get("TR_GB"));
////		}catch(Exception e) {
//////			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
////			ret = "29";
////			throw e;
////		}finally {
////			//actSock.close();
////			dataMsg = ret + makeSendDataGTFRsp(hmRecv, GTFData.RSP100);			
////			df.CommLogger("★ make(to POS): " + dataMsg);
////		}
////		
////		return dataMsg;
////		}
////
////		
////	public String testgetGTF301(HashMap<String, String> hmComm, HashMap<String, String> hm , int rcvIrtDataLen , COMMLog df) throws Exception {
////	
////		HashMap<String,String> hmRecv = new HashMap<String,String>();
////		
////		String sendMsg = "";		// GTF로 보낼 송신 전문
////		String recvBuf = "";		// GTF에서 받을 응답 전문
////		String dataMsg = "";		// POS로 보낼 응답 전문
////		String ret = "00";
////		StringBuffer sb = null;
////		
////		try {
////			//actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.GTF_FILTER)));					
////			//		SMS->GTF SEND 에필요한 데이터 가공 
////			//SMS->GTF SEND 에필요한 데이터 가공 
////			String tmpInq = hm.get("INQ_TYPE");
////			hm.remove("INQ_TYPE");
////			hm.put("LENGTH",  StringUtil.lPad(getDataLen(rcvIrtDataLen), 5, "0") );
////			hm.put("EDI","WM");
////			hm.put("VERSION","WM16050101");
////			hm.put("CREDIT_CARD_NUM","000000000000000000000");									
////			
////			sendMsg = makeSendDataGTF(hm,  GTFData.REQ301 );
////			
////			sb = new StringBuffer(sendMsg);			
////			df.CommLogger("901[sms>gtf] to send[" + sb.length() + "]:[" + sb.toString() + "]");
////			
////			//if (actSock.send(sendMsg)) {
////			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] OK");
////			//} else {
////			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] ERROR");
////			//	throw new Exception("GTF Server is no response");
////			//}
////			
////			//recvBuf = ((String) actSock.receive());
////			//GTF 에서 오는 취소응답 
////			recvBuf ="00456WMWM16050101100BBBBBBBBBBBBBBBBBBBBNAAAAAAAAAAaaaaaaaaaaAAAAAAAAAAEEEEEEEEEEEEEE4444999999999888888882ZZZZZZZZZZZZZZZZZZZZZN4040404040404040404040404040404040404040242424242424242424242424333F7705311604101006060606060606060606060606060606060606060606060606060606060604040404040404040404040404040404040404040000188888888Y212121212121212121212002122505050505050505050505050505050505050505050505050504444999999999aaaaaaaaa88888888ffffffff88888888ffffffff"; 
////	
////			sb = null;
////			sb = new StringBuffer(recvBuf);			
////			df.CommLogger("[GTF>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
////			
////			hmRecv = getParseGTFRsp(recvBuf, GTFData.RSP300);							
////	
////			hmRecv.remove("LENGTH");
////			hmRecv.put("INQ_TYPE", tmpInq);
////			hmRecv.remove("EDI");
////			hmRecv.remove("VERSION");
////			hmRecv.remove("CREDIT_CARD_NUM");
////	
////			
////	//		df.CommLogger(" >>>>>>>>>>>>> INQ_TYPE : " + (String)hm.get("INQ_TYPE"));
////	//		df.CommLogger(" >>>>>>>>>>>>> TR_GB : " + (String)hm.get("TR_GB"));
////		}catch(Exception e) {
////	//		df.CommLogger("▶ [ERROR]1: " + e.getMessage());
////			ret = "29";
////			throw e;
////		}finally {
////			//actSock.close();
////			dataMsg = ret + makeSendDataGTFRsp(hmRecv, GTFData.RSP300);
////			df.CommLogger("★ make(to POS): " + dataMsg);
////		}
////		
////		return dataMsg;
////	}		
////	
////	
////	
////
////
////	public String testgetGTF901(HashMap<String, String> hmComm, HashMap<String, String> hm , int rcvIrtDataLen , COMMLog df) throws Exception {
////		
////		HashMap<String,String> hmRecv = new HashMap<String,String>();
////		
////		String sendMsg = "";		// GTF로 보낼 송신 전문
////		String recvBuf = "";		// GTF에서 받을 응답 전문
////		String dataMsg = "";		// POS로 보낼 응답 전문
////		String ret = "00";
////		StringBuffer sb = null;
////		
////		try {
////			//actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.GTF_FILTER)));					
////			//		SMS->GTF SEND 에필요한 데이터 가공 
////			String tmpInq = hm.get("INQ_TYPE");
////			hm.remove("INQ_TYPE");	
////			hm.put("LENGTH",   StringUtil.lPad(getDataLen901(rcvIrtDataLen), 5, "0") );
////			hm.put("EDI","WM");
////			hm.put("VERSION","WM16050101");
////									
////			sendMsg = makeSendDataGTF(hm, GTFData.REQ901 );
////			
////			sb = new StringBuffer(sendMsg);			
////			df.CommLogger("901[sms>gtf] to send[" + sb.length() + "]:[" + sb.toString() + "]");
////			
////			//if (actSock.send(sendMsg)) {
////			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] OK");
////			//} else {
////			//	df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] ERROR");
////			//	throw new Exception("GTF Server is no response");
////			//}
////			
////			//recvBuf = ((String) actSock.receive());
////			//개시응답
////			recvBuf ="00157WMWM160501019001048198557WMTEST0001YYYY05DD143722100정상처리되었습니다.                                        .위드미 성수 푸조비즈빌딩점             ."; 
////
////			sb = null;
////			sb = new StringBuffer(recvBuf);			
////			df.CommLogger("[GTF>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
////			
////			hmRecv = getParseGTFRsp(recvBuf, GTFData.RSP900);							
////
////			hmRecv.remove("LENGTH");
////			hmRecv.put("INQ_TYPE", tmpInq);
////			hmRecv.remove("EDI");
////			hmRecv.remove("VERSION");
////			hmRecv.remove("CREDIT_CARD_NUM");
////
////			
//////				df.CommLogger(" >>>>>>>>>>>>> INQ_TYPE : " + (String)hm.get("INQ_TYPE"));
//////				df.CommLogger(" >>>>>>>>>>>>> TR_GB : " + (String)hm.get("TR_GB"));
////		}catch(Exception e) {
//////				df.CommLogger("▶ [ERROR]1: " + e.getMessage());
////			ret = "29";
////			throw e;
////		}finally {
////			//actSock.close();
////			dataMsg = ret + makeSendDataGTFRsp(hmRecv, GTFData.RSP900);
////			df.CommLogger("★ make(to POS): " + dataMsg);
////		}
////		
////		return dataMsg;
////	}	
////	
////
////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////unit test code	////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////	
////
////	
////	
////}



