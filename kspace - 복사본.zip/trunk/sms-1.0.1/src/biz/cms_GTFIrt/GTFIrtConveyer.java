package biz.cms_GTFIrt;

import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;

import biz.comm.AES;
	/*
int nlens[]= {5,2,10,3,20,
			  1,10,10,10,14,
			  4,9,8,1,21,
			  1,13,1,40,24,
			  3,1,6,6,3,
			  60,40,4,8,30,
			  1,9,30,10,100,
			  };	  
			  
String strHeaders[] = { 
		"LENGTH"				, //전문 길이
		"EDI"					, //업무 구분
		"VERSION"				, //전문버전(업무구분(2)+YYMMDD(6)+순번(2))
		"DOCUMENT_CD"			, // 문서코드 (승인101 , 조회201, 취소301,  개시901)
		"BUY_SERIAL_NUM"		, // 구매일련번호(환급창구사업자코드(2) +매장ID + 난수(5)+연도(2)+시퀀스넘버(6)
		
		"BUYER_CANCLE_CHECK"	, // 구매취소여부(Y,N)
		"TRADE_APPROVAL_NUM"	, // 거래승인번호
		"SELLER_BUSI_REGIST_NUM",	//판매자 사업자등록번호
		"TERMINAL_ID"			, // 단말기 ID 	(개시응답시 세팅 , 개시시에는 시리얼 넘버 )			
		"SELL_TIME"				, // 판매연월시분초(YYYYMMDDHHMMSS)
		
		"SELL_SUM_TOTAL"		, // 판매총수량				
		"SELL_SUM_MONEY"		, // 판매총금액
		"REFUND_AMOUNT"			, // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
		"PAYMENT_TYPE"			, // 결제유형(신용1, 현금2)
		"CREDIT_CARD_NUM"		, //결제신용카드번호  
		
		"KOR_DOMESTIC_CITIZEN"	, //내국인환급대상여부		(한국여권Y, 아니면 N)
		"KOR_IDENTITY"			, //주민번호
		"PASSPORT_ENC_YN"		, //여권암호화여부  (N:비암호화, D:DES , T:3DES)
		"PASSPORT_NAME"			, //여권영문이름(즉시환급 필수)
		"PASSPORT_NUM"			, //여권번호(즉시환급필수 암호화시 TripleDES)
		
		"PASSPORT_NATION"		, //여권국가코드 	(즉시환급 필수)			
		"PASSPORT_SEX"			, //여권성별(즉시환급 필수)
		"PASSPORT_BIRTH"		, //여권생일(즉시환급 필수)
		"PASSPORT_EXPIRE"		, //여권만료일(즉시환급 필수)
		"RESPONSE_CD"			, //응답코드(100정상 , 200 통신장애 , 300 정보오류 , 400 재전송 
		
		"RESPONSE_MESSAGE"		, //응답메시지 				
		"SHOP_NAME"				, //매장명
		"SEQUENCE_COUNT"		, //물품부반복회수  조회시 0000padding 
		"EXPORT_EXPIRY_DATE"	, // 반출유효기간(YYYYMMDD)
		"RCT_NO"				, //영수증번호
		
		"BEFORE_REFUND_YN"		, //즉시환급여부 (즉시환급Y , 사후 환급 N)
		"PAYMENT_AMOUNT"		, //결제금액
		"EXPORT_APPROVAL_NUM"	, //반출승인번호(즉시환급일경우 반출 승인 번호 리턴한다)
		"BEFORE_LIMIT_AMOUNT"	,  //즉시환급한도액(즉시환급조회 할경우 한도액 리턴한다. )
		"EXTRA"//비고
		};
		
int nlensGood[]= {3,1,2,50,4,
				  9,9,8,8,8,
				  8,16
				  };
				  		
String strHeadersGood[] = { //물품부
		"COMMODITY_NUM"			,  //물품일련번호
		"SCT_DIV"				,  //개별소비세구분
		"COMMODITY_CD"			,  //물품코드
		"COMMODITY_CONT"		,  //물품내용
		"VOLUME"				,  //수량
		"UNIT_PRICE"			,  //단가
		"SELL_PRICE"			,  //판매가격
		"VAT"					,  //부가가치세
		"SCT"					,  //개별소비세
		"ET"					,  //교육세
		"FFVS"					,  //농어촌특별세
		"EXTRA"					,  //비고
		
	};
	
	*/
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;



public class GTFIrtConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;
	
	COMMLog df = null;
	
	public GTFIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}
	
	private String makeSendDataGTF(HashMap<String, String> hm, COMMLog df ) {
		StringBuffer sb = new StringBuffer();				
		
		for (int i = 0; i < GTFData.nlensGTF.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeadersGTF[i].toString()), GTFData.nlensGTF[i]);
		}								

		return sb.toString();
}		
	
	private String makeSendDataGTF(HashMap<String, String> hm, COMMLog df ,int jobType) {
		StringBuffer sb = new StringBuffer();				
		
		//Append non necessary field 
		switch(jobType){
			case GTFData.REQ101:{
				hm.put("KOR_DOMESTIC_CITIZEN", " ");
				hm.put("KOR_IDENTITY", "0000000000000");
				hm.put("RESPONSE_CD", "000");
				hm.put("RESPONSE_MESSAGE", "                                                            ");
				hm.put("SHOP_NAME", "                                        ");
				
				hm.put("EXPORT_EXPIRY_DATE", "        ");				
				hm.put("PAYMENT_AMOUNT", "000000000");
				hm.put("EXPORT_APPROVAL_NUM", "000000000000000000000000000000");
				hm.put("BEFORE_LIMIT_AMOUNT", "0000000000");
				String tmpUniq = hm.get("MCH_SEND_UNIQ_NO");
				tmpUniq = tmpUniq + "                                                                               ";
				hm.put("MCH_SEND_UNIQ_NO", tmpUniq);
				
				hm.put("SCT", "00000000");
				hm.put("ET", "00000000");
				hm.put("FFVST", "00000000");
				hm.put("EXTRA", "                ");		
				
				break;
			}
			case GTFData.REQ301:{
				hm.put("KOR_DOMESTIC_CITIZEN", " ");
				hm.put("KOR_IDENTITY", "0000000000000");
				hm.put("PASSPORT_ENC_YN"," ");
				hm.put("PASSPORT_NAME","                                        ");
				hm.put("PASSPORT_NUM","                        ");
				
				hm.put("PASSPORT_NATION","   ");
				hm.put("PASSPORT_SEX"," ");
				hm.put("PASSPORT_BIRTH","000000");
				hm.put("PASSPORT_EXPIRE","000000");
				hm.put("RESPONSE_CD", "000");
				
				hm.put("RESPONSE_MESSAGE", "                                                            ");
				hm.put("SHOP_NAME", "                                        ");				
				hm.put("EXPORT_EXPIRY_DATE", "        ");
				hm.put("RCT_NO","                              ");
				hm.put("BEFORE_REFUND_YN"," ");

				hm.put("PAYMENT_AMOUNT", "000000000");
				hm.put("EXPORT_APPROVAL_NUM", "000000000000000000000000000000");
				hm.put("BEFORE_LIMIT_AMOUNT", "0000000000");
				String tmpUniq = hm.get("MCH_SEND_UNIQ_NO");
				tmpUniq = tmpUniq + "                                                                               ";
				hm.put("MCH_SEND_UNIQ_NO", tmpUniq);
				hm.put("SCT", "00000000");
				
				hm.put("ET", "00000000");
				hm.put("FFVST", "00000000");
				hm.put("EXTRA", "                ");
				break;

				

			}			
			case GTFData.REQ901:{
				hm.put("RESPONSE_CD", "000");	
				hm.put("RESPONSE_MESSAGE", "                                                            ");
				hm.put("SHOP_NAME", "                                        ");	
				for (int i = 0; i < GTFData.nlens901GTF.length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders901GTF[i].toString()), GTFData.nlens901GTF[i]);
					}			
				return sb.toString();						
			}				
		}		

		for (int i = 0; i < GTFData.nlensGTF.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeadersGTF[i].toString()), GTFData.nlensGTF[i]);
		}	
		
		return sb.toString();
}		

		
	private String getDataLen(int rcvIrtDataLen){
		int  sendGTFDataLen = rcvIrtDataLen -2 + 5 + 2 + 10 + 21  ;  //토탈길이 - InqType(2) + 길이필드(5)+업무구분(2)+전문버전(10)+신용카드번호 (21) 
		String str_sendGTFDataLen = String.valueOf(sendGTFDataLen);
		return str_sendGTFDataLen;
	}

	private String getDataLen901(int rcvIrtDataLen){
		int  sendGTFDataLen = rcvIrtDataLen -2 + 5 + 2 + 10   ;  //토탈길이 - InqType(2) + 길이필드(5)+업무구분(2)+전문버전(10)
		String str_sendGTFDataLen = String.valueOf(sendGTFDataLen);
		return str_sendGTFDataLen;
	}
	
	public String getGTF101(HashMap<String, String> hmComm, HashMap<String, String> hm, boolean encYn) throws Exception {
		GTFIrtProtocol protocol = new GTFIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// GTF로 보낼 송신 전문
		String recvBuf = "";		// GTF에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.GTF_FILTER)));	
			/*neo0531====>*/df.CommLogger("getGTF101 actSock create is success");
			//SMS->GTF SEND 에필요한 데이터 가공 
			String tmpInq = hm.get("INQ_TYPE");
			hm.remove("INQ_TYPE");
			hm.put("LENGTH",  "00644");
			hm.put("EDI","WM");
			hm.put("VERSION","WM16050101");
			hm.put("CREDIT_CARD_NUM","000000000000000000000");												
			
			sendMsg = makeSendDataGTF(hm, df , GTFData.REQ101);
			
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("GTF Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			/*neo0531====>*/df.CommLogger("GTF 101 actSock.receive");

			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[GTF>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseGTFRsp(recvBuf , GTFData.RSP100);				//hmRecv = protocol.getParseGTFRsp(recvBuf , GTFData.RSP100);				//hmRecv = protocol.getParseSSGPointRsp(recvBuf);	
			/*neo0531====>*/df.CommLogger("GTF 100 hmRecv  getParseGTFRsp parse is success");
			hmRecv.remove("LENGTH");
			hmRecv.put("INQ_TYPE", tmpInq);
			hmRecv.remove("EDI");
			hmRecv.remove("VERSION");
			hmRecv.remove("CREDIT_CARD_NUM");
			
			//20170601 KSN 여권번호 암호화 적용 작업 - POS로 여권번호 내려주는 단계에서 공란으로 보내기로 POS담당자와 협의
			if(encYn){
				hmRecv.put("PASSPORT_NUM", "                        ");
			}
			
			df.CommLogger("[GTF>sms] PASSPORT_NUM [" + hmRecv.get("PASSPORT_NUM") + "]");
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataGTFRsp(hmRecv, GTFData.RSP100,df);			
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	

	public String getGTF301(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		GTFIrtProtocol protocol = new GTFIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// GTF로 보낼 송신 전문
		String recvBuf = "";		// GTF에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.GTF_FILTER)));					
			df.CommLogger("getGTF301 actSock create is success");
			//SMS->GTF SEND 에필요한 데이터 가공 
			String tmpInq = hm.get("INQ_TYPE");
			hm.remove("INQ_TYPE");
			hm.put("LENGTH",  "00644" );
			hm.put("EDI","WM");
			hm.put("VERSION","WM16050101");
			hm.put("CREDIT_CARD_NUM","000000000000000000000");									
			
			sendMsg = makeSendDataGTF(hm, df , GTFData.REQ301 );
			
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "]" /*+":[JOB_CODE:" + (String)hm.get("MSG_TEXT") + "]"*/+ ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("GTF Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());

			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[GTF>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseGTFRsp(recvBuf, GTFData.RSP300);							

			hmRecv.remove("LENGTH");
			hmRecv.put("INQ_TYPE", tmpInq);
			hmRecv.remove("EDI");
			hmRecv.remove("VERSION");
			hmRecv.remove("CREDIT_CARD_NUM");

			
//			df.CommLogger(" >>>>>>>>>>>>> INQ_TYPE : " + (String)hm.get("INQ_TYPE"));
//			df.CommLogger(" >>>>>>>>>>>>> TR_GB : " + (String)hm.get("TR_GB"));
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataGTFRsp(hmRecv, GTFData.RSP300,df);
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}		


	public String getGTF901(HashMap<String, String> hmComm, HashMap<String, String> hm , int rcvIrtDataLen) throws Exception {
		GTFIrtProtocol protocol = new GTFIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// GTF로 보낼 송신 전문
		String recvBuf = "";		// GTF에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;		
		/*====>*/df.CommLogger("enter getGTF901");
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.GTF_FILTER)));					
			/*		SMS->GTF SEND 에필요한 데이터 가공 */
			/*neo0531====>*/df.CommLogger("getGTF901 actSock create is success");
			String tmpInq = hm.get("INQ_TYPE");
			hm.remove("INQ_TYPE");	
				hm.put("LENGTH",   StringUtil.lPad(getDataLen901(rcvIrtDataLen), 5, "0") );
			hm.put("EDI","WM");
			hm.put("VERSION","WM16050101");										
			sendMsg = makeSendDataGTF(hm, df , GTFData.REQ901 );
			/*neo0531====>*/df.CommLogger("getGTF901 sendMsg=["+sendMsg+"]");
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "]" /*+":[JOB_CODE:" + (String)hm.get("MSG_TEXT") + "]"*/+ ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>GTFApprove] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("GTF Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			df.CommLogger("[GTF>sms] RECV["+recvBuf+"]");
 
			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[GTF>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseGTFRsp(recvBuf, GTFData.RSP900);							

			hmRecv.remove("LENGTH");
			hmRecv.put("INQ_TYPE", tmpInq);
			hmRecv.remove("EDI");
			hmRecv.remove("VERSION");
			hmRecv.remove("CREDIT_CARD_NUM");

			}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataGTFRsp(hmRecv, GTFData.RSP900,df);
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		df.CommLogger("end getGTF901 ["+ dataMsg +"]");
		return dataMsg;
	}								
	
	
	private String makeSendDataGTFRsp(HashMap<String, String> hm, int rspType, COMMLog df) {
		StringBuffer sb = new StringBuffer();				
		//int reCnt = Integer.parseInt((String)hm.get("SEQUENCE_COUNT"));				
		switch(rspType){
		case GTFData.RSP100:{
			for (int i = 0; i < GTFData.nlens100.length; i++) {
				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders100[i].toString()), GTFData.nlens100[i]);
			}	
			break;
			}
		case GTFData.RSP300:{			
			for (int i = 0; i < GTFData.nlens300.length; i++) {
				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders300[i].toString()), GTFData.nlens300[i]);
			}				
			break;
			}
		case GTFData.RSP900:{				
			for (int i = 0; i < GTFData.nlens900.length; i++) {
				StringUtil.appendSpace(sb, (String) hm.get(GTFData.strHeaders900[i].toString()), GTFData.nlens900[i]);
			}							
			break;
		}
		
		default :{
				//do nothing
			}
		}			
		return sb.toString();
	}

	
}
