package biz.cms_CashBeeSender;

import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.ZipUtil;
 
import org.apache.log4j.Logger;

import biz.cms_TMoneySender.TMoneySenderFileTransfer;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

public class CashBeeSenderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(CashBeeSenderPollingAction.class);
	
	public static void main(String args[]) throws Exception {
		CashBeeSenderPollingAction action = new CashBeeSenderPollingAction();
		CashBeeSenderFileTransfer transfer = new CashBeeSenderFileTransfer();
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[1]]=" + args[1] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd			 = nvl(args[1].replaceFirst("-cmd:", ""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			if( cmd.length() != 3 ) return;
			
			if( cmd.charAt(0) == '1' ) {
				System.out.println("[DEBUG] execute downloadPUBCOINFOFile" );
     			action.downloadPUBCOINFOFile();
			}
			if( cmd.charAt(1) == '1' ) {
				System.out.println("[DEBUG] execute createCashBeeTranFile" );
				action.createCashBeeTranFile();
			}
			Thread.sleep(50);
			if( cmd.charAt(2) == '1' ) {
				System.out.println("[DEBUG] execute transfer" );
				transfer.transfer();
			}
			
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(String actionMode) {
		CashBeeSenderDAO dao = new CashBeeSenderDAO();
		List<Object> list = null;
		int totalCnt = 0;;
		
		try { 
			int ret = -1;
			
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode == "1" ) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String stdYmd = sdf.format(new Date());
				String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
				
				//(금일 대사파일 생성 유무 조회)
				list = dao.selSVCFILEDAILY(stdYmd, "CSB", "%", com_cd);
				totalCnt = list.size();
				
				//금일 대사파일 생성 row가 없으면 생성
				if( totalCnt <= 0 ) {
					HashMap<String, String> hm = new HashMap<String, String>();
					hm.put("COM_CD", com_cd);
					hm.put("STD_YMD", stdYmd);
					hm.put("SVC_ID", "CSB");
					hm.put("CMD_TY", "00");
					
					ret = dao.insSVCFILEINFO(hm);
						
					if( ret > 0 ) {
						downloadPUBCOINFOFile();
						Thread.sleep(50);
						
						createCashBeeTranFile();
						Thread.sleep(50);
						
						try {
							(new CashBeeSenderFileTransfer()).transfer();
						}catch(Exception e) {
							logger.info("[ERROR]" + e.getMessage());
						}
						hm.put("CMD_TY", "01");
						ret = dao.updSVCFILEINFO(hm);
					}
				}
			}
			else if( actionMode == "0" ) {
				String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
				String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "cashbee";
				File destDir = new File(destPath);
				boolean isFile = false;
				
				File[] files = destDir.listFiles();
				for(File file : files) {
					if(file.isFile()) {
						isFile = true;
						logger.info(file.getName());
						break;
					}
				}
				if( isFile ) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
					String stdYmd = sdf.format(new Date());
					String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
					list = null;
					
					//(금일 대사파일 생성 유무 조회)
					list = dao.selSVCFILEDAILY(stdYmd, "CSB", "01", com_cd);
					totalCnt = list.size();
					
					// 파일 재 송신
					if( totalCnt > 0 ) {
						logger.info("Retransfering to CashBee...");
						try {
							(new CashBeeSenderFileTransfer()).transfer();
						}catch(Exception e) {
							logger.info("[ERROR]" + e.getMessage());
						}
					}
				}
			}
//			else if( actionMode == "0" ) {
//				String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
//				String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "cashbee";
//				File destDir = new File(destPath);
//				CashBeeSenderFileTransfer transfer = new CashBeeSenderFileTransfer();
//				List<File> tmpList = null;
//				
//				if( destDir.exists() ) {
//					File[] files = destDir.listFiles();
//					
//					tmpList = Arrays.asList(files);
//					for( int i = 0;i < tmpList.size();i++ ) {
//						if( tmpList.get(i).isFile() ) {
//							transfer.transfer();
//							break;
//						}
//					}
//				}
//			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	public void downloadPUBCOINFOFile() {
		HashMap<String, String> hm = new HashMap<String, String>();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		HashMap<String, String> hmHeader = new HashMap<String, String>();
		CashBeeSenderProtocol protocol = new CashBeeSenderProtocol();
		CashBeeSenderDAO dao = new CashBeeSenderDAO();
		ActionSocket actSock = null;
		Socket extClntSock = null;
		List<Object> list = null;
		String sendMsg = "";
		String recvBuf = "";
		String com_cd = "";
		COMMLog df = new COMMLog();
		
		String server_ip = "";
		int server_port = 0;
		
		try {
			System.out.println("downloadPUBCOINFOFile START");
			logger.info("downloadPUBCOINFOFile START");
		
			server_ip = PropertyUtil.findProperty("communication-property", "CASHBEE_COMM_IP");
			logger.info("server_ip[" + server_ip + "]");
			server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CASHBEE_COMM_PORT"));
			logger.info("server_port[" + server_port + "]");
			
			extClntSock = new Socket(server_ip, server_port);
			logger.info("extClntSock[" + extClntSock + "]");
			actSock = new ActionSocket(extClntSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBEE_MST_FILTER)));
			logger.info("actSock[" + actSock + "]");
			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			df.setConnectionInfo(actSock.getSocket().getInetAddress()
					.getHostAddress().toString(),
					String.valueOf(actSock.getSocket().getPort()), logger,
					"CashBeePUBCOINFOFile");
			
			Map<String, String> map = null;
			List<Object> listTmnalID = new ArrayList<Object>();
			// 단말기및SAMID설치정보 테이블에서 단말기ID 5건 가져와서 LOOP
			list = dao.selTMNALSAMIDMST();
			df.CommLogger("list[" + list + "]");
			for(int i = 0;i < list.size();i++) {
				listTmnalID.add((Map<String, String>)list.get(i));
			}
			
			boolean bGotIt = false;
			int iLastRecvedSeqNo = 0;
			for(int i = 0;i < listTmnalID.size();i++) {
				while(true) {
					hm.put("COMMAND_TP", "D2");
					//hm.put("LENGTH", String.format("%2x", (int)49));
					hm.put("LENGTH", "  ");
					hm.put("TMNAL_ID", ((Map<String, String>)listTmnalID.get(i)).get("TMNAL_ID"));
					hm.put("SAM_TP", "10");
					hm.put("EB_INTG_SAMID", "0000000000000000");
					hm.put("FILE_TP", "10");
					hm.put("NEWREQ_YN", "0");
					hm.put("LAST_RECV_VER", "00000000");
					//hm.put("LAST_RECV_SEQ", "0000000000");
					hm.put("LAST_RECV_SEQ", String.format("%010d", iLastRecvedSeqNo));
					
					sendMsg = makeSendDataPUBCOINFOInq(hm);
					df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "]:[CMD_TP:" + (String)hm.get("COMMAND_TP") + "]:[" + sendMsg + "]");
					
					// 전송할 메시지를 byte 배열로 변환
					byte sendBytes[] = sendMsg.getBytes();
					
					// 전문 길이 0x0031(49) 설정
					sendBytes[2] = (byte)0x00;
					sendBytes[3] = (byte)0x31;
					
					if( actSock.send(sendBytes, sendBytes.length) ) {
						df.CommLogger("[sms>cashbee] SEND[" + sendBytes.length + "] OK");
					}else {
						df.CommLogger("[sms>cashbee] SEND[" + sendBytes.length + "] ERROR");
						continue;
					}
					recvBuf = ((String)actSock.receive());
					df.CommLogger("[sms<cashbee] RECV[" + recvBuf.getBytes().length + "]:[CMD_TP:" + recvBuf.substring(0, 2) +"]:[" + recvBuf + "]");
					
					if( !(recvBuf.substring(32, 34)).equals("00") ) {
						df.CommLogger(" >>>>>>>>>> Failed to receive PUBCOINFO File ");
						continue;
					}else {
						df.CommLogger(" >>>>>>>>>> Succeeded to receive PUBCOINFO File ");
						bGotIt = true;
					}
					
					hmRecv = protocol.getParseCashBeePUBCOINFORsp(recvBuf, df);
					
					if( iLastRecvedSeqNo == 0 )
					{
						com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
						hmHeader = protocol.getParsePUBCOINFOHDR((String)hmRecv.get("DATA"), df);
						hmHeader.put("CO_CD", com_cd);
					}
					
					int chk = insertDB((String)hmRecv.get("DATA"), hmHeader, iLastRecvedSeqNo, df);
					if( chk <= ++iLastRecvedSeqNo )
					{
						break;
					}
				}
				if( bGotIt ) 
				{
					break;
				}
			}
			if( !bGotIt ) {
				throw (new Exception("Failed to get valid terminal id !"));
			}
		}catch(UnknownHostException e) {
			logger.info("[DEBUG] " + e.getMessage());
		}catch(IOException e) {
			logger.info("[DEBUG] " + e.getMessage());
		}catch(Exception e) {
			logger.info("[DEBUG] " + e.getMessage());
		}finally {
			actSock.close();
		}
	}
	
	public int insertDB(String fileData, HashMap<String, String> hmHeader, int seqNo, COMMLog df) throws Exception {
		CashBeeSenderProtocol protocol = new CashBeeSenderProtocol();
		CashBeeSenderDAO dao = new CashBeeSenderDAO();
		HashMap<String, String> hmDataTmp = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		int resultHdr = 0;
		int resultDtl = 0;
		String com_cd = "";
		String ver = "";
		
		try {
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			String toDay = sdf.format(calendar.getTime());
			com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			List<Object> listCSBVersion = null;
			
			listCSBVersion = dao.selPUBCOINFO(com_cd);
			if( listCSBVersion.size() > 0 ) {
				Map<String, String> mapCSBVersion = (Map<String, String>)listCSBVersion.get(0);
				ver = (String)mapCSBVersion.get("CSB_VER");
				if( seqNo == 0 && ((String)hmHeader.get("FILE_VER")).compareTo(ver) <= 0 ) {
					df.CommLogger(" >>>>>>>>>> Skipped PUBCOINFO File.(Master is the latest version)");
					return -1;
				}else {
					dao.updDSTBMSTCHGHIS(com_cd, toDay, "%", "0015", "cms_CashBeeSender", "cms_CashBeeSender");
				}
			}
			
			int iHdrBytes = 0;
			if( seqNo == 0 )
			{
				iHdrBytes = 65;
			}else
			{
				iHdrBytes = 0;
			}
			
			hmDataTmp = protocol.getParsePUBCOINFODATATMP(parseByByte(fileData, iHdrBytes, iHdrBytes + 15), df);
			
			for(int i = 0;i < Integer.parseInt((String)hmDataTmp.get("PUBCO_NUM"));i++) {
				hmData = protocol.getParsePUBCOINFODATA(parseByByte(fileData, (iHdrBytes + 15) + 98 * i, (iHdrBytes + 15) + 98 * (i + 1)), df);
				hmData.put("CO_CD", com_cd);
				hmData.put("FILE_VER", (String)hmHeader.get("FILE_VER"));
				
				resultDtl += dao.insPUBCOINFODATA(hmData);
			}
			if( seqNo == (Integer.parseInt((String)hmHeader.get("TOTAL_CNT")) - 1) && resultDtl > 0 ) {
				df.CommLogger(" >>>>>>>>>> Inserted into ST_CSBPBCOINFO_DTL [" + Integer.toString(resultDtl) + "] rows ");
				
				resultHdr = dao.insPUBCOINFOHDR(hmHeader);
				df.CommLogger(" >>>>>>>>>> Inserted into ST_CSBPBCOINFO_HDR [" + Integer.toString(resultHdr) + "] rows ");
			}
		}catch(Exception e) {
			dao.delPUBCOINFODTL(com_cd, ver);
			throw e;
		}
		
		return Integer.parseInt((String)hmHeader.get("TOTAL_CNT"));
	}
	
	public String parseByByte(String dest, int start, int end) throws Exception {
		byte newBytes[];
		if( end <= start ) return null;
		
		try {
			byte bytes[] = dest.getBytes();
			newBytes = new byte[end - start];
			
			
			for(int i = 0;i < end-start;i++) {
				newBytes[i] = bytes[start + i];
			}
		}catch(Exception e) {
			throw e;
		}
		
		return (new String(newBytes));
	}
	
	public String makeSendDataPUBCOINFOInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,2,16
					  ,2,1,8,10};
		String strHeaders[] = {
			"COMMAND_TP",
			"LENGTH",
			"TMNAL_ID",
			"SAM_TP",
			"EB_INTG_SAMID",
			
			"FILE_TP",
			"NEWREQ_YN",
			"LAST_RECV_VER",
			"LAST_RECV_SEQ"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public boolean createCashBeeTranFile() {
		boolean bIsCreatedFile = false;
		
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			CashBeeSenderDAO dao = new CashBeeSenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			//String toDay = sdf.format(calendar.getTime());
			//calendar.setTime(sdf.parse(toDay));
			calendar.setTime(new Date());
			calendar.add(Calendar.DATE, -1);
			String stdDate = sdf.format(calendar.getTime());
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "cashbee";
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			// 전송 파일명 체계
			// 거래내역                 : EBS.WM.001.YYYYMMDD
			// 충전/지불 반송       : EBS.WM.002.YYYYMMDD
			// 충전/지불 정산결과 : EBS.WM.003.YYYYMMDD
			String strTRANFileNM = "EBS.WM.001." + stdDate;
			
			// 거래내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_TP", "H");
			hmHeader.put("FILE_NAME", strTRANFileNM);
			hmHeader.put("DATA_SNO", "00000000");
			hmHeader.put("ADJT_YMD", stdDate);
			hmHeader.put("FILLER", " ");
			hmHeader.put("NLCHAR", String.format("%1c", 10));
			
			sbFile.append(makeHeaderOfFile(hmHeader));
			
			list = dao.selCASHBEETRAN(com_cd, card_key, double_card_key);
			for(int i = 0;i < list.size();i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				hmData.put("RECORD_TP", "RD");
				hmData.put("LENGTH", "00");
				hmData.put("TMNAL_ID", (String)map.get("TMNAL_ID").trim());
				hmData.put("TRAN_ID", (String)map.get("TRAN_ID").trim());
				hmData.put("SAM_TP", (String)map.get("SAM_TP").trim());
				hmData.put("SAM_ID", (String)map.get("SAM_ID").trim());
				hmData.put("CARD_NO", (String)map.get("PPCARD_NO").trim());
				hmData.put("CARD_DEAL_SNO", StringUtil.lPad((String)map.get("PPCARD_TRAN_SEQ_NO").trim(), 10, "0"));
				hmData.put("DEAL_TP", (String)map.get("CASHB_TASK_TP").trim());
				hmData.put("CHRG_YMDHMS", (String)map.get("TRAN_DTM").trim());
				hmData.put("CHRG_BEF_RAMT", StringUtil.lPad((String)map.get("PPCARD_PRE_REM_AMT"), 10, "0"));
				hmData.put("CHRG_REQ_AMT", StringUtil.lPad((String)map.get("PPCARD_REQ_AMT"), 10, "0"));
				hmData.put("CHRG_AFT_RAMT", StringUtil.lPad((String)map.get("PPCARD_AFT_REM_AMT"), 10, "0"));
				hmData.put("CHRG_BEF_SAM_RAMT", StringUtil.lPad((String)map.get("SAM_PRE_REM_AMT"), 10, "0"));
				hmData.put("CHRG_AFT_SAM_RAMT", StringUtil.lPad((String)map.get("SAM_AFT_REM_AMT"), 10, "0"));	
				hmData.put("CARD_OWNER_ID", (String)map.get("CARD_HOLDER_TP").trim());
				hmData.put("PAY_TP", (String)map.get("PAY_TP").trim());
				hmData.put("MBSCARD_EXP_DT", (String)map.get("MBSCARD_EXP_DT").trim());
				hmData.put("MBSCARD_NO", (String)map.get("MBSCARD_NO").trim());
				hmData.put("FIRST_CHRG_FLAG", (String)map.get("FIRST_CHRG_FLAG").trim());
				hmData.put("FRU", "000");
				hmData.put("CHRG_FEE_RATE", (String)map.get("FEE_RATE").trim());
				hmData.put("CHRG_FEE", StringUtil.lPad((String)map.get("FEE"), 10, "0"));
				hmData.put("SAM_DEAL_SNO", StringUtil.lPad((String)map.get("SAM_TRAN_SEQ_NO").trim(), 10, "0"));
				hmData.put("SAM_ACCM_TOT_CNT", StringUtil.lPad((String)map.get("SAM_ACCM_TOT_CNT"), 10, "0"));
				hmData.put("ALGO_NO", (String)map.get("ALGO_NO").trim());
				hmData.put("KEYSET_VER", (String)map.get("KEYSET_VER").trim());
				hmData.put("CARD_DEPOSIT", StringUtil.lPad((String)map.get("CARD_DEPOSIT"), 10, "0"));
				hmData.put("PENALTY_AMT", StringUtil.lPad((String)map.get("PENALTY_AMT"), 10, "0"));
				hmData.put("CHRG_APPROVAL_NO", (String)map.get("CHRG_APPROVAL_NO").trim());
				hmData.put("PUBCO_ID", (String)map.get("PUBCO_ID").trim());
				hmData.put("SIGN_VAL_IND", (String)map.get("SIGN_VAL_IND").trim());
				hmData.put("SAM_TOT_AMT_COLLECT_CNT", StringUtil.lPad((String)map.get("SAM_TOT_AMT_COLLECT_CNT"), 10, "0"));
				hmData.put("SAM_SPBY_COLLECT_CNT", StringUtil.lPad((String)map.get("SAM_SPBY_COLLECT_CNT"), 5, "0"));
				hmData.put("SAM_ACCM_TOT_AMT", StringUtil.lPad((String)map.get("SAM_ACCM_TOT_AMT"), 10, "0"));
				hmData.put("CENTER_ID", (String)map.get("CENTER_ID"));
				hmData.put("ACCM_MILEAGE_TOT_AMT", StringUtil.lPad((String)map.get("ACCM_MILEAGE_TOT_AMT"), 10, "0"));
				hmData.put("PUBCO_REM_AMT", StringUtil.lPad((String)map.get("PUBCO_REM_AMT"), 10, "0"));
				hmData.put("PUBCO_CHRG_ACCM_AMT", StringUtil.lPad((String)map.get("PUBCO_CHRG_ACCM_AMT"), 10, "0"));
				hmData.put("RFU", (String)map.get("RFU").trim());
				hmData.put("RESND_FG", "0");
				hmData.put("DEAL_RESULT", (String)map.get("TRAN_RESULT").trim());
				hmData.put("ERR_CD", (String)map.get("ERR_OCCU_CD").trim());
				hmData.put("FILLER", " ");
				hmData.put("NLCHAR", String.format("%1c", 10));

				sbFile.append(makeDataOfCashBeeTranFile(hmData));
			}
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			hmTailer.put("RECORD_TP", "T");
			hmTailer.put("FILE_NAME", strTRANFileNM);
			hmTailer.put("DATA_SNO", "99999999");
			hmTailer.put("ADJT_YMD", stdDate);
			hmTailer.put("TOT_CNT", Integer.toString(list.size()));
			hmTailer.put("FILLER", " ");
			hmTailer.put("NLCHAR", String.format("%1c", 10));
			sbFile.append(makeTailerOfTranFile(hmTailer));
			
			// 거래내역 파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRANFileNM);
			
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRANFileNM);
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					dao.updCASHBEETRAN("1", (String)map.get("COM_CD"), (String)map.get("TMNAL_ID")
							, (String)map.get("TRAN_ID"));
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
	
	private String makeHeaderOfFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,20,8,8,301,1};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_NAME",
			"DATA_SNO",
			"ADJT_YMD",
			"FILLER",
			"NLCHAR"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeDataOfCashBeeTranFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,10,2
					  ,16,20,10,3,14
					  ,10,10,10,10,10
					  ,2,1,4,16,1
					  ,3,4,10,10,10
					  ,2,2,10,10,14
					  ,7,16,10,5,10
					  ,2,10,10,10,8
					  ,1,1,2,8,1};
		String strHeaders[] = {
			"RECORD_TP",
			"LENGTH",
			"TMNAL_ID",
			"TRAN_ID",
			"SAM_TP",
			
			"SAM_ID",
			"CARD_NO",
			"CARD_DEAL_SNO",
			"DEAL_TP",
			"CHRG_YMDHMS",
			
			"CHRG_BEF_RAMT",
			"CHRG_REQ_AMT",
			"CHRG_AFT_RAMT",
			"CHRG_BEF_SAM_RAMT",
			"CHRG_AFT_SAM_RAMT",
			
			"CARD_OWNER_ID",
			"PAY_TP",
			"MBSCARD_EXP_DT",
			"MBSCARD_NO",			
			"FIRST_CHRG_FLAG",
			
			"FRU",
			"CHRG_FEE_RATE",
			"CHRG_FEE",
			"SAM_DEAL_SNO",
			"SAM_ACCM_TOT_CNT",
			
			"ALGO_NO",
			"KEYSET_VER",
			"CARD_DEPOSIT",
			"PENALTY_AMT",
			"CHRG_APPROVAL_NO",
			
			"PUBCO_ID",
			"SIGN_VAL_IND",
			"SAM_TOT_AMT_COLLECT_CNT",
			"SAM_SPBY_COLLECT_CNT",
			"SAM_ACCM_TOT_AMT",
			
			"CENTER_ID",
			"ACCM_MILEAGE_TOT_AMT",
			"PUBCO_REM_AMT",
			"PUBCO_CHRG_ACCM_AMT",
			"RFU",
			
			"RESND_FG",
			"DEAL_RESULT",
			"ERR_CD",
			"FILLER",
			"NLCHAR"
		};
		
		for(int i = 0;i < nlens.length;i++) {
			//logger.info(" >>>>> " + strHeaders[i].toString() + "=" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeTailerOfTranFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,20,8,8,7
					  ,294,1};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_NAME",
			"DATA_SNO",
			"ADJT_YMD",
			"TOT_CNT",
			
			"FILLER",
			"NLCHAR"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
}