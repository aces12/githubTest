package biz.cms_MCBDTLDownloader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.HashMap;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import org.apache.log4j.Logger;

import biz.cms_PURCARDDTLDownloader.PURCARDDTLDownloaderDAO;
import biz.comm.COMMBiz;

public class MCBDTLDownloaderInst extends Thread {
	private static Logger logger = Logger.getLogger(MCBDTLDownloaderPollingAction.class);
	
	String path = "";
	
	public MCBDTLDownloaderInst(String path) {
		this.path = path;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
	public void deleteFile(String path, String fileNM) {
		File file = new File(path + File.separator + fileNM);
		if( file.exists() ) {
			logger.info("File Name : " + path + File.separator + fileNM);
			if( file.delete() ) {
				logger.info("File(" + path + File.separator + fileNM + ") removed !!!");
			}
		}
	}
	
	public void copyFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdirs();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(orgFile);
			fos = new FileOutputStream(destFile);
			
			int data = 0;
			while( (data = fis.read()) != -1 ) {
				fos.write(data);
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			try {
				fis.close();
				fis = null;
				fos.flush();
				fos.close();
				fos = null;
				System.gc();
			}catch(Exception e) {
				logger.info(e.getMessage());
			}
		}
		
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public void run() {
		int ret = 0;
		BufferedReader bin = null;
		StringTokenizer st = null;
		String readedLine = "";
		try {			
			MCBDTLDownloaderDAO dao = new MCBDTLDownloaderDAO();

			logger.info(">>>>>>> path = " + path);
			List<File> list = getDirFileList(path);
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			System.out.println("start insertDB");
			HashMap<String, String> hm = new HashMap<String, String>();
			
			for(int i = 0;i < list.size();i++ ) {
				if( !(list.get(i)).isFile() ) {
					continue;
				}
				String targetFile = list.get(i).getName();
				bin = new BufferedReader(new FileReader(path + File.separator + targetFile));
				String toKens = "";
				
				// 끝부분에 내역으로 나누기.
				while( (readedLine = bin.readLine()) != null ) {
					logger.info("[DEBUG] File Name : " + targetFile + ", readedLine = " + readedLine);
					// '\r'와'\n' 구분자로 토큰 분리
					st = new StringTokenizer(readedLine, "\r\n");
					// 이렇게 나누면 끝에 엔터 들어간 부분으로 나뉘어짐. 
					int col = 0;
					Map<String, String> map = new HashMap<String, String>();
					// 각 분리된 토큰을 저장
					while( st.hasMoreTokens() ) {
						
						// H 헤더, D 데이터, T 끝부분
						// 끊어온 부분에 맨 앞의 캐릭터에 따라서 적용이 달라지는데 우리가 실제로 필요한 데이터는 D 부분.
						toKens = "";
						toKens = st.nextToken();
						
						if ( toKens.charAt(0) ==  'A' || toKens.charAt(0) ==  'C' ) {
							// 1 D로 들어왔으면 나누기. 맨 앞 부분이 A(승인),C(취소) 이므로 해당 부분으로만 등록한다.
							// 구분 값으로 나누기.
							hm = getMCBSale(toKens);
							
							// DB에 등록
							try {
								dao.insMCBDTL(hm);
							}catch(Exception e) {
								System.out.println("[ERROR] Error for inserting data : " + e.getMessage());
								logger.info("[ERROR] Error for inserting data : " + e.getMessage());
							}
						}
					}
				}
				
				bin.close();
				bin = null;
				this.moveFile(path, targetFile, path + File.separator + "backup");
				logger.info("Data insert OK.  FTP work well done");
			}										
		}catch(Exception e) {
			logger.info("[ERROR1] " + e.getMessage());
		}finally {
			try {
				if( bin != null ) bin.close();
			}catch(Exception e) {}
		}
	}
	
	private HashMap<String, String> getMCBSale(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {  1, 6, 4
				      , 25
				      ,  8, 5, 4, 4, 6, 23 //,50 50바이트의 전문 대신 각각각 나눠서 대응한다.
				      ,  8, 6, 9};
		String strHeaders[] = 	{ "RECODE_TP_D"
								, "STORE_CD"
								, "POS_NO"

								, "CUL_TRACE_NO" 

								, "TRAN_YMD" ,"TRAN_STRCD","TRAN_POSNO" ,"TRAN_NO" ,"TRAN_HH24MMDD"  ,"TRAN_FILLER"	//, "TRACE_NO" 
								
								, "RESP_DY"
								, "RESP_TM"
								, "PIN_TRADE_AMT"
								};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		for (int i = 0; i < nlens.length; i++) {
			//logger.info("★ getMCBSale  : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			System.out.println("[getMCBSale]  : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
		}
		return hm;
	}
	

	
	
	
	
	
	
	
	
}