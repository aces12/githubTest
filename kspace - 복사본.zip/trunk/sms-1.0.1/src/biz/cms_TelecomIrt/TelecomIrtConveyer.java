package biz.cms_TelecomIrt;

import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_POSIrt.POSIrtDAO;
import biz.cms_POSIrt.POSIrtProtocol;
import biz.comm.AES;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.BasicStringFilter;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;
import kt.ktds.aes256cipher.AES256Cipher;

public class TelecomIrtConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;
	private static Logger logger = Logger.getLogger(TelecomIrtAction.class);

	COMMLog df = null;

	public TelecomIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}

	public String getTelecomKtApprsvr(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {

		POSIrtProtocol protocol = new POSIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		HashMap<String, String> hmReq = new HashMap<String, String>();
		HashMap<String, String> hmReturn = new HashMap<String, String>();
		
		String sendMsg = "";	// 송신 전문
		String recvBuf = "";	// 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
//		String orgAuthNo = ""; 
//		String orgAuthDate = "";
//		int today_from = 0;
//		int today_to = 0;
		String ret = "00";
		try {
//			today_from = (Integer.parseInt(new SimpleDateFormat("mm").format(Calendar.getInstance().getTime())) * 60) + Integer.parseInt(new SimpleDateFormat("ss").format(Calendar.getInstance().getTime()));
//			df.CommLogger("today_from[" + today_from + "]");
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.TELECOM_FILTER)));
			df.CommLogger("actSock.getSocket().getInetAddress()[" + actSock.getSocket().getInetAddress() + "]");
			df.CommLogger("actSock.getSocket().getPort()[" + actSock.getSocket().getPort()+ "]");
			
//			// read-time-out 10초 설정
//			actSock.getSocket().setSoTimeout(10*1000);
			
            //AES256Cipher a256 = AES256Cipher.getInstance();//기존

//            df.CommLogger("TEST 시작");
            AES256Cipher a256 = new AES256Cipher();//신규
//            df.CommLogger("인코딩 TEST");
//            df.CommLogger(a256.AES_Encode("ABCDEFGHIJKLabc"));
//            df.CommLogger("디코딩 TEST");
//            df.CommLogger("TEST 종료");
//            df.CommLogger("hm[" + hm + "]");
//            df.CommLogger("CARD_DATE 암호화 [" + a256.AES_Encode((new AES()).decrypt(((String)hm.get("CARD_DATA")).trim())) + "]");
//            df.CommLogger("CARD_DATE 복호화 [" + a256.AES_Decode(a256.AES_Encode((new AES()).decrypt(((String)hm.get("CARD_DATA")).trim()))) + "]");
//            df.CommLogger("TEST 종료");

			hmReq.put("MSG_TYPE",       (String)hm.get("MSG_TYPE"));                // 전문종류                 
			hmReq.put("PAY_GB",       (String)hm.get("PAY_GB"));                    // 적립구분                 
			hmReq.put("MSG_GB",       (String)hm.get("MSG_GB"));                    // 전문구분                 
			hmReq.put("INPUT_TY",       (String)hm.get("INPUT_TY"));                // 입력구분                 
			hmReq.put("CARD_DATA",       a256.AES_Encode((new AES()).decrypt(((String)hm.get("CARD_DATA")).trim())));            // 카드데이터                
			hmReq.put("TRAN_DATE",       (String)hm.get("TRAN_DATE"));              // 거래일시                     
			hmReq.put("PRODUCT_CD",       (String)hm.get("PRODUCT_CD"));            // PRODUCT코드                     
			hmReq.put("SALE_AMT",       (String)hm.get("SALE_AMT"));                // 거래금액                 
			hmReq.put("ORG_AUTH_NO",       (String)hm.get("ORG_AUTH_NO"));          // 원거래승인번호              
			hmReq.put("ORG_AUTH_DATE",       (String)hm.get("ORG_AUTH_DATE"));      // 원거래승인일자              
			hmReq.put("TRAN_NO",       (String)hm.get("SALE_TRAN_NO"));        // 거래번호  
			hmReq.put("STORE_CD",       (String)hm.get("STORE_CD"));      			// 점포코드   
			hmReq.put("TRAN_END",       "\r\n");      // 전문 종료 구분   

			df.CommLogger("hmReq[" + hmReq + "]");
			
			sendMsg = makeSendDataTelecomKtApprsvr(hmReq);
			
			df.CommLogger("[sms>TelecomKt SEND[" + sendMsg.getBytes().length + "]:[" + sendMsg + "]");
			
			// Socket 통신 시작
			if( actSock.send(sendMsg) ) { // 요청 송신
				df.CommLogger("[sms>TelecomKt] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>TelecomKt] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("TelecomKt server is no response");
			} 

			df.CommLogger("요청");
			recvBuf = ((String)actSock.receive()); // 요청 수신
			df.CommLogger("recvBuf.toString() [" + recvBuf.toString() + "]");
			df.CommLogger("수신완료");
			hmRecv = makeSendDataTelecomKtApprsvrRsp(new String(recvBuf.getBytes("EUC-KR"),"ISO8859_1"));
			df.CommLogger("[TelecomKt>sms hmRecv[" + hmRecv + "]");

			hmReturn.put("RESP_CD",       (String)hmRecv.get("RESP_CD"));                // 응답코드                 
			hmReturn.put("RESP_MSG",       (String)hmRecv.get("RESP_MSG"));                    // 응답메시지                 
			hmReturn.put("AUTH_NO",       (String)hmRecv.get("AUTH_NO"));                    // 승인번호                 
			hmReturn.put("DC_AMT",       (String)hmRecv.get("DC_AMT"));                // 발생포인트(결제금액)                 
			hmReturn.put("DERECT_AMT",       (String)hmRecv.get("DERECT_AMT"));            // 가용포인트                
			hmReturn.put("RECT_AMT",       (String)hmRecv.get("RECT_AMT"));              // 누적포인트                     
			hmReturn.put("AFTER_AMT",       (String)hmRecv.get("AFTER_AMT"));            // 할인후금액                     
			hmReturn.put("USE_AMT1",       (String)hmRecv.get("USE_AMT1"));                // 잔여한도1                 
			hmReturn.put("USE_AMT2",       (String)hmRecv.get("USE_AMT2"));          // 잔여한도2              
			hmReturn.put("STORE_NO",       (String)hmRecv.get("STORE_NO"));      // 가맹점번호              
			hmReturn.put("AUTH_DATE",       (String)hmRecv.get("AUTH_DATE"));        // 승인일자  
			hmReturn.put("AUTH_TIME",       (String)hmRecv.get("AUTH_TIME"));      			// 승인시간   
//			orgAuthNo = (String)hmRecv.get("AUTH_NO"); 
//			orgAuthDate = (String)hmRecv.get("AUTH_DATE"); 
			
//			makeSendDataTelecomKtApprsvrReturn(hmReturn);
			
		}catch(Exception e) { 
			df.CommLogger("e[" + e + "]");
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {			
//			today_to = (Integer.parseInt(new SimpleDateFormat("mm").format(Calendar.getInstance().getTime())) * 60) + Integer.parseInt(new SimpleDateFormat("ss").format(Calendar.getInstance().getTime()));
//
//			df.CommLogger("today_to[" + today_to + "]");
//			if(today_to-today_from>10){
//				dataMsg = "false" + orgAuthNo + orgAuthDate;
//			}else{
//				df.CommLogger("★ make(to POS): " + ret + (String)hm.get("INQ_TYPE") + makeSendDataTelecomKtApprsvrReturn(hmReturn));
//				dataMsg = ret + (String)hm.get("INQ_TYPE") + makeSendDataTelecomKtApprsvrReturn(hmReturn);
//			}
			df.CommLogger("★ make(to POS): " + ret + (String)hm.get("INQ_TYPE") + makeSendDataTelecomKtApprsvrReturn(hmReturn));
			dataMsg = ret + (String)hm.get("INQ_TYPE") + makeSendDataTelecomKtApprsvrReturn(hmReturn);
			// Socket 통신 종료
			actSock.close(); 
		}
		
		return dataMsg;
	}

//	public String getTelecomKtApprsvrCancle(HashMap<String, String> hm,String orgAuthNo,String orgAuthDate) throws Exception {
//
//		POSIrtProtocol protocol = new POSIrtProtocol();
//		String result = "";
//		HashMap<String, String> hmReq = new HashMap<String, String>();
//		HashMap<String, String> hmReturn = new HashMap<String, String>();
//		
//		String sendMsg = "";	// 송신 전문
//		String recvBuf = "";	// 응답 전문
//		String dataMsg = "";	// POS로 보낼 응답 전문
//		int today_from = 0;
//		int today_to = 0;
//		String ret = "00";
//		Calendar calendar = Calendar.getInstance();
//		java.util.Date date = calendar.getTime();
//		try {
//			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.TELECOM_FILTER)));
//			//df.CommLogger("actSock.getSocket().getInetAddress()[" + actSock.getSocket().getInetAddress() + "]");
//			//df.CommLogger("actSock.getSocket().getPort()[" + actSock.getSocket().getPort()+ "]");
//			
//            AES256Cipher a256 = new AES256Cipher();//신규
//
//			hmReq.put("MSG_TYPE",       "1");                // 전문종류                 
//			hmReq.put("PAY_GB",       (String)hm.get("PAY_GB"));                    // 적립구분                 
//			hmReq.put("MSG_GB",       (String)hm.get("MSG_GB"));                    // 전문구분                 
//			hmReq.put("INPUT_TY",       (String)hm.get("INPUT_TY"));                // 입력구분                 
//			hmReq.put("CARD_DATA",       a256.AES_Encode((new AES()).decrypt(((String)hm.get("CARD_DATA")).trim())));            // 카드데이터                
//			hmReq.put("TRAN_DATE",       (String)hm.get("TRAN_DATE"));              // 거래일시                     
//			hmReq.put("PRODUCT_CD",       (String)hm.get("PRODUCT_CD"));            // PRODUCT코드                     
//			hmReq.put("SALE_AMT",       (String)hm.get("SALE_AMT"));                // 거래금액                 
//			hmReq.put("ORG_AUTH_NO",       orgAuthNo);          // 원거래승인번호              
//			hmReq.put("ORG_AUTH_DATE",       orgAuthDate);      // 원거래승인일자              
//			hmReq.put("TRAN_NO",       (String)hm.get("SALE_TRAN_NO"));        // 거래번호  
//			hmReq.put("STORE_CD",       (String)hm.get("STORE_CD"));      			// 점포코드   
//			hmReq.put("TRAN_END",       "\r\n");      // 전문 종료 구분   
//
//			//df.CommLogger("hmReq[" + hmReq + "]");
//			
//			sendMsg = makeSendDataTelecomKtApprsvr(hmReq);
//			
//			df.CommLogger("[sms>TelecomKt SEND[" + sendMsg.getBytes().length + "]:[" + sendMsg + "]");
//			
//			// Socket 통신 시작
//			if( actSock.send(sendMsg) ) { // 요청 송신
//				df.CommLogger("[sms>TelecomKt] Cancle SEND[" + sendMsg.getBytes().length + "] OK");
//			}else {
//				df.CommLogger("[sms>TelecomKt] Cancle SEND[" + sendMsg.getBytes().length + "] ERROR");
//				throw new Exception("TelecomKt server is no response");
//			} 
//
//			recvBuf = ((String)actSock.receive()); // 요청 수신
//			//df.CommLogger("수신완료");
//			//df.CommLogger("취소 수신 recvBuf[" + recvBuf + "]");
//			result = (new String(recvBuf.getBytes("EUC-KR"),"ISO8859_1")).substring(0,4);
//			//df.CommLogger("[TelecomKt>sms hmRecv[" + hmRecv + "]");
//			//df.CommLogger("취소 수신 result[" + result + "]");
//			
//			// Socket 통신 종료
//			actSock.close(); 
//			
//		}catch(Exception e) { 
//			df.CommLogger("e[" + e + "]");
//			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
//			throw e;
//		}
//		return result;
//	}
	
	private String makeSendDataTelecomKtApprsvr(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1, 2, 2, 1, 128, 14, 6, 16, 15, 4, 21, 5, 4};
		String strHeaders[] = {
				"MSG_TYPE",       // 전문종류
				"PAY_GB",         // 적립구분
				"MSG_GB",    	  // 전문구분
				"INPUT_TY",       // 입력구분
				"CARD_DATA",      // 카드데이터
				"TRAN_DATE",      // 거래일시
				"PRODUCT_CD",     // PRODUCT코드
				"SALE_AMT",       // 거래금액
				"ORG_AUTH_NO",    // 원거래승인번호
				"ORG_AUTH_DATE",  // 원거래승인일자
				"TRAN_NO",        // 거래번호
				"STORE_CD",       // 점포코드
				"TRAN_END"        // 전문 종료 구분   
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public HashMap<String, String> makeSendDataTelecomKtApprsvrRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4, 100, 15, 16, 16, 16, 16, 16, 16, 15, 4, 6};
		String strHeaders[] = {
				"RESP_CD",      // 응답코드
				"RESP_MSG",     // 응답메시지
				"AUTH_NO",    	// 승인번호
				"DC_AMT",       // 발생포인트(결제금액)
				"DERECT_AMT",   // 가용포인트
				"RECT_AMT",     // 누적포인트
				"AFTER_AMT",    // 할인후금액
				"USE_AMT1",     // 잔여한도1
				"USE_AMT2",     // 잔여한도2
				"STORE_NO",     // 가맹점번호
				"AUTH_DATE",    // 승인일자
				"AUTH_TIME"    // 승인시간
		};

		int bInx=0;
		int eInx=0;	
		HashMap hm_sub = new HashMap();

		eInx = nlens[0];
		
		for(int i=0; i<nlens.length; i++ ){
			
			try {
				hm_sub.put(strHeaders[i].toString(), new String(rcvBuf.substring(bInx, eInx).getBytes("ISO8859_1"),"EUC-KR"));
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			if (i<nlens.length-1){
				bInx = eInx;
				eInx = eInx+nlens[i+1];
			}
		}
		
		return hm_sub;
	}
	
	
	private String makeSendDataTelecomKtApprsvrReturn(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4, 100, 15, 16, 16, 16, 16, 16, 16, 15, 4, 6};
		String strHeaders[] = {
				"RESP_CD",      // 응답코드
				"RESP_MSG",     // 응답메시지
				"AUTH_NO",    	// 승인번호
				"DC_AMT",       // 발생포인트(결제금액)
				"DERECT_AMT",   // 가용포인트
				"RECT_AMT",     // 누적포인트
				"AFTER_AMT",    // 할인후금액
				"USE_AMT1",     // 잔여한도1
				"USE_AMT2",     // 잔여한도2
				"STORE_NO",     // 가맹점번호
				"AUTH_DATE",    // 승인일자
				"AUTH_TIME"    // 승인시간
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}

}