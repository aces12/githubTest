package biz.cms_SSGMbsIrt;

import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import sun.misc.BASE64Decoder;

import com.cyberpass.seed.Seed;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.node.EngineContainer;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.util.StringUtil;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;
import biz.comm.AES;

public class SSGMbsIrtConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;
//	private EngineContainer container = null;
	
	COMMLog df = null;
	
	public SSGMbsIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}
	
	public String getSSGPointInq(HashMap<String, String> hmComm, HashMap<String, String> hm, boolean bIsExtended) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";		// 신세계포인트로 보낼 송신 전문
		String recvBuf = "";		// 신세계포인트에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
//		String retValue = "OK!";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.SSGPOINT_FILTER)));

			hm.put("MSG_LEN", "0535");
			hm.put("MSG_TEXT", "CONIRT0110");
			hm.put("TRADE_GB_CD", "100010");
			hm.put("BUSI_DT", (String)hmComm.get("TRAN_YMD"));
			hm.put("TRADE_GENTD_DT", (String)hm.get("TRADE_GENTD_DT"));
			hm.put("TRADE_GENTD_TM", (String)hm.get("TRADE_GENTD_TM"));
			hm.put("TRADE_GENTD_STCD", (String)hmComm.get("STORE_CD"));
			hm.put("POS_NO", (String)hmComm.get("POS_NO"));
			hm.put("TRADE_NO", (String)hmComm.get("TRAN_NO"));
			hm.put("APPR_NO", " ");
			if( !bIsExtended ) {
				hm.put("CARD_NO", (String)hm.get("CARD_NO"));
			}else {
				hm.put("CARD_NO", (new AES()).decrypt(((String)hm.get("CARD_NO")).trim()));
			}
			hm.put("BRCH_ID", (String)hm.get("BRCH_ID"));
			hm.put("PASSWD", " ");
			hm.put("CORP_CARD_AMT", "0000000000");
			hm.put("CASH_AMT", "0000000000");
			hm.put("OTHER_ETC_AMT", "0000000000");
			hm.put("NOADD_AMT", "0000000000");
			hm.put("SPOINT_AMT", "0000000000");
			hm.put("TOT_TRADE_AMT", "0000000000");
			hm.put("TPOINT", "00000000");
			hm.put("UBPOINT", "00000000");
			hm.put("GPOINT", "00000000");
			hm.put("REJCT_GB", "0");
			hm.put("OTRADE_BUSI_DT", "00000000");
			hm.put("OTRADE_APPR_NO", "00000000000000000000");
			hm.put("OTRADE_AMT", "0000000000");
			hm.put("REPLY_CD", "0000");
			hm.put("APPR_CRE_DT", "00000000");
			hm.put("APPR_CRE_TM", "000000");
			hm.put("REPLY_MESG", " ");
			hm.put("CUST_ID", " ");
			hm.put("SSGPAY_FLG", " ");
			hm.put("INPUT_FLG", " ");
			hm.put("RESERVE", " ");
			
			sendMsg = makeSendDataSSGPoint(hm, df);
			
			sb = new StringBuffer(sendMsg);
			sb.replace(71, 91, "********************");
			df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("MSG_TEXT") + "]:[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("SSG Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			sb = null;
			sb = new StringBuffer(recvBuf);
			sb.replace(71, 91, "********************");
			df.CommLogger("[sms<ssgpoint] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseSSGPointRsp(recvBuf);
			
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			hmRecv.put("CARD_NO", " ");
			hmRecv.put("TPOINT", ((String)hmRecv.get("TPOINT")).replaceFirst("^0+", ""));
			hmRecv.put("UBPOINT", ((String)hmRecv.get("UBPOINT")).replaceFirst("^0+", ""));
			hmRecv.put("GPOINT", ((String)hmRecv.get("GPOINT")).replaceFirst("^0+", ""));
			hmRecv.put("TPOINT", ((String)hmRecv.get("TPOINT")).equals("") ? "0" : (String)hmRecv.get("TPOINT"));
			hmRecv.put("UBPOINT", ((String)hmRecv.get("UBPOINT")).equals("") ? "0" : (String)hmRecv.get("UBPOINT"));
			hmRecv.put("GPOINT", ((String)hmRecv.get("GPOINT")).equals("") ? "0" : (String)hmRecv.get("GPOINT"));
			hmRecv.put("FILLER", " ");
		}catch(Exception e) {
//			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataSSGPointInqRsp(hmRecv, bIsExtended, df);
//			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		return dataMsg;
	}
	
	private String makeSendDataSSGPoint(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {4,10,6,8,4
					 ,6,5,4,4,20
					 ,20,10,4,10,10
					 ,10,10,10,10,8
					 ,8,8,1,8,20
					 ,10,4,8,6,80
					 ,9,1,1,198};
		String strHeaders[] = { 
				"MSG_LEN"			, // 전문 총길이
				"MSG_TEXT"			, // 전문 구분
				"TRADE_GB_CD"		, // 거래구분코드
				"BUSI_DT"			, // 영업일자
				"TRADE_GENTD_DT"	, // 거래발생일자
				
				"TRADE_GENTD_TM"	, // 거래발생시간
				"TRADE_GENTD_STCD"	, // 거래발생점번호
				"POS_NO"			, // POS번호
				"TRADE_NO"			, // 거래번호
				"APPR_NO"			, // 승인번호
				
				"CARD_NO"			, // 카드번호, 71~91
				"BRCH_ID"			, // 가맹점ID
				"PASSWD"			, // 비밀번호
				"CORP_CARD_AMT"		, // 수단별결제금액 - 제휴카드
				"CASH_AMT"			, // 수단별결제금액 - 현금
				
				"OTHER_ETC_AMT"		, // 수단별결제금액 - 타사카드/기타
				"NOADD_AMT"			, // 수단별결제금액 - 미적립결제액
				"SPOINT_AMT"		, // 수단별결제금액 - S POINT
				"TOT_TRADE_AMT"		, // 총거래금액
				"TPOINT"			, // 누적포인트
				
				"UBPOINT"			, // 가용포인트
				"GPOINT"			, // 금회포인트
				"REJCT_GB"			, // 취소구분(적립취소/사용취소)
				"OTRADE_BUSI_DT"	, // 원거래영업일자
				"OTRADE_APPR_NO"	, // 원거래승인번호
				
				"OTRADE_AMT"		, // 원거래금액
				"REPLY_CD"			, // 응답코드
				"APPR_CRE_DT"		, // 시스템일자
				"APPR_CRE_TM"		, // 시스템시간
				"REPLY_MESG"		, // 영수증출력메시지
				
				"CUST_ID"			, // 고객ID
				"SSGPAY_FLG"		, // SSGPAY 회원여부
				"INPUT_FLG"		, // 포인트카드 인식 구분
				"RESERVE"			  // FILLER
			};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getSSGPointPhoneInq(HashMap<String, String> hmComm, HashMap<String, String> hm, boolean bIsExtended) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmInq = new HashMap<String, String>();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		HashMap<String, String> hmRsp = new HashMap<String, String>();
		
		String sendMsg = "";		// 신세계포인트로 보낼 송신 전문
		String recvBuf = "";		// 신세계포인트에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
//		String retValue = "OK!";

		//df.CommLogger("hm" + hm + "]");
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.SSGPOINT_FILTER)));

			hmInq.put("MSG_LEN", "1005");                                           // (4)전문 총길이
			hmInq.put("MSG_TEXT", "ICPIRT0110"); 									// (10)전문구분
			hmInq.put("TRADE_GB_CD", "100030");                                     // (6)거래구분코드
			hmInq.put("MSG_ID", " ");			                                    // (20)전문ID
			hmInq.put("BUSI_DT", (String)hm.get("SALE_DATE")); 				        // (8)영업일자	 
			hmInq.put("TRADE_GENTD_STCD", (String)hm.get("STORE_CD"));	 	        // (5)거래발생점코드
			hmInq.put("TRADE_GENTD_POSNO", (String)hm.get("POS_NO"));            	// (4)거래발생POS번호
			hmInq.put("TRADE_NO", (String)hm.get("TRAN_NO"));	  			        // (4)거래번호
			hmInq.put("BRCH_ID", (String)hm.get("BRCH_ID"));	                    // (10)가맹점코드
			hmInq.put("TRADE_GENTD_DT", (String)hm.get("TRADE_GENTD_DT"));	        // (4)거래발생일자
			hmInq.put("TRADE_GENTD_TM", (String)hm.get("TRADE_GENTD_TM"));	        // (6)거래발생시간
			hmInq.put("PART_CODE", "130023");	                                    // (6)관계사 코드 : 이마트위드미(130023)
			hmInq.put("MOBILE_NO", (String)hm.get("MOBILE_NO"));	                // (30)핸드폰번호
			hmInq.put("CARD_NO1", " ");	                                            // (50)카드번호1
			hmInq.put("CUST_NM1", " ");	                                            // (30)성명1
			hmInq.put("CARD_NO2", " ");	                                            // (50)카드번호2
			hmInq.put("CUST_NM2", " ");	                                            // (30)성명2
			hmInq.put("CARD_NO3", " ");	                                            // (50)카드번호3
			hmInq.put("CUST_NM3", " ");	                                            // (30)성명3
			hmInq.put("CARD_NO4", " ");	                                            // (50)카드번호4
			hmInq.put("CUST_NM4", " ");	                                            // (30)성명4
			hmInq.put("CARD_NO5", " ");	                                            // (50)카드번호5
			hmInq.put("CUST_NM5", " ");	                                            // (30)성명5
			hmInq.put("CARD_NO6", " ");	                                            // (50)카드번호6
			hmInq.put("CUST_NM6", " ");	                                            // (30)성명6
			hmInq.put("CARD_NO7", " ");	                                            // (50)카드번호7
			hmInq.put("CUST_NM7", " ");	                                            // (30)성명7
			hmInq.put("CARD_NO8", " ");	                                            // (50)카드번호8
			hmInq.put("CUST_NM8", " ");	                                            // (30)성명8
			hmInq.put("CARD_NO9", " ");	                                            // (50)카드번호9
			hmInq.put("CUST_NM9", " ");	                                            // (30)성명9
			hmInq.put("CARD_NO10", " ");	                                        // (50)카드번호10
			hmInq.put("CUST_NM10", " ");	                                        // (30)성명10
			hmInq.put("SYSTEM_CRE_DT", " ");	                                    // (8)시스템일자
			hmInq.put("SYSTEM_CRE_TM", " ");	                                    // (6)시스템시간
			hmInq.put("REPLY_CD", " ");	                                            // (4)응답코드
			hmInq.put("RECV_MESSAGE", " ");	                                        // (80)기타 메시지

			//df.CommLogger("hmInq[" + hmInq + "]");
			sendMsg = makeSendDataSSGPointPhone(hmInq, df);
			
			sb = new StringBuffer(sendMsg);
			df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("MSG_TEXT") + "]:[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("SSG Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			sb = null;
			sb = new StringBuffer(recvBuf);
			df.CommLogger("[sms<ssgpoint] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseSSGPointPhoneRsp(recvBuf);
			//df.CommLogger("hmRecv" + hmRecv + "]");
	
			hmRsp.put("INQ_TYPE",          (String)hm.get("INQ_TYPE"));
			hmRsp.put("SALE_DATE",         (String)hm.get("SALE_DATE"));
			hmRsp.put("STORE_CD",          (String)hm.get("STORE_CD"));
			hmRsp.put("POS_NO",            (String)hm.get("POS_NO"));
			hmRsp.put("TRAN_NO",           (String)hm.get("TRAN_NO"));
			
			hmRsp.put("TRADE_GENTD_DT",    (String)hm.get("TRADE_GENTD_DT"));
			hmRsp.put("TRADE_GENTD_TM",    (String)hm.get("TRADE_GENTD_TM"));
			hmRsp.put("MOBILE_NO",         (String)hm.get("MOBILE_NO"));
			hmRsp.put("BRCH_ID",           (String)hm.get("BRCH_ID"));
			
			hmRsp.put("ENCRYPTION_DATA1",  (String)hmRecv.get("CARD_NO1"));
			hmRsp.put("CUST_NAME1",        (String)hmRecv.get("CUST_NM1"));
			hmRsp.put("ENCRYPTION_DATA2",  (String)hmRecv.get("CARD_NO2"));
			hmRsp.put("CUST_NAME2",        (String)hmRecv.get("CUST_NM2"));
			hmRsp.put("ENCRYPTION_DATA3",  (String)hmRecv.get("CARD_NO3"));
			
			hmRsp.put("CUST_NAME3",        (String)hmRecv.get("CUST_NM3"));
			hmRsp.put("ENCRYPTION_DATA4",  (String)hmRecv.get("CARD_NO4"));
			hmRsp.put("CUST_NAME4",        (String)hmRecv.get("CUST_NM4"));
			hmRsp.put("ENCRYPTION_DATA5",  (String)hmRecv.get("CARD_NO5"));
			hmRsp.put("CUST_NAME5",        (String)hmRecv.get("CUST_NM5"));
			
			hmRsp.put("ENCRYPTION_DATA6",  (String)hmRecv.get("CARD_NO6"));
			hmRsp.put("CUST_NAME6",        (String)hmRecv.get("CUST_NM6"));
			hmRsp.put("ENCRYPTION_DATA7",  (String)hmRecv.get("CARD_NO7"));
			hmRsp.put("CUST_NAME7",        (String)hmRecv.get("CUST_NM7"));
			hmRsp.put("ENCRYPTION_DATA8",  (String)hmRecv.get("CARD_NO8"));
			
			hmRsp.put("CUST_NAME8",        (String)hmRecv.get("CUST_NM8"));
			hmRsp.put("ENCRYPTION_DATA9",  (String)hmRecv.get("CARD_NO9"));
			hmRsp.put("CUST_NAME9",        (String)hmRecv.get("CUST_NM9"));
			hmRsp.put("ENCRYPTION_DATA10", (String)hmRecv.get("CARD_NO10"));
			hmRsp.put("CUST_NAME10",       (String)hmRecv.get("CUST_NM10"));
			
			hmRsp.put("REPLY_CD",          (String)hmRecv.get("REPLY_CD"));
			hmRsp.put("RECV_MESSAGE",      (String)hmRecv.get("RECV_MESSAGE"));
			//df.CommLogger("hmRsp" + hmRsp + "]");
		}catch(Exception e) {
//			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataSSGPointPhoneInqRsp(hmRsp, bIsExtended, df);
			df.CommLogger("dataMsg" + dataMsg + "]");
//			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		return dataMsg;
	}
	
	private String makeSendDataSSGPointPhone(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {4, 10, 6, 10, 8
				      , 5, 4, 4, 10, 4
				      , 6, 6, 30, 50, 30
				      , 50, 30, 50, 30, 50
				      , 30, 50, 30, 50, 30
				      , 50, 30, 50, 30, 50
				      , 30, 50, 30, 8, 6
				      , 4, 80
					 };
		String strHeaders[] = { 
				"MSG_LEN",              // (4)전문 총길이
				"MSG_TEXT", 			// (10)전문구분
				"TRADE_GB_CD",          // (6)거래구분코드
				"MSG_ID", 	            // (10)전문ID
				"BUSI_DT", 		        // (8)영업일자	
				
				"TRADE_GENTD_STCD", 	// (5)거래발생점코드
				"TRADE_GENTD_POSNO", 	// (4)거래발생POS번호
				"TRADE_NO", 	  		// (4)거래번호
				"BRCH_ID", 	            // (10)가맹점코드
				"TRADE_GENTD_DT", 	    // (4)거래발생일자
				
				"TRADE_GENTD_TM", 	    // (6)거래발생시간
				"PART_CODE",            // (6)관계사 코드 : 이마트위드미(130023)
				"MOBILE_NO", 	        // (30)핸드폰번호
				"CARD_NO1",             // (50)카드번호1
				"CUST_NM1",             // (30)성명1
				
				"CARD_NO2",             // (50)카드번호2
				"CUST_NM2",             // (30)성명2
				"CARD_NO3",             // (50)카드번호3
				"CUST_NM3",             // (30)성명3
				"CARD_NO4",             // (50)카드번호4
				
				"CUST_NM4",             // (30)성명4
				"CARD_NO5",             // (50)카드번호5
				"CUST_NM5",             // (30)성명5
				"CARD_NO6",             // (50)카드번호6
				"CUST_NM6",             // (30)성명6
				
				"CARD_NO7",             // (50)카드번호7
				"CUST_NM7",             // (30)성명7
				"CARD_NO8",             // (50)카드번호8
				"CUST_NM8",             // (30)성명8
				"CARD_NO9",             // (50)카드번호9
				
				"CUST_NM9",             // (30)성명9
				"CARD_NO10",            // (50)카드번호10
				"CUST_NM10",            // (30)성명10
				"SYSTEM_CRE_DT",        // (8)시스템일자
				"SYSTEM_CRE_TM",        // (6)시스템시간
				
				"REPLY_CD",             // (4)응답코드
				"RECV_MESSAGE"            // (80)기타 메시지
			};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataSSGPointInqRsp(HashMap hm, boolean bIsExtended, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2,4,6,20,10
					 ,20,8,8,4,8
					 ,6,100};
		int nlensEx[] = {2,4,6,128,10
						,20,8,8,4,8
						,6,100};
		
		String strHeaders[] = {
				"INQ_TYPE"			,
				"TRADE_GENTD_DT"	,
				"TRADE_GENTD_TM"	,
				"CARD_NO"			,
				"BRCH_ID"			,
				"APPR_NO"			,
				"TPOINT"			,
				"UBPOINT"			,
				"REPLY_CD"			,
				"APPR_CRE_DT"		,
				"APPR_CRE_TM"		,
				"FILLER"
			};
		
		if( !bIsExtended ) {
			for (int i = 0; i < nlens.length; i++) {
				//df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
			}
		}else {
			for (int i = 0; i < nlens.length; i++) {
				//df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlensEx[i]);
			}
		}

		return sb.toString();
	}
	
	private String makeSendDataSSGPointPhoneInqRsp(HashMap hm, boolean bIsExtended, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2, 8, 5, 4, 4
			       , 4, 6, 30, 10, 50
			       , 30, 50, 30, 50, 30
			       , 50, 30, 50, 30, 50
			       , 30, 50, 30, 50, 30
			       , 50, 30, 50, 30, 4
			       , 80
			      }; // 798
		
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ종별 : 신세계포인트 전화번호 조회
				"SALE_DATE"	        , // 영업일자
				"STORE_CD"	        , // 가맹점코드(점포코드)
				"POS_NO"	        , // POS번호
				"TRAN_NO"	        , // 거래번호
				
				"TRADE_GENTD_DT"	, // 거래발생일자
				"TRADE_GENTD_TM"	, // 거래발생시간
				"MOBILE_NO"			, // 전화번호
				"BRCH_ID"			, // 가맹점ID		
				"ENCRYPTION_DATA1"	, // (응답) 암호화DATA   -- 1 --
				
				"CUST_NAME1"		, // (응답) 이름	
				"ENCRYPTION_DATA2"	, // (응답) 암호화DATA   -- 2 --
				"CUST_NAME2"		, // (응답) 이름	
				"ENCRYPTION_DATA3"	, // (응답) 암호화DATA   -- 3 --
				"CUST_NAME3"		, // (응답) 이름	
				
				"ENCRYPTION_DATA4"	, // (응답) 암호화DATA   -- 4 --
				"CUST_NAME4"		, // (응답) 이름	
				"ENCRYPTION_DATA5"	, // (응답) 암호화DATA   -- 5 --
				"CUST_NAME5"		, // (응답) 이름	
				"ENCRYPTION_DATA6"	, // (응답) 암호화DATA   -- 6 --
				
				"CUST_NAME6"		, // (응답) 이름	
				"ENCRYPTION_DATA7"	, // (응답) 암호화DATA   -- 7 --
				"CUST_NAME7"		, // (응답) 이름	
				"ENCRYPTION_DATA8"	, // (응답) 암호화DATA   -- 8 --
				"CUST_NAME8"		, // (응답) 이름	
				
				"ENCRYPTION_DATA9"	, // (응답) 암호화DATA   -- 9 --
				"CUST_NAME9"		, // (응답) 이름	
				"ENCRYPTION_DATA10"	, // (응답) 암호화DATA   -- 10 --
				"CUST_NAME10"		, // (응답) 이름
				"REPLY_CD"			, // (응답) 응답코드
				
				"RECV_MESSAGE"		  // (응답) 응답메시지
			};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	public String getSSGPointApproval(HashMap<String, String> hmComm, HashMap<String, String> hm, boolean bIsExtended) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// 신세계포인트로 보낼 송신 전문
		String recvBuf = "";		// 신세계포인트에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		String input_flg = "";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.SSGPOINT_FILTER)));
			
			hm.put("MSG_LEN", "0535");
			hm.put("MSG_TEXT", "CONTRN0121");
			if( ((String)hm.get("TR_GB")).equals("PS") )		// 포인트 적립 전문
				hm.put("TRADE_GB_CD", "200020");
			else if( ((String)hm.get("TR_GB")).equals("PU") )	// 포인트 사용 전문
				hm.put("TRADE_GB_CD", "200030");
			else
				hm.put("TRADE_GB_CD","0");
			hm.put("BUSI_DT", (String)hmComm.get("TRAN_YMD"));
			hm.put("TRADE_GENTD_DT", (String)hm.get("TRADE_GENTD_DT"));
			hm.put("TRADE_GENTD_TM", (String)hm.get("TRADE_GENTD_TM"));			
			hm.put("TRADE_GENTD_STCD", (String)hmComm.get("STORE_CD"));
			hm.put("POS_NO", (String)hmComm.get("POS_NO"));
			hm.put("TRADE_NO", (String)hmComm.get("TRAN_NO"));
			hm.put("APPR_NO", " ");
			if( !bIsExtended ) {
				hm.put("CARD_NO", (String)hm.get("CARD_NO"));
			}else {
				hm.put("CARD_NO", (new AES()).decrypt(((String)hm.get("CARD_NO")).trim()));
			}
			hm.put("BRCH_ID", (String)hm.get("BRCH_ID"));
			hm.put("PASSWD", (String)hm.get("PASSWD"));
			hm.put("CORP_CARD_AMT", (String)hm.get("CORP_CARD_AMT"));
			hm.put("CASH_AMT", (String)hm.get("CASH_AMT"));
			hm.put("OTHER_ETC_AMT", (String)hm.get("OTHER_ETC_AMT"));
			hm.put("NOADD_AMT", (String)hm.get("NOADD_AMT"));
			hm.put("SPOINT_AMT", (String)hm.get("SPOINT_AMT"));
			hm.put("TOT_TRADE_AMT", (String)hm.get("TOT_TRADE_AMT"));
			hm.put("TPOINT", "00000000");
			hm.put("UBPOINT", "00000000");
			hm.put("GPOINT", "00000000");
			hm.put("REJCT_GB", "0");
			hm.put("OTRADE_BUSI_DT", "00000000");
			hm.put("OTRADE_APPR_NO", "00000000000000000000");
			hm.put("OTRADE_AMT", "0000000000");
			hm.put("REPLY_CD", "0000");
			hm.put("APPR_CRE_DT", "00000000");
			hm.put("APPR_CRE_TM", "000000");
			hm.put("REPLY_MESG", " ");
			hm.put("CUST_ID", " ");
			hm.put("SSGPAY_FLG", " ");
			df.CommLogger("(String)hm.get('PASSWD')[" + (String)hm.get("PASSWD") + "]");
			if(!((String)hm.get("PASSWD") == null || "".equals((String)hm.get("PASSWD").replace(" ", "")))){
				input_flg = "T";
			}else{
				input_flg = "M";
			}
			df.CommLogger("input_flg[" + input_flg + "]");
			hm.put("INPUT_FLG", input_flg);
			hm.put("RESERVE", " ");
			
			sendMsg = makeSendDataSSGPoint(hm, df);
			sb = new StringBuffer(sendMsg);
			sb.replace(71, 91, "********************");
			
			df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("MSG_TEXT") + "]:[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("SSG Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			sb = null;
			sb = new StringBuffer(recvBuf);
			sb.replace(71, 91, "********************");
			df.CommLogger("[sms<ssgpoint] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseSSGPointRsp(recvBuf);
			
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			hmRecv.put("CARD_NO", " ");
			hmRecv.put("TR_GB", (String)hm.get("TR_GB"));
			hmRecv.put("TPOINT", ((String)hmRecv.get("TPOINT")).replaceFirst("^0+", ""));
			hmRecv.put("UBPOINT", ((String)hmRecv.get("UBPOINT")).replaceFirst("^0+", ""));
			hmRecv.put("GPOINT", ((String)hmRecv.get("GPOINT")).replaceFirst("^0+", ""));
			hmRecv.put("TPOINT", ((String)hmRecv.get("TPOINT")).equals("") ? "0" : (String)hmRecv.get("TPOINT"));
			hmRecv.put("UBPOINT", ((String)hmRecv.get("UBPOINT")).equals("") ? "0" : (String)hmRecv.get("UBPOINT"));
			hmRecv.put("GPOINT", ((String)hmRecv.get("GPOINT")).equals("") ? "0" : (String)hmRecv.get("GPOINT"));
			hmRecv.put("FILLER", " ");
			
//			df.CommLogger(" >>>>>>>>>>>>> INQ_TYPE : " + (String)hm.get("INQ_TYPE"));
//			df.CommLogger(" >>>>>>>>>>>>> TR_GB : " + (String)hm.get("TR_GB"));
		}catch(Exception e) {
//			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataSSGPointApprovalRsp(hmRecv, bIsExtended, df);
//			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataSSGPointApprovalRsp(HashMap<String, String> hm, boolean bIsExtended, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,4,6,20
					  ,10,4,10,10,10
					  ,10,10,10,8,8
					  ,8,20,4,8,6
					  ,100,9,1};
		int nlensEx[] = {2,2,4,6,128
					  ,10,4,10,10,10
					  ,10,10,10,8,8
					  ,8,20,4,8,6
					  ,100,9,1};
		String strHeaders[] = {
				"INQ_TYPE"			,
				"TR_GB"				,
				"TRADE_GENTD_DT"	,
				"TRADE_GENTD_TM"	,
				"CARD_NO"			,
				
				"BRCH_ID"			,
				"PASSWD"			,
				"CORP_CARD_AMT"		,
				"CASH_AMT"			,
				"OTHER_ETC_AMT"		,
				
				"NOADD_AMT"			,
				"SPOINT_AMT"		,
				"TOT_TRADE_AMT"		,
				"GPOINT"			,
				"TPOINT"			,
				
				"UBPOINT"			,
				"APPR_NO"			,
				"REPLY_CD"			,
				"APPR_CRE_DT"		,
				"APPR_CRE_TM"		,
				
				"FILLER"			,
				"CUST_ID"			,
				"SSGPAY_FLG"
		};
		
		if( !bIsExtended ) {
			for (int i = 0; i < nlens.length; i++) {
				//df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
			}
		}else {
			for (int i = 0; i < nlens.length; i++) {
				//df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlensEx[i]);
			}
		}
		
		return sb.toString();
	}
	
	public String getSSGPointCancel(HashMap<String, String> hmComm, HashMap<String, String> hm, boolean bIsExtended) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";		// 신세계포인트로 보낼 송신 전문
		String recvBuf = "";		// 신세계포인트에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		String retValue = "OK!";
		String input_flg = "";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.SSGPOINT_FILTER)));
			
			hm.put("MSG_LEN", "0535");
			hm.put("MSG_TEXT", "CONTRN0141");
			hm.put("TRADE_GB_CD", "400080");
			hm.put("BUSI_DT", (String)hmComm.get("TRAN_YMD"));
			hm.put("TRADE_GENTD_DT", (String)hm.get("TRADE_GENTD_DT"));
			hm.put("TRADE_GENTD_TM", (String)hm.get("TRADE_GENTD_TM"));
			hm.put("TRADE_GENTD_STCD", (String)hmComm.get("STORE_CD"));
			hm.put("POS_NO", (String)hmComm.get("POS_NO"));
			hm.put("TRADE_NO", (String)hmComm.get("TRAN_NO"));
			hm.put("APPR_NO", " ");
			if( !bIsExtended ) {
				hm.put("CARD_NO", (String)hm.get("CARD_NO"));
			}else {
				hm.put("CARD_NO", (new AES()).decrypt(((String)hm.get("CARD_NO")).trim()));
			}
			hm.put("BRCH_ID", (String)hm.get("BRCH_ID"));
			hm.put("PASSWD", " ");
			hm.put("CORP_CARD_AMT", (String)hm.get("CORP_CARD_AMT"));
			hm.put("CASH_AMT", (String)hm.get("CASH_AMT"));
			hm.put("OTHER_ETC_AMT", (String)hm.get("OTHER_ETC_AMT"));
			hm.put("NOADD_AMT", (String)hm.get("NOADD_AMT"));
			hm.put("SPOINT_AMT", (String)hm.get("SPOINT_AMT"));
			hm.put("TOT_TRADE_AMT", (String)hm.get("TOT_TRADE_AMT"));
			hm.put("TPOINT", "00000000");
			hm.put("UBPOINT", "00000000");
			hm.put("GPOINT", "00000000");
			hm.put("REJCT_GB", (String)hm.get("REJCT_GB"));
			hm.put("OTRADE_BUSI_DT", (String)hm.get("OTRADE_BUSI_DT"));
			hm.put("OTRADE_APPR_NO", (String)hm.get("OTRADE_APPR_NO"));
			hm.put("OTRADE_AMT", (String)hm.get("OTRADE_AMT"));
			hm.put("REPLY_CD", "0000");
			hm.put("APPR_CRE_DT", "00000000");
			hm.put("APPR_CRE_TM", "000000");
			hm.put("REPLY_MESG", " ");
			hm.put("CUST_ID", " ");
			hm.put("SSGPAY_FLG", " ");	
			df.CommLogger("(String)hm.get('PASSWD')[" + (String)hm.get("PASSWD") + "]");
			if(!((String)hm.get("PASSWD") == null || "".equals((String)hm.get("PASSWD").replace(" ", "")))){
				input_flg = "T";
			}else{
				input_flg = "M";
			}
			hm.put("INPUT_FLG", "");		
			hm.put("RESERVE", " ");
			
			sendMsg = makeSendDataSSGPoint(hm, df);
			sb = new StringBuffer(sendMsg);
			sb.replace(71, 91, "********************");
			df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("MSG_TEXT") + "]:[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("SSG Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			sb = null;
			sb = new StringBuffer(recvBuf);
			sb.replace(71, 91, "********************");
			df.CommLogger("[sms<ssgpoint] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseSSGPointRsp(recvBuf);
			
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			hmRecv.put("CARD_NO", " ");
			hmRecv.put("TPOINT", ((String)hmRecv.get("TPOINT")).replaceFirst("^0+", ""));
			hmRecv.put("UBPOINT", ((String)hmRecv.get("UBPOINT")).replaceFirst("^0+", ""));
			hmRecv.put("GPOINT", ((String)hmRecv.get("GPOINT")).replaceFirst("^0+", ""));
			hmRecv.put("TPOINT", ((String)hmRecv.get("TPOINT")).equals("") ? "0" : (String)hmRecv.get("TPOINT"));
			hmRecv.put("UBPOINT", ((String)hmRecv.get("UBPOINT")).equals("") ? "0" : (String)hmRecv.get("UBPOINT"));
			hmRecv.put("GPOINT", ((String)hmRecv.get("GPOINT")).equals("") ? "0" : (String)hmRecv.get("GPOINT"));
			hmRecv.put("FILLER", " ");
		}catch(Exception e) {
//			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataSSGPointCancelRsp(hmRecv, bIsExtended, df);
//			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		return dataMsg;
	}
	
	private String makeSendDataSSGPointCancelRsp(HashMap hm, boolean bIsExtended, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,4,6,20,10
					  ,1,10,10,10,10
					  ,10,10,8,20,10
					  ,20,8,8,8,4
					  ,8,6,100};
		int nlensEx[] = {2,4,6,128,10
					  	,1,10,10,10,10
					    ,10,10,8,20,10
						,20,8,8,8,4
						,8,6,100};
		String strHeaders[] = {
				"INQ_TYPE"			,
				"TRADE_GENTD_DT"	,
				"TRADE_GENTD_TM"	,
				"CARD_NO"			,
				"BRCH_ID"			,
				
				"REJCT_GB"			,
				"CORP_CARD_AMT"		,
				"CASH_AMT"			,
				"OTHER_ETC_AMT"		,
				"NOADD_AMT"			,
				
				"SPOINT_AMT"		,
				"TOT_TRADE_AMT"		,
				"OTRADE_BUSI_DT"	,
				"OTRADE_APPR_NO"	,
				"OTRADE_AMT"		,
				
				"APPR_NO"			,
				"TPOINT"			,
				"UBPOINT"			,
				"GPOINT"			,
				"REPLY_CD"			,
				
				"APPR_CRE_DT"		,
				"APPR_CRE_TM"		,
				"FILLER"
		};
		
		if( !bIsExtended ) {
			for (int i = 0; i < nlens.length; i++) {
				//df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
			}
		}else {
			for (int i = 0; i < nlens.length; i++) {
				//df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlensEx[i]);
			}
		}
		
		return sb.toString();
	}
	
	public String getWeChatInq(HashMap<String, String> hmComm, HashMap<String, String> hm, int inqType) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		String sendMsg = "";		// 신세계머니로 보낼 송신 전문
		String recvBuf = "";		// 신세계머니에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String todayDT = sdf.format(calendar.getTime());
		String msgID        = "";
		String tranType     = ""; // 00:승인, 01:취소, 02:환불, 05:조회
		String tradeAmt     = ""; // 조회외에는 필수: "000000005800"
		String pinNo        = ""; // PIN 번호 ("활성화/취소"를 제외하고는 필수)
		String sendDate = hmComm.get("SYS_YMD");
		String sendTime = hmComm.get("SYS_HMS");
		String itemTitle = "";
		String itemContent = "";
		
		int parseStart = hm.get("ITEM_TITLE").indexOf("|");
		
		df.CommLogger("parseStart::["+parseStart+"]");
		
		if(parseStart > 0){
			//20180110 KSN 위챗 전문수정
			itemTitle = hm.get("ITEM_TITLE").substring(0, parseStart);
			itemContent = hm.get("ITEM_TITLE").substring(parseStart+1);
			
			df.CommLogger("WeChat::itemTitle::["+itemTitle+"]");
			df.CommLogger("WeChat::itemContent::["+itemContent+"]");
		}else{
			itemTitle = hm.get("ITEM_TITLE");
			itemContent = "";
		}

		df.CommLogger("WeChat SEND_DATE=[" + sendDate + "]");
		df.CommLogger("WeChat SEND_TIME=[" + sendTime + "]");

		switch (inqType) {
			case 80: // 위챗페이 조회 
				msgID     = "WEIF0100";
				tranType  = "03"; 
				break;
				
			case 81: // 위챗페이 승인 
				msgID     = "WEIS0100";
				tranType  = "00";
				break;
				
			case 82: // 위챗페이 승인취소  
				msgID     = "WEIU0100";
				tranType  = "01";
				break;
		}
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.SSGPOINT_FILTER)));

			hm.put("MSG_LEN", "0900"); 							// 01. 전문길이(4)
			hm.put("MSG_ID", msgID); 							// 02. 전문ID(8)
			hm.put("MCH_SEND_DATE", (String)hmComm.get("TRAN_YMD")); // 03. 전문전송일자(8)
			
			hm.put("MCH_SEND_UNIQ_NO", 
					  hmComm.get("TRAN_YMD")
					+ hmComm.get("POS_NO")
					+ "0000"
					+ hmComm.get("TRAN_NO"));			 		// 04. 전송거래고유번호(20)
			
			hm.put("MCH_NO", "FM00010772");         			// 05. 가맹점번호(15)  ==> 운영적용시 확인 (kkk 1)
			hm.put("MSG_GUBUN", "SEND");                 		// 06. 요청구분(4)
			hm.put("SER_COM_CD", "5700");                		// 07. 회사코드(4)  5700:위드미
			
			hm.put("SALE_DATE", sendDate);  					// 08. 영업일자(8) 
			hm.put("SALE_TIME", sendTime);  					// 09. 영업시간(6)
			
			df.CommLogger("CASHER_NO=[" + hm.get("CASHER_NO")     + "]");
			df.CommLogger("STORE_CD =[" + hmComm.get("STORE_CD")  + "]");
			
			hm.put("ST_CODE", hmComm.get("STORE_CD"));   		// 10. 점코드(10)
//			hm.put("ST_CODE", "00000");   						// 10. 점코드(10)     ==> 운영적용시 확인 (kkk 2)
			
			hm.put("TM_NO", hmComm.get("POS_NO"));       		// 11. POS 번호(4)
			hm.put("CD_NO", "0000");                     		// 12. CD 번호(4)
			hm.put("TRAN_NO", hmComm.get("TRAN_NO"));    		// 13. 거래 번호(4)
			
			hm.put("CASHER_NO", hm.get("CASHER_NO"));    		// 14. Casher 번호(10) (POS)
//			hm.put("CASHER_NO", "00000");    					// 14. Casher 번호(10) (POS) ==> 운영적용시 확인 (kkk 3)
			
			hm.put("POS_DATE", sendDate);    					// 15. POS시스템일자(8)
			hm.put("POS_TIME", sendTime);    					// 16. POS시스템시간(6)
			
			hm.put("SER_COM_UNIQ_NO", " ");      				// 17. 회사별 요청자 정보(20) (불필요: SPACE로 채움)
			hm.put("JUMPO_SYS_DATE", sendDate);  				// 18. 점포서버 전문전송일자(8)
			hm.put("JUMPO_SYS_TIME", sendTime); 		 		// 19. 점포서버 전문전송시간(6)
			hm.put("HEAD_ETC_FIELD", " "); 						// 20. 헤더예비필드(53) (불필요: SPACE로 채움)

			hm.put("TRAN_TYPE", tranType); 						// 21. 거래 TYPE(2) (00:승인, 01:취소, 03:조회)
			hm.put("AUTH_CODE",  hm.get("AUTH_CODE")); 			// 22. 인증코드 (18)
			hm.put("ITEM_CODE", " "); 							// 23. 상품코드 (32) (불필요: SPACE로 채움)
			hm.put("ITEM_TITLE", itemTitle); 					// 24. 상품이름 (127)
			
			if(todayDT.compareTo("20180120000000") >= 0){
				hm.put("ITEM_CONTENT", itemContent); 			// 25. 상품설명 (127) (불필요: SPACE로 채움)
			}else{
				hm.put("ITEM_CONTENT", ""); 					// 25. 상품설명 (127) (불필요: SPACE로 채움)
			}
			
			hm.put("PAY_CURRENCY", hm.get("PAY_CURRENCY")); 	// 26. 결제요청통화 (3)
			hm.put("PAY_RATE", "0000.00"); 						// 27. 결제요청환율 (7)
			hm.put("PAY_KRW_AMOUNT", hm.get("PAY_KRW_AMOUNT")); // 28. 결제요청금액(원화) (13)
			hm.put("PAY_USD_AMOUNT", "0000000000.00"); 			// 29. 결제요청금액(외화) (13)

			//------------------------------------------
			// 승인취소시 필수, 그외에는 SPACE
			//------------------------------------------
			if ((inqType == 82) || (inqType == 80)) // 승인취소 이면
			{
				hm.put("ORG_SER_COM_CD"  , "5700"); // 30. 원거래 회사코드 (4)
				//hm.put("ORG_SALE_DATE"   , "1"); // 31. 원거래 영업일자 (8)
				hm.put("ORG_ST_CODE"     , hm.get("ORG_ST_CODE")); // 32. 원거래 점코드 (10)
				//hm.put("ORG_TM_NO"       , " "); // 33. 원거래 포스번호 (4)
				//hm.put("ORG_TRAN_NO"     , " "); // 34. 원거래 거래번호 (4)
				//hm.put("ORG_CD_NO"       , "5700"); // 35. 원거래 CD번호 (4)
				hm.put("ORG_CASHER_NO"   , hm.get("ORG_CASHER_NO"));    // 36. 원거래 Casher번호 (10)
				hm.put("ORG_SEND_DATE"   , hm.get("ORG_SEND_DATE"));    // 37. 원거래 전문전송일자 (8)
				hm.put("ORG_SEND_UNIQ_NO", hm.get("ORG_SEND_UNIQ_NO")); // 38. 원거래 전송고유번호 (20)
				hm.put("ORG_MCH_NO"      , "FM00010772");       // 39. 원거래 가맹점번호 (15)
				hm.put("ORG_AUTH_DATE"   , hm.get("ORG_AUTH_DATE"));    // 40. 원거래 승인일자 (8)
				hm.put("ORG_AUTH_NO"     , hm.get("ORG_AUTH_NO"));      // 41. 원거래 승인번호 (32)
			}
			else
			{
				hm.put("ORG_SER_COM_CD"  , " "); // 30. 원거래 회사코드 (4)
				hm.put("ORG_SALE_DATE"   , " "); // 31. 원거래 영업일자 (8)
				hm.put("ORG_ST_CODE"     , " "); // 32. 원거래 점코드 (10)
				hm.put("ORG_TM_NO"       , " "); // 33. 원거래 포스번호 (4)
				hm.put("ORG_TRAN_NO"     , " "); // 34. 원거래 거래번호 (4)
				hm.put("ORG_CD_NO"       , " "); // 35. 원거래 CD번호 (4)
				hm.put("ORG_CASHER_NO"   , " "); // 36. 원거래 Casher번호 (10)
				hm.put("ORG_SEND_DATE"   , " "); // 37. 원거래 전문전송일자 (8)
				hm.put("ORG_SEND_UNIQ_NO", " "); // 38. 원거래 전송고유번호 (20)
				hm.put("ORG_MCH_NO"      , " "); // 39. 원거래 가맹점번호 (15)
				hm.put("ORG_AUTH_DATE"   , " "); // 40. 원거래 승인일자 (8)
				hm.put("ORG_AUTH_NO"     , " "); // 41. 원거래 승인번호 (32)
			}

			hm.put("AUTH_DATE", " "); // 42. 승인일자 (8)
			hm.put("AUTH_TIME", " "); // 43. 승인시간 (6)
			hm.put("AUTH_NO", " ");   // 44. 승인번호 (32)
			hm.put("RESP_CODE", " "); // 45. 응답코드 (4)
			
			hm.put("RESP_MSG", " ");  // 46. 응답메시지 (128)
			hm.put("PAY_STATUS", " ");  // 47. 결제상태 (1)
			hm.put("CANCEL_STATUS", " ");    // 48. 취소상태 (1)
			hm.put("DATA_ETC_FIELD", " "); // 49. DATA예비필드 (40)
			hm.put("MSG_END", " "); // 50. 전문종료바이트 (1)
			
			df.CommLogger("================ 2-1) SMS->SSG 송신전문 ===================");
			sendMsg = makeSendDataWeChat(hm, df);
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문종료내역 설정
			sendBytes[899] = (byte)0x0d;
			
			sb = new StringBuffer(sendMsg);
			sb.replace(315, 315+19, "*******************");
			
			df.CommLogger("================ 2-2) SMS->SSG 송신전문 ===================");
			df.CommLogger("전문길이=[" + sb.length() + "]");
			df.CommLogger("MSG_ID  =[" + (String)hm.get("MSG_ID") + "]");
			df.CommLogger("전문내용=[" + sb.toString() + "]");

			if (actSock.send(sendBytes, sendBytes.length))
			{
				df.CommLogger("[sms>ssg] SEND[" + sendBytes.length + "] OK");
			} 
			else 
			{
				df.CommLogger("[sms>ssg] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSG Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			sb = null;
			sb = new StringBuffer(recvBuf);
			sb.replace(315, 315+19, "*******************");
			
			df.CommLogger("================ 3-1) SMS<-SSG 응답전문 ===================");
			df.CommLogger("전문길이=[" + recvBuf.getBytes().length + "]");
			df.CommLogger("전문내용=[" + sb.toString() + "]");
			
			df.CommLogger("================ 3-2) SMS<-SSG 응답전문 ===================");
			hmRecv = protocol.getParseWeChatRsp(recvBuf);
			
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
		}
		catch (Exception e) 
		{
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}
		finally 
		{
			actSock.close();
			df.CommLogger("================ 4-1) POS<-SMS 응답전문 ===================");
			dataMsg = ret + makeSendDataWeChatRsp(hmRecv, df);
			df.CommLogger("dataMsg=[" + dataMsg + "]");
		}
		
		return dataMsg;
	}
	
	//20170828 알리페이결제수단추가 _ LYH
	public String getAlipayRsp(HashMap<String, String> hmComm, HashMap<String, String> hm, int inqType) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();

		HashMap<String, String> hmSend = new HashMap<String,String>();
		HashMap<String, String> hmRecv = new HashMap<String, String>();

		String sendMsg = "";		// Alipay Platform으로 보낼 송신 전문
		String recvBuf = "";		// Alipay Platform에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		String ALIPAY_MCH_NO = PropertyUtil.findProperty("service-property", "ALIPAY_MCH_NO");

		String sendDate = hmComm.get("SYS_YMD");
		String sendTime = hmComm.get("SYS_HMS");

		df.CommLogger("Alipay SEND_DATE=[" + sendDate + "]");
		df.CommLogger("Alipay SEND_TIME=[" + sendTime + "]");
		df.CommLogger("====== POS INPUT DATA ===============");
		for(Map.Entry<String,String> data : hm.entrySet()){
			df.CommLogger("["+data.getKey()+"]=" + data.getValue());
		}
		try {
			hmSend.put("AUTH_CODE",hm.get("AUTH_CODE")); // 바코드번호
			hmSend.put("AUTH_DT",nvl(hm.get("AUTH_DT")," ")); // 승인일시
			hmSend.put("AUTH_NO",nvl(hm.get("AUTH_NO")," ")); // 승인번호
			hmSend.put("DATE_ETC_FILED",nvl(hm.get("FILLER")," ")); // filler
			hmSend.put("KEY_IN_TYP",hm.get("INPUT_TYPE")); // WCC
			hmSend.put("MCH_NO",nvl(hm.get("MCH_NO"),ALIPAY_MCH_NO)); //  가맹점번호
			// 거래고유번호
			df.CommLogger("Alipay MCH_SEND_UNIQ_NO=[" + hm.get("MCH_SEND_UNIQ_NO") + "]");
			if(hm.get("MCH_SEND_UNIQ_NO") == null || hm.get("MCH_SEND_UNIQ_NO").trim().equals("")) {
				SSGMbsIrtDAO dao = new SSGMbsIrtDAO();
				String mchSendUniqNo = dao.selAlipayMchSendSeq(sendDate);
				df.CommLogger("Generated MCH_SEND_UNIQ_NO=" + mchSendUniqNo);
				hmSend.put("MCH_SEND_UNIQ_NO",mchSendUniqNo);
			}else {
				hmSend.put("MCH_SEND_UNIQ_NO",hm.get("MCH_SEND_UNIQ_NO")); 
			}
			hmSend.put("MCH_TYP",nvl(hm.get("MCH_TYPE")," ")); // 가맹점 구분
			hmSend.put("MCH_USE",nvl(hm.get("MCH_USE")," ")); // 가맹점 추가 사용
			hmSend.put("MSG_END"," "); // CR
			hmSend.put("MSG_TYP",hm.get("MSG_TYP")); // 메세지타입
			hmSend.put("ORG_AUTH_DD",nvl(hm.get("ORG_AUTH_DT")," ")); // 원거래 승인일자
			hmSend.put("ORG_AUTH_NO",nvl(hm.get("ORG_AUTH_NO")," ")); // 원거래 승인번호
			hmSend.put("PAY_AMOUNT",hm.get("PAY_AMT")); // 거래금액
			hmSend.put("PAY_CUR",hm.get("PAY_CUR")); // 통화코드
			hmSend.put("PAY_INFO"," "); //  알리페이 결재정보
			hmSend.put("PAY_STATUS"," ");  // 알리페이 거래 상태
			hmSend.put("POS_DD",hmComm.get("SYS_YMD")); // 시스템일자
			hmSend.put("POS_TM",hmComm.get("SYS_HMS")); // 시스템시간
			hmSend.put("RESP_CODE"," "); // 응답메세지코드
			hmSend.put("RESP_MSG"," "); // 응답메세지
			hmSend.put("SALE_DD",hmComm.get("SYS_YMD")); // 영업일자
			hmSend.put("SER_COM_CD",nvl(hm.get("SER_COM_CD"),"5700")); // 회사코드
			hmSend.put("ST_CODE",hmComm.get("STORE_CD")); // 점포코드
			hmSend.put("TERMINAL_ID",nvl(hm.get("TERMINAL_ID"),"")); // 터미널 ID
			hmSend.put("TM_NO",hmComm.get("POS_NO")); //  POS 번호 
			hmSend.put("TRAN_CODE",nvl(hm.get("TRAN_CODE"),"AP")); // TRAN_CODE
	
			if( 2130  == inqType ) {
				// Alipay 조회 
				hmSend.put("MSG_ID", "0345ALIF"); // Option Data
			}else if(2131 == inqType) {
				// Alipay 승인 
				hmSend.put("MSG_ID", "0345ALIS"); // Option Data
			}else if(2132 == inqType) {
				// Alipay 승인취소/망취소
				hmSend.put("MSG_ID", "0345ALIR"); // Option Data
			}
		}catch(Exception e) 
		{
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}

		df.CommLogger("============ SEND DATA ===============");
		for(Map.Entry<String,String> data: hmSend.entrySet()){
			df.CommLogger("["+data.getKey()+"]=" + data.getValue());
		}
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.ALIPAY_FILTER)));

			df.CommLogger("================ 2-1) SMS->ALIPAY PLATFORM 송신전문 ===================");
			sendMsg = makeSendDataAlipay(hmSend, df);
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문종료내역 설정
			sendBytes[344] = (byte)0x0d;
			
			sb = new StringBuffer(sendMsg);
			
			df.CommLogger("================ 2-2) SMS->ALIPAY PLATFORM 송신전문 ===================");
			df.CommLogger("전문길이=[" + sb.length() + "]");
			df.CommLogger("MSG_ID  =[" + (String)hm.get("MSG_ID") + "]");
			df.CommLogger("전문내용=[" + sb.toString() + "]");

			if (actSock.send(sendBytes, sendBytes.length))
			{
				df.CommLogger("[sms>alipay platform] SEND[" + sendBytes.length + "] OK");
			} 
			else 
			{
				df.CommLogger("[sms>alipay platform] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("Alipay Platform Server is no response");
			}
			
			recvBuf = (String)actSock.receive();
			sb = null;
			sb = new StringBuffer(recvBuf);
			
			
			df.CommLogger("================ 3-1) SMS<-ALIPAY PLATFORM 응답전문 ===================");
			df.CommLogger("전문길이=[" + recvBuf.getBytes().length + "]");
			df.CommLogger("전문내용=[" + sb.toString() + "]");
			
			df.CommLogger("================ 3-2) SMS<-ALIPAY PLATFORM 응답전문 ===================");
			hmRecv = protocol.getParseAlipayRsp(recvBuf);
			df.CommLogger("============ RECEIVE ===============");
			for(Map.Entry<String,String> data : hmRecv.entrySet()){
				df.CommLogger("["+data.getKey()+"]=" + data.getValue());
			}			
		}
		catch (Exception e) 
		{
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}
		finally 
		{
			actSock.close();
			df.CommLogger("================ 4-1) POS<-SMS 응답전문 ===================");
			dataMsg = ret + makeSendDataAlipayRsp(hmRecv, df);
			df.CommLogger("dataMsg=[" + dataMsg + "]");
		}
		
		return dataMsg;
	}
	
	private String makeSendDataAlipay(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= { 9, 4, 2, 15, 8,
					   6, 4, 12, 3, 12,

					   1, 20, 14, 12, 8,
					   12, 4, 2, 30, 15,

					   40, 50, 4, 8, 6,
					   1, 42, 1 
					};
		
        String strHeaders[] = {
        		"MSG_ID"           , // 01. Option Data (9)
        		"MSG_TYP"          , // 02. 메세지타입 (4)
        		"TRAN_CODE"        , // 03. TRAN_CODE (2)
        		"TERMINAL_ID"      , // 04. 터미널 ID (15)
        		"SALE_DD"          , // 05. 영업일자 YYYYMMDD (8)

        		"ST_CODE"          , // 06. 점포코드 (6)
        		"TM_NO"            , // 07. POS 번호 (4)
        		"MCH_SEND_UNIQ_NO" , // 08. 거래고유번호 (12)
        		"PAY_CUR"          , // 09. 통화코드 (3)
        		"PAY_AMOUNT"       , // 10. 거래금액 (12)

        		"KEY_IN_TYP"       , // 11. WCC (1)
        		"MCH_USE"          , // 12. 가맹점 추가 사용. (20)
        		"AUTH_DT"          , // 13. 승인일시 YYYYMMDDhhmmss  (14)
        		"AUTH_NO"          , // 14. 승인번호 (12)
        		"ORG_AUTH_DD"      , // 15. 원거래 승인일자 (8)

        		"ORG_AUTH_NO"      , // 16. 원거래 승인번호 (12)
        		"RESP_CODE"        , // 17. 응답메세지코드(4)
        		"MCH_TYP"          , // 18. 가맹점 구분 (2)
        		"AUTH_CODE"        , // 19. 바코드번호 (30)
        		"MCH_NO"           , // 20. 가맹점번호 (15)

        		"RESP_MSG"         , // 21. 응답메세지 (40)
        		"PAY_INFO"         , // 22. 알리페이 결재정보(50)
        		"SER_COM_CD"       , // 23. 회사코드 (4)
        		"POS_DD"           , // 24. POS 시스템일자 YYYYMMDD (8)
        		"POS_TM"           , // 25. POS 시스템시간 24HMISS (6)

        		"PAY_STATUS"       , // 26. 알리페이 거래 상태(1)
        		"DATE_ETC_FILED"   , // 27. filler (42)
        		"MSG_END"           // 28. CR (1)
            };

		for (int i = 0; i < nlens.length; i++) 
		{
			df.CommLogger((i+1) + ") " + "["+strHeaders[i]+"]=" + hm.get(strHeaders[i]));
			StringUtil.appendSpace(sb, hm.get(strHeaders[i]), nlens[i]);
		}
		
		return sb.toString();
	}

	private String makeSendDataWeChat(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {4,8,8,20,15
					 ,4,4,8,6,10
					 
					 ,4,4,4,10,8
					 ,6,20,8,6,53
					 
					 ,2,18,32,127,127
					 ,3,7,13,13,4
					 
					 ,8,10,4,4,4
					 ,10,8,20,15,8
					 
					 ,32,8,6,32,4
					 ,128,1,1,40,1
				};
		
        String strHeaders[] = {
                "MSG_LEN"           , // 01. 전문 길이
                "MSG_ID"            , // 02. 전문 ID
                "MCH_SEND_DATE"     , // 03. 전문전송일자
                "MCH_SEND_UNIQ_NO"  , // 04. 전송거래고유번호
                "MCH_NO"            , // 05. 가맹점번호

                "MSG_GUBUN"         , // 06. 요청구분
                "SER_COM_CD"        , // 07. 회사코드
                "SALE_DATE"         , // 08. 영업일자
                "SALE_TIME"         , // 09. 영업시간
                "ST_CODE"           , // 10. 점코드

                "TM_NO"             , // 11. 포스 번호
                "CD_NO"             , // 12. CD 번호
                "TRAN_NO"           , // 13. 거래 번호
                "CASHER_NO"         , // 14. Casher 번호
                "POS_DATE"          , // 15. POS시스템일자

                "POS_TIME"          , // 16. POS시스템시간
                "SER_COM_UNIQ_NO"   , // 17. 회사별 요청자 정보
                "JUMPO_SYS_DATE"    , // 18. 점포서버 전문전송일자
                "JUMPO_SYS_TIME"    , // 19. 점포서버 전문전송시간
                "HEAD_ETC_FIELD"    , // 20. 헤더예비필드

                "TRAN_TYPE"          , // 21. 거래TYPE (2)
                "AUTH_CODE"          , // 22. 인증코드 (18)
                "ITEM_CODE"          , // 23. 상품코드 (32)
                "ITEM_TITLE"         , // 24. 상품이름 (127)
                "ITEM_CONTENT"       , // 25. 상품설명 (127)

                "PAY_CURRENCY"       , // 26. 결제요청통화 (3)
                "PAY_RATE"           , // 27. 결제요청환율 (7)
                "PAY_KRW_AMOUNT"     , // 28. 결제요청금액(원화) (13)
                "PAY_USD_AMOUNT"     , // 29. 결제요청금액(외화) (13)
                "ORG_SER_COM_CD"     , // 30. 원거래 회사코드 (4)

                "ORG_SALE_DATE"      , // 31. 원거래 영업일자 (8)
                "ORG_ST_CODE"        , // 32. 원거래 점코드 (10)
                "ORG_TM_NO"          , // 33. 원거래 포스번호 (4)
                "ORG_TRAN_NO"        , // 34. 원거래 거래번호 (4)
                "ORG_CD_NO"          , // 35. 원거래 CD번호 (4)

                "ORG_CASHER_NO"      , // 36. 원거래 Casher번호 (10)
                "ORG_SEND_DATE"      , // 37. 원거래 전문전송일자 (8)
                "ORG_SEND_UNIQ_NO"   , // 38. 원거래 전송고유번호 (20)
                "ORG_MCH_NO"         , // 39. 원거래 가맹점번호 (15)
                "ORG_AUTH_DATE"      , // 40. 원거래 승인일자 (8)

                "ORG_AUTH_NO"        , // 41. 원거래 승인번호 (32)
                "AUTH_DATE"          , // 42. 승인일자 (8)
                "AUTH_TIME"          , // 43. 승인시간 (6)
                "AUTH_NO"            , // 44. 승인번호 (32)
                "RESP_CODE"          , // 45. 응답코드 (4) 

                "RESP_MSG"           , // 46. 응답메시지 (128)
                "PAY_STATUS"         , // 47. 결제상태 (1)
                "CANCEL_STATUS"      , // 48. 취소상태 (1)
                "DATA_ETC_FIELD"     , // 49. DATA예비필드 (40)
                "MSG_END"              // 50. 전문종료바이트 (1)
            };

		for (int i = 0; i < nlens.length; i++) 
		{
			df.CommLogger((i+1) + ") " + "["+strHeaders[i]+"]=" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	//20170828 알리페이결제수단추가 _ LYH
	private String makeSendDataAlipayRsp(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {
						12, 12, 14, 12, 8,
						12, 4,  40, 1
					 };
		
		String strHeaders[] = {
				"MCH_SEND_UNIQ_NO" , // 01. 거래고유번호 (12)
				"PAY_AMOUNT"	   , // 02. 거래금액 (12)
				"AUTH_DT"          , // 03. 승인일시 (14)
				"AUTH_NO"          , // 04. 승인번호 (12)
				"ORG_AUTH_DD"      , // 05. 원거래승인일자 (8)

				"ORG_AUTH_NO"      , // 06. 원거래승인번호 (12)
				"RESP_CODE"        , // 07. 응답코드 (4)
				"RESP_MSG"         , // 08. 응답메세지 (40)
				"PAY_STATUS"       , // 09. 알리페이 거래상태 (1)
			};
		
		for (int i = 0; i < nlens.length; i++) 
		{
			df.CommLogger((i+1) + ") " + "["+strHeaders[i]+"]=" + hm.get(strHeaders[i]));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i]), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataWeChatRsp(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {
						 2,4,128,1,1
						,8,8,6,32
					 };
		
		String strHeaders[] = {
				"INQ_TYPE"		,
				"RESP_CODE"		,
				"RESP_MSG"		,
				"PAY_STATUS"	,
				"CANCEL_STATUS"	,
				
				"SALE_DATE"		,
				"AUTH_DATE"		,
				"AUTH_TIME"		,
				"AUTH_NO"			
			};
		
		for (int i = 0; i < nlens.length; i++) 
		{
			df.CommLogger((i+1) + ") " + "["+strHeaders[i]+"]=" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	

	
	
	
	
	
	
	
	
	
	
	public String getSSGPosaInq(HashMap<String, String> hmComm, HashMap<String, String> hm, int inqType) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		String sendMsg = "";		// 신세계머니로 보낼 송신 전문
		String recvBuf = "";		// 신세계머니에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String todayDT = sdf.format(calendar.getTime());
		String msgID        = "";
		String tranType     = ""; // 00:승인, 01:취소, 02:환불, 05:조회
		String tradeType    = ""; // 47:조회, 29:활성화, 69:활성화 취소 
		String tradeAmt     = ""; // 조회외에는 필수: "000000005800"
		String pinNo        = ""; // PIN 번호 ("활성화/취소"를 제외하고는 필수)
		String sendDate = hm.get("SEND_DATE");
		String sendTime = hm.get("SEND_TIME");

		df.CommLogger("Posa SEND_DATE=[" + sendDate + "]");
		df.CommLogger("Posa SEND_TIME=[" + sendTime + "]");

		switch (inqType) {
			case 83: // 활성화
				msgID     = "PSIS0200";
				tranType  = "00"; 
				tradeType = "29"; // 29:활성화				
				tradeAmt  = hm.get("TRADE_AMT");
				pinNo     = " ";
				break;
				
			case 84: // 활성화 취소
				msgID     = "PSIS0200";
				tranType  = "01";
				tradeType = "69"; // 69:활성화 취소								
				tradeAmt  = hm.get("TRADE_AMT");
				pinNo     = " ";
				break;
				
			case 85: // 무응답 재처리 (활성화) 
				msgID     = "PSIQ0200";
				tranType  = "00"; 
				tradeType = "29"; // 29:활성화				
				tradeAmt  = hm.get("TRADE_AMT");
				pinNo     = " ";
				break;
				
			case 86: // 무응답 재처리 (활성화 취소) 
				msgID     = "PSIQ0200";
				tranType  = "01";
				tradeType = "69"; // 69:활성화 취소								
				tradeAmt  = hm.get("TRADE_AMT");
				pinNo     = " ";
				break;
		}
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.SSGPOINT_FILTER)));

			hm.put("MSG_LEN", "0900"); // 01. 전문길이(4)
			hm.put("MSG_ID", msgID); // 02. 전문ID(8)
			hm.put("MCH_SEND_DATE", (String) hmComm.get("TRAN_YMD")); // 03. 전문전송일자(8)
			
			hm.put("MCH_SEND_UNIQ_NO", 
					  hmComm.get("TRAN_YMD")
					+ hmComm.get("POS_NO")
					+ "0000"
					+ hmComm.get("TRAN_NO"));			 // 04. 전송거래고유번호(20)
			
			hm.put("POSA_MCH_NO", "FM00010770");         // 05. 가맹점번호(15)  ==> 운영적용시 확인 (kkk 1)
			hm.put("MSG_GUBUN", "SEND");                 // 06. 요청구분(4)
			hm.put("SER_COM_CD", "5700");                // 07. 회사코드(4)  5700:위드미
			
//			hm.put("SALE_DATE", sendDate);  // 08. 영업일자(8) 
			hm.put("SALE_DATE", (String) hmComm.get("TRAN_YMD"));  // 08. 영업일자(8) 
			hm.put("SALE_TIME", sendTime);  // 09. 영업시간(6)
			
			df.CommLogger("CASHER_NO=[" + hm.get("CASHER_NO")     + "]");
			df.CommLogger("STORE_CD =[" + hmComm.get("STORE_CD")  + "]");

			
			hm.put("ST_CODE", hmComm.get("STORE_CD"));   // 10. 점코드(10)
//			hm.put("ST_CODE", "00000");   // 10. 점코드(10)     ==> 운영적용시 확인 (kkk 2)
			
			hm.put("TM_NO", hmComm.get("POS_NO"));       // 11. POS 번호(4)
			hm.put("CD_NO", "0000");                     // 12. CD 번호(4)
			hm.put("TRAN_NO", hmComm.get("TRAN_NO"));    // 13. 거래 번호(4)
			
			hm.put("CASHER_NO", hm.get("CASHER_NO"));    // 14. Casher 번호(10) (POS)
//			hm.put("CASHER_NO", "00000");    // 14. Casher 번호(10) (POS) ==> 운영적용시 확인 (kkk 3)
			
			hm.put("POS_DATE", sendDate);    // 15. POS시스템일자(8)
			hm.put("POS_TIME", sendTime);    // 16. POS시스템시간(6)
			
			hm.put("SER_COM_UNIQ_NO", " ");      // 17. 회사별 요청자 정보(20) (불필요: SPACE로 채움)
			hm.put("JUMPO_SYS_DATE", sendDate);  // 18. 점포서버 전문전송일자(8)
			hm.put("JUMPO_SYS_TIME", sendTime);  // 19. 점포서버 전문전송시간(6)
			hm.put("HEAD_ETC_FIELD", " "); // 20. 헤더예비필드(53) (불필요: SPACE로 채움)

			hm.put("TRAN_TYPE", tranType); // 21. 거래 TYPE(2) (00:승인, 01:취소, 02:환불, 05:조회)
			hm.put("TRADE_TYPE", tradeType); // 22. 요청 TYPE(2) (47:조회, 29:활성화, 69:활성화취소, 25:회수, 65:회수취소)
			hm.put("TRACK_TYPE", "3"); // 23. TRACK 유무(1) (2:연번바코드, 3:카드번호)
			hm.put("START_BARCODE", " "); // 24. 시작바코드(50) (불필요: SPACE로 채움)
			hm.put("END_BARCODE", " "); // 25. 종료바코드(50) (불필요: SPACE로 채움)
			
			hm.put("POSA_CARD_NO", hm.get("POSA_CARD_NO")); // 26. POSA 카드 번호(100) (POS)
			hm.put("POSA_CONFIRM_NO", pinNo); // 27. PIN 번호(50)
			hm.put("KEY_IN_TYPE", hm.get("KEY_IN_TYPE")); // 28. KEY IN 유무(2) (POS)
			hm.put("TRADE_AMT", tradeAmt); // 29. 요청금액(12) (POS)
			hm.put("SPECIAL_GUBUN", "1"); // 30. 거래별 구분 코드(1) (1:일반, 2:유효기간만료폐기)

			hm.put("USE_GUBUN", "1"); // 31. 사용구분(1) (회수일때 1:일반회수, 3:폐기회수) (판매일때 1:일반판매)
			hm.put("POSA_GUBUN", hm.get("POSA_GUBUN")); // 32. 상품종류구분(1) (POS)
			hm.put("PART_GUBUN", " "); // 33. 제휴사구분코드(2)
			hm.put("POSA_MOBILE_NO", " "); // 34. 선물하기 번호(20)

			//------------------------------------------
			// 활성화취소시 필수, 그외에는 SPACE
			//------------------------------------------
			if (inqType == 84 || inqType == 86) // 활성화취소 이면
			{
				hm.put("ORG_SER_COM_CD", "5700"); // 35. 원거래 회사코드 (POS)  5700:위드미
				hm.put("ORG_SALE_DATE", hm.get("ORG_SALE_DATE"));       // 36. 원거래 영업일자 (POS)
				
				hm.put("ORG_ST_CODE", hm.get("ORG_ST_CODE"));           // 37. 원거래 점코드 (POS)
//				hm.put("ORG_ST_CODE", "00000"); // 37. 원거래 점코드 (POS)  ==> 운영적용시 확인 (kkk 4)

				hm.put("ORG_TM_NO", hm.get("ORG_TM_NO"));               // 38. 원거래 포스 번호 (POS)
				hm.put("ORG_TRAN_NO", hm.get("ORG_TRAN_NO"));           // 39. 원거래 거래 번호 (POS)
				hm.put("ORG_CD_NO", hm.get("ORG_CD_NO"));               // 40. 원거래 CD 번호 (POS)
				hm.put("ORG_SEND_DATE", hm.get("ORG_SEND_DATE"));       // 41. 원거래 전문전송 일자 (POS)
				hm.put("ORG_SEND_UNIQ_NO", hm.get("ORG_SEND_UNIQ_NO")); // 42. 원거래 전송 거래고유번호 (POS)
//				hm.put("ORG_POSA_MCH_NO", " ");          // 43. 원거래 가맹점번호 (불필요: SAPCE로 채움)   
				hm.put("ORG_POSA_MCH_NO", "FM00010770"); // 43. 원거래 가맹점번호 (불필요: SAPCE로 채움)   ==> 운영적용시 확인 (kkk 5)
				
				hm.put("ORG_AUTH_DATE", hm.get("ORG_AUTH_DATE"));       // 44. 원거래 승인일자 (POS)
				hm.put("ORG_AUTH_NO", hm.get("ORG_AUTH_NO"));           // 45. 원거래 승인번호 (POS)
			}
			else
			{
				hm.put("ORG_SER_COM_CD", " ");   // 35. 원거래 회사코드
				hm.put("ORG_SALE_DATE", " ");    // 36. 원거래 영업일자
				hm.put("ORG_ST_CODE", " ");      // 37. 원거래 점코드
				hm.put("ORG_TM_NO", " ");        // 38. 원거래 포스 번호
				hm.put("ORG_TRAN_NO", " ");      // 39. 원거래 거래 번호
				hm.put("ORG_CD_NO", " ");        // 40. 원거래 CD 번호
				hm.put("ORG_SEND_DATE", " ");    // 41. 원거래 전문전송 일자
				hm.put("ORG_SEND_UNIQ_NO", " "); // 42. 원거래 전송 거래고유번호
				hm.put("ORG_POSA_MCH_NO", " ");  // 43. 원거래 가맹점번호
				hm.put("ORG_AUTH_DATE", " ");    // 44. 원거래 승일일자
				hm.put("ORG_AUTH_NO", " ");      // 45. 원거래 승인번호맹
			}

			hm.put("AUTH_DATE", " ");  // 46. 승인일자
			hm.put("AUTH_TIME", " ");  // 47. 승인시간
			hm.put("AUTH_NO", " ");    // 48. 승인번호
			
			hm.put("REMAIN_AMT", " "); // 49. 상품권잔액 (IRT 불필요(응답용임): SPACE로 채움)
			hm.put("MD_CODE", hm.get("MD_CODE")); // 50. 회사별 상품 코드 (POS)

			hm.put("RESP_CODE", " ");        // 51. 응답코드
			hm.put("RESP_MSG", " ");         // 52. 응답메시지
			hm.put("EXT_POSA_CARD_NO", " "); // 53. 외부 발행 카드 번호
			hm.put("EVENT_AMT", hm.get("EVENT_AMT")); // 54. 행사 할인금액 (POS)
			hm.put("DATA_ETC_FIELD", " ");   // 55. DATA 예비필드

			hm.put("MSG_END", " "); // 56. 전문종료내역
			
			df.CommLogger("================ 2-1) SMS->SSG 송신전문 ===================");
			sendMsg = makeSendDataSSGPosa(hm, df);
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문종료내역 설정
			sendBytes[899] = (byte)0x0d;
			
			sb = new StringBuffer(sendMsg);
			sb.replace(315, 315+19, "*******************");
			
			df.CommLogger("================ 2-2) SMS->SSG 송신전문 ===================");
			df.CommLogger("전문길이=[" + sb.length() + "]");
			df.CommLogger("MSG_ID  =[" + (String)hm.get("MSG_ID") + "]");
			df.CommLogger("전문내용=[" + sb.toString() + "]");

			if (actSock.send(sendBytes, sendBytes.length))
			{
				df.CommLogger("[sms>ssg] SEND[" + sendBytes.length + "] OK");
			} 
			else 
			{
				df.CommLogger("[sms>ssg] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSG Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			sb = null;
			sb = new StringBuffer(recvBuf);
			sb.replace(315, 315+19, "*******************");
			
			df.CommLogger("================ 3-1) SMS<-SSG 응답전문 ===================");
			df.CommLogger("전문길이=[" + recvBuf.getBytes().length + "]");
			df.CommLogger("전문내용=[" + sb.toString() + "]");
			
			df.CommLogger("================ 3-2) SMS<-SSG 응답전문 ===================");
			hmRecv = protocol.getParseSSGPosaRsp(recvBuf);
			
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
		}
		catch (Exception e) 
		{
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}
		finally 
		{
			actSock.close();
			df.CommLogger("================ 4-1) POS<-SMS 응답전문 ===================");
			dataMsg = ret + makeSendDataPosaRsp(hmRecv, df);
			df.CommLogger("dataMsg=[" + dataMsg + "]");
		}
		
		return dataMsg;
	}
	
	private String makeSendDataSSGPosa(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {4,8,8,20,15
					 ,4,4,8,6,10
					 
					 ,4,4,4,10,8
					 ,6,20,8,6,53
					 
					 ,2,2,1,50,50
					 ,100,50,2,12,1
					 
					 ,1,1,2,20,4
					 ,8,10,4,4,4
					 
					 ,8,20,15,8,8
					 ,8,6,8,12,30
					 
					 ,4,60,32,12,130
					 ,1
				};
		
        String strHeaders[] = {
                "MSG_LEN"           , // 01. 전문 길이
                "MSG_ID"            , // 02. 전문 ID
                "MCH_SEND_DATE"     , // 03. 전문전송일자
                "MCH_SEND_UNIQ_NO"  , // 04. 전송거래고유번호
                "POSA_MCH_NO"       , // 05. 가맹점번호

                "MSG_GUBUN"         , // 06. 요청구분
                "SER_COM_CD"        , // 07. 회사코드
                "SALE_DATE"         , // 08. 영업일자
                "SALE_TIME"         , // 09. 영업시간
                "ST_CODE"           , // 10. 점코드

                "TM_NO"             , // 11. 포스 번호
                "CD_NO"             , // 12. CD 번호
                "TRAN_NO"           , // 13. 거래 번호
                "CASHER_NO"         , // 14. Casher 번호
                "POS_DATE"          , // 15. POS시스템일자

                "POS_TIME"          , // 16. POS시스템시간
                "SER_COM_UNIQ_NO"   , // 17. 회사별 요청자 정보
                "JUMPO_SYS_DATE"    , // 18. 점포서버 전문전송일자
                "JUMPO_SYS_TIME"    , // 19. 점포서버 전문전송시간
                "HEAD_ETC_FIELD"    , // 20. 헤더예비필드

                "TRAN_TYPE"         , // 21. 거래 TYPE
                "TRADE_TYPE"        , // 22. 요청 TYPE
                "TRACK_TYPE"        , // 23. TRACK 유무
                "START_BARCODE"     , // 24. 시작바코드
                "END_BARCODE"       , // 25. 종료바코드

                "POSA_CARD_NO"      , // 26. POSA 카드 번호
                "POSA_CONFIRM_NO"   , // 27. PIN 번호
                "KEY_IN_TYPE"       , // 28. KEY IN 유무
                "TRADE_AMT"         , // 29. 요청금액
                "SPECIAL_GUBUN"     , // 30. 거래별 구분 코드

                "USE_GUBUN"         , // 31. 사용구분
                "POSA_GUBUN"        , // 32. 상품종류구분
                "PART_GUBUN"        , // 33. 제휴사구분코드
                "POSA_MOBILE_NO"    , // 34. 선물하기 번호
                "ORG_SER_COM_CD"    , // 35. 원거래 회사코드

                "ORG_SALE_DATE"     , // 36. 원거래 영업일자
                "ORG_ST_CODE"       , // 37. 원거래 점코드
                "ORG_TM_NO"         , // 38. 원거래 포스 번호
                "ORG_TRAN_NO"       , // 39. 원거래 거래 번호
                "ORG_CD_NO"         , // 40. 원거래 CD 번호

                "ORG_SEND_DATE"     , // 41. 원거래 전문전송 일자
                "ORG_SEND_UNIQ_NO"  , // 42. 원거래 전송 거래고유번호
                "ORG_POSA_MCH_NO"   , // 43. 원거래 가뱅점번호
                "ORG_AUTH_DATE"     , // 44. 원거래 승일일자
                "ORG_AUTH_NO"       , // 45. 원거래 승인번호

                "AUTH_DATE"         , // 46. 승인일자
                "AUTH_TIME"         , // 47. 승인시간
                "AUTH_NO"           , // 48. 승인번호
                "REMAIN_AMT"        , // 49. 상품권잔액
                "MD_CODE"           , // 50. 회사별 상품 코드

                "RESP_CODE"         , // 51. 응답코드
                "RESP_MSG"          , // 52. 응답메시지
                "EXT_POSA_CARD_NO"  , // 53. 외부 발행 카드 번호
                "EVENT_AMT"         , // 54. 행사 할인금액
                "DATA_ETC_FIELD"    , // 55. DATA 예비필드

                "MSG_END"             // 56. 전문종료내역
            };

		for (int i = 0; i < nlens.length; i++) 
		{
			df.CommLogger((i+1) + ") " + "["+strHeaders[i]+"]=" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataPosaRsp(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {
						 2,4,60,12,8
						,6,8
					 };
		
		String strHeaders[] = {
				"INQ_TYPE"		,
				"RESP_CODE"		,
				"RESP_MSG"		,
				"REMAIN_AMT"	,
				"AUTH_DATE"		,
				
				"AUTH_TIME"		,
				"AUTH_NO"			
			};
		
		for (int i = 0; i < nlens.length; i++) 
		{
			df.CommLogger((i+1) + ") " + "["+strHeaders[i]+"]=" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	private static String nvl(String str, String defaultValue) {
	    if (str == null) {
	      return defaultValue;
	    } else if (str.equals("")) {
	      return defaultValue;
	    } else {
	      return str.trim();
	    }
	}

}