package biz.cms_SSGMbsIrt;

import java.security.Key;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.net.Socket;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.commons.net.util.Base64;

import org.apache.log4j.Logger;

import sun.misc.BASE64Decoder;

import com.cyberpass.seed.Seed;

import biz.comm.AES;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class SSGMbsIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(SSGMbsIrtAction.class);
	
	private String point_server_ip = "";
	private int point_server_port = 0;
	
	private String ssgpay_inqsvr_ip = "";
	private int ssgpay_inqsvr_port = 0;
	private String ssgpay_apprsvr_ip = "";
	private int ssgpay_apprsvr_port = 0;
	private String ssgmoney_apprsvr_ip = "";
	private int ssgmoney_apprsvr_port = 0;
	private String ssgmoney_bank_apprsvr_ip = "";
	private int ssgmoney_bank_apprsvr_port = 0;
	//private String ssgmoney_posasvr_ip = "";
	private int ssgmoney_posasvr_port = 0;
	private String ssgcoupon_apprsvr_ip = "";
	private int ssgcoupon_apprsvr_port = 0;
	
	//private String wechat_svr_ip = "";
	private int wechat_svr_port = 0;
	
	//20170828 알리페이결제수단추가 _ LYH
	private String alipay_platform_svr_ip = "";
	private int alipay_platform_svr_port = 0;
	
	//20171204 SSGCON 결제수단추가 KSN
	private String ssgcon_apprsvr_ip = "";
	private int ssgcon_apprsvr_port = 0;
	
	
	/**
	 * Receive data from SC through 9005 PORT(SC로부터 데이타를 9005 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(ActionSocket actionSocket) throws Exception {
		// TODO Auto-generated method stub
		
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		StringBuffer sb = null;
		List<Object> list = null;
		
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		
		HashMap<String, String> hmData = new HashMap<String, String>();
		
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		
		
		Socket extClntSock = null;
		SSGMbsIrtConveyer SSGMbsConveyer = null;
		SSGPayIrtConveyer SSGPayConveyer = null;
		
		this.point_server_ip = PropertyUtil.findProperty("communication-property", "SSGPOINT_SERVER_IP");
		//logger.error("point_server_ip[" + point_server_ip + "]");
		this.point_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGPOINT_SERVER_PORT"));
		//logger.error("point_server_port[" + point_server_port + "]");
		this.ssgpay_inqsvr_ip = PropertyUtil.findProperty("communication-property", "SSGPAY_INQSVR_IP");
		//logger.error("ssgpay_inqsvr_ip[" + ssgpay_inqsvr_ip + "]");
		this.ssgpay_inqsvr_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGPAY_INQSVR_PORT"));
		//logger.error("ssgpay_inqsvr_port[" + ssgpay_inqsvr_port + "]");
		this.ssgpay_apprsvr_ip = PropertyUtil.findProperty("communication-property", "SSGPAY_APPRSVR_IP");
		//logger.error("ssgpay_apprsvr_ip[" + ssgpay_apprsvr_ip + "]");
		this.ssgpay_apprsvr_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGPAY_APPRSVR_PORT"));
		//logger.error("ssgpay_apprsvr_port[" + ssgpay_apprsvr_port + "]");
		this.ssgmoney_apprsvr_ip = PropertyUtil.findProperty("communication-property", "SSGMONEY_APPRSVR_IP");
		//logger.error("ssgmoney_apprsvr_ip[" + ssgmoney_apprsvr_ip + "]");
		this.ssgmoney_apprsvr_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGMONEY_APPRSVR_PORT"));
		//logger.error("ssgmoney_apprsvr_port[" + ssgmoney_apprsvr_port + "]");
		this.ssgmoney_bank_apprsvr_ip = PropertyUtil.findProperty("communication-property", "SSGMONEY_BANK_APPRSVR_IP");
		//logger.error("ssgmoney_bank_apprsvr_ip[" + ssgmoney_bank_apprsvr_ip + "]");
		this.ssgmoney_bank_apprsvr_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGMONEY_BANK_APPRSVR_PORT"));
		//logger.error("ssgmoney_bank_apprsvr_port[" + ssgmoney_bank_apprsvr_port + "]");
		//this.ssgmoney_posasvr_ip = PropertyUtil.findProperty("communication-property", "SSGMONEY_POSASVR_IP");
		//logger.error("ssgmoney_posasvr_ip[" + ssgmoney_posasvr_ip + "]");
		this.ssgmoney_posasvr_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGMONEY_POSASVR_PORT"));
		//logger.error("ssgmoney_posasvr_port[" + ssgmoney_posasvr_port + "]");
		
		//this.wechat_svr_ip = PropertyUtil.findProperty("communication-property", "WECHAT_SVR_IP");
		//logger.error("wechat_svr_ip[" + wechat_svr_ip + "]");
		this.wechat_svr_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "WECHAT_SVR_PORT"));
		//logger.error("wechat_svr_port[" + wechat_svr_port + "]");
		
		this.ssgcoupon_apprsvr_ip = PropertyUtil.findProperty("communication-property", "SSGCOUPON_APPRSVR_IP");
		this.ssgcoupon_apprsvr_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGCOUPON_APPRSVR_PORT"));
		
		//20170828 알리페이결제수단추가 _ LYH
		this.alipay_platform_svr_ip = PropertyUtil.findProperty("communication-property", "ALIPAY_PLATFORM_SVR_IP");
		this.alipay_platform_svr_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "ALIPAY_PLATFORM_SVR_PORT"));
		
		//20171204 SSGCON 결제수단추가 KSN
		this.ssgcon_apprsvr_ip = PropertyUtil.findProperty("communication-property", "SSGCON_APPRSVR_IP");
		this.ssgcon_apprsvr_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGCON_APPRSVR_PORT"));

		//logger.error("COMMLog 생성 시작");
		COMMLog df = new COMMLog();
		//logger.error("COMMLog 생성 완료");
		try {
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());
			//logger.error("rcvBuf[" + rcvBuf + "]");

			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;

			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			
//			logger.error("getHostAddress[" + actionSocket.getSocket().getInetAddress()
//					.getHostAddress().toString() + "]");
//			
//			logger.error("getPort[" + actionSocket.getSocket().getPort() + "]");
//			
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger, "SSGMBSIRT");

			
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			logger.error("hmCommon[" + hmCommon + "]");

			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지
			// 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}
			

			logger.error("rcvBuf[" + rcvBuf + "]");
			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			logger.error("rcvDataBuf[" + rcvDataBuf + "]");
			inq_type = COMMBiz.getInqTypeCHG(protocol.getRcvMbsIrtDATA(rcvDataBuf));
			boolean bIsExtended = false;
			logger.error("inq_type[" + inq_type + "]");
			
			switch(inq_type) {
				// 34: 신세계포인트 조회(카드)
				case 34:
					df.execute("Checking SSGPoint");
					if (rcvDataBuf.length() == 196) {
							bIsExtended = false;
							hmData = protocol.getParseSSGPointInq(rcvDataBuf);
							sb = null;
							sb = new StringBuffer(rcvBuf);
							sb.replace(COMMBiz.CM_LENS+12, COMMBiz.CM_LENS+32, "********************");
							df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + sb.toString() + "]");
					} else if (rcvDataBuf.length() == 304) {
							bIsExtended = true;
							hmData = protocol.getParseSSGPointInqEx(rcvDataBuf);
							df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					}
					
					df.CommLogger("SSG POINT SEARCH_1");
					extClntSock = new Socket(point_server_ip, point_server_port);
					SSGMbsConveyer = new SSGMbsIrtConveyer(extClntSock, df);
					
					dataMsg = SSGMbsConveyer.getSSGPointInq(hmCommon, hmData, bIsExtended);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				
				// 23: 신세계포인트 조회(전화번호)
				case 23:
					df.execute("Checking SSGPoint");
	
					bIsExtended = true;
					hmData = protocol.getParseSSGPointPhoneInq(rcvDataBuf);
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					
					//PT 직원 번호인지 조회 
					int sv_str_tp = 0;
					String mobile_num = hmData.get("MOBILE_NO");
					String sale_date = hmData.get("SALE_DATE");
					String store_cd = hmData.get("STORE_CD");
					list = null;
					
					//암호화 키 만들기
					String tran_no = hmData.get("TRAN_NO");
					String pos_no = hmData.get("POS_NO");
					
					df.CommLogger("모바일 번호" + mobile_num);
					int tran_00 = Integer.parseInt(tran_no.substring(0, 1));
					int tran_01 = Integer.parseInt(tran_no.substring(1, 2));
					int tran_02 = Integer.parseInt(tran_no.substring(2, 3));
					int tran_03 = Integer.parseInt(tran_no.substring(3, 4));

					int pos_00 = Integer.parseInt(pos_no.substring(0, 1));
					int pos_01 = Integer.parseInt(pos_no.substring(1, 2));
					int pos_02 = Integer.parseInt(pos_no.substring(2, 3));
					int pos_03 = Integer.parseInt(pos_no.substring(3, 4));

					df.CommLogger("tran_no" + tran_no);
					df.CommLogger("tran_no_00" + tran_00);
					df.CommLogger("tran_01" + tran_01);
					df.CommLogger("tran_02" + tran_02);
					df.CommLogger("tran_03" + tran_03);
					df.CommLogger("pos_no" + pos_no);
				    StringBuilder sbHPDecKey = new StringBuilder();
				    sbHPDecKey.append((int)((tran_03 ^ pos_03) % 10));
				    sbHPDecKey.append((int)(tran_01 ^ pos_01) % 10);
				    sbHPDecKey.append((int)(tran_02 ^ pos_00) % 10);
				    sbHPDecKey.append((int)(tran_03 ^ pos_02) % 10);
				    sbHPDecKey.append((int)(pos_01 ^ tran_03) % 10);
				    sbHPDecKey.append((int)(pos_01 ^ tran_00) % 10);
				    sbHPDecKey.append((int)(pos_02 ^ tran_03) % 10);
				    sbHPDecKey.append((int)(pos_00 ^ tran_02) % 10);
				    sbHPDecKey.append((int)(tran_03 ^ pos_03) % 10);
				    sbHPDecKey.append((int)(tran_01 ^ pos_01) % 10);
				    sbHPDecKey.append((int)(tran_02 ^ pos_00) % 10);
				    sbHPDecKey.append((int)(tran_03 ^ pos_02) % 10);
				    sbHPDecKey.append((int)(pos_01 ^ tran_03) % 10);
				    sbHPDecKey.append((int)(pos_01 ^ tran_00) % 10);
				    sbHPDecKey.append((int)(pos_02 ^ tran_03) % 10);
				    sbHPDecKey.append((int)(pos_00 ^ tran_02) % 10);
				    
				    
				    String secretKey = sbHPDecKey.toString();
				    
				    //String secretKey = new Double(Math.pow(tran_03, pos_03) % 10).toString() + new Double(Math.pow(tran_01, pos_01) % 10).toString() + new Double(Math.pow(tran_02, pos_00) % 10).toString() + new Double(Math.pow(tran_02, pos_00) % 10).toString() + new Double(Math.pow(tran_03, pos_02) % 10).toString() + new Double(Math.pow(pos_01, tran_03) % 10).toString() + new Double(Math.pow(pos_01, tran_00) % 10).toString() + new Double(Math.pow(pos_02, tran_03) % 10).toString() + new Double(Math.pow(pos_00, tran_02) % 10).toString() + new Double(Math.pow(tran_03, pos_03) % 10).toString()
				    //+ new Double(Math.pow(tran_01, pos_01) % 10).toString() + new Double(Math.pow(tran_02, pos_00) % 10).toString() + new Double(Math.pow(tran_03, pos_02) % 10).toString() + new Double(Math.pow(pos_01, tran_03) % 10).toString() + new Double(Math.pow(pos_01, tran_00) % 10).toString() + new Double(Math.pow(pos_02, tran_03) % 10).toString() + new Double(Math.pow(pos_00, tran_02) % 10).toString();
					df.CommLogger("secretKey" + secretKey);
				    
					//모바일 번호 복호화 필요
					
					
					//String des_mobile_num = (new AES()).c(passport_num_enc.trim()); 
					SSGMbsIrtDAO dao = new SSGMbsIrtDAO();
					df.CommLogger("mobile_num 1 " + mobile_num);
					
					
					//String personal_info = (new AES()).decAES(mobile_num, secretKey);
					String personal_info = decAES(mobile_num, secretKey);
					df.CommLogger("personal_info 1 " + personal_info);

					df.CommLogger("mobile_num 1 " + personal_info);
					df.CommLogger("sale_date 1 " + sale_date);
					df.CommLogger("store_cd 1 " + store_cd);
					list = dao.getPTPhoneNumber(personal_info, sale_date, store_cd);
					
					
					/*
					if(sv_str_tp == 1) {
						df.CommLogger("출근중!!!!!!!!!");
						ret = 39; // 039=receive time out
						dataMsg = "";
						break;
						
					}
					*/
					
					df.CommLogger("list.size()" + list.size());
					//   
					
					boolean chkValue = true;
					if( list.size() > 0 ) {
						for( int i = 0;i < list.size();i++ ) {
							Map<String, String> map = (Map<String, String>)list.get(i);
							df.CommLogger("SV_STRARR_TP : " + ((String)map.get("SV_STRARR_TP")));
							if(((String)map.get("SV_STRARR_TP")).equals("0")) {
								df.CommLogger("출근중!!!!!!!!!");
								ret = 99;
								dataMsg = hmData.get("INQ_TYPE");
								//hmCommon.put("ERR_CD", "99");
								chkValue = false;
							}
						}						
					}
				
					
					if(chkValue) {
						df.CommLogger("출근아님!!!!!!!!!");					
						
						//PT 직원 체크					
						df.CommLogger("SSG CARD SEARCH_1");
						extClntSock = new Socket(point_server_ip, point_server_port);
						SSGMbsConveyer = new SSGMbsIrtConveyer(extClntSock, df);
						
						dataMsg = SSGMbsConveyer.getSSGPointPhoneInq(hmCommon, hmData, bIsExtended);
						ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
						dataMsg = dataMsg.substring(2);
					}
					break;
				// 35: 신세계포인트 승인(적립/사용)
				case 35:
					df.execute("Approval SSGPoint");
					if( rcvDataBuf.length() == 270 ) {
						bIsExtended = false;
						hmData = protocol.getParseSSGPointApproval(rcvDataBuf);
						sb = null;
						sb = new StringBuffer(rcvBuf);
						sb.replace(COMMBiz.CM_LENS+14, COMMBiz.CM_LENS+34, "********************");
						df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + sb.toString() + "]");
					}else if( rcvDataBuf.length() == 378 ) {
						bIsExtended = true;
						hmData = protocol.getParseSSGPointApprovalEx(rcvDataBuf);
						df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					}else if( rcvDataBuf.length() == 388 ) {
						bIsExtended = true;
						hmData = protocol.getParseSSGPointApprovalEx(rcvDataBuf);
						df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					}
					
					extClntSock = new Socket(point_server_ip, point_server_port);
					SSGMbsConveyer = new SSGMbsIrtConveyer(extClntSock, df);
					
					dataMsg = SSGMbsConveyer.getSSGPointApproval(hmCommon, hmData, bIsExtended);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 36: 신세계포인트 취소(적립/사용)
				case 36:
					df.execute("Cancelation SSGPoint");
					if( rcvDataBuf.length() == 303 ) {
						bIsExtended = false;
						hmData = protocol.getParseSSGPointCancel(rcvDataBuf);
						sb = null;
						sb = new StringBuffer(rcvBuf);
						sb.replace(COMMBiz.CM_LENS+12, COMMBiz.CM_LENS+32, "********************");
						df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + sb.toString() + "]");
					}else if( rcvDataBuf.length() == 411 ) {
						bIsExtended = true;
						hmData = protocol.getParseSSGPointCancelEx(rcvDataBuf);
						df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					}
					
					extClntSock = new Socket(point_server_ip, point_server_port);
					SSGMbsConveyer = new SSGMbsIrtConveyer(extClntSock, df);
					
					dataMsg = SSGMbsConveyer.getSSGPointCancel(hmCommon, hmData, bIsExtended);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);					
					break;
				// 61: (SSGPay) 결제정보 조회 (통합결제플랫폼)
				case 61:
					df.execute("Checking SSGPay");
					if( rcvDataBuf.length() == 102 ) {
						bIsExtended = false;
						hmData = protocol.getParseSSGPayInq(rcvDataBuf);
					}else if( rcvDataBuf.length() == 103 ) {
						bIsExtended = true;
						hmData = protocol.getParseSSGPayInqEx(rcvDataBuf);
					}else if ( rcvDataBuf.length() == 104 ) { 	//20170614 SSGPAY 상시할인/PLCC 추가
						df.execute("SSGPAY 상시할인/PLCC START");
						bIsExtended = true;
						hmData = protocol.getParseSSGPayInqEx104(rcvDataBuf);
						df.execute("SSGPAY 상시할인/PLCC hmData["+hmData+"]");
					}else if ( rcvDataBuf.length() == 105 ) { 	//20171210 PLCC 할인제외 칼럼 추가 (SSGPAY_CP_YN)
						df.execute("SSGPAY PLCC 할인제외 버전 START");
						bIsExtended = true;
						hmData = protocol.getParseSSGPayInqEx105(rcvDataBuf);
						df.execute("SSGPAY PLCC 할인제외 버전 hmData["+hmData+"]");
					}
					df.execute("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");
					
					extClntSock = new Socket(ssgpay_inqsvr_ip, ssgpay_inqsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayInq(hmCommon, hmData, bIsExtended);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					df.execute("[pos<sms] DATAMSG[" + dataMsg + "]");
					//logger.error("ret[" + ret + "]");
					//logger.error("dataMsg" + dataMsg + "]");
//					ret = 0;
//					dataMsg = "610000정상                                                        POIF01100520150512140549                                                                    NC2A9A98EE6D6211BC2F602058F95A5FAY1943DCA1F5D814EDD27CEC724372A3818465B59DE099EE258115458C80DDBB5DY046823B6BAD49888D41382A04AB5C0DAAC9AF328C3CDD007F37682FEFAEDE75D6D1CD6D2202BDA873126B0D7036D5C77000000369050Y1014579720551038017                                                1806                            9B2E2865FAD92AFBF269F88E8FBD539DECEB81D636F4381880DDC71FD7518C046CCB17483741E9E7E19D5437733654159B2E2865FAD92AFBF269F88E8FBD539DECEB81D636F4381880DDC71FD7518C046312A092A200BCE3772411B406BDC00E9B2E2865FAD92AFBF269F88E8FBD539DECEB81D636F4381880DDC71FD7518C046360065202BCE25926CA19EE7DAF561894F78D91FA4F4C9E5B9FCFC51B507A15FB7319492308E7B1BC443345D819F3ADFB7319492308E7B1BC443345D819F3ADNB8DE87DCDFFA6D64C03CCBE0E819B381";
					break;
				// 62: (SSGPay)신용카드 승인(미사용 - POS에서 승인)
				case 62:
					df.execute("Approval SSGPay_CreditCard");
					hmData = protocol.getParseSSGPayApproval(rcvDataBuf);
					
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");
					
					extClntSock = new Socket(ssgpay_apprsvr_ip, ssgpay_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayApproval(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 63: (SSGPay)신용카드 승인취소(미사용 - POS에서 승인)
				case 63:
					df.execute("Cancelation SSGPay_CreditCard");
					hmData = protocol.getParseSSGPayApproval(rcvDataBuf);
					
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");
					
					extClntSock = new Socket(ssgpay_apprsvr_ip, ssgpay_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayApproval(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 64: (SSGPay)SSG MONEY 결제 승인
				case 64:
					df.execute("Approval SSGPay_MGift");
					hmData = protocol.getParseSSGPayMGiftApproval(rcvDataBuf);
					
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");
					
					extClntSock = new Socket(ssgmoney_apprsvr_ip, ssgmoney_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayMGiftApproval(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
//					ret = 0;
//					dataMsg = "640000정상                                                        000000000000000000048500201504062015040619203598765432";
					break;
				// 65: (SSGPay)SSG MONEY 결제 승인 취소
				case 65:
					df.execute("Cancelation SSGPay_MGift");
					hmData = protocol.getParseSSGPayMGiftApproval(rcvDataBuf);
					
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");
					
					extClntSock = new Socket(ssgmoney_apprsvr_ip, ssgmoney_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayMGiftApproval(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
//					ret = 0;
//					dataMsg = "650000정상                                                        000000000000000000050000201504062015040619203598765432";
					break;
					// 75: (SSGPay)SSG MONEY 충전
				case 75:
					df.execute("Approval SSGPay_MGift_Chg");
					hmData = protocol.getParseSSGPayMGiftCharge(rcvDataBuf);
					
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");
					
					extClntSock = new Socket(ssgmoney_apprsvr_ip, ssgmoney_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayMGiftCharge(hmCommon, hmData,inq_type);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
//					ret = 0;
//					dataMsg = "750000정상                                                        000000000000000000048500201504062015040619203598765432";
					break;
				// 76: (SSGPay)SSG MONEY 충전취소
				case 76:
					df.execute("Cancelation SSGPay_MGift_Chg");
					hmData = protocol.getParseSSGPayMGiftCharge(rcvDataBuf);
					
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");
					
					extClntSock = new Socket(ssgmoney_apprsvr_ip, ssgmoney_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayMGiftCharge(hmCommon, hmData,inq_type);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
//					ret = 0;
//					dataMsg = "760000정상                                                        000000000000000000050000201504062015040619203598765432";
					break;
					// 77: (SSGPay)SSG MONEY 조회(충전정보)
				case 77:
					df.execute("Search SSGPay_MGift");
					hmData = protocol.getParseSSGPayMGiftCharge(rcvDataBuf);
					
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");
					
					extClntSock = new Socket(ssgmoney_apprsvr_ip, ssgmoney_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayMGiftCharge(hmCommon, hmData,inq_type);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
//					ret = 0;
//					dataMsg = "770000정상                                                        000000000000000000048500201504062015040619203598765432";
					break;
				// 78: (SSGPay)잔돈적립 망조회(충전정보) ==> 미사용_향후 사용 예정
				case 78:
					df.execute("Search SSGPay_MGift_Chg");
					hmData = protocol.getParseSSGPayMGiftCharge(rcvDataBuf);
					
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");
					
					extClntSock = new Socket(ssgmoney_apprsvr_ip, ssgmoney_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayMGiftCharge(hmCommon, hmData,inq_type);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
//					ret = 0;
//					dataMsg = "760000정상                                                        000000000000000000050000201504062015040619203598765432";
					break;

					
					
					
				case 80: // 80: 위챗페이 조회
				case 81: // 81: 위챗페이 승인  
				case 82: // 82: 위챗페이 승인취소 
					df.execute("Search getParseWeChatInq");
					df.CommLogger("================ 1-1) WeChat POS->SMS 수신전문 ===================");
					hmData = protocol.getParseWeChatInq(rcvDataBuf);

					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");

					df.CommLogger("================ 1-2) WeChat POS->SMS 수신전문 ===================");
					df.CommLogger("전문길이=[" + rcvBuf.getBytes().length + "]");
					df.CommLogger("INQ_TYPE=[" + rcvBuf.substring(50, 52) + "]");
					df.CommLogger("전문내용=[" + rcvBuf.toString() + "]");
					df.CommLogger("WeChat ServerIP:[" + ssgmoney_apprsvr_ip + "]  PORT:[" + wechat_svr_port + "]");
					df.CommLogger("kkkkkkkkkkkkkkkkk0000");
					extClntSock = new Socket(ssgmoney_apprsvr_ip, wechat_svr_port);
					df.CommLogger("kkkkkkkkkkkkkkkkk1111");
					SSGMbsConveyer = new SSGMbsIrtConveyer(extClntSock, df);
					df.CommLogger("kkkkkkkkkkkkkkkkk2222");
					
					dataMsg = SSGMbsConveyer.getWeChatInq(hmCommon, hmData, inq_type); 
					df.CommLogger("kkkkkkkkkkkkkkkkk3333");
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					
					df.CommLogger("ret=[" + ret + "]");
					df.CommLogger("dataMsg=[" + dataMsg + "]");
					break;
						
				
				case 83: // 83: (SSGMoney) POSA 활성화
				case 84: // 84: (SSGMoney) POSA 활성화 취소 
				case 85: // 85: (SSGMoney) POSA 무응답 재처리 (활성화)
				case 86: // 86: (SSGMoney) POSA 무응답 재처리 (활성화 취소)
					df.execute("Search getParseSSGPosaInq");
					df.CommLogger("================ 1-1) POS->SMS 수신전문 ===================");
					hmData = protocol.getParseSSGPosaInq(rcvDataBuf);

					df.CommLogger("================ 1-2) POS->SMS 수신전문 ===================");
					df.CommLogger("전문길이=[" + rcvBuf.getBytes().length + "]");
					df.CommLogger("INQ_TYPE=[" + rcvBuf.substring(50, 52) + "]");
					df.CommLogger("전문내용=[" + rcvBuf.toString() + "]");
					df.CommLogger("SSG ServerIP:" + ssgmoney_apprsvr_ip + "  PORT:" + ssgmoney_posasvr_port);
					extClntSock = new Socket(ssgmoney_apprsvr_ip, ssgmoney_posasvr_port);
					SSGMbsConveyer = new SSGMbsIrtConveyer(extClntSock, df);
					
					dataMsg = SSGMbsConveyer.getSSGPosaInq(hmCommon, hmData, inq_type); 
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					
					df.CommLogger("ret=[" + ret + "]");
					df.CommLogger("dataMsg=[" + dataMsg + "]");
					break;
			// 92: (SSGPay)SSG 계좌 결제 승인 -- 계좌 결제 수단 추가 2016.05.27 by OHT
			case 92:
					df.execute("Approval SSGPay_Account");
					hmData = protocol.getParseSSGPayBankApproval(rcvDataBuf);
					
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");
					
					extClntSock = new Socket(ssgmoney_bank_apprsvr_ip, ssgmoney_bank_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayAccountApproval(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					break;
			// 93: (SSGPay)SSG 계좌 결제 취소 -- 계좌 결제 수단 추가 2016.05.27 by OHT
			case 93:
					df.execute("Cancelation SSGPay_Account");
					hmData = protocol.getParseSSGPayBankApproval(rcvDataBuf);
					
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");
					
					extClntSock = new Socket(ssgmoney_bank_apprsvr_ip, ssgmoney_bank_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayAccountApproval(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);

					break;
					
			// 2126([C1) : (SSGPay) 도시락 쿠폰 승인/취소/망취소 -- 2017.03.16 by OHT
			case 2126:
					df.execute("SSGPay_COUPON");
					hmData = protocol.getParseSSGPayCoupon(rcvDataBuf);
					
					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");

					extClntSock = new Socket(ssgcoupon_apprsvr_ip, ssgcoupon_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGPayCoupon(hmCommon, hmData);
					df.CommLogger("dataMsg[" + dataMsg + "]");
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);

					break;

				case 2130: // C5(2130): Alipay 조회
				case 2131: // C6(2131): Alipay 승인
				case 2132: // C7(2132): Alipay 취소/망취소
					df.CommLogger("================ 1-1) Alipay POS->SMS 수신전문 ===================");
					// 조회
					df.execute("Search getParseAlipayInq");
					hmData = protocol.getParseAlipayInq(rcvDataBuf);

					df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf.toString() + "]");

					df.CommLogger("================ 1-2) Alipay POS->SMS 수신전문 ===================");
					df.CommLogger("전문길이=[" + rcvBuf.getBytes().length + "]");
					df.CommLogger("INQ_TYPE=[" + rcvBuf.substring(50, 52) + "]");
					df.CommLogger("전문내용=[" + rcvBuf.toString() + "]");
					df.CommLogger("Alipay Platform ServerIP:[" + alipay_platform_svr_ip + "]  PORT:[" + alipay_platform_svr_port + "]");
					extClntSock = new Socket(alipay_platform_svr_ip, alipay_platform_svr_port);
					SSGMbsConveyer = new SSGMbsIrtConveyer(extClntSock, df);

					dataMsg = SSGMbsConveyer.getAlipayRsp(hmCommon, hmData, inq_type); 

					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					
					df.CommLogger("ret=[" + ret + "]");
					df.CommLogger("dataMsg=[" + dataMsg + "]");
					break;
					
				case 2156:	//D0(2156) : SSG CON 금액형쿠폰 조회요청
					df.CommLogger("<----- SSG CON Check START ----->");
					hmData = protocol.getParseSSGConCheck(rcvDataBuf);
					df.CommLogger("SSGCON::hmData::["+hmData+"]");
					extClntSock = new Socket(ssgcon_apprsvr_ip, ssgcon_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGConInq(hmCommon, hmData);
					
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					
					break;
					
				case 2158: // D2(2158) : SSG CON 금액형쿠폰 사용승인/취소요청
					logger.info("<----- SSG CON REQ START ----->");
					hmData = protocol.getParseSSGConApprReq(rcvDataBuf);
					logger.info("SSGCON::hmData::["+hmData+"]");
					extClntSock = new Socket(ssgcon_apprsvr_ip, ssgcon_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGConMNAppr(hmCommon, hmData);
					
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					
					break;
					
				case 2160: // D4(2160) : SSG CON 물품형쿠폰 조회요청
					logger.info("<----- SSG CON CHECK(PRD) START ----->");
					hmData = protocol.getParseSSGConCheck(rcvDataBuf);
					logger.info("SSGCON::hmData::["+hmData+"]");
					extClntSock = new Socket(ssgcon_apprsvr_ip, ssgcon_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGConPrdInq(hmCommon, hmData);
					
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					
					break;
					
				case 2162: // D6(2162) : SSG CON 물품형쿠폰 사용승인/취소요청
					logger.info("<----- SSG CON REQ START ----->");
					hmData = protocol.getParseSSGConPrdApprReq(rcvDataBuf);
					logger.info("SSGCON::hmData::["+hmData+"]");
					extClntSock = new Socket(ssgcon_apprsvr_ip, ssgcon_apprsvr_port);
					SSGPayConveyer = new SSGPayIrtConveyer(extClntSock, df);
					
					dataMsg = SSGPayConveyer.getSSGConPrdAppr(hmCommon, hmData);
					
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					
					break;
						
				default:
				df.CommLogger("▶ INQ Type Code(INQ 종별 코드):   [" + inq_type + "]" + rcvBuf.length());
					ret = 99;
					break;
			}
		} catch (Exception e) {
			ret = 29; // 029=HOST APPL ERR
			retValue = "[ERROR]2:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			df.CommLogger("dataMsg[" + dataMsg + "]");
			df.CommLogger("sendMsg[" + sendMsg + "]");
					
			df.CommLogger("================ 4-2) POS<-SMS 응답전문 ===================");
			df.CommLogger("전문길이=[" + totalMsg.getBytes().length + "]");
			df.CommLogger("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
			df.CommLogger("전문내용=[" + totalMsg + "]");
			
			// Send Response Data (응답 데이타 전송)
			if (actionSocket.send(totalMsg)) {
				df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		} catch (Exception e) {
			retValue = "[ERROR]4" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		} finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("SSGMBSIRT", retValue);
			
			if (!extClntSock.isClosed()) {
				extClntSock.close();
			}
		}
	}
	
	
	
	public Key getAESKey(String secretkey) throws Exception {
	    String iv;
	    Key keySpec;

	    String key = secretkey;
	    iv = key.substring(0, 16);	    
	    byte[] keyBytes = new byte[16];	    
	    byte[] b = key.getBytes("UTF-8");	   
	    int len = b.length;	   
	    if (len > keyBytes.length) {
	       len = keyBytes.length;
	    }

	    System.arraycopy(b, 0, keyBytes, 0, len);
	    keySpec = new SecretKeySpec(keyBytes, "AES");
	    return keySpec;
	}
	
	// 복호화
	public String decAES(String enStr, String secretKey) throws Exception {
	    Key keySpec = getAESKey(secretKey);
	    String iv = secretKey;
	    Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
	    c.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(iv.getBytes("UTF-8")));
	    logger.info("<----- 3 ----->");
	    byte[] byteStr = Base64.decodeBase64(enStr.getBytes("UTF-8"));
	    logger.info("<----- 4 ----->");
	    String decStr = new String(c.doFinal(byteStr), "UTF-8");
	    logger.info("<----- 5 ----->");
	    return decStr;
	}

	
}



