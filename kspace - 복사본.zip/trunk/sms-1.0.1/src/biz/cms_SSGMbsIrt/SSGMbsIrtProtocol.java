package biz.cms_SSGMbsIrt;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class SSGMbsIrtProtocol {
	
	private static Logger logger = Logger.getLogger(SSGMbsIrtAction.class);
	
	public HashMap<String, String> getParseSSGPayMGiftRspApproval(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,8,8,20,15
					  ,4,4,8,6,10
					  ,4,4,4,10,8
					  ,6,20,8,6,53
					  ,2,2,2,2,20
					  ,1,50,50,3,100
					  ,50,2,12,1,1
					  ,1,2,4,20,4
					  ,8,10,4,4,4
					  ,8,20,15,8,8
					  ,8,6,8,12,30
					  ,4,60,12,48,12
					  ,12,12,12,12,23
					  ,1};
		String strHeaders[] = {
				"MSG_LEN"				,
				"MSG_ID"				,
				"MCH_SEND_DATE"			,
				"MCHH_SEND_UNIQ_NO"		,
				"GIFT_MCH_NO"			,
				
				"MSG_GUBUN"				,
				"SER_COM_CD"			,
				"SALE_DATE"				,
				"SALE_TIME"				,
				"ST_CODE"				,
				
				"TM_NO"					,
				"CD_NO"					,
				"TRAN_NO"				,
				"CASHER_NO"				,
				"POS_DATE"				,
				
				"POS_TIME"				,
				"SER_COM_UNIQ_NO"		,
				"JUMPO_SYS_DATE"		,
				"JUMPO_SYS_TIME"		,
				"HEAD_ETC_FIELD"		,
				
				"TRAN_TYPE"				,
				"TRADE_TYPE"			,
				"EVENT_GUBUN"			,
				"EVENT_TYPE"			,
				"EVENT_NO"				,
				
				"TRACK_TYPE"			,
				"START_BARCODE"			,
				"END_BARCODE"			,
				"BARCODE_CNT"			,
				"GIFT_CARD_NO"			,
				
				"GIFT_CONFIRM_NO"		,
				"KEY_IN_TYPE"			,
				"TRADE_AMT"				,
				"SPECIAL_GUBUN"			,
				"USE_GUBUN"				,
				
				"GIFT_GUBUN"			,
				"PART_GUBUN"			,
				"GIFT_CODE"				,
				"GIFT_MOMILE_NO"		,
				"ORG_SER_COM_CD"		,
				
				"ORG_SALE_DATE"			,
				"ORG_ST_CODE"			,
				"ORG_TM_NO"				,
				"ORG_TRAN_NO"			,
				"ORG_CD_NO"				,
				
				"ORG_SEND_DATE"			,
				"ORG_SEND_UNIQ_NO"		,
				"ORG_GIFT_MCH_NO"		,
				"ORG_AUTH_DATE"			,
				"ORG_AUTH_NO"			,
				
				"AUTH_DATE"				,
				"AUTH_TIME"				,
				"AUTH_NO"				,
				"REMAIN_AMT"			,
				"MD_CODE"				,
				
				"RESP_CODE"				,
				"RESP_MSG"				,
				"REFUND_ABLE_AMT"		,
				"PLATFORM_BARCODE"		,
				"NORM_REF_AMT"			,
				
				"NORM_REF_FEE"			,
				"SWAP_REF_AMT"			,
				"SWAP_REF_FEE"			,
				"FREE_REF_AMT"			,
				"DATA_ETC_FIELD"		,
				
				"MSG_END"				
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayAccountRspApproval(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,8,8,24,4
				  ,2,4,15,8,6
				  ,10,4,4,4,4
				  ,10,8,6,6,4
				  ,30,4,30,8,6
				  ,20,20,20,8,6
				  ,4,60,3,30,4
				  ,20,84,64,2,96
				  ,12,12,12,8,6
				  ,15,4,50,100,8
				  ,24,4,8,10,4
				  ,4,4,4,10,8
				  ,15,2,1,64,12
				  ,536,1};
		String strHeaders[] = {
							"MSG_LEN"				,   // 01. 전문길이(4)                           
							"MSG_ID"				,   // 02. 전문ID(8)                           
							"MCH_SEND_DATE"			,   // 03. 전문전송일자(8)                         
							"MCH_SEND_UNIQ_NO"		,   // 04. 전송거래고유번호(24)                      
							"MSG_GUBUN"				,   // 05. 요청구분(4)                           
							                                                                     
							"TRAN_TYPE"				,   // 06. 거래TYPE(2)                         
							"SER_COM_CD"			,   // 07. 회사코드(4)                           
							"TERM_ID"				,   // 08. 터미널아이디(15)                        
							"SALE_DATE"				,   // 09. 영업일자(8)                           
							"SALE_TIME"				,   // 10. 영업시간(6)                           
							                                                                     
							"ST_CODE"				,   // 11. 점코드(10)                           
							"TM_NO"					,   // 12. 포스번호(4)                           
							"SHOP_NO"				,   // 13. 매장번호(4)                           
							"CD_NO"					,   // 14. CD번호(4)                           
							"TRAN_NO"				,   // 15. TRAN_NO(4)                        
							                                                                     
							"CASHER_NO"				,   // 16. Casher번호(10)                      
							"POS_DATE"				,   // 17. POS시스템일자(8)                       
							"POS_TIME"				,   // 18. POS시스템시간(6)                       
							"NORMAL_GUBUN"			,   // 19. 정상 예외 구분(6)                       
							"BUY_FIRM_CODE"			,   // 20. 매입사코드(4)                          
							                                                                     
							"BUY_FIRM_NM"			,   // 21. 매입사명(30)                          
							"ISSUE_FIRM_CODE"		,   // 22. 발행사코드(4)                          
							"ISSUE_FIRM_NM"			,   // 23. 발행사명(30)                          
							"CARD_SYS_DATE"			,   // 24. 카드사요청일자(8)                        
							"CARD_SYS_TIME"			,   // 25. 카드사요청시간(6)                        
							                                                                     
							"CARD_UNIQ_NO"			,   // 26. 카드사요청고유번호(20)                     
							"CARD_MCH_NO"			,   // 27. 카드사가맹점번호(20)                      
							"SER_COM_UNIQ_NO"		,   // 28. 회사별요청자정보(20)                      
							"JUMPO_SYS_DATE "		,   // 29. 점포서버전문전송일자(8)                     
							"JUMPO_SYS_TIME"		,   // 30. 점포서버전문전송시간(6)                     
							                                                                     
							"RESP_CODE"				,   // 31. 응답메시지 코드(4)                       
							"RESP_MSG"				,   // 32. 응답메시지 설명(60)                      
							"BANK_CODE"				,   // 33. 은행코드(3)                           
							"BANK_NM"				,   // 34. 은행사명(30)                          
							"BANK_VAN_FLAG"			,   // 35. 금융VAN구분(4)                        
							                                                                     
							"PLATFORM_M_ID"			,   // 36. 플랫폼연동가맹점ID(20)                    
							"HEAD_ETC_FIELD"		,   // 37. Header예비필더(84)                    
							"DELEGATE_BARCODE_NO"	,   // 38. 통합바코드번호(64)                       
							"KEY_IN_TYPE"			,   // 39. KEY_IN유무(2)                       
							"BANK_ACCOUNT_NO"		,   // 40. 가상은행계좌번호(96)                      
							                                                                     
							"BANK_TOT_TRADE_AMT"	,   // 41. 전체거래금액(12)                        
							"BANK_DIS_TRADE_AMT"	,   // 42. 에누리금액(12)                         
							"BANK_NET_TRADE_AMT"	,   // 43. 실승인요청금액(12)                       
							"AUTH_DATE"				,   // 44. 가상은행계좌 승인일자(8)                    
							"AUTH_TIME"				,   // 45. 가상은행계좌 승인시간(6)                    
							                                                                     
							"AUTH_NO"				,   // 46. 가상은행계좌 승인번호(15)                   
							"MD_CNT"				,   // 47. 상품 수량(4)                          
							"MD_CODE"				,   // 48. 회사별 상품 코드 (50)                    
							"MD_NAME"				,   // 49. 상품명(100)                          
							"ORG_SEND_DATE"			,   // 50. 원거래 전문전송일자(8)                     
							                                                                     
							"ORG_SEND_UNIQ_NO"		,   // 51. 원거래 전송 거래고유번호(24)                 
							"ORG_SER_COM_CD"		,   // 52. 원거래 회사코드(4)                       
							"ORG_SALE_DATE"			,   // 53. 원거래 영업일자(8)                       
							"ORG_ST_CODE"			,   // 54. 원거래 점코드(10)                       
							"ORG_TM_NO"				,   // 55. 원거래 포스 번호(4)                      
							                                                                     
							"ORG_SHOP_NO"			,   // 56. 원거래 매장번호(4)                       
							"ORG_CD_NO"				,   // 57. 원거래 CD 번호(4)                      
							"ORG_TRAN_NO"			,   // 58. 원거래 거래 번호(4)                      
							"ORG_CASHER_NO"			,   // 59. 원거래 Casher 번호(10)                 
							"ORG_BANK_AUTH_DATE"	,   // 60. 원거래 가상은행계좌 승인일자 (8)               
							                                                                     
							"ORG_BANK_AUTH_NO"		,   // 61. 원거래 가상은행계좌 승인번호(15)               
							"CNCL_GUBUN"			,   // 62. 취소 구분(2)                          
							"CNCL_USE_YN"			,   // 63. 부분취소 가능 여부(1)                     
							"ORG_DELEGATE_BARCODE_NO",  // 64. 원거래 통합바코드번호(64)                   
							"ORG_BANK_AUTH_AMT"		,   // 65. 원거래 실승인요청금액(12)                   
							                                                                     
							"DATA_ETC_FIELD"		,   // 66. DATA예비필드(536)                     
							"MSG_END"	                // 67. 전문 종료 내역(1)                       
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayMGiftRspCharge(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,8,8,20,15
				  ,4,4,8,6,10
				  ,4,4,4,10,8
				  ,6,20,8,6,53
				  ,2,2,24,1,100
				  ,3,100,50,2,12
				  ,1,1,1,2,4
				  ,20,4,8,10,4
				  ,4,4,8,20,15
				  ,8,8,8,6,8
				  ,12,30,4,60,12
				  ,48,60,2,21,1};
		String strHeaders[] = {
				"MSG_LEN"				,
				"MSG_ID"				,
				"MCH_SEND_DATE"			,
				"MCHH_SEND_UNIQ_NO"		,
				"GIFT_MCH_NO"			,
				
				"MSG_GUBUN"				,
				"SER_COM_CD"			,
				"SALE_DATE"				,
				"SALE_TIME"				,
				"ST_CODE"				,
				
				"TM_NO"					,
				"CD_NO"					,
				"TRAN_NO"				,
				"CASHER_NO"				,
				"POS_DATE"				,
				
				"POS_TIME"				,
				"SER_COM_UNIQ_NO"		,
				"JUMPO_SYS_DATE"		,
				"JUMPO_SYS_TIME"		,
				"HEAD_ETC_FIELD"		,
				
				"TRAN_TYPE"				,
				"TRADE_TYPE"			,
				"EVENT_ETC_FIELD"		,
				"TRACK_TYPE"			,
				"BARCODE_ETC_FIELD"		,
	
				"BARCODE_CNT"			,
				"GIFT_CARD_NO"			,
				"GIFT_CONFIRM_NO"		,
				"KEY_IN_TYPE"			,
				"TRADE_AMT"				,
	
				"SPECIAL_GUBUN"			,
				"USE_GUBUN"				,
				"GIFT_GUBUN"			,
				"PART_GUBUN"			,
				"GIFT_CODE"				,
	
				"GIFT_MOMILE_NO"		,
				"ORG_SER_COM_CD"		,
				"ORG_SALE_DATE"			,
				"ORG_ST_CODE"			,
				"ORG_TM_NO"				,
	
				"ORG_TRAN_NO"			,
				"ORG_CD_NO"				,
				"ORG_SEND_DATE"			,
				"ORG_SEND_UNIQ_NO"		,
				"ORG_GIFT_MCH_NO"		,
	
				"ORG_AUTH_DATE"			,
				"ORG_AUTH_NO"			,
				"AUTH_DATE"				,
				"AUTH_TIME"				,
				"AUTH_NO"				,
	
				"REMAIN_AMT"			,
				"MD_CODE"				,
				"RESP_CODE"				,
				"RESP_MSG"				,
				"REFUND_ABLE_AMT"		,
	
				"PLATFORM_BARCODE"		,
				"AMT_ETC_FIELD"			,
				"PAY_TYPE"				,
				"DATA_ETC_FIELD"		,
				"MSG_END"				
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayRspApproval(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,8,8,24,4
					  ,2,4,15,8,6
					  ,10,4,4,4,4
					  ,10,8,6,6,4
					  ,4,8,6,20,20
					  ,20,8,6,4,60
					  ,201,32,2,2,32
					  ,48,32,2,12,12
					  ,12,8,6,20,4
					  ,50,100,4,8,10
					  ,4,4,4,4,8
					  ,24,8,20,627,1};
		String strHeaders[] = {
				"MSG_LEN"				, // 01. 전문길이(4)
				"MSG_ID"				, // 02. 전문ID(8)
				"MCH_SEND_DATE"			, // 03. 전문전송일자(8)
				"MCH_SEND_UNIQ_NO"		, // 04. 전송거래고유번호(24)
				"MSG_GUBUN"				, // 05. 요청구분(4)
				
				"TRAN_TYPE"				, // 06. 거래TYPE(2)
				"SER_COM_CD"			, // 07. 회사코드(4)
				"TERM_ID"				, // 08. 터미널아이디(15)
				"SALE_DATE"				, // 09. 영업일자(8)
				"SALE_TIME"				, // 10. 영업시간(6)
				
				"ST_CODE"				, // 11. 점포코드(10)
				"TM_NO"					, // 12. 포스번호(4)
				"SHOP_NO"				, // 13. 매장번호(4)
				"CD_NO"					, // 14. CD번호(4)
				"TRAN_NO"				, // 15. 거래번호(4)
				
				"CASHER_NO"				, // 16. Casher번호(4)
				"POS_DATE"				, // 17. POS시스템일자(8)
				"POS_TIME"				, // 18. POS시스템시간(6)
				"NORMAL_GUBUN"			, // 19. 정상 예외 구분(6)
				"BUY_FIRM_CODE"			, // 20. 매입사코드(4)
				
				"ISSUE_FIRM_CODE"		, // 21. 발행사코드(4)
				"CARD_SYS_DATE"			, // 22. 카드사요청일자(8)
				"CARD_SYS_TIME"			, // 23. 카드사요청시간(6)
				"CARD_UNIQ_NO"			, // 24. 카드사요청고유번호(20)
				"CARD_MCH_NO"			, // 25. 카드사가맹점번호(20)
				
				"SER_COM_UNIQ_NO"		, // 26. 회사별요청자정보(20)
				"JUMPO_SYS_DATE"		, // 27. 점포서버전문전송일자(8)
				"JUMPO_SYS_TIME"		, // 28. 점포서버전문전송시간(6)
				"RESP_CODE"				, // 29. 응답메시지 코드(4)
				"RESP_MSG"				, // 30. 응답메시지 설명(60)
				
				"HEAD_ETC_FIELD"		, // 31. Header예약필더(201)
				"DELEGATE_BARCODE_NO"	, // 32. 통합바코드번호(32)
				"KEY_IN_TYPE"			, // 33. KEY_IN유무(2)
				"CARD_CERT_FLAG"		, // 34. 신용카드인증구분(2)
				"CARD_NO"				, // 35. 신용카드번호(32)
				
				"CARD_LOCAL_CERTIFY_NO" , // 36. 간편결제인증번호(48)
				"CARD_OTC_CERTIFY_NO"	, // 37. 간편결제인증번호(32)
				"INS_MON"				, // 38. 할부개월(2)
				"CARD_TOT_TRADE_AMT"	, // 39. 전체거래금액(12)
				"CARD_DIS_TRADE_AMT"	, // 40. 할인금액(12)
				
				"CARD_NET_TRADE_AMT"	, // 41. 실승인요청금액(12)
				"CARD_AUTH_DATE"		, // 42. 승인일자(8)
				"CARD_AUTH_TIME"		, // 43. 승인시간(6)
				"CARD_AUTH_NO"			, // 44. 승인번호(20)
				"MD_CNT"				, // 45. 상품수량(4)
				
				"MD_CODE"				, // 46. 상품코드(50)
				"MD_NAME"				, // 47. 상품명(100)
				"ORG_SER_COM_CD"		, // 48. 원거래회사코드(4)
				"ORG_SALE_DATE"			, // 49. 원거래영업일자(8)
				"ORG_ST_CODE"			, // 50. 원거래점코드(10)
				
				"ORG_TM_NO"				, // 51. 원거래포스번호(4)
				"ORG_SHOP_NO"			, // 52. 원거래매장번호(4)
				"ORG_TRAN_NO"			, // 53. 원거래거래번호(4)
				"ORG_CD_NO"				, // 54. 원거래CD번호(4)
				"ORG_SEND_DATE"			, // 55. 원거래전문전송일자(8)
				
				"ORG_SEND_UNIQ_NO"		, // 56. 원거래전송거래고유번호(24)
				"ORG_CARD_AUTH_DATE"	, // 57. 원거래카드승인일자(8)
				"ORG_CARD_AUTH_NO"		, // 58. 원거래카드승인번호(20)
				"DATA_ETC_FIELD"		, // 59. DATA예비필드(627)
				"MSG_END"				  // 60. 전문종료내역(1)
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayMGiftApproval(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,10,100,50,2
					  ,12,1,4,4,8
					  ,10,4,4,4,8
					  ,20,8,8,48};
		String strHeaders[] = {
				"INQ_TYPE"				,
				"CASHER_NO"				,
				"GIFT_CARD_NO"			,
				"GIFT_CONFIRM_NO"		,
				"KEY_IN_TYPE"			,
				
				"TRADE_AMT"				,
				"USE_GUBUN"				,
				"GIFT_CODE"				,
				"ORG_SER_COM_CD"		,
				"ORG_SALE_DATE"			,
				
				"ORG_ST_CODE"			,
				"ORG_TM_NO"				,
				"ORG_TRAN_NO"			,
				"ORG_CD_NO"				,
				"ORG_SEND_DATE"			,
				
				"ORG_SEND_UNIQ_NO"		,				
				"ORG_AUTH_DATE"			,
				"ORG_AUTH_NO"			,
				"PLATFORM_BARCODE"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayBankApproval(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,10,8,2,8,
				6,64,2,1,20,
				3,30,4,96,12,
				12,12,8,6,15,
				8,24,4,8,10,
				4,4,4,8,8,
				8,15,64,12};
		
		String strHeaders[] = {
				"INQ_TYPE"				,//종별 2
				"CASHER_NO"				,//캐셔번호	10
				"MSG_ID"				,//전문아이디 8
				"TRAN_TYPE"				,//트란 타입	2
				"SALE_DATE"				,//영업일자	8
				
				"SALE_TIME"				,//영업시간 6
				"DELEGATE_BARCODE_NO"	,//통합바코드	64
				"KEY_IN_TYPE"			,//key_in 유무2
				"EVENT_MD_IN_YN"		,//이벤트 상품 포함여부1
				"PLATFORM_M_ID"			,//플랫폼 연동 가맹점 id 20
				
				"BANK_CODE"				, // 3. 은행코드(3)         
				"BANK_NM"				, // 4. 은행사명(30)       
				"BANK_VAN_FLAG"			, // 5. 금융VAN구분(4)     
				"BANK_ACCOUNT_NO"		, // 6.가상계좌번호  
				"BANK_TOT_TRADE_AMT"	, // 7.전체거래금액
				
				"BANK_DIS_TRADE_AMT"	, // 8.에누리금액  
				"BANK_NET_TRADE_AMT"	, // 9.실승인요청금액
				"BANK_AUTH_DATE"		, // 10.가상은행계좌 승인일자
				"BANK_AUTH_TIME"		, // 11.가상은행계좌 승인시간
				"BANK_AUTH_NO"			, // 12.가상은행계좌 승인번호
				
				"ORG_SEND_DATE"			, // 13.원거래전문전송일자
				"ORG_SEND_UNIQ_NO"		, // 14.원거래전송거래고유번호
				"ORG_SER_COM_CD"		, // 15.원거래 회사코드
				"ORG_SALE_DATE"			, // 16.원거래 영업일자
				"ORG_ST_CODE"			, // 17.원거래 점코드
				
				"ORG_TM_NO"				, // 18.원거래 포스번호
				"ORG_SHOP_NO"			, // 19.원거래 매장번호
				"ORG_CD_NO"				, // 20.원거래 CD번호
				"ORG_TRAN_NO"			, // 21.원거래 승인일자
				"ORG_CASHER_NO"			, // 22.원거래 승인번호
				
				"ORG_BANK_AUTH_DATE"	, // 23.원거래 가상은행계좌 승인일자
				"ORG_BANK_AUTH_NO"		, // 24.원거래 가산은행계좌 승인번호
				"ORG_DELEGATE_BARCODE_NO", // 25.원거래 통합 바코드
				"ORG_BANK_AUTH_AMT"		, // 26.원거래 실승인요청
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayMGiftCharge(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,10,100,50,2
					  ,12,1,1,4,4
					  ,8,10,4,4,4
					  ,8,20,8,8,48
					  ,2};
		String strHeaders[] = {
				"INQ_TYPE"				,
				"CASHER_NO"				,
				"GIFT_CARD_NO"			,
				"GIFT_CONFIRM_NO"		,
				"KEY_IN_TYPE"			,
				
				"TRADE_AMT"				,
				"SPECIAL_GUBUN"         ,
				"USE_GUBUN"				,
				"GIFT_CODE"				,
				"ORG_SER_COM_CD"		,
				
				"ORG_SALE_DATE"			,				
				"ORG_ST_CODE"			,
				"ORG_TM_NO"				,
				"ORG_TRAN_NO"			,
				"ORG_CD_NO"				,
				
				"ORG_SEND_DATE"			,
				"ORG_SEND_UNIQ_NO"		,				
				"ORG_AUTH_DATE"			,
				"ORG_AUTH_NO"			,
				"PLATFORM_BARCODE"      ,
				
				"PAY_TYPE"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayApproval(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,10,4,4,32
					  ,2,2,32,48,32
					  ,2,12,12,12,4
					  ,50,100,8,4,4
					  ,8,24,8,20};
		String strHeaders[] = {
				"INQ_TYPE"				,
				"CASHER_NO"				,
				"BUY_FIRM_CODE"			,
				"ISSUE_FIRM_CODE"		,
				"DELEGATE_BARCODE_NO"	,
				
				"KEY_IN_TYPE"			,
				"CARD_CERT_FLAG"		,
				"CARD_NO"				,
				"CARD_LOCAL_CERTIFY_NO"	,
				"CARD_OTC_CERTIFY_NO"	,
				
				"INS_MON"				,
				"CARD_TOT_TRADE_AMT"	,
				"CARD_DIS_TRADE_AMT"	,
				"CARD_NET_TRADE_AMT"	,
				"MD_CNT"				,
				
				"MD_CODE"				,
				"MD_NAME"				,
				"ORG_SALE_DATE"			,
				"ORG_TM_NO"				,
				"ORG_TRAN_NO"			,
				
				"ORG_SEND_DATE"			,
				"ORG_SEND_UNIQ_NO"		,
				"ORG_CARD_AUTH_DATE"	,
				"ORG_CARD_AUTH_NO"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayRspInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,8,8,24,4
					  ,2,4,15,8,6
					  ,10,4,4,4,4
					  ,10,8,6,6,4
					  ,30,4,30,8,6
					  ,20,20,20,8,6
					  ,4,60,3,30,4
					  ,20,84,64,2,1
					  ,32,1,64,1,64
					  ,32,12,1,1,2
					  ,64,32,96,96,128
					  ,32,32,1,32,1
					  ,1,1,1,96,15
					  ,6,1,1,8,8
					  ,170,1};
		String strHeaders[] = {
				"MSG_LEN"				, // 01. 전문길이(4)
				"MSG_ID"				, // 02. 전문ID(8)
				"MCH_SEND_DATE"			, // 03. 전문전송일자(8)
				"MCH_SEND_UNIQ_NO"		, // 04. 전송거래고유번호(24)
				"MSG_GUBUN"				, // 05. 요청구분(4)
				
				"TRAN_TYPE"				, // 06. 거래TYPE(2)
				"SER_COM_CD"			, // 07. 회사코드(4)
				"TERM_ID"				, // 08. 터미널아이디(15)
				"SALE_DATE"				, // 09. 영업일자(8)
				"SALE_TIME"				, // 10. 영업시간(6)
				
				"ST_CODE"				, // 11. 점포코드(10)
				"TM_NO"					, // 12. 포스번호(4)
				"SHOP_NO"				, // 13. 매장번호(4)
				"CD_NO"					, // 14. CD번호(4)
				"TRAN_NO"				, // 15. 거래번호(4)
				
				"CASHER_NO"				, // 16. Casher번호(10)
				"POS_DATE"				, // 17. POS시스템일자(8)
				"POS_TIME"				, // 18. POS시스템시간(6)
				"NORMAL_GUBUN"			, // 19. 정상 예외 구분(6)
				"BUY_FIRM_CODE"			, // 20. 매입사코드(4)
				
				"BUY_FIRM_NM"			, // 21. 매입사명(30)
				"ISSUE_FIRM_CODE"		, // 22. 발행사코드(4)
				"ISSUE_FIRM_NM"			, // 23. 발행사명(30)
				"CARD_SYS_DATE"			, // 24. 카드사요청일자(8)
				"CARD_SYS_TIME"			, // 25. 카드사요청시간(6)
				
				"CARD_UNIQ_NO"			, // 26. 카드사요청고유번호(20)
				"CARD_MCH_NO"			, // 27. 카드사가맹점번호(20)
				"SER_COM_UNIQ_NO"		, // 28. 회사별요청자정보(20)
				"JUMPO_SYS_DATE"		, // 29. 점포서버전문전송일자(8)
				"JUMPO_SYS_TIME"		, // 30. 점포서버전문전송시간(6)
				
				"RESP_CODE"				, // 31. 응답메시지 코드(4)
				"RESP_MSG"				, // 32. 응답메시지 설명(60)
				"BANK_CODE"				, // 33. 은행코드(3)           -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"BANK_NM"				, // 34. 은행사명(30)          -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"BANK_VAN_FLAG"			, // 35. 금융VAN구분(4)        -- 계좌 결제 수단 추가 2016.05.27 by OHT
				
				"PLATFORM_M_ID"			, // 36. 플랫폼연동가맹점ID(20)  -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"HEAD_ETC_FIELD"		, // 37. Header예약필더(141)
				"DELEGATE_BARCODE_NO"	, // 38. 통합바코드번호(64)
				"KEY_IN_TYPE"			, // 39. KEY_IN유무(2)
				"EMP_ID_YN"				, // 40. 사원증유무(1)
				
				"EMP_ID_NO"				, // 41. 사원증번호(32)
				"S_POINT_YN"			, // 42. 신세계포인트여부(1)
				"S_POINT_CARD_NO"		, // 43. 신세계포인트카드번호(64)
				"M_GIFT_CARD_YN"		, // 44. 모바일상품권여부(1)
				"M_GIFT_CARD_NO"		, // 45. 모바일상품권번호(64)
				
				"M_GIFT_CONFIRM_NO"		, // 46. 모바일상품권인증번호(32)
				"M_GIFT_CARD_AMT"		, // 47. 모바일상품권잔액(12)
				"CARD_YN"				, // 48. 신용카드여부(1)
				"CARD_CNT"				, // 49. 응답카드수량(1)
				"CARD_CERT_FLAG_1"		, // 50. 신용카드인증구분(2)
				
				"CARD_NO_1"				, // 51. 신용카드번호(64)
				"CARD_DATE_NO_1"		, // 52. 신용카드유효기간(32)
				"CARD_CERTIFY_NO_1"		, // 53. 인증번호(96)
				"CARD_TRACK2DATA_1"		, // 54. 가상 TRACK2 DATA(96)
				"CARD_ETC_DATA_1"		, // 55. 카드사 예비필드(128)
				
				"CARD_RECEIPT_A_1"		, // 56. 영수증출력A(32)
				"CARD_RECEIPT_D_1"		, // 57. 영수증출력D(32)
				"CASH_RECEIPT_YN"		, // 58. 현금영수증식별여부(1)
				"CASH_RECEIPT_INFO"		, // 59. 현금영수증식별정보(32)
				"DIRECT_AUTH_FLAG"		, // 60. 가맹점직라인여부(1)
				
				"EVENT_MD_IN_YN"		, // 61. 이벤트상품포함여부(1)
				"EVENT_YN"				, // 62. 이벤트참여식별여부(1)
				"BANK_YN"				, // 63. 가상은행계좌 여부(1)    -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"BANK_ACCOUNT_NO"		, // 64. 가상은행계좌번호(96)    -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"BANK_RECEIPT"			, // 65. 은행계좌 영수증 출력(15) -- 계좌 결제 수단 추가 2016.05.27 by OHT
				
				"CARD_BIN"				, // 66. 실 카드빈(6) 			--SSGPAY 상시할인/PLCC 추가 2017.06.13 KSN
				"SSGPAY_CP_YN"  		, // 67. SSGPAY 쿠폰 존재 여부(1)  --SSGPAY 상시할인/PLCC 추가 2017.06.13 KSN
				"SSGPAY_CP_FLAG"		, // 68. SSGPAY 쿠폰 구분자(1) 	--SSGPAY 상시할인/PLCC 추가 2017.06.13 KSN
				"SSGPAY_CP_APPLY"		, // 69. SSGPAY 쿠폰 적용 액(8) 	--SSGPAY 상시할인/PLCC 추가 2017.06.13 KSN
				"SSGPAY_CP_MAX_AMT"		, // 70. SSGPAY 쿠폰 최대 금액(8)  --SSGPAY 상시할인/PLCC 추가 2017.06.13 KSN
				
				"DATA_ETC_FIELD"		, // 71. DATA예비필드(170)
				"MSG_END"				  // 72. 전문종료내역(1)
				
				
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 8, 2, 8, 6, 10, 64, 2};
		String strHeaders[] = {
				"INQ_TYPE"				,
				"MSG_ID"				,
				"TRAN_TYPE"				,
				"SALE_DATE"				,
				"SALE_TIME"				,
				"CASHER_NO"				,
				"DELEGATE_BARCODE_NO"	,
				"KEY_IN_TYPE"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
//		for(int i = 0;i < nlens.length;i++ ) {
//			logger.info(">>>" + strHeaders[i] + "=" + (String)hm.get(strHeaders[i]));
//		}
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayInqEx(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 8, 2, 8, 6, 10, 64, 2, 1};
		String strHeaders[] = {
				"INQ_TYPE"				,
				"MSG_ID"				,
				"TRAN_TYPE"				,
				"SALE_DATE"				,
				"SALE_TIME"				,
				"CASHER_NO"				,
				"DELEGATE_BARCODE_NO"	,
				"KEY_IN_TYPE"			,
				"EVENT_MD_IN_YN"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	//20170614 SSGPAY 상시할인/PLCC 추가
	public HashMap<String, String> getParseSSGPayInqEx104(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 8, 2, 8, 6, 10, 64, 2, 1, 1};
		String strHeaders[] = {
				"INQ_TYPE"				,
				"MSG_ID"				,
				"TRAN_TYPE"				,
				"SALE_DATE"				,
				"SALE_TIME"				,
				"CASHER_NO"				,
				"DELEGATE_BARCODE_NO"	,
				"KEY_IN_TYPE"			,
				"EVENT_MD_IN_YN"		,
				"DC_MD_IN_YN"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		System.out.println("[pos>sms] RECV["+hm.size()+"]");
		return hm;
	}
	
	//20171210 SSGPAY PLCC 할인제외칼럼 추가
	public HashMap<String, String> getParseSSGPayInqEx105(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 8, 2, 8, 6, 10, 64, 2, 1, 1, 1};
		String strHeaders[] = {
				"INQ_TYPE"				,
				"MSG_ID"				,
				"TRAN_TYPE"				,
				"SALE_DATE"				,
				"SALE_TIME"				,
				"CASHER_NO"				,
				"DELEGATE_BARCODE_NO"	,
				"KEY_IN_TYPE"			,
				"EVENT_MD_IN_YN"		,
				"DC_MD_IN_YN"			,
				"SSGPAY_CP_YN"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		System.out.println("[pos>sms] RECV["+hm.size()+"]");
		return hm;
	}
	
	/***
	 * getRcvMbsIrtDATA
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	
	public String getRcvMbsIrtDATA(String rcvBuf){		
		HashMap<String, String> hm = new HashMap<String, String>();
		String ret = "";
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};
	
		String strHeaders[] = {      				
				"INQ_TYPE"			  // INQ Type(INQ 종별)    
			};		

		logger.info("getRcvMbsIrtDATA rcvBuf[" + rcvBuf + "]" );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		logger.info("getRcvMbsIrtDATA hm[" + hm + "]" );
		return (String)hm.get("INQ_TYPE");
	}
	
	public HashMap<String, String> getParseSSGPointInq(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,4,6,20,10};  // 42
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별)
				"TRADE_GENTD_DT"	, // 거래발생일자(MMDD)
				"TRADE_GENTD_TM"	, // 거래발생시간(HHMISS)
				"CARD_NO"			, // 포인트 적립할 카드번호
				"BRCH_ID"			  // 가맹점ID
			};
		
//		logger.info("▶ getParseSSGPointInq-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPointInqEx(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,4,6,128,10}; // 150
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별)
				"TRADE_GENTD_DT"	, // 거래발생일자(MMDD)
				"TRADE_GENTD_TM"	, // 거래발생시간(HHMISS)
				"CARD_NO"			, // 포인트 적립할 카드번호
				"BRCH_ID"			  // 가맹점ID
			};
		
//		logger.info("▶ getParseSSGPointInq-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPointRsp(String rcvBuf){ 
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[]= {4,10,6,8,4
					 ,6,5,4,4,20
					 ,20,10,4,10,10
					 ,10,10,10,10,8
					 ,8,8,1,8,20
					 ,10,4,8,6,80
					 ,9,1,1,198};
		String strHeaders[] = {
				"MSG_LEN"			,
				"MSG_TEXT"			,
				"TRADE_GB_CD"		,
				"BUSI_DT"			,
				"TRADE_GENTD_DT"	,
				
				"TRADE_GENTD_TM"	,
				"TRADE_GENTD_STCD"	,
				"POS_NO"			,
				"TRADE_NO"			,
				"APPR_NO"			,
				
				"CARD_NO"			,
				"BRCH_ID"			,
				"PASSWD"			,
				"CORP_CARD_AMT"		,
				"CASH_AMT"			,
				
				"OTHER_ETC_AMT"		,
				"NOADD_AMT"			,
				"SPOINT_AMT"		,
				"TOT_TRADE_AMT"		,
				"TPOINT"			,
				
				"UBPOINT"			,
				"GPOINT"			,
				"REJCT_GB"			,
				"OTRADE_BUSI_DT"	,
				"OTRADE_APPR_NO"	,
				
				"OTRADE_AMT"		,
				"REPLY_CD"			,
				"APPR_CRE_DT"		,
				"APPR_CRE_TM"		,
				"REPLY_MESG"		,
				
				"CUST_ID"			,
				"SSGPAY_FLG"		,
				"INPUT_FLG"		,
				"RESERVE"			
			};
		
//		logger.info("▶ getParseSSGPointInqRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
//		for(int i = 0;i < nlens.length;i++ ) {
//			logger.info(">>>" + strHeaders[i] + "=" + (String)hm.get(strHeaders[i]));
//		}
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPointPhoneRsp(String rcvBuf){ 
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[]= {4, 10, 6, 10, 8
			      , 5, 4, 4, 10, 4
			      , 6, 6, 30, 50, 30
			      , 50, 30, 50, 30, 50
			      , 30, 50, 30, 50, 30
			      , 50, 30, 50, 30, 50
			      , 30, 50, 30, 8, 6
			      , 4, 80
				 };
		String strHeaders[] = {
				"MSG_LEN",              // (4)전문 총길이
				"MSG_TEXT", 			// (10)전문구분
				"TRADE_GB_CD",          // (6)거래구분코드
				"MSG_ID", 	            // (10)전문ID
				"BUSI_DT", 		        // (8)영업일자	
				
				"TRADE_GENTD_STCD", 	// (5)거래발생점코드
				"TRADE_GENTD_POSNO", 	// (4)거래발생POS번호
				"TRADE_NO", 	  		// (4)거래번호
				"BRCH_ID", 	            // (10)가맹점코드
				"TRADE_GENTD_DT", 	    // (4)거래발생일자
				
				"TRADE_GENTD_TM", 	    // (6)거래발생시간
				"PART_CODE",            // (6)관계사 코드 : 이마트위드미(130023)
				"MOBILE_NO", 	        // (30)핸드폰번호
				"CARD_NO1",             // (50)카드번호1
				"CUST_NM1",             // (30)성명1
				
				"CARD_NO2",             // (50)카드번호2
				"CUST_NM2",             // (30)성명2
				"CARD_NO3",             // (50)카드번호3
				"CUST_NM3",             // (30)성명3
				"CARD_NO4",             // (50)카드번호4
				
				"CUST_NM4",             // (30)성명4
				"CARD_NO5",             // (50)카드번호5
				"CUST_NM5",             // (30)성명5
				"CARD_NO6",             // (50)카드번호6
				"CUST_NM6",             // (30)성명6
				
				"CARD_NO7",             // (50)카드번호7
				"CUST_NM7",             // (30)성명7
				"CARD_NO8",             // (50)카드번호8
				"CUST_NM8",             // (30)성명8
				"CARD_NO9",             // (50)카드번호9
				
				"CUST_NM9",             // (30)성명9
				"CARD_NO10",            // (50)카드번호10
				"CUST_NM10",            // (30)성명10
				"SYSTEM_CRE_DT",        // (8)시스템일자
				"SYSTEM_CRE_TM",        // (6)시스템시간
				
				"REPLY_CD",             // (4)응답코드
				"RECV_MESSAGE"            // (80)기타 메시지
			};
		
//		logger.info("▶ getParseSSGPointInqRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
//		for(int i = 0;i < nlens.length;i++ ) {
//			logger.info(">>>" + strHeaders[i] + "=" + (String)hm.get(strHeaders[i]));
//		}
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPointApproval(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,4,6,20
					  ,10,4,10,10,10
					  ,10,10,10};
		String strHeaders[] = {
				"INQ_TYPE"			,
				"TR_GB"				,
				"TRADE_GENTD_DT"	,
				"TRADE_GENTD_TM"	,
				"CARD_NO"			,
				
				"BRCH_ID"			,
				"PASSWD"			,
				"CORP_CARD_AMT"		,
				"CASH_AMT"			,
				"OTHER_ETC_AMT"		,
				
				"NOADD_AMT"			,
				"SPOINT_AMT"		,
				"TOT_TRADE_AMT"
			};
		
//		logger.info("▶ getParseSSGPointApproval-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPointApprovalEx(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,4,6,128
					  ,10,4,10,10,10
					  ,10,10,10};
		String strHeaders[] = {
				"INQ_TYPE"			,
				"TR_GB"				,
				"TRADE_GENTD_DT"	,
				"TRADE_GENTD_TM"	,
				"CARD_NO"			,
				
				"BRCH_ID"			,
				"PASSWD"			,
				"CORP_CARD_AMT"		,
				"CASH_AMT"			,
				"OTHER_ETC_AMT"		,
				
				"NOADD_AMT"			,
				"SPOINT_AMT"		,
				"TOT_TRADE_AMT"
			};
		
//		logger.info("▶ getParseSSGPointApproval-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}

	public HashMap<String, String> getParseSSGPointCancel(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,4,6,20,10
					  ,1,10,10,10,10
					  ,10,10,8,20,10};
		String strHeaders[] = {
				"INQ_TYPE"			,
				"TRADE_GENTD_DT"	,
				"TRADE_GENTD_TM"	,
				"CARD_NO"			,
				"BRCH_ID"			,
				
				"REJCT_GB"			,
				"CORP_CARD_AMT"		,
				"CASH_AMT"			,
				"OTHER_ETC_AMT"		,
				"NOADD_AMT"			,
				
				"SPOINT_AMT"		,
				"TOT_TRADE_AMT"		,
				"OTRADE_BUSI_DT"	,
				"OTRADE_APPR_NO"	,
				"OTRADE_AMT"
		};
		
//		logger.info("▶ getParseSSGPointCancel-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPointCancelEx(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,4,6,128,10
					  ,1,10,10,10,10
					  ,10,10,8,20,10};
		String strHeaders[] = {
				"INQ_TYPE"			,
				"TRADE_GENTD_DT"	,
				"TRADE_GENTD_TM"	,
				"CARD_NO"			,
				"BRCH_ID"			,
				
				"REJCT_GB"			,
				"CORP_CARD_AMT"		,
				"CASH_AMT"			,
				"OTHER_ETC_AMT"		,
				"NOADD_AMT"			,
				
				"SPOINT_AMT"		,
				"TOT_TRADE_AMT"		,
				"OTRADE_BUSI_DT"	,
				"OTRADE_APPR_NO"	,
				"OTRADE_AMT"
		};
		
//		logger.info("▶ getParseSSGPointCancel-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	//20170828 알리페이결제수단추가 _ LYH
	public HashMap<String, String> getParseAlipayInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {
				2, 4, 12, 3, 12,
				1, 8, 12, 30,
			  };

		String strHeaders[] = {
			"INQ_TYPE"         , // 01. INQ종별 (2)
			"MSG_TYP"          , // 02. 메세지타입 (4)
			"MCH_SEND_UNIQ_NO" , // 03. 거래고유번호 (12)
			"PAY_CUR"          , // 04. 통화코드 (3)
			"PAY_AMT"          , // 05. 거래금액 (12)

			"INPUT_TYPE"       , // 06. WCC (1)
			"ORG_AUTH_DT"      , // 07. 원거래승인일자 (8)
			"ORG_AUTH_NO"      , // 08. 원거래승인번호 (12)
			"AUTH_CODE"        , // 09. 바코드 번호 (30)
		};

		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		for (int i = 0; i < nlens.length; i++) 
		{
			logger.info((i+1) + ") " + strHeaders[i] + "=[" + (String) hm.get(strHeaders[i]) + "]");
		}
		
		return hm;
	}

	public HashMap<String, String> getParseAlipayApprovalAndCancel(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {
						2, 4, 12, 3, 12,
						1, 8, 12, 30,
					  };
		
		String strHeaders[] = {
				"INQ_TYPE"         , // 01. INQ종별 (2)
				"MSG_TYP"          , // 02. 메세지타입 (4)
				"MCH_SEND_UNIQ_NO" , // 03. 거래고유번호 (12)
				"PAY_CUR"          , // 04. 통화코드 (3)
				"PAY_AMT"          , // 05. 거래금액 (12)

				"INPUT_TYPE"       , // 06. WCC (1)
				"ORG_AUTH_DT"      , // 07. 원거래승인일자 (8)
				"ORG_AUTH_NO"      , // 08. 원거래승인번호 (12)
				"AUTH_CODE"        , // 09. 바코드 번호 (30)
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		for (int i = 0; i < nlens.length; i++) 
		{
			logger.info((i+1) + ") " + strHeaders[i] + "=[" + (String) hm.get(strHeaders[i]) + "]");
		}
		
		return hm;
	}

	
	
	public HashMap<String, String> getParseWeChatInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {
					   2,10,18,127,3 
					  ,13,4,8,10,4
					  
					  ,4,4,10,8,20
					  ,8,32
					  };
		
		String strHeaders[] = {
				"INQ_TYPE"				,
				"CASHER_NO"	    		,
				"AUTH_CODE"			    ,
				"ITEM_TITLE"		    ,
				"PAY_CURRENCY"			,
				
				"PAY_KRW_AMOUNT"		,
				"ORG_SER_COM_CD"		,
				"ORG_SALE_DATE"			,				
				"ORG_ST_CODE"			,
				"ORG_TM_NO"				,

				"ORG_TRAN_NO"			,
				"ORG_CD_NO"				,
				"ORG_CASHER_NO"			,
				"ORG_SEND_DATE"			,
				"ORG_SEND_UNIQ_NO"		,
				
				"ORG_AUTH_DATE"			,
				"ORG_AUTH_NO"			
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		for (int i = 0; i < nlens.length; i++) 
		{
			logger.info((i+1) + ") " + strHeaders[i] + "=[" + (String) hm.get(strHeaders[i]) + "]");
		}
		
		return hm;
	}
	//20170828 알리페이결제수단추가 _ LYH
	public HashMap<String, String> getParseAlipayRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[]= { 9, 4, 2, 15, 8,
				   6, 4, 12, 3, 12,

				   1, 20, 14, 12, 8,
				   12, 4, 2, 30, 15,

				   40, 50, 4, 8, 6,
				   1, 42, 1, 
				};
	
		 String strHeaders[] = {
				 "MSG_ID"           , // 01. Option Data (9)
				 "MSG_TYP"          , // 02. 메세지타입 (4)
				 "TRAN_CODE"        , // 03. TRAN_CODE (2)
				 "TERMINAL_ID"      , // 04. 터미널 ID (15)
				 "SALE_DD"          , // 05. 영업일자 YYYYMMDD (8)

				 "ST_CODE"          , // 06. 점포코드 (6)
				 "TM_NO"            , // 07. POS 번호 (4)
				 "MCH_SEND_UNIQ_NO" , // 08. 거래고유번호 (12)
				 "PAY_CUR"          , // 09. 통화코드 (3)
				 "PAY_AMOUNT"       , // 10. 거래금액 (12)

				 "KEY_IN_TYP"       , // 11. WCC (1)
				 "MCH_USE"          , // 12. 가맹점 추가 사용. (20)
				 "AUTH_DT"          , // 13. 승인일시 YYYYMMDDhhmmss  (14)
				 "AUTH_NO"          , // 14. 승인번호 (12)
				 "ORG_AUTH_DD"      , // 15. 원거래 승인일자 (8)

				 "ORG_AUTH_NO"      , // 16. 원거래 승인번호 (12)
				 "RESP_CODE"        , // 17. 응답메세지코드(4)
				 "MCH_TYP"          , // 18. 가맹점 구분 (2)
				 "AUTH_CODE"        , // 19. 바코드번호 (30)
				 "MCH_NO"           , // 20. 가맹점번호 (15)

				 "RESP_MSG"         , // 21. 응답메세지 (40)
				 "PAY_INFO"         , // 22. 알리페이 결재정보(50)
				 "SER_COM_CD"       , // 23. 회사코드 (4)
				 "POS_DD"           , // 24. POS 시스템일자 YYYYMMDD (8)
				 "POS_TM"           , // 25. POS 시스템시간 24HMISS (6)

				 "PAY_STATUS"       , // 26. 알리페이 거래 상태(1)
				 "DATE_ETC_FILED"   , // 27. filler (42)
				 "MSG_END"          , // 28. CR (1)
		};
		 
		//hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		byte[] rcvBufBytes = null;
		try {
			rcvBufBytes = rcvBuf.getBytes("iso-8859-1");
		} catch ( Exception ex){
			rcvBufBytes = rcvBuf.getBytes();
		}		 
		
		int bInx=0;
		int eInx=0;	

		eInx = nlens[0];
		
		for(int i=0; i<nlens.length; i++ ){
			
			try { 
				hm.put(strHeaders[i].toString(), new String(rcvBufBytes, bInx, eInx - bInx,"EUC-KR"));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}	
			if (i<nlens.length-1){
				bInx = eInx;
				eInx = eInx+nlens[i+1];
			}
		}	

		for (int i = 0; i < nlens.length; i++) 
		{
			logger.info((i+1) + ") " + strHeaders[i] + "=[" + (String) hm.get(strHeaders[i]) + "]");
		}
		
		return hm;
	}

	public HashMap<String, String> getParseWeChatRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[]= {4,8,8,20,15
				 ,4,4,8,6,10
				 
				 ,4,4,4,10,8
				 ,6,20,8,6,53
				 
				 ,2,18,32,127,127
				 ,3,7,13,13,4
				 
				 ,8,10,4,4,4
				 ,10,8,20,15,8
				 
				 ,32,8,6,32,4
				 ,128,1,1,40,1
			};
	
   String strHeaders[] = {
           "MSG_LEN"           , // 01. 전문 길이
           "MSG_ID"            , // 02. 전문 ID
           "MCH_SEND_DATE"     , // 03. 전문전송일자
           "MCH_SEND_UNIQ_NO"  , // 04. 전송거래고유번호
           "MCH_NO"            , // 05. 가맹점번호

           "MSG_GUBUN"         , // 06. 요청구분
           "SER_COM_CD"        , // 07. 회사코드
           "SALE_DATE"         , // 08. 영업일자
           "SALE_TIME"         , // 09. 영업시간
           "ST_CODE"           , // 10. 점코드

           "TM_NO"             , // 11. 포스 번호
           "CD_NO"             , // 12. CD 번호
           "TRAN_NO"           , // 13. 거래 번호
           "CASHER_NO"         , // 14. Casher 번호
           "POS_DATE"          , // 15. POS시스템일자

           "POS_TIME"          , // 16. POS시스템시간
           "SER_COM_UNIQ_NO"   , // 17. 회사별 요청자 정보
           "JUMPO_SYS_DATE"    , // 18. 점포서버 전문전송일자
           "JUMPO_SYS_TIME"    , // 19. 점포서버 전문전송시간
           "HEAD_ETC_FIELD"    , // 20. 헤더예비필드

           "TRAN_TYPE"          , // 21. 거래TYPE (2)
           "AUTH_CODE"          , // 22. 인증코드 (18)
           "ITEM_CODE"          , // 23. 상품코드 (32)
           "ITEM_TITLE"         , // 24. 상품이름 (127)
           "ITEM_CONTENT"       , // 25. 상품설명 (127)

           "PAY_CURRENCY"       , // 26. 결제요청통화 (3)
           "PAY_RATE"           , // 27. 결제요청환율 (7)
           "PAY_KRW_AMOUNT"     , // 28. 결제요청금액(원화) (13)
           "PAY_USD_AMOUNT"     , // 29. 결제요청금액(외화) (13)
           "ORG_SER_COM_CD"     , // 30. 원거래 회사코드 (4)

           "ORG_SALE_DATE"      , // 31. 원거래 영업일자 (8)
           "ORG_ST_CODE"        , // 32. 원거래 점코드 (10)
           "ORG_TM_NO"          , // 33. 원거래 포스번호 (4)
           "ORG_TRAN_NO"        , // 34. 원거래 거래번호 (4)
           "ORG_CD_NO"          , // 35. 원거래 CD번호 (4)

           "ORG_CASHER_NO"      , // 36. 원거래 Casher번호 (10)
           "ORG_SEND_DATE"      , // 37. 원거래 전문전송일자 (8)
           "ORG_SEND_UNIQ_NO"   , // 38. 원거래 전송고유번호 (20)
           "ORG_MCH_NO"         , // 39. 원거래 가맹점번호 (15)
           "ORG_AUTH_DATE"      , // 40. 원거래 승인일자 (8)

           "ORG_AUTH_NO"        , // 41. 원거래 승인번호 (32)
           "AUTH_DATE"          , // 42. 승인일자 (8)
           "AUTH_TIME"          , // 43. 승인시간 (6)
           "AUTH_NO"            , // 44. 승인번호 (32)
           "RESP_CODE"          , // 45. 응답코드 (4) 

           "RESP_MSG"           , // 46. 응답메시지 (128)
           "PAY_STATUS"         , // 47. 결제상태 (1)
           "CANCEL_STATUS"      , // 48. 취소상태 (1)
           "DATA_ETC_FIELD"     , // 49. DATA예비필드 (40)
           "MSG_END"              // 50. 전문종료바이트 (1)
       };
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		for (int i = 0; i < nlens.length; i++) 
		{
			logger.info((i+1) + ") " + strHeaders[i] + "=[" + (String) hm.get(strHeaders[i]) + "]");
		}
		
		return hm;
	}
	
	public HashMap<String, String> getParseWeChatApproval(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,10,4,4,32
					  ,2,2,32,48,32
					  ,2,12,12,12,4
					  ,50,100,8,4,4
					  ,8,24,8,20};
		String strHeaders[] = {
				"INQ_TYPE"				,
				"CASHER_NO"				,
				"BUY_FIRM_CODE"			,
				"ISSUE_FIRM_CODE"		,
				"DELEGATE_BARCODE_NO"	,
				
				"KEY_IN_TYPE"			,
				"CARD_CERT_FLAG"		,
				"CARD_NO"				,
				"CARD_LOCAL_CERTIFY_NO"	,
				"CARD_OTC_CERTIFY_NO"	,
				
				"INS_MON"				,
				"CARD_TOT_TRADE_AMT"	,
				"CARD_DIS_TRADE_AMT"	,
				"CARD_NET_TRADE_AMT"	,
				"MD_CNT"				,
				
				"MD_CODE"				,
				"MD_NAME"				,
				"ORG_SALE_DATE"			,
				"ORG_TM_NO"				,
				"ORG_TRAN_NO"			,
				
				"ORG_SEND_DATE"			,
				"ORG_SEND_UNIQ_NO"		,
				"ORG_CARD_AUTH_DATE"	,
				"ORG_CARD_AUTH_NO"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	public HashMap<String, String> getParseWeChatCancel(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,4,6,20,10
					  ,1,10,10,10,10
					  ,10,10,8,20,10};
		String strHeaders[] = {
				"INQ_TYPE"			,
				"TRADE_GENTD_DT"	,
				"TRADE_GENTD_TM"	,
				"CARD_NO"			,
				"BRCH_ID"			,
				
				"REJCT_GB"			,
				"CORP_CARD_AMT"		,
				"CASH_AMT"			,
				"OTHER_ETC_AMT"		,
				"NOADD_AMT"			,
				
				"SPOINT_AMT"		,
				"TOT_TRADE_AMT"		,
				"OTRADE_BUSI_DT"	,
				"OTRADE_APPR_NO"	,
				"OTRADE_AMT"
		};
		
		logger.info("▶ getParseWeChatCancel-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public HashMap<String, String> getParseSSGPosaInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {
					   2,10,100,20,2 
					  ,12,1,4,8,10
					  
					  ,4,4,4,8,20
					  ,8,8,12,8,6
					  };
		
		String strHeaders[] = {
				"INQ_TYPE"				,
				"CASHER_NO"				,
				"POSA_CARD_NO"			,
				"MD_CODE"		        ,
				"KEY_IN_TYPE"			,
				
				"TRADE_AMT"				,
				"POSA_GUBUN"            ,
				"ORG_SER_COM_CD"		,
				"ORG_SALE_DATE"			,				
				"ORG_ST_CODE"			,

				"ORG_TM_NO"				,
				"ORG_TRAN_NO"			,
				"ORG_CD_NO"				,
				"ORG_SEND_DATE"			,
				"ORG_SEND_UNIQ_NO"		,
				
				"ORG_AUTH_DATE"			,
				"ORG_AUTH_NO"			,
				"EVENT_AMT"             ,
				"SEND_DATE"             ,
				"SEND_TIME"               
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		for (int i = 0; i < nlens.length; i++) 
		{
			logger.info((i+1) + ") " + strHeaders[i] + "=[" + (String) hm.get(strHeaders[i]) + "]");
		}
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPosaRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[]= {
				  4,8,8,20,15
				 ,4,4,8,6,10
				 
				 ,4,4,4,10,8
				 ,6,20,8,6,53
				 
				 ,2,2,1,50,50
				 ,100,50,2,12,1
				 
				 ,1,1,2,20,4
				 ,8,10,4,4,4
				 
				 ,8,20,15,8,8
				 ,8,6,8,12,30
				 
				 ,4,60,32,12,130
				 ,1
			};
	
   String strHeaders[] = {
           "MSG_LEN"           , // 01. 전문 길이
           "MSG_ID"            , // 02. 전문 ID
           "MCH_SEND_DATE"     , // 03. 전문전송일자
           "MCH_SEND_UNIQ_NO"  , // 04. 전송거래고유번호
           "POSA_MCH_NO"       , // 05. 가맹점번호

           "MSG_GUBUN"         , // 06. 요청구분
           "SER_COM_CD"        , // 07. 회사코드
           "SALE_DATE"         , // 08. 영업일자
           "SALE_TIME"         , // 09. 영업시간
           "ST_CODE"           , // 10. 점코드

           "TM_NO"             , // 11. 포스 번호
           "CD_NO"             , // 12. CD 번호
           "TRAN_NO"           , // 13. 거래 번호
           "CASHER_NO"         , // 14. Casher 번호
           "POS_DATE"          , // 15. POS시스템일자

           "POS_TIME"          , // 16. POS시스템시간
           "SER_COM_UNIQ_NO"   , // 17. 회사별 요청자 정보
           "JUMPO_SYS_DATE"    , // 18. 점포서버 전문전송일자
           "JUMPO_SYS_TIME"    , // 19. 점포서버 전문전송시간
           "HEAD_ETC_FIELD"    , // 20. 헤더예비필드

           "TRAN_TYPE"         , // 21. 거래 TYPE
           "TRADE_TYPE"        , // 22. 요청 TYPE
           "TRACK_TYPE"        , // 23. TRACK 유무
           "START_BARCODE"     , // 24. 시작바코드
           "END_BARCODE"       , // 25. 종료바코드

           "POSA_CARD_NO"      , // 26. POSA 카드 번호
           "POSA_CONFIRM_NO"   , // 27. PIN 번호
           "KEY_IN_TYPE"       , // 28. KEY IN 유무
           "TRADE_AMT"         , // 29. 요청금액
           "SPECIAL_GUBUN"     , // 30. 거래별 구분 코드

           "USE_GUBUN"         , // 31. 사용구분
           "POSA_GUBUN"        , // 32. 상품종류구분
           "PART_GUBUN"        , // 33. 제휴사구분코드
           "POSA_MOBILE_NO"    , // 34. 선물하기 번호
           "ORG_SER_COM_CD"    , // 35. 원거래 회사코드

           "ORG_SALE_DATE"     , // 36. 원거래 영업일자
           "ORG_ST_CODE"       , // 37. 원거래 점코드
           "ORG_TM_NO"         , // 38. 원거래 포스 번호
           "ORG_TRAN_NO"       , // 39. 원거래 거래 번호
           "ORG_CD_NO"         , // 40. 원거래 CD 번호

           "ORG_SEND_DATE"     , // 41. 원거래 전문전송 일자
           "ORG_SEND_UNIQ_NO"  , // 42. 원거래 전송 거래고유번호
           "ORG_POSA_MCH_NO"   , // 43. 원거래 가뱅점번호
           "ORG_AUTH_DATE"     , // 44. 원거래 승일일자
           "ORG_AUTH_NO"       , // 45. 원거래 승인번호

           "AUTH_DATE"         , // 46. 승인일자
           "AUTH_TIME"         , // 47. 승인시간
           "AUTH_NO"           , // 48. 승인번호
           "REMAIN_AMT"        , // 49. 상품권잔액
           "MD_CODE"           , // 50. 회사별 상품 코드

           "RESP_CODE"         , // 51. 응답코드
           "RESP_MSG"          , // 52. 응답메시지
           "EXT_POSA_CARD_NO"  , // 53. 외부 발행 카드 번호
           "EVENT_AMT"         , // 54. 행사 할인금액
           "DATA_ETC_FIELD"    , // 55. DATA 예비필드

           "MSG_END"             // 56. 전문종료내역
       };
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		for (int i = 0; i < nlens.length; i++) 
		{
			logger.info((i+1) + ") " + strHeaders[i] + "=[" + (String) hm.get(strHeaders[i]) + "]");
		}
		
		return hm;
	}
	
	public HashMap<String, String> getParsePosaApproval(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,10,4,4,32
					  ,2,2,32,48,32
					  ,2,12,12,12,4
					  ,50,100,8,4,4
					  ,8,24,8,20};
		String strHeaders[] = {
				"INQ_TYPE"				,
				"CASHER_NO"				,
				"BUY_FIRM_CODE"			,
				"ISSUE_FIRM_CODE"		,
				"DELEGATE_BARCODE_NO"	,
				
				"KEY_IN_TYPE"			,
				"CARD_CERT_FLAG"		,
				"CARD_NO"				,
				"CARD_LOCAL_CERTIFY_NO"	,
				"CARD_OTC_CERTIFY_NO"	,
				
				"INS_MON"				,
				"CARD_TOT_TRADE_AMT"	,
				"CARD_DIS_TRADE_AMT"	,
				"CARD_NET_TRADE_AMT"	,
				"MD_CNT"				,
				
				"MD_CODE"				,
				"MD_NAME"				,
				"ORG_SALE_DATE"			,
				"ORG_TM_NO"				,
				"ORG_TRAN_NO"			,
				
				"ORG_SEND_DATE"			,
				"ORG_SEND_UNIQ_NO"		,
				"ORG_CARD_AUTH_DATE"	,
				"ORG_CARD_AUTH_NO"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	public HashMap<String, String> getParsePosaCancel(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,4,6,20,10
					  ,1,10,10,10,10
					  ,10,10,8,20,10};
		String strHeaders[] = {
				"INQ_TYPE"			,
				"TRADE_GENTD_DT"	,
				"TRADE_GENTD_TM"	,
				"CARD_NO"			,
				"BRCH_ID"			,
				
				"REJCT_GB"			,
				"CORP_CARD_AMT"		,
				"CASH_AMT"			,
				"OTHER_ETC_AMT"		,
				"NOADD_AMT"			,
				
				"SPOINT_AMT"		,
				"TOT_TRADE_AMT"		,
				"OTRADE_BUSI_DT"	,
				"OTRADE_APPR_NO"	,
				"OTRADE_AMT"
		};
		
		logger.info("▶ getParsePosaCancel-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPointPhoneInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 8, 5, 4, 4
				       , 4, 6, 30, 10
				      }; // 798
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ종별 : 신세계포인트 전화번호 조회
				"SALE_DATE"	        , // 영업일자
				"STORE_CD"	        , // 가맹점코드(점포코드)
				"POS_NO"	        , // POS번호
				"TRAN_NO"	        , // 거래번호
				
				"TRADE_GENTD_DT"	, // 거래발생일자
				"TRADE_GENTD_TM"	, // 거래발생시간
				"MOBILE_NO"			, // 전화번호
				"BRCH_ID"			 // 가맹점ID	
			};
		
//		logger.info("▶ getParseSSGPointInq-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayCoupon(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 5, 4, 8, 8
				       , 20, 15, 4, 4, 8
				       , 6, 10, 4, 4, 4
				       , 10, 8, 6, 2, 2
				       , 1, 100, 50, 2, 12
				       , 1, 1, 1, 2, 20
				       , 4, 8, 10, 4, 4
				       , 4, 8, 20, 15, 8
				       , 8
				      }; 
		String strHeaders[] = {
				"INQ_TYPE"					, // 01.ING종별(2)
				"STORE_CODE"				, // 02.점포코드(5)
				"POS_NO"					, // 03.POS번호(4)
				"MSG_ID"					, // 04.전문ID(8)
				"MCH_SEND_DATE"				, // 05.전문전송일자(8)

				"MCH_SEND_UNIQ_NO"			, // 06.전송거래고유번호(20)
				"MCH_NO"					, // 07.가맹점번호(15)
				"MSG_GUBUN"					, // 08.요청구분(4)
				"SER_COM_CD"				, // 09.회사코드(4)
				"SALE_DATE"					, // 10.영업일자(8)

				"SALE_TIME"					, // 11.영업시간(6)
				"ST_CODE"					, // 12.점코드(10)
				"TM_NO"						, // 13.포스번호(4)
				"CD_NO"						, // 14.CD번호(4)
				"TRAN_NO"					, // 15.거래번호(4)

				"CASHER_NO"					, // 16.Casher번호(10)
				"POS_DATE"					, // 17.POS시스템일자(8)
				"POS_TIME"					, // 18.POS시스템시간(6)
				"TRAN_TYPE"					, // 19.거래 TYPE(2)
				"TRADE_TYPE"				, // 20.요청TYPE(2)

				"TRACK_TYPE"				, // 21.Track2유무(1)
				"GIFT_CARD_NO"				, // 22.쿠폰번호(100)
				"CONFIRM_NO"				, // 23.PIN번호(50)
				"KEY_IN_TYPE"				, // 24.KEY IN 유무(2)
				"TRADE_AMT"					, // 25.요청금액(12)

				"SPECIAL_GUBUN"				, // 26.거래별 구분코드(1)
				"USE_GUBUN"					, // 27.사용구분(1)
				"GOODS_GUBUN"				, // 28.상품종류구분(1)
				"PART_GUBUN"				, // 29.제유사구분코드(2)
				"MOBILE_NO"					, // 30.선물하기 번호(20)

				"ORG_SER_COM_CD"			, // 31.원거래 회사코드(4)
				"ORG_SALE_DATE"				, // 32.원거래 영업일자(8)
				"ORG_ST_CODE"				, // 33.원거래 점코드(10)
				"ORG_TM_NO"					, // 34.원거래 포스 번호(4)
				"ORG_TRAN_NO"				, // 35.원거래 거래 번호(4)

				"ORG_CD_NO"					, // 36.원거래 CD번호(4)
				"ORG_SEND_DATE"				, // 37.원거래 전문전송일자(8)
				"ORG_SEND_UNIQ_NO"			, // 38.원거래 전송 고유거래번호(20)
				"ORG_MCH_NO"				, // 39.원거래 가맹점번호(15)
				"ORG_AUTH_DATE"				, // 40.원거래 승인일자(8)

				"ORG_AUTH_NO"				, // 41.원거래 승인번호(8)
			};
		
//		logger.info("▶ getParseSSGPointInq-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSSGPayCouponRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4, 8, 8, 20, 15
					 ,4, 4, 8, 6, 10 
					 ,4, 4, 4, 10, 8 
					 , 6, 20, 8, 6, 53 
					 , 2, 2, 1, 100, 100 
					 , 50, 2, 12, 1, 1 
					 , 1, 2, 20, 4, 8 
					 , 10, 4, 4, 4, 8 
					 , 20, 15, 8, 8, 8 
					 , 6, 8, 12, 30, 4 
					 , 60, 174, 1};
		String strHeaders[] = {
								/* 통합결제플랫폼조회전문 HEADER 구성  */
								"MSG_LEN"							,  // 01.전문길이(4) : 0900
								"MSG_ID"							,  // 02.전문 ID(8) : 승인/취소-CPAU0200, 망취소-CPIM0300       
								"MCH_SEND_DATE"						,  // 03.전문전송일자(8)      
								"MCH_SEND_UNIQ_NO"					,  // 04.전송 거래고유번호(20) : 영업일자(8)+포스번호(4)+CD번호(4)+거래번호(4) 
								"MCH_NO"							,  // 05.가맹점번호(15) : IC00000000
				
								"MSG_GUBUN"							,  // 06.요청구분(4) : SEND
								"SER_COM_CD"						,  // 07.회사코드(4) : 5700
								"SALE_DATE"							,  // 08.영업일자(8)
								"SALE_TIME"							,  // 09.영업시간(6)
								"ST_CODE"							,  // 10.점코드(10)
				
								"TM_NO"								,  // 11.포스번호(4)
								"CD_NO"								,  // 12.CD번호(4)
								"TRAN_NO"							,  // 13.거래번호(4)
								"CASHER_NO"							,  // 14.Casher번호(10)
								"POS_DATE"							,  // 15.POS시스템일자(8)
				
								"POS_TIME"							,  // 16.POS시스템시간(6)
								"SER_COM_UNIQ_NO"					,  // 17.회사별 요청자 정보(20) : SPACE로 체움
								"JUMPO_SYS_DATE"					,  // 18.점포서버 전문전송일자(8)
								"JUMPO_SYS_TIME"					,  // 19.점포서버 전문전송시간(6)
								"HEAD_ETC_FIELD"					,  // 20.헤더예비필드(53) : SPACE로 체움
				
								/* 통합결제플랫폼조회전문 DETAIL 구성  */                   
								"TRAN_TYPE"							,  // 21.거래 TYPE(2) : 승인-00, 취소-01, 망취소-03
								"TRADE_TYPE"						,  // 22.요청 TYPE(2) : 회수-25, 취소-65
								"TRACK_TYPE"						,  // 23.Track2 유무(1) : 개별-3
								"END_BARCODE"						,  // 24.종료바코드(100) : SPACE로 체움
								"GIFT_CARD_NO"						,  // 25.쿠폰 번호(100)
				
								"CONFIRM_NO"						,  // 26.PIN 번호(50) : SPACE로 체움
								"KEY_IN_TYPE"						,  // 27.KEY IN 유무(2) : 바코드-05, WEB-06, SWIP-00, KEYIN-01, RF-02, IR-03
								"TRADE_AMT"							,  // 28.요청금액(12)
								"SPECIAL_GUBUN"						,  // 29.거래별 구분 코드(1) : 일반-1
								"USE_GUBUN"							,  // 30.사용구분(1) : 승인-1, 그외-NULL
				
								"GOODS_GUBUN"						,  // 31.상품종류구분(1) : 쿠폰-5
								"PART_GUBUN"						,  // 32.제휴사구분코드(2) : 자사상품-60
								"MOBILE_NO"							,  // 33.선물하기 번호(20) : SPACE로 체움
								"ORG_SER_COM_CD"					,  // 34.원거래 회사코드(4) : 취소-승인정보, 승인-SPACE
								"ORG_SALE_DATE"						,  // 35.원거래 영업일자(8) : 취소-승인정보, 승인-SPACE
				
								"ORG_ST_CODE"						,  // 36.원거래 점코드(10) : 취소-승인정보, 승인-SPACE
								"ORG_TM_NO"							,  // 37.원거래 포스번호(4) : 취소-승인정보, 승인-SPACE
								"ORG_TRAN_NO"						,  // 38.원거래 거래 번호(4) : 취소-승인정보, 승인-SPACE
								"ORG_CD_NO"							,  // 39.원거래 CD 번호(4) : 취소-승인정보, 승인-SPACE
								"ORG_SEND_DATE"						,  // 40.원거래 전문전송일자(8) : 취소-승인정보, 승인-SPACE
				
								"ORG_SEND_UNIQ_NO"					,  // 41.원거래 전송 거래고유번호(20) : 취소-승인정보, 승인-SPACE
								"ORG_MCH_NO"						,  // 42.원거래 가맹점번호(15) : 취소-승인정보, 승인-SPACE
								"ORG_AUTH_DATE"						,  // 43.원거래 승인일자(8) : 취소-승인정보, 승인-SPACE
								"ORG_AUTH_NO"						,  // 44.원거래 승인번호(8) : 취소-승인정보, 승인-SPACE
								"AUTH_DATE"							,  // 45.승인일자(8) : SPACE로 체움
				
								"AUTH_TIME"							,  // 46.승인시간(6) : SPACE로 체움
								"AUTH_NO"							,  // 47.승인번호(8) : SPACE로 체움
								"REMAIN_AMT"						,  // 48.잔액(12) : SPACE로 체움
								"MD_CODE"							,  // 49.상품 코드(30) : SPACE로 체움
								"RESP_CODE"							,  // 50.응답 코드(4) : SPACE로 체움
				
								"RESP_MSG"							,  // 51.응답메시지(60) : SPACE로 체움
								"DATA_ETC_FIELD"					,  // 52.DATA예비필드(174) : SPACE로 체움
								"MSG_END" 							   // 53.전문 종료 내역(1) : SPACE로 체움         
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	public HashMap<String, String> getParseSSGConCheck (String rcvBuf) { //20171202 KSN SSGCON 쿠폰조회요청
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 2, 10, 8, 6, 2,
				        64, 64
				      }; //92
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ종별 : SSG CON 조회 요청
				"USER_ID"	        , // 사원번호
				"SALE_DATE"	        , // 거래일자
				"SALE_TIME"	        , // 거래시간
				"KEY_IN_TYPE"	    , // 수 입력타입 (01: KEY-IN, 02:SCAN)
				
				"COUPON_NO"			, // 쿠폰번호(암호화)
				"BARCODE_NO"		  // 통합바코드번호(암호화)
			};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	public HashMap<String, String> getParseSSGConApprReq (String rcvBuf) { //20171205 KSN SSGCON 쿠폰승인요청
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 2, 1, 10, 8, 6,
				        2, 64, 12, 26, 8,
				        8, 8, 20, 3, 4,
				        20, 64, 12, 8, 64
				      }; //272
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ종별 : SSG CON 승인 요청
				"TYPE"		        , // 거래구분
				"USER_ID"	        , // 사원번호
				"SALE_DATE"	        , // 거래일자
				"SALE_TIME"	        , // 거래시간
				
				"KEY_IN_TYPE"	    , // 수 입력타입 (01: KEY-IN, 02:SCAN)
				"COUPON_NO"			, // 쿠폰번호(암호화)
				"USED_AMT"			, // 사용금액
				"ORG_TRACE_NO"		, // 원거래 전문 추적번호
				"ORG_SALE_DATE"		, // 원거래 거래일자
				
				"ORG_AUTH_DATE"		, // 원거래 승인일자
				"ORG_AUTH_NO"		, // 원거래 승인번호
				"SEL_AUTH_NO"		, // 조회인증번호
				"CLASS_GUBUN"		, // 분류구분
				"PRD_TYPE"			, // 상품타입
				
				"PRD_ID"			, // 상품아이디
				"PRD_NM"			, // 상품명
				"PRD_AMT"			, // 상품액면가
				"ORG_MSG_SEND_DT"	, // 원거래 전문 전송일자
				"BARCODE_NO"		  // 통합바코드번호(암호화)
			};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		
		return hm;
	}
	
	
	public HashMap<String, String> getParseSSGConPrdApprReq (String rcvBuf) { //20171205 KSN SSGCON 쿠폰승인요청
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 2, 1, 10, 8, 6,
				        2, 64, 12, 20, 3,
				        4, 20, 26, 8, 8,
				        8, 8, 64, 20
				      };
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ종별 : SSG CON 승인 요청
				"TYPE"		        , // 거래구분
				"USER_ID"	        , // 사원번호
				"SALE_DATE"	        , // 거래일자
				"SALE_TIME"	        , // 거래시간
				
				"KEY_IN_TYPE"	    , // 수 입력타입 (01: KEY-IN, 02:SCAN)
				"COUPON_NO"			, // 쿠폰번호(암호화)
				"USED_AMT"			, // 사용금액
				"SEL_AUTH_NO"		, // 조회인증번호
				"CLASS_GUBUN"		, // 분류구분
				
				"PRD_TYPE"			, // 상품타입
				"PRD_ID"			, // 상품ID
				"ORG_TRACE_NO"		, // 원거래 전문 추적번호
				"ORG_SALE_DATE"		, // 원거래 거래일자
				"ORG_AUTH_DATE"		, // 원거래 승인일자
				
				"ORG_AUTH_NO"		, // 원거래 승인번호
				"ORG_MSG_SEND_DT"	, // 원거래 전문 전송일자
				"BARCODE_NO"		, // 통합바코드번호(암호화)
				"PRD_SKU_CODE"		  // 상품바코드
			};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		
		return hm;
	}
	
	
	public HashMap<String, String> getParseSSGConRspHDR(String rcvBuf){ 
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[]= {5, 8, 8, 6, 26,
					  5, 15, 15, 4, 10,
					  4, 5, 4, 5, 10,
					  2, 8, 6, 40, 1,
					  4, 64, 45, 2, 2,
					  1, 1, 64, 20, 4
				 };
		String strHeaders[] = {
				"MSG_LEN",              // (5)전문 총길이
				"MSG_ID",	 			// (8)전문 번호
				"MSG_SEND_DT",          // (8)전문 전송일자
				"MSG_SEND_TM", 	        // (6)전문 전송시간
				"MSG_TRACE_NO", 		// (26)전문 전송거래추적번호	
				
				"MSG_DATA_LEN", 		// (5)전문 본문길이
				"PTR_ID", 				// (15)제휴사 아이디
				"PTR_MCH_ID", 			// (15)가맹점 아이디
				"SER_COM_CD", 	  		// (4)회사코드
				"ST_CODE", 	            // (10)점 코드
				
				"TM_NO", 	    		// (4)포스번호
				"SHOP_NO",              // (5)매장 번호
				"CD_NO",	 	        // (4)CD 번호
				"TRAN_NO",              // (5)거래 번호
				"CASHER_NO",            // (10)캐셔 번호
				
				"TRAN_TYPE",            // (2)거래 구분
				"SALE_DATE",            // (8)거래 일자
				"SALE_TIME",            // (6)거래 시간
				"SER_COM_REQ_NO",       // (40)회사별 부가요청 정보
				"CRYPYO_GUBUN",         // (1)보안 설정구분
				
				"RESP_CODE",            // (4)응답 코드
				"RESP_MSG",             // (64)응답 메시지
				"HEADER_FILLER",        // (45)헤더 필러
				"KEY_IN_TYPE",	        // (2)수 입력타입
				"TRADE_TYPE",        	// (2)거래 요청타입
				
				"USE_FUNC_GUBUN",       // (1)사용 가능 구분
				"USE_GUBUN",        	// (1)사용 구분
				"DELEGATE_BARCODE_NO",  // (64)통합 바코드번호
				"SEL_AUTH_NO",        	// (20)조회 인증번호
				"GRP_ARRAY_CNT"         // (4)그룹 정보 개수
			};
		
//		logger.info("▶ getParseSSGPointInqRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
//		for(int i = 0;i < nlens.length;i++ ) {
//			logger.info(">>>" + strHeaders[i] + "=" + (String)hm.get(strHeaders[i]));
//		}
		
		return hm;
	}
	
	
	
	public HashMap<String, String> getParseSSGConCheckRspGRP(String rcvBuf){ 
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[]= {4, 2, 20, 3, 3,
				      64, 20, 64, 20, 4,
				      12, 10, 4, 1, 12,
				      12, 12, 12, 8, 8,
				      101, 4
				 };
		String strHeaders[] = {
				"GRP_STA",              // (4)그룹 시작문자
				"GRP_TYPE",	 			// (2)그룹 타입
				"ADD_DC_CODE",          // (20)추가할인코드
				"INFO_INDEX", 	        // (3)상품 정보 순서
				"CLASS_GUBUN", 			// (3)분류 구분
				
				"CPN_NO", 				// (64)쿠폰 번호
				"PRD_ID", 				// (20)상품 아이디
				"PRD_NM", 				// (64)상품 명
				"PRD_SKU_CODE", 	  	// (20)상품 바코드
				"PRD_CNT", 	            // (4)상품 갯수
				
				"PRD_AMT", 	    		// (12)상품 액면가
				"BRD_CODE",             // (10)브랜드 코드
				"PRD_TYPE",	 	        // (4)상품 타입
				"AMT_RATE_GUBUN",       // (1)정액/정률 구분
				"MIN_MAX_DC_BUY_AMT",   // (12)최소/최대 할인구매금액
				
				"DC_RATE_AMT",          // (12)할인율(금액)적립율(금액)
				"ADD_DC_RATE_AMT",      // (12)추가할인율(금액)
				"REMAIN_AMT",      		// (12)남은금액
				"EXPIRY_STARTDATE",     // (8)유효기간 시작일
				"EXPIRY_ENDDATE",       // (8)유효기간 종료일
				
				"ARRAY_ETC_FILED",      // (101)ARRAY DATA 예비필드
				"GRP_END"               // (4)그룹 종료
			};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	public HashMap<String, String> getParseSSGConRspTL(String rcvBuf){ 
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[]= {105, 1};
		String strHeaders[] = {
				"DATA_FILLER",		    // (105)데이터 필러
				"MSG_END"               // (1)전문 종료 문자
			};
		
//		logger.info("▶ getParseSSGPointInqRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
//		for(int i = 0;i < nlens.length;i++ ) {
//			logger.info(">>>" + strHeaders[i] + "=" + (String)hm.get(strHeaders[i]));
//		}
		
		return hm;
	}
	
	
	public HashMap<String, String> getParseSSGConApprRspGRP(String rcvBuf){ 
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[]= {4, 2, 20, 3, 3,
				      64, 20, 64, 20, 4,
				      12, 10, 4, 1, 12,
				      12, 12, 125, 4
				 };
		String strHeaders[] = {
				"GRP_STA",              // (4)그룹 시작문자
				"GRP_TYPE",	 			// (2)그룹 타입
				"ADD_DC_CODE",          // (20)추가할인코드
				"INFO_INDEX", 	        // (3)상품 정보 순서
				"CLASS_GUBUN", 			// (3)분류 구분
				
				"CPN_NO", 				// (64)쿠폰 번호
				"PRD_ID", 				// (20)상품 아이디
				"PRD_NM", 				// (64)상품 명
				"PRD_SKU_CODE", 	  	// (20)상품 바코드
				"PRD_CNT", 	            // (4)상품 갯수
				
				"PRD_AMT", 	    		// (12)상품 액면가
				"BRD_CODE",             // (10)브랜드 코드
				"PRD_TYPE",	 	        // (4)상품 타입
				"AMT_RATE_GUBUN",       // (1)정액/정률 구분
				"TOT_TRADE_AMT",   		// (12)전체거래금액
				
				"TRADE_AMT",          	// (12)사용금액
				"REMAIN_AMT",      		// (12)남은금액
				"ARRAY_ETC_FILED",      // (125)ARRAY DATA 예비필드
				"GRP_END"               // (4)그룹 종료
			};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	//getParseSSGConApprRspTL
	public HashMap<String, String> getParseSSGConApprRspTL(String rcvBuf){ 
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[]= {8, 6, 8, 8, 26,
					  8, 8, 8, 129, 1
				 };
		String strHeaders[] = {
				"AUTH_DATE",            // (8)승인일자
				"AUTH_TIME",	 		// (6)승인시간
				"AUTH_NO",          	// (8)승인번호
				"ORG_MSG_SEND_DT", 	    // (8)원거래전문전송일자
				"ORG_MSG_TRACE_NO", 	// (26)원거래전문추적번호
				
				"ORG_SALE_DATE", 		// (8)원거래거래일자
				"ORG_AUTH_DATE", 		// (8)원거래승인일자
				"ORG_AUTH_NO", 			// (8)원거래승인번호
				"DATA_FILLER", 	  		// (129)데이터필러
				"MSG_END" 	            // (1)전문종료내역
			};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
}