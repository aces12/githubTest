package biz.cms_SSGMbsIrt;

import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;

class Teststart {

	private static Logger logger = Logger.getLogger(Teststart.class);
	static COMMLog cLog = new COMMLog();

	public static void main(String[] args)  throws Exception {
		try {
			cLog.setStartTime();
			cLog.setbizLogger(logger);

			String path          = "C:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
			System.out.println("1");
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			// DAO
			System.out.println("2");
			execute();
			
		} catch (Exception e) {
			System.out.println("[ERROR] Exception : " + e.getMessage());
		}
		
	}



	public static void execute() throws Exception {
		// TODO Auto-generated method stub
		
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		StringBuffer sb = null;
		
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		
		HashMap<String, String> hmData = new HashMap<String, String>();
		
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		
		
		Socket extClntSock = null;
		SSGMbsIrtConveyer SSGMbsConveyer = null;
		SSGPayIrtConveyer SSGPayConveyer = null;
		
		String point_server_ip = "174.100.67.174";
		//System.out.println("point_server_ip[" + point_server_ip + "]");
		int point_server_port = 64000;
		
		//System.out.println("COMMLog 생성 시작");
		COMMLog df = new COMMLog();
		//System.out.println("COMMLog 생성 완료");
		try {
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = "0003880600999000215742017061420170614210541000100235PS0614210541031c38c363f3cfe4725d6549e5163d65                                                                                                B200003371    000000000000000011000000000000000000000000000000000000001100000000000000000000000000                                                                                                                                                    ";
			//System.out.println("rcvBuf[" + rcvBuf + "]");

			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;

			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();

			
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			System.out.println("hmCommon[" + hmCommon + "]");

			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지
			// 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}
			

			System.out.println("rcvBuf[" + rcvBuf + "]");
			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			System.out.println("rcvDataBuf[" + rcvDataBuf + "]");
			inq_type = COMMBiz.getInqTypeCHG(protocol.getRcvMbsIrtDATA(rcvDataBuf));
			boolean bIsExtended = false;
			System.out.println("inq_type[" + inq_type + "]");
			
			switch(inq_type) {
				// 35: 신세계포인트 승인(적립/사용)
				case 35:
					System.out.println("Approval SSGPoint");
					if( rcvDataBuf.length() == 270 ) {
						bIsExtended = false;
						hmData = protocol.getParseSSGPointApproval(rcvDataBuf);
						sb = null;
						sb = new StringBuffer(rcvBuf);
						sb.replace(COMMBiz.CM_LENS+14, COMMBiz.CM_LENS+34, "********************");
						System.out.println("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + sb.toString() + "]");
					}else if( rcvDataBuf.length() == 378 ) {
						bIsExtended = true;
						hmData = protocol.getParseSSGPointApprovalEx(rcvDataBuf);
						System.out.println("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					}else if( rcvDataBuf.length() == 388 ) {
						bIsExtended = true;
						hmData = protocol.getParseSSGPointApprovalEx(rcvDataBuf);
						System.out.println("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					}

					System.out.println("point_server_ip[" + point_server_ip + "]");
					System.out.println("point_server_port[" + point_server_port + "]");
					extClntSock = new Socket(point_server_ip, point_server_port);
					System.out.println("extClntSock[" + extClntSock + "]");
					SSGMbsConveyer = new SSGMbsIrtConveyer(extClntSock, df);
					System.out.println("SSGMbsConveyer[" + SSGMbsConveyer + "]");
					
					dataMsg = SSGMbsConveyer.getSSGPointApproval(hmCommon, hmData, bIsExtended);
					System.out.println("dataMsg[" + dataMsg + "]");
					ret = COMMBiz.toInteger(dataMsg.substring(0,2), 99);
					dataMsg = dataMsg.substring(2);
					break;
						
				default:
				System.out.println("▶ INQ Type Code(INQ 종별 코드):   [" + inq_type + "]" + rcvBuf.length());
					ret = 99;
					break;
			}
		} catch (Exception e) {
			ret = 29; // 029=HOST APPL ERR
			retValue = "[ERROR]2:" + e.getMessage();
			System.out.println("▶ " + retValue);
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			System.out.println("dataMsg[" + dataMsg + "]");
			System.out.println("sendMsg[" + sendMsg + "]");
					
			System.out.println("================ 4-2) POS<-SMS 응답전문 ===================");
			System.out.println("전문길이=[" + totalMsg.getBytes().length + "]");
			System.out.println("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
			System.out.println("전문내용=[" + totalMsg + "]");
			
			// Send Response Data (응답 데이타 전송)
//			if (actionSocket.send(totalMsg)) {
//				System.out.println("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
//			} else {
//				System.out.println("[pos<sms] SEND[" + totalMsg.getBytes().length + "] ERROR");
//			}
		} catch (Exception e) {
			retValue = "[ERROR]4" + e.getMessage();
			System.out.println("▶ " + retValue);
		} finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("SSGMBSIRT", retValue);
			
			if (!extClntSock.isClosed()) {
				extClntSock.close();
			}
		}
	}
	
}



