package biz.cms_HJParcelTran;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_HanPaySender.HanPaySenderDAO;
import biz.cms_HanPaySender.HanPaySenderFileTransfer;
import biz.cms_SmartconSender.SmartconSenderMakeTransferMST;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.SFTPManager;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

public class HJParcelTranPollingAction_test extends PollingAction {
	private static Logger logger = Logger.getLogger(HJParcelTranPollingAction.class);
	
	private String hanjin_ftp_ip = "";
	private int hanjin_ftp_port = 0;
	private String hanjin_ftp_id = "";
	private String hanjin_ftp_pwd = "";
	
	public static void main(String args[]) throws Exception {
		HJParcelTranPollingAction_test action = new HJParcelTranPollingAction_test();
		
		try {
			/*if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));*/
			String path          = "C:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			String retMsg = "";
			action.execute("1");
			
			System.out.println("[Received Data]=" + retMsg);
		}catch(Exception e) {
			System.out.println("[Received Data]=" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		
		System.out.println("hanjin tran down start");
		SFTPManager sFtpMgr = null;
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK = false;
		String FileNm = ""; //FileNm = targetFileNm;
		
		try{
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			/*if( actionMode != "1" ) return;
			
			this.hanjin_ftp_ip = PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_IP");
			this.hanjin_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_PORT"));
			this.hanjin_ftp_id = PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_ID");
			this.hanjin_ftp_pwd = PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_PWD");
			
			try{				
				sFtpMgr = new SFTPManager(hanjin_ftp_ip, hanjin_ftp_port, hanjin_ftp_id, hanjin_ftp_pwd);	
				logger.info("TRY Connected to " + hanjin_ftp_ip + ":" + hanjin_ftp_port);
			}catch(Exception e){
				logger.info("exception occur"+e.getMessage());
				logger.info(" SFTP Connect fail exception occur ");
				return;
			}					
			logger.info(" SFTP Connection is Success ");	
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "hanjin";//"";
			
			File destDir = new File(destPath);
			
			if( !destDir.exists() ) {
				destDir.mkdir();
				logger.info("[DEBUG] Try to make dir" );
			}
			isDownOK = false;
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

			calendar.setTime(new Date());
			String stdDate = sdf.format(calendar.getTime());
			
			iRetry = 0;
			String downTargetFileNM = "HANJIN.TRAN." + stdDate;
			
			logger.info("HJParcelSenderFileTransfer ::: downTargetFileNM ::: "+downTargetFileNM);
			bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + downTargetFileNM));
	        sFtpMgr.cd(File.separator + "out"); // 경로변경
		    logger.info("HJParcelSenderFileTransfer ::: change directory succ.");
		    
		    while (iRetry < 2) {
		    	if ((isDownOK = sFtpMgr.get(downTargetFileNM, bos))) {
		          break;
		        }
		        iRetry++;
	        }
		    logger.info("HJParcelSenderFileTransfer ::: isDownOK ::: "+isDownOK);
		      
		    bos.flush();
	        bos.close();
		    bos = null;
		    System.gc(); 
		    
		    if( isDownOK ) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + downTargetFileNM + "]");
				// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
				if( sFtpMgr.rename(downTargetFileNM, downTargetFileNM.concat(".ok")) ) {
					logger.info("[DEBUG] Succeeded to rename.");
					
					File file = new File(destPath + File.separator + downTargetFileNM);
					File fileOK = new File(destPath + File.separator + downTargetFileNM.concat(".ok"));
					file.renameTo(fileOK);//다운로드 완료시 파일명에 .ok 추가
				}else {
					logger.info("[DEBUG] Failed to rename.");	
				}
			}else {
				logger.info("[ERROR4] Can't get " + downTargetFileNM + " from FTP server");
									
				File file = new File(destPath + File.separator + downTargetFileNM);
				if( !file.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + downTargetFileNM + "]");
				}				
				logger.info("[ERROR2] Can't get file on FTP server");
			}*/
		    
			String stdDate = "20170922";
			destPath = "C:/withme_com/files/down/hanjin";
		    System.out.println("HJParcelTranFileTransfer ::: HANJIN INSERT START");
		    logger.info("HJParcelTranFileTransfer ::: HANJIN INSERT START");
		    HJParcelTranInst insert = new HJParcelTranInst(destPath, stdDate);
		    insert.start();
			
		}catch(Exception e){
			if(!isDownOK)//예외 발생시 !isDownOK삭제(ACTION_TIME 다중 발생시 생성되는 0byte파일 삭제)
			{
				File file = new File(destPath + File.separator + FileNm);
				if( !file.delete() ) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm + "]");
				}				
				logger.info("[ERROR] Exception, delete file: "+FileNm);
			}
			
			logger.info("[ERROR1] " + e.getMessage());
		}finally{
			if( bos != null ) {
				try {
					bos.close();
					bos = null;
				}catch(Exception e) {}
			}
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {
			}
		}
		
		HJParcelTranDAO dao = new HJParcelTranDAO();
		List<Object> list = null;
		int totalCnt = 0;
		
	}
	
	private String makeHeaderOfFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,6,14,7,8
					  ,264};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"FILE_CRTD_YMDHMS",
			"TRANS_CNT",
			"ADJ_YMD",
			
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	private String makeDataOfHJParcelTranFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {
			2, 6, 1, 21, 1,
			1, 15, 8, 5, 4,
			4, 2, 9, 9, 9,
			9, 2, 14, 15, 10,
			30, 1 };
		String strHeaders[] = {
			"MSG_TYPE",
			"MSG_LEN",
			"DEAL_TYPE",
			"TRAN_ID",
			"ENP_DIV",
			
			"DLV_TYP",
			"WBL_NUM",
			"TRAN_YMD",
			"STORE_CD",
			"POS_NO",
			
			"TRAN_NO",
			"PAYMENT_TP",
			"TRN_FEE",
			"ETC_FEE",
			"EXT_FEE",
			
			"SAL_FEE",
			"PAY_CON",
			"RCV_DATETIME",
			"RSV_WBL",
			"CSR_NUM",
			
			"RTN_NUM",
			"RCV_TAG"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {	
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	private String makeTailerOfTranFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,6,7,286};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"TRANS_CNT",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	private byte[] makeStartOrEndReq(String pckTp, String seqNum) {
		byte[] tempBytes;
		byte[] sendBytes;
		
		// 시작전문 문자열 부분 생성
		StringBuffer sb = new StringBuffer();
		sb.append(pckTp);			// Packet구분자(1)
		sb.append(seqNum);			// 일련번호(YYYYMMDDHHMMSSS)(15)
		sb.append("1");				// 서비스번호(1)
		sb.append("  ");				// 요청응답구분(2)
		
		// 시작 전문 문자열을 바이트 배열로 변환
		tempBytes = (sb.toString()).getBytes();
		
		// 시작 전문 문자열과 종료문자를 담을 바이트 배열 생성
		sendBytes = new byte[tempBytes.length + 1];
		
		// 전송할 바이트 배열에 바이트 배열로 변환된 시작전문 문자열 부분 copy
		System.arraycopy(tempBytes, 0, sendBytes, 0, tempBytes.length);
		
		sendBytes[sendBytes.length - 1] = 0x0d;
		
		return sendBytes;
	}
}
