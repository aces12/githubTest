package biz.cms_HJParcelTran;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.apache.log4j.Logger;

import biz.comm.SFTPManager;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

public class HJParcelTranPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(HJParcelTranPollingAction.class);
	
	private String hanjin_ftp_ip = "";
	private int hanjin_ftp_port = 0;
	private String hanjin_ftp_id = "";
	private String hanjin_ftp_pwd = "";
	
	public static void main(String args[]) throws Exception {
		HJParcelTranPollingAction action = new HJParcelTranPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			//String path          = "C:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			String retMsg = "";
			action.execute("1");
			
			System.out.println("[Received Data]=" + retMsg);
		}catch(Exception e) {
			System.out.println("[Received Data]=" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		
		System.out.println("hanjin tran down start");
		SFTPManager sFtpMgr = null;
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK = false;
		String FileNm = ""; //FileNm = targetFileNm;
		
		try{
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode != "1" ) return;
			
			this.hanjin_ftp_ip = PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_IP");
			this.hanjin_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_PORT"));
			this.hanjin_ftp_id = PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_ID");
			this.hanjin_ftp_pwd = PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_PWD");
			
			logger.info("[INFO] Trying HANJIN SFTP Connection...");
			
			try{				
				sFtpMgr = new SFTPManager(hanjin_ftp_ip, hanjin_ftp_port, hanjin_ftp_id, hanjin_ftp_pwd);	
				logger.info("[INFO] TRY Connected to " + hanjin_ftp_ip + ":" + hanjin_ftp_port);
			}catch(Exception e){
				logger.info("[INFO] exception occur"+e.getMessage());
				logger.info("[INFO] SFTP Connect fail exception occur ");
				return;
			}					
			logger.info("[INFO] SFTP Connection is Success ");	
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "hanjin";//"";
			
			File destDir = new File(destPath);
			
			if( !destDir.exists() ) {
				destDir.mkdir();
				logger.info("[DEBUG] Try to make dir" );
			}
			isDownOK = false;
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			String stdDate = sdf.format(calendar.getTime());
			
			iRetry = 0;
			String downTargetFileNM = "HANJIN.TRAN." + stdDate;
			FileNm = downTargetFileNM;
			
			logger.info("HJParcelSenderFileTransfer ::: downTargetFileNM ::: "+downTargetFileNM);
			bos = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + downTargetFileNM));
			
	        sFtpMgr.cd(".." + File.separator + "out"); // 경로변경
		    logger.info("HJParcelSenderFileTransfer ::: change directory succ.");
		    
		    while (iRetry < 2) {
		    	logger.info("HJParcelSenderFileTransfer ::: iRetry ::: "+iRetry);
		    	if ((isDownOK = sFtpMgr.get(downTargetFileNM, bos))) {
		    		logger.info("HJParcelSenderFileTransfer ::: success ::: ");
		          break;
		        }
		        iRetry++;
	        }
		    logger.info("HJParcelSenderFileTransfer ::: isDownOK ::: "+isDownOK);
		      
		    bos.flush();
	        bos.close();
		    bos = null;
		    System.gc(); 
		    
		    if( isDownOK ) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + downTargetFileNM + "]");
				// 다운 받은 파일은 삭제한다.
				
				//if( sFtpMgr.rename(downTargetFileNM, downTargetFileNM.concat(".ok")) ) {
				if( sFtpMgr.rm(downTargetFileNM) ) {
					logger.info("[DEBUG] Succeeded remove file.");
					
					File file = new File(destPath + File.separator + downTargetFileNM);
					File fileOK = new File(destPath + File.separator + downTargetFileNM.concat(".ok"));
					file.renameTo(fileOK);//다운로드 완료시 파일명에 .ok 추가
				}else {
					logger.info("[DEBUG] Failed to remove.");
				}
			}else {
				logger.info("[ERROR4] Can't get " + downTargetFileNM + " from FTP server");
									
				File file = new File(destPath + File.separator + downTargetFileNM);
				if( !file.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + downTargetFileNM + "]");
				}				
				logger.info("[ERROR2] Can't get file on FTP server");
			}
		    
		    System.out.println("HJParcelTranFileTransfer ::: HANJIN INSERT START");
		    logger.info("HJParcelTranFileTransfer ::: HANJIN INSERT START");
		    HJParcelTranInst insert = new HJParcelTranInst(destPath, stdDate);
		    insert.start();
			
		}catch(Exception e){
			if(!isDownOK)//예외 발생시 !isDownOK삭제(ACTION_TIME 다중 발생시 생성되는 0byte파일 삭제)
			{
				File file = new File(destPath + File.separator + FileNm);
				if( !file.delete() ) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm + "]");
				}				
				logger.info("[ERROR] Exception, delete file: "+FileNm);
			}
			
			logger.info("[ERROR1] " + e.getMessage());
		}finally{
			if( bos != null ) {
				try {
					bos.close();
					bos = null;
				}catch(Exception e) {}
			}
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {
			}
		}
	}
}
