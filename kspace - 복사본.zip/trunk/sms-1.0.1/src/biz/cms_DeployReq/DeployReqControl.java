package biz.cms_DeployReq;

import biz.cms_DeployReq.DeployReqClientAction;

public class DeployReqControl {
	
	public synchronized void useThread() throws InterruptedException {
		//System.out.println( "lend :" + MasterCrtClientAction.getJobThread());
		if (DeployReqClientAction.getJobThread() == 0) {
			//System.out.println(t.getName() + ": wating...");
			this.wait();
			//System.out.println(t.getName() + ": return...");
		}
		DeployReqClientAction.decrement();
	}
	
	public synchronized void returnThread() {
		DeployReqClientAction.increment();
		this.notify();
	}
}
