/*
 * DeployDAO.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */

package biz.cms_DeployReq;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

/** 
 * DeployDAO
 * A class that has inherited GenericDAO(GenericDAO를 상속받은 클래스)
 * It is responsible for functions to access DB to retrieve respective information(DB에 접속하여 해당 정보를 조회해 오거나)
 * or update DB information(DB정보를 업데이트 하는 기능을 담당한다).
 * @created  on 1.0,  11/03/17
 * @created  by khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */ 
public class DeployReqDAO extends GenericDAO{	
	private static Logger logger = Logger.getLogger(DeployReqDAO.class);
	
	/**
     * selSTBDA100AT - Search stores to be deployed(배신할 점포 조회)
     * @return List Stores to be subject to deployment(배신 대상 점포)
     */
	public List selSTBDA100AT(String transYmd, String comcd, String store, String id) {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_STBDA100AT2"));
			sql.setString(++i, transYmd);
			sql.setString(++i, comcd);
			sql.setString(++i, store);
			sql.setString(++i, id);
			System.out.println(findQuery("stsys-sql", "SEL_STBDA100AT2"));
			list = executeQuery(sql);
			
		} catch (Exception e) {
			logger.info("[ERROR]"+e);
		} 
		
		return list;
	}
	
    /**
     * updSTBDA100AT - No. of deployment status values after deployment(배신 후 배신상태값 수정)
     * @param map 
     * @return int update된 데이터 rowcount
     * @exception exception 
     */
	public int updSTBDA100AT(Map map) {
		SqlWrapper sql = new SqlWrapper();
		int i=0;
		int rows=-1;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA100AT_0));
			sql.setString(++i, (String)map.get("oper_id"));
			sql.setString(++i, (String)map.get("trans_ymd"));
			sql.setString(++i, (String)map.get("com_cd"));
			sql.setString(++i, (String)map.get("store_cd"));
			sql.setString(++i, (String)map.get("pos_no"));
			sql.setString(++i, (String)map.get("trans_id"));
			sql.setString(++i, (String)map.get("trans_seq"));
			rows = executeUpdate(sql);
		} catch (Exception e) {
			rollback();
			logger.info("[ERROR]"+e);
		} finally {
			end();
		}
		
		return rows;
	}
	
    /**
     * selDeployMSG - Search messages to be deployed(배신할 메시지 조회)
     * @param map 
     * @return List 
     */
	public List selDeployMSG(Map map) {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_DEPLOYMSG"));
			sql.setString(++i, (String)map.get("send_id"));
			sql.setString(++i, (String)map.get("msg_cd"));
			list = executeQuery(sql);
		} catch (Exception e) {
			logger.info("[ERROR]"+e);
		} 
		
		return list;
	}
}
