/*
 * SysInqDAO.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_MbsIrt;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;

import biz.comm.COMMLog;

/**
 * SysInqDAO
 * A class that has inherited GenericDAO(GenericDAO를 상속받은 클래스)
 * It is responsible for functions to access DB to retrieve respective information(DB에 접속하여 해당 정보를 조회해 오거나)
 * or update DB information(DB정보를 업데이트 하는 기능을 담당한다).
 * @created on 1.0, 11/03/17
 * @created by oki(FUJITSU KOREA LTD.)
 * 
 * @modified on
 * @modified by
 * @caused by
 */
public class MbsIrtDAO extends GenericDAO {

	/***************************************************************************
	 * getMbsNewCustNo : Result of Deployment Order Check Reflection(신규고객번호)
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return datamsg
	 * @throws Exception
	 */
	public String getMbsNewCustNo(HashMap hmComm, HashMap hm, COMMLog df) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String res_cd = "00";
		// DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

			//df.CommLogger("tran_ymd:"   + (String)hm.get("tran_ymd"));
			df.CommLogger("tran_ymd:"   + (String)hmComm.get("TRAN_YMD"));

			System.out.println("[DEBUG] [SP_MBSIRT_INQ_CUSTNO_NEW] Begin");
			proc.put("POS.dbo.SP_MBSIRT_INQ_CUSTNO_NEW", 6);
			proc.setString(++i, (String)hmComm.get("COM_CD"));		// COM_CD
			proc.setString(++i, (String)hmComm.get("TRAN_YMD"));	// TRAN_YMD
			proc.setString(++i, (String)hmComm.get("STORE_CD"));	// STORE_CD
			//proc.setString(++i, tranYmd);	// tran_ymd
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// CUST_NO
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			if (prs.getInt(5) != 0) {
				res_cd = "99";
				String retMsg = prs.getString(6);
				df.CommLogger("[DEBUG] [SP_MBSIRT_INQ_CUSTNO_NEW] Error: "+ retMsg);
				System.out.println("[DEBUG] [SP_MBSIRT_INQ_CUSTNO_NEW] Error: "+ retMsg);
			}
				
			hm.put("INQ_TYPE", "13");
			hm.put("CUST_NO",  prs.getString(4));
			hm.put("RES_CD",   res_cd);
			hm.put("ERROR_MSG", prs.getString(6));

			commit();
		} catch(SQLException e){ 	
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		} catch (Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();	
			throw e;
		} finally {
			dataMsg = ret + makeSendDataNewCustNo(hm, df);
			df.CommLogger("★ make: " + dataMsg);
		}

		return dataMsg;
	}

	/***************************************************************************
	 * makeSendDataNewCustNo : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @param df
	 * @return 전송메세지
	 */
	private String makeSendDataNewCustNo(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2,20,2,120};
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별 : 13)    
				"CUST_NO"			, // Cust No(고객번호) 
				"RES_CD"			, // Response Code(응답코드) 
				"ERROR_MSG"			  // Error Message(에러메시지)
			};

		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}


	/***************************************************************************
	 * getMbsRegCust : Result of Deployment Order Check Reflection(신규고객등록)
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return datamsg
	 * @throws Exception
	 */
	public String getMbsRegCust(HashMap hmComm, HashMap hm, COMMLog df) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String res_cd = "00";
		// DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

//			String cust_nm = (String)hm.get("CUST_NM");
//			byte[] bytes = cust_nm.getBytes("Unicode");
//
//			String str1 = new String(bytes, "Unicode");
//			df.CommLogger("CUST_NM(encoding: Unicode)"   + str1);
//			String str2 = new String(bytes, "MS949");
//			df.CommLogger("CUST_NM(encoding: MS949)"   + str2);
//			String str3 = new String(bytes, "UTF-8");
//			df.CommLogger("CUST_NM(encoding: UTF-8)"   + str3);
//			String str4 = new String(bytes, "UTF-16LE");
//			df.CommLogger("CUST_NM(encoding: UTF-16LE)"   + str4);
//			String str5 = new String(bytes, "UTF-16BE");
//			df.CommLogger("CUST_NM(encoding: UTF-16BE)"   + str5);
//			String str6 = new String(bytes, "UnicodeLittle");
//			df.CommLogger("CUST_NM(encoding: UnicodeLittle)"   + str6);
//			String str7 = new String(bytes, "EUC-KR");
//			df.CommLogger("CUST_NM(encoding: EUC-KR)"   + str7);
//			String str8 = new String(bytes, "8859_1");
//			df.CommLogger("CUST_NM(encoding: 8859_1)"   + str8);
//			String str9 = new String(bytes, "GB2312");
//			df.CommLogger("CUST_NM(encoding: GB2312)"   + str9);
//			String str10 = new String(bytes, "ISO-2022-CN");
//			df.CommLogger("CUST_NM(encoding: ISO-2022-CN)"   + str10);
//			String str11 = new String(bytes, "MS936");
//			df.CommLogger("CUST_NM(encoding: MS936)"   + str11);
//			String str12 = new String(bytes, "GB18030");
//			df.CommLogger("CUST_NM(encoding: GB18030)"   + str12);
//			String str13 = new String(bytes, "EUC_CN");
//			df.CommLogger("CUST_NM(encoding: EUC_CN)"   + str13);
//			String str14 = new String(bytes, "GBK");
//			df.CommLogger("CUST_NM(encoding: GBK)"   + str14);
//			
//			String strEncode = new String(bytes, "UTF-16LE");
//			df.CommLogger("##CUST_NM(encoding: UTF-16LE)"   + strEncode);

			//df.CommLogger("tran_ymd:"   + (String)hm.get("tran_ymd"));
			df.CommLogger("tran_ymd:"   + (String)hmComm.get("TRAN_YMD"));
			df.CommLogger("input01:"   + (String)hmComm.get("TRAN_YMD"));
			df.CommLogger("input02:"   + (String)hmComm.get("SYS_HMS"));
			df.CommLogger("input03:"   + (String)hmComm.get("COM_CD"));
			df.CommLogger("input04:"   + (String)hmComm.get("STORE_CD"));
			df.CommLogger("input05:"   + (String)hmComm.get("POS_NO"));
			df.CommLogger("input06:"   + (String)hm.get("CUST_NO"));
			df.CommLogger("input07:"   + (String)hm.get("CUST_NM"));
			df.CommLogger("input08:"   + (String)hm.get("CUST_CARD_NO"));
			df.CommLogger("input09:"   + (String)hm.get("TEL_NO"));
			df.CommLogger("input10:"   + (String)hm.get("BIRTH_DAY"));
			df.CommLogger("input11:"   + (String)hm.get("MARRY_DAY"));
			
			System.out.println("[DEBUG] [SP_MBSIRT_INQ_CUSTREG] Begin");
			proc.put("POS.dbo.SP_MBSIRT_INQ_CUSTREG", 13);
			proc.setString(++i, (String)hmComm.get("TRAN_YMD"));	// TRAN_YMD
			proc.setString(++i, (String)hmComm.get("SYS_HMS"));		// SYS_HMS
			proc.setString(++i, (String)hmComm.get("COM_CD"));		// COM_CD
			proc.setString(++i, (String)hmComm.get("STORE_CD"));	// STORE_CD
			proc.setString(++i, (String)hmComm.get("POS_NO"));		// POS_NO
			proc.setString(++i, (String)hm.get("CUST_NO"));			// CUST_NO
			proc.setString(++i, (String)hm.get("CUST_NM"));			// CUST_NM
			//proc.setString(++i, strConv);			// CUST_NM
			//proc.setString(++i, strEncode);			// CUST_NM
			proc.setString(++i, (String)hm.get("CUST_CARD_NO"));	// CUST_CARD_NO
			proc.setString(++i, (String)hm.get("TEL_NO"));			// TEL_NO
			proc.setString(++i, (String)hm.get("BIRTH_DAY"));		// BIRTH_DAY
			proc.setString(++i, (String)hm.get("MARRY_DAY"));		// MARRY_DAY
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			if (prs.getInt(12) != 0) {
				res_cd = "99";
				String retMsg = prs.getString(13);
				df.CommLogger("[DEBUG] [SP_MBSIRT_INQ_CUSTREG] Error: "+ retMsg);
				System.out.println("[DEBUG] [SP_MBSIRT_INQ_CUSTREG] Error: "+ retMsg);
			}
				
			hm.put("INQ_TYPE", "15");
			hm.put("RES_CD",   res_cd);
			hm.put("ERROR_MSG", prs.getString(13));

			commit();
		} catch(SQLException e){ 	
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		} catch (Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();	
			throw e;
		} finally {
			dataMsg = ret + makeSendDataRegCust(hm, df);
			df.CommLogger("★ make: " + dataMsg);
			end();
		}

		return dataMsg;
	}


	/***************************************************************************
	 * makeSendDataRegCust : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @param df
	 * @return 전송메세지
	 */
	private String makeSendDataRegCust(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2,2,120};
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별 : 15)    
				"RES_CD"			, // Response Code(응답코드) 
				"ERROR_MSG"			  // Error Message(에러메시지)
			};

		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}


	/***************************************************************************
	 * getMbsDropCust : Result of Deployment Order Check Reflection(고객탈퇴)
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return datamsg
	 * @throws Exception
	 */
	public String getMbsDropCust(HashMap hmComm, HashMap hm, COMMLog df) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String res_cd = "00";
		// DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

			//df.CommLogger("tran_ymd:"   + (String)hm.get("tran_ymd"));
			df.CommLogger("tran_ymd:"   + (String)hmComm.get("TRAN_YMD"));
			
			System.out.println("[DEBUG] [SP_MBSIRT_INQ_CUSTDROP] Begin");
			proc.put("POS.dbo.SP_MBSIRT_INQ_CUSTDROP", 10);
			proc.setString(++i, (String)hmComm.get("TRAN_YMD"));	// TRAN_YMD
			proc.setString(++i, (String)hmComm.get("SYS_HMS"));		// SYS_HMS
			proc.setString(++i, (String)hmComm.get("COM_CD"));		// COM_CD
			proc.setString(++i, (String)hmComm.get("STORE_CD"));	// STORE_CD
			proc.setString(++i, (String)hmComm.get("POS_NO"));		// POS_NO
			proc.setString(++i, (String)hm.get("CUST_CARD_NO"));	// CUST_CARD_NO
			proc.setString(++i, (String)hm.get("SECEDE_DT"));		// SECEDE_DT
			proc.setString(++i, (String)hm.get("SECEDE_REASON"));	// SECEDE_REASON
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			if (prs.getInt(9) != 0) {
				res_cd = "99";
				String retMsg = prs.getString(10);
				df.CommLogger("[DEBUG] [SP_MBSIRT_INQ_CUSTDROP] Error: "+ retMsg);
				System.out.println("[DEBUG] [SP_MBSIRT_INQ_CUSTDROP] Error: "+ retMsg);
			}
				
			hm.put("INQ_TYPE", "17");
			hm.put("RES_CD",   res_cd);
			hm.put("ERROR_MSG", prs.getString(10));

			commit();
		} catch(SQLException e){ 	
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		} catch (Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();	
			throw e;
		} finally {
			dataMsg = ret + makeSendDataDropCust(hm, df);
			df.CommLogger("★ make: " + dataMsg);
		}

		return dataMsg;
	}

	/***************************************************************************
	 * makeSendDataDropCust : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @param df
	 * @return 전송메세지
	 */
	private String makeSendDataDropCust(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2,2,120};
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별 : 17)    
				"RES_CD"			, // Response Code(응답코드) 
				"ERROR_MSG"			  // Error Message(에러메시지)
			};

		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}


	/***************************************************************************
	 * getMbsRegCard : Result of Deployment Order Check Reflection(고객카드등록)
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return datamsg
	 * @throws Exception
	 */
	public String getMbsRegCard(HashMap hmComm, HashMap hm, COMMLog df) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String res_cd = "00";
		// DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

			//df.CommLogger("tran_ymd:"   + (String)hm.get("tran_ymd"));
			df.CommLogger("tran_ymd:"   + (String)hmComm.get("TRAN_YMD"));
			
			System.out.println("[DEBUG] [SP_MBSIRT_INQ_CARDREG] Begin");
			proc.put("POS.dbo.SP_MBSIRT_INQ_CARDREG", 11);
			proc.setString(++i, (String)hmComm.get("TRAN_YMD"));	// TRAN_YMD
			proc.setString(++i, (String)hmComm.get("SYS_HMS"));		// SYS_HMS
			proc.setString(++i, (String)hmComm.get("COM_CD"));		// COM_CD
			proc.setString(++i, (String)hmComm.get("STORE_CD"));	// STORE_CD
			proc.setString(++i, (String)hmComm.get("POS_NO"));		// POS_NO
			proc.setString(++i, (String)hm.get("CUST_NO"));		// CUST_NO
			proc.setString(++i, (String)hm.get("CUST_CARD_NO"));	// CUST_CARD_NO
			proc.setString(++i, (String)hm.get("NEW_CUST_CARD_NO"));	// NEW_CUST_CARD_NO
			proc.setString(++i, (String)hm.get("PROC_FLAG"));		// PROC_FLAG
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			if (prs.getInt(10) != 0) {
				res_cd = "99";
				String retMsg = prs.getString(11);
				df.CommLogger("[DEBUG] [SP_MBSIRT_INQ_CARDREG] Error: "+ retMsg);
				System.out.println("[DEBUG] [SP_MBSIRT_INQ_CARDREG] Error: "+ retMsg);
			}
				
			hm.put("INQ_TYPE", "19");
			hm.put("RES_CD",   res_cd);
			hm.put("ERROR_MSG", prs.getString(11));

			commit();
		} catch(SQLException e){ 	
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		} catch (Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();	
			throw e;
		} finally {
			dataMsg = ret + makeSendDataRegCard(hm, df);
			df.CommLogger("★ make: " + dataMsg);
		}

		return dataMsg;
	}

	/***************************************************************************
	 * makeSendDataRegCard : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @param df
	 * @return 전송메세지
	 */
	private String makeSendDataRegCard(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2,2,120};
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별 : 19)    
				"RES_CD"			, // Response Code(응답코드) 
				"ERROR_MSG"			  // Error Message(에러메시지)
			};

		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}


	/***************************************************************************
	 * getMbsInqCust : Result of Deployment Order Check Reflection(고객카드등록)
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return datamsg
	 * @throws Exception
	 */
	public String getMbsInqCust(HashMap hmComm, HashMap hm, COMMLog df) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String res_cd = "00";
		// DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

			//df.CommLogger("tran_ymd:"   + (String)hm.get("tran_ymd"));
			df.CommLogger("tran_ymd:"   + (String)hmComm.get("TRAN_YMD"));
			df.CommLogger("inq_value:"   + (String)hm.get("INQ_VALUE"));
			
			System.out.println("[DEBUG] [SP_MBSIRT_INQ_CUST] Begin");
			proc.put("POS.dbo.SP_MBSIRT_INQ_CUST", 12);
			proc.setString(++i, (String)hmComm.get("TRAN_YMD"));	// TRAN_YMD
			proc.setString(++i, (String)hmComm.get("SYS_HMS"));		// SYS_HMS
			proc.setString(++i, (String)hmComm.get("COM_CD"));		// COM_CD
			proc.setString(++i, (String)hmComm.get("STORE_CD"));	// STORE_CD
			proc.setString(++i, (String)hmComm.get("POS_NO"));		// POS_NO
			proc.setString(++i, (String)hm.get("INQ_FLAG"));		// INQ_FLAG
			proc.setString(++i, (String)hm.get("INQ_VALUE"));		// INQ_VALUE
			proc.setString(++i, (String)hm.get("CUST_CARD_INQ_FALG"));	// CUST_CARD_INQ_FALG
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// INQ_COUNT
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// INQ_RESULT
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			if (prs.getInt(11) != 0) {
				res_cd = "99";
				String retMsg = prs.getString(12);
				df.CommLogger("[DEBUG] [SP_MBSIRT_INQ_CUST] Error: "+ retMsg);
				System.out.println("[DEBUG] [SP_MBSIRT_INQ_CUST] Error: "+ retMsg);
			}
				
			hm.put("INQ_TYPE", "21");
			hm.put("RES_CD",   res_cd);
			hm.put("ERROR_MSG", prs.getString(12));
			hm.put("INQ_COUNT", StringUtil.lPad(String.valueOf(prs.getInt(9)),4,"0"));
			hm.put("INQ_RESULT", prs.getString(10));

			commit();
		} catch(SQLException e){ 	
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		} catch (Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();	
			throw e;
		} finally {
			dataMsg = ret + makeSendDataInqCust(hm, df);
			df.CommLogger("★ make: " + dataMsg);
		}

		return dataMsg;
	}

	/***************************************************************************
	 * makeSendDataInqCust : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @param df
	 * @return 전송메세지
	 */
	private String makeSendDataInqCust(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2,2,120,4};
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별 : 21)    
				"RES_CD"			, // Response Code(응답코드) 
				"ERROR_MSG"			, // Error Message(에러메시지)
				"INQ_COUNT"		 	  // Inq Count(조회건수)
			};

		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		if ((String) hm.get("INQ_COUNT") != "0000") {
			// Inq Result(조회결과데이터)
			StringUtil.appendSpace(sb, (String) hm.get("INQ_RESULT"), 0);
		}

		return sb.toString();
	}


	/***************************************************************************
	 * getMbsInqCustInfo : Result of Deployment Order Check Reflection(고객카드등록)
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return datamsg
	 * @throws Exception
	 */
	public String getMbsInqCustInfo(HashMap hmComm, HashMap hm, COMMLog df) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String res_cd = "00";
		// DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

			//df.CommLogger("tran_ymd:"   + (String)hm.get("tran_ymd"));
			df.CommLogger("tran_ymd:"   + (String)hmComm.get("TRAN_YMD"));
			
			System.out.println("[DEBUG] [SP_MBSIRT_INQ_CUSTINFO] Begin");
			proc.put("POS.dbo.SP_MBSIRT_INQ_CUSTINFO", 9);
			proc.setString(++i, (String)hmComm.get("TRAN_YMD"));	// TRAN_YMD
			proc.setString(++i, (String)hmComm.get("SYS_HMS"));		// SYS_HMS
			proc.setString(++i, (String)hmComm.get("COM_CD"));		// COM_CD
			proc.setString(++i, (String)hmComm.get("STORE_CD"));	// STORE_CD
			proc.setString(++i, (String)hmComm.get("POS_NO"));		// POS_NO
			proc.setString(++i, (String)hm.get("CUST_CARD_NO"));	// CUST_CARD_NO
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// INQ_RESULT
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			if (prs.getInt(8) != 0) {
				res_cd = "99";
				String retMsg = prs.getString(9);
				df.CommLogger("[DEBUG] [SP_MBSIRT_INQ_CUSTINFO] Error: "+ retMsg);
				System.out.println("[DEBUG] [SP_MBSIRT_INQ_CUSTINFO] Error: "+ retMsg);
			}
				
			hm.put("INQ_TYPE", "23");
			hm.put("RES_CD",   res_cd);
			hm.put("ERROR_MSG", prs.getString(9));
			hm.put("INQ_RESULT", prs.getString(7));

			commit();
		} catch(SQLException e){ 	
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		} catch (Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();	
			throw e;
		} finally {
			dataMsg = ret + makeSendDataInqCustInfo(hm, df);
			df.CommLogger("★ make: " + dataMsg);
		}

		return dataMsg;
	}

	/***************************************************************************
	 * makeSendDataInqCustInfo : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @param df
	 * @return 전송메세지
	 */
	private String makeSendDataInqCustInfo(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2,315,2,120};
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별 : 23)    
				"INQ_RESULT"	 	, // Inq Result(조회결과)
				"RES_CD"			, // Response Code(응답코드) 
				"ERROR_MSG"			  // Error Message(에러메시지)
			};

		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}


	/***************************************************************************
	 * getMbsInqPoint : Result of Deployment Order Check Reflection(고객카드등록)
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return datamsg
	 * @throws Exception
	 */
	public String getMbsInqPoint(HashMap hmComm, HashMap hm, COMMLog df) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String res_cd = "00";
		// DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

			//df.CommLogger("tran_ymd:"   + (String)hm.get("tran_ymd"));
			df.CommLogger("tran_ymd:"   + (String)hmComm.get("TRAN_YMD"));
			
			System.out.println("[DEBUG] [SP_MBSIRT_INQ_POINT] Begin");
			proc.put("POS.dbo.SP_MBSIRT_INQ_POINT", 9);
			proc.setString(++i, (String)hmComm.get("TRAN_YMD"));	// TRAN_YMD
			proc.setString(++i, (String)hmComm.get("SYS_HMS"));		// SYS_HMS
			proc.setString(++i, (String)hmComm.get("COM_CD"));		// COM_CD
			proc.setString(++i, (String)hmComm.get("STORE_CD"));	// STORE_CD
			proc.setString(++i, (String)hmComm.get("POS_NO"));		// POS_NO
			proc.setString(++i, (String)hm.get("CUST_CARD_NO"));	// CUST_CARD_NO
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// INQ_RESULT
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			if (prs.getInt(8) != 0) {
				res_cd = "99";
				String retMsg = prs.getString(9);
				df.CommLogger("[DEBUG] [SP_MBSIRT_INQ_POINT] Error: "+ retMsg);
				System.out.println("[DEBUG] [SP_MBSIRT_INQ_POINT] Error: "+ retMsg);
			}
				
			hm.put("INQ_TYPE", "25");
			hm.put("RES_CD",   res_cd);
			hm.put("ERROR_MSG", prs.getString(9));
			hm.put("INQ_RESULT", prs.getString(7));

			commit();
		} catch(SQLException e){ 	
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		} catch (Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();	
			throw e;
		} finally {
			dataMsg = ret + makeSendDataInqPoint(hm, df);
			df.CommLogger("★ make: " + dataMsg);
		}

		return dataMsg;
	}

	/***************************************************************************
	 * makeSendDataInqPoint : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @param df
	 * @return 전송메세지
	 */
	private String makeSendDataInqPoint(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2,182,2,120};
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별 : 25)    
				"INQ_RESULT"	 	, // Inq Result(조회결과)
				"RES_CD"			, // Response Code(응답코드) 
				"ERROR_MSG"			  // Error Message(에러메시지)
			};

		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}


	/***************************************************************************
	 * getMbsInqPointUsed : Result of Deployment Order Check Reflection(고객카드등록)
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return datamsg
	 * @throws Exception
	 */
	public String getMbsInqPointUsed(HashMap hmComm, HashMap hm, COMMLog df) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String res_cd = "00";
		// DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

			//df.CommLogger("tran_ymd:"   + (String)hm.get("tran_ymd"));
			df.CommLogger("tran_ymd:"   + (String)hmComm.get("TRAN_YMD"));
			
			System.out.println("[DEBUG] [SP_MBSIRT_INQ_POINTUSE] Begin");
			proc.put("POS.dbo.SP_MBSIRT_INQ_POINTUSE", 12);
			proc.setString(++i, (String)hmComm.get("TRAN_YMD"));	// TRAN_YMD
			proc.setString(++i, (String)hmComm.get("SYS_HMS"));		// SYS_HMS
			proc.setString(++i, (String)hmComm.get("COM_CD"));		// COM_CD
			proc.setString(++i, (String)hmComm.get("STORE_CD"));	// STORE_CD
			proc.setString(++i, (String)hmComm.get("POS_NO"));		// POS_NO
			proc.setString(++i, (String)hm.get("TRAN_NO"));		// TRAN_NO
			proc.setString(++i, (String)hm.get("CUST_CARD_NO"));	// CUST_CARD_NO
			proc.setString(++i, (String)hm.get("USE_FLAG"));		// USE_FLAG
			proc.setString(++i, (String)hm.get("USE_POINT"));		// USE_POINT
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// INQ_RESULT
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			if (prs.getInt(11) != 0) {
				res_cd = "99";
				String retMsg = prs.getString(12);
				df.CommLogger("[DEBUG] [SP_MBSIRT_INQ_POINTUSE] Error: "+ retMsg);
				System.out.println("[DEBUG] [SP_MBSIRT_INQ_POINTUSE] Error: "+ retMsg);
			}
				
			hm.put("INQ_TYPE", "27");
			hm.put("RES_CD",   res_cd);
			hm.put("ERROR_MSG", prs.getString(12));
			hm.put("INQ_RESULT", prs.getString(10));

			commit();
		} catch(SQLException e){ 	
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		} catch (Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();	
			throw e;
		} finally {
			dataMsg = ret + makeSendDataInqPointUsed(hm, df);
			df.CommLogger("★ make: " + dataMsg);
		}

		return dataMsg;
	}

	/***************************************************************************
	 * makeSendDataInqPointUsed : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @param df
	 * @return 전송메세지
	 */
	private String makeSendDataInqPointUsed(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2,66,2,120};
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별 : 27)    
				"INQ_RESULT"	 	, // Inq Result(조회결과)
				"RES_CD"			, // Response Code(응답코드) 
				"ERROR_MSG"			  // Error Message(에러메시지)
			};

		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

}
