package biz.cms_StaffDCIrt;

import java.net.Socket;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;

public class StaffDCIrtAction extends ServerAction {
	private String server_ip = "";
	private int server_port = 0;
	private static Logger logger = Logger.getLogger(StaffDCIrtAction.class);
	
	public void execute(ActionSocket actionSocket) throws Exception {
		logger.info( "check actionSocket" );
		
		int ret = 0;
		int inq_type = 0;
		
		String sendMsg = ""; 
		String dataMsg = ""; 
		String totalRcvBuf = ""; 
		String rcvDataBuf = ""; 
		String retValue = "OK!"; 
		HashMap<String, String> hmCommon = new HashMap<String, String>(); 
		HashMap<String, String> hmData = new HashMap<String, String>();
		HashMap<String, String> hmStaffInfo = new HashMap<String, String>();
		StaffDCIrtProtocol StaffDCIrtProtocol = new StaffDCIrtProtocol(); 
		StaffDCIrtDAO dao = new StaffDCIrtDAO();
		StaffDCIrtConveyer conveyer = null;
		
		COMMLog df = new COMMLog(); //로그
		
		try{
			totalRcvBuf = ((String) actionSocket.receive());
			logger.info("totalRcvBuf :"+ totalRcvBuf);
			
			if( totalRcvBuf.length() < COMMBiz.CM_LENS + 2 ) return; //길이 검증
			
			df.setStartTime();
			
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,	"STAFFDC");
			
			hmCommon = COMMBiz.getData(totalRcvBuf, COMMBiz.CM_HEADER);
			logger.info("hmCommon :"+hmCommon);
						
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) { 
				return;
			}
			
			rcvDataBuf = totalRcvBuf.substring(COMMBiz.CM_LENS); 
			logger.info("rcvDataBuf :"+rcvDataBuf);
			
			inq_type = StaffDCIrtProtocol.getStaffDCIrtInq(rcvDataBuf);
			
			
			switch(inq_type) {// 조회/승인요청(B0), 취소(B1)
			case 2094: // 조회/승인 2094="BO".hashCode() 
				logger.info("check case B0");
				
				Socket extClntSock = null;
				this.server_ip = PropertyUtil.findProperty("communication-property", "STAFFCHK_COMM_IP");
				this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "STAFFCHK_COMM_PORT"));

				extClntSock = new Socket(server_ip, server_port);	
				conveyer = new StaffDCIrtConveyer(extClntSock, df);
//				logger.info("server_ip : "+server_ip+" / server_port : "+server_port);
				
				hmData = StaffDCIrtProtocol.getStaffDCReq(rcvDataBuf);
//				logger.info("hmData : "+hmData);
				
				hmStaffInfo = conveyer.StaffDCIrtConveyer(hmData);//사원인증정보
//				logger.info("hmStaffInfo : "+hmStaffInfo);
		
				dataMsg = dao.getStaffDCReq(hmCommon, hmData, hmStaffInfo,  df);	
				
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				
				break;

				
			case 2095: // 취소 2095="B1".hashCode()
				logger.info("check case B1");
				hmData = StaffDCIrtProtocol.getStaffDCReq(rcvDataBuf);
				
				dataMsg = dao.getStaffDCRetr(hmCommon, hmData, df);
				
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				
				break;
				}
		}
		catch(Exception e) {
			ret = 29;
			retValue = "[ERROR]2:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {}
		
		try{// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			logger.info("sendMsg [" + sendMsg + "]");
			String totalMsg = sendMsg + dataMsg;
			df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + totalMsg + "]");
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(totalMsg)) {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		}catch(Exception e) {
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("StaffDCIrt", retValue);
		}
		
	}
}
