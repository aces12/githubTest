package biz.cms_StaffDCIrt;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class StaffDCIrtDAO extends GenericDAO{
	private static Logger logger = Logger.getLogger(StaffDCIrtAction.class);
	StaffDCIrtProtocol StaffDCIrtProtocol = new StaffDCIrtProtocol(); 
	
	public String getStaffDCReq(HashMap<String, String> hmComm, HashMap<String, String> hm, HashMap<String, String> hmStaff, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();			
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
		int rows = -1;	
		
		String dataMsg = "";		
		String ret = "00";
		
		try {
			
			// 사원이 아닐 경우 SKIP
//			logger.info("(String)hmStaff.get(RETURN_CD)[" + (String)hmStaff.get("RETURN_CD") + "] ");
			if("0000".equals((String)hmStaff.get("RETURN_CD"))){
			
				// DB Connection(DB 접속)
				connect("CMGNS");
				
				begin();
	
				sql.put(findQuery("service-sql", "SEL_STAFF_DISCOUNT_INFO"));
				sql.setString(++i, "1002");   // 회사코드
				sql.setString(++i, (String)hmStaff.get("COMP_CD"));      // 소속사 코드
				sql.setString(++i, (String)hmStaff.get("EMPLOYEE_ID"));  // 사번
				
				// (당일)임직원 할인 유무 확인
				logger.info("sql.debug()[" + sql.debug() + "] ");
				list = executeQuery(sql);
//				logger.info("list[" + list + "] ");
				
				if( list.size() == 1 ) {
//					logger.info("list.size()[" + list.size() + "] ");
					map = (Map)list.get(0);					
 					logger.info("RESP_CODE["+(String)map.get("RESP_CODE")+"]");	
 					logger.info("USE_CNT["+(String)map.get("USE_CNT")+"]");	
 					logger.info("USE_AMT["+(String)map.get("USE_AMT")+"]");	
					
					if("0000".equals((String)map.get("RESP_CODE")) && Integer.parseInt(map.get("USE_AMT")) == 0){
						// 조건 삭제 && Integer.parseInt(map.get("USE_CNT")) == 0 
						// sql 초기화
						sql.close();
						i = 0;
						
						sql.put(findQuery("service-sql", "INS_STAFF_DISCOUNT_HIST"));
						sql.setString(++i, ((String)hm.get("CTL_TRAN_NO")).substring(0, 8));                    		                            // 거래일시
						sql.setString(++i, "1002"); 													    // 회사코드
						sql.setString(++i, (String)hmStaff.get("COMP_CD"));                                                	        // 소속사코드
						sql.setString(++i, (String)hmStaff.get("EMPLOYEE_ID"));                                                      // 사번
						sql.setString(++i, (String)hm.get("CTL_TRAN_NO"));                                                       // 거래요청번호
						sql.setString(++i, (String)hm.get("REQ_TYPE"));													        // 요청구분 0:승인요청 1:취소 2:망취소
						sql.setString(++i, (String)hm.get("PAY_AMT"));													        // 결제요청금액
						sql.setString(++i, (String)hm.get("STORE_CODE")+(String)hm.get("POS_NO"));  // 등록/수정자 ID 
						sql.setString(++i, (String)hm.get("STORE_CODE")+(String)hm.get("POS_NO"));  // 등록/수정자 ID
		
						logger.info("sql[" + sql + "] ");
						logger.info("sql.toString()[" + sql.toString() + "] ");
						logger.info("sql.debug()[" + sql.debug() + "] ");
						rows = executeUpdate(sql);
//						logger.info("rows[" + rows + "] ");

						if(rows != 1){
							hm.put("RESP_CODE", "0010"); // 결과코드
							//hm.put("RETURN_CD", "10"); 
							hm.put("RESP_MSG", "이력 생성 오류");      // 응답메시지     
						    logger.info("RESP_CODE[0010]");       
							rollback();
						}else{
							hm.put("RESP_CODE", (String)map.get("RESP_CODE")); // 결과코드
							hm.put("RETURN_CD", "00");  
						}
					}else if(!"0000".equals((String)map.get("RESP_CODE"))){
						hm.put("RESP_CODE", "0012");  // 결과코드
						//hm.put("RETURN_CD", "12");  
						hm.put("RESP_MSG", "거래 승인이 불가합니다.");  // 응답메시지
						logger.info("RESP_CODE[0012]");
//					}else if(Integer.parseInt(map.get("USE_CNT")) > 0){
//						hm.put("RESP_CODE", "0013");  // 결과코드
//						//hm.put("RETURN_CD", "13"); 
//						hm.put("RESP_MSG", "이용가능 횟수가 초과 되었습니다.");  // 응답메시지
//						logger.info("RESP_CODE[0013]");
					}else if(Integer.parseInt(map.get("USE_AMT")) > 0){
						hm.put("RESP_CODE", "0014");  // 결과코드
						//hm.put("RETURN_CD", "14"); 
						hm.put("RESP_MSG", "이용가능 금액이 초과 되었습니다.");  // 응답메시지
					    logger.info("RESP_CODE[0014]");
					}else {
						hm.put("RESP_CODE", "0017"); // 결과코드
						//hm.put("RETURN_CD", "17"); 
						hm.put("RESP_MSG", "조회 오류.");      // 응답메시지   
					    logger.info("RESP_CODE[0017]");    
					}
				} else {
					hm.put("RESP_CODE", "0016"); // 결과코드
					//hm.put("RETURN_CD", "16"); 
					hm.put("RESP_MSG", "조회 오류.");      // 응답메시지   
				    logger.info("RESP_CODE[0016]");       
				}
				//logger.info("hm" + hm + "] ");					
			}else{
				hm.put("RESP_CODE", "0015");  // 결과코드     
				//hm.put("RETURN_CD", "15"); 
				hm.put("RESP_MSG", "사원정보가 확인되지 않습니다");  // 응답메시지
			    logger.info("RESP_CODE[0015]");
			}
		}catch(Exception e) {
			logger.info("Exception[" + e.getMessage() + "]");
			rollback();
			throw e;
		}finally {
			logger.info("USE_CNT[" + (String)hmStaff.get("USE_CNT") + "]");
			logger.info("USE_AMT[" + (String)hmStaff.get("USE_AMT") + "]");
			logger.info("RETURN_CD[" + (String)hmStaff.get("RETURN_CD") + "]");
			logger.info("EMPLOYEE_YN[" + (String)hmStaff.get("EMPLOYEE_YN") + "]");
			logger.info("EMPLOYEE_ID[" + (String)hmStaff.get("EMPLOYEE_ID") + "]");
			logger.info("COMP_CD[" + (String)hmStaff.get("COMP_CD") + "]");
			logger.info("COMP_NM[" + (String)hmStaff.get("COMP_NM") + "]");
			logger.info("EMPLOYEE_NM[" + (String)hmStaff.get("EMPLOYEE_NM") + "]");
			logger.info("RANK_CD[" + (String)hmStaff.get("RANK_CD") + "]");
			logger.info("RANK_NM[" + (String)hmStaff.get("RANK_NM") + "]");
			logger.info("RSP_MESSAGE[" + (String)hmStaff.get("RSP_MESSAGE") + "]");
			//사원정보입력
			if("0000".equals((String)hmStaff.get("RETURN_CD"))){
				hm.put("USE_CNT", (String)map.get("USE_CNT"));       // 사용횟수      
				hm.put("USE_AMT", (String)map.get("USE_AMT"));       // 사용금액     
				hm.put("RETURN_CD", ((String)hmStaff.get("RETURN_CD")).substring(0, 2));       // 응답코드
				hm.put("EMPLOYEE_YN", (String)hmStaff.get("EMPLOYEE_YN"));      // 직원유무
				hm.put("EMPLOYEE_ID", (String)hmStaff.get("EMPLOYEE_ID"));      // 사번
				hm.put("COMP_CD", (String)hmStaff.get("COMP_CD"));      // 소속사코드
				hm.put("COMP_NM", (String)hmStaff.get("COMP_NM"));      // 소속사명
				hm.put("EMPLOYEE_NM", (String)hmStaff.get("EMPLOYEE_NM"));      // 이름
				hm.put("RANK_CD", (String)hmStaff.get("RANK_CD"));      // 직급코드
				hm.put("RANK_NM", (String)hmStaff.get("RANK_NM"));      // 직급명
				hm.put("RSP_MESSAGE", (String)hmStaff.get("RSP_MESSAGE"));      // 응답메세지
			}else{
				hm.put("USE_CNT", "0");       // 사용횟수      
				hm.put("USE_AMT", "0");       // 사용금액   
				hm.put("RETURN_CD", ((String)hmStaff.get("RETURN_CD")).substring(0, 2));       // 응답코드
				hm.put("EMPLOYEE_YN", "-");      // 직원유무
				hm.put("EMPLOYEE_ID", "-");      // 사번
				hm.put("COMP_CD", "-");      // 소속사코드
				hm.put("COMP_NM", "-");      // 소속사명
				hm.put("EMPLOYEE_NM", "-");      // 이름
				hm.put("RANK_CD", "-");      // 직급코드
				hm.put("RANK_NM", "-");      // 직급명  
				hm.put("RSP_MESSAGE", (String)hmStaff.get("RSP_MESSAGE"));      // 응답메세지
			}
			
			dataMsg = ret + StaffDCIrtProtocol.makeSendDataStrStockNow(hm, df); //POS응답 전송메세지 생성
			logger.info("dataMsg" + dataMsg + "] ");
			end();
		}
		return dataMsg;
	}
	
	public String getStaffDCRetr(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();		
		List<Object> list = null;
		int i = 0;
		int rows = -1;
		
		String dataMsg = "";		
		String ret = "00";
		
		try {
//			logger.info("hm [" + hm + "]");
//			logger.info("STORE_CODE [" + (String)hm.get("STORE_CODE") + "]");
//			logger.info("COM_CD [" + "1002" + "]");
//			logger.info("EMPLOYEE_ID [" + (String)hm.get("EMPLOYEE_ID") + "]");
//			logger.info("COMP_CD [" + (String)hm.get("COMP_CD") + "]");
//			logger.info("REQ_TYPE [" + (String)hm.get("REQ_TYPE") + "]");
//			logger.info("CTL_TRAN_NO [" + (String)hm.get("CTL_TRAN_NO") + "]");
			
			// DB Connection(DB 접속)
			connect("CMGNS");

			begin();
			
			sql.put(findQuery("service-sql", "UPD_STAFF_DISCOUNT_HIST"));
			sql.setString(++i, (String)hm.get("REQ_TYPE"));                                                         // 요청구분 0:승인요청 1:취소 2:망취소         
			sql.setString(++i, (String)hm.get("STORE_CODE")+(String)hm.get("POS_NO"));  // 등록/수정자 ID                      
			sql.setString(++i, ((String)hm.get("CTL_TRAN_NO")).substring(0, 8));                                                          // 거래일시                           
			sql.setString(++i, "1002");                                                       // 회사코드                           
//			sql.setString(++i, (String)hm.get("COMP_CD"));                                                          // 소속사코드                          
//			sql.setString(++i, (String)hm.get("EMPLOYEE_ID"));                                                      // 사번                             
			sql.setString(++i, (String)hm.get("CTL_TRAN_NO"));                                                       // 거래번호                           

//			logger.info("sql[" + sql + "] ");
//			logger.info("sql.toString()[" + sql.toString() + "] ");
//			logger.info("sql.debug()[" + sql.debug() + "] ");

			rows = executeUpdate(sql);
//			logger.info("rows[" + rows + "] ");
			
			if( rows == 1 ) {			
				hm.put("RESP_CODE", "0000"); // 결과코드       
				hm.put("RESP_MSG", "정상");   // 응답메시지 
				hm.put("USE_CNT", "");       // 사용횟수      
				hm.put("USE_AMT", "");       // 사용금액      
			}else if(rows < 1){
				hm.put("RESP_CODE", "0020"); // 결과코드       
				hm.put("RESP_MSG", "이력 생성 오류");      // 응답메시지     
				hm.put("USE_CNT", "");       // 사용횟수      
				hm.put("USE_AMT", "");       // 사용금액      
			    logger.info("RESP_CODE[0020]");
				rollback();
			}else if(rows > 1){
				hm.put("RESP_CODE", "0021"); // 결과코드       
				hm.put("RESP_MSG", "이력 생성 오류");      // 응답메시지     
				hm.put("USE_CNT", "");       // 사용횟수      
				hm.put("USE_AMT", "");       // 사용금액      
			    logger.info("RESP_CODE[0021]");
				rollback();
			}
			
//			logger.info("hm" + hm + "] ");
			
		}catch(Exception e) {
			logger.info("Exception[" + e.getMessage() + "]");
			rollback();
			throw e;
		}finally {
			
			hm.put("RETURN_CD", "00");      // 응답코드
			hm.put("EMPLOYEE_YN", "");      // 직원유무
			hm.put("EMPLOYEE_ID", "");      // 사번
			hm.put("COMP_CD", "");      // 소속사코드
			hm.put("COMP_NM", "");      // 소속사명
			hm.put("EMPLOYEE_NM", "");      // 이름
			hm.put("RANK_CD", "");      // 직급코드
			hm.put("RANK_NM", "");      // 직급명
			hm.put("RSP_MESSAGE", "");      // 응답메세지
			
			dataMsg = ret + StaffDCIrtProtocol.makeSendDataStrStockNow(hm, df);
//			logger.info("dataMsg" + dataMsg + "] ");
			end();
		}
		
		return dataMsg;
	}

}
