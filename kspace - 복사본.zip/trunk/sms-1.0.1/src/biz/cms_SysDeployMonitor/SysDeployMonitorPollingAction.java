/*
 * MasterCrtAgentPollingAction.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_SysDeployMonitor;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.CurrentContext;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.node.EngineContainer;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.DaemonContainer;
import kr.fujitsu.com.ffw.daemon.net.polling.ActionPollingContainer;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.cms_CashBeeSender.CashBeeSenderDAO;
import biz.cms_DeployReq.DeployReqClientAction;
import biz.cms_MasterAgent.MasterAgentPOSOperator;
import biz.cms_MasterCrt.MasterCrtClientAction;


/** 
 * SysDeployMonitorPollingAction
 * 배신 상태 모니터링 
 * 준비완료에서 멈추어있는 경우 배신완료 인경우 준비완료로 변경함 
 * @created  on 
 * @created  by  
 *  
 * @modified on 
 * @caused   by 
 */ 
public class SysDeployMonitorPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(SysDeployMonitorPollingAction.class);

	public void execute(String actionMode) {

		try {
			SysDeployMonitorDAO dao   = new SysDeployMonitorDAO();
		
			// POS 단에서 OPER_ID = 3 인경우 더 MASTER 적용절차가 진행 되지 않는 현상 해결
			// 매 30초 시간 주기로 STBDA100AT 의  OPER_ID 를 바라보고 
			// 마지막 적용시간 +5  이상인 점포에 대해서 OPER_ID = 3 인경우 OPER_ID = 2 로 변경함  
 
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			String today = sdf.format(calendar.getTime());
			
			calendar.add(Calendar.DATE, -1); //당일 전일 자 데이터 처리 
			String tran_ymd = sdf.format(calendar.getTime());
			
			String local_no = PropertyUtil.findProperty("communication-property", "LOCAL_SERVER_NO");
			
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if (actionMode == "1")
			{
				logger.info("[INFO] Don't do anything at Action time ");
			}			
			else if (actionMode == "0")
			{
				logger.info("[INFO] polling..");
				int cnt = dao.selStopPROGRESS(today, tran_ymd,local_no);
				
				if (cnt>0){
					logger.info("[INFO] selStopPROGRESS cnt=" + cnt + ")");
					int in_progress_cnt = dao.updOPERID(today, tran_ymd,local_no);

					if( in_progress_cnt > 0 ) {
						logger.info("[INFO] update oper_id 3 to 2  (cnt=" + in_progress_cnt + ")");
					}			
				}
			}											
		} catch (Exception e) {
			logger.info("Exception occure at DeployMonitor "+ e.getMessage());
		}
	}	
}
