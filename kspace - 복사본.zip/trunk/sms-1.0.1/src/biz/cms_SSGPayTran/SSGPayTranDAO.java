package biz.cms_SSGPayTran;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_TranDivide.TranDividePollingAction;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class SSGPayTranDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(SSGPayTranPollingAction.class);
	
	public int updSSGPAYTRAN_RCVY(String com_cd, String proc_ymdhms) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGPAYTRAN_RCVY"));
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int updSSGMONEYCHGTRAN_RCVY(String com_cd, String proc_ymdhms) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGMONEYCHGTRAN_RCVY"));
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int updSSGPOSATRAN_RCVY(String com_cd, String proc_ymdhms) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGPOSATRAN_RCVY"));
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int updWeChatTRAN_RCVY(String com_cd, String proc_ymdhms) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_WECHATTRAN_RCVY"));
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int updSSGMONEYTRAN_RCVY(String com_cd, String proc_ymdhms) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGMONEYTRAN_RCVY"));
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int updSSGSTAFFTRAN_RCVY(String com_cd, String proc_ymdhms) { //20170220
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGSTAFFDCTRAN_RCVY"));
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int updSSGMONEYCHGTRAN_RESET(String proc_id, String tran_ymd, String store_cd, String pos_no, String tran_no, String com_cd) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGMONEYTCHGRAN_RESET"));
			sql.setString(++i, proc_id);
			sql.setString(++i, tran_ymd);
			sql.setString(++i, store_cd);
			sql.setString(++i, pos_no);
			sql.setString(++i, tran_no);
			sql.setString(++i, com_cd);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int updSSGPOSATRAN_RESET(String proc_id, String tran_ymd, String store_cd, String pos_no, String tran_no, String com_cd) 
	{
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0; 
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGPOSARAN_RESET"));
			sql.setString(++i, proc_id);
			sql.setString(++i, tran_ymd);
			sql.setString(++i, store_cd);
			sql.setString(++i, pos_no);
			sql.setString(++i, tran_no);
			sql.setString(++i, com_cd);
			
			ret = executeUpdate(sql); 
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int updWeChatTRAN_RESET(String proc_id, String tran_ymd, String store_cd, String pos_no, String tran_no, String com_cd) 
	{
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0; 
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_WECHATRAN_RESET"));
			sql.setString(++i, proc_id);
			sql.setString(++i, tran_ymd);
			sql.setString(++i, store_cd);
			sql.setString(++i, pos_no);
			sql.setString(++i, tran_no);
			sql.setString(++i, com_cd);
			
			ret = executeUpdate(sql); 
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int updSSGMONEYTRAN_RESET(String proc_id, String tran_ymd, String store_cd, String pos_no, String tran_no, String com_cd) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGMONEYTRAN_RESET"));
			sql.setString(++i, proc_id);
			sql.setString(++i, tran_ymd);
			sql.setString(++i, store_cd);
			sql.setString(++i, pos_no);
			sql.setString(++i, tran_no);
			sql.setString(++i, com_cd);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int updSSGPAYTRAN_RESET(String proc_id, String tran_ymd, String store_cd, String pos_no, String tran_no, String com_cd) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGPAYTRAN_RESET"));
			sql.setString(++i, proc_id);
			sql.setString(++i, tran_ymd);
			sql.setString(++i, store_cd);
			sql.setString(++i, pos_no);
			sql.setString(++i, tran_no);
			sql.setString(++i, com_cd);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int updSSGSTAFFDCTRAN_RESET(String proc_id, String tran_ymd, String store_cd, String pos_no, String tran_no, String com_cd) 
	{
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0; 
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGSTAFFDCTRAN_RESET"));
			sql.setString(++i, proc_id);
			sql.setString(++i, tran_ymd);
			sql.setString(++i, store_cd);
			sql.setString(++i, pos_no);
			sql.setString(++i, tran_no);
			sql.setString(++i, com_cd);
			logger.info("sql[" + sql.debug() + "]");
			ret = executeUpdate(sql); 
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	public List<Object> selSSGMONEYCHGTRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SSGMONEYCHGTRAN"));
			sql.setString(++i, card_key);
			sql.setString(++i, double_card_key);
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selSSGMONEYCHGTRAN::" + e);
		}
		
		return list;
	}
	
	public List<Object> selSSGPOSATRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			String sSql = findQuery("service-sql", "SEL_SSGPOSATRAN");
			
			logger.info("sSql=[" + sSql + "]");
			
			sql.put(sSql);
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selSSGPOSATRAN::" + e);
		}
		
		return list;
	}
	
	public List<Object> selWeChatTRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			String sSql = findQuery("service-sql", "SEL_WECHATTRAN");
			
			logger.info("sSql=[" + sSql + "]");
			
			sql.put(sSql);
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selWeChatTRAN::" + e);
		}
		
		return list;
	}
	
	public List<Object> selSSGMONEYTRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SSGMONEYTRAN"));
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selSSGMONEYTRAN::" + e);
		}
		
		return list;
	}
	
	public List<Object> selSSGPAYTRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SSGPAYTRAN"));
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selSSGPAYTRAN::" + e);
		}
		
		return list;
	}
	
	public List<Object> selSSGSTAFFDCTRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SSGSTAFFDCTRAN"));
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selSSGSTAFFTRAN::" + e);
		}
		
		return list;
	}
	
	public int updSSGMONEYTRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int ret = 0;
		int i = 0;
		int sequence = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			// 통신서버 3대가 같은 row를 update 하려는 시도를 차단하기 위해
			// 1~3 범위로 순환되는 sequence 값을 조회해서 그 값이 (REG_YMDHMS % 3)와 같은
			// row들만 update 한다.
			// 통신서버 3대는 동시에 같은 row를 update 할 수 없게 된다.
			sql.put(findQuery("service-sql", "SEL_SSGMONEYGROUPSEQ"));
			
			list = executeQuery(sql);
			sql.close();
			if( list.size() > 0 ) sequence = Integer.parseInt((String)((Map<String, String>)list.get(0)).get("SEQ"));
			
			i = 0;
			sql.clearParameter();
			sql.put(findQuery("service-sql", "UPD_SSGMONEYTRAN"));
			sql.setString(++i, proc_ymdhms);
			sql.setString(++i, com_cd);
			sql.setInt(++i, sequence-1);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			ret = 0;
			rollback();
			logger.info("[ERROR]updSSGMONEYTRAN::" + e);
		}finally {
			end();
		}
		
		return ret;
		
	}
	
	public int updSSGMONEYCHGTRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int ret = 0;
		int i = 0;
		int sequence = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			// 통신서버 3대가 같은 row를 update 하려는 시도를 차단하기 위해
			// 1~3 범위로 순환되는 sequence 값을 조회해서 그 값이 (REG_YMDHMS % 3)와 같은
			// row들만 update 한다.
			// 통신서버 3대는 동시에 같은 row를 update 할 수 없게 된다.
			sql.put(findQuery("service-sql", "SEL_SSGMONEYCHGGROUPSEQ"));
			
			list = executeQuery(sql);
			sql.close();
			if( list.size() > 0 ) sequence = Integer.parseInt((String)((Map<String, String>)list.get(0)).get("SEQ"));
			
			i = 0;
			sql.clearParameter();
			sql.put(findQuery("service-sql", "UPD_SSGMONEYCHGTRAN"));
			sql.setString(++i, proc_ymdhms);
			sql.setString(++i, com_cd);
			sql.setInt(++i, sequence-1);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			ret = 0;
			rollback();
			logger.info("[ERROR]updSSGMONEYCHGTRAN::" + e);
		}finally {
			end();
		}
		
		return ret;
		
	}

	public int updSSGPAYTRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int ret = 0;
		int i = 0;
		int sequence = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			// 통신서버 3대가 같은 row를 update 하려는 시도를 차단하기 위해
			// 1~3 범위로 순환되는 sequence 값을 조회해서 그 값이 (REG_YMDHMS % 3)와 같은
			// row들만 update 한다.
			// 통신서버 3대는 동시에 같은 row를 update 할 수 없게 된다.
			sql.put(findQuery("service-sql", "SEL_SSGPAYGROUPSEQ"));
			
			list = executeQuery(sql);
			sql.close();
			if( list.size() > 0 ) sequence = Integer.parseInt((String)((Map<String, String>)list.get(0)).get("SEQ"));
			
			i = 0;
			sql.clearParameter();
			sql.put(findQuery("service-sql", "UPD_SSGPAYTRAN"));
			sql.setString(++i, proc_ymdhms);
			sql.setString(++i, com_cd);
			sql.setInt(++i, sequence-1);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			ret = 0;
			rollback();
			logger.info("[ERROR]updSSGPAYTRAN::" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
	
	
	
	public int updSSGPOSATRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int ret = 0;
		int i = 0;
		int sequence = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			// 통신서버 3대가 같은 row를 update 하려는 시도를 차단하기 위해
			// 1~3 범위로 순환되는 sequence 값을 조회해서 그 값이 (REG_YMDHMS % 3)와 같은
			// row들만 update 한다.
			// 통신서버 3대는 동시에 같은 row를 update 할 수 없게 된다.
			sql.put(findQuery("service-sql", "SEL_SSGPOSAGROUPSEQ"));
			
			list = executeQuery(sql);
			sql.close();
			if( list.size() > 0 ) sequence = Integer.parseInt((String)((Map<String, String>)list.get(0)).get("SEQ"));
			
			i = 0;
			sql.clearParameter();
			sql.put(findQuery("service-sql", "UPD_SSGPOSATRAN"));
			sql.setString(++i, proc_ymdhms);
			sql.setString(++i, com_cd);
			sql.setInt(++i, sequence-1);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			ret = 0;
			rollback();
			logger.info("[ERROR]updSSGPOSATRAN::" + e);
		}finally {
			end();
		}
		
		return ret;
		
	}
	
	public int updSSGSTAFFDCTRAN(String com_cd, String proc_ymdhms) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int ret = 0;
		int i = 0;
		int sequence = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			// 통신서버 3대가 같은 row를 update 하려는 시도를 차단하기 위해
			// 1~3 범위로 순환되는 sequence 값을 조회해서 그 값이 (REG_YMDHMS % 3)와 같은
			// row들만 update 한다.
			// 통신서버 3대는 동시에 같은 row를 update 할 수 없게 된다.
			sql.put(findQuery("service-sql", "SEL_SSGSTAFFDCGROUPSEQ"));

//			logger.info("updSSGSTAFFDCTRAN");
			list = executeQuery(sql);
			sql.close();
			if( list.size() > 0 ) sequence = Integer.parseInt((String)((Map<String, String>)list.get(0)).get("SEQ"));
			
			i = 0;
			sql.clearParameter();
			sql.put(findQuery("service-sql", "UPD_SSGSTAFFDCTRAN"));
			sql.setString(++i, proc_ymdhms);
			sql.setString(++i, com_cd);
			sql.setInt(++i, sequence-1);

//			logger.info("sql[" + sql.debug() + "]");
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			ret = 0;
			rollback();
			logger.info("[ERROR]updSSGSTAFFDCTRAN::" + e);
		}finally {
			end();
		}
		
		return ret;
		
	}

	

	
}
