package biz.cms_SSGPayTran;

import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import sun.misc.BASE64Decoder;

import com.cyberpass.seed.Seed;

import biz.cms_SSGMbsTran.SSGMbsTranPollingAction;
import biz.comm.AES;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;

public class SSGPayTranPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(SSGPayTranPollingAction.class);
	
	public static void main(String args[]) throws Exception {

		try {
			SSGPayTranPollingAction action = new SSGPayTranPollingAction();

//			String path          = "D:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
//			System.out.println("path[" + path + "]");	
//			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);	
//			System.out.println("locator[" + locator + "]");	
//			System.out.println("action[" + action + "]");
			
			if(args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			action.execute("1");
			
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}  

	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		try {
			//logger.info("[ssgpay]SSGPayTranPollingAction execute");
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
//			if (actionMode == "0")
//			{
				SimpleDateFormat sdf = new SimpleDateFormat("MMddHHmmss");
				String proc_ymdhms = sdf.format(new Date()) + (Double.toString(Math.random())).substring(2, 6);
				String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
				
				SSGPayTranDAO dao = new SSGPayTranDAO();
				List<Object> list = null;
				int ret = -1;
				
				// SSGPay 집계대사Tran 송신
				try {
					// SSGPay TRAN에 대상 정보 기록 및 기록된 TRAN 조회
					ret = dao.updSSGPAYTRAN(com_cd, proc_ymdhms);
//					logger.info("SSGPay<"+Integer.toString(ret)+">");

					if( ret > 0 ) {
						// 대상 정보 기록된 TRAN 조회
						list = dao.selSSGPAYTRAN(com_cd, proc_ymdhms);
						
						if( list.size() <= 0 )
						{
							dao.updSSGPAYTRAN_RCVY(com_cd, proc_ymdhms);
						}else {
							for(int i = 0;i < list.size();i++) {
								Map<String, String> map = (Map<String, String>)list.get(i);
								try {
									this.transferToSSGPay(map);
								}catch(Exception e) {
									logger.info("[ERROR]:" + e.getMessage());
								}
								Thread.sleep(50);
							}
						}
					}
				}catch(Exception e) {
					logger.info("[ERROR-SSGPay]" + e.getMessage());
				}
				
				// SSGMoney 집계대사Tran 송신
				try {
					// SSGMoney TRAN에 대상 정보 기록 및 기록된 TRAN 조회
					ret = dao.updSSGMONEYTRAN(com_cd, proc_ymdhms);
//					logger.info("SSGMoney<"+Integer.toString(ret)+">");
					
					if( ret > 0 ) {
						// 대상 정보 기록된 TRAN 조회
						list = dao.selSSGMONEYTRAN(com_cd, proc_ymdhms);
						
						if( list.size() <= 0 )
						{
							dao.updSSGMONEYTRAN_RCVY(com_cd, proc_ymdhms);
						}else {
							for(int i = 0;i < list.size();i++) {
								Map<String, String> map = (Map<String, String>)list.get(i);
								try {
									this.transferToSSGMoney(map);
								}catch(Exception e) {
									logger.info("[ERROR]:" + e.getMessage());
								}
								Thread.sleep(50);
							}
						}
					}
				}catch(Exception e) {
					logger.info("[ERROR-SSGMoney]" + e.getMessage());
				}
				
				// SSGMoney 충전대사Tran 송신
				try {
					// SSGMoney 충전TRAN에 대상 정보 기록 및 기록된 TRAN 조회
					ret = dao.updSSGMONEYCHGTRAN(com_cd, proc_ymdhms);
//					logger.info("SSGMoney<"+Integer.toString(ret)+">");
					
					if( ret > 0 ) {
						// 대상 정보 기록된 TRAN 조회
						list = dao.selSSGMONEYCHGTRAN(com_cd, proc_ymdhms);
						
						if( list.size() <= 0 )
						{
							dao.updSSGMONEYCHGTRAN_RCVY(com_cd, proc_ymdhms);
						}else {
							for(int i = 0;i < list.size();i++) {
								Map<String, String> map = (Map<String, String>)list.get(i);
								try {
									this.transferToSSGMoneyChg(map);
								}catch(Exception e) {
									logger.info("[ERROR]:" + e.getMessage());
								}
								Thread.sleep(50);
							}
						}
					}
				}catch(Exception e) {
					logger.info("[ERROR-SSGMoneyChg]" + e.getMessage());
				}
				
				// SSG POSA Tran 송신
				try {
					// SSG POSA TRAN에 대상 정보 기록 및 기록된 TRAN 조회
					ret = dao.updSSGPOSATRAN(com_cd, proc_ymdhms);
					
//					logger.info("1) dao.updSSGPOSATRAN(): com_cd     =[" + com_cd + "]");
//					logger.info("1) dao.updSSGPOSATRAN(): proc_ymdhms=[" + proc_ymdhms + "]");
//					logger.info("1) dao.updSSGPOSATRAN(): ret        =[" + ret + "]");
					
					if (ret > 0) 
					{
						// 대상 정보 기록된 TRAN 조회
						list = dao.selSSGPOSATRAN(com_cd, proc_ymdhms);
						
						logger.info("2) dao.selSSGPOSATRAN(): com_cd=[" + com_cd + "]");
						logger.info("2) dao.selSSGPOSATRAN(): proc_ymdhms=[" + proc_ymdhms + "]");
						logger.info("2) dao.selSSGPOSATRAN(): list.size()=[" + list.size() + "]");
						
						if (list.size() <= 0)
						{
							logger.info("3) dao.updSSGPOSATRAN_RCVY(): com_cd     =[" + com_cd + "]");
							logger.info("3) dao.updSSGPOSATRAN_RCVY(): proc_ymdhms=[" + proc_ymdhms + "]");

							dao.updSSGPOSATRAN_RCVY(com_cd, proc_ymdhms);
						}
						else 
						{
							logger.info("4) transferToSSGPosa(): list.size()=[" + list.size() + "]");
							
							for (int i = 0; i < list.size(); i++) 
							{
								Map<String, String> map = (Map<String, String>)list.get(i);
								try 
								{
									this.transferToSSGPosa(map);
									
									logger.info((i+0) + "] transferToSSGPosa");
								}
								catch(Exception e) 
								{
									logger.info("[ERROR]:" + e.getMessage());
								}
								
								Thread.sleep(50);
							}
						}
					}
				}
				catch (Exception e) 
				{
					logger.info("[ERROR-SSGPosa]" + e.getMessage());
				}
				
				// SSG Staff Tran 송신
				try {
					// SSG Staff TRAN에 대상 정보 기록 및 기록된 TRAN 조회
					ret = dao.updSSGSTAFFDCTRAN(com_cd, proc_ymdhms);
					
//					logger.info("1) dao.updSSGSTAFFTRAN(): com_cd     =[" + com_cd + "]");
//					logger.info("1) dao.updSSGSTAFFTRAN(): proc_ymdhms=[" + proc_ymdhms + "]");
//					logger.info("1) dao.updSSGSTAFFTRAN(): ret        =[" + ret + "]");
					
					if (ret > 0) 
					{
						// 대상 정보 기록된 TRAN 조회
						list = dao.selSSGSTAFFDCTRAN(com_cd, proc_ymdhms);
						
						logger.info("2) dao.selSSGSTAFFTRAN(): com_cd=[" + com_cd + "]");
						logger.info("2) dao.selSSGSTAFFTRAN(): proc_ymdhms=[" + proc_ymdhms + "]");
						logger.info("2) dao.selSSGSTAFFTRAN(): list.size()=[" + list.size() + "]");
						
						if (list.size() <= 0)
						{
							logger.info("3) dao.updSSGSTAFFTRAN_RCVY(): com_cd     =[" + com_cd + "]");
							logger.info("3) dao.updSSGSTAFFTRAN_RCVY(): proc_ymdhms=[" + proc_ymdhms + "]");

							dao.updSSGSTAFFTRAN_RCVY(com_cd, proc_ymdhms);
						}
						else 
						{
							logger.info("4) transferToSSGStaff(): list.size()=[" + list.size() + "]");
							
							for (int i = 0; i < list.size(); i++) 
							{
								Map<String, String> map = (Map<String, String>)list.get(i);
								try 
								{	logger.info("before transfer");
									this.transferToSSGStaffDC(map);
									
									logger.info((i+0) + "] transferToSSGStaff");
								}
								catch(Exception e) 
								{
									logger.info("[ERROR]:" + e.getMessage());
								}
								
								Thread.sleep(50);
							}
						}
					}
				}
				catch (Exception e) 
				{
					logger.info("[ERROR-SSGStaff]" + e.getMessage());
				}
//			}
		}
		catch(Exception e) 
		{
			logger.info("[ERROR]" + e.getMessage());
		}
	}

	public void transferToSSGPay(Map<String, String> map) throws Exception {
		ActionSocket actSock = null;
		SSGPayTranDAO dao = new SSGPayTranDAO();
		String dataMsg = "";
		String recvBuf = "";
		byte sendBytes[];
		String comCd = "";
		String ip = "";
		int port = 0;
		
		try {
			comCd = PropertyUtil.findProperty("stsys-property", "COM_CD");											// 회사코드
			ip = PropertyUtil.findProperty("communication-property", "SSGPAY_INQSVR_IP");							// IP
			port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGPAY_INQSVR_PORT"));		// PORT
			
			if( comCd.trim() == "" ) {
				comCd = "1002";
			}
			actSock = new ActionSocket(new Socket(ip, port), (Filter)(new COMMConveyerFilter(COMMBiz.SSGPAY_FILTER)));
			actSock.getSocket().setSoTimeout(5000);
			String strHeader = makeSSGPayTranHeader(map);
			String strData = makeSSGPayTranData(map);
			dataMsg = strHeader + strData;
			
			// Data 전문을 바이트 배열로 변환
			sendBytes = dataMsg.getBytes();
			sendBytes[1599] = (byte)0x0d;
			
			logger.info("[sms>ssgpay] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");
			
			/**
			 ** 1. 대사TRAN(1건) 송신
			 **/
			if( actSock.send(sendBytes, sendBytes.length) ) {
				logger.info("[sms>ssgpay] SEND[" + sendBytes.length + "] OK");
			}else {
				logger.info("[sms>ssgpay] SEND[" + sendBytes.length + "] ERROR");
	
				throw new Exception("SSGPay server is no response");
			}
			
			// 대사TRAN전문에 대한 응답
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<ssgpay] RECV[" + recvBuf.getBytes().length + "]::[" + recvBuf + "]");
			
//			logger.info("RESP_CD=" + recvBuf.substring(295, 299));
			
			if( !(recvBuf.substring(295, 299)).equals("0000") )
			{
//				logger.info((recvBuf.substring(299, 359)).trim());
				dao.updSSGPAYTRAN_RESET( "9"
									   ,(String)map.get("SYS_YMD")
									   , (String)map.get("STORE_CD")
									   , (String)map.get("POS_NO")
									   , (String)map.get("TRAN_NO")
									   , (String)map.get("COM_CD"));
			}else
			{
				dao.updSSGPAYTRAN_RESET( "1"
									   ,(String)map.get("SYS_YMD")
									   , (String)map.get("STORE_CD")
									   , (String)map.get("POS_NO")
									   , (String)map.get("TRAN_NO")
									   , (String)map.get("COM_CD"));
			}
		}catch(Exception e) {
			logger.info("", e);
		}finally {
			
		}
	}
	
	public void transferToSSGMoneyChg(Map<String, String> map) throws Exception {
		ActionSocket actSock = null;
		SSGPayTranDAO dao = new SSGPayTranDAO();
		String strMessage = "";
		String recvBuf = "";
		byte sendBytes[] = null;
		String comCd = "";
		String ip = "";
		int port = 0;
		
		try {
			comCd = PropertyUtil.findProperty("stsys-property", "COM_CD");												// 회사코드
			ip = PropertyUtil.findProperty("communication-property", "SSGMONEY_APPRSVR_IP");							// IP
			port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGMONEY_APPRSVR_PORT"));		// PORT
			
			if( comCd.trim() == "" ) {
				comCd = "1002";
			}
			actSock = new ActionSocket(new Socket(ip, port), (Filter)(new COMMConveyerFilter(COMMBiz.SSGPAY_FILTER)));
			actSock.getSocket().setSoTimeout(5000);
			strMessage = makeSSGMoneyChgTran(map);
			
			// Data 전문을 바이트 배열로 변환
			sendBytes = strMessage.getBytes();
			sendBytes[899] = (byte)0x0d;
			
			logger.info("[sms>ssgmoney] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");
			
			/**
			 ** 1. 대사TRAN(1건) 송신
			 **/
			if( actSock.send(sendBytes, sendBytes.length) ) {
				logger.info("[sms>ssgmoney] SEND[" + sendBytes.length + "] OK");
			}else {
				logger.info("[sms>ssgmoney] SEND[" + sendBytes.length + "] ERROR");
	
				throw new Exception("SSGMoney server is no response");
			}
			
			// 대사TRAN전문에 대한 응답
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<ssgmoney] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");
			
			logger.info("RESP_CD=" + recvBuf.substring(692, 696));
			
			if( !(recvBuf.substring(692, 696)).equals("0000") && !(recvBuf.substring(692, 696)).equals("5170")
				&& !(recvBuf.substring(692, 696)).equals("5160") )
			{
				logger.info((recvBuf.substring(696, 756)).trim());
				dao.updSSGMONEYCHGTRAN_RESET( "9"
									     , (String)map.get("SYS_YMD")
									     , (String)map.get("ST_CODE")
									     , (String)map.get("TM_NO")
									     , (String)map.get("TRAN_NO")
									     , (String)map.get("COM_CD"));
			}else
			{
				dao.updSSGMONEYCHGTRAN_RESET( "1"
									     , (String)map.get("SYS_YMD")
									     , (String)map.get("ST_CODE")
									     , (String)map.get("TM_NO")
									     , (String)map.get("TRAN_NO")
									     , (String)map.get("COM_CD"));
			}
		}catch(Exception e) {
			logger.info("", e);
		}finally {
			
		}
	}
	
	public void transferToSSGPosa(Map<String, String> map) throws Exception 
	{
		ActionSocket actSock = null;
		SSGPayTranDAO dao = new SSGPayTranDAO();
		String strMessage = "";
		String recvBuf = "";
		byte sendBytes[] = null;
		String comCd = "";
		String ip = "";
		int port = 0;
		
		try {
			comCd = PropertyUtil.findProperty("stsys-property", "COM_CD");												// 회사코드
			ip = PropertyUtil.findProperty("communication-property", "SSGMONEY_APPRSVR_IP");							// IP
			port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGMONEY_POSASVR_PORT"));		// PORT
			
			if( comCd.trim() == "" ) 
			{
				comCd = "1002";
			}
			
			actSock = new ActionSocket(new Socket(ip, port), (Filter)(new COMMConveyerFilter(COMMBiz.SSGPAY_FILTER)));
			actSock.getSocket().setSoTimeout(5000);
			strMessage = makeSSGPosaTran(map);
			
			// Data 전문을 바이트 배열로 변환
			sendBytes = strMessage.getBytes();
			sendBytes[899] = (byte)0x0d;
			
			logger.info("[sms>ssgmoney] POSA SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");
			
			/**
			 ** 1. 대사TRAN(1건) 송신
			 **/
			if (actSock.send(sendBytes, sendBytes.length)) 
			{
				logger.info("[sms>ssgmoney] POSA SEND[" + sendBytes.length + "] OK");
			}
			else 
			{
				logger.info("[sms>ssgmoney] POSA SEND[" + sendBytes.length + "] ERROR");
	
				throw new Exception("SSGMoney server is no response");
			}
			
			// 대사TRAN전문에 대한 응답 
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<ssgmoney] POSA RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");
			
			String respCode = recvBuf.substring(661, 665);
			
			logger.info("POSA SYS_YMD=[" + map.get("SYS_YMD") + "]");
			logger.info("POSA ST_CODE=[" + map.get("ST_CODE") + "]");
			logger.info("POSA TM_NO  =[" + map.get("TM_NO")   + "]");
			logger.info("POSA TRAN_NO=[" + map.get("TRAN_NO") + "]");
			logger.info("POSA COM_CD =[" + map.get("COM_CD")  + "]");

			logger.info("POSA respCode=[" + respCode + "]");
		     
			if (!respCode.equals("0000") && !respCode.equals("0015") && !respCode.equals("5170") && !respCode.equals("5160"))
			{
				dao.updSSGPOSATRAN_RESET( "9"
									     , (String)map.get("SYS_YMD")
									     , (String)map.get("ST_CODE")  // "00999" // kkk 1 운영적용시 확인 
									     , (String)map.get("TM_NO")
									     , (String)map.get("TRAN_NO")
									     , (String)map.get("COM_CD")); 

				logger.info("POSA 상태코드: 9");
			}
			else
			{
				dao.updSSGPOSATRAN_RESET( "1"
									     , (String)map.get("SYS_YMD")
									     , (String)map.get("ST_CODE")  // "00999" // kkk 2 운영적용시 확인
									     , (String)map.get("TM_NO")
									     , (String)map.get("TRAN_NO")
									     , (String)map.get("COM_CD"));

				logger.info("POSA 상태코드: 1");
			}
		}
		catch(Exception e) 
		{
			logger.info("", e);
		}
		finally 
		{
			
		}
	}
	
	public void transferToWeChat(Map<String, String> map) throws Exception 
	{
		ActionSocket actSock = null;
		SSGPayTranDAO dao = new SSGPayTranDAO();
		String strMessage = "";
		String recvBuf = "";
		byte sendBytes[] = null;
		String comCd = "";
		String ip = "";
		int port = 0;
		
		try {
			comCd = PropertyUtil.findProperty("stsys-property", "COM_CD");												// 회사코드
			ip = PropertyUtil.findProperty("communication-property", "SSGMONEY_APPRSVR_IP");							// IP
			port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "WECHAT_SVR_PORT"));		// PORT
			
			if( comCd.trim() == "" ) 
			{
				comCd = "1002";
			}
			
			actSock = new ActionSocket(new Socket(ip, port), (Filter)(new COMMConveyerFilter(COMMBiz.SSGPAY_FILTER)));
			actSock.getSocket().setSoTimeout(5000);
			strMessage = makeSSGPosaTran(map);
			
			// Data 전문을 바이트 배열로 변환
			sendBytes = strMessage.getBytes();
			sendBytes[899] = (byte)0x0d;
			
			logger.info("[sms>ssgmoney] WeChat SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");
			
			/**
			 ** 1. 대사TRAN(1건) 송신
			 **/
			if (actSock.send(sendBytes, sendBytes.length)) 
			{
				logger.info("[sms>ssgmoney] WeChat SEND[" + sendBytes.length + "] OK");
			}
			else 
			{
				logger.info("[sms>ssgmoney] WeChat SEND[" + sendBytes.length + "] ERROR");
	
				throw new Exception("SSGMoney server is no response");
			}
			
			// 대사TRAN전문에 대한 응답 
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<ssgmoney] WeChat RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");
			
			String respCode = recvBuf.substring(661, 665);
			
			logger.info("WeChat SYS_YMD=[" + map.get("SYS_YMD") + "]");
			logger.info("WeChat ST_CODE=[" + map.get("ST_CODE") + "]");
			logger.info("WeChat TM_NO  =[" + map.get("TM_NO")   + "]");
			logger.info("WeChat TRAN_NO=[" + map.get("TRAN_NO") + "]");
			logger.info("WeChat COM_CD =[" + map.get("COM_CD")  + "]");

			logger.info("WeChat respCode=[" + respCode + "]");
		     
			if (!respCode.equals("0000") && !respCode.equals("0015") && !respCode.equals("5170") && !respCode.equals("5160"))
			{
				dao.updWeChatTRAN_RESET( "9"
									     , (String)map.get("SYS_YMD")
									     , (String)map.get("ST_CODE")  // "00999" // kkk 1 운영적용시 확인 
									     , (String)map.get("TM_NO")
									     , (String)map.get("TRAN_NO")
									     , (String)map.get("COM_CD")); 

				logger.info("WeChat 상태코드: 9");
			}
			else
			{
				dao.updWeChatTRAN_RESET( "1"
									     , (String)map.get("SYS_YMD")
									     , (String)map.get("ST_CODE")  // "00999" // kkk 2 운영적용시 확인
									     , (String)map.get("TM_NO")
									     , (String)map.get("TRAN_NO")
									     , (String)map.get("COM_CD"));

				logger.info("WeChat 상태코드: 1");
			}
		}
		catch(Exception e) 
		{
			logger.info("", e);
		}
		finally 
		{
			
		}
	}
	
	public void transferToSSGMoney(Map<String, String> map) throws Exception {
		ActionSocket actSock = null;
		SSGPayTranDAO dao = new SSGPayTranDAO();
		String strMessage = "";
		String recvBuf = "";
		byte sendBytes[] = null;
		String comCd = "";
		String ip = "";
		int port = 0;
		
		try {
			comCd = PropertyUtil.findProperty("stsys-property", "COM_CD");												// 회사코드
			ip = PropertyUtil.findProperty("communication-property", "SSGMONEY_APPRSVR_IP");							// IP
			port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGMONEY_APPRSVR_PORT"));		// PORT
			
			if( comCd.trim() == "" ) {
				comCd = "1002";
			}
			actSock = new ActionSocket(new Socket(ip, port), (Filter)(new COMMConveyerFilter(COMMBiz.SSGPAY_FILTER)));
			actSock.getSocket().setSoTimeout(5000);
			strMessage = makeSSGMoneyTran(map);
			
			// Data 전문을 바이트 배열로 변환
			sendBytes = strMessage.getBytes();
			sendBytes[899] = (byte)0x0d;
			
			logger.info("[sms>ssgmoney] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");
			
			/**
			 ** 1. 대사TRAN(1건) 송신
			 **/
			if( actSock.send(sendBytes, sendBytes.length) ) {
				logger.info("[sms>ssgmoney] SEND[" + sendBytes.length + "] OK");
			}else {
				logger.info("[sms>ssgmoney] SEND[" + sendBytes.length + "] ERROR");
	
				throw new Exception("SSGMoney server is no response");
			}
			
			// 대사TRAN전문에 대한 응답
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<ssgmoney] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");
			
			logger.info("RESP_CD=" + recvBuf.substring(692, 696));
			
			if( !(recvBuf.substring(692, 696)).equals("0000") && !(recvBuf.substring(692, 696)).equals("5170")
				&& !(recvBuf.substring(692, 696)).equals("5160") )
			{
				logger.info((recvBuf.substring(696, 756)).trim());
				dao.updSSGMONEYTRAN_RESET( "9"
									     , (String)map.get("SYS_YMD")
									     , (String)map.get("ST_CODE")
									     , (String)map.get("TM_NO")
									     , (String)map.get("TRAN_NO")
									     , (String)map.get("COM_CD"));
			}else
			{
				dao.updSSGMONEYTRAN_RESET( "1"
									     , (String)map.get("SYS_YMD")
									     , (String)map.get("ST_CODE")
									     , (String)map.get("TM_NO")
									     , (String)map.get("TRAN_NO")
									     , (String)map.get("COM_CD"));
			}
		}catch(Exception e) {
			logger.info("", e);
		}finally {
			
		}
	}
	
	public void transferToSSGStaffDC(Map<String, String> map) throws Exception //20170220
	{
		logger.info("transferToSSGStaffDC");
		ActionSocket actSock = null;
		SSGPayTranDAO dao = new SSGPayTranDAO();
		String strMessage = "";
		String recvBuf = "";
		byte sendBytes[] = null;
		String comCd = "";
		String ip = "";
		int port = 0;

//		logger.info("map [" + map + "]");
		try {
			comCd = PropertyUtil.findProperty("stsys-property", "COM_CD");										// 회사코드
			ip = PropertyUtil.findProperty("communication-property", "STAFFCHK_COMM_IP");						// IP
			port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "STAFFCHK_COMM_PORT"));	// PORT
			
			if( comCd.trim() == "" ) 
			{
				comCd = "1002";
			}

//			logger.info("ip [" + ip + "]");
//			logger.info("port [" + port + "]");
			actSock = new ActionSocket(new Socket(ip, port), (Filter)(new COMMConveyerFilter(COMMBiz.STAFFCHECK_FILTER)));
			actSock.getSocket().setSoTimeout(5000);
			strMessage = makeStaffDCTran(map);
			
//			logger.info("chk1");

			
			// Data 전문을 바이트 배열로 변환
			sendBytes = strMessage.getBytes();
//			sendBytes[899] = (byte)0x0d;
			
			logger.info("[sms>ssgStaffInfo] STAFFTRAN SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");
			
			/** 
			 ** 1. 대사TRAN(1건) 송신
			 **/
			if (actSock.send(sendBytes, sendBytes.length)) 
			{
				logger.info("[sms>ssgStaffInfo] STAFFTRAN SEND[" + sendBytes.length + "] OK");
			}
			else 
			{
				logger.info("[sms>ssgStaffInfo] STAFFTRAN SEND[" + sendBytes.length + "] ERROR");
	
				throw new Exception("STAFFINFO server is no response");
			}
//			logger.info("chk2");
			// 대사TRAN전문에 대한 응답 
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<ssgmoney] STAFFDCTRAN RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");
			
			String respCode = recvBuf.substring(120, 124);
//			logger.info(respCode);
//			logger.info("STAFF SYS_YMD=[" + map.get("SYS_YMD") + "]");
//			logger.info("STAFF ST_CODE=[" + map.get("ST_CODE") + "]");
//			logger.info("STAFF TM_NO  =[" + map.get("TM_NO")   + "]");
//			logger.info("STAFF TRAN_NO=[" + map.get("TRAN_NO") + "]");
//			logger.info("STAFF COM_CD =[" + map.get("COM_CD")  + "]");

//			logger.info("STAFFDCTRAN respCode=[" + respCode + "]");
		     
			if (!respCode.equals("0000") && !respCode.equals("0015") && !respCode.equals("5170") && !respCode.equals("5160"))
			{
				logger.info("SYS_YMD"+(String)map.get("SYS_YMD"));
				logger.info("ST_CODE "+(String)map.get("ST_CODE"));
				logger.info("TM_NO "+(String)map.get("TM_NO"));
				logger.info("COM_CD "+(String)map.get("COM_CD"));
				
				dao.updSSGSTAFFDCTRAN_RESET( "9"
									     , (String)map.get("SYS_YMD")
									     , (String)map.get("STORE_CD")  // "00999" // kkk 1 운영적용시 확인 
									     , (String)map.get("POS_NO")
									     , (String)map.get("TRAN_NO")
									     , (String)map.get("COM_CD")); 

				logger.info("STAFFTRAN 상태코드: 9");
			}
			else
			{
				logger.info("SYS_YMD"+(String)map.get("SYS_YMD"));
				logger.info("ST_CODE "+(String)map.get("ST_CODE"));
				logger.info("TM_NO "+(String)map.get("TM_NO"));
				logger.info("COM_CD "+(String)map.get("COM_CD"));
				
				dao.updSSGSTAFFDCTRAN_RESET( "1"
									     , (String)map.get("SYS_YMD") 
									     , (String)map.get("STORE_CD")
									     , (String)map.get("POS_NO")
									     , (String)map.get("TRAN_NO")
									     , (String)map.get("COM_CD"));

				logger.info("STAFF 상태코드: 1");
			}
		}
		catch(Exception e) 
		{
			logger.info("", e);
		}
		finally 
		{

		}
	}
	
	private String makeSSGMoneyChgTran(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,8,8,20,15
					  ,4,4,8,6,10
					  ,4,4,4,10,8
					  ,6,20,8,6,53
					  ,2,2,24,1,100
					  ,3,100,50,2,12
					  ,1,1,1,2,4
					  ,20,4,8,10,4
					  ,4,4,8,20,15
					  ,8,8,8,6,8
					  ,12,30,4,60,12
					  ,48,60,2,21,1
					  };
		String strHeaders[] = {
				"MSG_LEN"				,
				"MSG_ID"				,
				"MCH_SEND_DATE"			,
				"MCHH_SEND_UNIQ_NO"		,
				"GIFT_MCH_NO"			,
				
				"MSG_GUBUN"				,
				"SER_COM_CD"			,
				"SALE_DATE"				,
				"SALE_TIME"				,
				"ST_CODE"				,
				
				"TM_NO"					,
				"CD_NO"					,
				"TRAN_NO"				,
				"CASHER_NO"				,
				"POS_DATE"				,
				
				"POS_TIME"				,
				"SER_COM_UNIQ_NO"		,
				"JUMPO_SYS_DATE"		,
				"JUMPO_SYS_TIME"		,
				"HEAD_ETC_FIELD"		,
				
				"TRAN_TYPE"				,
				"TRADE_TYPE"			,
				"EVENT_ETC_FIELD"		,
				"TRACK_TYPE"			,
				"BARCODE_ETC_FIELD"		,
				
				"BARCODE_CNT"			,
				"GIFT_CARD_NO"			,
				"GIFT_CONFIRM_NO"		,
				"KEY_IN_TYPE"			,
				"TRADE_AMT"				,
				
				"SPECIAL_GUBUN"			,
				"USE_GUBUN"				,				
				"GIFT_GUBUN"			,
				"PART_GUBUN"			,
				"GIFT_CODE"				,
				
				"GIFT_MOMILE_NO"		,
				"ORG_SER_COM_CD"		,				
				"ORG_SALE_DATE"			,
				"ORG_ST_CODE"			,
				"ORG_TM_NO"				,
				
				"ORG_TRAN_NO"			,
				"ORG_CD_NO"				,				
				"ORG_SEND_DATE"			,
				"ORG_SEND_UNIQ_NO"		,
				"ORG_GIFT_MCH_NO"		,
				
				"ORG_AUTH_DATE"			,
				"ORG_AUTH_NO"			,				
				"AUTH_DATE"				,
				"AUTH_TIME"				,
				"AUTH_NO"				,
				
				"REMAIN_AMT"			,
				"MD_CODE"				,				
				"RESP_CODE"				,
				"RESP_MSG"				,
				"REFUND_ABLE_AMT"		,
				
				"PLATFORM_BARCODE"		,				
				"AMT_ETC_FIELD"			,
				"PAY_TYPE"				,
				"DATA_ETC_FIELD"		,
				"MSG_END"				
		};
		
		try {
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String todayDT = sdf.format(calendar.getTime());
			String SSGPAY_COM_CD = "5700";
			String SSGPAY_GIFTFCSTR_ID = "";
			
			Seed seed = Seed.getInstance("CBC/PKCS5Padding");
			String keyData = PropertyUtil.findProperty("service-property", "KEY_DATA");
			String ivData = PropertyUtil.findProperty("service-property", "IV_DATA");
			seed.setKey(keyData.getBytes());
			seed.setIV(ivData.getBytes());
			BASE64Decoder decoder = new BASE64Decoder();
		
		
			SSGPAY_GIFTFCSTR_ID = PropertyUtil.findProperty("service-property", "SSGPAY_GIFTFCSTR_ID");
		
			/*
			 * 통합결제플랫폼 모바일상품권 회수요청전문 HEADER 구성
			 */
			map.put("MSG_LEN", "0900");												// 01. 전문길이(4)
			map.put("MSG_ID", "CGTS0200");											// 02. 전문ID(8)
	//		map.put("MCH_SEND_DATE", (String)map.get("MCH_SEND_DATE"));				// 03. 전문전송일자(8)
	//		map.put("MCHH_SEND_UNIQ_NO", (String)map.get("MCHH_SEND_UNIQ_NO"));		// 04. 전송거래고유번호(20)
			map.put("GIFT_MCH_NO", SSGPAY_GIFTFCSTR_ID);							// 05. 가맹점번호(15)
			map.put("MSG_GUBUN", "SEND");											// 06. 요청구분(4)
			map.put("SER_COM_CD", SSGPAY_COM_CD);									// 07. 회사코드(4)
	//		map.put("SALE_DATE", (String)map.get("SALE_DATE"));						// 08. 영업일자(8)
	//		map.put("SALE_IMTE", (String)map.get("SALE_IMTE"));						// 09. 영업시간(6)
	//		map.put("ST_CODE", (String)map.get("ST_CODE"));							// 10. 점코드(10)
	//		map.put("TM_NO", (String)map.get("TM_NO"));								// 11. 포스번호(4)
			map.put("CD_NO", "0000");												// 12. CD번호(4)
	//		map.put("TRAN_NO", (String)map.get("TRAN_NO"));							// 13. TRAN_NO(4)
			map.put("CASHER_NO", (String)map.get("ST_CODE"));						// 14. Casher번호(10)
	//		map.put("POS_DATE", (String)map.get("POS_DATE"));						// 15. POS시스템일자(8)
	//		map.put("POS_TIME", (String)map.get("POS_TIME"));						// 16. POS시스템시간(6)
			map.put("SER_COM_UNIQ_NO", " ");										// 17. 회사별요청자정보(20)
			map.put("JUMPO_SYS_DATE", todayDT.substring(0, 8));						// 18. 점포서버 전문전송일자(8)
			map.put("JUMPO_SYS_TIME", todayDT.substring(8, 14));					// 19. 점포서버 전문전송시간(6)
			map.put("HEAD_ETC_FIELD", " ");											// 20. 헤더예비필드(53)
			/*
			 * 통합결제플랫폼 모바일상품권 회수요청전문 DATA 구성
			 */
			map.put("TRAN_TYPE", (String)map.get("TRAN_TYPE"));						// 21. 거래TYPE(2)
			map.put("TRADE_TYPE", 
					((String)map.get("TRAN_TYPE")).equals("00") ? "27" : "67");		// 22. 요청TYPE(2)
			map.put("EVENT_ETC_FIELD", " ");										// 23. 행사예비필드(24)
			map.put("TRACK_TYPE", "3");												// 24. TRACK2 유무(1)
			map.put("BARCODE_ETC_FIELD", " ");										// 25. 바코드예비필드(100)
			map.put("BARCODE_CNT", "001");											// 26. 판매수량(3)
/*			
			map.put("GIFT_CARD_NO",
					new String(
							seed.decrypt(
									decoder.decodeBuffer(
											((String)map.get("GIFT_CARD_NO")).trim()
														)
										)
							   ));													// 27. GIFT카드번호(100)
*/							   
//			map.put("GIFT_CONFIRM_NO", (String)map.get("GIFT_CONFIRM_NO"));			// 28. GIFT인증번호(50)
			map.put("KEY_IN_TYPE", "05");											// 29. KEY_IN 유무(2)
			map.put("TRADE_AMT"
					, String.format("%012d", Long.parseLong((String)map.get("TRADE_AMT"))));// 30. 요청금액(12)
//			map.put("SPECIAL_GUBUN", "1");											// 31. 거래별 구분코드(1)
			map.put("USE_GUBUN", "1");												// 32. 사용구분(1)
			map.put("GIFT_GUBUN", "3");												// 33. 상품종류구분(1)
			map.put("PART_GUBUN", "60");											// 34. 제휴사구분코드(2)
			map.put("GIFT_CODE", (String)map.get("GIFT_CODE"));						// 35. 권종코드(4)
			map.put("GIFT_MOMILE_NO", " ");											// 36. 선물하기번호(20)
			map.put("ORG_SER_COM_CD", 
					((String)map.get("TRAN_TYPE")).equals("00") ? " " : SSGPAY_COM_CD);			// 37. 원거래 회사코드(4)
//			map.put("ORG_SALE_DATE", (String)map.get("ORG_SALE_DATE"));				// 38. 원거래 영업일자(8)
//			map.put("ORG_ST_CODE", (String)map.get("ORG_ST_CODE"));					// 39. 원거래 점코드(10)
//			map.put("ORG_TM_NO", (String)map.get("ORG_TM_NO"));						// 40. 원거래 포스번호(4)
//			map.put("ORG_TRAN_NO", (String)map.get("ORG_TRAN_NO"));					// 41. 원거래 거래번호(4)
			map.put("ORG_CD_NO", 
					((String)map.get("TRAN_TYPE")).equals("00") ? " " : (String)map.get("ORG_CD_NO"));// 42. 원거래 CD번호(4)
//			map.put("ORG_SEND_DATE", (String)map.get("ORG_SEND_DATE"));				// 43. 원거래 전문전송일자(8)
//			map.put("ORG_SEND_UNIQ_NO", (String)map.get("ORG_SEND_UNIQ_NO"));		// 44. 원거래전송거래고유번호(20)
			map.put("ORG_GIFT_MCH_NO", ((String)map.get("TRAN_TYPE")).equals("00") ? " " : SSGPAY_GIFTFCSTR_ID);	// 45. 원거래가맹점번호(15)
//			map.put("ORG_AUTH_DATE", (String)map.get("ORG_AUTH_DATE"));				// 46. 원거래 승인일자(8)
//			map.put("ORG_AUTH_NO", (String)map.get("ORG_AUTH_NO"));					// 47. 원거래 승인번호(8)
//			map.put("AUTH_DATE", (String)map.get("AUTH_DATE"));						// 48. 승인일자(8)
//			map.put("AUTH_TIME", (String)map.get("AUTH_TIME"));						// 49. 승인시간(6)
//			map.put("AUTH_NO", (String)map.get("AUTH_NO"));							// 50. 승인번호(8)
			map.put("REMAIN_AMT" 
					, String.format("%012d", Long.parseLong((String)map.get("REMAIN_AMT"))));// 51. 상품권잔액금액(12)
			map.put("MD_CODE", " ");												// 52. 회사별물품코드(30)
			map.put("RESP_CODE", " ");												// 53. 응답코드(4)
			map.put("RESP_MSG", " ");												// 54. 응답메시지(60)
			map.put("REFUND_ABLE_AMT", " ");										// 55. 환불가능금액(12)
//			map.put("PLATFORM_BARCODE", (String)map.get("PLATFORM_BARCODE"));		// 56. 통합플랫폼바코드(48)
			map.put("AMT_ETC_FIELD", " ");											// 57. 금액관련 예비필드(60)
			map.put("PAY_TYPE", "11");												// 58. 결제수단(2)
			map.put("DATA_ETC_FIELD", " ");											// 59. DATA예비필드(21)
			map.put("MSG_END", " ");												// 60. 전문종료내역(1)
			
			for (int i = 0; i < nlens.length; i++) {
//				logger.info("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) map.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) map.get(strHeaders[i].toString()), nlens[i]);
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return sb.toString();
	}
	
	private String makeSSGPosaTran(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {4,8,8,20,15
				 ,4,4,8,6,10
				 
				 ,4,4,4,10,8
				 ,6,20,8,6,53
				 
				 ,2,2,1,50,50
				 ,100,50,2,12,1
				 
				 ,1,1,2,20,4
				 ,8,10,4,4,4
				 
				 ,8,20,15,8,8
				 ,8,6,8,12,30
				 
				 ,4,60,32,12,130
				 ,1
			};
		
        String strHeaders[] = {
                "MSG_LEN"           , // 01. 전문 길이
                "MSG_ID"            , // 02. 전문 ID
                "MCH_SEND_DATE"     , // 03. 전문전송일자
                "MCH_SEND_UNIQ_NO"  , // 04. 전송거래고유번호
                "POSA_MCH_NO"       , // 05. 가맹점번호

                "MSG_GUBUN"         , // 06. 요청구분
                "SER_COM_CD"        , // 07. 회사코드
                "SALE_DATE"         , // 08. 영업일자
                "SALE_TIME"         , // 09. 영업시간
                "ST_CODE"           , // 10. 점코드

                "TM_NO"             , // 11. 포스 번호
                "CD_NO"             , // 12. CD 번호
                "TRAN_NO"           , // 13. 거래 번호
                "CASHER_NO"         , // 14. Casher 번호
                "POS_DATE"          , // 15. POS시스템일자

                "POS_TIME"          , // 16. POS시스템시간
                "SER_COM_UNIQ_NO"   , // 17. 회사별 요청자 정보
                "JUMPO_SYS_DATE"    , // 18. 점포서버 전문전송일자
                "JUMPO_SYS_TIME"    , // 19. 점포서버 전문전송시간
                "HEAD_ETC_FIELD"    , // 20. 헤더예비필드

                "TRAN_TYPE"         , // 21. 거래 TYPE
                "TRADE_TYPE"        , // 22. 요청 TYPE
                "TRACK_TYPE"        , // 23. TRACK 유무
                "START_BARCODE"     , // 24. 시작바코드
                "END_BARCODE"       , // 25. 종료바코드

                "POSA_CARD_NO"      , // 26. POSA 카드 번호
                "POSA_CONFIRM_NO"   , // 27. PIN 번호
                "KEY_IN_TYPE"       , // 28. KEY IN 유무
                "TRADE_AMT"         , // 29. 요청금액
                "SPECIAL_GUBUN"     , // 30. 거래별 구분 코드

                "USE_GUBUN"         , // 31. 사용구분
                "POSA_GUBUN"        , // 32. 상품종류구분
                "PART_GUBUN"        , // 33. 제휴사구분코드
                "POSA_MOBILE_NO"    , // 34. 선물하기 번호
                "ORG_SER_COM_CD"    , // 35. 원거래 회사코드

                "ORG_SALE_DATE"     , // 36. 원거래 영업일자
                "ORG_ST_CODE"       , // 37. 원거래 점코드
                "ORG_TM_NO"         , // 38. 원거래 포스 번호
                "ORG_TRAN_NO"       , // 39. 원거래 거래 번호
                "ORG_CD_NO"         , // 40. 원거래 CD 번호

                "ORG_SEND_DATE"     , // 41. 원거래 전문전송 일자
                "ORG_SEND_UNIQ_NO"  , // 42. 원거래 전송 거래고유번호
                "ORG_POSA_MCH_NO"   , // 43. 원거래 가뱅점번호
                "ORG_AUTH_DATE"     , // 44. 원거래 승일일자
                "ORG_AUTH_NO"       , // 45. 원거래 승인번호

                "AUTH_DATE"         , // 46. 승인일자
                "AUTH_TIME"         , // 47. 승인시간
                "AUTH_NO"           , // 48. 승인번호
                "REMAIN_AMT"        , // 49. 상품권잔액
                "MD_CODE"           , // 50. 회사별 상품 코드

                "RESP_CODE"         , // 51. 응답코드
                "RESP_MSG"          , // 52. 응답메시지
                "EXT_POSA_CARD_NO"  , // 53. 외부 발행 카드 번호
                "EVENT_AMT"         , // 54. 행사 할인금액
                "DATA_ETC_FIELD"    , // 55. DATA 예비필드

                "MSG_END"             // 56. 전문종료내역
            };
		
		try 
		{
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String todayDT = sdf.format(calendar.getTime());
			
			map.put("MSG_LEN", "0900");      // 01. 전문길이(4)
			map.put("MSG_ID", "PSTS0200");   // 02. 전문ID(8)
			map.put("MCH_SEND_DATE", map.get("TRAN_YMD")); // 03. 전문전송일자(8)
			map.put("MCH_SEND_UNIQ_NO", map.get("MCH_SEND_UNIQ_NO")); // 04. 전송거래고유번호(20)
			
			map.put("POSA_MCH_NO", "FM00010770");      // 05. 가맹점번호(15)  ==> 운영적용시 확인 (kkk 3)
			map.put("MSG_GUBUN", "SEND");              // 06. 요청구분(4)

			map.put("SER_COM_CD", "5700");     // 07. 회사코드(4)  5700:위드미
			
			map.put("SALE_DATE", map.get("SALE_DATE")); // 08. 영업일자(8) 
			map.put("SALE_TIME", map.get("SALE_TIME"));  // 09. 영업시간(6)
			
			map.put("ST_CODE", map.get("ST_CODE"));   // 10. 점코드(10)
//			map.put("ST_CODE", "00000");   // 10. 점코드(10)   ==> 운영적용시 확인 (kkk 4)
			
			map.put("TM_NO", map.get("TM_NO"));       // 11. POS 번호(4)
			map.put("CD_NO", "0000");                  // 12. CD 번호(4)
			map.put("TRAN_NO", map.get("TRAN_NO"));    // 13. 거래 번호(4)

			map.put("CASHER_NO", (String) map.get("CASHER_NO")); // 14. Casher 번호(10) (POS)
//			map.put("CASHER_NO", "00000"); // 14. Casher 번호(10) (POS) ==> 운영적용시 확인 (kkk 5)
			
			map.put("POS_DATE", map.get("POS_DATE")); // 15. POS시스템일자(8)
			map.put("POS_TIME", map.get("POS_TIME")); // 16. POS시스템시간(6)
			
			map.put("SER_COM_UNIQ_NO", " "); // 17. 회사별 요청자 정보(20) (불필요: SPACE로 채움)
			map.put("JUMPO_SYS_DATE", todayDT.substring(0, 8));  // 18. 점포서버 전문전송일자(8)
			map.put("JUMPO_SYS_TIME", todayDT.substring(8, 14)); // 19. 점포서버 전문전송시간(6)
			map.put("HEAD_ETC_FIELD", " "); // 20. 헤더예비필드(53) (불필요: SPACE로 채움)

			map.put("TRAN_TYPE", map.get("TRAN_TYPE")); // 21. 거래 TYPE(2) (00:승인, 01:취소)
			map.put("TRADE_TYPE", map.get("TRADE_TYPE")); // 22. 요청 TYPE(2) (29:활성화, 69:활성화취소)
			
			map.put("TRACK_TYPE", "3"); // 23. TRACK 유무(1) (2:연번바코드, 3:카드번호)
			map.put("START_BARCODE", " "); // 24. 시작바코드(50) (불필요: SPACE로 채움)
			map.put("END_BARCODE", " "); // 25. 종료바코드(50) (불필요: SPACE로 채움)
			
			map.put("POSA_CARD_NO", map.get("POSA_CARD_NO")); // 26. POSA 카드 번호(100) (POS)
			map.put("POSA_CONFIRM_NO", " "); // 27. PIN 번호(50) ("활성화/취소"를 제외하고는 필수)
//			map.put("KEY_IN_TYPE", map.get("KEY_IN_TYPE")); // 28. KEY IN 유무(2) (POS)
			map.put("KEY_IN_TYPE", "05"); // 28. KEY IN 유무(2) (POS)   05:BARCODE
			
			String tradeAmt = StringUtil.lPad(map.get("TRADE_AMT").trim(), 12, "0");
			logger.info("tradeAmt=[" + tradeAmt + "]");
			map.put("TRADE_AMT", tradeAmt); // 29. 요청금액(12) (POS)
			
			map.put("SPECIAL_GUBUN", "1"); // 30. 거래별 구분 코드(1) (1:일반, 2:유효기간만료폐기)

			map.put("USE_GUBUN", "1"); // 31. 사용구분(1) (회수일때 1:일반회수, 3:폐기회수) (판매일때 1:일반판매)
			map.put("POSA_GUBUN", map.get("POSA_GUBUN")); // 32. 상품종류구분(1) (POS)
			map.put("PART_GUBUN", " "); // 33. 제휴사구분코드(2)
			map.put("POSA_MOBILE_NO", " "); // 34. 선물하기 번호(20)

			//------------------------------------------
			// 활성화취소시 필수, 그외에는 SPACE
			//------------------------------------------
			String tranType = map.get("TRAN_TYPE"); // 00:활성화, 01:활성화취소
			if (tranType.equals("00")) // 활성화 이면
			{
				map.put("ORG_SER_COM_CD", " ");   // 35. 원거래 회사코드
				map.put("ORG_SALE_DATE", " ");    // 36. 원거래 영업일자
				map.put("ORG_ST_CODE", " ");      // 37. 원거래 점코드
				map.put("ORG_TM_NO", " ");        // 38. 원거래 포스 번호
				map.put("ORG_TRAN_NO", " ");      // 39. 원거래 거래 번호
				map.put("ORG_CD_NO", " ");        // 40. 원거래 CD 번호
				map.put("ORG_SEND_DATE", " ");    // 41. 원거래 전문전송 일자
				map.put("ORG_SEND_UNIQ_NO", " "); // 42. 원거래 전송 거래고유번호
				map.put("ORG_POSA_MCH_NO", " ");  // 43. 원거래 가맹점번호
				map.put("ORG_AUTH_DATE", " ");    // 44. 원거래 승일일자
				map.put("ORG_AUTH_NO", " ");      // 45. 원거래 승인번호맹
			}
			else
			{
				map.put("ORG_SER_COM_CD", "5700"); // 35. 원거래 회사코드 (POS)  5700:위드미
				
				map.put("ORG_SALE_DATE", (String) map.get("ORG_SALE_DATE"));       // 36. 원거래 영업일자 (POS)

				map.put("ORG_ST_CODE", (String) map.get("ORG_ST_CODE"));           // 37. 원거래 점코드 (POS)
//				map.put("ORG_ST_CODE", "00000");           // 37. 원거래 점코드 (POS) ==> 운영적용시 확인 kkk 6
				
				map.put("ORG_TM_NO", (String) map.get("ORG_TM_NO"));               // 38. 원거래 포스 번호 (POS)
				map.put("ORG_TRAN_NO", (String) map.get("ORG_TRAN_NO"));           // 39. 원거래 거래 번호 (POS)
				map.put("ORG_CD_NO", (String) map.get("ORG_CD_NO"));               // 40. 원거래 CD 번호 (POS)
				map.put("ORG_SEND_DATE", (String) map.get("ORG_SEND_DATE"));       // 41. 원거래 전문전송 일자 (POS)
				map.put("ORG_SEND_UNIQ_NO", (String) map.get("ORG_SEND_UNIQ_NO")); // 42. 원거래 전송 거래고유번호 (POS)
				
//				map.put("ORG_POSA_MCH_NO", " ");          // 43. 원거래 가맹점번호 (불필요: SAPCE로 채움)
				map.put("ORG_POSA_MCH_NO", "FM00010770"); // 43. 원거래 가맹점번호 (불필요: SAPCE로 채움)   ==> 운영적용시 확인 (kkk 7)
				
				map.put("ORG_AUTH_DATE", (String) map.get("ORG_AUTH_DATE"));       // 44. 원거래 승인일자 (POS)
				map.put("ORG_AUTH_NO", (String) map.get("ORG_AUTH_NO"));           // 45. 원거래 승인번호 (POS)
			}

			map.put("AUTH_DATE", map.get("AUTH_DATE"));   // 46. 승인일자
			map.put("AUTH_TIME", map.get("AUTH_TIME"));   // 47. 승인시간
			map.put("AUTH_NO", map.get("AUTH_NO"));       // 48. 승인번호
			
			
			String remainAmt = StringUtil.lPad(map.get("REMAIN_AMT").trim(), 12, "0");
			logger.info("remainAmt=[" + remainAmt + "]");
			map.put("REMAIN_AMT", remainAmt); // 49. 상품권잔액
			
			
			map.put("MD_CODE", map.get("MD_CODE"));       // 50. 회사별 상품 코드 (POS)

			map.put("RESP_CODE", " ");        // 51. 응답코드
			map.put("RESP_MSG", " ");         // 52. 응답메시지
			map.put("EXT_POSA_CARD_NO", " "); // 53. 외부 발행 카드 번호
			
			String eventAmt = StringUtil.lPad(map.get("EVENT_AMT").trim(), 12, "0");
			logger.info("eventAmt=[" + eventAmt + "]");
			map.put("EVENT_AMT", eventAmt); // 54. 행사 할인금액 (POS)
			
			map.put("DATA_ETC_FIELD", " ");   // 55. DATA 예비필드

			map.put("MSG_END", " "); // 56. 전문종료내역
			
			for (int i = 0; i < nlens.length; i++) 
			{
				logger.info((i+1) + ") " + "["+strHeaders[i]+"]=" + map.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) map.get(strHeaders[i].toString()), nlens[i]);
			}
		}
		catch(Exception e) 
		{
			logger.info("[ERROR]" + e);
		}
		
		return sb.toString();
	}
	
	private String makeSSGMoneyTran(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,8,8,20,15
					  ,4,4,8,6,10
					  ,4,4,4,10,8
					  ,6,20,8,6,53
					  ,2,2,2,2,20
					  ,1,50,50,3,100
					  ,50,2,12,1,1
					  ,1,2,4,20,4
					  ,8,10,4,4,4
					  ,8,20,15,8,8
					  ,8,6,8,12,30
					  ,4,60,12,48,12
					  ,12,12,12,12,23
					  ,1};
		String strHeaders[] = {
				"MSG_LEN"				,
				"MSG_ID"				,
				"MCH_SEND_DATE"			,
				"MCHH_SEND_UNIQ_NO"		,
				"GIFT_MCH_NO"			,
				
				"MSG_GUBUN"				,
				"SER_COM_CD"			,
				"SALE_DATE"				,
				"SALE_TIME"				,
				"ST_CODE"				,
				
				"TM_NO"					,
				"CD_NO"					,
				"TRAN_NO"				,
				"CASHER_NO"				,
				"POS_DATE"				,
				
				"POS_TIME"				,
				"SER_COM_UNIQ_NO"		,
				"JUMPO_SYS_DATE"		,
				"JUMPO_SYS_TIME"		,
				"HEAD_ETC_FIELD"		,
				
				"TRAN_TYPE"				,
				"TRADE_TYPE"			,
				"EVENT_GUBUN"			,
				"EVENT_TYPE"			,
				"EVENT_NO"				,
				
				"TRACK_TYPE"			,
				"START_BARCODE"			,
				"END_BARCODE"			,
				"BARCODE_CNT"			,
				"GIFT_CARD_NO"			,
				
				"GIFT_CONFIRM_NO"		,
				"KEY_IN_TYPE"			,
				"TRADE_AMT"				,
				"SPECIAL_GUBUN"			,
				"USE_GUBUN"				,
				
				"GIFT_GUBUN"			,
				"PART_GUBUN"			,
				"GIFT_CODE"				,
				"GIFT_MOMILE_NO"		,
				"ORG_SER_COM_CD"		,
				
				"ORG_SALE_DATE"			,
				"ORG_ST_CODE"			,
				"ORG_TM_NO"				,
				"ORG_TRAN_NO"			,
				"ORG_CD_NO"				,
				
				"ORG_SEND_DATE"			,
				"ORG_SEND_UNIQ_NO"		,
				"ORG_GIFT_MCH_NO"		,
				"ORG_AUTH_DATE"			,
				"ORG_AUTH_NO"			,
				
				"AUTH_DATE"				,
				"AUTH_TIME"				,
				"AUTH_NO"				,
				"REMAIN_AMT"			,
				"MD_CODE"				,
				
				"RESP_CODE"				,
				"RESP_MSG"				,
				"REFUND_ABLE_AMT"		,
				"PLATFORM_BARCODE"		,
				"NORM_REF_AMT"			,
				
				"NORM_REF_FEE"			,
				"SWAP_REF_AMT"			,
				"SWAP_REF_FEE"			,
				"FREE_REF_AMT"			,
				"DATA_ETC_FIELD"		,
				
				"MSG_END"				
		};
		
		try {
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String todayDT = sdf.format(calendar.getTime());
			String SSGPAY_COM_CD = "5700";
			String SSGPAY_GIFTFCSTR_ID = "";
			
			Seed seed = Seed.getInstance("CBC/PKCS5Padding");
			String keyData = PropertyUtil.findProperty("service-property", "KEY_DATA");
			String ivData = PropertyUtil.findProperty("service-property", "IV_DATA");
			seed.setKey(keyData.getBytes());
			seed.setIV(ivData.getBytes());
			BASE64Decoder decoder = new BASE64Decoder();
		
		
			SSGPAY_GIFTFCSTR_ID = PropertyUtil.findProperty("service-property", "SSGPAY_GIFTFCSTR_ID");
		
		
			/*
			 * 통합결제플랫폼 모바일상품권 회수요청전문 HEADER 구성
			 */
			map.put("MSG_LEN", "0900");												// 01. 전문길이(4)
			map.put("MSG_ID", "PGTU0200");											// 02. 전문ID(8)
	//		map.put("MCH_SEND_DATE", (String)map.get("MCH_SEND_DATE"));				// 03. 전문전송일자(8)
	//		map.put("MCHH_SEND_UNIQ_NO", (String)map.get("MCHH_SEND_UNIQ_NO"));		// 04. 전송거래고유번호(20)
			map.put("GIFT_MCH_NO", SSGPAY_GIFTFCSTR_ID);							// 05. 가맹점번호(15)
			map.put("MSG_GUBUN", "SEND");											// 06. 요청구분(4)
			map.put("SER_COM_CD", SSGPAY_COM_CD);									// 07. 회사코드(4)
	//		map.put("SALE_DATE", (String)map.get("SALE_DATE"));						// 08. 영업일자(8)
	//		map.put("SALE_IMTE", (String)map.get("SALE_IMTE"));						// 09. 영업시간(6)
	//		map.put("ST_CODE", (String)map.get("ST_CODE"));							// 10. 점코드(10)
	//		map.put("TM_NO", (String)map.get("TM_NO"));								// 11. 포스번호(4)
			map.put("CD_NO", "0000");												// 12. CD번호(4)
	//		map.put("TRAN_NO", (String)map.get("TRAN_NO"));							// 13. TRAN_NO(4)
	//		map.put("CASHER_NO", (String)map.get("CASHER_NO"));						// 14. Casher번호(10)
	//		map.put("POS_DATE", (String)map.get("POS_DATE"));						// 15. POS시스템일자(8)
	//		map.put("POS_TIME", (String)map.get("POS_TIME"));						// 16. POS시스템시간(6)
			map.put("SER_COM_UNIQ_NO", " ");										// 17. 회사별요청자정보(20)
			map.put("JUMPO_SYS_DATE", todayDT.substring(0, 8));						// 18. 점포서버 전문전송일자(8)
			map.put("JUMPO_SYS_TIME", todayDT.substring(8, 14));					// 19. 점포서버 전문전송시간(6)
			map.put("HEAD_ETC_FIELD", " ");											// 20. 헤더예비필드(53)
			/*
			 * 통합결제플랫폼 모바일상품권 회수요청전문 DATA 구성
			 */
			map.put("TRAN_TYPE", (String)map.get("TRAN_TYPE"));						// 21. 거래TYPE(2)
			map.put("TRADE_TYPE", 
					((String)map.get("TRAN_TYPE")).equals("00") ? "25" : "65");		// 22. 요청TYPE(2)
			map.put("EVENT_GUBUN", " ");											// 23. 행사구분(2)
			map.put("EVENT_TYPE", " ");												// 24. 행사타입(2)
			map.put("EVENT_NO", " ");												// 25. 행사번호(20)
			map.put("TRACK_TYPE", "3");												// 26. TRACK2 유무(1)
			map.put("START_BARCODE", " ");											// 27. 시작바코드(50)
			map.put("END_BARCODE", " ");											// 28. 종료바코드(50)
			map.put("BARCODE_CNT", "001");											// 29. 판매수량(3)
			map.put("GIFT_CARD_NO",
					new String(
							seed.decrypt(
									decoder.decodeBuffer(
											((String)map.get("GIFT_CARD_NO")).trim()
														)
										)
							   ));													// 30. GIFT카드번호(100)
//			map.put("GIFT_CONFIRM_NO", (String)map.get("GIFT_CONFIRM_NO"));			// 31. GIFT인증번호(50)
			map.put("KEY_IN_TYPE", "05");											// 32. KEY_IN 유무(2)
			map.put("TRADE_AMT"
					, String.format("%012d", Long.parseLong((String)map.get("TRADE_AMT"))));// 33. 요청금액(12)
			map.put("SPECIAL_GUBUN", "1");											// 34. 미수수료구분(1)
			map.put("USE_GUBUN", "1");												// 35. 사용구분(1)
			map.put("GIFT_GUBUN", "3");												// 36. 상품종류구분(1)
			map.put("PART_GUBUN", "60");											// 37. 제휴사구분코드(2)
			map.put("GIFT_CODE", (String)map.get("GIFT_CODE"));						// 38. 권종코드(4)
			map.put("GIFT_MOMILE_NO", " ");											// 39. 선물하기번호(20)
//			map.put("ORG_SER_COM_CD", (String)map.get("ORG_SER_COM_CD"));			// 40. 원거래 회사코드(4)
//			map.put("ORG_SALE_DATE", (String)map.get("ORG_SALE_DATE"));				// 41. 원거래 영업일자(8)
//			map.put("ORG_ST_CODE", (String)map.get("ORG_ST_CODE"));					// 42. 원거래 점코드(10)
//			map.put("ORG_TM_NO", (String)map.get("ORG_TM_NO"));						// 43. 원거래 포스번호(4)
//			map.put("ORG_TRAN_NO", (String)map.get("ORG_TRAN_NO"));					// 44. 원거래 거래번호(4)
			map.put("ORG_CD_NO", 
					((String)map.get("TRAN_TYPE")).equals("00") ? " " : (String)map.get("ORG_CD_NO"));// 45. 원거래 CD번호(4)
//			map.put("ORG_SEND_DATE", (String)map.get("ORG_SEND_DATE"));				// 46. 원거래 전문전송일자(8)
//			map.put("ORG_SEND_UNIQ_NO", (String)map.get("ORG_SEND_UNIQ_NO"));		// 47. 원거래전송거래고유번호(20)
			map.put("ORG_GIFT_MCH_NO", " ");										// 48. 원거래가맹점번호(15)
//			map.put("ORG_AUTH_DATE", (String)map.get("ORG_AUTH_DATE"));				// 49. 원거래 승인일자(8)
//			map.put("ORG_AUTH_NO", (String)map.get("ORG_AUTH_NO"));					// 50. 원거래 승인번호(8)
//			map.put("AUTH_DATE", (String)map.get("AUTH_DATE"));						// 51. 승인일자(8)
//			map.put("AUTH_TIME", (String)map.get("AUTH_TIME"));						// 52. 승인시간(6)
//			map.put("AUTH_NO", (String)map.get("AUTH_NO"));							// 53. 승인번호(8)
			map.put("REMAIN_AMT" 
					, String.format("%012d", Long.parseLong((String)map.get("REMAIN_AMT"))));// 54. 상품권잔액금액(12)
			map.put("MD_CODE", " ");												// 55. 회사별물품코드(30)
			map.put("RESP_CODE", " ");												// 56. 응답코드(4)
			map.put("RESP_MSG", " ");												// 57. 응답메시지(60)
			map.put("REFUND_ABLE_AMT", " ");										// 58. 환불가능금액(12)
//			map.put("PLATFORM_BARCODE", (String)map.get("PLATFORM_BARCODE"));		// 59. 통합플랫폼바코드(48)
			map.put("NORM_REF_AMT", " ");											// 60. 일반상품권금액(12)
			map.put("NORM_REF_FEE", " ");											// 61. 일반상품권환불수수료(12)
			map.put("SWAP_REF_AMT", " ");											// 62. 전환상품권금액(12)
			map.put("SWAP_REF_FEE", " ");											// 63. 전환상품권환불수수료(12)
			map.put("FREE_REF_AMT", " ");											// 64. 무상금액(12)
			map.put("DATA_ETC_FIELD", " ");											// 65. DATA예비필드(23)
			map.put("MSG_END", " ");												// 66. 전문종료내역(1)
			
			for (int i = 0; i < nlens.length; i++) {
//				logger.info("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) map.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) map.get(strHeaders[i].toString()), nlens[i]);
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return sb.toString();
	}
	
	private String makeSSGPayTranHeader(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= { 4, 8, 8, 24, 4
					 , 2, 4, 15, 8, 6
					 , 10, 4, 4, 4, 4
					 , 10, 8, 6, 6, 4
					 , 30, 4, 30, 8, 6
					 , 20, 20, 20, 8, 6
					 , 4, 60, 3, 30, 4, 20, 84 };
		String strHeaders[] = { 
				"MSG_LEN", "MSG_ID", "MCH_SEND_DATE", "MCH_SEND_UNIQ_NO", "MSG_GUBUN"
			  , "TRAN_TYPE", "SER_COM_CD", "TERM_ID", "SALE_DATE", "SALE_TIME"
			  , "ST_CODE", "TM_NO", "SHOP_NO", "CD_NO", "TRAN_NO"
			  , "CASHER_NO", "POS_DATE", "POS_TIME", "NORMAL_GUBUN", "BUY_FIRM_CODE"
			  , "BUY_FIRM_NM", "ISSUE_FIRM_CODE", "ISSUE_FIRM_NM", "CARD_SYS_DATE", "CARD_SYS_TIME"
			  , "CARD_UNIQ_NO", "CARD_MCH_NO", "SER_COM_UNIQ_NO", "JUMPO_SYS_DATE", "JUMPO_SYS_TIME"
			  , "RESP_CODE", "RESP_MSG", "BANK_CODE", "BANK_NM", "BANK_VAN_FLAG", "PLATFORM_M_ID", "HEAD_ETC_FIELD"};
		
		map.put("MSG_LEN", "1600");										// 1. 전문길이
		map.put("MSG_ID", (String)map.get("MSG_ID"));					// 2. 전문ID
		map.put("MCH_SEND_DATE", (String)map.get("SEND_DATE"));			// 3. 전문전송일자
		map.put("MCH_SEND_UNIQ_NO", (String)map.get("SEND_UNIQ_NO"));	// 4. 전송거래고유번호
		map.put("MSG_GUBUN", "SEND");									// 5. 요청구분(요청:SEND, 응답:RECV)
		map.put("TRAN_TYPE", (String)map.get("DEAL_TYPE"));				// 6. 거래TYPE(승인:00, 오타:01, 반품:02)
		map.put("SER_COM_CD", "5700");									// 7. 회사코드
		map.put("TERM_ID", (String)map.get("TERMINAL_ID"));				// 8. 터미널ID
		map.put("SALE_DATE", (String)map.get("SALE_DATE"));				// 9. 영업일자
		map.put("SALE_TIME", (String)map.get("SALE_TIME"));				// 10. 영업시간
		map.put("ST_CODE", (String)map.get("STORE_CD"));				// 11. 점코드
		map.put("TM_NO", (String)map.get("POS_NO"));					// 12. 포스번호
		map.put("SHOP_NO", "0000");										// 13. 매장번호
		map.put("CD_NO", "0000");										// 14. CD번호
		map.put("TRAN_NO", (String)map.get("TRAN_NO"));					// 15. 거래번호
		map.put("CASHER_NO", (String)map.get("CASHIER_NO"));			// 16. CASHIER번호
		map.put("POS_DATE", (String)map.get("SYS_YMD"));				// 17. POS시스템일자
		map.put("POS_TIME", (String)map.get("SYS_HMS"));				// 18. POS시스템시간
		map.put("NORMAL_GUBUN", "NORMAL");								// 19. 정상예외구분
		map.put("BUY_FIRM_CODE", "    " );									// 20. 매입사
		map.put("BUY_FIRM_NM", "                              " );									// 21. 매입사명
		map.put("ISSUE_FIRM_CODE", "    " );								// 22. 발행사
		map.put("ISSUE_FIRM_NM", "                              ");									// 23. 발행사명
		map.put("CARD_SYS_DATE", "        " );									// 24. 카드사요청일자
		map.put("CARD_SYS_TIME", "      ");									// 25. 카드사요청시간
		map.put("CARD_UNIQ_NO", (String)map.get("CARD_UNIQ_NO") );									// 26. 카드사요청고유번호
		map.put("CARD_MCH_NO", "                    ");									// 27. 카드사가맹점번호
		map.put("SER_COM_UNIQ_NO", "                    " );								// 28. 회사별 요청자 정보
		map.put("JUMPO_SYS_DATE", (String)map.get("SYS_YMD"));			// 29. 점포서버 전문전송일자
		map.put("JUMPO_SYS_TIME", (String)map.get("SYS_HMS"));			// 30. 점포서버 전문전송시간
		map.put("RESP_CODE", "    ");										// 31. 응답코드
		map.put("RESP_MSG", "                                                            " );										// 32. 응답메시지    
		map.put("BANK_CODE", (String)map.get("BANK_CODE") );										// 33. 은행코드(3)       
		map.put("BANK_NM", (String)map.get("BANK_NM"));										// 34. 은행사명(30)    
		map.put("BANK_VAN_FLAG", (String)map.get("BANK_VAN_FLAG"));									// 35. 금융VAN구분(4)  
		map.put("PLATFORM_M_ID", (String)map.get("PLATFORM_M_ID"));									// 36. 플랫폼연동가맹점ID(20)    
		map.put("HEAD_ETC_FIELD", "" );									// 33. 헤더예비필드
		
		for (int i = 0; i < nlens.length; i++) {
//			logger.info("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) map.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) map.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSSGPayTranData(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 64, 50, 50, 1, 1
					  , 32, 1, 1, 64, 1
					  , 1, 64, 12, 8, 12
					  , 8, 12, 1, 1, 2
					  , 64, 2, 12, 8, 20
					  , 32, 32, 8, 20, 1
					  , 1, 32, 1, 12, 8
					  , 24, 4, 8, 10, 4
					  , 4, 4, 4, 10, 12
					  , 12, 12, 4, 50, 100
					  , 1, 1, 2, 1, 1
					  , 1, 96, 12, 8, 15
					  , 15, 8, 15, 2, 1
					  , 1, 1, 8, 9, 1};

		String strHeaders[] = {
				"DELEGATE_BARCODE_NO", "RECEIPT_NO", "ORG_RECEIPT_NO", "EMP_ID_NO_PLAT_YN", "EMP_ID_NO_USE_YN"
			  , "EMP_ID_NO", "S_POINT_PLAT_YN", "S_POINT_USE_YN", "S_POINT_CARD_NO", "M_GIFT_CARD_PLAT_YN"
			  , "M_GIFT_CARD_USE_YN", "M_GIFT_CARD_NO", "M_GIFT_USE_AMT", "M_GIFT_AUTH_DATE", "M_GIFT_AUTH_NO"
			  , "ORG_M_GIFT_AUTH_DATE", "ORG_M_GIFT_AUTH_NO", "CREDIT_CARD_PLAT_YN", "CREDIT_CARD_YN", "CARD_CERT_FLAG"
			  , "CREDIT_CARD_NO", "CREDIT_CARD_INS_MON", "CREDIT_CARD_USE_AMT", "CREDIT_CARD_AUTH_DATE", "CREDIT_CARD_AUTH_NO"
			  , "CREDIT_CARD_RECEIPT_A", "CREDIT_CARD_RECEIPT_D", "ORG_CREDIT_CARD_AUTH_DATE", "ORG_CREDIT_CARD_AUTH_NO", "CASH_RECEIPT_INFO_PLAT_YN"
			  , "CASH_RECEIPT_INFO_USE_YN", "CASH_RECEIPT_INFO", "ETC_PAY_YN", "ETC_PAY_AMT", "ORG_SEND_DATE"
			  , "ORG_SEND_UNIQ_NO", "ORG_SER_COM_CD", "ORG_SALE_DATE", "ORG_ST_CODE", "ORG_TM_NO"
			  , "ORG_SHOP_NO", "ORG_CD_NO", "ORG_TRAN_NO", "ORG_CASHIER_NO", "TOT_TRADE_AMT"
			  , "DIS_TRADE_AMT", "NET_TRADE_AMT", "MD_CNT", "MD_CODE", "MD_NAME"
			  , "EVENT_MD_IN_YN", "EVENT_YN", "CNCL_GUBUN", "CNCL_USE_YN", "BANK_PLAT_YN"
			  , "BANK_YN", "BANK_ACCOUNT_NO", "BANK_USE_AMT", "BANK_AUTH_DATE", "BANK_AUTH_NO"
			  , "BANK_RECEIPT", "ORG_BANK_AUTH_DATE", "ORG_BANK_AUTH_NO", "BANK_CNCL_GUBUN", "BANK_CNCL_USE_YN"
			  , "SSGPAY_CP_PLAT_YN", "SSGPAY_CP_USE_YN", "SSGPAY_CP_AMT", "DATA_ETC_FIELD", "MSG_END"};
		
		map.put("DELEGATE_BARCODE_NO", (String)map.get("BARCODE_NO_ENCRPT"));				// 34. 통합바코드번호
		map.put("RECEIPT_NO", (String)map.get("TRAN_YMD")
							+ (String)map.get("STORE_CD")
							+ (String)map.get("POS_NO")
							+ (String)map.get("TRAN_NO"));
		map.put("ORG_RECEIPT_NO", (String)map.get("ORG_SALE_DT")
								+ (String)map.get("ORG_ST_CODE")
								+ (String)map.get("ORG_TM_NO")
								+ (String)map.get("ORG_TRAN_NO"));
		map.put("EMP_ID_NO_PLAT_YN", (String)map.get("EMPID_PLAT_YN"));
		map.put("EMP_ID_NO_USE_YN", (String)map.get("EMPID_USE_YN"));
		
		map.put("EMP_ID_NO", (String)map.get("EMPID_NO_ENCRPT"));
		map.put("S_POINT_PLAT_YN", (String)map.get("SPOINT_PLAT_YN"));
		map.put("S_POINT_USE_YN", (String)map.get("SPOINT_USE_YN"));
		map.put("S_POINT_CARD_NO", (String)map.get("SPOINT_NO_ENCRPT"));
		map.put("M_GIFT_CARD_PLAT_YN", (String)map.get("MGIFT_PLAT_YN"));
		
		map.put("M_GIFT_CARD_USE_YN", (String)map.get("MGIFT_USE_YN"));
		map.put("M_GIFT_CARD_NO", (String)map.get("MGIFT_NO_ENCRPT"));
		map.put("M_GIFT_USE_AMT", String.format("%012d", Long.parseLong((String)map.get("MGIFT_AMT"))));
		map.put("M_GIFT_AUTH_DATE", (String)map.get("MGIFT_AUTH_DT"));
		map.put("M_GIFT_AUTH_NO", (String)map.get("MGIFT_AUTH_NO"));
		
		map.put("ORG_M_GIFT_AUTH_DATE", (String)map.get("ORG_MGIFT_AUTH_DT"));
		map.put("ORG_M_GIFT_AUTH_NO", (String)map.get("ORG_MGIFT_AUTH_NO"));
		map.put("CREDIT_CARD_PLAT_YN", (String)map.get("CCARD_PLAT_YN"));
		map.put("CREDIT_CARD_YN", (String)map.get("CCARD_USE_YN"));
		map.put("CARD_CERT_FLAG", (String)map.get("CCARD_CERT_TP"));
		
		map.put("CREDIT_CARD_NO", (String)map.get("CCARD_NO_ENCRPT"));
		map.put("CREDIT_CARD_INS_MON", (String)map.get("CCARD_INS_MON"));
		map.put("CREDIT_CARD_USE_AMT", String.format("%012d", Long.parseLong((String)map.get("CCARD_AMT"))));
		map.put("CREDIT_CARD_AUTH_DATE", (String)map.get("CCARD_AUTH_DT"));
		map.put("CREDIT_CARD_AUTH_NO", (String)map.get("CCARD_AUTH_NO"));
		
		map.put("CREDIT_CARD_RECEIPT_A", (String)map.get("CCARD_RCPT_A_ENCRPT"));
		map.put("CREDIT_CARD_RECEIPT_D", (String)map.get("CCARD_RCPT_D_ENCRPT"));
		map.put("ORG_CREDIT_CARD_AUTH_DATE", (String)map.get("ORG_CCARD_AUTH_DT"));
		map.put("ORG_CREDIT_CARD_AUTH_NO", (String)map.get("ORG_CCARD_AUTH_NO"));
		map.put("CASH_RECEIPT_INFO_PLAT_YN", (String)map.get("CASHRCPT_INFO_PLAT_YN"));
		
		map.put("CASH_RECEIPT_INFO_USE_YN", (String)map.get("CASHRCPT_INFO_USE_YN"));
		map.put("CASH_RECEIPT_INFO", (String)map.get("CASHRCPT_INFO_ENCRPT"));
		map.put("ETC_PAY_YN", (String)map.get("ETC_PAY_YN"));
		map.put("ETC_PAY_AMT", String.format("%012d", Long.parseLong((String)map.get("ETC_PAY_AMT"))));
		map.put("ORG_SEND_DATE", (String)map.get("ORG_SEND_DT"));
		
		map.put("ORG_SEND_UNIQ_NO", (String)map.get("ORG_SEND_UNIQ_NO"));
		map.put("ORG_SER_COM_CD", (String)map.get("ORG_SER_COM_CD"));
		map.put("ORG_SALE_DATE", (String)map.get("ORG_SALE_DT"));
		map.put("ORG_ST_CODE", (String)map.get("ORG_ST_CODE"));
		map.put("ORG_TM_NO", (String)map.get("ORG_TM_NO"));
		
		map.put("ORG_SHOP_NO", (String)map.get("ORG_SHOP_NO"));
		map.put("ORG_CD_NO", (String)map.get("ORG_CD_NO"));
		map.put("ORG_TRAN_NO", (String)map.get("ORG_TRAN_NO"));
		map.put("ORG_CASHIER_NO", (String)map.get("ORG_CASHIER_NO"));
		map.put("TOT_TRADE_AMT", String.format("%012d", Long.parseLong((String)map.get("TOT_TRADE_AMT"))));
		
		map.put("DIS_TRADE_AMT", String.format("%012d", Long.parseLong((String)map.get("DIS_TRADE_AMT"))));
		map.put("NET_TRADE_AMT", String.format("%012d", Long.parseLong((String)map.get("NET_TRADE_AMT"))));
		map.put("MD_CNT", String.format("%04d", Integer.parseInt((String)map.get("MD_CNT"))));
		map.put("MD_CODE", (String)map.get("MD_CODE"));
		map.put("MD_NAME", (String)map.get("MD_NAME"));
		
		//20170620 SSGPAY 상시할인정보 EVENT_YN 치환전송 추가 START
		if(!"".equals((String)map.get("DC_MD_IN_YN"))){
			map.put("EVENT_MD_IN_YN", (String)map.get("DC_MD_IN_YN"));
		}else{
			map.put("EVENT_MD_IN_YN", (String)map.get("EVT_MD_IN_YN"));
		}
		
		if(!"".equals((String)map.get("SSGPAY_DC_YN"))){
			map.put("EVENT_YN", (String)map.get("SSGPAY_DC_YN"));
		}else{
			map.put("EVENT_YN", (String)map.get("EVT_YN"));
		}
		//20170620 SSGPAY 상시할인정보 EVENT_YN 치환전송 추가 END
		
		map.put("CNCL_GUBUN", (String)map.get("BANK_CNCL_GUBUN"));
		map.put("CNCL_USE_YN", (String)map.get("BANK_CNCL_USE_YN"));		
		map.put("BANK_PLAT_YN", (String)map.get("BANK_PLAT_YN"));
		
		map.put("BANK_YN", (String)map.get("BANK_YN"));
		map.put("BANK_ACCOUNT_NO", (String)map.get("BANK_ACCOUNT_NO"));			
		map.put("BANK_USE_AMT", StringUtil.lPad((String)map.get("BANK_USE_AMT").trim(), 12, "0")); //		map.put("BANK_USE_AMT", (String)map.get("BANK_USE_AMT"));
		map.put("BANK_AUTH_DATE", (String)map.get("BANK_AUTH_DATE"));
		map.put("BANK_AUTH_NO", (String)map.get("BANK_AUTH_NO"));
		
		map.put("BANK_RECEIPT", (String)map.get("BANK_RECEIPT"));
		map.put("ORG_BANK_AUTH_DATE", (String)map.get("ORG_BANK_AUTH_DATE"));
		map.put("ORG_BANK_AUTH_NO", (String)map.get("ORG_BANK_AUTH_NO"));
		map.put("BANK_CNCL_GUBUN", (String)map.get("BANK_CNCL_GUBUN"));
		map.put("BANK_CNCL_USE_YN", (String)map.get("BANK_CNCL_USE_YN"));
		
		//20170614 SSGPAY 상시할인/PLCC 추가 START
		map.put("SSGPAY_CP_PLAT_YN", (String)map.get("SSGPAY_CP_PLAT_YN"));
		map.put("SSGPAY_CP_USE_YN", (String)map.get("SSGPAY_CP_USE_YN"));
		map.put("SSGPAY_CP_AMT", (String)map.get("SSGPAY_CP_AMT"));
		//20170614 SSGPAY 상시할인/PLCC 추가 END
		map.put("DATA_ETC_FIELD", " ");
		map.put("MSG_END", " ");
		
		logger.info("★ DC_MD_IN_YN : ["+map.get("DC_MD_IN_YN")+"]");
		logger.info("★ EVENT_MD_IN_YN : ["+map.get("EVENT_MD_IN_YN")+"]");
		logger.info("★ SSGPAY_DC_YN : ["+map.get("SSGPAY_DC_YN")+"]");
		logger.info("★ EVENT_YN : ["+map.get("EVENT_YN")+"]");
		logger.info("★ SSGPAY_CP_PLAT_YN : ["+map.get("SSGPAY_CP_PLAT_YN")+"]");
		logger.info("★ SSGPAY_CP_USE_YN : ["+map.get("SSGPAY_CP_USE_YN")+"]");
		logger.info("★ SSGPAY_CP_AMT : ["+map.get("SSGPAY_CP_AMT")+"]");
		
		for (int i = 0; i < nlens.length; i++) {
//			logger.info("★ make send strHeaders : ["+strHeaders[i]+"]["+ (String) map.get(strHeaders[i].toString())+"]");
			StringUtil.appendSpace(sb, (String) map.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeStaffDCTran(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {4, 8, 10, 4, 8
					, 6, 4, 4, 4, 10
					, 4, 20, 20, 8, 6
					, 2, 1, 10, 80, 1
					, 12, 12, 12, 8, 4
					, 4, 4, 20, 1, 20
					, 10, 10, 50, 50, 10
					, 50, 4, 50, 100, 55
			};
		
        String strHeaders[] = {
//HEADER        		
                "MSG_LEN",			// 01. 전문 길이 "0700"
                "MSG_ID",			// 02. 전문 ID "AUTH1800"
                "SER_COM_CD",		// 03. 회사코드 "CV0       "
                "MSG_GUBUN",		// 04. 요청구분 "SEND"
                "SALE_DATE",		// 05. 영업일자 "YYYYMMDD" (String)hm.get("REG_YMD")

                "SALE_TIME",		// 06. 영업시간 "24HMISS" (String)hm.get("REG_HMS")
                "ST_CD",			// 07. 점코드 "   " + (String)hm.get("STORE_CODE").substring(0, 1)
                "ST_CD2",			// 08. 점포서버번호 (String)hm.get("STORE_CODE").substring(1, 5)
                "POS_NO",			// 09. 포스번호 (String)hm.get("POS_NO")
                "CASHER_NO",		// 10. Casher번호 "          "

                "TRAN_NO",			// 11. 거래번호 "    "
                "COM_TRAN_NO",		// 12. 회사별 거래번호 (String)hm.get("REG_YMD") + (String)hm.get("POS_NO") + (String)hm.get("REG_HMS") + "  "
                "COM_ADD_INFO",		// 13. 회사별 추가정보 "                    "
                "TRAN_SEND_DATE",	// 14. 전문전송일자 (String)hm.get("REG_YMD")
                "TRAN_SEND_TIME",	// 15. 전문전송시간 (String)hm.get("REG_HMS")
//DATA    
                "TRAN_TYPE",		// 16. 거래 TYPE "00"
                "CONF_GUBUN",		// 17. 인증방법구분 (String)hm.get("CONF_GUBUN")
                "ELEC_STAFF",		// 18. 전자사원증 (String)hm.get("ELEC_STAFF")
                "CARD_INFO",		// 19. 신용카드 (String)hm.get("CARD_NO")
                "KEY_IN_YN",		// 20. KEY IN 유무 (String)hm.get("KEY_IN")

                "TOTAL_AMT",		// 21. 총매출금액 "000000000000"
                "AMT",				// 22. 순매출금액 "000000000000"
                "SALE_AMT",			// 23. 직원 할인 금액 "000000000000"
                "ORG_SALE_DATE",	// 24. 원거래 영업일자	(String)hm.get("ORG_TRAN_DATE")
                "ORG_ST_CODE",		// 25. 원거래 점코드	
                
                "ORG_TM_NO",		// 26. 원거래 포스번호	(String)hm.get("ORG_POS_NO")
                "ORG_TRAN_NO",		// 27. 원거래 거래번호	(String)hm.get("ORG_TRAN_NO")
                "ORG_SEND_UNIQ_NO",	// 28. 원거래 고유번호	(String)hm.get("REQ_TRANNO")
                "AUTH_ID",			// 29. 승인주체
                "AUTH_NO",			// 30. 승인번호
                
                "EMPLOYEE_ID",		// 31. 사번		"10BYTE그대로"
                "COMP_CD",			// 32. 소속사코드	"10BYTE그대로"
                "COMP_NM",			// 33. 소속사명	"                                                  "
                "EMPLOYEE_NM",		// 34. 이름		"                                                  "
                "RANK_CD",			// 35. 직급코드	"          "
                
                "RANK_NM",			// 36. 직급명		"                                                  "
                "MD_CNT",			// 37. 회사별 물품수
                "MD_CODE",			// 38. 회사별 물품코드
                "MD_NM",			// 39. 회사별 물품명
                "FILLER"			// 40. FILLER	"                                                       "
            };
		
		try 
		{
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String todayDT = sdf.format(calendar.getTime());
//HEADER			
//			logger.info("ORG_TRAN_DATE [" + (String)map.get("SYS_YMD") + "]");
			map.put("MSG_LEN", "0700");      										// 01. 전문길이(4)
			map.put("MSG_ID", "AUTH1800");   										// 02. 전문ID(8)
			map.put("SER_COM_CD", "CV0       ");									// 03. 회사코드(8)
			map.put("MSG_GUBUN","SEND");											// 04. 요청구분(20)
			map.put("SALE_DATE", (String)map.get("TRAN_YMD"));						// 05. pos시스템일자 "YYYYMMDD"
			
			map.put("SALE_TIME", (String)map.get("REG_DATETIME").substring(8, 14));	// 06. 영업시간 "24HMISS" (String)hm.get("REG_HMS")                                                             
			map.put("ST_CD", (String)map.get("STORE_CD").substring(1, 5));	// 07. 점코드 "   " + (String)hm.get("STORE_CODE").substring(0, 1)                                             
			map.put("ST_CD2", (String)map.get("STORE_CD").substring(0, 1) );			// 08. 점포서버번호 (String)hm.get("STORE_CODE").substring(1, 5)                                                  
			map.put("POS_NO", (String)map.get("POS_NO"));							// 09. 포스번호 (String)hm.get("POS_NO")                                                                        
			map.put("CASHER_NO", " ");										// 10. CASHER번호
			                                                                                                                                            
			map.put("TRAN_NO", (String)map.get("TRAN_NO"));							// 11. 거래번호
			map.put("COM_TRAN_NO", (String)map.get("SYS_YMD")+(String)map.get("STORE_CD")+(String)map.get("POS_NO").substring(2, 4)+ (String)map.get("TRAN_NO"));							// 12. 회사별 거래번호 (String)hm.get("SYS_YMD") + (String)hm.get("POS_NO") + (String)hm.get("REG_HMS") + "  "     
			map.put("COM_ADD_INFO", " ");      					// 13. 회사별 추가정보 
			map.put("TRAN_SEND_DATE", todayDT.substring(0, 8));    					// 14. 전문전송일자 (String)hm.get("REG_YMD")                                                                     
			map.put("TRAN_SEND_TIME", todayDT.substring(8, 14));    				// 15. 전문전송시간 (String)hm.get("REG_HMS")                                                                     
//DATA			                                                                                                                                            
			map.put("TRAN_TYPE", (String)map.get("APLLY_GUBUN"));					// 16. 거래 TYPE 승인:00, 취소:02
			map.put("CONF_GUBUN", "5");												// 17. 인증방법구분 (String)hm.get("CONF_GUBUN")
			map.put("ELEC_STAFF", " ");									// 18. 전자사원증 (String)hm.get("ELEC_STAFF")                                                                   
			map.put("CARD_INFO", " ");// 19. 신용카드 (String)hm.get("CARD_NO")                                                                       
			map.put("KEY_IN_YN", "1");												// 20. KEY IN 유무 (String)hm.get("KEY_IN")                                                                   
			                                                                                                                                            
			map.put("TOTAL_AMT", String.format("%012d", Integer.parseInt((String)map.get("GSALE_AMT").trim())));									// 21. 총매출금액 "000000000000"                                                                                 
			map.put("AMT", String.format("%012d", Integer.parseInt((String)map.get("NSALE_AMT").trim())));											// 22. 순매출금액 "000000000000"                                                                                 
			map.put("SALE_AMT", String.format("%012d", Integer.parseInt((String)map.get("DC_AMT").trim())));							// 23. 직원 할인 금액 "000000000000"    

//			logger.info("ORG_TRAN_DATE [" + (String)map.get("ORG_TRAN_DATE").trim() + "]");
			if("".equals((String)map.get("ORG_TRAN_DATE").trim())){
				map.put("ORG_SALE_DATE", " ");						// 24. 원거래 영업일자	(String)hm.get("ORG_TRAN_DATE")                                                             
				map.put("ORG_ST_CODE", " ");	// 25. 원거래 점코드, 원거래고유번호(승인요청번호)에서 가져옴        
				map.put("ORG_TM_NO", " ");         			// 26. 원거래 포스번호	(String)hm.get("ORG_POS_NO")                                                                
				map.put("ORG_TRAN_NO", " ");       			// 27. 원거래 거래번호	(String)hm.get("ORG_TRAN_NO")    
				map.put("ORG_SEND_UNIQ_NO", " ");					// 28. 원거래 고유번호	(String)hm.get("REQ_TRANNO")                                                                
			}else{
				map.put("ORG_SALE_DATE", (String)map.get("ORG_TRAN_DATE"));						// 24. 원거래 영업일자	(String)hm.get("ORG_TRAN_DATE")                                                             
				map.put("ORG_ST_CODE", (String)map.get("STORE_CD").substring(1, 5));	// 25. 원거래 점코드, 원거래고유번호(승인요청번호)에서 가져옴                     
				map.put("ORG_TM_NO", (String)map.get("ORG_POS_NO"));         			// 26. 원거래 포스번호	(String)hm.get("ORG_POS_NO")                                                                
				map.put("ORG_TRAN_NO", (String)map.get("ORG_TRAN_NO"));       			// 27. 원거래 거래번호	(String)hm.get("ORG_TRAN_NO")    
				map.put("ORG_SEND_UNIQ_NO", (String)map.get("ORG_TRAN_DATE")+(String)map.get("STORE_CD")+(String)map.get("ORG_POS_NO").substring(2, 4)+ (String)map.get("ORG_TRAN_NO"));					// 28. 원거래 고유번호	(String)hm.get("REQ_TRANNO")                                                                
			}
			
			map.put("AUTH_ID", "2");												// 29. 승인주체                                                                                                 
			map.put("AUTH_NO", " ");								// 30. 승인번호
			                                         
			map.put("EMPLOYEE_ID", new AES().decrypt((String)map.get("EMPLOYEE_NO").trim()));		// 31. 사번		"10BYTE그대로"
			map.put("COMP_CD", (String)map.get("COMP_CD"));									// 32. 소속사코드	"10BYTE그대로"                                                                                 
			map.put("COMP_NM", " ");		// 33. 소속사명	                                            
			map.put("EMPLOYEE_NM", " ");	// 34. 이름		                                        
			map.put("RANK_CD", " ");           									// 35. 직급코드
			                                                                                                                                            
			map.put("RANK_NM", " ");		// 36. 직급명	
			map.put("MD_CNT", (String)map.get("PLU_CNT"));            											// 37. 회사별 물품수
			map.put("MD_CODE", (String)map.get("PLU_CD"));		// 38. 회사별 물품코드
			map.put("MD_NM", (String)map.get("ITEM_NM"));// 39. 회사별 물품명                                                                                              
			map.put("FILLER", " ");	// 40. FILLER

			for (int i = 0; i < nlens.length; i++) 
			{
//				logger.info((i+1) + ") " + "["+strHeaders[i]+"]=" + map.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) map.get(strHeaders[i].toString()), nlens[i]);
			}
		}
		catch(Exception e) 
		{
			logger.info("[ERROR]" + e);
		}
		
		return sb.toString();
	}
}
