package biz.cms_MCBIrt;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class MCBIrtDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(MCBIrtDAO.class);
	
	public List<Object> getBizCoNo(String co_cd, String store_cd) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			logger.info("co_cd[" + co_cd + "]"); 
			//DB Connection(DB 접속)
			connect("CMGNS"); 

			logger.info("store_cd[" + store_cd + "]");
			sql.put(findQuery("service-sql", "SEL_HQBIZLOCMST")); //★★★★★★★쿼리추가

			sql.setString(++i, co_cd);
			sql.setString(++i, store_cd);
			logger.info("getBizCoNo");

			logger.info("sql[" + sql.debug() + "]");
			list = executeQuery(sql);
			logger.info("getBizCoNo list[" + list + "]");
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return list;
	}
	
	
}