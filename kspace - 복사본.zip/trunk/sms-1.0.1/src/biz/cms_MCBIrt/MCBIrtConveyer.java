package biz.cms_MCBIrt;

import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sun.org.apache.xerces.internal.impl.dv.util.*;
//import com.sshtools.j2ssh.util.Base64;

import biz.comm.AES;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.BasicStringFilter;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil; 



public class MCBIrtConveyer {
	private static final byte[] pbszIV = null;
	private Socket svrSock = null;
	private ActionSocket actSock = null;

	COMMLog df = null;
	byte pIV[] = {(byte)0x65, (byte)0x6D, (byte)0x61, (byte)0x72, (byte)0x74, (byte)0x32
            , (byte)0x34, (byte)0x5E, (byte)0x32, (byte)0x43, (byte)0x32, (byte)0x21
            , (byte)0x31, (byte)0x30, (byte)0x30, (byte)0x32};
	
	byte pMK[] =  {(byte)0x45, (byte)0x2D, (byte)0x4D, (byte)0x41, (byte)0x52
			     , (byte)0x54, (byte)0x21, (byte)0x32, (byte)0x34, (byte)0x24
			     , (byte)0x64, (byte)0x6C, (byte)0x61, (byte)0x6B, (byte)0x78, (byte)0x6D};
	 
	 

	public MCBIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}
	
	// ==================================== 모바일 문화 상품권 잔액 조회 START ================================================
	// 모바일 문화 상품권 잔액 조회 ( 서버 -> 문화진흥원 )
	// 인자 : 공통코드(50bytes) ,  보낼 데이터 셋 ( POS에서 보낸 실시간 데이터 송신 전문 파싱 )
	// 공통코드와 pos에서 받은 데이터를 가지고 문화진흥원에 보낼 데이터를 만들어 넣음
	// 만들어 낼 데이터대로만 만들어주면 됨
	public String getMCBBalanceSnd(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		MCBIrtProtocol protocol = new MCBIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		KISA_SEED_CBC seed= new KISA_SEED_CBC();
		
		String sendMsg = "";	// 문화진흥원로 보낼 송신 전문
		String recvBuf = "";	// 문화진흥원에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		
		String decPinscrachno = "";	// pos 송신 문화진흥원 번호
		String encPinscrachno = "";	// pos 송신 문화진흥원 번호
		String encSendMsg = "";	// 문화진흥원 송신 전문(암호화)
		String encSendMsg1 = "";	// 문화진흥원 송신 전문(암호화)
		
		byte[] enc  = null;
		byte[] enc2 = null;
		
		String ret = "00";
		
		byte[] encTest = null;
		
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.MCB_FILTER)));
//HEADER	
			hm.put("HEADNO"			, "9110"); 								//4  : 전문번호
			hm.put("MESSAGELENGTH"	, "0392");								//4  : membercode 부터 끝가지 400 - 8
//DATA
			hm.put("MEMBERCODE"		, "EMART24");							//7  : 컬처랜드에서 제공 받아야 함 "EMART24"

			// 복호화 할 놈을 Base64.decode로 감싸고 복호화 seed.SEED_CBC_Decrypt
			enc = Base64.decode(hm.get("PINSCRACHNO").trim());
			
			decPinscrachno = new String( seed.SEED_CBC_Decrypt(pMK, pIV, enc, 0, enc.length ) ) ;
			hm.put("PINSCRACHNO"		, decPinscrachno);							//7  : 컬처랜드에서 제공 받아야 함 "EMART24"

			//전송할 포멧으로 변경
			sendMsg = makeSendDataMCBBalanceSnd(hm);
			// 여기에서 1~15까지는 암호화 없이 보내고, 그 이후부터 암호화 해서 보냄.

			// 암호화 한 놈을 encode로 감싸고 스트링 으로 만들어서 던진다.
			encSendMsg = new String( Base64.encode(
										seed.SEED_CBC_Encrypt(pMK, pIV
												               , sendMsg.substring(15, sendMsg.length()).getBytes()   		// 암호화 데이터
												               , 0 															// 암호화 시작위치
												               , sendMsg.substring(15, sendMsg.length()).getBytes().length  // 암호화 사이즈 
																)
													)
									);
			encSendMsg1 = sendMsg.substring(0, 15) + encSendMsg ;
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = encSendMsg1.getBytes();

			if( actSock.send(encSendMsg1) ) {
				df.CommLogger("[server>mcb] SEND[" + sendBytes.length + "] OK");
			}else {
				df.CommLogger("[server>mcb] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("MCB server is no response");
			}
	
			// 수신 받아옴.
			recvBuf = ((String)actSock.receive());
			recvBuf = recvBuf.trim();
			df.CommLogger("[server<mcb] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			df.CommLogger("chk");
			
			// 1. 수신 받은 데이터중 앞에 15바이트는 복호화 제외 대상
			// 2. 15바이트 이후 데이터는 복호화 대상
			// 복호화 할 놈을 Base64.decode로 감싸고 복호화 seed.SEED_CBC_Decrypt
			enc2 = Base64.decode(recvBuf.substring(15, recvBuf.getBytes().length));
			recvBuf = recvBuf.substring(0, 15) + new String( seed.SEED_CBC_Decrypt(pMK, pIV, enc2, 0, enc2.length ) ) ;
//			df.CommLogger("[server<mcb] 2222recvBuf["+recvBuf+"]");
			//받아온 데이터를 파싱해서 json 식으로 등록해주고
			hmRecv = protocol.getParseBalanceMCBRcv(recvBuf);
			encPinscrachno = new String( Base64.encode(
					seed.SEED_CBC_Encrypt(pMK, pIV
							               , hmRecv.get("PINSCRACHNO").trim().getBytes()   		 // 암호화 데이터
							               , 0 													 // 암호화 시작위치
							               , hmRecv.get("PINSCRACHNO").trim().getBytes().length  // 암호화 사이즈 
											)
								)
				);
			hmRecv.put("PINSCRACHNO", encPinscrachno.replaceAll("\n", "")); // 암호화된 녀석을 다시 넣어줌
			
			hmRecv.put("INQ_TYPE", "F7"); // 잔액조회 응답
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			// JSON 식으로 되어있는 데이터를 보내준다. POS로
			dataMsg = ret + makeSendDataMCBBalanceRcvRsp(hmRecv);
			df.CommLogger("★ make(to POS): " + dataMsg);
		}	
		return dataMsg;
	}
	
	// 문화 진흥원에 전송용 데이터로 설정 (SERVER -> 문화진흥원)
	private String makeSendDataMCBBalanceSnd(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,4,7
				 	,20,10,40,4,16
				 	,8,6,1,15,265
				 	};
		String strHeaders[] = {
				//HEADER				
				"HEADNO",
				"MESSAGELENGTH",
				//BODY
				"MEMBERCODE",
				
				"STORECODE",
				"SUBMEMBERCODE",
				"SUBMEMBERNAME",
				"POSCODE",
				"PINSCRACHNO",
				
				"REQUESTDATE",
				"REQUESTTIME",
				"INPUTTYPE",
				"MEMBERIP",
				"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ makeSendDataMCBBalanceSnd : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//POS 에 내리기 위한 문자열 전문 생성 ( pos <- 서버 )
	private String makeSendDataMCBBalanceRcvRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,20,10,40,4
	               ,4,80,9,9,8
	               ,6,60,199};
		String strHeaders[] = {
			  "INQ_TYPE"
			, "STORECODE"
			, "SUBMEMBERCODE"
			, "SUBMEMBERNAME"
			, "POSCODE"
			
			, "RESULTCODE"
			, "PINSCRACHNO"
			, "PINFACEVALUE"
			, "PINBALANCE"
			, "RESPONSEDATE"
			
			, "RESPONSETIME"
			, "ERRORMESSAGE"
			, "FILLER"
		};
	
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ makeSendDataMCBBalanceRcvRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// ==================================== 모바일 문화 상품권 잔액 조회 END ================================================
	

	// ==================================== 모바일 문화 상품권 사용요청 START ================================================
	// 모바일 문화 상품권 잔액 조회 ( 서버 -> 문화진흥원 )
	// 인자 : 공통코드(50bytes) ,  보낼 데이터 셋 ( POS에서 보낸 실시간 데이터 송신 전문 파싱 )
	// 공통코드와 pos에서 받은 데이터를 가지고 문화진흥원에 보낼 데이터를 만들어 넣음
	// 만들어 낼 데이터대로만 만들어주면 됨
	public String getMCBUseSnd(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		MCBIrtProtocol protocol = new MCBIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		KISA_SEED_CBC seed= new KISA_SEED_CBC();
		
		String sendMsg = "";	// 문화진흥원로 보낼 송신 전문
		String recvBuf = "";	// 문화진흥원에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		String decPinscrachno = "";	// pos에수 수신한 문화진흥원 번호
		String encPinscrachno = "";	// pos 송신 문화진흥원 번호
		
		String encSendMsg = "";	// 문화진흥원 송신 전문(암호화)
		String encSendMsg1 = "";	// 문화진흥원 송신 전문(암호화)
		
		byte[] enc  = null;
		byte[] enc2 = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.MCB_FILTER)));
//HEADER	
			hm.put("HEADNO"			, "9210"); 								//4  : 전문번호
			hm.put("MESSAGELENGTH"	, "0392");								//4  : membercode 부터 끝가지 400 - 8
//DATA
			hm.put("MEMBERCODE"		, "EMART24");							//7  : 컬처랜드에서 제공 받아야 함 "EMART24"
			
			
			
			// 복호화 할 놈을 Base64.decode로 감싸고 복호화 seed.SEED_CBC_Decrypt
			enc = Base64.decode(hm.get("PINSCRACHNO").trim());
			// pin 번호 복호화
			decPinscrachno = new String( seed.SEED_CBC_Decrypt(pMK, pIV, enc, 0, enc.length ) ) ;
			hm.put("PINSCRACHNO"		, decPinscrachno);							//7  : 컬처랜드에서 제공 받아야 함 "EMART24"
			
			//전송할 포멧으로 변경( 1 포맷 변경, 2 암호화)
			sendMsg = makeSendDataMCBUseSnd(hm);
			
			// 암호화 한 놈을 encode로 감싸고 스트링 으로 만들어서 던진다.
			encSendMsg = new String( Base64.encode(
										seed.SEED_CBC_Encrypt(pMK, pIV
												               , sendMsg.substring(15, sendMsg.length()).getBytes()   		// 암호화 데이터
												               , 0 															// 암호화 시작위치
												               , sendMsg.substring(15, sendMsg.length()).getBytes().length  // 암호화 사이즈 
																)
													)
									);
			encSendMsg1 = sendMsg.substring(0, 15) + encSendMsg ;
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = encSendMsg1.getBytes();
			
			if( actSock.send(encSendMsg1) ) {
				df.CommLogger("[server>mcb] SEND[" + sendBytes.length + "] OK");
			}else {
				df.CommLogger("[server>mcb] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("MCB server is no response");
			}
			

			
			recvBuf = ((String)actSock.receive());
			recvBuf = recvBuf.trim();
			df.CommLogger("[server<mcb] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			df.CommLogger("chk");
			// 수신한 데이터를 복호화
			// 1. 수신 받은 데이터중 앞에 15바이트는 복호화 제외 대상
			// 2. 15바이트 이후 데이터는 복호화 대상
			
			// 복호화 할 놈을 Base64.decode로 감싸고 복호화 seed.SEED_CBC_Decrypt
			enc2 = Base64.decode(recvBuf.substring(15, recvBuf.getBytes().length));
			recvBuf = recvBuf.substring(0, 15) + new String( seed.SEED_CBC_Decrypt(pMK, pIV, enc2, 0, enc2.length ) ) ;
			
			
			//받아온 데이터를 파싱해서 json 식으로 등록해주고
			hmRecv = protocol.getParseBalanceMCBRcv(recvBuf);
			
			// 받아온 pin 번호를 다시 암호화. 하여 pos에서 받을수 있도록 변경
			encPinscrachno = new String( Base64.encode(
					seed.SEED_CBC_Encrypt(pMK, pIV
							               , hmRecv.get("PINSCRACHNO").trim().getBytes()   		 // 암호화 데이터
							               , 0 													 // 암호화 시작위치
							               , hmRecv.get("PINSCRACHNO").trim().getBytes().length  // 암호화 사이즈 
											)
								)
				);
			//암호화 후에 나오는 특수 문자 제거. 엔터.
			hmRecv.put("PINSCRACHNO", encPinscrachno.replaceAll("\n", "")); // 암호화된 녀석을 다시 넣어줌
			
			//받아온 데이터를 파싱해서 json 식으로 등록해주고
			hmRecv = protocol.getParseUseMCBRcv(recvBuf);
			hmRecv.put("INQ_TYPE", "F8"); // 잔액조회 응답
			
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			// JSON 식으로 되어있는 데이터를 보내준다. POS로
			dataMsg = ret + makeSendDataMCBUseRcvRsp(hmRecv);
			df.CommLogger("★ make(to POS): " + dataMsg);
		}	
		return dataMsg;
	}
	
	// 문화 진흥원에 전송용 데이터로 설정 (사용) (SERVER -> 문화진흥원)
	private String makeSendDataMCBUseSnd(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,4,7,20,10,40,4
				    ,16,9,50,8,6
				    ,1,50,15,156
				 	};
		String strHeaders[] = {
				//HEADER				
				"HEADNO",
				"MESSAGELENGTH",
				//BODY
				"MEMBERCODE",
				
				"STORECODE",
				"SUBMEMBERCODE",
				"SUBMEMBERNAME",
				"POSCODE",
				
				"PINSCRACHNO",
				"REQUESTAMOUNT",
				"MEMBERCONTROLCODE",
				"REQUESTDATE",
				"REQUESTTIME",
				
				"INPUTTYPE",
				"PRODUCTNAME",
				"MEMBERIP",
				"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ makeSendDataMCBUseSnd : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//POS 에 내리기 위한 문자열 전문 생성 ( pos <- 서버 )
	private String makeSendDataMCBUseRcvRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,20,10,40,4
	               ,4,80,25,50,8
	               ,6,9,9,9,60,115
	               };
		String strHeaders[] = {
			  "INQ_TYPE"     // F8 모바일문화상품권 사용요청
			, "STORECODE"    // 사용처
			, "SUBMEMBERCODE"// 사용처 점포코드
			, "SUBMEMBERNAME"// 사용처 점포명
			, "POSCODE"      // POS 코드
			
			, "RESULTCODE"   // 응답코드 0000 정상 / XXXX ERROR CODE
			, "PINSCRACHNO"  // 문화상품권 번호
			, "CONTROLCODE"  // 컬쳐랜드 거래번호
			, "MEMBERCONTROLCODE" // 사용처 거래번호
			, "RESPONSEDATE"  //사용일자
			
			, "RESPONSETIME" // 사용시간
			, "PINFACEVALUE" // 모바일문화상품권 금액(액면)
			, "LEVYAMOUNT"   // 모바일문화상품권 사용금액
			, "PINBALANCE"   // 모바일문화상품권 잔액
			, "ERRORMESSAGE" // 응답메시지
			, "FILLER"       // SPACE
		};
	
	
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ makeSendDataMCBUseRcvRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// ==================================== 모바일 문화 상품권 사용요청 END ================================================
	
	// ==================================== 모바일 문화 상품권 사용취소 START ================================================
	// 모바일 문화 상품권 잔액 조회 ( 서버 -> 문화진흥원 )
	// 인자 : 공통코드(50bytes) ,  보낼 데이터 셋 ( POS에서 보낸 실시간 데이터 송신 전문 파싱 )
	// 공통코드와 pos에서 받은 데이터를 가지고 문화진흥원에 보낼 데이터를 만들어 넣음
	// 만들어 낼 데이터대로만 만들어주면 됨
	public String getMCBCancelSnd(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		MCBIrtProtocol protocol = new MCBIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		KISA_SEED_CBC seed= new KISA_SEED_CBC();
		
		String sendMsg = "";	// 문화진흥원로 보낼 송신 전문
		String recvBuf = "";	// 문화진흥원에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		String decPinscrachno = "";	// pos 송신 문화진흥원 번호
		String encPinscrachno = "";	// pos 송신 문화진흥원 번호
		String encSendMsg = "";	// 문화진흥원 송신 전문(암호화)
		String encSendMsg1 = "";	// 문화진흥원 송신 전문(암호화)
		
		byte[] enc  = null;
		byte[] enc2 = null;
		
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.MCB_FILTER)));
//HEADER	
			hm.put("HEADNO"			, "9310"); 								//4  : 전문번호
			hm.put("MESSAGELENGTH"	, "0392");								//4  : membercode 부터 끝가지 400 - 8
//DATA
			hm.put("MEMBERCODE"		, "EMART24");							//7  : 컬처랜드에서 제공 받아야 함 "EMART24"
			
			// 복호화 할 놈을 Base64.decode로 감싸고 복호화 seed.SEED_CBC_Decrypt
			enc = Base64.decode(hm.get("PINSCRACHNO").trim());
			// pin 번호 복호화
			decPinscrachno = new String( seed.SEED_CBC_Decrypt(pMK, pIV, enc, 0, enc.length ) ) ;
			hm.put("PINSCRACHNO"		, decPinscrachno);							
			
			
			//전송할 포멧으로 변경
			sendMsg = makeSendDataMCBCancelSnd(hm);
			
			// 암호화 한 놈을 encode로 감싸고 스트링 으로 만들어서 던진다.
			encSendMsg = new String( Base64.encode(
										seed.SEED_CBC_Encrypt(pMK, pIV
												               , sendMsg.substring(15, sendMsg.length()).getBytes()   		// 암호화 데이터
												               , 0 															// 암호화 시작위치
												               , sendMsg.substring(15, sendMsg.length()).getBytes().length  // 암호화 사이즈 
																)
													)
									);
			encSendMsg1 = sendMsg.substring(0, 15) + encSendMsg ;
			

			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = encSendMsg1.getBytes();
			
			if( actSock.send(encSendMsg1) ) {
				df.CommLogger("[server>mcb] SEND[" + sendBytes.length + "] OK");
			}else {
				df.CommLogger("[server>mcb] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("MCB server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			recvBuf = recvBuf.trim();
			df.CommLogger("[server<mcb] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			df.CommLogger("chk");
			
			// 복호화 할 놈을 Base64.decode로 감싸고 복호화 seed.SEED_CBC_Decrypt
			enc2 = Base64.decode(recvBuf.substring(15, recvBuf.getBytes().length));
			recvBuf = recvBuf.substring(0, 15) + new String( seed.SEED_CBC_Decrypt(pMK, pIV, enc2, 0, enc2.length ) ) ;
			
			//받아온 데이터를 파싱해서 json 식으로 등록해주고
			hmRecv = protocol.getParseBalanceMCBRcv(recvBuf);
			
			// 받아온 pin 번호를 다시 암호화. 하여 pos에서 받을수 있도록 변경
			encPinscrachno = new String( Base64.encode(
								seed.SEED_CBC_Encrypt(pMK, pIV
										               , hmRecv.get("PINSCRACHNO").trim().getBytes()   		 // 암호화 데이터
										               , 0 													 // 암호화 시작위치
										               , hmRecv.get("PINSCRACHNO").trim().getBytes().length  // 암호화 사이즈 
													)
											)
							);
			//암호화 후에 나오는 특수 문자 제거. 엔터.
			hmRecv.put("PINSCRACHNO", encPinscrachno.replaceAll("\n", "")); // 암호화된 녀석을 다시 넣어줌
			
			//받아온 데이터를 파싱해서 json 식으로 등록해주고
			hmRecv = protocol.getParseCancelMCBRcv(recvBuf);
			hmRecv.put("INQ_TYPE", "F9"); // 사용요청 취소
			
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			// JSON 식으로 되어있는 데이터를 보내준다. POS로
			dataMsg = ret + makeSendDataMCBCancelRcvRsp(hmRecv);
			df.CommLogger("★ make(to POS): " + dataMsg);
		}	
		return dataMsg;
	}
	
	// 문화 진흥원에 전송용 데이터로 설정 (SERVER -> 문화진흥원)
	private String makeSendDataMCBCancelSnd(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,4
				    ,7,20,10,40,4
				 	,2,16,25,50,50
				 	,9,8,6,1,15
				 	,129
				 	};
		String strHeaders[] = {
				//HEADER				
				"HEADNO"
				,"MESSAGELENGTH"
				//BODY
				,"MEMBERCODE"
				, "STORECODE"
				, "SUBMEMBERCODE"
				, "SUBMEMBERNAME"
				, "POSCODE"
				
				, "CANCLETYPE"
				, "PINSCRACHNO"
				, "CONTROLCODE"
				, "MEMBERCONTROLCODE"
				, "MEMBERCANCELCODE"
				
				, "CANCELAMOUNT"
				, "REQUESTDATE"
				, "REQUESTTIME"
				, "INPUTTYPE"
				, "MEMBERIP"
				
				, "FILLER"      // SPACE
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ makeSendDataMCBCancelSnd : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		return sb.toString();
	}
	
	
	//POS 에 내리기 위한 문자열 전문 생성 ( pos <- 서버 )
	private String makeSendDataMCBCancelRcvRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,20,10,40,4
				,4,80,25,25,50
				,50,8,6
				,9,9,9,60,40
	               };
		String strHeaders[] = {
			  "INQ_TYPE"     // F9 모바일문화상품권 사용요청 취소
			, "STORECODE"    // 사용처
			, "SUBMEMBERCODE"// 사용처 점포코드
			, "SUBMEMBERNAME"// 사용처 점포명
			, "POSCODE"      // POS 코드
			
			  , "RESULTCODE"   // 응답코드 0000 정상 / XXXX ERROR CODE
			  , "PINSCRACHNO"  // 문화상품권 번호
			  , "CANCELCONTROLCODE"  // 컬쳐랜드 거래번호
			  , "CONTROLCODE"  // 컬쳐랜드 거래번호
			  , "MEMBERCONTROLCODE"

			  , "MEMBERCANCELCONTROL"
			  , "CANCELDATE"
			  , "CANCELTIME"
			  
			  , "PINFACEVALUE" // 모바일문화상품권 금액(액면)
			  , "CANCELAMOUNT"   // 모바일문화상품권 사용금액
			  , "PINBALANCE"   // 모바일문화상품권 잔액
			  ,"ERRORMESSAGE"
			  ,"FILLER"
		};
		

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ makeSendDataMCBCancelRcvRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// ==================================== 모바일 문화 상품권 사용취소 END ================================================

}