package biz.cms_SSGConTran;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_TranDivide.TranDividePollingAction;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class SSGConTranDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(SSGConTranPollingAction.class);
	
	public int updSSGCONTRAN_RCVY(String com_cd, String proc_ymdhms) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			connect("CMGNS");	// DB Connection(DB 접속)
			
			sql.put(findQuery("service-sql", "UPD_SSGCONTRAN_RCVY"));
			sql.setString(++i, com_cd);
			sql.setString(++i, proc_ymdhms);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	
	public int updSSGCONTRAN_RESET(String proc_id, String tran_ymd, String store_cd, String pos_no, String tran_no, String com_cd, String trace_no) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			connect("CMGNS");	// DB Connection(DB 접속)
			
			sql.put(findQuery("service-sql", "UPD_SSGCONTRAN_RESET"));
			sql.setString(++i, proc_id);
			sql.setString(++i, tran_ymd);
			sql.setString(++i, store_cd);
			sql.setString(++i, pos_no);
			sql.setString(++i, tran_no);
			sql.setString(++i, com_cd);
			sql.setString(++i, trace_no);
			
			ret = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	
	public List<Object> selSSGCONTRAN(String com_cd, String proc_ymdhms, String server_no) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			connect("CMGNS");	//DB Connection(DB 접속)
			
			sql.put(findQuery("service-sql", "SEL_SSGCONTRAN"));
			sql.setString(++i, com_cd);
			sql.setString(++i, server_no);
			sql.setString(++i, proc_ymdhms);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selSSGCONTRAN::" + e);
		}
		
		return list;
	}
	

	public int updSSGCONTRAN(String com_cd, String proc_ymdhms, String server_no) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			connect("CMGNS");	// DB Connection(DB 접속)
			
			//통신서버 4대에서 균등분배가 되도록 하기 위하여 점포코드를 4로 나눈 값으로 각 서버별 담당 점포를 분배한다.
			//00999는 송도2번서버에서 분해되어야함. 
			//구로1: 0, 구로2: 1, 송도1: 2, 송도2: 3
			i = 0;
			sql.clearParameter();
			sql.put(findQuery("service-sql", "UPD_SSGCONTRAN"));
			sql.setString(++i, proc_ymdhms);
			sql.setString(++i, com_cd);
			sql.setString(++i, server_no);
			
			ret = executeUpdate(sql);
			
			sql.close();
		}catch(Exception e) {
			ret = 0;
			rollback();
			logger.info("[ERROR]updSSGCONTRAN::" + e);
			logger.info("[ERROR]sql_debug::["+sql.debug()+"]");
		}finally {
			end();
		}
		
		return ret;
	}
	
}
