package biz.cms_SSGConTran;

import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;

import com.cyberpass.seed.Seed;

public class SSGConTranPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(SSGConTranPollingAction.class);
	
	public static void main(String args[]) throws Exception {

		try {
			SSGConTranPollingAction action = new SSGConTranPollingAction();
			
			if(args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			action.execute("1");
			
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}  

	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("MMddHHmmss");
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMddHHmmss");
			String msg_send_dt = sdf1.format(new Date()).substring(0, 8);
			String msg_send_tm = sdf1.format(new Date()).substring(8, 14);
			String proc_ymdhms = sdf.format(new Date()) + (Double.toString(Math.random())).substring(2, 6);
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String server_no = PropertyUtil.findProperty("communication-property", "LOCAL_SERVER_NO");

			logger.info("[INFO]server_no::["+server_no+"]");
			
			SSGConTranDAO dao = new SSGConTranDAO();
			List<Object> list = null;
			int ret = -1;
			
			try {	// SSGCon Tran 송신
				ret = dao.updSSGCONTRAN(com_cd, proc_ymdhms, server_no);	// SSGCon TRAN 대상 정보 조회
				
				if( ret > 0 ) {
					list = dao.selSSGCONTRAN(com_cd, proc_ymdhms, server_no);	// 대상 정보 기록된 TRAN 조회
					
					if( list.size() <= 0 ){
						logger.info("[INFO] no data.");
						dao.updSSGCONTRAN_RCVY(com_cd, proc_ymdhms);
					}else {
						for(int i = 0;i < list.size();i++) {
							Map<String, String> map = (Map<String, String>)list.get(i);
							try {
								this.transferToSSGCon(map, msg_send_dt, msg_send_tm);
							}catch(Exception e) {
								logger.info("[ERROR]:" + e.getMessage());
							}
							Thread.sleep(50);
						}
					}
				}
			}catch(Exception e) {
				logger.info("[ERROR]" + e.getMessage());
			}
		} catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}

	public void transferToSSGCon(Map<String, String> map, String sendDt, String sendTm) throws Exception {
		ActionSocket actSock = null;
		SSGConTranDAO dao = new SSGConTranDAO();
		String dataMsg = "";
		String recvBuf = "";
		byte sendBytes[];
		String comCd = "";
		String ip = "";
		int port = 0;
		
		try {
			comCd = PropertyUtil.findProperty("stsys-property", "COM_CD");											// 회사코드
			ip = PropertyUtil.findProperty("communication-property", "SSGCON_APPRSVR_IP");							// IP
			port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGCON_APPRSVR_PORT"));	// PORT
			
			if( comCd.trim() == "" ) {
				comCd = "1002";
			}
			actSock = new ActionSocket(new Socket(ip, port), (Filter)(new COMMConveyerFilter(COMMBiz.SSGCON_FILTER)));
			actSock.getSocket().setSoTimeout(5000);
			
				
			String strHeader = makeSSGConTranHeader(map, sendDt, sendTm);
			String strDataHd = makeSSGPayTranDataHd(map);
			String strDataGr = makeSSGPayTranDataGr(map); //반복되는애
			String strDataTl = makeSSGPayTranDataTl(map);
			dataMsg = strHeader + strDataHd + strDataGr + strDataTl;
			
			// Data 전문을 바이트 배열로 변환
			sendBytes = dataMsg.getBytes();
			sendBytes[999] = (byte)0x0d;
			
			logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");
			
			/**
			 ** 1. 대사TRAN(1건) 송신
			 **/
			if( actSock.send(sendBytes, sendBytes.length) ) {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] OK");
			}else {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSGCON server is no response");
			}
			
			// 대사TRAN전문에 대한 응답
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<ssgcon] TRACE_NO[" + (String)map.get("MSG_TRACE_NO") + "]");
			logger.info("[sms<ssgcon] RECV[" + recvBuf.getBytes().length + "]::[" + recvBuf + "]");
			logger.info("[INFO] RESP_CODE::["+recvBuf.substring(186, 190)+"]");
			
			if( !(recvBuf.substring(186, 190)).equals("0000") ) {
				dao.updSSGCONTRAN_RESET( "9"
									   , (String)map.get("TRAN_YMD")
									   , (String)map.get("ST_CODE")
									   , (String)map.get("TM_NO")
									   , (String)map.get("TRAN_NO")
									   , (String)map.get("COM_CD")
									   , (String)map.get("MSG_TRACE_NO"));
			} else {
				dao.updSSGCONTRAN_RESET( "1"
									   , (String)map.get("TRAN_YMD")
									   , (String)map.get("ST_CODE")
									   , (String)map.get("TM_NO")
									   , (String)map.get("TRAN_NO")
									   , (String)map.get("COM_CD")
									   , (String)map.get("MSG_TRACE_NO"));
			}
		}catch(Exception e) {
			logger.info("", e);
			logger.info("[ERROR]SSGCON TRAN FAIL... ERR_MSG::["+e.getMessage()+"]");
			try{
				logger.info("[INFO] SYS_YMD::["+(String)map.get("TRAN_YMD")+"]::STORE_CD::["+(String)map.get("ST_CODE")+"]::POS_NO::["+(String)map.get("TM_NO")+"]::TRAN_NO::["+(String)map.get("TRAN_NO")+"]::TRACE_NO::["+(String)map.get("MSG_TRACE_NO")+"]");
				dao.updSSGCONTRAN_RESET( "9"
						   , (String)map.get("TRAN_YMD")
						   , (String)map.get("ST_CODE")
						   , (String)map.get("TM_NO")
						   , (String)map.get("TRAN_NO")
						   , (String)map.get("COM_CD")
						   , (String)map.get("MSG_TRACE_NO"));
			}catch(Exception e1){
				logger.info("[ERROR] update proc_id fail. ERR_MSG::["+e1.getMessage()+"]");
			}
		}finally {
			logger.info("[INFO]SSGCON TRAN TRANSFER FIN.");
		}
	}
	
	
	private String makeSSGConTranHeader(Map<String, String> map, String sendDt, String sendTm) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {5, 8, 8, 6, 26,
					  5, 15, 15, 4, 10,
					  4, 5, 4, 5, 10,
					  2, 8, 6, 40, 1,
					  4, 64, 45};
		String strHeaders[] = { 
				"MSG_LEN", "MSG_ID", "MSG_SEND_DT", "MSG_SEND_TM", "MSG_TRACE_NO"
			  , "MSG_DATA_LEN", "PTR_ID", "PTR_MCH_ID", "SER_COM_CD", "ST_CODE"
			  , "TM_NO", "SHOP_NO", "CD_NO", "TRAN_NO", "CASHER_NO"
			  , "TRAN_TYPE", "SALE_DATE", "SALE_TIME", "SER_COM_REQ_NO", "CRYPTO_GUBUN"
			  , "RESP_CODE", "RESP_MSG", "HEADER_FILLER"
		};
		
		map.put("MSG_LEN", "01000");									// 1. 전문길이(가변)
		map.put("MSG_ID",  "PCTU0200");									// 2. 전문ID
		map.put("MSG_SEND_DT", sendDt);									// 3. 전문전송일자
		map.put("MSG_SEND_TM", sendTm);									// 4. 전문전송시간
		map.put("MSG_TRACE_NO", (String)map.get("MSG_TRACE_NO"));		// 5. 전문전송거래추적번호(영업일자+포스번호+매장번호+CD번호+거래번호)
		map.put("MSG_DATA_LEN", "700");									// 6. 전문본문길이(1차오픈은 고정값)
		map.put("PTR_ID", "FM00010770");								// 7. 제휴사아이디
		map.put("PTR_MCH_ID", (String)map.get("PTR_MCH_ID"));			// 8. 가맹점아이디
		map.put("SER_COM_CD", "5700");									// 9. 회사코드
		map.put("ST_CODE", (String)map.get("ST_CODE"));					// 10. 점코드
		map.put("TM_NO", (String)map.get("TM_NO"));						// 11. 포스번호
		map.put("SHOP_NO", "00000");									// 12. 매장번호
		map.put("CD_NO", "0000");										// 13. CD번호
		map.put("TRAN_NO", 	 "0"+(String)map.get("TRAN_NO"));			// 14. 거래번호
		map.put("CASHER_NO", (String)map.get("CASHER_NO"));				// 15. CASHIER번호
		map.put("TRAN_TYPE", (String)map.get("TRAN_TYPE"));				// 16. 거래구분
		map.put("SALE_DATE", (String)map.get("SALE_DATE"));				// 17. 거래일자
		map.put("SALE_TIME", (String)map.get("SALE_TIME"));				// 18. 거래시간
		map.put("SER_COM_REQ_NO", "");									// 19. 회사별 부가요청 정보
		map.put("CRYPTO_GUBUN", "0" );									// 20. 보안 설정구분
		map.put("RESP_CODE", "");										// 21. 응답코드
		map.put("RESP_MSG", "");										// 22. 응답메시지
		map.put("HEADER_FILLER", "");									// 23. 헤더필러
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) map.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) map.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	private String makeSSGPayTranDataHd(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 2, 1, 1, 64,
					    20, 4
					  };

		String strHeaders[] = {
				"KEY_IN_TYPE", "TRADE_TYPE", "USE_FUNC_GUBUN", "USE_GUBUN", "DELEGATE_BARCODE_NO"
			  , "SEL_AUTH_NO", "GRP_ARRAY_CNT"};
		
		map.put("KEY_IN_TYPE", 			(String)map.get("KEY_IN_TYPE"));			// 24. 수 입력타입
		map.put("TRADE_TYPE", 			(String)map.get("TRADE_TYPE"));				// 25. 거래 요청타입
		map.put("USE_FUNC_GUBUN", 		(String)map.get("USE_FUNC_GUBUN"));			// 26. 사용기능구분
		map.put("USE_GUBUN", 			(String)map.get("USE_GUBUN"));				// 27. 사용구분
		map.put("DELEGATE_BARCODE_NO",  (String)map.get("DELEGATE_BARCODE_NO"));	// 28. 통합결제바코드번호
		map.put("SEL_AUTH_NO", 			(String)map.get("SEL_AUTH_NO"));			// 29. 조회인증번호
		map.put("GRP_ARRAY_CNT", 		"0001");									// 30. 그룹 정보 개수(1차개발시 고정)
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info("★ make send strHeaders : ["+strHeaders[i]+"]["+ (String) map.get(strHeaders[i].toString())+"]");
			StringUtil.appendSpace(sb, (String) map.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	private String makeSSGPayTranDataGr(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 4, 2, 20, 3, 3,
					    64, 20, 64, 20, 4,
					    12, 10, 4, 1, 12,
					    12, 12, 125, 4
					  };

		String strHeaders[] = {
				"GRP_STA", "GRP_TYPE", "ADD_DC_CODE", "INFO_INDEX", "CLASS_GUBUN"
			  , "CPN_NO", "PRD_ID", "PRD_NM", "PRD_SKU_CODE", "PRD_CNT"
			  , "PRD_AMT", "BRD_CODE", "PRD_TYPE", "AMT_RATE_GUBUN", "TOT_TRADE_AMT"
			  , "TRADE_AMT", "REMAIN_AMT", "ARRAY_ETC_FIELD", "GRP_END"};
		
		map.put("GRP_STA", 			"GSTA");							// 31. 그룹시작문자
		map.put("GRP_TYPE", 		(String)map.get("GRP_TYPE"));		// 32. 그룹타입
		map.put("ADD_DC_CODE", 		"");								// 33. 추가할인코드
		map.put("INFO_INDEX", 		"001");								// 34. 상품정보순서
		map.put("CLASS_GUBUN",  	(String)map.get("CLASS_GUBUN"));	// 35. 분류구분
		map.put("CPN_NO", 			(String)map.get("CPN_NO"));			// 36. 쿠폰번호
		map.put("PRD_ID", 			(String)map.get("PRD_ID"));			// 37. 상품아이디
		map.put("PRD_NM", 			(String)map.get("PRD_NM"));			// 38. 상품명
		map.put("PRD_SKU_CODE", 	(String)map.get("PRD_SKU_CODE"));	// 39. 상품바코드
		map.put("PRD_CNT", 			"");								// 40. 상품갯수
		map.put("PRD_AMT", 			(String)map.get("PRD_AMT"));		// 41. 상품원가
		map.put("BRD_CODE", 		"");								// 42. 브랜드코드
		map.put("PRD_TYPE", 		(String)map.get("PRD_TYPE"));		// 43. 상품타입
		map.put("AMT_RATE_GUBUN", 	"");								// 44. 정액/정률구분
		
		map.put("TOT_TRADE_AMT", 	String.format("%012d", Integer.parseInt(map.get("TOT_TRADE_AMT").trim())));	// 45. 전체거래금액
		map.put("TRADE_AMT", 		String.format("%012d", Integer.parseInt(map.get("TRADE_AMT").trim())));		// 46. 사용금액
		map.put("REMAIN_AMT", 		String.format("%012d", Integer.parseInt(map.get("REMAIN_AMT").trim())));	// 47. 남은금액
		map.put("ARRAY_ETC_FIELD", 	"");								// 48. ARRAY DATA 예비필드
		map.put("GRP_END", 			"GFIN");							// 49. 그룹종료
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info("★ make send strHeaders : ["+strHeaders[i]+"]["+ (String) map.get(strHeaders[i].toString())+"]");
			StringUtil.appendSpace(sb, (String) map.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	private String makeSSGPayTranDataTl(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 8, 6, 8, 8, 26,
						8, 8, 8, 129, 1
					  };

		String strHeaders[] = {
				"AUTH_DATE", "AUTH_TIME", "AUTH_NO", "ORG_MSG_SEND_DT", "ORG_MSG_TRACE_NO"
			  , "ORG_SALE_DATE", "ORG_AUTH_DATE", "ORG_AUTH_NO", "DATA_FILLER", "MSG_END"};
		
		map.put("AUTH_DATE", 		(String)map.get("AUTH_DATE"));			// 50. 승인일자
		map.put("AUTH_TIME", 		(String)map.get("AUTH_TIME"));			// 51. 승인시간
		map.put("AUTH_NO", 			(String)map.get("AUTH_NO"));			// 52. 승인번호
		map.put("ORG_MSG_SEND_DT", 	(String)map.get("ORG_MSG_SEND_DT"));	// 53. 원거래전문전송일자
		map.put("ORG_MSG_TRACE_NO", (String)map.get("ORG_MSG_TRACE_NO"));	// 54. 원거래전문전송거래추적번호
		map.put("ORG_SALE_DATE", 	(String)map.get("ORG_SALE_DATE"));		// 55. 원거래거래일자
		map.put("ORG_AUTH_DATE", 	(String)map.get("ORG_AUTH_DATE"));		// 56. 원거래승인일자
		map.put("ORG_AUTH_NO", 		(String)map.get("ORG_AUTH_NO"));		// 57. 원거래승인번호
		map.put("DATA_FILLER", 		"");									// 58. 데이터필러
		map.put("MSG_END", 			"");									// 59. 전문종료내역
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info("★ make send strHeaders : ["+strHeaders[i]+"]["+ (String) map.get(strHeaders[i].toString())+"]");
			StringUtil.appendSpace(sb, (String) map.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
}
