package biz.cms_DaemonMonitor;

import java.net.Socket;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.daemon.DaemonLauncher;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

public class DaemonMonitorPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(DaemonMonitorPollingAction.class);
	
	Socket socket = null;
	
	@Override
	public void execute(String arg0) {
		// TODO Auto-generated method stub		
//		checkBlockedTran();
		
		if( isAliveContainer() ) {
			excuteContainer();
		}
		
		if( isAliveContainer2() ) {
			excuteContainer2();
		}
	}
	
	private void checkBlockedTran() {
		DaemonMonitorDAO dao = new DaemonMonitorDAO();
		List<Object> list = null;
		
		list = dao.selBlockedTran(30);
		
		for(int i = 0;i < list.size();i++) {
			Map<String, String> map = (Map<String, String>)list.get(i);
			
			dao.updBlockedTran(map);
		}
	}

	private boolean isAliveContainer() {
		boolean bIsAlive = false;
//		try {
//			try {
//				socket = new Socket("localhost", 14009);
//				bIsAlive = true;
//			}catch(Exception e) {
//				bIsAlive = false;
//			}finally {
//				socket.close();
//			}
//		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
//		}
		
		try {
			socket = new Socket("localhost", 14009);
			bIsAlive = false;
			socket.close();
		}catch(Exception e) {
			bIsAlive = true;
		}
		
		return bIsAlive;
	}
	
	private boolean isAliveContainer2() {
		boolean bIsAlive = false;
//		try {
//			try {
//				socket = new Socket("localhost", 14026);
//				bIsAlive = true;
//			}catch(Exception e) {
//				bIsAlive = false;
//			}finally {
//				socket.close();
//			}
//		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
//		}
		
		
		try {
			socket = new Socket("localhost", 14026);
			bIsAlive = false;
			socket.close();
		}catch(Exception e) {
			bIsAlive = true;
		}
		
		return bIsAlive;
	}
	
	private void excuteContainer() {
		StringBuffer cmd = new StringBuffer();
		
		cmd.append("java ").append("-Xms128m -Xmx128m" + " ")
		.append("kr.fujitsu.com.ffw.daemon.net.polling.ActionPollingContainer" + " ")
		.append("cms_TranDivide" + " ").append("-mode:xml" + " ")
		.append("/home/withme/CMBO/workspace/sms-1.0.1/xml/daemon-config.xml");
		try{
			new DaemonLauncher("cms_TranDivide", cmd).start();
			logger.info("executed cms_TranDivide...");
		} catch (Exception e) {
			logger.error("",e);
		}
	}
	
	private void excuteContainer2() {
		StringBuffer cmd = new StringBuffer();
		
		cmd.append("java ").append("-Xms128m -Xmx128m" + " ")
		.append("kr.fujitsu.com.ffw.daemon.net.polling.ActionPollingContainer" + " ")
		.append("cms_CashRcptManager" + " ").append("-mode:xml" + " ")
		.append("/home/withme/CMBO/workspace/sms-1.0.1/xml/daemon-config.xml");
		try{
			new DaemonLauncher("cms_CashRcptManager", cmd).start();
			logger.info("executed cms_CashRcptManager...");
		} catch (Exception e) {
			logger.error("",e);
		}
	}
}
