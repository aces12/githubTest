package biz.cms_CJPclDTLDownloader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

public class CJPclDTLDownloaderInst extends Thread {
	private static Logger logger = Logger.getLogger(CJPclDTLDownloaderPollingAction.class);
	
	String path = "";
	
	public CJPclDTLDownloaderInst(String path) {
		this.path = path;
	}
	
	public void run() {
		int ret = 0;
		BufferedReader bin = null;
		StringTokenizer st = null;
		String readedLine = "";
		try {
			CJPclDTLDownloaderDAO dao = new CJPclDTLDownloaderDAO();
			
			List<File> list = getDirFileList(path);
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			for(int i = 0;i < list.size();i++ ) {
				if( !(list.get(i)).isFile() ) {
					continue;
				}
				String targetFile = list.get(i).getName();
				bin = new BufferedReader(new FileReader(path + File.separator + targetFile));
				
//				logger.info(">>>>>>>>> daily = " + targetFile.substring(0, 1));
				
				// 일대사 파일
				if( targetFile.substring(0, 1).equals("D") ) {
					while( (readedLine = bin.readLine()) != null ) {
						logger.info("[DEBUG] File Name : " + targetFile + ", readedLine = " + readedLine);
						// '\t'와'\n' 구분자로 토큰 분리
						st = new StringTokenizer(readedLine, "\t\n");
						
						int col = 0;
						HashMap<String, String> map = new HashMap<String, String>();
						String strHeaders[] = {
							"STORE_CD",			// 1.편의점코드
							"TRAN_YMD",			// 2.영업일자
							"PARCEL_CD",		// 3.운송장번호
							"PARCEL_TP",		// 4.접수종류
							"PAY_TP",			// 5.정산구분
							"TOTAL_AMT",		// 6.택배운임
							"APPR_YMDHMS"		// 7.접수일시
						};
						map.put("CO_CD", com_cd);
						map.put("ADJT_DT", targetFile.substring(9, 17));					// 정산기준일
						// 각 분리된 토큰을 저장
						while( st.hasMoreTokens() ) {
							map.put(strHeaders[col++], st.nextToken());
//							logger.info("☆  value[" + Integer.toString(col-1) + "] = " + map.get(strHeaders[col-1]));
						}
						ret = dao.updPARCELTRN(map);
						if( ret != 1 ) {
							logger.info("["+targetFile.substring(0, 1)+"]"+"There is an Error on inserting data");
						}
						
					}
					bin.close();
					bin = null;
					System.gc();
					//this.copyFile(path, targetFile, path + File.separator + "backup");
					//this.deleteFile(path, targetFile);
					this.moveFile(path, targetFile, path + File.separator + "backup");
				// 일정산 파일
				}else if( targetFile.substring(0, 1).equals("A") ) {
					while( (readedLine = bin.readLine()) != null ) {
						logger.info("[DEBUG] File Name : " + targetFile + ", readedLine = " + readedLine);
						// '\t'와'\n' 구분자로 토큰 분리
						st = new StringTokenizer(readedLine, "\t\n");
						
						int col = 0;
						HashMap<String, String> map = new HashMap<String, String>();
						String strHeaders[] = {
							"TRAN_YMD",						// 1. 영업일자
							"STORE_CD",						// 2. 점포코드
							"POS_NO",						// 3. POS번호
							"TRAN_NO",						// 4. TRAN번호
							"PARCEL_CD",					// 5. 운송장번호
							"ADJT_DT",						// 6. 정산일자
							"PAYMENT_TP",					// 7. 정산구분(01:선불, 02:착불, 03:신용)
							"PARCEL_STS_TP",				// 8. 정산종류(01:접수, 02:취소)
							"BASE_COST_TP",					// 9. 요금&수수료구분
							"TOT_AMT",						// 10.택배총금액
							"BASE_AMT",						// 11.기본운임
							"PERRY_RTS_AMT",				// 12.도선비금액
							"ITEM_EXT_AMT",					// 13.물품가할증금액
							"DC_AMT",						// 14.택배할인금액
							"FEE_AMT"						// 15.수수료금액
						};
						map.put("CO_CD", com_cd);		// 회사코드
						map.put("PARCEL_CMP_TP", "01");	// 택배회사구분(01:CJ대한통운)
						map.put("PARCEL_IN_QTY", "1");	// 택배접수수량
						// 각 분리된 토큰을 저장
						while( st.hasMoreTokens() ) {
							map.put(strHeaders[col++], st.nextToken());
//							logger.info("☆  value[" + Integer.toString(col-1) + "] = " + map.get(strHeaders[col-1]));
						}
						
						try {
							ret = dao.insHQPARCELADJT_TRN(map);
						}catch(Exception e)
						{
							logger.info("[ERROR1] " + e.getMessage());
						}
						if( ret != 1 ) {
							logger.info("["+targetFile.substring(0, 1)+"]"+"There is an Error on inserting data");
						}
						
					}
					bin.close();
					bin = null;
					//this.copyFile(path, targetFile, path + File.separator + "backup");
					//this.deleteFile(path, targetFile);
					this.moveFile(path, targetFile, path + File.separator + "backup");
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR1] " + e.getMessage());
		}finally {
			try {
				if( bin != null ) bin.close();
			}catch(Exception e) {}
		}
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
	public void deleteFile(String path, String fileNM) {
		File file = new File(path + File.separator + fileNM);
		if( file.exists() ) {
			logger.info("File Name : " + path + File.separator + fileNM);
			if( file.delete() ) {
				logger.info("File(" + path + File.separator + fileNM + ") removed !!!");
			}
		}
	}
	
	public void copyFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdirs();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(orgFile);
			fos = new FileOutputStream(destFile);
			
			int data = 0;
			while( (data = fis.read()) != -1 ) {
				fos.write(data);
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			try {
				fis.close();
				fis = null;
				fos.flush();
				fos.close();
				fos = null;
				System.gc();
			}catch(Exception e) {
				logger.info(e.getMessage());
			}
		}
		
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
}
