package biz.cms_TMoneySender;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class TMoneySenderProtocol {
//	private static Logger logger = Logger.getLogger(TMoneySenderProtocol.class);
	
	public static int COMM_LEN = 32;
	public static int LENGTH_BY_SEQUENCE = 900;
	
	public String getResCD(String recvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3,8,4,1
					  ,1,8,3};
		String strHeaders[] = {
			"TLGM_LEN",
			"WORK_CD",
			"COMPANY_CD",
			"TLGM_CD",
			"DEAL_TP",
			
			"SNDRCV_FG",
			"FILE_NM",
			"RES_CD"	
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);
		
		return (String)hm.get("RES_CD");
	}

	public String getRecvData0640(String recvBuf, String key) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3,8,4,1
				  	  ,1,8,3,8,12
				  	  ,4};
		
		String strHeaders[] = {
			"TLGM_LEN",
			"WORK_CD",
			"COMPANY_CD",
			"TLGM_CD",
			"DEAL_TP",
				
			"SNDRCV_FG",
			"FILE_NM",
			"RES_CD",
			"FILE_NAME",
			"FILE_SIZE",

			"TLGM_BYTE_NUM"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);
		
		return (String)hm.get(key);
	}
	
	public List<Integer> getRecvData0300(String recvBuf) {
		int totErrNum = 0;
		String chkStr = "";
		List<Integer> array = new ArrayList<Integer>();
		
		int len = Integer.parseInt(recvBuf.substring(0,4));
		int lossChkLen = len - 38;
				
		totErrNum = Integer.parseInt((recvBuf.substring(39, 42)).trim());
		chkStr = recvBuf.substring(42, 42 + lossChkLen);
		for( int i = 0;i < lossChkLen;i++) {
			if( array.size() == totErrNum ) break;
			if( chkStr.charAt(i) == '0') {	// 결번 Sequence Number 확인
				array.add(i);
			}
		}
		
		return array;
	}
	
	public boolean get0610WhetherNormality(String recvBuf, String strMgrCd) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3,8,4,1
					  ,1,8,3,10,3
					  ,20,16};
		boolean bRet = false;
		String strHeaders[] = {
			"TLGM_LEN",
			"WORK_CD",
			"COMPANY_CD",
			"TLGM_CD",
			"DEAL_TP",
			
			"SNDRCV_FG",
			"FILE_NM",
			"RES_CD",
			"TRANS_TIME",
			"MANAGE_INFO",
			
			"SENDER_NM",
			"SENDER_PW"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);
		
		if( ((String)hm.get("TLGM_CD")).equals("0610") 
				&& ((String)hm.get("MANAGE_INFO")).equals(strMgrCd) ) {
			if( ((String)hm.get("RES_CD")).equals("000") ) {
				bRet = true;
			}
		}
		
		return bRet;
	}
}