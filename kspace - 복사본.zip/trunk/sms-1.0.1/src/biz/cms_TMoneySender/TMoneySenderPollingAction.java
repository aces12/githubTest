package biz.cms_TMoneySender;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.io.File;

import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

import org.apache.log4j.Logger;

public class TMoneySenderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(TMoneySenderPollingAction.class);

	public static void main(String args[]) throws Exception {
		TMoneySenderPollingAction action = new TMoneySenderPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[0]]=" + args[1] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			if( cmd.length() != 3 ) return;
			
			if( cmd.charAt(0) == '1' ) {
				System.out.println("[DEBUG] execute createTMNALIDPSAMIDFile" );
				action.createTMNALIDPSAMIDFile();
				Thread.sleep(50);
			}
			if( cmd.charAt(1) == '1' ) {
				System.out.println("[DEBUG] execute createTMoneyPaymentFile" );
				action.createTMoneyPaymentFile();
				Thread.sleep(50);
			}
			if( cmd.charAt(2) == '1' ) {
				(new TMoneySenderFileTransfer()).transfer();
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(String actionMode) {
		TMoneySenderDAO dao = new TMoneySenderDAO();
		List<Object> list = null;
		int totalCnt = 0;
		
		try {
			int ret = -1;
			
			// actionMode : 0-POLLING_PERIOD에 주기적으로 무조건 수행, 1-ACTION_TIME에 한 번 수행
			if( actionMode == "1" ) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String stdYmd = sdf.format(new Date());
				String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
				
				logger.info("stdYmd="+stdYmd);
				
				//(금일 대사파일 생성 유무 조회)
				list = dao.selSVCFILEDAILY(stdYmd, "TMY", "%", com_cd);
				totalCnt = list.size();
				
				logger.info("totalCnt="+Integer.toString(totalCnt));
				
				//금일 대사파일 생성 row가 없으면 생성
				if( totalCnt <= 0 ) {
					HashMap<String, String> hm = new HashMap<String, String>();
					hm.put("COM_CD", com_cd);
					hm.put("STD_YMD", stdYmd);
					hm.put("SVC_ID", "TMY");
					hm.put("CMD_TY", "00");
					
					ret = dao.insSVCFILEINFO(hm);
					
					if( ret > 0 ) {
						createTMNALIDPSAMIDFile();
						Thread.sleep(50);
						
						createTMoneyPaymentFile();
						Thread.sleep(50);
						
						try {
							(new TMoneySenderFileTransfer()).transfer();
						}catch(Exception e) {
							logger.info("[ERROR]" + e.getMessage());
						}
						hm.put("CMD_TY", "01");
						ret = dao.updSVCFILEINFO(hm);
					}
				}
			}
			else if( actionMode == "0" ) {
				String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
				String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "tmoney";
				File destDir = new File(destPath);
				boolean isFile = false;
				
				File[] files = destDir.listFiles();
				for(File file : files) {
					if(file.isFile()) {
						isFile = true;
						logger.info(file.getName());
						break;
					}
				}
				if( isFile ) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
					String stdYmd = sdf.format(new Date());
					String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
					list = null;
					
					//(금일 대사파일 생성 유무 조회)
					list = dao.selSVCFILEDAILY(stdYmd, "TMY", "01", com_cd);
					totalCnt = list.size();
					
					// 파일 재 송신
					if( totalCnt > 0 ) {
						logger.info("Retransfering to TMoney...");
						try {
							(new TMoneySenderFileTransfer()).transfer();
						}catch(Exception e) {
							logger.info("[ERROR]" + e.getMessage());
						}
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	public boolean createTMoneyPaymentFile() {
		boolean bIsCreatedFile = false;
		
		try {
			int deal_tot_cnt = 0;
			int deal_tot_amt = 0;
			int cancel_tot_cnt = 0;
			int cancel_tot_amt = 0;
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			TMoneySenderDAO dao = new TMoneySenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String toDay = sdf.format(calendar.getTime());
			calendar.setTime(new Date());
			calendar.add(Calendar.DATE, -1);
			String strDate = sdf.format(calendar.getTime());
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			//String destPath = basePath + "\\files\\up\\tmoney";
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "tmoney";
			// 전송 파일명 : 연계기능별구분코드'TX' + 업체코드'WM' + 전송일자'MMDD'
			String strTMoneyPaymentFileNM = "TXWM" + toDay.substring(4);
			
			// 단말기 ID / PSAM ID 설치 정보내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_TP", "H");
			hmHeader.put("FILE_CRT_DT", strDate);
			hmHeader.put("FILLER", " ");
			
			sbFile.append(makeHeaderOfFile(hmHeader));
			
			list = dao.selTMONEYPAYMENTTRAN(com_cd, card_key, double_card_key);
			
			for(int i = 0;i < list.size();i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
//				String strTransactionID = ((String)map.get("TRAN_YMD")).substring(2) + (String)map.get("STORE_CD")
//						+ (String)map.get("POS_NO") + (String)map.get("TRAN_NO");
				
				hmData.put("RECORD_TP", "D");
				hmData.put("SNO", String.format("%07d", i + 1));
				hmData.put("TRANSACTION_ID", (String)map.get("TRAN_ID"));
				hmData.put("FCSTR_ID", (String)map.get("FCSTR_ID"));
				hmData.put("TMNAL_ID", ((String)map.get("TMNAL_ID")).trim());
				hmData.put("TRAN_YMD", (String)map.get("TRAN_YMD"));
				hmData.put("TRAN_NO", (String)map.get("TRAN_NO"));
				hmData.put("PSAM_ID", (String)map.get("PSAM_ID").trim());
				hmData.put("PSAM_TRAN_SEQ_NO", (String)map.get("PSAM_TRAN_SEQ_NO").trim());
				hmData.put("PPCARD_NO", (String)map.get("PPCARD_NO").trim());
				hmData.put("PPCARD_TRAN_SEQ_NO", (String)map.get("PPCARD_TRAN_SEQ_NO").trim());
				hmData.put("TMONY_TASK_TP", (String)map.get("TMONY_TASK_TP").trim());
				if( ((String)map.get("TMONY_TASK_TP")).equals("001") ) {		// 001:거래
					deal_tot_cnt++;
					deal_tot_amt += Integer.parseInt((String)map.get("PPCARD_REQ_AMT")); 
				}else if( ((String)map.get("TMONY_TASK_TP")).equals("064") ) {	// 064:직전지불거래취소
					cancel_tot_cnt++;
					cancel_tot_amt += Integer.parseInt((String)map.get("PPCARD_REQ_AMT")); 
				}
				hmData.put("PPCARD_PRE_REM_AMT", String.format("%010d", Integer.parseInt(map.get("PPCARD_PRE_REM_AMT"))));
				hmData.put("PPCARD_REQ_AMT", String.format("%010d", Integer.parseInt(map.get("PPCARD_REQ_AMT"))));
				hmData.put("PPCARD_AFT_REM_AMT", String.format("%010d", Integer.parseInt(map.get("PPCARD_AFT_REM_AMT"))));
				hmData.put("TRAN_DTM", (String)map.get("TRAN_DTM").trim());
				hmData.put("ALGO_NO", (String)map.get("ALGO_NO").trim());
				hmData.put("SPBY_TRAN_KEY_VER", (String)map.get("SPBY_TRAN_KEY_VER").trim());
				hmData.put("ELE_MONY_IDTY", (String)map.get("ELE_MONY_IDTY").trim());
				hmData.put("PSAM_TOT_AMT_COLECT_SEQ_NO", String.format("%010d", Integer.parseInt(map.get("PSAM_TOT_AMT_COLECT_SEQ_NO"))));
				hmData.put("PSAM_SPBY_COLECT_CNT", String.format("%05d", Integer.parseInt(map.get("PSAM_SPBY_COLECT_CNT"))));
				hmData.put("PSAM_ACCM_TOT_AMT", String.format("%010d", Integer.parseInt(map.get("PSAM_ACCM_TOT_AMT"))));
				hmData.put("SIGN_VAL", (String)map.get("SIGN_VAL").trim());
				hmData.put("CARD_TP_VAL", (String)map.get("CARD_TP_VAL").trim());
				hmData.put("CARD_HOLDER_TP", (String)map.get("CARD_HOLDER_TP").trim());
				hmData.put("HSM_STATUS", " ");
				hmData.put("ERR_YMDHMS", " ");
				hmData.put("ERR_CD", " ");
				hmData.put("FILLER", " ");
//				hmData.put("RESPON_CD", (String)map.get("RESPON_CD"));
				
				sbFile.append(makeDataOfTMoneyPaymentFile(hmData));
			}
			
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			hmTailer.put("RECORD_TP", "T");
			hmTailer.put("TOTAL_DATA_ROWS", String.format("%02d", list.size()));
			hmTailer.put("DEAL_CNT", String.format("%07d", deal_tot_cnt));
			hmTailer.put("DEAL_TOT_AMT", String.format("%013d", deal_tot_amt));
			hmTailer.put("CANCEL_CNT", String.format("%07d", cancel_tot_cnt));
			hmTailer.put("CANCEL_TOT_AMT", String.format("%013d", cancel_tot_amt));
			hmTailer.put("FILLER", " ");
			sbFile.append(makeTailerOfTMoneyPaymentFile(hmTailer));
						
			// 지불 내역 파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTMoneyPaymentFileNM);
			
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTMoneyPaymentFileNM);
				
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					dao.updTMONEYPAYMENTTRAN("1", (String)map.get("TRAN_ID"), (String)map.get("COM_CD"));
				}
			}
			
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
	
	public boolean createTMNALIDPSAMIDFile() {
		boolean bIsCreatedFile = false;
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			TMoneySenderDAO dao = new TMoneySenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String toDay = sdf.format(calendar.getTime());
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			//String destPath = basePath + "\\files\\up\\tmoney";
			String destPath = basePath + File.separator +  "files" + File.separator + "up" + File.separator + "tmoney";
			// 전송 파일명 : 연계기능별구분코드'TZ' + 업체코드'MM' + 전송일자'MMDD'
			String strTMNALIDSAMIDFileNM = "TZWM" + toDay.substring(4);
			String strTMFCSTR_ID = PropertyUtil.findProperty("service-property", "TMONEY_FCSTR_ID");	// 티머니 대표가맹점ID
			
			// 단말기 ID / PSAM ID 설치 정보내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_TP", "H");
			hmHeader.put("FILE_CRT_DT", toDay);
			hmHeader.put("FILLER", " ");
			
			sbFile.append(makeHeaderOfFile(hmHeader));
			
			list = dao.selTMONEYTMLSAMIDMST(com_cd);
			
			if( list.size() > 0 ) {
				for(int i = 0;i < list.size();i++) {
					HashMap<String, String> hmData = new HashMap<String, String>();
					Map<String, String> map = (Map<String, String>)(list.get(i));
					
					hmData.put("RECORD_TP", "D");
					hmData.put("SNO", String.format("%07d", i + 1));
					hmData.put("REP_FCSTR_ID", strTMFCSTR_ID);
					hmData.put("FCSTR_ID", (String)map.get("FCSTR_ID"));
					hmData.put("TMNAL_ID", (String)map.get("TMNAL_ID"));
					hmData.put("SAM_ID", (String)map.get("SAM_ID"));
					hmData.put("SAM_TP", "2");
					hmData.put("FILLER", " ");
					sbFile.append(makeDataOfTMNALSAMIDFile(hmData));
				}
				
				HashMap<String, String> hmTailer = new HashMap<String, String>();
				hmTailer.put("RECORD_TP", "T");
				hmTailer.put("TOTAL_DATA_ROWS", String.format("%02d", list.size()));
				hmTailer.put("FILLER", " ");
				sbFile.append(makeTailerOfTMNALSAMIDFile(hmTailer));
				
				// 단말기 ID/PSAM ID 설치정보내역 파일 생성
				bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTMNALIDSAMIDFileNM);
	
				// 파일 생성 시 처리상태구분코드 Update
				if( bIsCreatedFile ) {
	//				String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
					logger.info(" >>>>>>>>>>>>> Created File " + strTMNALIDSAMIDFileNM);
					
					for(int i = 0;i < list.size();i++) {
						Map<String, String> map = (Map<String, String>)list.get(i);
						dao.updTMONEYTMLSAMIDMST("1", com_cd, (String)map.get("FCSTR_ID")
								, (String)map.get("TMNAL_ID"), (String)map.get("SAM_ID"));
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
	
	private String makeHeaderOfFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,8,291};
		String strHeaders[] = {
			"RECORD_TP"		,
			"FILE_CRT_DT"	,
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeDataOfTMoneyPaymentFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,7,20,7,9
					  ,8,5,16,10,20
					  ,10,3,10,10,10
					  ,14,2,2,2,10
					  ,5,10,8,2,2
					  ,1,14,2,80};
		String strHeaders[] = {
			"RECORD_TP",
			"SNO",
			"TRANSACTION_ID",
			"FCSTR_ID",
			"TMNAL_ID",
			
			"TRAN_YMD",
			"TRAN_NO",
			"PSAM_ID",
			"PSAM_TRAN_SEQ_NO",
			"PPCARD_NO",
			
			"PPCARD_TRAN_SEQ_NO",
			"TMONY_TASK_TP",
			"PPCARD_PRE_REM_AMT",
			"PPCARD_REQ_AMT",
			"PPCARD_AFT_REM_AMT",
			
			"TRAN_DTM",
			"ALGO_NO",
			"SPBY_TRAN_KEY_VER",
			"ELE_MONY_IDTY",
			"PSAM_TOT_AMT_COLECT_SEQ_NO",
			
			"PSAM_SPBY_COLECT_CNT",
			"PSAM_ACCM_TOT_AMT",
			"SIGN_VAL",
			"CARD_TP_VAL",
			"CARD_HOLDER_TP",
			
			"HSM_STATUS",
			"ERR_YMDHMS",
			"ERR_CD",			
			"FILLER"
		};
		
		for(int i = 0;i < nlens.length;i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeDataOfTMNALSAMIDFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,7,7,7,9
					  ,16,1,252};
		String strHeaders[] = {
			"RECORD_TP"		,
			"SNO"			,
			"REP_FCSTR_ID"	,
			"FCSTR_ID"		,
			"TMNAL_ID"		,
			
			"SAM_ID"		,
			"SAM_TP"		,
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeTailerOfTMoneyPaymentFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,7,7,13,7
					 ,13,252};
		String strHeaders[] = {
			"RECORD_TP",
			"TOTAL_DATA_ROWS",
			"DEAL_CNT",
			"DEAL_TOT_AMT",
			"CANCEL_CNT",
			
			"CANCEL_TOT_AMT",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeTailerOfTMNALSAMIDFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,7,292};
		String strHeaders[] = {
			"RECORD_TP"			,
			"TOTAL_DATA_ROWS"	,
			"FILLER"			
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
}