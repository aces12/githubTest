/*
 * SysInfoRcvProtocol.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_TranCall;

import java.util.HashMap;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;

import biz.comm.COMMBiz;


/** 
 * SysInfoRcvProtocol
 *  
 * @created  on 1.0,  11/03/17
 * @created  by oki(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */ 
public class TranCallProtocol {

	private static Logger logger = Logger.getLogger(TranCallProtocol.class);
	
	/***
	 * getRcvTranCallDATA
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	
	public int getRcvTranCallDATA(String rcvBuf){		
		HashMap hm = new HashMap();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};   
	
		String strHeaders[] = {      				
				"INQ_TYPE"		   // INQ Type(INQ 종별)    
			};		
		
		logger.info("▶ Receive Data" + rcvBuf );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if (Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE"))){
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		return ret;
	}	


	/***
	 * getParseTranCall: Tran Data request to hm hashmap according to message layout(거래호출을 전문레이아웃에 맞춰 hm hashmap에 저장한다).
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseTranCall(String rcvBuf){		
		HashMap hm = new HashMap();
		int nlens[]= {2,13,8,5,4,4};   
		String strHeaders[] = {      				                                                                        
				"INQ_TYPE"		, // INQ Type(INQ 종별)    
				"OP_NO"				, // Operator No(담당자번호) 
				"REQ_TRAN_YMD"		, // Tran Date(거래일자)
				"REQ_STORE_CD"		, // Store Code(점포코드)
				"REQ_POS_NO"		, // POS No.(포스번호)
				"REQ_TRAN_NO"		  // Tran No(거래번호)
			};
		
		logger.info("▶ getParseTranCall-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders,rcvBuf);
		
		return hm;
	}	
};


	
