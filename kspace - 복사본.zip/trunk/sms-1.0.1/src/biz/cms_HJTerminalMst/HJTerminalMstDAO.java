package biz.cms_HJTerminalMst;

import java.util.HashMap;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

import org.apache.log4j.Logger;

/**
 * 한진 택배 터미널ID 정보 취득 처리 DAO
 * 
 * @author FCV00040
 */
public class HJTerminalMstDAO extends GenericDAO {

	private static Logger logger = Logger.getLogger(HJTerminalMstPollingAction.class);

	/**
	 * 한진 터미널정보 갱신 
	 * @param hm
	 * @return
	 * @throws Exception
	 */
	public int insHJTerminalMst(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		String strQuery = null;
		int i = 0;
		int rows = -1;

		try {
			begin();

			connect("CMGNS"); //DB Connection(DB 접속)

			strQuery = findQuery("service-sql", "INS_HJ_TERMINAL_MST"); 

			sql.put(strQuery);

			sql.setString(++i, (String)hm.get("POST_NO"));
			sql.setString(++i, (String)hm.get("CITY_ADDR"));
			sql.setString(++i, (String)hm.get("GU_ADDR"));
			sql.setString(++i, (String)hm.get("DONG_ADDR"));
			sql.setString(++i, (String)hm.get("SUB_ADDR"));

			sql.setString(++i, (String)hm.get("TERMINAL_CD"));
			sql.setString(++i, (String)hm.get("TERMINAL_NM"));
			sql.setString(++i, (String)hm.get("SALE_CD"));
			sql.setString(++i, (String)hm.get("SALE_NM"));
			sql.setString(++i, (String)hm.get("DELI_HOUR"));

			sql.setString(++i, (String)hm.get("DIVISION_TP"));
			sql.setString(++i, (String)hm.get("HUB_CD"));
			sql.setString(++i, (String)hm.get("MID_CD"));
			sql.setString(++i, (String)hm.get("SUB_CD"));
			sql.setString(++i, (String)hm.get("COL_AREA_NM"));
			
			sql.setString(++i, (String)hm.get("ES_NM"));
			sql.setString(++i, (String)hm.get("QUICK_AREA"));

			rows = executeUpdate(sql);
		} catch (Exception e) {
			rollback();
			logger.info("[ERROR] HJTerminalMstDAO.insHJTerminalMst() : " + e.getMessage());
			throw e;
		} finally {
			end();
		}

		return rows;
	}

}
