/*
 * MasterRunner.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_MasterCrt;

import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.CurrentContext;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.node.EngineContainer;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.DaemonContainer;
import kr.fujitsu.com.ffw.daemon.net.client.ActionClientContainer;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.daemon.net.server.ActionServerContainer;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.cms_DeployReq.DeployReqClientAction;
import biz.cms_MasterAgent.MasterAgentDAO;
import biz.cms_MasterAgent.MasterAgentPOSOperator;
import biz.cms_MasterAgent.MasterAgentPollingAction;
import biz.cms_MasterAgent.MasterAgentPushRetry;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;

/** 
 * MasterRunner
 * Identify method to generate file according to deliminator of the master file(마스터 파일의 구분자에 따라 파일 생성하는 방식을 구분한다).
 * Call MasterExcutor(MasterExcutor를 호출)
 * @created  on 1.0,  11/03/17
 * @created  khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by  
 */ 
public class MasterCrtRunner implements Runnable {// 0213 use Thread Pool  // //extends Thread {   //original code	 

	private final int POS_PORT = 9029;
	//private final int MAX_TARGET_NUM = 100;
	
	private static Logger logger = Logger.getLogger(MasterCrtClientAction.class);

	private MasterCrtClientAction action = null;
	private Map map = null;
	private List list170G = null;//180423 leeseungho 170at 생성방식 변경
	private DaemonConfigLocator locator = null;
	private int curWork = 0;

	/**
	 * Create MasterRunner(MasterRunner 생성)
	 * @param action
	 */
	public MasterCrtRunner(MasterCrtClientAction action) {
		this.action = action;
	}

	/**
	 * Set Map value transferred from MasterAction(MasterClientAction에서 넘어온 Map 값 셋팅) 
	 * @param map
	 */
	public void setMap(Map map) {
		this.map = map;
	}
	
	//180423 leeseungho 170at 생성방식 변경
	public void setList170G(List list) {
		this.list170G = list;
	}
	
	
	public static String[] getMapKeys(Map map) {
		if (map == null) {
			return null;
		}
		String[] ret = new String[map.size()];
		int inc = 0;
		for (Iterator i = map.keySet().iterator(); i.hasNext();) {
			ret[inc++] = (String) i.next();
		}

		return ret;
	}
	
	/**
	 * Execute Generation of Deployment File(배신 파일 생성 실행)
	 */
	public void run(){
		try {			
			int ret = -1;			
																													// thread +				//action.msControl.useThread(); 			// 0213 delete for use Thread Pool//original code
			String trans_id = (String)map.get("TRANS_ID");			
			logger.info(Thread.currentThread().getName()+" START ["+(String)map.get("TRANS_SEQ")+"/"+(String)map.get("STORE_CD")+"]    " );
			
			if (   !(trans_id.equals("PGM")) && !(trans_id.equals("MSG"))	)
				ret = generateMasterFile(map);
			
			logger.info(Thread.currentThread().getName()+" END   ["+(String)map.get("TRANS_SEQ")+"/"+(String)map.get("STORE_CD")+"]    " );
			
			action.workIncrement();		
			this.curWork = action.getWork();											
																													//action.msControl.returnThread();			//0213 delete for use Thread Pool original code							
			if (action.getStatus()) {
				logger.info("***getStatus() The end " );
				return;
			}			
			
		} catch(Exception e) {
			logger.info("[ERROR1] making Mst Thread Exception" + e);
		}finally{
			//System.gc();		// 0213 use delete System.gc() //
		}

	}

				
		
			

	
	/**
	 * generateMasterFile - Generate Deployment File(배신 파일 생성)
	 * @param map
	 * @return int 
	 */
	private int generateMasterFile(Map map) {
		MasterCrtExecutor exe   = new MasterCrtExecutor();
		exe.setList170G(this.list170G); //180423 leeseungho 170at 생성방식 변경
		MasterCrtDAO dao   = new MasterCrtDAO();
		String transId = (String)map.get("trans_id");
		String fileDir = null;
		int ret = -1;
		try {
			//System.out.println("trans_id : " + transId);
			// Generate Deployment File : POS Master(배신 파일 생성 : POS 마스터)
			if(transId.equals("MST")) {
//				ret = dao.updSTBDA100AT0(map);  // 마스터생성중 플래그세팅
				fileDir = exe.runMst(map);		// Return directory on whick file has been generated(파일이 생성된 디렉토리 리턴)
			} 		
			// Generate Deployment File : Owner POS Master(배신 파일 생성 : 점주 POS 마스터)
			else if(transId.equals("POSDLL")) {
				fileDir = exe.runMst(map);		// Return directory on whick file has been generated(파일이 생성된 디렉토리 리턴)
			} 

			// Generate Deployment File : FF-IMAGE Master(배신 파일 생성 : FF-IMAGE 마스터)
			else if(transId.equals("FFIMG")) {
				fileDir = exe.runFFImg(map);	// Return directory on whick file has been generated(파일이 생성된 디렉토리 리턴)
			}
			//파일생성 경로를 FTP 다운로드 경로로 변환
			// 마스터 배포 방식 변경 시작(20131125/조충연)
			/*
			String basePath = PropertyUtil.findProperty("stsys-property", "FTP_ROOT");	// FTP 루트 
			String addPath  = ((String)map.get("urgent_yn")).equals("0") ? "deploy" : "urgent";
			String ftpPath = basePath+"/"+(String)map.get("trans_id")+"/"+(String)map.get("trans_ymd")+"/"+addPath+"/"+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+".zip"; // (FTP 다운로드 풀경로)
			*/
			
			if( !fileDir.equals("ERROR") ) {
				
				String basePath = PropertyUtil.findProperty("stsys-property", "FTP_ROOT");	// FTP 루트 
				String addPath = "";
				if(((String)map.get("urgent_yn")).equals("0")) {		// 정기배신
					addPath = "deploy";
				}else if(((String)map.get("urgent_yn")).equals("1")) {	// 긴급(전체)
					addPath = "urgent1";
				}else if(((String)map.get("urgent_yn")).equals("2")) {	// 긴급(변경row)
					addPath = "urgent2";
				}
				String ftpPath = basePath+"/"+(String)map.get("trans_id")+"/"+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+"/"+addPath+"/"+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+".zip"; // (FTP 다운로드 풀경로)
				
				// 마스터 배포 방식 변경 끝(20131125/조충연)
	
				map.put("trans_file_dir", ftpPath);
	
				// DB Update - Correct Deployment status value(DB 업데이트 - 배신 상태값 수정)
				//System.out.println(">>>>>>>>>>>>>>>>>fileDir::" + fileDir);
				//System.out.println(">>>>>>>>>>>>>>>>>ftpDir::" + ftpPath);
				//System.out.println(">>>>>>>>>>>>>>>>>Before Deploy Update");
				ret = dao.updSTBDA100AT1(map);  //마스터생성완료 플래그세팅
				//System.out.println(">>>>>>>>>>>>>>>>>After Deploy Update");
				//			if(ret > 0) ret = 1;
			}else {
				logger.info("[ERROR5] POS마스터파일 생성 실패(" + (String)map.get("urgent_yn") + "/" + (String)map.get("store_cd") + "/" + (String)map.get("trans_id")+ "/" + (String)map.get("trans_seq") + ")");
				ret = dao.spSMSSEND("POS마스터파일 생성 실패("+(String)map.get("store_cd")+")", "cms_MasterCrt");
			}
		} catch (Exception e) {
			logger.info("[ERROR2]" + e);
		}
		
		return ret;
	}
	

		
	public void newDeploy(Map map) throws Exception{
		
		MasterAgentDAO dao   = new MasterAgentDAO();
		
		List list = null;		
		int ret = -1;
		String local_no = PropertyUtil.findProperty("communication-property", "LOCAL_SERVER_NO");

//		신배신 처리 시작
//		 * 	신배신 적용 점에 대해 pos list 작성하고 그 pos 들을 대상으로 
//		 * pushMSG(파일전송의뢰 응답 전문(inqtype = 04))를 보내고 해당 MSG 의 응답을 받아 관리 하고  
//		 * pushMsg 의 응답을 받지 못한 점을 대상으로 재전송 함
		
		
		// 직전 만들어진 점의  POS List 조회		
		//call Thread but problem is  there are can't recognize final time
		String transid = (String)map.get("TRANS_ID");
		if (transid.equals("MST")){
			list = dao.selSendPushPosLIST((String)map.get("TRANS_YMD"),local_no,(String)map.get("TRANS_SEQ")
					,(String)map.get("STORE_CD"),transid);
			
		}else if (transid.equals("PGM")|| transid.equals("MSG")){
			list = dao.selSendPushPosLISTPGM((String)map.get("TRANS_YMD"),local_no,(String)map.get("TRANS_SEQ")
					,(String)map.get("STORE_CD"),transid);
			
		} 
				
		logger.info("[TRANS_YMD: "+ (String)map.get("TRANS_YMD") 
				+ "] [STORE_CD: "   +(String)map.get("STORE_CD")+"]"
				+ "] [TRANS_SEQ: "   +(String)map.get("TRANS_SEQ")+"]"
				+ "] [DEPLOY_POS_CNT "   +list.size()+"]"
				);		
					
		
//		list = dao.selSTBDA100ATOri((String)map.get("TRANS_YMD"), (String)map.get("COM_CD"), (String)map.get("STORE_CD"), local_no);
		Map<String, String> mapNew = null;
		for(int j=0; j<list.size(); j++) {

			mapNew = (Map<String, String>)list.get(j);		
			
			if( ((String)mapNew.get("POS_IP")).length() == 0 ) {
				// PROC_ID = "0":미송신, "1":송신중, "2":송신완료, "3":송신에러, "4":전송 3회 모두 송신실패 , "5": POS IP 없음
				dao.updTARGETMASTERLIST(mapNew, "5");	
				logger.info("this store["+(String)mapNew.get("STORE_CD")
						+"] has not pos IP pos_no:"+ (String)mapNew.get("POS_NO"));
				
			}else{
				// for test
				/*if( ((String)mapNew.get("POS_IP")).equals("10.149.206.188") )
					mapNew.put("POS_IP", "10.100.116.180");
				if( ((String)mapNew.get("POS_IP")).equals("10.149.206.178") )
					mapNew.put("POS_IP", "10.100.116.181");
				if( ((String)mapNew.get("POS_IP")).equals("10.149.206.179") )
					mapNew.put("POS_IP", "10.100.116.182");
				if( ((String)mapNew.get("POS_IP")).equals("10.149.206.180") )
					mapNew.put("POS_IP", "10.100.116.183");*/
				//
				//interval 적용 단위 millisecond			
				Thread.sleep( Integer.parseInt((String)mapNew.get("INTERVAL")));
				//logger.info("[CURRENT STORE INTERVAL: "+ (String)mapNew.get("INTERVAL") + "] [STORE_CD:"+(String)mapNew.get("STORE_CD")+"]");
				sendOrderToPOS(mapNew);				
			}
		}
		
		////////////////////////////////////////////////////////////////		
	} 
	
	
	private void sendOrderToPOS(Map<String, String> map) {
		MasterAgentDAO dao = new MasterAgentDAO();
		Socket sock = null;
		ActionSocket actSock = null;
		String sendData = "";
		String recvData = "";
		boolean bIsOK = false;
//		logger.info("★IP:" +(String)map.get("POS_IP")
//				+"★1st★sendOrderToPOS★ "
//				+"★STORE_CD:" +(String)map.get("STORE_CD")
//				+"★POS_NO:" +(String)map.get("POS_NO")
//				+"★NEW_DEPLOY_YN:" +(String)map.get("NEW_DEPLOY_YN")				
//		);		
		
		
		// PROC_ID = "0":미송신, "1":송신중, "2":송신완료, "3":송신에러, "4":전송 3회 모두 송신실패 , "5": POS IP 없음  
		try {

			//sock = new Socket((String)map.get("POS_IP"), POS_PORT);
			sock = new Socket();
			SocketAddress serverAddress = new InetSocketAddress((String)map.get("POS_IP"), POS_PORT);
			sock.connect(serverAddress, 3000);

			actSock = new ActionSocket(sock, (Filter)(new COMMConveyerFilter(COMMBiz.MASTER_EXT_FILTER)));

			
			actSock.getSocket().setSoTimeout(3000);
						
			sendData = makeMasterOrderMessage(map);
			logger.info("[sms>pos] STORE_CD["+ (String)map.get("STORE_CD")
					+"]POS_NO["+ (String)map.get("POS_NO")
					+"]TRANS_SEQ["+ (String)map.get("TRANS_SEQ")
					+"]IP:"+ (String)map.get("POS_IP")
					+"length[" + sendData.length() + "]::[" + sendData + "]"
					);
			//actSock.send(sendData);
			if( actSock.send(sendData) ) {
				logger.info("[sms>pos] STORE_CD["+ (String)map.get("STORE_CD")
						+"]TRANS_SEQ["+ (String)map.get("TRANS_SEQ")
						+"]IP:"+ (String)map.get("POS_IP")						
						+"[sms>pos] SEND["+ sendData.length() + "] OK");
			}
			
			recvData = (String)actSock.receive();
			//logger.info("[sms<pos] RECV[" + recvData.length() + "]:[JOB_CODE:]:[" + recvData + "]");
			
			if( recvData.trim().equals("OK") ) {
				bIsOK = true;
				dao.updTARGETMASTERLIST(map, "2");
				logger.info("[★RECV OK★] [IP: "+ (String)map.get("POS_IP") +"]POS_NO["+ (String)map.get("POS_NO")+ "] [STORE_CD:"+(String)map.get("STORE_CD")+ "]:[recvData][" + recvData + "]");
			}else {
				dao.updTARGETMASTERLIST(map, "3");
				logger.info("[recv OK FAIL ] [IP: "+ (String)map.get("POS_IP") + "] [STORE_CD:"+(String)map.get("STORE_CD")+"]");
			}
		}catch(SocketTimeoutException ste) {		// flag를 오류로 변경..나중에 오류인 것들만 다시 돌린다.
			dao.updTARGETMASTERLIST(map, "3");
			logger.info("[1st][ERROR:TimeOut][STORE_CD:"+(String)map.get("STORE_CD")+"]POS_NO["+ (String)map.get("POS_NO")+"][IP: "+ (String)map.get("POS_IP") + "]" + ste.getMessage());
		}catch(Exception e) {						// flag를  완료로 변경			 
			dao.updTARGETMASTERLIST(map, "3");
			logger.info("[1st][Exception ERROR][STORE_CD:"+(String)map.get("STORE_CD")+"]POS_NO["+ (String)map.get("POS_NO")+"][IP: "+ (String)map.get("POS_IP") + "]" + e.getMessage());
		}finally {
			if(actSock != null) actSock.close();
		}
	}
	
	public String getLocalIP() {
		InetAddress iAddress;
		String currentIp = "";
		try {
			iAddress= InetAddress.getLocalHost();
			currentIp = iAddress.getHostAddress();
		}catch(Exception e) {
			logger.info("[ERROR3]" + e);
		}
		
		return currentIp;
	}
	
	public String makeMasterOrderMessage(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		
		try {
			String transId = (String)map.get("TRANS_ID");
			String fileDir = (String)map.get("TRANS_FILE_DIR");						

			StringUtil.appendSpace(sb, "04", 2);							// 01.INQ_종별("04":파일전송의뢰)
					
			if( transId.equals("PGM") ) {
				transId = "01";
			}else if( transId.equals("MST") ) {
				transId = "02";
			}else if( transId.equals("CUSTDSP") ) {
				transId = "03";
			}else if( transId.equals("FFIMG") ) {
				transId = "04";
			}else if( transId.equals("POSDLL") ) {
				transId = "05";
			}else if( transId.equals("MSG") ) {
				transId = "06";
			}else {
				transId = "%";
			}

			
			// 긴급 메세지의 경우 전문 형태가 다르다. 
			if( transId.equals("06") ) {
				MasterAgentDAO dao = new MasterAgentDAO();
				List<Object> list = dao.selURGENTMSGLIST(map);
				if( list.size() > 0 ) {
					Map<String, String> m = (Map<String, String>)list.get(0);
					
					StringUtil.appendSpace(sb, transId, 2);						// 01.상세종별(01:프로그램,02:마스터,03:객면컨텐츠,04:상품이미지,05:POSDLL,06:긴급메세지)
					StringUtil.appendSpace(sb, (String)m.get("TRANS_VER"), 10);	// 02.메시지번호
					StringUtil.appendSpace(sb, (String)m.get("URGENT_YN"), 1);	// 03.메시지구분
					StringUtil.appendSpace(sb, (String)m.get("POS_SYMDHMS"),12);// 04.게시시작일시
					StringUtil.appendSpace(sb, (String)m.get("POS_EYMDHMS"),12);// 05.게시종료일시
					StringUtil.appendSpace(sb, (String)m.get("MSG_TITLE"), 100);// 06.메시지(타이틀)
					StringUtil.appendSpace(sb, (String)m.get("MSG_CONT"), 1000);// 07.메시지					
				}
				
			}else {

				StringUtil.appendSpace(sb, transId, 2);							// 01.상세종별(01:프로그램,02:마스터,03:객면컨텐츠,04:상품이미지,05:POSDLL,06:긴급메세지)
				StringUtil.appendSpace(sb, (String)map.get("URGENT_YN"), 1);	// 02.적용구분(0:일반배신,1:즉시적용,2:긴급적용)
				StringUtil.appendSpace(sb, (String)map.get("TRANS_YMD"), 14);	// 03.적용일시
				StringUtil.appendSpace(sb, getLocalIP(), 15);					// 04.서버IP
				int dot = fileDir.lastIndexOf("/");
				StringUtil.appendSpace(sb, fileDir.substring(0, dot), 100);		// 05.파일경로
				StringUtil.appendSpace(sb, fileDir.substring(dot+1), 20);		// 06.파일명
				StringUtil.appendSpace(sb, (String)map.get("TRANS_VER"), 30);	// 07.파일버전

			}
		}catch(Exception e) {
			logger.info("[ERROR4]" + e);
		}
		
		return sb.toString();
	}

}
