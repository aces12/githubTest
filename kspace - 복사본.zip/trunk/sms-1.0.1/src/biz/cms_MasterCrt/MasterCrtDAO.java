/*
 * MasterDAO.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */

package biz.cms_MasterCrt;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;

/** 
 * MasterDAO
 * A class that has inherited GenericDAO(GenericDAO를 상속받은 클래스)
 * It is responsible for functions to access DB to retrieve respective information(DB에 접속하여 해당 정보를 조회해 오거나)
 * or update DB information(DB정보를 업데이트 하는 기능을 담당한다).
 * @created  on 1.0,  11/03/17
 * @created  khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok 
 * @caused   by  
 */ 
public class MasterCrtDAO extends GenericDAO{	
	//private static Logger logger = Logger.getLogger(MasterCrtDAO.class);
	private static Logger logger = Logger.getLogger(MasterCrtClientAction.class);
	
	public int spSMSSEND(String strMsg, String strSender) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("stsys-sql", "PR_SMSSEND"));
			sql.setString(++i, strMsg);
			sql.setString(++i, strSender);
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
	
	
	/*
	 * 마스터 생성 중 FLAG 세팅을 파일 생성 전에 한번에 변경
	 * OPER_ID => '1'
	 */
	public int updSTBDA100AT0ALL(List<Object> list) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			begin();
			
			for(int j = 0;j < list.size();j++)
			{
				i = 0;
				Map<String, String> map = (Map<String, String>)list.get(j);
				
				sql.clearParameter();
				sql.put(findQuery(COMMBiz.XML_STSYS_SQL, "UPD_STBDA100AT0ALL"));
				
				sql.setString(++i, (String)map.get("TRANS_YMD"));
				sql.setString(++i, (String)map.get("STORE_CD"));
				sql.setInt(++i, Integer.parseInt((String)map.get("TRANS_SEQ")));
				
//				logger.info(sql.debug());
				ret = executeUpdate(sql);
				sql.close();
			}
//			sql.put(findQuery(COMMBiz.XML_STSYS_SQL, "UPD_STBDA100AT0ALL"));
//			sql.setString(++i, transYmd);
//			sql.setInt(++i, transSeq);			
//
//			logger.info("[DEBUG] sql=" + sql.debug());
//			
//			ret = executeUpdate(sql);
			
		}catch(Exception e) { //이 익셉션...
			logger.info("[ERROR]" + e.getMessage()); 
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	
	/*
	 * FLAG 세팅을 파일 생성 전에 한번에 변경
	 * PROC_ID => '1'
	 */
	public int updSTBDA100AT0ALLPGMMSG(List<Object> list) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			begin();
			
			for(int j = 0;j < list.size();j++)
			{
				i = 0;
				Map<String, String> map = (Map<String, String>)list.get(j);
				
				sql.clearParameter();
				sql.put(findQuery(COMMBiz.XML_STSYS_SQL, "UPD_STBDA100AT0ALLPGMMSG"));
				
				sql.setString(++i, (String)map.get("TRANS_YMD"));
				sql.setString(++i, (String)map.get("STORE_CD"));
				sql.setInt(++i, Integer.parseInt((String)map.get("TRANS_SEQ")));
				sql.setString(++i, (String)map.get("TRANS_ID"));
				ret = executeUpdate(sql);
//				logger.info(sql.debug());
				sql.close();
			}
//			sql.put(findQuery(COMMBiz.XML_STSYS_SQL, "UPD_STBDA100AT0ALLPGMMSG"));
//			sql.setString(++i, transYmd);
//			sql.setInt(++i, transSeq);			
//
//			logger.info("[DEBUG] sql=" + sql.debug());
//			
//			ret = executeUpdate(sql);
			
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
		
	/**
     * Search stores to create master data file(마스터데이터 파일을 생성할 점포 조회)
     * @return List Store List(점포목록)
     * @exception exception Description of Exception(예외사항설명)
     */
	public List selSTBDA100AT(String transYmd, String com, String store, String local_no) {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		String tmpStr = "";
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_STBDA100AT"));
			sql.setString(++i, transYmd);	// trans_ymd
			sql.setString(++i, com);	// com_cd
			sql.setString(++i, store);	// store_cd
			sql.setString(++i, local_no);	
			tmpStr = sql.debug();
			//logger.info("[[[[[[[[DEBUG]]]]]]]" + tmpStr);
			list = executeQuery(sql);			
			logger.info("[★★★★SEL_STBDA100AT★★★★]" );
			//logger.info(tmpStr);
		} catch (Exception e) {
//			System.out.println(e.getMessage());
			logger.info("[ERROR]" + e);

			logger.info("[DEBUG]" + tmpStr);

		} 
		
		return list;
	}

	/**
     * Search stores to create master data file(마스터데이터 파일을 생성할 점포 조회)
     * @return List Store List(점포목록)
     * @exception exception Description of Exception(예외사항설명)
     */
	public List selSTBDA100ATPGM(String transYmd, String com, String store, String local_no) {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_STBDA100ATPGM"));
			sql.setString(++i, transYmd);	// trans_ymd
			sql.setString(++i, com);	// com_cd
			sql.setString(++i, store);	// store_cd
			sql.setString(++i, local_no);	// store_cd
			list = executeQuery(sql);
			//logger.info("[DEBUG]" + sql.debug());
		} catch (Exception e) {
//			System.out.println(e.getMessage());
			logger.info("[ERROR]" + e);
			try {
				logger.info("[DEBUG]" + sql.debug());
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} 
		
		return list;
	}
	
	/**			
     * Search stores to create master data file(마스터데이터 파일을 생성할 점포 조회)
     * @return List Store List(점포목록)
     * @exception exception Description of Exception(예외사항설명)
     */
	public List selSTBDA100ATMSG(String transYmd, String com, String store, String local_no) {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_STBDA100ATMSG"));
			sql.setString(++i, transYmd);	// trans_ymd
			sql.setString(++i, com);	// com_cd
			sql.setString(++i, store);	// store_cd
			sql.setString(++i, local_no);	// store_cd
			list = executeQuery(sql);
			//logger.info("[DEBUG]" + sql.debug());
		} catch (Exception e) {
			try {
				logger.info("[DEBUG]" + sql.debug());
			} catch (Exception e1) {
				e1.printStackTrace();
			}
//			System.out.println(e.getMessage());
			logger.info("[ERROR]" + e);
		} 
		
		return list;
	}
	
	
	
	
	
	
	/**
     * Search stores to create master data file(push msg 전송할 포스 조회)
     * @return List Store List(포스목록)
     * @exception exception Description of Exception(예외사항설명)
     */
	public List selSTBDA100ATOri(String transYmd, String com, String store, String local_no) {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_STBDA100AT_ORI"));
			sql.setString(++i, transYmd);	// trans_ymd
			sql.setString(++i, com);	// com_cd
			sql.setString(++i, store);	// store_cd
			sql.setString(++i, local_no);	// store_cd
			list = executeQuery(sql);
			logger.info("[DEBUG]" + sql.debug());
		} catch (Exception e) {
//			System.out.println(e.getMessage());
			logger.info("[ERROR]" + e);
		} 
		
		return list;
	}	
	/**
	 * excuteProcedure - Call Master Procedure(마스터데이터 프로시저 호출)
	 * @param m
	 * @param sqlString : sqlname used in stsys-sql.xml(stsys-sql.xml에서 사용하는 sqlname)
	 * @param max : Variable to process paging (In the case of mass storage data, as it may have outofmemory, it is required to search data with paging)(paging 처리를 위한 변수 (대용량데이터일 경우 outofmemory에러가 발생할 수 있므로 paging처리해서 데이터 조회))
	 * @return List : Data List(데이터 목록)
	 * @throws Exception
	 */
	public String executeMasterProcedure( String sqlString ) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		String retMsg = "";
		// DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

			if (sqlString.equals("SP_MSTMERGE_ST2AT")) {
//				System.out.println("[DEBUG] [SP_MSTMERGE_ST2AT] Begin");
				proc.put("SP_MSTMERGE_ST2AT", 2);
				proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
				proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE
	
				ProcedureResultSet prs = super.executeUpdateProcedure(proc);
	
				retMsg = prs.getString(2);
	
				if (prs.getInt(1) != 0) {
					ret = "99";
					logger.info("[DEBUG] [SP_MSTMERGE_ST2AT] Error: "+ retMsg);
//					System.out.println("[DEBUG] [SP_MSTMERGE_ST2AT] Error: "+ retMsg);
				}
			} else if (sqlString.equals("PR_PROM_ITEM_PROC")) {
				Date date = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String currDate = sdf.format(date);

//				System.out.println("[DEBUG] [PR_PROM_ITEM_PROC] Begin");
				proc.put("PR_PROM_ITEM_PROC", 4);
				proc.setString(++i, currDate);	// CURRDATE
				proc.setString(++i, "0");	// DAILY_MOD
				proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
				proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE
	
				ProcedureResultSet prs = super.executeUpdateProcedure(proc);
	
				retMsg = prs.getString(4);
	
				if (prs.getInt(3) != 0) {
					ret = "99";
					logger.info("[DEBUG] [PR_PROM_ITEM_PROC] Error: "+ retMsg);
//					System.out.println("[DEBUG] [PR_PROM_ITEM_PROC] Error: "+ retMsg);
				}
			}
				
			commit();
		} catch(SQLException e){ 	
			logger.info( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			logger.info( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		} catch (Exception e) {
			logger.info( "▶ SEL Error : " + e);
			logger.info( "▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();	
			throw e;
		} finally {
			logger.info( "★ excuteProcedure complete. ");
			dataMsg = ret + "/" + retMsg;
			end();
		}

		return dataMsg;
	}

	/**
     * updSTBDA100AT0 - Modify status value after master file(마스터생성중 플래그세팅)
     * @param m
	 * m[0] = trans_ymd
	 * m[1] = store_cd
	 * m[2] = trans_id
	 * m[3] = trans_seq
	 * m[4] = urgent_yn
	 * m[5] = file_dir
     * @return int Rowcount of updated data(update된 데이터 rowcount)
     * @exception exception 
     */
	public int updSTBDA100AT0(Map map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i=0;
		int rows=-1;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();
			sql.put(findQuery(COMMBiz.XML_STSYS_SQL, COMMBiz.TB_UPD_STBDA100AT0));
			sql.setString(++i, (String)map.get("trans_ymd"));	// trans_ymd
			sql.setString(++i, (String)map.get("com_cd"));		// com_cd
			sql.setString(++i, (String)map.get("store_cd"));	// store_cd
			sql.setString(++i, (String)map.get("trans_id"));	// trans_id
			sql.setString(++i, (String)map.get("trans_seq"));	// trans_seq
//System.out.println("[DEBUG] [SQL]" + sql.debug());
//logger.info("[SQL][" + COMMBiz.TB_UPD_STBDA100AT0 + "]" + sql.debug());
			rows = executeUpdate(sql);
		} catch (Exception e) {
			rollback();
			throw e;
		} finally {
			end();
		}
		
		return rows;
	}	
	
	/**
     * updSTBDA100AT1 - Modify status value after master file(마스터생성완료 플래그세팅)
     * @param m
	 * m[0] = trans_ymd
	 * m[1] = store_cd
	 * m[2] = trans_id
	 * m[3] = trans_seq
	 * m[4] = urgent_yn
	 * m[5] = file_dir
     * @return int Rowcount of updated data(update된 데이터 rowcount)
     * @exception exception 
     */
	public int updSTBDA100AT1(Map map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i=0;
		int rows=-1;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();
			sql.put(findQuery(COMMBiz.XML_STSYS_SQL, COMMBiz.TB_UPD_STBDA100AT1));
			sql.setString(++i, (String)map.get("trans_file_dir"));	// file_dir
			sql.setString(++i, (String)map.get("trans_ymd"));	// trans_ymd
			sql.setString(++i, (String)map.get("com_cd"));		// com_cd
			sql.setString(++i, (String)map.get("store_cd"));	// store_cd
			sql.setString(++i, (String)map.get("trans_id"));	// trans_id
			sql.setString(++i, (String)map.get("trans_seq"));	// trans_seq
//System.out.println("[DEBUG] [SQL]" + sql.debug());
//			logger.info("[SQL][" + COMMBiz.TB_UPD_STBDA100AT1 + "]" + sql.debug());
			rows = executeUpdate(sql);
		} catch (Exception e) {
			rollback();
			throw e;
		} finally {
			end();
		}
		
		return rows;
	}	
	
	/**
	 * selectMaster - Search Master Data(마스터데이터 조회)
	 * @param m
	 * @param sqlString : sqlname used in stsys-sql.xml(stsys-sql.xml에서 사용하는 sqlname)
	 * @param max : Variable to process paging (In the case of mass storage data, as it may have outofmemory, it is required to search data with paging)(paging 처리를 위한 변수 (대용량데이터일 경우 outofmemory에러가 발생할 수 있므로 paging처리해서 데이터 조회))
	 * @return List : Data List(데이터 목록)
	 * @throws Exception
	 */
	public List selectMaster( Map map, String sqlString, int max) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			String flag = (String)map.get("urgent_yn");
			
			//sql.put(findQuery("stsys-sql", sqlString+flag));
			sql.put(findQuery("stsys-sql", sqlString));
			// Emergency(긴급)
			
//			if(flag.equals("1")) {
//				// Good Master(상품마스터)
//				if (sqlString.equals("SEL_STBDM130AT")) {
//					sql.setString(++i, (String)map.get("com_cd"));		// com_cd
//					sql.setString(++i, (String)map.get("store_cd"));	// store_cd
//					sql.setString(++i, (String)map.get("trans_ymd"));	// trans_ymd
//					sql.setInt(++i, max);		// paging from
//					sql.setInt(++i, max);		// paging to
//				} 
//				// Event Master, Event Good Master, Receipt Event Master, Receipt Event Good Master(행사마스터, 행사상품마스터, 영수증행사마스터, 영수증행사상품마스터) 
//				//if(sqlString.equals("SEL_STBDM100AT")||sqlString.equals("SEL_STBDM101AT")
//				// ||sqlString.equals("SEL_STBDM110AT")||sqlString.equals("SEL_STBDM111AT")) {
//				//	sql.setString(++i, (String)map.get("trans_ymd"));	// trans_ymd
//				//}
//
//			// Normal Time(정시)
//			} else {
				// PLU Master(PLU 마스터)
/*				if(sqlString.equals("SEL_STBDM130AT") || sqlString.equals("SEL_STBDM130AT2") ) {
//					System.out.println("[DEBUG] [trans_ymd]SEL_STBDM130AT"+flag+"=" + (String)map.get("trans_ymd")+"," + (String)map.get("store_cd"));
					sql.setString(++i, (String)map.get("store_cd"));		// store_cd
					sql.setString(++i, (String)map.get("com_cd"));			// com_cd
					sql.setInt(++i, max);		// paging from
					sql.setInt(++i, max);		// paging to
*/
			if(sqlString.equals("SEL_STBDM130AT")  ) {
//				System.out.println("[DEBUG] [trans_ymd]SEL_STBDM130AT"+flag+"=" + (String)map.get("trans_ymd")+"," + (String)map.get("store_cd"));
				sql.setString(++i, (String)map.get("SYS_DATE"));		//sys_date
				sql.setString(++i, (String)map.get("store_cd"));		// store_cd
				sql.setString(++i, (String)map.get("com_cd"));			// com_cd
				sql.setInt(++i, max);		// paging from
				sql.setInt(++i, max);		// paging to				
//				logger.info("[SQL][" + sqlString + "]" + sql.debug());
			}else if(sqlString.equals("SEL_STBDM130AT2") ) {
//					System.out.println("[DEBUG] [trans_ymd]SEL_STBDM130AT"+flag+"=" + (String)map.get("trans_ymd")+"," + (String)map.get("store_cd"));
					sql.setString(++i, (String)map.get("store_cd"));		// store_cd
					sql.setString(++i, (String)map.get("com_cd"));			// com_cd
					sql.setInt(++i, max);		// paging from
					sql.setInt(++i, max);		// paging to			
					//logger.info("[SQL][" + sqlString + "]" + sql.debug());					
			}else if( sqlString.equals("SEL_STBDM130AT_PDA") ) {
					sql.setString(++i, (String)map.get("store_cd"));		// store_cd
					sql.setString(++i, (String)map.get("com_cd"));			// com_cd
					sql.setString(++i, (String)map.get("store_cd"));		// store_cd
					sql.setString(++i, (String)map.get("com_cd"));			// com_cd
					sql.setInt(++i, max);		// paging from
					sql.setInt(++i, max);		// paging to
				}
//			}

//			logger.info("[SQL][" + sqlString + "]" + sql.debug());
//			System.out.println("[DEBUG] [SQL][" + sqlString + "]" + sql.debug());
			list = executeQuery(sql);
//			System.out.println("[DEBUG] [SQL][" + sqlString + "] result count:" + list.size());
		} catch (Exception e) {
			logger.info("[ERROR]" + e+"** MSG:"+e.getMessage());
//			System.out.println("[DEBUG] [ERROR][" + sqlString + "]" + e);
		} 
		
		return list;
	}

	/**
	 * selectGlobalMaster - Search Global Master Data(글로벌마스터데이터 조회)
	 * @param m
	 * @param sqlString : sqlname used in stsys-sql.xml(stsys-sql.xml에서 사용하는 sqlname)
	 * @param max : Variable to process paging (In the case of mass storage data, as it may have outofmemory, it is required to search data with paging)(paging 처리를 위한 변수 (대용량데이터일 경우 outofmemory에러가 발생할 수 있므로 paging처리해서 데이터 조회))
	 * @return List : Data List(데이터 목록)
	 * @throws Exception
	 */
	public List selectGlobalMaster( Map map, String sqlString, int max) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			String flag = (String)map.get("urgent_yn");
			sql.put(findQuery("stsys-sql", sqlString));
			// Promotion Master, Promotion Item Master, Receipt Promotion Master, Receipt Promotion Item Master(판촉행사마스터, 판촉행사상품마스터, 영수증행사마스터, 영수증행사상품마스터)
			if (sqlString.equals("SEL_STBDM270AT")
			  ||sqlString.equals("SEL_STBDM102AT")||sqlString.equals("SEL_STBDM103AT")
			  ||sqlString.equals("SEL_STBDM110AT")||sqlString.equals("SEL_STBDM111AT")
			  ||sqlString.equals("SEL_STBDM140AT")||sqlString.equals("SEL_STBDM141AT")
			  ||sqlString.equals("SEL_STMBS120AT")||sqlString.equals("SEL_STMBS130AT")
			  ||sqlString.equals("SEL_STMBS140AT")||sqlString.equals("SEL_STMBS170AT")
			  ||sqlString.equals("SEL_STBDM640AT")||sqlString.equals("SEL_STBDM650AT")
			  ||sqlString.equals("SEL_STBDM660AT")||sqlString.equals("SEL_STBDM661AT")
			  ||sqlString.equals("SEL_STBDM160AT")||sqlString.equals("SEL_STBDM161AT")
			  ||sqlString.equals("SEL_STBDM162AT")||sqlString.equals("SEL_STBDM163AT")
			  ||sqlString.equals("SEL_STBDM164AT")||sqlString.equals("SEL_STBDM165AT")
			  ||sqlString.equals("SEL_STBDM159AT")||sqlString.equals("SEL_STBDM300AT")
			  ||sqlString.equals("SEL_STBDM104AT")||sqlString.equals("SEL_STBDM112AT")
			  ||sqlString.equals("SEL_STBDM940AT")||sqlString.equals("SEL_STBDM941AT")
			  ||sqlString.equals("SEL_STBDM942AT")
			) {
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				if( sqlString.equals("SEL_STBDM102AT") || sqlString.equals("SEL_STBDM103AT") || sqlString.equals("SEL_STBDM104AT")
				 || sqlString.equals("SEL_STBDM110AT") || sqlString.equals("SEL_STBDM111AT") || sqlString.equals("SEL_STBDM112AT")
				 || sqlString.equals("SEL_STBDM940AT") || sqlString.equals("SEL_STBDM941AT") || sqlString.equals("SEL_STBDM942AT")) {
					//if( (((String)map.get("trans_ver")).substring(8)).equals("01") ) {	// 정기배신
					if( ((String)map.get("urgent_yn")).equals("0") && ((String)map.get("trans_seq")).equals("1") ) {		// 정기 배신
						sql.setString(++i, "0");
						sql.setString(++i, "0");
					}else {	// 기타
						sql.setString(++i, "1");
						sql.setString(++i, "1");
					}
				}
			} else if(sqlString.equals("SEL_STBDM170AT")
			  ||sqlString.equals("SEL_STBDM020AT")||sqlString.equals("SEL_STBDM051AT")
			  ||sqlString.equals("SEL_STBDM052AT")||sqlString.equals("SEL_STBDM053AT")
			  ||sqlString.equals("SEL_STBDM271AT")||sqlString.equals("SEL_STBDM272AT")
			  ||sqlString.equals("SEL_STBDM273AT")||sqlString.equals("SEL_STBDM274AT")
			  ||sqlString.equals("SEL_STBDM275AT")||sqlString.equals("SEL_STBDM276AT")
			  ||sqlString.equals("SEL_STBDM011AT")
			  ||sqlString.equals("SEL_STBDM311AT")
			  ||sqlString.equals("SEL_STBDM350AT")||sqlString.equals("SEL_STBDM312AT")
			  ||sqlString.equals("SEL_STBDM662AT")
			  ||sqlString.equals("SEL_STBDM910AT")||sqlString.equals("SEL_STBDM920AT")
			  ||sqlString.equals("SEL_STBDM930AT")
			  ||sqlString.equals("SEL_STBDM152AT")||sqlString.equals("SEL_STBDM153AT")
			  ||sqlString.equals("SEL_STBDM154AT")||sqlString.equals("SEL_STBDM155AT")
			  ||sqlString.equals("SEL_STBDM156AT")||sqlString.equals("SEL_STBDM157AT")
			  ||sqlString.equals("SEL_STBDM158AT")/*||sqlString.equals("SEL_STBDM670AT")*/
			  ||sqlString.equals("SEL_STBDM680AT")||sqlString.equals("SEL_STBDM480AT")
			  ||sqlString.equals("SEL_STBDM490AT")||sqlString.equals("SEL_STBDM280AT")
			  ||sqlString.equals("SEL_STBDM281AT")||sqlString.equals("SEL_STBDM671AT")
			  ||sqlString.equals("SEL_STBDM180AT")
			  ) {
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
			} else if(sqlString.equals("SEL_STBDM150AT")) {
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
			} else if (sqlString.equals("SEL_STBDM151AT")){
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
			} else if(sqlString.equals("SEL_STBDM931AT")
			  ) {
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
			} else if(sqlString.equals("SEL_STBDM670AT")
			  ) {
				Calendar calendar = new GregorianCalendar(Locale.KOREA);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				calendar.setTime(new Date());
				String adjt_dt = "";
				
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				if( ((String)map.get("urgent_yn")).equals("0") && ((String)map.get("trans_seq")).equals("1") ) {		// 정기 배신
					calendar.add(Calendar.DATE, 1);
					adjt_dt = sdf.format(calendar.getTime());
				}else {
					adjt_dt = sdf.format(calendar.getTime());
				}
				sql.setString(++i, adjt_dt);
				
//				logger.info("[SQL][" + sqlString + "]" + sql.debug());
			}

			else if(sqlString.equals("SEL_STBDM690AT")){
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				if( ((String)map.get("urgent_yn")).equals("0") && ((String)map.get("trans_seq")).equals("1") ) {		// 정기 배신
					sql.setString(++i, "0");
					sql.setString(++i, "0");
				}else {	// 기타
					sql.setString(++i, "1");
					sql.setString(++i, "1");
				}				
			}else if(sqlString.equals("SEL_STBDM691AT") ){
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd							
			}	


			else if(sqlString.equals("SEL_STBDM700AT") 
			) {
				 //logger.info("[SQL][" + sqlString + "]" + sql.debug());
				 //logger.info("(String)map.get(com_cd)=" + (String)map.get("com_cd"));
				if( ((String)map.get("urgent_yn")).equals("0") && ((String)map.get("trans_seq")).equals("1") ) {		// 정기 배신
					sql.setString(++i, (String)map.get("com_cd"));		// com_cd
					sql.setString(++i, "0");
					sql.setString(++i, "0");
				}else {	// 기타
					sql.setString(++i, (String)map.get("com_cd"));		// com_cd
					sql.setString(++i, "1");
					sql.setString(++i, "1");
				}				
				//logger.info("[SQL][" + sqlString + "]" + sql.debug());
			} else if(sqlString.equals("SEL_STBDM710AT") || sqlString.equals("SEL_STBDM711AT") ){
				
				if( ((String)map.get("urgent_yn")).equals("0") && ((String)map.get("trans_seq")).equals("1") ) {		// 정기 배신
					sql.setString(++i, (String)map.get("com_cd"));		// com_cd
					sql.setString(++i, "0");
					sql.setString(++i, "0");
				}else {	// 기타
					sql.setString(++i, (String)map.get("com_cd"));		// com_cd
					sql.setString(++i, "1");
					sql.setString(++i, "1");
				}		
			} else if(sqlString.equals("SEL_STBDM720AT") ){
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd						
			} else if(sqlString.equals("SEL_STBDM730AT") ){
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				if( ((String)map.get("urgent_yn")).equals("0") && ((String)map.get("trans_seq")).equals("1") ) {		// 정기 배신
					sql.setString(++i, "0");
				}else {	// 기타
					sql.setString(++i, "1");
				}
			} else if(sqlString.equals("SEL_STBDM190AT")){
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
			}
		

//			logger.info("[SQL][" + sqlString + "]" + sql.debug());
//			System.out.println("[DEBUG] [SQL][" + sqlString + "]" + sql.debug());
			list = executeQuery(sql);
//			System.out.println("[DEBUG] [SQL][" + sqlString + "] result count:" + list.size());
		} catch (Exception e) {
			logger.info("[ERROR]" + e.getMessage());
			logger.info("[SQL][" + sqlString + "]");
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
		} 
		
		return list;
	}

	/**
	 * selectFFImg - Search FF-PLU image(FF-PLU 이미지 조회)
	 * @param m
	 * @param imgPath : FF-PLU Image File Path(FF-PLU 이미지파일 경로)
	 * @return
	 * @throws Exception
	 */
	public List selectFFImg(Map map, String imgPath) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_FFIMG"));
			sql.setString(++i, imgPath);	// ff-plu imagefile path
			sql.setString(++i, (String)map.get("store_cd"));	// store_cd
			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		}
		return list;
	}
	
	/**
	 * selMSTGRPSETT - 마스터그룹 배신생성조건 조회
	 * @param com : 회사코드
	 * @return
	 * @throws Exception
	 */
	public List selMSTGRPSETT(String com, String grpCd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_MSTGRPSETT"));
			sql.setString(++i, com);	// com_cd
			sql.setString(++i, grpCd);
			list = executeQuery(sql);
		} catch (Exception e) {
//			System.out.println(e.getMessage());
			logger.info("[ERROR]selMSTGRPSETT::" + e);
		}
		
		return list;
	}
	
	/**
	 * selMSTGRPLIST - 마스터그룹 배신생성조건 조회
	 * @param com : 회사코드
	 * @return
	 * @throws Exception
	 */
	public List selMSTGRPLIST(String com) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_MSTGRPLIST"));
			sql.setString(++i, com);	// com_cd
			list = executeQuery(sql);
		} catch (Exception e) {
//			System.out.println(e.getMessage());
			logger.info("[ERROR]selMSTGRPLIST::" + e);
			logger.info("[ERROR]sql::"+sql.debug());
		}
		
		return list;
	}
	
	/**
	 * selTBLBELONGTOMSTGRP - 마스터그룹 배신생성조건 조회
	 * @param com : 회사코드
	 * @return
	 * @throws Exception
	 */
	public List selTBLBELONGTOMSTGRP(String com, String grpCd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_TBLBELONGTOMSTGRP"));
			sql.setString(++i, com);	// com_cd
			sql.setString(++i, grpCd);	// master group cd
			list = executeQuery(sql);
		} catch (Exception e) {
//			System.out.println(e.getMessage());
			logger.info("[ERROR]selTBLBELONGTOMSTGRP::" + e);
		}
		
		return list;
	}
	
	/**
	 * selMSTGRPSETT - 마스터그룹 배신생성조건 조회
	 * @param com : 회사코드
	 * @param grpCd : 마스터그룹코드
	 * @return
	 * @throws Exception
	 */
	public List selMSTGRPCHG(String com, String store, String grpCd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_MSTGRPCHG"));
			sql.setString(++i, com);	// com_cd
			sql.setString(++i, "A16"+store);	// bizloc_org_cd
			sql.setString(++i, grpCd);	// dstb_mst_grp_cd
			list = executeQuery(sql);
		} catch (Exception e) {
//			System.out.println(e.getMessage());
			logger.info("[ERROR]selMSTGRPCHG::" + e);
		}
		
		return list;
	}
	
	/**
	 * selUGTMSTGRPALL - 마스터그룹 배신생성조건 조회
	 * @param com : 회사코드
	 * @param transYmd : 영업일자
	 * @param storeCd : 점포코드
	 * @return
	 * @throws Exception
	 */
	public List<Object> selUGTMSTGRPALL(String com, String transYmd, String storeCd, String urgent_tp, String trans_ver) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_UGTMSTGRPALL"));
			sql.setString(++i, transYmd);	// TRANS_YMD
			sql.setString(++i, storeCd);	// STORE_CD
			sql.setString(++i, com);		// COM_CD
			sql.setString(++i, urgent_tp);	// URGENT_YN
			sql.setString(++i, trans_ver);	// TRANS_VER
			
			list = executeQuery(sql);
		} catch (Exception e) {
//			System.out.println(e.getMessage());
			logger.info("[ERROR]selUGTMSTGRPALL::" + e);
			logger.info("[ERROR]" + sql.debug());
		}
		return list;
	}
	
	
	
	
	public int selCNTINPROGRESS(String transYMD_1, String transYMD_2, String localNo) {
		List<Object> result = null;
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = 0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_INPROGRESS"));
			sql.setString(++i, transYMD_1);
			sql.setString(++i, transYMD_2);
			sql.setString(++i, localNo);
			result = executeQuery(sql);
			
			rows = result.size();
		}catch(Exception e) {
			logger.info("[ERROR]selCNTINPROGRESS::" + e.getMessage());
		}
		
		return rows;
	}
	
	
	
}






















