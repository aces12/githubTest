package biz.cms_MasterCrt;

import biz.cms_MasterCrt.MasterCrtClientAction;;

public class MasterCrtControl {
	
	public synchronized void useThread() throws InterruptedException {
		//System.out.println( "lend :" + MasterCrtClientAction.getJobThread());
		if (MasterCrtClientAction.getJobThread() <= 0) {
			//System.out.println(t.getName() + ": wating...");
			this.wait();
			//System.out.println(t.getName() + ": return...");
		}
		MasterCrtClientAction.decrement();
	}
	
	public synchronized void returnThread() {
		MasterCrtClientAction.increment();
		this.notify();
	}
}
