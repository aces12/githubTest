package biz.cms_SvArrivalSync;

import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_POSIrt.POSIrtDAO;
import biz.cms_POSIrt.POSIrtProtocol;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.BasicStringFilter;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

public class SvArrivalSyncConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;
	private static Logger logger = Logger.getLogger(SvArrivalSyncPollingAction.class);

	COMMLog df = null;

	public SvArrivalSyncConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}

	public int SvArrivalSyncConveyer(Object list) throws Exception {

		POSIrtProtocol protocol = new POSIrtProtocol();
		HashMap<String, String> hm = new HashMap<String, String>();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		HashMap<String, String> hmReq = new HashMap<String, String>();
		
		String sendMsg = "";	
		String recvBuf = "";
		int updateYn = 0;	

		hm = (HashMap<String, String>) list;
		
		try { 
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.STAFFCHECK_FILTER)));

			hmReq.put("DEAL_LEN",        "0700");    // 전문길이         0700:고정값  
			hmReq.put("DEAL_TYPE",       "AUTH0201");    // 전문ID     AUTH0301:이마트   
			hmReq.put("CO_CD",           "AE0       ");    // 회사코드           
			hmReq.put("REQ_GUBUN",       "SEND");    // 요청구분           SEND:고정    
			hmReq.put("OPER_DATE",       (String)hm.get("REG_YMD"));    // 영업일자           
			hmReq.put("OPER_TIME",       (String)hm.get("REG_HMS"));    // 영업시간           
			hmReq.put("STORE_CD",        "   " + (String)hm.get("STORE_CODE").substring(0, 1));    // 점코드            
			hmReq.put("STORE_CD2",       (String)hm.get("STORE_CODE").substring(1, 5));    // 점포서버번호         
			hmReq.put("POS_NO",          (String)hm.get("POS_NO"));    // 포스번호           
			hmReq.put("CASHER_NO",       "          ");    // CASHER번호       
			hmReq.put("TRAN_NO",         "    ");    // 거래번호           
			hmReq.put("COM_TRAN_NO",     (String)hm.get("REG_YMD") + (String)hm.get("POS_NO") + (String)hm.get("REG_HMS") + "  ");    // 회사별거래번호        
			hmReq.put("COM_ADD_INFO",    "                    ");    // 회사별추가정보        
			hmReq.put("TRAN_SEND_DATE",  (String)hm.get("REG_YMD"));    // 전문전송일자         
			hmReq.put("TRAN_SEND_TIME",  (String)hm.get("REG_HMS"));    // 전문전송시간         
			hmReq.put("TRAN_TYPE",       "05");    // 거래TYPE    조회:05      
			hmReq.put("CONF_GUBUN",      (String)hm.get("CONF_GUBUN"));    // 인증방법구분      전자사원증:1,  카드:2
			hmReq.put("ELEC_STAFF",      (String)hm.get("ELEC_STAFF"));    // 전자사원증          
			hmReq.put("CARD_INFO",       (String)hm.get("CARD_NO"));    // 신용카드           
			hmReq.put("KEY_IN_YN",       (String)hm.get("KEY_IN"));    // KEY_IN 유무      
			hmReq.put("TOTAL_AMT",       "000000000000");    // 총매출금액           
			hmReq.put("AMT",             "000000000000");    // 순매출금액          
			hmReq.put("SALE_AMT",        "000000000000");    // 직원할인금액         
			hmReq.put("GDS_CNT",         "0000");    // 구매물품수          
			hmReq.put("GDS_CD",          "                                                  ");    // 구매물품대표코드       
			hmReq.put("GDS_NM",          "                                                                                                    ");    // 구매물품명          
			hmReq.put("FILLER",          "                                                                                                                                                                                                                                                                                                        ");   // FILLER 

			sendMsg = makeSendDataStaffCheck(hmReq);
			
			// Socket 통신 시작
			if( actSock.send(sendMsg) ) { // 요청 송신
				logger.info("[sms>StaffCheck] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				logger.info("[sms>StaffCheck] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("StaffCheck server is no response");
			}
			
			recvBuf = ((String)actSock.receive()); // 요청 수신
			hmRecv = makeSendDataStaffCheckRsp(new String(recvBuf.getBytes("EUC-KR"),"ISO8859_1"));
			
			SvArrivalSyncDAO dao = new SvArrivalSyncDAO(); 
			updateYn = dao.upSvArrivalSync((String)hmRecv.get("TRAN_SEND_DATE"), (String)hmRecv.get("ELEC_STAFF"), hmRecv.get("EMPLOYEE_ID"));

		}catch(Exception e) { 
			logger.info("▶ [ERROR]1: " + e.getMessage());
			throw e;
		}finally {
			// Socket 통신 종료
			actSock.close(); 
		}
		
		return updateYn;
	}
	
	
	private String makeSendDataStaffCheck(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4, 8, 10, 4, 8, 6, 4, 4, 4, 10, 4, 20, 20, 8, 6, 2, 1, 10, 80, 1, 12, 12, 12, 4, 50, 100, 296};
		String strHeaders[] = {
			"DEAL_LEN",       // 전문길이    
			"DEAL_TYPE",      // 전문ID    
			"CO_CD",          // 회사코드    
			"REQ_GUBUN",      // 요청구분    
			"OPER_DATE",      // 영업일자    
			"OPER_TIME",      // 영업시간    
			"STORE_CD",       // 점코드     
			"STORE_CD2",      // 점포서버번호  
			"POS_NO",         // 포스번호    
			"CASHER_NO",      // CASHER번호
			"TRAN_NO",        // 거래번호    
			"COM_TRAN_NO",    // 회사별거래번호 
			"COM_ADD_INFO",   // 회사별추가정보 
			"TRAN_SEND_DATE", // 전문전송일자  
			"TRAN_SEND_TIME", // 전문전송시간  
			"TRAN_TYPE",      // 거래TYPE
			"CONF_GUBUN",     // 인증방법구분
			"ELEC_STAFF",     // 전자사원증
			"CARD_INFO",      // 신용카드
			"KEY_IN_YN",      // KEY_IN 유무
			"TOTAL_AMT",      // 총매출금액
			"AMT",            // 순매출금액
			"SALE_AMT",       // 직원할인금액
			"GDS_CNT",        // 구매물품수
			"GDS_CD",         // 구매물품대표코드
			"GDS_NM",         // 구매물품명
			"FILLER"          // FILLER
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public HashMap<String, String> makeSendDataStaffCheckRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		//int nlens[] = {4, 8, 10, 4, 8, 6, 4, 4, 4, 10, 4, 20, 20, 8, 6, 2, 4, 20, 2, 12, 1, 10, 80, 1, 12, 12, 12, 10, 10};
		int nlens[] = {4, 8, 10, 4, 8, 6, 4, 4, 4, 10, 4, 20, 20, 8, 6, 2, 4, 20, 2, 12, 1, 10, 80, 1, 12, 12, 12, 10, 10, 50, 50, 10, 50, 60, 172};
		String strHeaders[] = {
				"DEAL_LEN",       // 전문길이
				"DEAL_TYPE",      // 전문ID
				"CO_CD",          // 회사코드
				"REQ_GUBUN",      // 요청구분
				"OPER_DATE",      // 영업일자
				"OPER_TIME",      // 영업시간
				"STORE_CD",       // 점코드
				"STORE_CD2",      // 점포서버번호
				"POS_NO",         // 포스번호
				"CASHER_NO",      // CASHER번호
				"TRAN_NO",        // 거래번호
				"COM_TRAN_NO",    // 회사별거래번호
				"COM_ADD_INFO",   // 회사별추가정보
				"TRAN_SEND_DATE", // 전문전송일자
				"TRAN_SEND_TIME", // 전문전송시간
				"SERVICE_CD",     // 서비스코드
				"RETURN_CD",      // 응답코드
				"CONF_NO",        // 승인번호
				"EMPLOYEE_YN",    // 직원유무
				"REST_AMT",       // 잔여한도금액
				"ELEC_STAFF_YN",  // 전자사원증유무
				"ELEC_STAFF",     // 전자사원증
				"CARD_INFO",      // 신용카드
				"KEY_IN_YN",      // KEY_IN 유무
				"TOTAL_AMT",      // 총매출금액
				"AMT",            // 순매출금액
				"SALE_AMT",       // 직원할인금액
				"EMPLOYEE_ID",    // 사번
				"COMP_CD",        // 소속사코드
				"COMP_NM",        // 소속사명
				"EMPLOYEE_NM",    // 이름       
				"RANK_CD",        // 직급코드     
				"RANK_NM",        // 직급명      
				"RSP_MESSAGE",    // 응답메시지    
				"FILLER"          // FILLER   
		};

		int bInx=0;
		int eInx=0;	
		HashMap hm_sub = new HashMap();

		eInx = nlens[0];
		
		for(int i=0; i<nlens.length; i++ ){
			
			try {
				hm_sub.put(strHeaders[i].toString(), new String(rcvBuf.substring(bInx, eInx).getBytes("ISO8859_1"),"EUC-KR"));
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			if (i<nlens.length-1){
				bInx = eInx;
				eInx = eInx+nlens[i+1];
			}
		}
		
		return hm_sub;
	}

}