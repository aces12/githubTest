package biz.cms_SvArrivalSync;

import java.net.Socket;
import java.util.List;

import org.apache.log4j.Logger;

import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

/** 
 * SvArrivalSyncPollingAction
 * 사원증 인증(사원증 SV 점착 인증) 동기화
 * @created  on 1.0,  11/05/02
 * @created  by oht(I&C) 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by 
 */ 
public class SvArrivalSyncPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(SvArrivalSyncPollingAction.class);
	
	private String server_ip = "";
	private int server_port = 0;
	SvArrivalSyncConveyer conveyer = null;
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public static void main(String args[]) throws Exception {
		SvArrivalSyncPollingAction action = new SvArrivalSyncPollingAction();
		
		String path          = nvl(args[0].replaceFirst("-path:"  ,""));
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);

		try {
			if (args == null || args.length < 1) {
				logger.info("------ SvArrivalSync main args null");
			}

			action.execute("");
			
		}catch(Exception e) {
			System.out.println("[ERROR]" + e.getMessage());
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	@Override
	public void execute(String actionMode) {
		Socket extClntSock = null;
		SvArrivalSyncDAO dao = new SvArrivalSyncDAO(); 
		COMMLog df = new COMMLog();
		
		// TODO Auto-generated method stub
		try {
			List<Object> list = null;
			int totalCount = 0; 
			int i = 0;

			list = dao.selSvArrivalSync(""); 
			logger.info("▶ 동기화 [" + list.size() + "]건 진행 시작");
			totalCount = list.size();
			
			if( totalCount > 0) {
				this.server_ip = PropertyUtil.findProperty("communication-property", "STAFFCHK_COMM_IP");
				this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "STAFFCHK_COMM_PORT"));			

				extClntSock = new Socket(server_ip, server_port);	
				conveyer = new SvArrivalSyncConveyer(extClntSock, df);		

				for(i = 0; i < list.size(); i++){	
					logger.info("▶ 동기화 [" + (i+1) + "]" + list.get(i) + " 진행 시작");			 
					conveyer.SvArrivalSyncConveyer(list.get(i));	
				}
			}			
			//df.CommLogger("▶ 동기화 [" + list.size() + "]건 진행 종료");	
			logger.info("▶ 동기화 [" + list.size() + "]건 진행 종료");		
		}catch(Exception e) {
			logger.info("", e);
		}
	}

}
