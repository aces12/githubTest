package biz.cms_CashBeeReceiver;

import java.util.HashMap;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class CashBeeReceiverDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(CashBeeReceiverInst.class);
	
	public int updCashBeeCHRGPAY(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			begin();
			
			sql.put(findQuery("service-sql", "UPD_CASHBEECHRGPAYRCV"));
			sql.setString(++i, (String)hm.get("ERR_CD"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
			sql.setString(++i, (String)hm.get("PROC_ID"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("TMNAL_ID"));
			sql.setString(++i, (String)hm.get("TRAN_ID"));
			
//			logger.info(" sql : " + sql.debug());
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insCashBeeCHRGPAYRslt(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_CASHBEECHRGPAYRESULT"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
			sql.setString(++i, (String)hm.get("TMNAL_ID"));
			sql.setString(++i, "A16" + ((String)hm.get("TMNAL_ID")).substring(2, 7));
			sql.setString(++i, (String)hm.get("CHRG_AMT"));
			
			sql.setString(++i, (String)hm.get("CHRG_FEE"));
			sql.setString(++i, (String)hm.get("PAY_AMT"));
			sql.setString(++i, (String)hm.get("PAY_TOTAL_FEE"));
			sql.setString(++i, (String)hm.get("FSBTR_DEPOSIT_AMT"));
			sql.setString(++i, (String)hm.get("RTN_CNT"));
			
			sql.setString(++i, (String)hm.get("RTN_AMT"));
			sql.setString(++i, (String)hm.get("RTN_FEE"));
			sql.setString(++i, (String)hm.get("DELAY_CHRG_CNCL_CNT"));
			sql.setString(++i, (String)hm.get("DELAY_CHRG_CNCL_AMT"));
			sql.setString(++i, (String)hm.get("DELAY_CHRG_CNCL_FEE"));
			
			sql.setString(++i, (String)hm.get("CASH_RTN_CNT"));
			sql.setString(++i, (String)hm.get("CASH_RTN_AMT"));
			sql.setString(++i, (String)hm.get("CASH_RTN_FEE"));
			
//			logger.info(" sql : " + sql.debug());
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insCashBeeCHRGPAY(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_CASHBEECHRGPAYRCV"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("TMNAL_ID"));
			sql.setString(++i, (String)hm.get("TRAN_ID"));
			sql.setString(++i, "20" + ((String)hm.get("TRAN_ID")).substring(0, 6));
			sql.setString(++i, "A16" + ((String)hm.get("TMNAL_ID")).substring(2, 7));
			
			sql.setString(++i, (String)hm.get("WORK_ID"));
			sql.setString(++i, (String)hm.get("SAM_TYPE"));
			sql.setString(++i, (String)hm.get("SAM_ID"));
			sql.setString(++i, (String)hm.get("CARD_NO"));
			sql.setString(++i, (String)hm.get("CARD_KEY"));
			sql.setString(++i, (String)hm.get("DOUBLE_CARD_KEY"));
			sql.setString(++i, (String)hm.get("CARD_DEAL_SNO"));
			
			sql.setString(++i, (String)hm.get("DEAL_YMDHMS"));
			sql.setString(++i, (String)hm.get("DEAL_BEF_RAMT"));
			sql.setString(++i, (String)hm.get("DEAL_REQ_AMT"));
			sql.setString(++i, (String)hm.get("DEAL_AFT_RAMT"));
			sql.setString(++i, (String)hm.get("BEF_SAM_RAMT"));
			
			sql.setString(++i, (String)hm.get("AFT_SAM_RAMT"));
			sql.setString(++i, (String)hm.get("CARD_TYPE"));
			sql.setString(++i, (String)hm.get("PAY_TYPE"));
			sql.setString(++i, (String)hm.get("MBSCARD_EXP_DATE"));
			sql.setString(++i, (String)hm.get("MBSCARD_NO"));

			sql.setString(++i, (String)hm.get("CARD_KEY"));
			sql.setString(++i, (String)hm.get("DOUBLE_CARD_KEY"));
			sql.setString(++i, (String)hm.get("FIRST_CHRG_FG"));
			sql.setString(++i, (String)hm.get("FRU"));
			sql.setString(++i, (String)hm.get("FEE_RATE"));
			
			sql.setString(++i, (String)hm.get("FEE_AMT"));
			sql.setString(++i, (String)hm.get("SAM_DEAL_SNO"));			
			sql.setString(++i, (String)hm.get("SAM_TOT_CNT"));
			sql.setString(++i, (String)hm.get("ALGM_ID"));
			sql.setString(++i, (String)hm.get("KEYSET_VER"));
			
			sql.setString(++i, (String)hm.get("CARD_DEPOSIT"));
			sql.setString(++i, (String)hm.get("PENALTY_AMT"));			
			sql.setString(++i, (String)hm.get("CHRG_APPROVAL_NO"));
			sql.setString(++i, (String)hm.get("PUBCO_ID"));
			sql.setString(++i, (String)hm.get("SIGN_VAL"));
			
			sql.setString(++i, (String)hm.get("NCSAM"));
			sql.setString(++i, (String)hm.get("NISAM"));			
			sql.setString(++i, (String)hm.get("TOTSAM"));
			sql.setString(++i, (String)hm.get("IDCENTER"));
			sql.setString(++i, (String)hm.get("MPSAM"));
			
			sql.setString(++i, (String)hm.get("MAXIDCENTER"));
			sql.setString(++i, (String)hm.get("BALIDCENTER"));			
			sql.setString(++i, (String)hm.get("RFU"));
			sql.setString(++i, (String)hm.get("RESULT"));
			sql.setString(++i, (String)hm.get("ERR_CD"));
			sql.setString(++i, (String)hm.get("PROC_ID"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
}