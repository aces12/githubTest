package biz.cms_CashBeeReceiver;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class CashBeeReceiverInst extends Thread {
	private static Logger logger = Logger.getLogger(CashBeeReceiverInst.class);
	
	String path = "";
	
	public CashBeeReceiverInst(String path) {
		this.path = path;
	}
	
	public void run() {
		String fileNM = "";
		
		try {
//			logger.info(" >>>>>>>>>>>>>>>>>>>> start!!!");
			
			List<File> file = getDirFileList(path);
			
			logger.info(" >>>>>>>>>>>>>>>>>>>> file cnt : " + Integer.toString(file.size()));
			
			for(int i = 0;i < file.size();i++) {
				fileNM = file.get(i).getName();
				
				logger.info(" >>>>>>>>>>>>>>>>>>> file name : " + fileNM);
				
				int len = 0;
				int totLen = 0;
				String readLine = "";
				
				long fileSize = (file.get(i)).length();
				
				byte buf[] = new byte[(int)fileSize];
				InputStream is = new FileInputStream(file.get(i));
				
//				BufferedReader br = new BufferedReader(new FileReader(file.get(i)));
				StringBuffer sb = new StringBuffer();
				
				
				while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
					sb.append(new String(buf));
					totLen += len;
					if( totLen == fileSize ) {
						break;
					}
				}
				
				is.close();
				
				if( (fileNM.substring(7, 10)).equals("002") ) {			// 충전/지불 반송
					this.insertFile002(sb.toString());
				}else if( (fileNM.substring(7, 10)).equals("003") ) {	// 충전/지불 정산결과
					this.insertFile003(sb.toString());
				}
				// 파일 옮기기...
				this.moveFile(path, fileNM, path + File.separator + "backup");
				logger.info("[DEBUG] File " + fileNM + " processed successfuly.");
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	private void insertFile002(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			CashBeeReceiverDAO dao = new CashBeeReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
//				String strRecord = readData.substring(i*CashBeeReceiverProtocol.LENGTH_BY_RECORD, (i + 1) * CashBeeReceiverProtocol.LENGTH_BY_RECORD - 1);
				
//				logger.info(" recvLen : " + Integer.toString(bytes.length) + ", totLen : " + Integer.toString(totLen));
//				logger.info(" >>>>>>>>>>>>>> i : " + Integer.toString(i));
				
				String strRecord = new String(bytes, i*CashBeeReceiverProtocol.LENGTH_BY_RECORD, CashBeeReceiverProtocol.LENGTH_BY_RECORD);
				totLen += CashBeeReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getCashBeeCHRGPAYDtl_HDR(strRecord);
					adjt_dt = ((String)hm.get("FILE_NM")).substring(11, 19);
				}else if( strRecord.charAt(0) == 'R' ) {
					if( strRecord.charAt(1) == 'D' ) {
						hm = getCashBeeCHRGPAYDtl_DAT(strRecord);
						
						hm.put("CO_CD", com_cd);
						hm.put("ADJT_DT", adjt_dt);
						hm.put("CARD_KEY", card_key);
						hm.put("DOUBLE_CARD_KEY", double_card_key);
						
//						logger.info(" >>>>>>>>> ERR_CD = " + (String)hm.get("ERR_CD"));
						
						if( ((String)hm.get("ERR_CD")).equals("00") ) {
							logger.info(" >>>>>>>>> 정상");
							hm.put("PROC_ID", "4");
						}else if( ((String)hm.get("ERR_CD")).equals("07") ) {
							logger.info(" >>>>>>>>> 충전/지불 중복 오류");
							hm.put("PROC_ID", "4");
						}else {
							logger.info(" >>>>>>>>> 반송");
							hm.put("PROC_ID", "3");
						}
						try {
							if( ((String)hm.get("WORK_ID")).equals("001") ) {	// 지불거래이면
								//if( !((String)hm.get("PAY_TYPE")).equals("5") ) {	// 지불취소는 제외
									iRtn = dao.updCashBeeCHRGPAY(hm);
								//}
							}else {	// 그 밖에 모든 거래이면
								iRtn = dao.insCashBeeCHRGPAY(hm);
							}
						}catch(Exception e) {
							logger.info("[ERROR] Error for inserting data : " + e.getMessage());
						}
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFile003(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			CashBeeReceiverDAO dao = new CashBeeReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
//				String strRecord = readData.substring(i*CashBeeReceiverProtocol.LENGTH_BY_RSLT_RECORD, (i + 1) * CashBeeReceiverProtocol.LENGTH_BY_RSLT_RECORD - 1);
				
//				logger.info(" recvLen : " + Integer.toString(bytes.length) + ", totLen : " + Integer.toString(totLen));
//				logger.info(" >>>>>>>>>>>>>> i : " + Integer.toString(i));
				
				String strRecord = new String(bytes, i*CashBeeReceiverProtocol.LENGTH_BY_RSLT_RECORD, CashBeeReceiverProtocol.LENGTH_BY_RSLT_RECORD);
				totLen += CashBeeReceiverProtocol.LENGTH_BY_RSLT_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getCashBeeCHRGPAYRslt_HDR(strRecord);
					adjt_dt = ((String)hm.get("FILE_NM")).substring(11, 19);
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getCashBeeCHRGPAYRslt_DAT(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("ADJT_DT", adjt_dt);
					try {
						dao.insCashBeeCHRGPAYRslt(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private HashMap<String, String> getCashBeeCHRGPAYRslt_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,20,8,8,162,1};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_NM",
			"DATA_SNO",
			"ADJT_DT",
			"FILLER",
			"NLCHAR"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getCashBeeCHRGPAYRslt_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,10,13,13
					  ,13,13,13,13,13
					  ,13,13,13,13,7
					  ,10,10,10,1};
		String strHeaders[] = {
			"RECORD_TP",
			"DATA_SNO",
			"TMNAL_ID",
			"CHRG_AMT",
			"CHRG_FEE",
			
			"PAY_AMT",
			"PAY_TOTAL_FEE",
			"FSBTR_DEPOSIT_AMT",
			"RTN_CNT",
			"RTN_AMT",
			
			"RTN_FEE",
			"DELAY_CHRG_CNCL_CNT",
			"DELAY_CHRG_CNCL_AMT",
			"DELAY_CHRG_CNCL_FEE",
			"CASH_RTN_CNT",
			
			"CASH_RTN_AMT",
			"CASH_RTN_FEE",
			"FILLER",
			"NLCHAR"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getCashBeeCHRGPAYRslt_TAIL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,20,8,8,7,155,1};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_NM",
			"DATA_SNO",
			"ADJT_DT",
			"TOTAL_DATA_CNT",
			"FILLER",
			"NLCHAR"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getCashBeeCHRGPAYDtl_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,20,8,8,301,1};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_NM",
			"DATA_SNO",
			"ADJT_DT",
			"FILLER",
			"NLCHAR"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getCashBeeCHRGPAYDtl_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,10,2
					  ,16,20,10,3,14
					  ,10,10,10,10,10
					  ,2,1,4,16,1
					  ,3,4,10,10,10
					  ,2,2,10,10,14
					  ,7,16,10,5,10
					  ,2,10,10,10,8
					  ,1,1,2,8,1};
		String strHeaders[] = {
			"RECORD_TP",
			"LENGTH",
			"TMNAL_ID",
			"TRAN_ID",
			"SAM_TYPE",
			
			"SAM_ID",
			"CARD_NO",
			"CARD_DEAL_SNO",
			"WORK_ID",
			"DEAL_YMDHMS",
			
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			"BEF_SAM_RAMT",
			"AFT_SAM_RAMT",
			
			"CARD_TYPE",
			"PAY_TYPE",
			"MBSCARD_EXP_DATE",
			"MBSCARD_NO",
			"FIRST_CHRG_FG",
			
			"FRU",
			"FEE_RATE",
			"FEE_AMT",
			"SAM_DEAL_SNO",
			"SAM_TOT_CNT",
			
			"ALGM_ID",
			"KEYSET_VER",
			"CARD_DEPOSIT",
			"PENALTY_AMT",
			"CHRG_APPROVAL_NO",
			
			"PUBCO_ID",
			"SIGN_VAL",
			"NCSAM",
			"NISAM",
			"TOTSAM",
			
			"IDCENTER",
			"MPSAM",
			"MAXIDCENTER",
			"BALIDCENTER",
			"RFU",
			
			"RESND_FG",
			"RESULT",
			"ERR_CD",
			"FILLER",
			"NLCHAR"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
//			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
}