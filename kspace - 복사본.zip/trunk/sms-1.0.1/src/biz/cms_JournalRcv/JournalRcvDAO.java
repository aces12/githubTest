/*
 * JournalDAO.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */

package biz.cms_JournalRcv;

import java.sql.SQLException;
import java.util.HashMap;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.sql.SqlUtil;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

/** 
 * JournalDAO
 * A class that has inherited GenericDAO(GenericDAO를 상속받은 클래스)
 * It is responsible for functions to access DB to retrieve respective information(DB에 접속하여 해당 정보를 조회해 오거나)
 * or update DB information(DB정보를 업데이트 하는 기능을 담당한다). 
 * @created  on 1.0,  11/03/17
 * @created  by oki(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */ 
public class JournalRcvDAO extends GenericDAO{	
	
	/**
	 * setData   : Save journal data(저널  데이타 저장)
	 * @param hm      : Message Data(전문 데이타) 
	 * @param rcvBuf  : Receive Buffer
	 * @return 0: Success(성공) 
	 * 029 : HOST APPL ERROR
	 * 020 : HOST DB ERROR
	 * @throws Exception
	 */
	public int setData(HashMap hmCommon, HashMap hmData, String rcvBuf, COMMLog df) throws Exception{
		int rows=0;	
		int rtn=0;
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		
		try {
			begin();
			connect("CMGNS");
			
			sql.put(findQuery("journal-sql", "INS_STTRP050DT"));
			sql.setString(++i,   (String)hmData.get("TRAN_YMD"));
			sql.setString(++i,   (String)hmCommon.get("COM_CD"));
			sql.setString(++i,   (String)hmData.get("STORE_CD"));
			sql.setString(++i,   (String)hmData.get("POS_NO"));
			sql.setString(++i,   (String)hmData.get("TRAN_NO"));
			sql.setString(++i,   (String)hmData.get("SYS_YMDHMS"));
			sql.setString(++i,   (String)hmData.get("TRAN_TYPE"));
			sql.setString(++i,   (String)hmData.get("TRAN_KIND"));
			sql.setString(++i,   (String)hmData.get("OP_NO"));
			sql.setString(++i,  (String)hmData.get("PMOD_YN"));
			sql.setString(++i,  (String)hmData.get("STOP_YN"));
			sql.setString(++i,  (String)hmData.get("CUST_CLS_ID"));
			sql.setString(++i,  (String)hmData.get("CUST_COUNT"));
			sql.setString(++i,  (String)hmData.get("NSALE_AMT"));
			sql.setString(++i,  (String)hmData.get("JNL_REC_LEN"));
			sql.setString(++i,  (String)hmData.get("JNL_DAT_LEN"));
			sql.setStringForClob(++i, rcvBuf.substring(COMMBiz.CM_LENS + 91));  //clob (CM헤더+저널전문) 길이
			sql.setString(++i,  (String)hmData.get("SYS_YMDHMS"));
						
//			df.CommLogger("▶ [DEBUG]SQL:"+ sql.debug());
//			System.out.println("▶ [DEBUG]SQL:"+ sql.debug());
			rows = executeUpdate(sql); 
//			df.CommLogger("▶▶▶ Journal ["+rows + "] has(have) been entered(건 입력되었습니다).");

		} catch(SQLException e){ 	
			df.CommLogger( "▶ [ERROR]1:"+ e.getErrorCode() );
			df.CommLogger( "▶ [ERROR]1:"+ e.getMessage() );
			// In the case of duplicated data, return value is normal, or otherwise, return 20 DB ERROR(데이타 중복인 경우는 리턴값이 정상이고, 그 외에는 20 DB ERROR 리턴 )
			if (e.getErrorCode()!=1) rtn=20;	
			// 중복키 에러 : 오라클 버전 에러코드 1 ??
			//if (e.getErrorCode()!=1){
			//	rtn=20;
			//}
			// 접속 에러 : MSSQL 접속/로그인실패 0
			if (e.getErrorCode()==0){
				rtn=20;
			}
			// 중복키 에러 : MSSQL 버전 에러코드 2627
			if (e.getErrorCode()==2627){
				rtn=20;
			}
			rollback();		
		} catch (Exception e) {
			rtn=29;
			df.CommLogger( "▶ [ERROR]2: " + e.getMessage());
			rollback();
			throw e;
		} finally {
			end();
		}
		
		return rtn;
	}
	

	
	
}
