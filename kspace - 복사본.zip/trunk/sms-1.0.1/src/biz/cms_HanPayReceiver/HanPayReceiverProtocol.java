package biz.cms_HanPayReceiver;

import java.util.HashMap;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class HanPayReceiverProtocol {
	private static Logger logger = Logger.getLogger(HanPayReceiverProtocol.class);
	
	public static int LENGTH_BY_RECORD = 300;
	public static int LENGTH_BY_CARDPUBCO_RECORD = 150;
	
	public HashMap<String, String> getReceiver0600(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {24,10,3,20,16};
		String strHeaders[] = {
			"FILE_NAME",
			"TRANS_TIME",
			"MANAGE_INFO",
			"SENDER_NM",
			"SENDER_PW"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getReceiver0620(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {24,4,3};
		String strHeaders[] = {
			"FILE_NAME",
			"BLOCK_NO",
			"SEQUENCE_NO"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getReceiver0630(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {24,12,4};
		String strHeaders[] = {
			"FILE_NAME",
			"FILE_SIZE",
			"TLGM_BYTE_NUM"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getReceiver0320(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3,4};
		String strHeaders[] = {
			"BLOCK_NO",
			"SEQUENCE_NO",
			"DATA_BYTE_LEN"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		hm.put("DATA", new String(rcvBuf.getBytes(), 11, Integer.parseInt((String)hm.get("DATA_BYTE_LEN"))));
		
		return hm;
	}
}
