package biz.cms_HanPayReceiver;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.cms_CashBeeReceiver.CashBeeReceiverProtocol;
import biz.cms_TMoneyReceiver.TMoneyReceiverDAO;
import biz.comm.COMMBiz;

public class HanPayReceiverInst extends Thread {
	private static Logger logger = Logger.getLogger(HanPayReceiverAction.class);
	
	String path = "";
	
	public HanPayReceiverInst(String path) {
		this.path = path;
	}
	
	public void run() {
		String fileNM = "";
		
		try {
			List<File> file = getDirFileList(path);
			
			logger.info(" >>>>>>>>>>>>>>>>>>>> file cnt : " + Integer.toString(file.size()));
			
			for(int i = 0;i < file.size();i++) {
				fileNM = file.get(i).getName();
				
				logger.info(" >>>>>>>>>>>>>>>>>>> file name : " + fileNM);
				
				int len = 0;
				int totLen = 0;
				String readLine = "";
				
				long fileSize = (file.get(i)).length();
				
				byte buf[] = new byte[(int)fileSize];
				InputStream is = new FileInputStream(file.get(i));
				
//				BufferedReader br = new BufferedReader(new FileReader(file.get(i)));
				StringBuffer sb = new StringBuffer();
				

				while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
					logger.info("fileSize="+Integer.toString((int)fileSize));
					sb.append(new String(buf));
					totLen += len;
					logger.info("totLen="+Integer.toString((int)totLen));
					if( totLen == fileSize ) {
						break;
					}
				}
				
				is.close();
				
				logger.info("fileNM="+fileNM);
				
				String[] fileNMSplited = fileNM.split("[.]");
				
				logger.info("file name="+fileNMSplited[1]);
				
				if( fileNMSplited[1].equals("AC07") ) {					// 온라인 충전 정산결과
					this.insertFileAC07(sb.toString());
				}else if( fileNMSplited[1].equals("AC08") ) {			// 가맹점별 온라인 충전 정산결과
					this.insertFileAC08(sb.toString());
				}else if( fileNMSplited[1].equals("BC02") ) {			// 지불거래내역 정산결과
					this.insertFileBC02(sb.toString());
				}else if( fileNMSplited[1].equals("BC03") ) {			// 가맹점별 지불거래내역 정산결과
					this.insertFileBC03(sb.toString());
				}else if( fileNMSplited[1].equals("BC06") ) {			// 카드발행사 정보
					this.insertFileBC06(sb.toString());
				}
				
				// 파일 옮기기...
				this.moveFile(path, fileNM, path + File.separator + "backup");
				logger.info("[DEBUG] File " + fileNM + " processed successfuly.");
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	private void insertFileAC07(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			HanPayReceiverDAO dao = new HanPayReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*HanPayReceiverProtocol.LENGTH_BY_RECORD, HanPayReceiverProtocol.LENGTH_BY_RECORD);
				totLen += HanPayReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getHanPayADJTRslt_HDR(strRecord);
					adjt_dt = hm.get("ADJT_DT");
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getHanPayCHRGADJTRslt_DAT(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("ADJT_DT", adjt_dt);
					hm.put("CARD_KEY", card_key);
					hm.put("DOUBLE_CARD_KEY", double_card_key);
					try {
						dao.insHanPayCHRGADJTRslt_DAT(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}					
				}else if( strRecord.charAt(0) == 'T') {
					hm = getHanPayCHRGADJTRslt_TAL(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("ADJT_DT", adjt_dt);
					try {
						dao.insHanPayCHRGADJTRslt_HDR(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileAC08(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			HanPayReceiverDAO dao = new HanPayReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*HanPayReceiverProtocol.LENGTH_BY_RECORD, HanPayReceiverProtocol.LENGTH_BY_RECORD);
				totLen += HanPayReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getHanPayADJTRslt_HDR(strRecord);
					adjt_dt = hm.get("ADJT_DT");
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getHanPayCHRGADJTRsltByFcstrID_1_DAT(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("ADJT_DT", adjt_dt);
					try {
						dao.insHanPayCHRGADJTRsltByFcstrID_1_DAT(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'T') {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileBC02(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			HanPayReceiverDAO dao = new HanPayReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*HanPayReceiverProtocol.LENGTH_BY_RECORD, HanPayReceiverProtocol.LENGTH_BY_RECORD);
				totLen += HanPayReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getHanPayADJTRslt_HDR(strRecord);
					adjt_dt = hm.get("ADJT_DT");
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getHanPayPAYADJTRslt_DAT(strRecord);
					hm.put("CO_CD", com_cd);
					if( ((String)hm.get("RESP_CD")).equals("01") ) {
						logger.info(" >>>>>>>>> 정상");
						hm.put("PROC_ID", "4");
					}else {
						logger.info(" >>>>>>>>> 반송");
						hm.put("PROC_ID", "3");
					}
					
					hm.put("FILE_MK_DT", adjt_dt);
					
					try {
						iRtn = dao.updHanPayPAYMENT_DTL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'T' ) {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileBC03(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			HanPayReceiverDAO dao = new HanPayReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*HanPayReceiverProtocol.LENGTH_BY_RECORD, HanPayReceiverProtocol.LENGTH_BY_RECORD);
				totLen += HanPayReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getHanPayADJTRslt_HDR(strRecord);
					adjt_dt = hm.get("ADJT_DT");
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getHanPayCHRGADJTRsltByFcstrID_2_DAT(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("ADJT_DT", adjt_dt);
					try {
						dao.insHanPayCHRGADJTRsltByFcstrID_2_DAT(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'T') {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileBC06(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			HanPayReceiverDAO dao = new HanPayReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*HanPayReceiverProtocol.LENGTH_BY_CARDPUBCO_RECORD, HanPayReceiverProtocol.LENGTH_BY_CARDPUBCO_RECORD);
				totLen += HanPayReceiverProtocol.LENGTH_BY_CARDPUBCO_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					try {
						dao.delHanPayPUBCOMST(com_cd);
					}catch(Exception e) {
						logger.info("[ERROR] Error for deleting data : " + e.getMessage());
					}
					continue;
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getHanPayPUBCO_DTL(strRecord);
					hm.put("CO_CD", com_cd);
					
					try {
						dao.insHanPayPUBCOMST(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}					
				}else if( strRecord.charAt(0) == 'T' ) {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private HashMap<String, String> getHanPayPUBCO_DTL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,6,7,10,6
					  ,120};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"SEQ_NO",
			"TMNAL_ID",
			"PUBCO_CD",
			
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getHanPayADJTRslt_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,6,14,7,8
					  ,264};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"FILE_CRT_DTM",
			"TRANS_CNT",
			"ADJT_DT",
			
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getHanPayPAYADJTRslt_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,6,7,20,10
					  ,8,16,10,16,10
					  ,2,10,10,10,10
					  ,10,14,2,2,2
					  ,10,5,10,8,2
					  ,2,87};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"SEQ_NO",
			"TRAN_UNQ_NO",
			"TMNAL_ID",
			
			"ADJT_DT",
			"SAM_ID",
			"SAM_TRAN_SEQ_NO",
			"PPCARD_NO",
			"CARD_TRAN_SEQ_NO",
			
			"TRAN_TP",
			"TRANBE_REM_AMT",
			"TRAN_REQ_AMT",
			"TRANAF_REM_AMT",
			"TRAN_FEE",
			
			"PENALTY_AMT",
			"TRAN_DTM",
			"ALGO_ID",
			"SAM_KEY_SET_VER",
			"KEY_SET_VER",
			
			"PSAM_TOT_AMT_COLECT_SEQ_NO",
			"PSAM_SPBY_COLECT_CNT",
			"PSAM_ACCM_TOT_AMT",
			"SIGN_VAL",
			"CARD_TP",
			
			"RESP_CD",
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getHanPayCHRGADJTRslt_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,6,7,20,15
					  ,10,16,4,14,14
					  ,10,2,14,10,10
					  ,10,10,2,2,2
					  ,121};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"SEQ_NO",
			"TRAN_UNQ_NO",
			"FCSTR_ID",
			
			"TMNAL_ID",
			"CARD_NO",
			"CARD_TP",
			"TRAN_REQ_DTM",
			"TRAN_FNSH_DTM", 
			
			"CARD_TRAN_SEQ_NO",
			"TASK_TP",
			"TRAN_OCCU_DTM",
			"TRANBE_REM_AMT",
			"TRAN_REQ_AMT",
			
			"TRANAF_REM_AMT",
			"TRAN_FEE",
			"RESP_CD",
			"PAY_TP",
			"CCARD_CO_TP",
			
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getHanPayCHRGADJTRslt_TAL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,6,7,7,13
					  ,10,7,13,10,7
					  ,13,10,196};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"TOT_RECORD_CNT",
			"TOT_RECHRG_CNT",
			"TOT_RECHRG_AMT",
			
			"TOT_RECHRG_FEE",
			"TOT_RECHRGCNCL_CNT",
			"TOT_RECHRGCNCL_AMT",
			"TOT_RECHRGCNCL_FEE",
			"TOT_RETRECHRG_CNT",
			
			"TOT_RETRECHRG_AMT",
			"TOT_RETRECHRG_FEE",
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getHanPayCHRGADJTRsltByFcstrID_1_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,6,7,15,7
					  ,13,10,7,13,10
					  ,7,13,10,181};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"SEQ_NO",
			"WM_STORE_CD",
			"TOT_RECHRG_CNT",
			
			"TOT_RECHRG_AMT",
			"TOT_RECHRG_FEE",
			"TOT_RECHRGCNCL_CNT",
			"TOT_RECHRGCNCL_AMT",
			"TOT_RECHRGCNCL_FEE",
			
			"TOT_RETRECHRG_CNT",
			"TOT_RETRECHRG_AMT",
			"TOT_RETRECHRG_FEE",
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getHanPayCHRGADJTRsltByFcstrID_2_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,6,7,15,7
					  ,13,10,7,13,10
					  ,211};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"SEQ_NO",
			"BIZLOC_ORG_CD",
			"TOT_PMNT_CNT",
			
			"TOT_PMNT_AMT",
			"TOT_PMNT_FEE",
			"TOT_RTN_CNT",
			"TOT_RTN_AMT",
			"TOT_RTN_FEE",
			
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
//			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
}
