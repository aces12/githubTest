package biz.cms_CGDTLDownloader;

import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class CGDTLDownloaderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(CGDTLDownloaderDAO.class);
	
	public int insCGDailyDTL(Map<String, String> map) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_CGVENDAILYAPPR_TRN"));
			sql.setString(++i, (String)map.get("CO_CD"));
			sql.setString(++i, (String)map.get("ADJT_DT"));
			sql.setString(++i, "A16" + (String)map.get("STORE_CD"));
			sql.setString(++i, (String)map.get("APPR_NO"));
			sql.setString(++i, (String)map.get("NOR_CNCL_TP"));
			sql.setString(++i, (String)map.get("APPR_ELECDOC_UNQ_ID"));
			sql.setString(++i, (String)map.get("CNCL_ELECDOC_UNQ_ID"));
			sql.setString(++i, (String)map.get("GDS_BARCD_NO"));
			sql.setString(++i, (String)map.get("AMT"));
			sql.setString(++i, (String)map.get("APPR_DTM"));
			sql.setString(++i, (String)map.get("CNCL_DTM"));
			
			logger.info("[SQL1][INS_CGVENDAILYAPPR_TRN]" + sql.debug() );
									
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
		}finally {
			//transaction 종료
			end();
		}
		
		return rows;
	}
	
	public int insCGMonthlyDTL(Map<String, String> map) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_CGVENMMBYAPPR_SUM"));
			sql.setString(++i, (String)map.get("CO_CD"));
			sql.setString(++i, (String)map.get("ADJT_DT"));
			sql.setString(++i, "A16" + (String)map.get("STORE_CD"));
			sql.setString(++i, (String)map.get("APPR_NO"));
			sql.setString(++i, (String)map.get("NOR_CNCL_TP"));
			sql.setString(++i, (String)map.get("APPR_ELECDOC_UNQ_ID"));
			sql.setString(++i, (String)map.get("CNCL_ELECDOC_UNQ_ID"));
			sql.setString(++i, (String)map.get("GDS_BARCD_NO"));
			sql.setString(++i, (String)map.get("AMT"));
			sql.setString(++i, (String)map.get("APPR_DTM"));
			sql.setString(++i, (String)map.get("CNCL_DTM"));
			
			logger.info("[SQL2][INS_CGVENMMBYAPPR_SUM]" + sql.debug() );
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
		}finally {
			//transaction 종료
			end();
		}
		
		return rows;
	}
}