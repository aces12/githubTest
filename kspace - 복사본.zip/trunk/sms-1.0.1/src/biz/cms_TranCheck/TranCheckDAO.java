package biz.cms_TranCheck;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class TranCheckDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(TranCheckPollingAction.class);
	
	public List<Object> selBlockedTran(int srchCycle) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("tran-sql", "SEL_TRANCHECK"));
			sql.setInt(++i, srchCycle);
			
//			logger.info("sql=" + sql.debug());
			list = executeQuery(sql);
		}catch(Exception e) {
			//System.out.println(e.getMessage());
			logger.info("[ERROR]selBlockedTran::" + e);
//			throw e;
		}
		
		return list;
	}
	
	public int procBLKDTRANDIVIDE(Map<String, String> map) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		String tran_ymd = (String)map.get("tran_ymd");
		String tran_hms = (String)map.get("tran_hms");
		String com_cd = (String)map.get("com_cd");
		String store_cd = (String)map.get("store_cd");
		String pos_no = (String)map.get("pos_no");
		String tran_no = (String)map.get("tran_no");
		String tran_type = (String)map.get("tran_type");
		String tran_kind = (String)map.get("tran_kind");
		String stop_yn = (String)map.get("stop_yn");
		String pmod_yn = (String)map.get("pmod_yn");
		int i=0;
		int ret=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

//			logger.info("[id:"+ proc_id + "]tran_ymd:"   + tran_ymd);
//			logger.info("[id:"+ proc_id + "]tran_hms:"   + tran_hms);
//			logger.info("[id:"+ proc_id + "]com_cd:"     + com_cd);
//			logger.info("[id:"+ proc_id + "]store_cd:"   + store_cd);
//			logger.info("[id:"+ proc_id + "]pos_no:"     + pos_no);
//			logger.info("[id:"+ proc_id + "]tran_no:"    + tran_no);
//			logger.info("[id:"+ proc_id + "]tran_type:"  + tran_type);
//			logger.info("[id:"+ proc_id + "]tran_kind:"  + tran_kind);
//			logger.info("[id:"+ proc_id + "]stop_yn:"    + stop_yn);
//			logger.info("[id:"+ proc_id + "]pmod_yn:"    + pmod_yn);
			
//			logger.info("[id:"+ proc_id + "][DEBUG] [procTRANDIVIDE] Begin");
			proc.put("SP_TRANDIVIDE", 12);
			proc.setString(++i, tran_ymd);	// tran_ymd
			proc.setString(++i, tran_hms);	// tran_hms
			proc.setString(++i, com_cd);	// com_cd
			proc.setString(++i, store_cd);	// store_cd
			proc.setString(++i, pos_no);	// pos_no
			proc.setString(++i, tran_no);	// tran_no
			proc.setString(++i, tran_type);	// tran_type
			proc.setString(++i, tran_kind);	// tran_kind
			proc.setString(++i, stop_yn);	// stop_yn
			proc.setString(++i, pmod_yn);	// pmod_yn
			proc.registerOutParameter(++i, DataTypes.INTEGER);
			proc.registerOutParameter(++i, DataTypes.VARCHAR);

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			ret = prs.getInt(11);
//			String retMsg = prs.getString(12);
//			logger.info("[id:"+ proc_id + "][DEBUG] [procTRANDIVIDE] ResultMsg:" + retMsg);
//			logger.info("[id:"+ proc_id + "][DEBUG] [procTRANDIVIDE] End");
		} catch (Exception e) {
			rollback();
//			System.out.println(e.getMessage());
			logger.info("[ERROR] procBLKDTRANDIVIDE::" + e);
			ret=-1;
		} finally {
			// 모든 trasaction을 종료하고 리소스를 반납합니다.
			end();
		}
		
		return ret;
	}
}
