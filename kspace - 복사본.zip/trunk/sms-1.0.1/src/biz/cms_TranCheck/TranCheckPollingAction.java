package biz.cms_TranCheck;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_TMoneySender.TMoneySenderFileTransfer;
import biz.cms_TMoneySender.TMoneySenderPollingAction;

import kr.fujitsu.com.ffw.daemon.core.CurrentContext;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

public class TranCheckPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(TranCheckPollingAction.class);
	private static DaemonConfigLocator locator = null;
	
	public static void main(String args[]) throws Exception {
		TranCheckPollingAction action = new TranCheckPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			action.execute("1");
			
			
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		try {
//			if( actionMode == "1" ) {
//				logger.info(">>>> 2222 <<<<");
//				String xmlPath = PropertyUtil.findProperty("stsys-property", "SMS_ROOT");
//				
//				if( locator == null ) {
//					locator = DaemonConfigLocator.getInstance("xml", xmlPath);
//					locator.setCurrentContext(new CurrentContext(locator.getDaemonConfig()
//							.getNode().getEngineContainer("cms_TranCheck")));
//				}
//				
//				String strSearchCycle = "";
//				
//				try {
//					strSearchCycle = locator.getCurrentContext().getContext().getEngineAttribute().getAttribute("SearchCycle").getValue();
//				}catch( NumberFormatException e ) {
//					logger.info("NumberFormatException : System set default value(30minute).");
//					locator = null;
//					strSearchCycle = "30";
//				}
				
				TranCheckDAO dao = new TranCheckDAO();
				List<Object> list = null;
				
				list = dao.selBlockedTran(30);
				
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					
					dao.procBLKDTRANDIVIDE(map);
				}
//			}
		}catch(Exception e) {
			locator = null;
			logger.info("TranCheck Exception : " + e.getMessage());
		}
	}

}
