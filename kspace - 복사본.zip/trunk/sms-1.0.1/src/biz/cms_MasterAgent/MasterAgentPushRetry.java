package biz.cms_MasterAgent;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;
import biz.cms_MasterCrt.MasterCrtClientAction;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;

public class MasterAgentPushRetry extends Thread {
	private static Logger logger = Logger.getLogger(MasterAgentPollingAction.class);
	private final int POS_PORT = 9029;
	private final int MAX_TARGET_NUM = 100;
	private int curWork = 0;
	private int curPushCnt = 0;
	private MasterAgentPOSOperator operator = null;
	private Map<String, String> map = null;
	private MasterCrtClientAction action = null;
	
	public MasterAgentPushRetry(int curPushCnt,MasterCrtClientAction action) {
		this.curPushCnt = curPushCnt;
		this.action =  action;
		logger.info("★★ _"+curPushCnt+"_ MasterAgentPushRetry Thread create ★★");
	}
	
	private volatile boolean stop = false;
	public void stopThread() {
	     stop = true;
	}
	
	public void setMap(Map<String, String> map) {
		this.map = map;
	}

	public synchronized void waitThread() throws InterruptedException {				
			this.wait();
			logger.info("★★waiting!!!!★★");
		}
	
	public synchronized void wakeThread() {		
		this.notify();
		logger.info("★★wakening!!!!★★");
	}
	public void run() {
		if (!stop){
			try {
//				logger.info("★★ _"+curPushCnt+"_ MasterAgentPushRetry Thread start running ★★");			
				newDeployRetry(map);				
			}catch(Exception e) {
				logger.info("[ERROR]" + e);
			}finally{
				System.gc();
			}			
			
		}

	}
	

	public void newDeployRetry(Map map) throws Exception{
		
		MasterAgentDAO dao   = new MasterAgentDAO();
		List list = null;		
		int ret = -1;
		
		String local_no = PropertyUtil.findProperty("communication-property", "LOCAL_SERVER_NO");

		Calendar cal = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("MMddHHmmssSSSSS");
		String sOTPVal = dateFormat1.format(cal.getTime()) + (Double.toString(Math.random())).substring(2, 9);

		logger.info("★_"+curPushCnt+"_newDeployRetry start[STORE_CD]"+ (String)map.get("STORE_CD")+"[TRANS_SEQ]"+ (String)map.get("TRANS_SEQ"));		
	
		ret = dao.updMASTERTARGETSEL((String)map.get("TRANS_SEQ"),sOTPVal, "3", local_no,(String)map.get("TRANS_ID"));  //PROC_ID 3=>1    배신 1회실패한 POS들을 다시 배신 준비로 변경함

		if( ret > 0 ) {
//			logger.info("★★_"+curPushCnt+"_ master sendOrder start **["+(String)map.get("STORE_CD")
//					+ "**["+(String)map.get("TRANS_SEQ")
//					+ "] reservation POS Count =[" + ret + "]  ★★★★");
			// 예약된 POS List 조회
			list = dao.selTARGETMASTERLIST(sOTPVal,local_no,(String)map.get("TRANS_SEQ"));
			
			//logger.info("★★selTARGETMASTERLIST list.size=>["+list.size()+"]★★★★★★★");					
			MasterAgentPOSOperator op = new MasterAgentPOSOperator(curPushCnt , action);
	
			op.setMaxThread(MAX_TARGET_NUM);

			op.pushRequest(list);
		}else{
			logger.info("★_★_★ _There are no push fail pos. so no try send push★_★_★  ");
			
		}

		
	} 
}

	
