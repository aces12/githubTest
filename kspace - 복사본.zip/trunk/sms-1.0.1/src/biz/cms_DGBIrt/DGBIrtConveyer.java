package biz.cms_DGBIrt;

import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import biz.comm.AES;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.BasicStringFilter;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

public class DGBIrtConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;

	COMMLog df = null;
	
	public DGBIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}
	
	public String getDGBChangeSnd(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		DGBIrtProtocol protocol = new DGBIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// UPAY로 보낼 송신 전문
		String recvBuf = "";	// UPAY에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.DGB_FILTER)));
			hm.put("STX", " ");//
//HEADER			
			hm.put("DATA_LEN", "0206");						//HEADER(57)+BODYDATA(149)
			hm.put("DATA_CD", (String)hmComm.get("SYS_HMS").substring(2, 6)
							+(String)hmComm.get("STORE_CD")
							+(String)hmComm.get("POS_NO").substring(1, 4)
							+(String)hmComm.get("TRAN_NO"));//송신기관생성번호(MMDD+점포번호+포스번호+거래번호)
			hm.put("SYS_SEND_CD", "01020000");				// WITHME기관코드(0102)+0000
			hm.put("SYS_RECV_CD", "01020000");				// WITHME기관코드(0102)+0000
			hm.put("TASK_CD", "0170");						//업무구분코드
			hm.put("JOB_CD", "0010");						//작업구분코드
			hm.put("SEND_DATE", (String)hmComm.get("SYS_YMD")+(String)hmComm.get("SYS_HMS"));//전문전송일시
			hm.put("HEADER_REQ", "   ");					//HEADER응답코드
//DATA
			hm.put("FCSTR_NO", (String)hm.get("FCSTR_NO").trim());//1.편의점ID
//			hm.put("DEAL_UNIQ_NO", (String)hm.get("DEAL_UNIQ_NO").trim());//2.거래관리번호
//			hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID").trim());//3.단말기ID
			AES aes = new AES();
			hm.put("CARD_NO", aes.decrypt((String)hm.get("CARD_NO").trim()));//4.카드일련번호
//			hm.put("CVEP", (String)hm.get("CVEP").trim());//5.카드암호화버전
//			hm.put("ALGEP", (String)hm.get("ALGEP").trim());//6.카드알고리즘
//			hm.put("PARAM_TYPE", (String)hm.get("PARAM_TYPE").trim());//7.파라미터종류
//			hm.put("OLD_CARD_HOLDER", (String)hm.get("OLD_CARD_HOLDER").trim());//8.변경전카드소지자코드
//			hm.put("BALEP", (String)hm.get("BALEP").trim());//9.카드잔액
//			hm.put("ID_CENTER", (String)hm.get("ID_CENTER").trim());//10.전자화폐사업자코드
//			hm.put("NTEP", (String)hm.get("NTEP").trim());//11.카드카운트
//			hm.put("REP", (String)hm.get("REP").trim());//12.카드생성랜덤번호
//			hm.put("SIGN", (String)hm.get("SIGN").trim());//13.SIGN값
//			hm.put("NEW_CARD_HOLDER", (String)hm.get("NEW_CARD_HOLDER").trim());//14.변경후카드소지자코드
//			hm.put("RHOST", (String)hm.get("RHOST").trim());//15.HOST생성랜덤번호
//			hm.put("TRAN_YMD", (String)hm.get("TRAN_YMD").trim());//16.처리일시
//			hm.put("BIRTH_YMD", (String)hm.get("BIRTH_YMD").trim());//17.생년월일

//			hm.put("FILLER", " ");
//			hm.put("NEWLN_CHAR", String.format("%1x", 0x0A));
			
			hm.put("ETX", " ");
			
			sendMsg = makeSendDataDGBChangeSnd(hm);
			
			df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "]:[COMMAND_TYPE: [" + sendMsg + "]");
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문 길이 STX, ETX 설정
			sendBytes[0] = (byte)0x02;
			sendBytes[211] = (byte)0x03;
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("DGB UPay server is no response");
			}
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<dgbupay] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			
			hmRecv = protocol.getParseDGBChangeRcvRsp(recvBuf);
			df.CommLogger("chk");
			hmRecv.put("INQ_TYPE", "B6");
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataDGBChangeRcvRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}	
		return dataMsg;
	}
	
	private String makeSendDataDGBChangeRcvRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,100
					 ,4,16,8,8,4
					 ,4,16,8,16,8};
		String strHeaders[] = {
			"INQ_TYPE",
			"RES_CD",
			"RES_MSG",
			
			"DATA_LEN",
			"DATA_CD",
			"SYS_SEND_CD",
			"SYS_RECV_CD",
			"TASK_CD",
			"JOB_CD",
			
			"IDHOST",
			"NTHOST",
			
			"EPV",
			"SIGN2",
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make Send DataDGBRcvRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataDGBChangeSnd(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1
				 	,4,16,8,8,4
				 	,4,14,3,	13,18
				 	,10,16,2,2,4
				 	,2,8,2,8,16
				 	,8,2,16,14,8
				 	,1};
		String strHeaders[] = {
			"STX",
//HEADER				
			"DATA_LEN",
			"DATA_CD",
			"SYS_SEND_CD",
			"SYS_RECV_CD",
			"TASK_CD",
			"JOB_CD",
			"SEND_DATE",
			"HEADER_REQ",
//BODY				                  			
			"FCSTR_NO",
			"DEAL_UNIQ_NO",
			
			"TERMINAL_ID",
			"CARD_NO",
			"CVEP",
			"ALGEP",
			"PARAM_TYPE",
			
			"OLD_CARD_HOLDER",
			"BALEP",
			"ID_CENTER", 
			"NTEP",
			"REP",
			
			"SIGN",
			"NEW_CARD_HOLDER",
			"RHOST",
			"TRAN_YMD",
			"BIRTH_YMD"
			
			,"ETX"
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send DGBChangeSnd : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getDGBChangeCompletedInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		DGBIrtProtocol protocol = new DGBIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.DGB_FILTER)));
			hm.put("STX", " ");
//HEADER			
			hm.put("DATA_LEN", "0110");						//HEADER(57)+BODYDATA(53)
			hm.put("DATA_CD", (String)hmComm.get("SYS_HMS").substring(2, 6)
							+(String)hmComm.get("STORE_CD")
							+(String)hmComm.get("POS_NO").substring(1, 4)
							+(String)hmComm.get("TRAN_NO"));//송신기관생성번호(MMDD+점포번호+포스번호+거래번호)
			hm.put("SYS_SEND_CD", "01020000");				// WITHME기관코드(0102)+0000
			hm.put("SYS_RECV_CD", "01020000");				// WITHME기관코드(0102)+0000
			hm.put("TASK_CD", "0170");						//업무구분코드
			hm.put("JOB_CD", "0030");						//작업구분코드
			hm.put("SEND_DATE", (String)hmComm.get("SYS_YMD")+(String)hmComm.get("SYS_HMS"));//전문전송일시
			hm.put("HEADER_REQ", "   ");					//HEADER응답코드
//DATA
			hm.put("FCSTR_NO", (String)hm.get("FCSTR_NO").trim());//1.편의점ID
//			hm.put("DEAL_UNIQ_NO", (String)hm.get("DEAL_UNIQ_NO").trim());//2.거래관리번호
			AES aes = new AES();
			hm.put("CARD_NO", aes.decrypt((String)hm.get("CARD_NO").trim()));//4.카드일련번호
//			hm.put("ID_CARD_HOLDER", (String)hm.get("ID_CARD_HOLDER").trim());//4.카드소지자코드
//			hm.put("RESP_CD", (String)hm.get("RESP_CD").trim());//5.카드처리응답코드
			
			hm.put("ETX", " ");
			
			sendMsg = makeSendDataDGBChangeResultInq(hm);
			
			df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "]:[sendMsg:" + sendMsg + "]");
			
			byte sendBytes[] = sendMsg.getBytes();
			// 전문 길이 설정
			sendBytes[0] = (byte)0x02;
			sendBytes[115] = (byte)0x03;
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("DGB UPay server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<cashbee] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			
			hmRecv = protocol.getParseDGBChangeResultRsp(recvBuf);
			hmRecv.put("INQ_TYPE", "B7");
			
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataDGBChangeCompletedRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataDGBChangeCompletedRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,100};
		String strHeaders[] = {
			"INQ_TYPE",
			"RES_CD",
			"RES_MSG",			
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeRFNDCompletedRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataDGBChangeResultInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1
					 ,4,16,8,8,4
			 	 	 ,4,14,3,	13,18
			 	 	 ,16,2,4
			 	 	 ,1};
		String strHeaders[] = {
				"STX",
//HEADER				
				"DATA_LEN",
				"DATA_CD",
				"SYS_SEND_CD",
				"SYS_RECV_CD",
				"TASK_CD",
				"JOB_CD",
				"SEND_DATE",
				"HEADER_REQ",
//BODY				        
				"FCSTR_NO",
				"DEAL_UNIQ_NO",
				"CARD_NO", 
				"ID_CARD_HOLDER",
				"RESP_CD"
			
				,"ETX"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeRFNDResultInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeRFNDFailInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,8,10,16,8,6
					  ,10,1,70};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
					
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
					
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
					
			"PAY_FLAG",
			"RFND_FEE_AMT",
			"RFND_FEE_RATE",
			"IDLSAM",
			"NT_CARDLSAM",
			
			"SIGN2_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"DEAL_RESULT",
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeRFNDFailInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getCashBeeCHRGCancelInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		DGBIrtProtocol protocol = new DGBIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBEE_FILTER)));
			
			hm.put("DATA_LEN", "0300");
			//hm.put("DEAL_TYPE", (String)hm.get("DEAL_TYPE"));
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));
			//hm.put("DEAL_REQ_YMD", (String)hm.get("DEAL_REQ_YMD"));
			//hm.put("DEAL_REQ_HMS", (String)hm.get("DEAL_REQ_HMS"));
			//hm.put("DEAL_SNO", (String)hm.get("DEAL_SNO"));
			hm.put("RES_CD", "0000");
			hm.put("RES_MSG", " ");
			hm.put("PUBCO_INFOCHNG_YN", "00");
			//hm.put("ADJT_YMD", (String)hm.get("ADJT_YMD"));
			hm.put("FILLER", " ");
			//hm.put("CARD_NO", (String)hm.get("CARD_NO"));
			//hm.put("DEAL_BEF_RAMT", (String)hm.get("DEAL_BEF_RAMT"));
			//hm.put("DEAL_REQ_AMT", (String)hm.get("DEAL_REQ_AMT"));
			//hm.put("DEAL_AFT_RAMT", (String)hm.get("DEAL_AFT_RAMT"));
			//hm.put("PAY_FLAG", (String)hm.get("PAY_FLAG"));
			//hm.put("CHRG_FEE_AMT", (String)hm.get("CHRG_FEE_AMT"));
			//hm.put("CHRG_FEE_RATE", (String)hm.get("CHRG_FEE_RATE"));
			//hm.put("ALGEP", (String)hm.get("ALGEP"));
			//hm.put("BALEP", (String)hm.get("BALEP"));
			//hm.put("IDCENTER", (String)hm.get("IDCENTER"));
			//hm.put("IDEP", (String)hm.get("IDEP"));
			//hm.put("NTEP", (String)hm.get("NTEP"));
			//hm.put("REP", (String)hm.get("REP"));
			//hm.put("BEF_IDSAM", (String)hm.get("BEF_IDSAM"));
			//hm.put("BEF_MLDA", (String)hm.get("BEF_MLDA"));
			//hm.put("BEF_NTEP", (String)hm.get("BEF_NTEP"));
			//hm.put("SIGN1_VAL", (String)hm.get("SIGN1_VAL"));
			//hm.put("RFU", (String)hm.get("RFU"));
			//hm.put("L_MEMBER_NO", (String)hm.get("L_MEMBER_NO"));
			//hm.put("ODEAL_CHRG_YMDHMS", (String)hm.get("ODEAL_CHRG_YMDHMS"));
			//hm.put("ODEAL_CHRG_SIGN2", (String)hm.get("ODEAL_CHRG_SIGN2"));
			
			sendMsg = makeSendDataCashBeeCHRGCancelInq(hm);
			
			df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("DEAL_TYPE") + "]:[" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>cashbee] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("CashBee server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<cashbee] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			
			hmRecv = protocol.getParseCashBeeCHRGCancelRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataCashBeeCHRGCancelRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataCashBeeCHRGCancelRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,10,4,16
					  ,20,10,10,10,1
					  ,10,4,16,10,8
					  ,10,16,8,6,10
					  ,6};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"RES_CD",
			"RES_MSG",
				
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
				
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDSAM",
			"NT_CARDLSAM",
			"SIGN2",
			
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			"DEAL_SNO",
			
			"EVT_CHRG_AMT"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGCancelRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataCashBeeCHRGCancelInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,2,10
					  ,2,16,10,16,16
					  ,10,10,8,8,16
					  ,14,8,9};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
			
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"ALGEP",
			"BALEP",
			
			"IDCENTER",
			"IDEP",
			"NTEP",
			"REP",
			"BEF_IDSAM",
			
			"BEF_MLDA",
			"BEF_NTEP",
			"SIGN1_VAL",
			"RFU",
			"L_MEMBER_NO",
			
			"ODEAL_CHRG_YMDHMS",
			"ODEAL_CHRG_SIGN2",
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGCancelInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getDGBCHRGCompletedInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		DGBIrtProtocol protocol = new DGBIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {				df.CommLogger("1");
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.DGB_FILTER)));
			hm.put("STX", " ");
			
			hm.put("DATA_LEN", "0174");							//HEADER(57)+BODYDATA(117)
			hm.put("DATA_CD", (String)hmComm.get("SYS_HMS").substring(2, 6)
							+(String)hmComm.get("STORE_CD")
							+(String)hmComm.get("POS_NO").substring(1, 4)
							+(String)hmComm.get("TRAN_NO"));	//송신기관생성번호(MMDD+점포번호+포스번호+거래번호)
			hm.put("SYS_SEND_CD", "01020000");					// WITHME기관코드(0102)+0000
			hm.put("SYS_RECV_CD", "01020000");					// WITHME기관코드(0102)+0000
//			hm.put("TASK_CD", "1410");
			if(hm.get("PROC_CD").equals("00")){hm.put("TASK_CD", "1410");}//업무구분코드
			else if(hm.get("PROC_CD").equals("01")){hm.put("TASK_CD", "1420");}
			else if(hm.get("PROC_CD").equals("02")){hm.put("TASK_CD", "1430");}
			else if(hm.get("PROC_CD").equals("03")){hm.put("TASK_CD", "1440");}
			
			hm.put("JOB_CD", "0030");			//작업구분코드
			hm.put("SEND_DATE", (String)hmComm.get("SYS_YMD")+(String)hmComm.get("SYS_HMS"));//전문전송일시
			hm.put("HEADER_REQ", "   ");		//HEADER응답코드
			
			hm.put("FCSTR_NO", (String)hm.get("FCSTR_NO").trim());			//1.가맹점번호 등록 응답받은 편의점 ID
//			hm.put("DEAL_UNIQ_NO", (String)hm.get("DEAL_UNIQ_NO").trim());	//2.거래관리번호
//			hm.put("CARD_CORP_CD", (String)hm.get("CARD_CORP_CD").trim());	//3.카드사코드
			AES aes = new AES();
			hm.put("CARD_NO", aes.decrypt((String)hm.get("CARD_NO").trim()));//4.카드일련번호
//			hm.put("BALEP", (String)hm.get("BALEP").trim());				//5.카드잔액
//			hm.put("NTEP", (String)hm.get("NTEP").trim());					//6.카드거래카운트
//			hm.put("SAM_ID", (String)hm.get("SAM_ID").trim());				//7.SAMID
//			hm.put("NTSAM", (String)hm.get("NTSAM").trim());				//8.SAM거래카운터
//			hm.put("RHSM", (String)hm.get("RHSM").trim());					//9.SAM생성난수HSM난수
//			hm.put("SIGN3", (String)hm.get("SIGN3").trim());				//10.전자화폐발행사서명
//			hm.put("RESP_CD", (String)hm.get("RESP_CD").trim());			//11.거래응답코드
			
			hm.put("ETX", " ");
			
			sendMsg = makeSendDataDGBCHRGResultInq(hm);
			
			df.CommLogger("sendMsg:["+sendMsg+"]");
			
			byte sendBytes[] = sendMsg.getBytes();
			
			sendBytes[0] = (byte)0x02;
			sendBytes[179] = (byte)0x03;
			
//			df.CommLogger("[sms>dgb] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("DEAL_TYPE") + "]:[" + sendMsg + "]");
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>dgb] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>dgb] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("DGB UPay server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<dgb] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:" + recvBuf.substring(4, 6) + "]:[" + recvBuf + "]");
			
			hmRecv = protocol.getParseDGBCHRGResultRsp(recvBuf);
			hmRecv.put("INQ_TYPE", "B5");
			
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataDGBCHRGCompletedRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataDGBCHRGCompletedRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
//		hm.put("RESP_MSG", rspMsgParsing((String)hm.get("RESP_CD")));	//오류메세지 가져옴
		int nlens[] = {2,2,100};
		String strHeaders[] = {
			"INQ_TYPE",
			"RESP_CD",
			"RESP_MSG",
		};
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGCompletedRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataDGBCHRGResultInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1
				 ,4,16,8,8,4
			 	 ,4,14,3,	13,18
			 	 ,2,16,8,8,16
			 	 ,8,16,8,4
			 	 ,1};
		String strHeaders[] = {
				"STX",
//HEADER				
				"DATA_LEN",
				"DATA_CD",
				"SYS_SEND_CD",
				"SYS_RECV_CD",
				"TASK_CD",
				"JOB_CD",
				"SEND_DATE",
				"HEADER_REQ",
//BODY				                  
				"FCSTR_NO",
				"DEAL_UNIQ_NO",
				"CARD_CORP_CD",
				"CARD_NO",
				"BALEP",
				
				"NTEP",
				"SAM_ID",
				"NTSAM",
				"RHSM",
				"SIGN3",
			
				"RESP_CD"
				
				,"ETX"
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send DGBCHRGResultInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}

	
	public String getDGBCHRGInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		DGBIrtProtocol protocol = new DGBIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.DGB_FILTER)));
			
			hm.put("STX", " ");//BYTE시작
//HEADER			
			hm.put("DATA_LEN", "0310");								//HEADER(57)+BODYDATA(253)
			hm.put("DATA_CD", (String)hmComm.get("SYS_HMS").substring(2, 6)
							+(String)hmComm.get("STORE_CD")
							+(String)hmComm.get("POS_NO").substring(1, 4)
							+(String)hmComm.get("TRAN_NO"));		//송신기관생성번호(MMDD+점포번호+포스번호+거래번호)
			hm.put("SYS_SEND_CD", "01020000");						// WITHME기관코드(0102)+0000
			hm.put("SYS_RECV_CD", "01020000");						// WITHME기관코드(0102)+0000
						
				 if(hm.get("PROC_CD").equals("00")){hm.put("TASK_CD", "1410");}
			else if(hm.get("PROC_CD").equals("01")){hm.put("TASK_CD", "1420");}
			else if(hm.get("PROC_CD").equals("02")){hm.put("TASK_CD", "1430");}
			else if(hm.get("PROC_CD").equals("03")){hm.put("TASK_CD", "1440");}
			
			df.CommLogger(Integer.parseInt(hm.get("PROC_CD")) + "/" +hm.get("PROC_CD")+"/"+hm.get("TASK_CD"));//
			
			hm.put("JOB_CD", "0010");//작업구분코드
			hm.put("SEND_DATE", (String)hmComm.get("SYS_YMD")+(String)hmComm.get("SYS_HMS"));//전문전송일시
			hm.put("HEADER_REQ", "   ");//HEADER응답코드
//DATA
			hm.put("FCSTR_NO", (String)hm.get("FCSTR_NO").trim());			//1.가맹점번호 등록 응답받은 편의점 ID
//			hm.put("DEAL_UNIQ_NO", (String)hm.get("DEAL_UNIQ_NO").trim());	//2.거래관리번호
//			hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID").trim());	//3.단말기번호
//			hm.put("ADJT_YMD", (String)hm.get("ADJT_YMD").trim());			//4.정산일자
//			hm.put("CARD_CORP_CD", (String)hm.get("CARD_CORP_CD").trim());	//5.카드사구분
			AES aes = new AES();//카드번호 복호화, 적용된 다른 프로젝트 확인
			hm.put("CARD_NO", aes.decrypt((String)hm.get("CARD_NO").trim()));//6.카드번호 decrypt
//			hm.put("ID_CARD_HOLDER", (String)hm.get("ID_CARD_HOLDER").trim());//7.카드소지자유형코드
//			hm.put("CARD_TP", (String)hm.get("CARD_TP").trim());			//8타카드소지자유형코드
//			hm.put("CVEP", (String)hm.get("CVEP").trim());					//9카드암호화버전
//			hm.put("ALGEP", (String)hm.get("ALGEP").trim());				//.10적용알고리즘
//			hm.put("VKDL_KEY", (String)hm.get("VKDL_KEY").trim());			//11.충전키버전
//			hm.put("BALEP", (String)hm.get("BALEP").trim());				//12.카드잔액
//			hm.put("MLDA", (String)hm.get("MLDA").trim());					//13.충전금액
//			hm.put("IDCENTER", (String)hm.get("IDCENTER").trim());			//14.전자화폐사업자코드
//			hm.put("NTEP", (String)hm.get("NTEP").trim());					//15.카드거래카운터
//			hm.put("REP", (String)hm.get("REP").trim());					//16.카드생성랜덤 난수
//			hm.put("RSAM", (String)hm.get("RSAM").trim());					//17.SAM생성랜덤번호
//			hm.put("SAM_ID", (String)hm.get("SAM_ID").trim());				//18.LSAMID
//			hm.put("NTSAM", (String)hm.get("NTSAM").trim());				//19.LSAM거래카운터
//			hm.put("SIGN1", (String)hm.get("SIGN1").trim());				//20?전자화폐발행사 SIGN값
//			hm.put("BEF_TRT", (String)hm.get("BEF_TRT").trim());			//21.직전거래 거래유형
//			hm.put("BEF_MLDA", (String)hm.get("BEF_MLDA").trim());			//22.직전거래 거래금액
//			hm.put("BEF_NTEP", (String)hm.get("BEF_NTEP").trim());			//23.직전거래 카드거래카운트
//			hm.put("BEF_BALEP", (String)hm.get("BEF_BALEP").trim());		//24.직전거래 거래후카드잔액
//			hm.put("BEF_SAM_ID", (String)hm.get("BEF_SAM_ID").trim());		//25.직전거래 SAM일련번호
//			hm.put("BEF_NT_SAM", (String)hm.get("BEF_NT_SAM").trim());		//26.직전거래 SAM거래카운트
//			hm.put("BEF_YMD", (String)hm.get("BEF_YMD").trim());			//27.직전거래 거래일시
//			hm.put("RETURN_TP", (String)hm.get("RETURN_TP").trim());		//28.발행사코드
//			hm.put("ORG_DEAL_UNIQ_NO", (String)hm.get("ORG_DEAL_UNIQ_NO").trim());//29.원지불거래관리번호	
			
			hm.put("ETX", " ");//BYTE종료
			
			sendMsg = makeSendDataDGBCHRGInq(hm);	
			df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "]:[FCSTR_NO:" + (String)hm.get("FCSTR_NO") + "]:[" + sendMsg + "]");
			
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문 길이 STX, ETX 설정
			sendBytes[0] = (byte)0x02;
			sendBytes[315] = (byte)0x03;
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("DGBupay server is no response");
			}

			recvBuf = (String)actSock.receive();
			df.CommLogger("[sms<dgbupay] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
						
			hmRecv = protocol.getParseDGBCHRGRsp(recvBuf);
			hmRecv.put("INQ_TYPE", "B4");

		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataDGBCHRGRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataDGBCHRGRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		
		int nlens[] = {2,2,100,4,16
					 ,8,8,4,4,14
					 ,16,16,8,8,8
					 ,16,8};
		String strHeaders[] = {
			"INQ_TYPE",
			"RESP_CD",
			"RESP_MSG",		
			"DATA_LEN",
			"DATA_CD",
			
			"SYS_SEND_CD",
			"SYS_RECV_CD",
			"TASK_CD",
			"JOB_CD",
			"TRAN_YMD",	//SEND_DATE->TRAN_YMD로 수정
			
			"HOST_NO",
			"RHSM",
			"BALEP",
			"NTLSAM",
			"SIGN2",
			
			"SAM_ID",
			"NTSAM"
		};
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeCHRGRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		return sb.toString();
	}
	
	private String makeSendDataDGBCHRGInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1
					 ,4,16,8,8,4
				 	 ,4,14,3,	13,18
				 	 ,10,8,2,16,2
				 	 ,4,2,2,2,8
				 	 ,8,2,8,16,16
				 	 ,16,8,8,2,8
				 	 ,8,8,16,8,14
				 	 ,2,18
				 	 ,1};
		String strHeaders[] = {
				"STX",
//HEADER				
				"DATA_LEN",
				"DATA_CD",
				"SYS_SEND_CD",
				"SYS_RECV_CD",
				"TASK_CD",
				"JOB_CD",
				"SEND_DATE",
				"HEADER_REQ",
//BODY				                  
				"FCSTR_NO", 
				"DEAL_UNIQ_NO", 
				"TERMINAL_ID", 
				"ADJT_YMD",
				"CARD_CORP_CD",
				"CARD_NO", 
				"ID_CARD_HOLDER", 
				"CARD_TP",
				"CVEP", 
				"ALGEP",
				"VKDL_KEY",
				"BALEP", 
				"MLDA",
				"IDCENTER",
				"NTEP",
				"REP",
				"RSAM",
				"SAM_ID",
				"NTSAM", 
				"SIGN1",
				"BEF_TRT", 
				"BEF_MLDA",
				"BEF_NTEP", 
				"BEF_BALEP", 
				"BEF_SAM_ID",
				"BEF_NT_SAM",
				"BEF_YMD",
				"RETURN_TP",
				"ORG_DEAL_UNIQ_NO"
				
				,"ETX"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send DGBCHRGInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	public String getDGBTMNLINSTALLInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		DGBIrtProtocol protocol = new DGBIrtProtocol();
		DGBIrtDAO dao = new DGBIrtDAO();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// DGB로 보낼 송신 전문
		String recvBuf = "";	// DGB에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		List<Object> list = null;
		Map<String, String> map = null;
		
		String strBizNm = " ";
		String strBizNo = " ";
		String withme_corp_no = " ";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.DGB_FILTER)));
			
			hm.put("STX", " ");//BYTE시작
//HEADER
			hm.put("DATA_LEN", "0190");						//HEADER(57)+BODYDATA(133)
			hm.put("DATA_CD", (String)hmComm.get("SYS_HMS").substring(2, 6)
							+(String)hmComm.get("STORE_CD")
							+(String)hmComm.get("POS_NO").substring(1, 4)
							+(String)hmComm.get("TRAN_NO"));//송신기관생성번호(MMDD+점포번호+포스번호+거래번호)
			hm.put("SYS_SEND_CD", "01020000");// WITHME기관코드(0102)+0000
			hm.put("SYS_RECV_CD", "01020000");// WITHME기관코드(0102)+0000
			hm.put("TASK_CD", "0180");		//업무구분코드
			hm.put("JOB_CD", "0010");		//작업구분코드
			hm.put("SEND_DATE", (String)hmComm.get("SYS_YMD")+(String)hmComm.get("SYS_HMS"));//전문전송일시
			hm.put("HEADER_REQ", "   ");	//HEADER응답코드	
//DATA			
//해당편의점정보
			list = dao.getBizCoNo((String)hmComm.get("COM_CD"), (String)hmComm.get("STORE_CD"));
			if( list.size() > 0 ) {
				map = (Map<String, String>)list.get(0);
				strBizNm = map.get("BIZLOC_NM");    
				strBizNo = map.get("BIZCO_NO");     	
			}
//WITHME사업자번호
			withme_corp_no = PropertyUtil.findProperty("service-property", "WITHME_CORP_NO");
//			hm.put("JOB_TP", (String)hm.get("JOB_TP").trim());				//업무구분
//			hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID").trim());	//단말기ID
//			hm.put("SAM_ID", (String)hm.get("SAM_ID").trim());				//SAM일련번호
//			hm.put("BEF_SAM_ID", (String)hm.get("BEFORE_SAM_ID").trim());//교체전SAM일련번호
			hm.put("FCSTR_NM", strBizNm);									//편의점명
			hm.put("TEL_NO", "                    ");						//전화번호
			hm.put("HQ_CORP_REG_NO", withme_corp_no);						//유통제휴사(withme)사업자번호
			hm.put("FCSTR_CORP_REG_NO", strBizNo);							//편의점사업자번호
			hm.put("BEF_FCSTR_CORP_REG_NO", "          ");					//양수도전편의점사업자번호
						
			hm.put("ETX", " ");//BYTE종료
			
//			hm.put("FCSTR_NM", "테스트점포2");			//test삽입 편의점명
//			hm.put("FCSTR_CORP_REG_NO", "4445566777");	//test삽입 편의점사업자번호
			
						
			sendMsg = makeSendDataDGBTMNLINSTALLInq(hm);					//업체전송데이터 생성
			df.CommLogger("[sms>DGBUpay] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("JOB_TP") + "]:[" + sendMsg + "]");

			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문 길이 STX, ETX 설정
			sendBytes[0] = (byte)0x02;
			sendBytes[195] = (byte)0x03;
			
			if( actSock.send(sendBytes, sendBytes.length) ) {//sendBytes, sendBytes.length
				df.CommLogger("[sms>DGBUpay] SEND[" + sendBytes.length + "] OK");
			}else {
				df.CommLogger("[sms>DGBupay] SEND[" + sendBytes.length + "] ERROR");

				throw new Exception("DGB Upay server is no response");
			}

			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<dgbupay] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			
			hmRecv = protocol.getParseDGBTMNLINSTALLRsp(recvBuf);
			df.CommLogger("hmRecv[" + hmRecv + "]");
			hmRecv.put("INQ_TYPE", "B3");

		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			df.CommLogger("finally");
			dataMsg = ret + makeSendDataDGBTMNLINSTALLRsp(hmRecv);
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataDGBTMNLINSTALLInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1, 4,16,8,8,4
					 ,4,14,3,	1,10
					 ,16,16,40,20,10
					 ,10,10 ,1
					 };
		String strHeaders[] = {
				"STX",
//공통HEADER				
				"DATA_LEN",
				"DATA_CD",
				"SYS_SEND_CD",
				"SYS_RECV_CD",
				"TASK_CD",
				"JOB_CD",
				"SEND_DATE",
				"HEADER_REQ",
//DATA
				"JOB_TP",
				"TERMINAL_ID",
				"SAM_ID",
				"BEF_SAM_ID",
				"FCSTR_NM",
				"TEL_NO",
				"HQ_CORP_REG_NO",
				"FCSTR_CORP_REG_NO",
				"BEF_FCSTR_CORP_REG_NO"
				
				,"ETX"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			df.CommLogger("★ make: ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataDGBTMNLINSTALLRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();

		int nlens[] = {2,2,100,13};
		String strHeaders[] = {
			"INQ_TYPE",
			"RESP_CD",
			"RESP_MSG",

			"FCSTR_NO"
		};
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeTMNLINSTALLRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataHeaderRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		//HeaderLength=61
		int nlens[] = {4,16,8,8,4
					  ,4,14,3};
		String strHeaders[] = {
			"DATA_LEN",			//전문길이
			"DATA_CD",			//전문일련번호
			"SYSSEND_CD",		//시스템구분코드SEND
			"SYSRECV_CD",		//시스템구분코드RECV
			"TASK_CD",			//업무구분코드
			
			"JOB_CD",			//작업구분코드
			"SEND_DATE",		//전문송신일시
			"HEADER_REQ",		//HEADER응답코드
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeTMNLINSTALLRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String rspMsgParsing(String rspCode){
		String rspMsg = "";
		if (rspCode.equals("00")){rspMsg = "정상";		
		}else if (rspCode.equals("01")){	rspMsg = "오류데이터(데이트 포멧 이상)";
		}else if (rspCode.equals("03")){	rspMsg = "SIGN 값 오류";
		}else if (rspCode.equals("04")){	rspMsg = "미발행 카드(선불카드 ID 미등록)";	//권종변경응답코드
		}else if (rspCode.equals("05")){	rspMsg = "LSAM ID 미등록";
		}else if (rspCode.equals("06")){	rspMsg = "선불카드 ID 미등록";
		}else if (rspCode.equals("07")){	rspMsg = "데이터 레코드내 중복데이터 존재";
		}else if (rspCode.equals("09")){	rspMsg = "권종불일치 (생년월일 비교)";		//권종변경응답코드
		}else if (rspCode.equals("10")){	rspMsg = "교통카드 발행사 ID 미등록";
		}else if (rspCode.equals("12")){	rspMsg = "환불불가 오류";
		}else if (rspCode.equals("51")){	rspMsg = "가맹점 ID 오류";
		}else if (rspCode.equals("52")){	rspMsg = "1회 최대 충전한도 초과";
		}else if (rspCode.equals("53")){	rspMsg = "반품기관 초과";
		}else if (rspCode.equals("54")){	rspMsg = "처리불가 거래유형 오류";
		}else if (rspCode.equals("55")){	rspMsg = "반품충전 금액 오류";
		}else if (rspCode.equals("56")){	rspMsg = "지불내역 미존재 오류";
		}else if (rspCode.equals("91")){	rspMsg = "기처리 오류";
		}else if (rspCode.equals("92")){	rspMsg = "대경 잔액";
		}else if (rspCode.equals("99")){	rspMsg = "기타 처리 불가";
		}else if (rspCode.equals("FF")){	rspMsg = "서명값 불일치";					//권종변경응답코드
		}else{	rspMsg = "알수 없는 응답코드 ";
		}
		return rspMsg;
	} 
}