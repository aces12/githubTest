package biz.cms_DGBIrt;

import java.util.HashMap;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class DGBIrtProtocol {
	private static Logger logger = Logger.getLogger(DGBIrtAction.class);
	
	public int getRcvDGBIrtDATA(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret = 0;
		int nlens[] = {2};
		
		String strHeaders[] = {
			"INQ_TYPE"		// INQ Type(INQ 종별)
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		ret = COMMBiz.getInqTypeCHG((String)hm.get("INQ_TYPE"));
		
		return ret;
	}
	
	// 캐시비에서 보낸 충전취소 결과 전송 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGCnclResultRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,2,2,10,10,10
					  ,16,8,16,8,6
					  ,10,8,23};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
								
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
								
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDEP",
			"NTEP",
			
			"IDCENTER",
			"ALGEP",
			"MLDA",
			"BALEP",
			"NT_CARDLSAM",
			
			"IDLSAM",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"SIGN2_VAL",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCnclResultRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// 캐시비에서 보낸 충전취소 실패 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGCnclFailRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,8,10,16,8,6
					  ,10,1,70};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
									
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
									
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
				
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDLSAM",
			"NT_CARDLSAM",
			
			"SIGN2_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"DEAL_RESULT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCnclFailRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 충전취소 완료 요청 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGCnclCompltedInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,8,6
					  ,10,8,20,10,10
					  ,10,1,10,4,16
					  ,10,2,2,10,10
					  ,16,10,10,8,16
					  ,8,6,10,8,6
					  ,1};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"ADJT_YMD",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDEP",
			
			"NTEP",
			"IDCENTER",
			"ALGEP",
			"MLDA",
			"NT_CARDLSAM",
			
			"IDLSAM",
			"NTSAM",
			"BALEP",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			"DEAL_SNO",
			"SIGN2_VAL",
			"EVT_CHRG_AMT",
			
			"DEAL_RESULT"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCnclCompltedInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// 캐시비에서 보낸 충전취소 요청 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGCancelRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
				  	  ,1,10,4,16,10
				  	  ,8,10,16,8,6
				  	  ,10,6,65};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
							
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
							
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDSAM",
			"NT_CARDLSAM",
			
			"SIGN2",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"EVT_CHRG_AMT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCancelRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 충전취소 요청 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGCancelInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,8,6
					  ,10,8,20,10,10
					  ,10,1,10,4,2
					  ,10,2,16,10,16
					  ,16,10,10,8,8
					  ,16,14,8};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"ADJT_YMD",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"ALGEP",
			
			"BALEP",
			"IDCENTER",
			"IDEP",
			"NTEP",
			"REP",
			
			"BEF_IDSAM",
			"BEF_MLDA",
			"BEF_NTEP",
			"SIGN1_VAL",
			"RFU",
			
			"L_MEMBER_NO",
			"ODEAL_CHRG_YMDHMS",
			"ODEAL_CHRG_SIGN2"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCancelInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 실시간 지불데이터 송신 전문 파싱
	public HashMap<String, String> getParseDGBChangeSnd(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,13,18,10,128
					 ,2,2,4,2,8
					 ,2,8,16,8,2
					 ,16,14,8};
		String strHeaders[] = {
			"INQ_TYPE"
			,"FCSTR_NO"
			,"DEAL_UNIQ_NO"
			,"TERMINAL_ID"
			,"CARD_NO"
			
			,"CVEP"
			,"ALGEP"
			,"PARAM_TYPE"
			,"OLD_CARD_HOLDER"
			,"BALEP"
			
			,"ID_CENTER"
			,"NTEP"
			,"REP"
			,"SIGN"
			,"NEW_CARD_HOLDER"
			
			,"RHOST"
			,"TRAN_YMD"
			,"BIRTH_YMD"
		};
		
		//logger.info( "▶ getParseCashBeeRTPaymentSnd-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseDGBChangeRcvRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1
				 ,4,16,8,8,4
			 	 ,4,14,3,	13,18
			 	 ,2,40,16,16,8
			 	 ,16,8
			 	 ,1};
		String strHeaders[] = {
			"STX",
//HEADER				
			"DATA_LEN",
			"DATA_CD",
			"SYS_SEND_CD",
			"SYS_RECV_CD",
			"TASK_CD",
			"JOB_CD",
			"SEND_DATE",
			"HEADER_REQ",
//BODY				                  			
			"FCSTR_NO",
			"DEAL_UNIQ_NO",
			"RES_CD",
			"RES_MSG",
			"CARD_NO",
			"IDHOST",
			"NTHOST",
			"EPV",
			"SIGN2"
			
			,"ETX"
		};
		
		logger.info( "▶ getParseDGBChangeRcvRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// UPAY 권종 변경 결과 요청 전문 파싱
	public HashMap<String, String> getParseDGBChangeCompletedInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,13,18,128,2,4};
		String strHeaders[] = {
			"INQ_TYPE",
			"FCSTR_NO",
			"DEAL_UNIQ_NO",
			"CARD_NO",
			"ID_CARD_HOLDER",
			
			"RESP_CD",
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCompletedInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// UPAY에서 보낸 환불 결과 응답 전문 파싱
	public HashMap<String, String> getParseDGBChangeResultRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1
					 ,4,16,8,8,4
			 	 	 ,4,14,3,	13,18
			 	 	 ,2,40
			 	 	 ,1};
		String strHeaders[] = {
			"STX",
//HEADER				
			"DATA_LEN",
			"DATA_CD",
			"SYS_SEND_CD",
			"SYS_RECV_CD",
			"TASK_CD",
			"JOB_CD",
			"SEND_DATE",
			"HEADER_REQ",
//BODY				        
			"FCSTR_NO",
			"DEAL_UNIQ_NO",
			"RES_CD",
			"RES_MSG"
			
			,"ETX"
		};
		
		//logger.info( "▶ getParseCashBeeRFNDResultRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// 캐시비에서 보낸 환불 실패 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeRFNDFailRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,8,10,16,8,6
					  ,10,1,70};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
							
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
							
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
				
			"PAY_FLAG",
			"RFND_FEE_AMT",
			"RFND_FEE_RATE",
			"IDLSAM",
			"NT_CARDLSAM",
			
			"SIGN2_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"DEAL_RESULT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeRFNDFailRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 충전/지불취소 요청 전문 파싱
	public HashMap<String, String> getParseDGBCHRGInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,18,13,10,8
					 ,2,2,128,2,4
					 ,2,2,2,8,8
					 ,2,8,16,16,16
					 ,8,8,2,8,8
					 ,8,16,8,14,2
					 ,18};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_UNIQ_NO",
			"FCSTR_NO", //길이 확인
			"TERMINAL_ID",
			"ADJT_YMD",
			
			"CARD_CORP_CD",
			"PROC_CD",
			"CARD_NO",
			"ID_CARD_HOLDER",
			"CARD_TP",
			
			"CVEP",
			"ALGEP",
			"VKDL_KEY",
			"BALEP",
			"MLDA",
			
			"IDCENTER",
			"NTEP",
			"REP",
			"RSAM",
			"SAM_ID",
			
			"NTSAM",
			"SIGN1",
			"BEF_TRT",
			"BEF_MLDA",
			"BEF_NTEP",
			
			"BEF_BALEP",
			"BEF_SAM_ID",
			"BEF_NT_SAM",
			"BEF_YMD",
			"RETURN_TP",
			
			"ORG_DEAL_UNIQ_NO"
		};
		logger.info( "▶ getParseDGBCHRGInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);		
		
		return hm;
	}
	
	// DGBUPAY에서 보낸 충전/지불취소 응답 전문 파싱
	public HashMap<String, String> getParseDGBCHRGRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1
					 ,4,16,8,8,4
			 	 	 ,4,14,3,	13,18
			 	 	 ,2,40,2,16,16
			 	 	 ,8,16,16,8,8
			 	 	 ,14,8
			 	 	 ,1};
		String strHeaders[] = {
			"STX",
//HEADER
			"DATA_LEN",
			"DATA_CD",
			"SYS_SEND_CD",
			"SYS_RECV_CD",
			"TASK_CD",
			"JOB_CD",
			"SEND_DATE",
			"HEADER_REQ",
//BODY				
			"FCSTR_NO",		//편의점ID
			"DEAL_UNIQ_NO",	//거래관리번호
			"RESP_CD",		//충전거래오류코드
			"RESP_MSG",		//오류코드메세지
			"CARD_CORP_CD",	//카드사코드
			"CARD_NO",		//CARD일련번호
			"SAM_ID",		//SAM일련번호
			"NTSAM",		//SAM거래카운트
			"HOST_NO",		//HOST일련번호
			"RHSM",			//HOST생성랜덤번호
			"BALEP",		//거래후잔액
			"NTLSAM",		//거래후카운터
			"TRAN_YMD",		//거래일시TIME
			"SIGN2"			//HSM SIGN값
			
			,"ETX"
		};
		//logger.info( "▶ getParseCashBeeCHKPPAMTRsp-" + rcvBuf );
		//hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
				
		return hm;
	}

	
	// POS에서 보낸 단말기 설치 요청 전문 파싱
	public HashMap<String, String> getParseDGBTMNLINSTALLInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,1,10,16,16};
		String strHeaders[] = {
			"INQ_TYPE",
			"JOB_TP",
			"TERMINAL_ID",
			"SAM_ID",
			
			"BEF_SAM_ID",
		};
		
		//logger.info( "▶ getParseCashBeeTMNLINSTALLInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);		
		
		return hm;
	}
	
	// DGBUPAY에서 보낸 단말기설치 응답 전문 파싱
	public HashMap<String, String> getParseDGBTMNLINSTALLRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1
					 ,4,16,8,8,4
				 	 ,4,14,3
				 	 ,1,10,16,16,40
				 	 ,20,10,10,10,2
				 	 ,40,13,1
				 	 };
	String strHeaders[] = {
			"STX",
//공통HEADER				
			"DATA_LEN",
			"DATA_CD",
			"SYS_SEND_CD",
			"SYS_RECV_CD",
			"TASK_CD",
			"JOB_CD",
			"SEND_DATE",
			"HEADER_REQ",
//DATA
			"JOB_TP",
			"TERMINAL_ID",
			"SAM_ID",
			"BEF_SAM_ID",
			"FCSTR_NM",
			"TEL_NO",
			"HQ_CORP_REG_NO",
			"FCSTR_CORP_REG_NO",
			"BEF_FCSTR_CORP_REG_NO",
			"RESP_CD",		//응답코드
			"RESP_MSG",		//응답메세지
			"FCSTR_NO"//DGB유페이 관리고유번호
			
			,"ETX"
	};
		logger.info("▶ getParseDGBTMNLINSTALLRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 예치금 확인 요청 전문 파싱
	public HashMap<String, String> getParseCashBeeCHKPPAMTInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,10,8,6,10
					  ,4,16,8,10,10
					  ,2};
		String strHeaders[] = {
			"INQ_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			"DEAL_SNO",
			
			"RES_CD",
			"RES_MSG",
			"ADJT_YMD",
			"BRANCH_NO",
			"RECHRGABLE_AMT",
			
			"RESULT"
		};
		
		//logger.info( "▶ getParseCashBeeCHKPPAMTInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseCashBeeCHKPPAMTRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,10,10,2,198};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_GB_CD",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
			
			"FILLER",
			"BRANCH_NO",
			"RECHRGABLE_AMT",
			"RESULT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHKPPAMTRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 충전/지불취소 완료 요청 전문 파싱
	public HashMap<String, String> getParseDGBCHRGCompletedInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,18,13,2,128
					 ,8,8,16,8,16
					 ,8,4,2};
		String strHeaders[] = {
			"INQ_TYPE"
			,"DEAL_UNIQ_NO"	
			,"FCSTR_NO"
			,"CARD_CORP_CD"
			,"CARD_NO"
			
			,"BALEP"
			,"NTEP"
			,"SAM_ID"
			,"NTSAM"
			,"RHSM"
			
			,"SIGN3"
			,"RESP_CD"
			,"PROC_CD"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCompletedInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// DGBUPAY에서 보낸 충전/지불취소 결과 응답 전문 파싱
	public HashMap<String, String> getParseDGBCHRGResultRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1
					 ,4,16,8,8,4
					 ,4,14,3,	13,18
			 	 	 ,2,40
			 	 	 ,1};
		String strHeaders[] = {
				"STX",
//HEADER				
				"DATA_LEN",
				"DATA_CD",
				"SYS_SEND_CD",
				"SYS_RECV_CD",
				"TASK_CD",
				"JOB_CD",
				"SEND_DATE",
				"HEADER_REQ",
			
				"FCSTR_NO",
				"DEAL_UNIQ_NO",
				"RESP_CD",
				"RESP_MSG"
				
				,"ETX"
		};
		//logger.info( "▶ getParseCashBeeCHRGResultRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// 캐시비에서 보낸 충전/지불취소 실패 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGFailRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,8,10,16,8,6
					  ,10,6,1,64};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
						
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
						
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
					
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDLSAM",
			"NT_CARDLSAM",
			
			"SIGN2_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"EVT_CHRG_AMT",
			"DEAL_RESULT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGFailRsp-" + rcvBuf );
		//hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
}