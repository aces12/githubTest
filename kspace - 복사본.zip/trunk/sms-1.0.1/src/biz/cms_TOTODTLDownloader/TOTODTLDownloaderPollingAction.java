package biz.cms_TOTODTLDownloader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.apache.log4j.Logger;

import biz.cms_TMoneySender.TMoneySenderDAO;
import biz.comm.SFTPManager;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

public class TOTODTLDownloaderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(TOTODTLDownloaderPollingAction.class);
	
	private String toto_ftp_ip = "";
	private int toto_ftp_port = 0;
	private String toto_ftp_id = "";
	private String toto_ftp_pwd = "";
	
	public final String TOTSELL_CD = "1219";
	
	public static void main(String args[]) throws Exception {
		TOTODTLDownloaderPollingAction action = new TOTODTLDownloaderPollingAction();
		if( args == null || args.length < 1 ) {
			logger.info("------ master main args null");
		}
		System.out.println("[DEBUG] [args[0]]=" + args[0] );
		
		String path          = nvl(args[0].replaceFirst("-path:"  ,""));
		String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));
		String fileNm		 = nvl(args[2].replaceFirst("-file:", ""));
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		
		if( cmd.length() != 2 ) return;
		
		if( cmd.charAt(0) == '1' ) {
			System.out.println("downloading file" );
			action.downloadSpecifiedFile(fileNm);
		}
		if( cmd.charAt(1) == '1' ) {
			System.out.println("inserting to DB" );
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "toto";
			
			TOTODTLDownloaderInst dailyInsert = new TOTODTLDownloaderInst(destPath, action);
			dailyInsert.start();
		}
	}
	
	private void downloadSpecifiedFile(String fileNM) {
		SFTPManager sFtpMgr = null;
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK = false;
		
		try {
			this.toto_ftp_ip = PropertyUtil.findProperty("communication-property", "TOTO_FTP_SERVER_IP");
			this.toto_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "TOTO_FTP_SERVER_PORT"));
			this.toto_ftp_id = PropertyUtil.findProperty("communication-property", "TOTO_FTP_SERVER_ID");
			this.toto_ftp_pwd = PropertyUtil.findProperty("communication-property", "TOTO_FTP_SERVER_PWD");
			
			sFtpMgr = new SFTPManager(toto_ftp_ip, toto_ftp_port, toto_ftp_id, toto_ftp_pwd);
			
			logger.info("Connected to " + toto_ftp_ip + ":" + toto_ftp_port);
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "toto";
			
			File destDir = new File(destPath);
			if( !destDir.exists() ) {
				destDir.mkdir();
			}
			
			isDownOK = false;
			
			String targetFileNM = fileNM + ".txt";
			iRetry = 0;
			try {
				bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + targetFileNM));
				
				while( iRetry < 2 ) {
					if( isDownOK = sFtpMgr.get(targetFileNM, bos)) {
						break;
					}
					iRetry++;
				}
			}catch(Exception e) {
				logger.info("[ERROR_1] Can't get file on FTP server");
			}
			if( bos != null ) {
				bos.flush();
				bos.close();
				bos = null;
			}
			System.gc();
			
			if( isDownOK ) {
				logger.info("[DEBUG] successfuly downloaded file [" + targetFileNM + "]");
			}else {
				File file = new File(destPath + File.separator + targetFileNM);
				if( !file.delete() ) {
					logger.info("[ERROR_2] Failed to delete empty file [" + targetFileNM + "]");
				}
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			if( bos != null ) {
				try {
					bos.close();
					bos = null;
				}catch(Exception e) {}
			}
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {}
		}
	}

	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		SFTPManager sFtpMgr = null;
		
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK = false;
		
		try {
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode != "1" ) return;
			
			this.toto_ftp_ip = PropertyUtil.findProperty("communication-property", "TOTO_FTP_SERVER_IP");
			this.toto_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "TOTO_FTP_SERVER_PORT"));
			this.toto_ftp_id = PropertyUtil.findProperty("communication-property", "TOTO_FTP_SERVER_ID");
			this.toto_ftp_pwd = PropertyUtil.findProperty("communication-property", "TOTO_FTP_SERVER_PWD");
			
			sFtpMgr = new SFTPManager(toto_ftp_ip, toto_ftp_port, toto_ftp_id, toto_ftp_pwd);
			
			logger.info("Connected to " + toto_ftp_ip + ":" + toto_ftp_port);
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "toto";
			
			File destDir = new File(destPath);
			if( !destDir.exists() ) {
				destDir.mkdir();
			}
			
			isDownOK = false;
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			calendar.add(Calendar.DATE, -1);
			String stdDate = sdf.format(calendar.getTime());
			
			String targetFileNM = TOTSELL_CD + "-" + stdDate + ".txt";
			iRetry = 0;
			try {
				bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + targetFileNM));
				
				while( iRetry < 2 ) {
					if( isDownOK = sFtpMgr.get(targetFileNM, bos)) {
						break;
					}
					iRetry++;
				}
			}catch(Exception e) {
				logger.info("[ERROR_1] Can't get file on FTP server");
				(new TOTODTLDownloaderDAO()).spSMSSEND("스포츠토토 " + targetFileNM + " 수신 실패", "cms_TOTODTLDownloader");
			}
			if( bos != null ) {
				bos.flush();
				bos.close();
				bos = null;
			}
			System.gc();
			
			if( isDownOK ) {
				logger.info("[DEBUG] successfuly downloaded file [" + targetFileNM + "]");
//				// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
//				if( sFtpMgr.rename(targetFileNM, targetFileNM.concat(".ok")) ) {
//					logger.info("[DEBUG] Succeeded to rename.");
//				}else {
//					logger.info("[DEBUG] Failed to rename.");
//				}
			}else {
				File file = new File(destPath + File.separator + targetFileNM);
				if( !file.delete() ) {
					logger.info("[ERROR_2] Failed to delete empty file [" + targetFileNM + "]");
				}
			}
			
			isDownOK = false;
			targetFileNM = TOTSELL_CD + "-" + stdDate + "-CNCL.txt";
			iRetry = 0;
			try {
				bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + targetFileNM));
							
				while( iRetry < 2 ) {
					if( isDownOK = sFtpMgr.get(targetFileNM, bos)) {
						break;
					}
					iRetry++;
				}
			}catch(Exception e) {
				logger.info("[ERROR_3] Can't get file on FTP server");
				(new TOTODTLDownloaderDAO()).spSMSSEND("스포츠토토 " + targetFileNM + " 수신 실패", "cms_TOTODTLDownloader");
			}
			if( bos != null ) {
				bos.flush();
				bos.close();
				bos = null;
			}
			System.gc();
			
			if( isDownOK ) {
				logger.info("[DEBUG] successfuly downloaded file [" + targetFileNM + "]");
//				// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
//				if( sFtpMgr.rename(targetFileNM, targetFileNM.concat(".ok")) ) {
//					logger.info("[DEBUG] Succeeded to rename.");
//				}else {
//					logger.info("[DEBUG] Failed to rename.");
//				}
			}else {
				File file = new File(destPath + File.separator + targetFileNM);
				if( !file.delete() ) {
					logger.info("[ERROR_4] Failed to delete empty file [" + targetFileNM + "]");
				}
			}
			
			// 파일 읽어서 DB Insert
			TOTODTLDownloaderInst dailyInsert = new TOTODTLDownloaderInst(destPath, this);
			dailyInsert.start();
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			if( bos != null ) {
				try {
					bos.close();
					bos = null;
				}catch(Exception e) {}
			}
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {}
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}

}
