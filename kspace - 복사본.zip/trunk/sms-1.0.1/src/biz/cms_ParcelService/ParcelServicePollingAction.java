package biz.cms_ParcelService;

import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

public class ParcelServicePollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(ParcelServicePollingAction.class);
	
	public ActionSocket actSock = null;
	
	public static void main(String args[]) throws Exception {
		ParcelServicePollingAction action = new ParcelServicePollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			String retMsg = "";
			retMsg = action.transfer();
			
			System.out.println("[Received Data]=" + retMsg);
		}catch(Exception e) {
			System.out.println("[Received Data]=" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		try {
			//if( actionMode == "0" ) {
				this.transfer();
			//}
		}catch(Exception e) {
			logger.info("", e);
		}
	}
	
	public String transfer() {
		ParcelServiceDAO dao = new ParcelServiceDAO();
		String dataMsg = "";
		String recvBuf = "";
		byte sendBytes[];
		String comCd = "";
		String ip = "";
		int port = 0;
		
		try {
			comCd = PropertyUtil.findProperty("stsys-property", "COM_CD");											// 회사코드
			ip = PropertyUtil.findProperty("communication-property", "CJPARCEL_COMM_IP");							// IP
			port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CJPARCEL_COMM_PORT"));		// PORT
			
			if( comCd.trim() == "" ) {
				comCd = "1002";
			}
			
			// 전송할 택배TRAN Item들을 가져온다.
			dataMsg = dao.procGETVALIDPACELITEM(comCd);
			
//			logger.info("SP Return : " + dataMsg);
			
			if( dataMsg.equals("No Data") )
			{
				return dataMsg;
			}
			
			actSock = new ActionSocket(new Socket(ip, port), (Filter)(new COMMConveyerFilter(COMMBiz.CJPARCEL_FILTER)));
			actSock.getSocket().setSoTimeout(5000);
			
			// 시작전문/완료전문에 사용되는 일련번호를 구한다
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmsss");
			String seqNum = sdf.format(calendar.getTime());
						
			sendBytes = makeStartOrEndReq("S", seqNum);
			
			logger.info("[sms>cj] SEND[" + sendBytes.length + "]:[ST][" + new String(sendBytes) + "]");
			
			/**
			 ** 1. 시작전문(1건) 송신
			 **/
			if( actSock.send(sendBytes, sendBytes.length) ) {
				logger.info("[sms>cj] SEND[" + sendBytes.length + "] OK");
			}else {
				logger.info("[sms>cj] SEND[" + sendBytes.length + "] ERROR");
	
				throw new Exception("CJ_Parcel server is no response");
			}
			
			// Data 전문을 바이트 배열로 변환
			sendBytes = dataMsg.getBytes();
			
			logger.info("[sms>cj] SEND[" + sendBytes.length + "]:[DT][" + dataMsg + "]");
			
			/**
			 ** 2. Data 전문(n건) 송신
			 **/
			if( actSock.send(sendBytes, sendBytes.length) ) {
				logger.info("[sms>cj] SEND[" + sendBytes.length + "] OK");
			}else {
				logger.info("[sms>cj] SEND[" + sendBytes.length + "] ERROR");
	
				throw new Exception("CJ_Parcel server is no response");
			}
			
			sendBytes = null;
			
			sendBytes = makeStartOrEndReq("E", seqNum);
			
			logger.info("[sms>cj] SEND[" + sendBytes.length + "]:[ED][" + new String(sendBytes) + "]");
			
			/**
			 ** 3. 완료 전문(1건) 송신
			 **/
			if( actSock.send(sendBytes, sendBytes.length) ) {
				logger.info("[sms>cj] SEND[" + sendBytes.length + "] OK");
			}else {
				logger.info("[sms>cj] SEND[" + sendBytes.length + "] ERROR");
	
				throw new Exception("CJ_Parcel server is no response");
			}
			
			// 완료 전문에 대한 응답
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<cj] RECV[" + recvBuf.getBytes().length + "]::[" + recvBuf + "]");
		}catch(Exception e) {
			logger.info("", e);
		}finally {
			if( actSock != null ) {
				actSock.close();
				actSock = null;
			}
		}
		
		return recvBuf;
	}
	
	private byte[] makeStartOrEndReq(String pckTp, String seqNum) {
		byte[] tempBytes;
		byte[] sendBytes;
		
		// 시작전문 문자열 부분 생성
		StringBuffer sb = new StringBuffer();
		sb.append(pckTp);			// Packet구분자(1)
		sb.append(seqNum);			// 일련번호(YYYYMMDDHHMMSSS)(15)
		sb.append("1");				// 서비스번호(1)
		sb.append("  ");				// 요청응답구분(2)
		
		// 시작 전문 문자열을 바이트 배열로 변환
		tempBytes = (sb.toString()).getBytes();
		
		// 시작 전문 문자열과 종료문자를 담을 바이트 배열 생성
		sendBytes = new byte[tempBytes.length + 1];
		
		// 전송할 바이트 배열에 바이트 배열로 변환된 시작전문 문자열 부분 copy
		System.arraycopy(tempBytes, 0, sendBytes, 0, tempBytes.length);
		
		sendBytes[sendBytes.length - 1] = 0x0d;
		
		return sendBytes;
	}
}
