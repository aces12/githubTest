
///////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////SFTP 일경우////////////////////////////////////////////// 
///////////////////////////////////////////////////////////////////////////////////////////////////////
package biz.cms_GTFDTLDownloader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;
import biz.comm.SFTPManager;

/*
 * to do  
 * 1.  FTP 다운로드 루틴 확인 할것 
 * 2 . 파싱 후 db저장 정상 확인 OK 
 * 
 * 
 * 
 * */
/** 
 * GTFDTLDownloaderPollingAction
 * GTF global TAX Free 일별승인내역 수신			 * BTDTLDownloaderPollingAction  * 바통(다날) 일별승인내역 수신
 * @created  on 1.0,  11/03/17
 * @created  by khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by 
 */ 
public class GTFDTLDownloaderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(GTFDTLDownloaderPollingAction.class);
	
	private String gtf_ftp_ip = "";
	private int gtf_ftp_port = 0;
	private String gtf_ftp_id = "";
	private String gtf_ftp_pwd = "";
	
	public static void main(String args[]) throws Exception {	
		GTFDTLDownloaderPollingAction action = new GTFDTLDownloaderPollingAction();
		if (args == null || args.length < 1) {
			logger.info("------ master main args null");
		}
		logger.info("[DEBUG] [args[0]]=" + args[0] );
		
		String path          = nvl(args[0].replaceFirst("-path:"  ,""));
		String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));

		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		
		if( cmd.length() != 2 ) return;
		
		if( cmd.charAt(0) == '1' ) {
			System.out.println("downloading file + inserting DB" );
			action.execute("1");
		}
		if( cmd.charAt(1) == '1' ) {
			System.out.println("inserting DB" );
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "gtf";
			GTFDTLDownloaderInst dailyInsert = new GTFDTLDownloaderInst(destPath);
			dailyInsert.start();
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(String actionMode) {
		SFTPManager sFtpMgr = null;
		
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK = false;
		
		try {
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode != "1" ) return;

			this.gtf_ftp_ip = PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_IP");
			this.gtf_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_PORT"));
			this.gtf_ftp_id = PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_ID");
			this.gtf_ftp_pwd = PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_PWD");	
			
			try{				
				sFtpMgr = new SFTPManager(gtf_ftp_ip, gtf_ftp_port, gtf_ftp_id, gtf_ftp_pwd);	
				logger.info("TRY Connected to " + gtf_ftp_ip + ":" + gtf_ftp_port);
			}catch(Exception e){
				logger.info("exception occur"+e.getMessage());
				logger.info(" SFTP Connect fail exception occur ");
				return;
			}					
			logger.info(" SFTP Connection is Success ");						
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "gtf";//"cashgate";
			
			File destDir = new File(destPath);
			
			if( !destDir.exists() ) {
				destDir.mkdir();
				logger.info("[DEBUG] Try to make dir" );
			}
			isDownOK = false;

			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

			calendar.setTime(new Date());
			calendar.add(Calendar.DATE, -1);
			String stdDate = sdf.format(calendar.getTime());
			
			String targetFileNm = "GLOBAL_TAX_FREE_WITHME_" + stdDate + ".dat";
									
			iRetry = 0;			
			bos = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + targetFileNm));
			
			while( iRetry < 2 ) {				
				if( isDownOK = sFtpMgr.get(targetFileNm, bos)) {		
					break;
				}
				iRetry++;
			}
			bos.flush();
			bos.close();
			bos = null;
			System.gc();
			
			if( isDownOK ) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm + "]");
				// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
				if( sFtpMgr.rename(targetFileNm, targetFileNm.concat(".ok")) ) {
					logger.info("[DEBUG] Succeeded to rename.");
				}else {
					logger.info("[DEBUG] Failed to rename.");	
				}
			}else {
				logger.info("[ERROR4] Can't get " + targetFileNm + " from FTP server");
									
				File file = new File(destPath + File.separator + targetFileNm);
				if( !file.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm + "]");
				}				
				logger.info("[ERROR2] Can't get file on FTP server");
			}		
			// 파일 읽어서 DB Insert
			GTFDTLDownloaderInst dailyInsert = new GTFDTLDownloaderInst(destPath);
			dailyInsert.start();				

		}catch(Exception e) {
			logger.info(e.getMessage());					
		}finally {
			if( bos != null ) {
				try {
					bos.close();
					bos = null;
				}catch(Exception e) {}
			}
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {
			}
		}
	}
	
	
}







///////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////FTP 일경우////////////////////////////////////////////// 
///////////////////////////////////////////////////////////////////////////////////////////////////////
//package biz.cms_GTFDTLDownloader;
//
//import java.io.BufferedOutputStream;
//import java.io.File;
//import java.io.FileOutputStream;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//import java.util.Date;
//import java.util.GregorianCalendar;
//import java.util.Locale;
//
//import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
//import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
//import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
//
//import org.apache.log4j.Logger;
//import org.apache.commons.net.ftp.FTP;
//import org.apache.commons.net.ftp.FTPClient;
//import org.apache.commons.net.ftp.FTPReply;
///*
// * to do  
// * 1.  FTP 다운로드 루틴 확인 할것 
// * 2 . 파싱 후 db저장 정상 확인 OK 
// * 
// * 
// * 
// * */
///** 
// * GTFDTLDownloaderPollingAction
// * GTF global TAX Free 일별승인내역 수신
// * @created  on 1.0,  11/03/17
// * @created  by khk(FUJITSU KOREA LTD.) 
// *  
// * @modified on 
// * @modified by ok
// * @caused   by 
// */ 
//
//
//public class GTFDTLDownloaderPollingAction extends PollingAction {
//	private static Logger logger = Logger.getLogger(GTFDTLDownloaderPollingAction.class);
//	
//	private String gtf_ftp_ip = "";
//	private int gtf_ftp_port = 0;
//	private String gtf_ftp_id = "";
//	private String gtf_ftp_pwd = "";
//	
//	public static void main(String args[]) throws Exception {
//		GTFDTLDownloaderPollingAction action = new GTFDTLDownloaderPollingAction();
//		if (args == null || args.length < 1) {
//			logger.info("------ master main args null");
//		}
//		logger.info("[DEBUG] [args[0]]=" + args[0] );
//		
//		String path          = nvl(args[0].replaceFirst("-path:"  ,""));
//		
//		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
//		
//		action.execute("1");
//	}
//	
//	private static String nvl(String param) {
//		return param != null ? param: "";
//	}
//	
//	public void execute(String actionMode) {
//		FTPClient client = null;
//		BufferedOutputStream bos = null;
//		String basePath = "";
//		String destPath = "";
///*neo0531*/		logger.info("[DEBUG] GTFDTLDownloaderPollingAction execute start" );
//		try {
//			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
//			if( actionMode != "1" ) return;
//			
//			this.gtf_ftp_ip = PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_IP");
//			this.gtf_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_PORT"));
//			this.gtf_ftp_id = PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_ID");
//			this.gtf_ftp_pwd = PropertyUtil.findProperty("communication-property", "GTF_FTP_SERVER_PWD");
//			
//			client = new FTPClient();
//			client.setControlEncoding("euc-kr");
//			
///*neo0531*/		logger.info("[DEBUG] FTPClient" );			
///*neo0531 for test*/ this.gtf_ftp_ip = "192.168.11.106";//"10.149.206.254";			
///*neo0531 for test*/ this.gtf_ftp_port = 1500;
//			client.connect(this.gtf_ftp_ip, this.gtf_ftp_port);
//			
///*neo0531*/		logger.info("[DEBUG] client.connect" );
//			
//			int resultCode = client.getReplyCode();
//			if( !FTPReply.isPositiveCompletion(resultCode) ) {
//				logger.info("[ERROR1] Can't connect on FTP server");
//				throw new Exception();
//			}else {
//				client.setSoTimeout(5000);
//				boolean isLogin = false;
//				isLogin = client.login(this.gtf_ftp_id, this.gtf_ftp_pwd);
//				if( !isLogin ) {
//					logger.info("[ERROR2] Can't login on FTP server");
//					/*neo0531*/		logger.info("[DEBUG] Can't login" );
//					throw new Exception();
//				}
//				
//				client.setFileType(FTP.BINARY_FILE_TYPE);
//				client.enterLocalPassiveMode();
//				
//				basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
///*neo0531 for test*/ basePath = "C:\\HOME\\workspace" 	;			
//				destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "gtf";//"cashgate";
//				
//				File destDir = new File(destPath);
//				
//				if( !destDir.exists() ) {
//					destDir.mkdir();
//					/*neo0531*/		logger.info("[DEBUG] Can't login" );
//				}
//				
//				boolean isDownOK = false;
//
//				boolean isMonthClose = false;
//				Calendar calendar = new GregorianCalendar(Locale.KOREA);
//				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//				String todayDate = sdf.format(calendar.getTime());
//				if( (todayDate.substring(6, 8)).equals("01") ) {
//					isMonthClose = true;
//				}
//				calendar.setTime(new Date());
//				calendar.add(Calendar.DATE, -1);
//				String closeDate = sdf.format(calendar.getTime());
//				
//				String targetFileNm = "GLOBAL_TAX_FREE_WITHME_" + closeDate + ".DAT";//String targetFileNm = "cashgate_" + closeDate + "_D.txt";
//				//String tragetMonthlyFileNm = "gtf_" + closeDate + "_M.txt";//String tragetMonthlyFileNm = "cashgate_" + closeDate + "_M.txt";
//				
//				int iRetry = 0;
//				
//				bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + targetFileNm));
//				while( iRetry < 2 ) {
//					if( isDownOK = client.retrieveFile(targetFileNm, bos) ) {
//						break;
//					}
//					iRetry++;
//				}
//				bos.flush();
//				bos.close();
//				bos = null;
//				System.gc();
//				
//				if( isDownOK ) {
//					logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm + "]");
//					// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
//					if( client.rename(targetFileNm, targetFileNm.concat(".ok")) ) {
//						logger.info("[DEBUG] Succeeded to rename.");
//					}else {
//						logger.info("[DEBUG] Failed to rename.");
//						
//						/*neo0531*/		logger.info("[DEBUG] Can't login" );
//					}
//				}else {
//					logger.info("[ERROR4] Can't get " + targetFileNm + " from FTP server");
//					/*neo0531*/		logger.info("[DEBUG] Can't login" );					
//					File file = new File(destPath + File.separator + targetFileNm);
//					if( !file.delete() ) {
//						logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm + "]");
//					}
//				}
//				
//				/*if( isMonthClose ) {
//					bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + tragetMonthlyFileNm));
//					while( iRetry < 2 ) {
//						if( isDownOK = client.retrieveFile(tragetMonthlyFileNm, bos) ) {
//							break;
//						}
//						iRetry++;
//					}
//					bos.flush();
//					bos.close();
//					bos = null;
//					System.gc();
//					
//					if( isDownOK ) {
//						logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + tragetMonthlyFileNm + "]");
//						// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
//						if( client.rename(tragetMonthlyFileNm, tragetMonthlyFileNm.concat(".ok")) ) {
//							logger.info("[DEBUG] Succeeded to rename.");
//						}else {
//							logger.info("[DEBUG] Failed to rename.");
//						}
//					}else {
//						logger.info("[ERROR4] Can't get " + tragetMonthlyFileNm + " from FTP server");
//						File file = new File(destPath + File.separator + tragetMonthlyFileNm);
//						if( !file.delete() ) {
//							logger.info("[ERROR4-1] Failed to delete empty file [" + tragetMonthlyFileNm + "]");
//						}
//					}
//				}	*/			
//				
//				// 파일 읽어서 DB Insert
//				GTFDTLDownloaderInst dailyInsert = new GTFDTLDownloaderInst(destPath);
//				dailyInsert.start();				
//				
//				client.logout();
//			}
//		}catch(Exception e) {
//			logger.info(e.getMessage());
//			/*neo0531*/		logger.info("[DEBUG] Exception occur="+e.getMessage() );			
//		}finally {
//			if( bos != null ) {
//				try {
//					bos.close();
//				}catch(Exception e) {}
//			}
//			if( client != null && client.isConnected() ) {
//				try {
//					client.disconnect();
//				}catch(Exception e) {}
//			}
//		}
//	}
//}












