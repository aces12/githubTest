package biz.cms_GTFDTLDownloader;

import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class GTFDTLDownloaderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(GTFDTLDownloaderPollingAction.class);
	
	
	public int insGTFDailyDTL(Map<String, String> map) {
		SqlWrapper sql = new SqlWrapper();
		String sqlDbg = "";
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();			
			//DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("service-sql", "INS_TAXFREEVENDAILY_TRN"));
			
			sql.setString(++i, map.get("SER_COM_CD"));
			sql.setString(++i, map.get("MCH_SEND_UNIQ_NO"));
			sql.setString(++i, map.get("BUY_SERIAL_NUM"));		
			sql.setString(++i, map.get("ETC_REG_DATE"));
			sql.setString(++i, map.get("ETC_REG_TIME"));
			
			sql.setString(++i, map.get("STORE_CODE"));
			sql.setString(++i, map.get("SALE_DATE"));
			sql.setString(++i, map.get("POSNO"));
			sql.setString(++i, map.get("TRAN_NO"));
			sql.setString(++i, map.get("RETAMT"));
			
			sql.setString(++i, map.get("VEN_VAT_AMT"));			
			sql.setString(++i, map.get("TAX_FREE_AMT"));			
			sql.setString(++i, map.get("EXPORT_APPROVAL_NUM"));
			sql.setString(++i, map.get("PAYMENT_TYPE"));
			sql.setString(++i, map.get("SPECIAL_GUBUN"));

			sql.setString(++i, map.get("CNCL_CHK"));
			sql.setString(++i, map.get("REFUND_DATE"));  // 2016.11.25 환급일 추가 - OHT
			
//			sql.setString(++i, map.get("REG_DATE"));
//			sql.setString(++i, map.get("REG_DTM"));	
//			sql.setString(++i, map.get("MOD_DATE"));
//			sql.setString(++i, map.get("MOD_TIME"));
					
			
			sqlDbg = sql.debug();						
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			logger.info("[SQL1][INS_TAXFREEVENDAILY_TRN]" + sqlDbg );
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			System.out.println("[ERROR1] " + e.getMessage());
		}finally {
			//transaction 종료
			end();
			logger.info("[Data Insert well done]");
		}
		
		return rows;
	}
	
	
	
	
}


/*public int insCGDailyDTL(Map<String, String> map) {
	SqlWrapper sql = new SqlWrapper();
	int i = 0;
	int rows = -1;
	
	try {
		//transaction 발생
		begin();
		
		//DB Connection(DB 접속)
		connect("CMGNS");
		
		sql.put(findQuery("service-sql", "INS_CGVENDAILYAPPR_TRN"));
		sql.setString(++i, (String)map.get("CO_CD"));
		sql.setString(++i, (String)map.get("ADJT_DT"));
		sql.setString(++i, "A16" + (String)map.get("STORE_CD"));
		sql.setString(++i, (String)map.get("APPR_NO"));
		sql.setString(++i, (String)map.get("NOR_CNCL_TP"));
		sql.setString(++i, (String)map.get("APPR_ELECDOC_UNQ_ID"));
		sql.setString(++i, (String)map.get("CNCL_ELECDOC_UNQ_ID"));
		sql.setString(++i, (String)map.get("GDS_BARCD_NO"));
		sql.setString(++i, (String)map.get("AMT"));
		sql.setString(++i, (String)map.get("APPR_DTM"));
		sql.setString(++i, (String)map.get("CNCL_DTM"));
		
		logger.info("[SQL1][INS_CGVENDAILYAPPR_TRN]" + sql.debug() );
								
		rows = executeUpdate(sql);
		
	}catch(Exception e) {
		rollback();
		logger.info("[ERROR1] " + e.getMessage());
	}finally {
		//transaction 종료
		end();
	}
	
	return rows;
}*/





		
		
		
		
