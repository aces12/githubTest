package biz.cms_GTFDTLDownloader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.HashMap;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import org.apache.log4j.Logger;

public class GTFDTLDownloaderInst extends Thread {
	private static Logger logger = Logger.getLogger(GTFDTLDownloaderPollingAction.class);
	
	String path = "";
	
	public GTFDTLDownloaderInst(String path) {
		this.path = path;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
	public void deleteFile(String path, String fileNM) {
		File file = new File(path + File.separator + fileNM);
		if( file.exists() ) {
			logger.info("File Name : " + path + File.separator + fileNM);
			if( file.delete() ) {
				logger.info("File(" + path + File.separator + fileNM + ") removed !!!");
			}
		}
	}
	
	public void copyFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdirs();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(orgFile);
			fos = new FileOutputStream(destFile);
			
			int data = 0;
			while( (data = fis.read()) != -1 ) {
				fos.write(data);
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			try {
				fis.close();
				fis = null;
				fos.flush();
				fos.close();
				fos = null;
				System.gc();
			}catch(Exception e) {
				logger.info(e.getMessage());
			}
		}
		
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public void run() {
		int ret = 0;
		BufferedReader bin = null;
		StringTokenizer st = null;
		String readedLine = "";
		try {			
			GTFDTLDownloaderDAO dao = new GTFDTLDownloaderDAO();

			logger.info(">>>>>>> path = " + path);
			List<File> list = getDirFileList(path);
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			for(int i = 0;i < list.size();i++ ) {
				if( !(list.get(i)).isFile() ) {
					continue;
				}
				String targetFile = list.get(i).getName();
				bin = new BufferedReader(new FileReader(path + File.separator + targetFile));
				
				/*logger.info(">>>>>>>>> daily = " + targetFile.substring(18, 19));				
				if( targetFile.substring(18, 19).equals("D") ) {
					bIsDaily = true;
				}else if( targetFile.substring(18, 19).equals("M") ) {
					bIsDaily = false;
				}*/
				while( (readedLine = bin.readLine()) != null ) {
					logger.info("[DEBUG] File Name : " + targetFile + ", readedLine = " + readedLine);
					// '\t'와'\n' 구분자로 토큰 분리
					st = new StringTokenizer(readedLine, "\t\n");
					
					int col = 0;
					Map<String, String> map = new HashMap<String, String>();

					String strHeaders[] = {
						"SER_COM_CD",						//1.회사코드(위드미:1002)
						"MCH_SEND_UNIQ_NO",					//2.Global tax free 전송 고유번호
						"BUY_SERIAL_NUM",					//3.환급창구사업자코드(2) +매장ID + 난수(5)+연도(2)+시퀀스넘버(6)
						"ETC_REG_DATE",						//4.위드미에서 받고 Global tax free 시스템에 등록한 일자						
						"ETC_REG_TIME",						//5.위드미에서 받고 Global tax free 시스템에 등록한 시간											
						
						"STORE_CODE",						//6.점코드 (위드미점코드) ex:00999						
						"SALE_DATE",						//7.영업일자(판매일자)
						"POSNO",							//8.위드미에서 받은 포스번호 (ex:0001)
						"TRAN_NO",							//9.위드미에서 받은 거래번호						
						"RETAMT",							//10.거래금액
						
						"VEN_VAT_AMT",						//11.업체수수료 (Global tax free 수수료						
						"TAX_FREE_AMT",						//12.외국인환급금액 (외국인이 환급받는 금액)											
						"EXPORT_APPROVAL_NUM",				//13.반출승인번호 						
						"PAYMENT_TYPE",						//14.결제유형 (카드:1, 현금:2)
						"SPECIAL_GUBUN",					//15.즉시/사후구분 (즉시환급:1, 사후:2)

						"CNCL_CHK",							//16. 취소확인 (승인:Y, 취소:N)
						"REFUND_DATE",						//17. 환급일 2016.11.25 환급일 추가 - OHT
//						"REG_DATE",							//18.위드미시스템 등록일자
//						"REG_DTM",							//19.위드미시스템 등록시간
//						"MOD_DATE",							//20.위드미시스템 수정일자						
//						"MOD_TIME"							//21.위드미시스템 수정시간
						
					};
					// 각 분리된 토큰을 저장
					while( st.hasMoreTokens() ) {
						map.put(strHeaders[col++], st.nextToken());
						logger.info("☆  value[" + Integer.toString(col-1) + "] = " + map.get(strHeaders[col-1]));							
					}
					ret = dao.insGTFDailyDTL(map);

					if( ret != 1 ) {
						logger.info("["+targetFile.substring(18, 19)+"]"+"There is an Error on inserting data");
					}					
				}
				bin.close();
				bin = null;
				this.moveFile(path, targetFile, path + File.separator + "backup");
				logger.info("Data insert OK.  FTP work well done");
			}										
		}catch(Exception e) {
			logger.info("[ERROR1] " + e.getMessage());
		}finally {
			try {
				if( bin != null ) bin.close();
			}catch(Exception e) {}
		}
	}
	
	

	
	
	
	
	
	
	
	
}