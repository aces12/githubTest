package biz.cms_WineIrt;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.regex.Pattern;

import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class WineIrtProtocol {
	
	/***
	 * getRcvEConIrtDATA
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	
	public String getRcvEConIrtDATA(String rcvBuf){		
		HashMap<String, String> hm = new HashMap<String, String>();
		 
		logger.info("EConIrtDATA::rcvBuf::["+rcvBuf+"]"); 
		
		int nlens[]= {2};
		String strHeaders[] = { "INQ_TYPE" };		
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		logger.info("EConIrtDATA::hm::["+hm+"]");
		
		return (String)hm.get("INQ_TYPE");
	}
	
	
	private static Logger logger = Logger.getLogger(WineIrtAction.class);
	//20181017 wine
	public HashMap<String, String> getParseWineReq(String rcvBuf){
		
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {  
			20, 178
		};
		
		String strHeaders[] = {
			"WINE_CODE"			, // 신고구분
			"FILLER"			  // 필러
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	

	
}