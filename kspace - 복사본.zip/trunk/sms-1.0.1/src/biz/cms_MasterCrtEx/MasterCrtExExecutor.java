package biz.cms_MasterCrtEx;

import java.io.File;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

import org.apache.log4j.Logger;

import biz.cms_MasterAgentEx.MasterAgentExPollingAction;
import biz.cms_MasterCrt.MasterCrtDAO;

/** 
 * MasterCrtExExecutor
 * A class to actually generate files(실제로 파일을 생성하는 클래스)
 * It generates master files (TBL), and compresses the generated files(Zip) to make a Zip file on FTP File Serve Path(마스터 파일(TBL)을 만들고, 만든 파일을 압축(ZIP)하여 FTP파일 서버 경로에 압축파일을 만든다).  
 * @created  on 1.0,  11/03/17
 * @created  khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by  
 */ 
public class MasterCrtExExecutor {
	private static Logger logger = Logger.getLogger(MasterAgentExPollingAction.class);
	
	/**
	 * runMst - Generate Master File(마스터 파일 생성)
	 * @param m : Values to Generate Master File(마스터파일을 생성하기 위한 값)
	 * m[0] = trans_ymd
	 * m[1] = store_cd
	 * m[2] = trans_id
	 * m[3] = trans_seq
	 * m[4] = urgent_yn
	 * @return String : Directory in which master file has been generated(마스터파일이 생성된 디렉토리)
	 * @throws Exception
	 */
	public String runMst(Map<String, String> map) throws Exception {
		String basePath = PropertyUtil.findProperty("stsys-property", "FILECRT_ROOT");	// 파일 생성 루트
		String addPath = "";
		if(((String)map.get("urgent_yn")).equals("0")) {
			addPath = "deploy";
		}else if(((String)map.get("urgent_yn")).equals("1")) {
			addPath = "urgent1";
		}else if(((String)map.get("urgent_yn")).equals("2")) {
			addPath = "urgent2";
		}
		String rootPath = basePath+File.separator+(String)map.get("trans_id")+File.separator+(String)map.get("com_cd")+"_"+(String)map.get("store_cd");
		String destPath = "";
		String tblPath = "";
		
		String pdaDestPath = basePath+File.separator+"PDA"+File.separator+"MST"+File.separator+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+File.separator+"deploy";
		String pdaPath = basePath+File.separator+"PDA"+File.separator+"MST"+File.separator+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+File.separator+"deploy"+File.separator+"TBL";
		String zipName = (String)map.get("com_cd")+"_"+(String)map.get("store_cd")+".zip";	// POS Code(점코드)
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		List<Object> list = null;
		String conditionTP;
		String useYN;
		boolean bSrcDelete = false;
		String rtnData = "ERROR";
		
		try {
			// 정기마스터/긴급마스터 구분
			String flag = (String)map.get("urgent_yn");
			
			// 정기배신
			if( flag.equals("0") ) {
				destPath = rootPath+File.separator+addPath+File.separator+map.get("trans_ymd");	// Path to which zipFile will be generated(zipFile을 만들 경로)
				tblPath = basePath+File.separator+(String)map.get("trans_id")+File.separator+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+File.separator+addPath+File.separator+map.get("trans_ymd")+File.separator+"TBL";
				
				bSrcDelete = false;
				
				// 마스터그룹코드 목록 조회
				List<Object> listMSTGRPSETT = null;
				Map<String, String> mapMSTGRPLIST = null;
				Map<String, String> mapMSTGRPSETT = null;
				list = dao.selMSTGRPLIST((String)map.get("COM_CD"));
				for(int i = 0;i < list.size();i++) {					
					mapMSTGRPLIST = (Map<String, String>)list.get(i);
					
//					logger.info("★☆★Master Group Code : " + (String)mapMSTGRPLIST.get("MST_GRP_CD") + "★☆★");
					
					// 해당 마스터그룹코드의 배포 옵션 조회
					listMSTGRPSETT = dao.selMSTGRPSETT((String)map.get("COM_CD"), (String)mapMSTGRPLIST.get("MST_GRP_CD"));
					mapMSTGRPSETT = (Map<String, String>)listMSTGRPSETT.get(0);					
					
					conditionTP = (String)mapMSTGRPSETT.get("CONDITION_TP");		// 배신생성조건구분<F205>
					useYN = (String)mapMSTGRPSETT.get("USE_YN");					// 사용여부<C101>
					
					// 마스터그룹에 속한 테이블들의 이름을 가져와서  ArrayList에 Method 타입으로 추가한다.
					List<Object> listMSTGRPTBL = null;
					Map<String, String> mapMSTGRPTBL = null;
					listMSTGRPTBL = dao.selTBLBELONGTOMSTGRP(
							(String)map.get("COM_CD")
							, (String)mapMSTGRPLIST.get("MST_GRP_CD"));
					List<Method> methodArray = new ArrayList<Method>();
					for(int j = 0;j < listMSTGRPTBL.size();j++) {
						mapMSTGRPTBL = (Map<String, String>)listMSTGRPTBL.get(j);
						methodArray.add(((Object)this).getClass()
								.getDeclaredMethod("generate"+(String)mapMSTGRPTBL.get("TBL_NM")
										, Map.class, String.class));
//						logger.info("★☆★Table - " + "generate"+(String)mapMSTGRPTBL.get("TBL_NM") + "★☆★");
					}
					
					// 사용여부가 '사용'(useYN=1)이고 배신생성조건구분이 '미생성'(conditionTP=2)이 아니라면
					if( useYN.equals("1") ) {		
						if( conditionTP.equals("0") ) {			// 전체 생성(변경이 되었든 안되었든 무조건 생성)
//							logger.info("Master Group Code(" + (String)mapMSTGRPLIST.get("MST_GRP_CD") + ") must be created unconditionally ");
							for(int k = 0;k < methodArray.size();k++) {
								((Method)(methodArray.get(k))).invoke((Object)this, map, tblPath);		
//								logger.info("★☆★Called " + "generate"+(String)mapMSTGRPTBL.get("TBL_NM") + "★☆★");
							}
						}else if( conditionTP.equals("1") ) {	// 변경분 생성(변경 되었을 경우 생성)
//							logger.info("Master Group Code(" + (String)mapMSTGRPLIST.get("MST_GRP_CD") + ") is created when data is changed ");
							List<Object> chgList = dao.selMSTGRPCHG((String)map.get("COM_CD")
									, (String)map.get("STORE_CD")
									, (String)mapMSTGRPLIST.get("MST_GRP_CD"));
							
							if( chgList.size() > 0 ) {
								Map<String, String> chgMap = (Map<String, String>)chgList.get(0);
								String chgDT = (String)chgMap.get("CHG_DT");
								// 어제 이후로 변경된 건이라면 마스터 생성
								if( IsMSTGRPChanged(chgDT, -1) ) {
									for(int k = 0;k < methodArray.size();k++) {
										((Method)(methodArray.get(k))).invoke((Object)this, map, tblPath);
//										logger.info("★☆★Called " + "generate"+(String)mapMSTGRPTBL.get("TBL_NM") + "★☆★");
									}
								}
							}else {
								logger.info("Master Group Code(" + (String)mapMSTGRPLIST.get("MST_GRP_CD") + ") was not changed");
							}
						}
					}
				}
				// PDA 마스터 생성
				generateSTBDM130AT_PDA(map, pdaPath);
				ZipUtil.createZip(pdaDestPath, pdaPath, zipName, true);
			// 긴급  전체(마스터그룹 전체) or 긴급 변경(변경된 row)
			}else if(flag.equals("1") || flag.equals("2")) {	
				destPath = rootPath+File.separator+addPath;	// Path to which zipFile will be generated(zipFile을 만들 경로)
				tblPath = basePath+File.separator+(String)map.get("trans_id")+File.separator+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+File.separator+addPath+File.separator+"TBL";
				
				bSrcDelete = true;
				list = dao.selUGTMSTGRPALL((String)map.get("COM_CD"), (String)map.get("TRANS_YMD"), (String)map.get("STORE_CD"), flag, (String)map.get("TRANS_VER"));
				
				logger.info("list.size()=" + Integer.toString(list.size()));
				
				for(int i = 0;i < list.size();i++) {
					// 상품 마스터 그룹은 변경된row만 생성, 나머지 마스터 그룹은 긴급 전체와 똑같이 생성함
					Map<String, String> m = (Map<String, String>)list.get(i);
					String tblNM = (String)m.get("TBL_NM");
						
					Object obj = this;
					Method method = obj.getClass().getDeclaredMethod("generate"+tblNM, Map.class, String.class);
					logger.info("Called Method [generate"+tblNM+"()]");
					method.invoke(obj, map, tblPath);
				}
			}
			
			ZipUtil.createZip(destPath, tblPath, zipName, bSrcDelete);
			logger.info("[comcd : "+(String)map.get("com_cd")+"][storecd : "+(String)map.get("store_cd")+"] ZIP Filename : "+zipName+" is created.");
			
			rtnData = destPath + File.separator + zipName;
			
			logger.info("path="+rtnData);
			
			// 마스터 디렉토리는 3일치만 가져가고 3일 이전의 디렉토리는 삭제한다.
			cleanUpDirectory(rootPath+File.separator+addPath);
		}catch (Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return rtnData;
	}
	
	private void cleanUpDirectory(String destPath) {
		ArrayList<String> dir;
		int iTotalDirNum = 0;
		
		try {
			dir = getDirList(destPath);
			
			iTotalDirNum = dir.size();
			if( iTotalDirNum < 4 ) return;
			
			String[] dirName = dir.toArray(new String[iTotalDirNum]);
			
			// 디렉토리명으로 오름차순 정렬
			Arrays.sort(dirName);
				
			for(int i = 0;iTotalDirNum > 3;i++ ) {
				ZipUtil.deleteDir(destPath+File.separator+dirName[i]);
				iTotalDirNum--;
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	public ArrayList<String> getDirList(String dirPath) {
		ArrayList<String> dirList = new ArrayList<String>();
		List<File> tmpList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();

			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isDirectory() && tmpList.get(i).getName().length() == 8 ) {
					dirList.add(tmpList.get(i).getName());
				}
			}
		}
		
		return dirList;
	}
	
	private boolean IsMSTGRPChanged(String chgDT, int day) {
		boolean bRtn = false;
		try {
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			
			String toDay = sdf.format(calendar.getTime());
			
			calendar.add(Calendar.DATE, day);
			String stdDate = sdf.format(calendar.getTime());
			
			// 변경 날짜가 어제 이후라면 생성
			if( stdDate.compareTo(chgDT) <= 0 ) {
				bRtn = true;
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bRtn;
	}
	
	/**
	 * generateSTBDM170AT - Generate Store Master Inquirty Results as TBL File(점포마스터 조회 결과를 TBL파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM170AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao = new MasterCrtExDAO();
		String fileName = "STBDM170AT.tbl";
		int max = 0;
		try {
			sb.append("STORE|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM170AT", max);
//			System.out.println("[DEBUG] list count:" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("store_cd") + "|" );
				sb.append( (String)map.get("store_owner") + "|" );
				sb.append( (String)map.get("store_nm") + "|" );
				sb.append( (String)map.get("store_addr") + "|" );
				sb.append( (String)map.get("store_biz_no") + "|" );
				sb.append( (String)map.get("store_tel") + "|" );
				sb.append( (String)map.get("store_pos_qty") + "|" );
				sb.append( (String)map.get("hq_send_ip") + "|" );
				sb.append( (String)map.get("hq_recv_ip") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * generateSTBDM130AT_PDA - 점포상품마스터 요약 조회 결과를 TBL파일로 생성
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM130AT_PDA(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao = new MasterCrtExDAO();
		String fileName = "STBDM130AT.tbl";
		boolean flag = true;
		int max = 0;
		try {
			while(flag) {
				List<Object> list = null;
				
				list = dao.selectMaster(m, "SEL_STBDM130AT_PDA", max);
				if(list.size() > 0) {
					if(max > 0)
						sb.setLength(0);
					
					for(int i = 0;i < list.size();i++) {
						Map<String, String> map = (Map<String, String>)list.get(i);
						sb.append( (String)map.get("plu_cd") + "|" );
						sb.append( (String)map.get("plu_snm") + "|" );
						sb.append( (String)map.get("item_price") + "|");
						sb.append( (String)map.get("sal_enbl_yn") + "\r\n" );
					}
					if (max == 0)
					{
						// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
						if(sb.length()>0) {
							ZipUtil.createFileUTF16(sb, path, fileName, false);
							logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
						} else {
							ZipUtil.createFileUTF16(sb, path, fileName, false);
							logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
						}
					}
					else
					{
						// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 추가)
						ZipUtil.createFileUTF16(sb, path, fileName, true);
//						logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is appended.");
					}					

					max++;
				}else {
					if( max == 0 ) {
						ZipUtil.createFileUTF16(sb, path, fileName, false);
//						logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is appended.");
					}
					
					flag = false;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM130AT - Generate Good Master Inquiry Results as File(상품마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM130AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM130AT.tbl";
		boolean flag = true;
		int max = 0;
		try {			
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PLU\r\n");
			sb.append("PLU|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
						
			while(flag) {
//				List<Object> list = dao.selectMaster(m, "SEL_STBDM130AT", max);
				List<Object> list = null;
				if( ((String)m.get("URGENT_YN")).equals("2") ) {
					list = dao.selectMaster(m, "SEL_STBDM130AT2", max);
				}else {
					list = dao.selectMaster(m, "SEL_STBDM130AT", max);
				}
				
//				System.out.println("[DEBUG] list count:" + list.size());
				if(list.size() > 0 ) {
					if (max > 0)
						sb.setLength(0);
					
					for (int i=0; i < list.size(); i++) {
						Map<String, String> map = (Map<String, String>)list.get(i);
						sb.append( (String)map.get("plu_cd") + "|" );
						sb.append( (String)map.get("cate_id") + "|" );
						sb.append( (String)map.get("grp_id") + "|" );
						sb.append( (String)map.get("sgrp_id") + "|" );
						sb.append( (String)map.get("brand_id") + "|" );
						sb.append( (String)map.get("plu_snm") + "|" );
						sb.append( (String)map.get("plu_nm") + "|" );
						sb.append( (String)map.get("item_price") + "|" );
						sb.append( (String)map.get("item_price") + "|" );
						sb.append( (String)map.get("item_ty") + "|" );
						sb.append( (String)map.get("item_tax_id") + "|" );
						sb.append( (String)map.get("btl_plu_cd") + "|" );
						sb.append( (String)map.get("item_oprc") + "|" );
						sb.append( (String)map.get("sale_stop_yn") + "|" );
						sb.append( (String)map.get("sale_unit_qty") + "|" );
						sb.append( (String)map.get("dc_yn") + "|" );
						sb.append( (String)map.get("save_yn") + "|" );
						sb.append( (String)map.get("prc_chg_yn") + "|" );
						sb.append( (String)map.get("service_yn") + "|" );
						sb.append( (String)map.get("pack_yn") + "|" );
						sb.append( (String)map.get("ks_yn") + "|" );
						sb.append( (String)map.get("delivery_yn") + "|" );
						//sb.append( (String)map.get("svcchg_yn") + "|\r\n" );
						sb.append( (String)map.get("svcchg_yn") + "|" );
						//상품마스터 신규 추가 컬럼
						sb.append( (String)map.get("buy_yn") + "|" );
						sb.append( (String)map.get("youth_sale_yn") + "|" );
						sb.append( (String)map.get("sales_type") + "|" );
						sb.append( (String)map.get("pay_type") + "|" );
						sb.append( (String)map.get("ffplu_yn") + "|" );
						sb.append( (String)map.get("timebarcode_ty") + "|" );
						sb.append( (String)map.get("service_item_ty") + "|" );
						sb.append( (String)map.get("medicine_yn") + "|" );
						sb.append( (String)map.get("item_cd") + "|" );
						sb.append( (String)map.get("cash_rec_yn") + "|\r\n" );
					}
					if (max == 0)
					{
						// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
						if(sb.length()>0) {
							ZipUtil.createFileUTF16(sb, path, fileName, false);
							logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
						} else {
							ZipUtil.createFileUTF16(sb, path, fileName, false);
							logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
						}
					}
					else
					{
						// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 추가)
						ZipUtil.createFileUTF16(sb, path, fileName, true);
//						logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is appended.");
					}					

					max++;
				} else {
					if( max == 0 ) {
						ZipUtil.createFileUTF16(sb, path, fileName, false);
//						logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is appended.");
					}
					
					flag = false;
				}
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM020AT - Generate Brand Master Inquirty Results as File(브랜드마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM020AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM020AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("BRAND_MST\r\n");
			sb.append("BRAND_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM020AT", max);
//			System.out.println("[DEBUG] list count:" + list.size());
			if(list.size() > 0 ) {
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("brand_id") + "|" );
					sb.append( (String)map.get("brand_nm") + "|\r\n" );
				}
			}
	
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(sb.length()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM051AT - Generate Category Level1 Master Inquirty Results as File(카테고리대분류마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM051AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM051AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("LARGE_CLASS_MST\r\n");
			sb.append("LARGE_CLASS_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
		    
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM051AT", max);
//			System.out.println("[DEBUG] list count:" + list.size());
			if(list.size() > 0 ) {
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("cate_id") + "|" );
					sb.append( (String)map.get("cate_name") + "|\r\n" );
				}
			}
	
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(sb.length()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM052AT - Generate Category Level2 Master Inquirty Results as File(카테고리중분류마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM052AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM052AT.tbl";
		//boolean flag = true;
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("MID_CLASS_MST\r\n");
			sb.append("MID_CLASS_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
		    
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM052AT", max);
//			System.out.println("[DEBUG] list count:" + list.size());
			if(list.size() > 0 ) {
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("grp_id") + "|" );
					sb.append( (String)map.get("cate_id") + "|" );
					sb.append( (String)map.get("grp_name") + "|\r\n" );
				}
			}
	
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(sb.length()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM052AT - Generate Category Level3 Master Inquirty Results as File(카테고리소분류마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM053AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM053AT.tbl";
		//boolean flag = true;
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("SMALL_CLASS_MST\r\n");
			sb.append("SMALL_CLASS_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
		    
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM053AT", max);
//			System.out.println("[DEBUG] list count:" + list.size());
			if(list.size() > 0 ) {
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("sgrp_id") + "|" );
					sb.append( (String)map.get("cate_id") + "|" );
					sb.append( (String)map.get("grp_id") + "|" );
					sb.append( (String)map.get("sgrp_name") + "|\r\n" );
				}
			}
	
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(sb.length()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
     * 5. generateSTBDM270AT - Generate Store Receipt Master Inquirty Results as File(점포영수증마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM270AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM270AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PRTMSG\r\n");
			sb.append("PRTMSG|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
		    
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM270AT", max);
//			System.out.println("[DEBUG] SEL_STBDM270AT list=" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)m.get("store_cd") + "|" );
				sb.append( (String)map.get("pos_no") + "|" );
				sb.append( (String)map.get("use_id") + "|" );
				sb.append( (String)map.get("prt_seq") + "|" );
				sb.append( (String)map.get("prt_id") + "|" );
				sb.append( (String)map.get("enlarge_id") + "|" );
				sb.append( (String)map.get("char_string") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
     * 5. generateSTBDM271AT - Generate Receipt Format Group Master Inquirty Results as File(영수증유형그룹마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM271AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM271AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("RECEIPT_FORMAT_GROUP\r\n");
			sb.append("RECEIPT_FORMAT_GROUP|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)			    
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM271AT", max);
//			System.out.println("[DEBUG] SEL_STBDM271AT list=" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("receipt_format_group") + "|" );
				sb.append( (String)map.get("receipt_format_group_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
     * 5. generateSTBDM272AT - Generate Receipt Format Master Inquirty Results as File(영수증유형마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM272AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM272AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("RECEIPT_FORMAT\r\n");
			sb.append("RECEIPT_FORMAT|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)			    
		    
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM272AT", max);
//			System.out.println("[DEBUG] SEL_STBDM272AT list=" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("receipt_format_group") + "|" );
				sb.append( (String)map.get("receipt_format_flag") + "|" );
				sb.append( (String)map.get("seq_no") + "|" );
				sb.append( (String)map.get("align_flag") + "|" );
				sb.append( (String)map.get("size_flag") + "|" );
				sb.append( (String)map.get("receipt_format_tag") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
     * 5. generateSTBDM273AT - Generate KPS Format Group Master Inquirty Results as File(주방프린터유형그룹마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM273AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM273AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("KPS_FORMAT_GROUP\r\n");
			sb.append("KPS_FORMAT_GROUP|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM273AT", max);
//			System.out.println("[DEBUG] SEL_STBDM273AT list=" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("kps_format_group") + "|" );
				sb.append( (String)map.get("kps_format_group_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
     * 5. generateSTBDM274AT - Generate KPS Format Master Inquirty Results as File(주방프린터유형마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM274AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM274AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("KPS_FORMAT\r\n");
			sb.append("KPS_FORMAT|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM274AT", max);
//			System.out.println("[DEBUG] SEL_STBDM274AT list=" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("kps_format_group") + "|" );
				sb.append( (String)map.get("kps_format_flag") + "|" );
				sb.append( (String)map.get("seq_no") + "|" );
				sb.append( (String)map.get("align_flag") + "|" );
				sb.append( (String)map.get("size_flag") + "|" );
				sb.append( (String)map.get("kps_format_tag") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
     * 5. generateSTBDM275AT - Generate Account Slip Format Group Master Inquirty Results as File(정산지인쇄유형그룹마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM275AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM275AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("ACCOUNT_SLIP_FORMAT_GROUP\r\n");
			sb.append("ACCOUNT_SLIP_FORMAT_GROUP|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM275AT", max);
//			System.out.println("[DEBUG] SEL_STBDM275AT list=" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("account_slip_format_group") + "|" );
				sb.append( (String)map.get("account_slip_format_group_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
     * 5. generateSTBDM276AT - Generate Account Slip Format Master Inquirty Results as File(정산지인쇄유형마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM276AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM276AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("ACCOUNT_SLIP_FORMAT\r\n");
			sb.append("ACCOUNT_SLIP_FORMAT" + "|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM276AT", max);
//			System.out.println("[DEBUG] SEL_STBDM276AT list=" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("account_slip_format_group") + "|" );
				sb.append( (String)map.get("account_slip_type") + "|" );
				sb.append( (String)map.get("seq_no") + "|" );
				sb.append( (String)map.get("account_code") + "|" );
				sb.append( (String)map.get("print_flag") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
     * 5. generateSTBDM011AT - Generate Substitution PLU Master Inquirty Results as File(대체상품마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM011AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM011AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("SUBSTITUTION_PLU\r\n");
			sb.append("SUBSTITUTION_PLU|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM011AT", max);
//			System.out.println("[DEBUG] SEL_STBDM011AT list=" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("plu_cd") + "|" );
				sb.append( (String)map.get("substitution_plu_cd") + "|" );
				sb.append( (String)map.get("combo_up_charge_amt") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM102AT - Generate Promotion Master Inquirty Results as File(행사마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM102AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM102AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PROMH\r\n");
			sb.append("PROMH|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM102AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("prom_evt_cd") + "|" );
				sb.append( (String)map.get("prom_evt_nm") + "|" );
				sb.append( (String)map.get("prom_evt_symd") + "|" );
				sb.append( (String)map.get("prom_evt_eymd") + "|" );
				sb.append( (String)map.get("prom_evt_shh") + "|" );
				sb.append( (String)map.get("prom_evt_ehh") + "|" );
				sb.append( (String)map.get("prom_evt_aday_yn") + "|" );
				sb.append( (String)map.get("prom_evt_seq") + "|" );
				sb.append( (String)map.get("prom_evt_ty") + "|" );
				sb.append( (String)map.get("prom_evt_cnd") + "|" );
				sb.append( (String)map.get("prom_evt_coupon") + "|" );
				sb.append( (String)map.get("prom_evt_org_id") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg1_ty") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg1_amt") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg1_dc") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg2_ty") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg2_amt") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg2_dc") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg3_ty") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg3_amt") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg3_dc") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg4_ty") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg4_amt") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg4_dc") + "|" );
				sb.append( (String)map.get("prom_evt_desc") + "|" );
				sb.append( (String)map.get("prom_evt_dc_div") + "|" );
				sb.append( (String)map.get("prom_evt_amt") + "|" );
				sb.append( (String)map.get("filler1") + "|" );
				sb.append( (String)map.get("filler2") + "|" );
				sb.append( (String)map.get("filler3") + "|" );
				sb.append( (String)map.get("filler4") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM103AT - Generate Promotion PLU Master Inquirty Results as File(행사상품마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM103AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM103AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PROMD\r\n");
			sb.append("PROMD|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM103AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("plu_cd") + "|" );
				sb.append( (String)map.get("prom_evt_cd") + "|" );
				sb.append( (String)map.get("item_org_grp") + "|" );
				sb.append( (String)map.get("dc_price") + "|" );
				sb.append( (String)map.get("prom_evt_ty") + "|" );
				sb.append( (String)map.get("prom_evt_div") + "|" );
				sb.append( (String)map.get("obj_reg_ty") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM104AT - Generate Promotion Card Master Inquirty Results as File(행사카드마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM104AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao = new MasterCrtExDAO();
		String fileName = "STBDM104AT.tbl";
		int max = 0;
		try {
			sb.append("PROMCARD|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM104AT", max);
			for(int i = 0;i < list.size();i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("prom_evt_cd") + "|" );		// 행사코드
				sb.append( (String)map.get("prefix_st_no") + "|" );		// 카드BIN시작
				sb.append( (String)map.get("prefix_end_no") + "|" );	// 카드BIN끝
				sb.append( "|" );										// FILLER1
				sb.append( "|" );										// FILLER2
				sb.append( "|" );										// FILLER3
				sb.append( "|" );										// FILLER4
				sb.append( "|\r\n" );									// FILLER5
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		
		return 0;
	}
	
	/**
	 * 4. generateSTBDM110AT - Generate Receipt Promotion Master Inquirty Results as File(영수증행사마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM110AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM110AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PRTPROMH\r\n");
			sb.append("PRTPROMH|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM110AT", max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("rect_evt_cd") + "|" );
				sb.append( (String)map.get("rect_evt_nm") + "|" );
				sb.append( (String)map.get("rect_evt_symd") + "|" );
				sb.append( (String)map.get("rect_evt_eymd") + "|" );
				sb.append( (String)map.get("rect_evt_shh") + "|" );
				sb.append( (String)map.get("rect_evt_ehh") + "|" );
				sb.append( (String)map.get("rect_evt_aday_yn") + "|" );
				sb.append( (String)map.get("rect_evt_ty") + "|" );
				sb.append( (String)map.get("rect_evt_amt") + "|" );
				sb.append( (String)map.get("rect_evt_kind") + "|" );
				sb.append( (String)map.get("rect_prt_msg1") + "|" );
				sb.append( (String)map.get("rect_prt_msg2") + "|" );
				sb.append( (String)map.get("rect_prt_msg3") + "|" );
				sb.append( (String)map.get("rect_prt_msg4") + "|" );
				sb.append( (String)map.get("rect_prt_msg5") + "|" );
				sb.append( (String)map.get("rect_prt_msg6") + "|" );
				sb.append( (String)map.get("rect_prt_msg7") + "|" );
				sb.append( (String)map.get("rect_prt_msg8") + "|" );
				sb.append( (String)map.get("rect_prt_msg9") + "|" );
				sb.append( (String)map.get("rect_prt_msg10") + "|" );
				sb.append( (String)map.get("filler1") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM111AT - Generate Receipt Promotion PLU Master Inquirty Results as File(영수증행사상품마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM111AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM111AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PRTPROMD\r\n");
			sb.append("PRTPROMD|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM111AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("plu_cd") + "|" );
				sb.append( (String)map.get("rect_evt_cd") + "|" );
				sb.append( (String)map.get("obj_reg_ty") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM112AT - Generate Receipt Promotion PLU Master Inquirty Results as File(영수증행사카드마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM112AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM112AT.tbl";
		int max = 0;
		try {
			sb.append("PRTPROMCARD|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM112AT",max);
			for(int i = 0;i < list.size();i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("prom_evt_cd") + "|" );		// 행사코드
				sb.append( (String)map.get("prefix_st_no") + "|" );		// 카드BIN시작
				sb.append( (String)map.get("prefix_end_no") + "|" );	// 카드BIN끝
				sb.append( "|" );										// FILLER1
				sb.append( "|" );										// FILLER2
				sb.append( "|" );										// FILLER3
				sb.append( "|" );										// FILLER4
				sb.append( "|\r\n" );									// FILLER5
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 2. generateSTBDM140AT - Generate FF-Category Inquirty Results as File(FF-카테고리 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM140AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM140AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("FFGROUP\r\n");
			sb.append("FFGROUP|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM140AT", max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
			    sb.append( (String)map.get("ffplu_cat") + "|" );
			    sb.append( (String)map.get("ffplu_cat_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
     * 3. generateSTBDM141AT - Generate FF-PLU Inquirty Results as File(FF-PLU 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM141AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM141AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("FFPLU\r\n");
			sb.append("FFPLU|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM141AT", max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);

			    sb.append( (String)map.get("ffplu_cat") + "|" );
			    sb.append( (String)map.get("ffplu_seq") + "|" );
			    sb.append( (String)map.get("plu_cd") + "|" );
			    sb.append( (String)map.get("ffplu_asgn_yn") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 5. generateSTBDM300AT - Generate Staff Master Inquirty Results as File(직원마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM300AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM300AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("STAFF\r\n");
			sb.append("STAFF|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM300AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("user_id") + "|" );
				sb.append( (String)map.get("user_ty") + "|" );
				sb.append( (String)map.get("user_nm") + "|" );
				sb.append( (String)map.get("user_pw") + "|" );
				sb.append( (String)map.get("user_auth_grp_cd") + "|" );
				sb.append( (String)map.get("user_card_no") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 5. generateSTBDM311AT - Generate Staff Auth Group Master Inquirty Results as File(직원권한그룹마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM311AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM311AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("STAFF_AUTH_GROUP\r\n");
			sb.append("STAFF_AUTH_GROUP|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM311AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("staff_auth_group") + "|" );
				sb.append( (String)map.get("staff_auth_group_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 5. generateSTBDM312AT - Generate Staff Auth Master Inquirty Results as File(직원권한마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM312AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM312AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("STAFF_AUTH\r\n");
			sb.append("STAFF_AUTH|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM312AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("staff_auth_group") + "|" );
				sb.append( (String)map.get("sfkc_key") + "|" );
				sb.append( (String)map.get("manager_auth_check") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
     * 5. generateSTBDM350AT - Generate Common Code Master Inquirty Results as File(공통코드마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM350AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM350AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("COMMONMSG\r\n");
			sb.append("COMMONMSG|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM350AT",max);

			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);

			    sb.append( (String)map.get("country_cd") + "|" );
				sb.append( (String)map.get("comm_cd_cat") + "|" );
				sb.append( (String)map.get("comm_cd") + "|" );
				sb.append( (String)map.get("prt_order") + "|" );
				sb.append( (String)map.get("comm_cd_cont") + "|" );
				sb.append( (String)map.get("value") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 5. generateSTBDM920AT - Generate Culture Master Inquirty Results as File(문화마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM920AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM920AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("GCULTMST\r\n");
			sb.append("GCULTMST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM920AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
			    sb.append( (String)map.get("culture_id") + "|" );
				sb.append( (String)map.get("culture_nm") + "|" );
				sb.append( (String)map.get("date_pattern") + "|" );
				sb.append( (String)map.get("currency_symbol") + "|" );
				sb.append( (String)map.get("currency_nm") + "|" );
				sb.append( (String)map.get("decimal_digits") + "|" );
				sb.append( (String)map.get("decimal_symbol") + "|" );
				sb.append( (String)map.get("grouping_digits") + "|" );
				sb.append( (String)map.get("grouping_symbol") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 5. generateSTBDM910AT - Generate Message Master Inquirty Results as File(메시지마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM910AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM910AT.tbl";
		int max = 0;
		String strMessage;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("MESSAGEMST\r\n");
			sb.append("MESSAGEMST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM910AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
			    sb.append( (String)map.get("country_cd") + "|" );
			    sb.append( (String)map.get("msg_id") + "|" );
			    sb.append( (String)map.get("msg_type_id") + "|" );
				//메시지마스터 메시지내용은 CR,LF 존재하므로 POS단의 행별 라인단위 read의 일관화를 위해 <br>로 치환
				strMessage = (String)map.get("message");
				strMessage = strMessage.replaceAll("\r\n", "<br>");
				strMessage = strMessage.replaceAll("\n", "<br>");
				sb.append( strMessage + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 5. generateSTBDM930AT - Generate Tax Master Inquirty Results as File(세금마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM930AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM930AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("GTAXMST\r\n");
			sb.append("GTAXMST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM930AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
			    sb.append( (String)map.get("country_cd") + "|" );
			    sb.append( (String)map.get("tax_id") + "|" );
			    sb.append( (String)map.get("tax_nm") + "|" );
			    sb.append( (String)map.get("flag") + "|" );
			    sb.append( (String)map.get("amt_or_perc") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 5. generateSTBDM640AT - Generate POS Master Inquirty Results as File(POS마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM640AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM640AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("POS_MST\r\n");
			sb.append("POS_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM640AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
			    sb.append( (String)map.get("store_cd") + "|" );
			    sb.append( (String)map.get("pos_no") + "|" );
			    sb.append( (String)map.get("pos_nm") + "|" );
			    sb.append( (String)map.get("pos_option") + "|" );
			    sb.append( (String)map.get("pos_hw_id") + "|" );
			    sb.append( (String)map.get("op_button_group") + "|" );
			    sb.append( (String)map.get("receipt_format_group") + "|" );
			    sb.append( (String)map.get("kps_format_group") + "|" );
			    sb.append( (String)map.get("account_slip_format_group") + "|" );
			    sb.append( (String)map.get("pos_key_group") + "|||||" );
			    sb.append( ((String)m.get("trans_ver")).substring(0, 8) + "^" + (String)map.get("cashrcpt_apprno") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 9. generateSTBDM650AT - Generate Option Master Inquirty Results as File(옵션마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM650AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM650AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("OPTIONMST\r\n");
			sb.append("OPTIONMST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM650AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
			    sb.append( (String)map.get("pos_no") + "|" );
			    sb.append( (String)map.get("option_cd") + "|" );
			    sb.append( (String)map.get("option_val") + "|" );
			    sb.append( (String)map.get("option_nm") + "|" );
			    sb.append( (String)map.get("option_desc") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 9. generateSTBDM660AT - Generate POS Setting Master Inquirty Results as File(POS설정마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM660AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM660AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("POSSETTING_MST\r\n");
			sb.append("POSSETTING_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM660AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
			    sb.append( (String)map.get("pos_no") + "|" );
			    sb.append( (String)map.get("setting_item_class_type") + "|" );
			    sb.append( (String)map.get("setting_item_cd") + "|" );
			    sb.append( (String)map.get("setting_item_val") + "|" );
			    sb.append( (String)map.get("setting_item_nm") + "|" );
			    sb.append( (String)map.get("setting_input_type") + "|" );
			    sb.append( (String)map.get("com_group_cd") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 9. generateSTBDM661AT - Generate Preset Master Inquirty Results as File(단축키마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM661AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM661AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PRESET_MST\r\n");
			sb.append("PRESET_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM661AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
			    sb.append( (String)map.get("preset_key") + "|" );
			    sb.append( (String)map.get("plu_cd") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 9. generateSTBDM662AT - Generate Reason Master Inquirty Results as File(사유마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM662AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM662AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("REASON_MST\r\n");
			sb.append("REASON_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM662AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
			    sb.append( (String)map.get("country_id") + "|" );
			    sb.append( (String)map.get("reason_ty") + "|" );
			    sb.append( (String)map.get("reason_cd") + "|" );
			    sb.append( (String)map.get("reason_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM150AT - Generate Menu Header Master Results as File(메뉴헤더마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM150AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM150AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("MENU_HEADER\r\n");
			sb.append("MENU_HEADER|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM150AT", max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);

//				System.out.println("[DEBUG] [menu_cd]=" + (String)map.get("menu_cd"));
			    sb.append( (String)map.get("menu_cd") + "|" );
			    sb.append( (String)map.get("menu_nm") + "|" );
			    sb.append( (String)map.get("back_color") + "|" );
			    sb.append( (String)map.get("font_color") + "|" );
			    sb.append( (String)map.get("font_size") + "|" );
			    sb.append( (String)map.get("font_nm") + "|" );
			    sb.append( (String)map.get("use_flag") + "|" );
			    sb.append( (String)map.get("display_seq") + "|" );
			    sb.append( (String)map.get("sale_type") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM151AT - Generate Menu Button Master Results as File(메뉴버튼마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM151AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM151AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("MENU_BUTTON\r\n");
			sb.append("MENU_BUTTON|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM151AT", max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);

			    sb.append( (String)map.get("menu_cd") + "|" );
			    sb.append( (String)map.get("seq_no") + "|" );
			    sb.append( (String)map.get("menu_type") + "|" );
			    sb.append( (String)map.get("type_cd") + "|" );
			    sb.append( (String)map.get("key_cd") + "|" );
			    sb.append( (String)map.get("text_nm") + "|" );
			    sb.append( (String)map.get("up_back_color") + "|" );
			    sb.append( (String)map.get("down_back_color") + "|" );
			    sb.append( (String)map.get("up_back_image") + "|" );
			    sb.append( (String)map.get("down_back_image") + "|" );
			    sb.append( (String)map.get("font_color") + "|" );
			    sb.append( (String)map.get("font_nm") + "|" );
			    sb.append( (String)map.get("font_size") + "|" );
			    sb.append( (String)map.get("x_point") + "|" );
			    sb.append( (String)map.get("y_point") + "|" );
			    sb.append( (String)map.get("width") + "|" );
			    sb.append( (String)map.get("height") + "|" );
			    sb.append( (String)map.get("disp_flag") + "|" );
			    sb.append( (String)map.get("disp_type") + "|" );
			    sb.append( (String)map.get("use_flag") + "|" );
			    sb.append( (String)map.get("base_gds_yn") + "|" );
			    sb.append( (String)map.get("change_enable_yn") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM152AT - Generate Select Modifier Master Results as File(선택수정자마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM152AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM152AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("OPTION_MODIFIER_MST\r\n");
			sb.append("OPTION_MODIFIER_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM152AT", max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
	
			    sb.append( (String)map.get("modifier_cd") + "|" );
			    sb.append( (String)map.get("seq_no") + "|" );
			    sb.append( (String)map.get("modifier_nm") + "|" );
			    sb.append( (String)map.get("modifier_type") + "|" );
			    sb.append( (String)map.get("type_cd") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM154AT - Generate Combo Master Results as File(콤보마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM154AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM154AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("COMBO_MST\r\n");
			sb.append("COMBO_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM154AT", max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
	
			    sb.append( (String)map.get("plu_cd") + "|" );
			    sb.append( (String)map.get("seq_no") + "|" );
			    sb.append( (String)map.get("combo_type") + "|" );
			    sb.append( (String)map.get("child_plu_cd") + "|" );
			    sb.append( (String)map.get("child_menu_cd") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM156AT - Generate Op. Button Group Master Results as File(조작버튼그룹마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM156AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM156AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("OP_BUTTON_GROUP\r\n");
			sb.append("OP_BUTTON_GROUP|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM156AT", max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
	
			    sb.append( (String)map.get("op_button_group") + "|" );
			    sb.append( (String)map.get("op_button_group_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM157AT - Generate Op. Button Setup Master Results as File(조작버튼설정마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM157AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM157AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("OP_BUTTON_SETUP\r\n");
			sb.append("OP_BUTTON_SETUP|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM157AT", max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
	
			    sb.append( (String)map.get("op_button_group") + "|" );
			    sb.append( (String)map.get("op_button_flag") + "|" );
			    sb.append( (String)map.get("seq_no") + "|" );
			    sb.append( (String)map.get("sfkc_key") + "|" );
			    sb.append( (String)map.get("sfkc_key_nm") + "|" );
			    sb.append( (String)map.get("back_image") + "|" );
			    sb.append( (String)map.get("font_color") + "|" );
			    sb.append( (String)map.get("font_nm") + "|" );
			    sb.append( (String)map.get("font_size") + "|" );
			    sb.append( (String)map.get("option1") + "|" );
			    sb.append( (String)map.get("option2") + "|" );
			    sb.append( (String)map.get("option3") + "|" );
			    sb.append( (String)map.get("option4") + "|" );
			    sb.append( (String)map.get("option5") + "|" );
			    sb.append( (String)map.get("option6") + "|" );
			    sb.append( (String)map.get("option7") + "|" );
			    sb.append( (String)map.get("option8") + "|" );
			    sb.append( (String)map.get("option9") + "|" );
			    sb.append( (String)map.get("option10") + "|" );
			    sb.append( (String)map.get("option11") + "|" );
			    sb.append( (String)map.get("option12") + "|" );
			    sb.append( (String)map.get("option13") + "|" );
			    sb.append( (String)map.get("option14") + "|" );
			    sb.append( (String)map.get("option15") + "|" );
			    sb.append( (String)map.get("option16") + "|" );
			    sb.append( (String)map.get("option17") + "|" );
			    sb.append( (String)map.get("option18") + "|" );
			    sb.append( (String)map.get("option19") + "|" );
			    sb.append( (String)map.get("option20") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM158AT - SFKC Key Master Results as File(SFKC키마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM158AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM158AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("SFKC_MST\r\n");
			sb.append("SFKC_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM158AT", max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
	
			    sb.append( (String)map.get("country_cd") + "|" );
			    sb.append( (String)map.get("sfkc_key") + "|" );
			    sb.append( (String)map.get("sfkc_key_nm") + "|" );
			    sb.append( (String)map.get("sfkc_key_type") + "|" );
			    sb.append( (String)map.get("sale_wait_flag") + "|" );
			    sb.append( (String)map.get("saling_flag") + "|" );
			    sb.append( (String)map.get("pay_wait_flag") + "|" );
			    sb.append( (String)map.get("paying_flag") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM670AT - CASHBEE PUBCO INFO Master Results as File(캐시비발행사정보 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM670AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM670AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("SFKC_MST\r\n");
			sb.append("TRANS_CB_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM670AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("PBCO_ID") + "|" );
				sb.append( (String)map.get("PBCO_NM") + "|" );
				sb.append( (String)map.get("PBCO_KEY_VER") + "|" );
				sb.append( (String)map.get("PBCO_KEY_VAL") + "|" );
				sb.append( (String)map.get("RECHG_FEE_RT") + "|" );
				sb.append( (String)map.get("BUY_FEE_RT") + "|" );
				sb.append( (String)map.get("RFU_VAL") + "|" );
				sb.append( (String)map.get("REPAY_FEE") + "|" );
				sb.append( (String)map.get("PENAL_AMT") + "|" );
				sb.append( (String)map.get("SAM_TP") + "|" );
				sb.append( (String)map.get("RECHG_ENBL_YN") + "|" );
				sb.append( (String)map.get("BUY_ENBL_YN") + "|" );
				sb.append( (String)map.get("REPAY_ENBL_YN") + "|" );
				sb.append( (String)map.get("ROBB_LOST_SEAH_YN") + "|" );
				sb.append( (String)map.get("REPAY_MAX_AMT") + "|" );
				sb.append( (String)map.get("ELE_MONYCO_ID") + "|" );
				sb.append( (String)map.get("CARD_MAX_RECHG_AMT") + "|" );
				sb.append( (String)map.get("ONCE_MAX_RECHG_AMT") + "|\r\n" );
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM671AT - HANPAY PUBCO INFO Master Results as File(한페이발행사정보 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM671AT(Map m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM671AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("SFKC_MST\r\n");
			sb.append("TRANS_HP_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM671AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("PBCO_CD") + "|" );
				sb.append( (String)map.get("TMNAL_ID") + "|\r\n" );
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM680AT - TMONEY PUBCO INFO Master Results as File(티머니발행사제어정보 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM680AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM680AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("SFKC_MST\r\n");
			sb.append("TRANS_TM_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM680AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("PBCO_ID") + "|" );
				sb.append( (String)map.get("PBCO_FNC_DEFINE_VAL") + "|\r\n" );
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM480AT - CARD BIN Master Results as File(카드BIN마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM480AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM480AT.tbl";
		int max = 0;
		try {
			sb.append("CCARD|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM480AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("PREFIX_ST_NO") + "|" );			// 카드BIN시작
				sb.append( (String)map.get("PREFIX_END_NO") + "|" );		// 카드BIN끝
				sb.append( (String)map.get("PREFIX_TP") + "|" );			// 카드BIN유형
				sb.append( "00|" );											// DIGIT COUNT
				sb.append( (String)map.get("CARD_ISUCO_TP") + "|" );		// 카드사코드
				sb.append( "|" );											// 카드사명
				sb.append( (String)map.get("CARD_PAY_TP") + "|" );			// 결제구분코드
				sb.append( (String)map.get("CARD_TP_TP") + "|\r\n" );		// 카드유형코드
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM490AT - HARM PLU Master Results as File(위해상품 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM490AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM490AT.tbl";
		int max = 0;
		try {
			sb.append("HARM_MST|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM490AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("HARM_PLU") + "|" );				// 상품바코드
				sb.append( (String)map.get("MAKE_CMP") + "|" );				// 제조업체
				sb.append( (String)map.get("MAKE_DT") + "|" );				// 제조일자
				sb.append( (String)map.get("EXP_DT") + "|" );				// 유통기한
				sb.append( (String)map.get("HARM_REASON") + "|" );			// 위해사유
				sb.append( (String)map.get("NOTI_PL") + "|" );				// 고시처
				sb.append( (String)map.get("NOTI_DT") + "|" );				// 고시일시
				sb.append( "|\r\n" );										// 설명
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM280AT - POS KEY GROUP Master Results as File(POSKEY그룹마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM280AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM280AT.tbl";
		int max = 0;
		try {
			sb.append("POS_KEY_GROUP|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM280AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("POS_KEY_GRP_CD") + "|" );			// POSKEY그룹코드
				sb.append( (String)map.get("POS_KEY_GRP_NM") + "|" );			// POSKEY그룹명
				sb.append( (String)map.get("POS_KEYBD_EQUIP_CD") + "|\r\n" );	// POSKEY종류
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM281AT - POS Key Master Results as File(POSKEY마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM281AT(Map<String, String> m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String fileName = "STBDM281AT.tbl";
		int max = 0;
		try {
			sb.append("POS_KEY|" + (String)m.get("trans_ver") + "|" + (String)m.get("trans_ymd") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM281AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("POS_KEY_GRP_CD") + "|" );		// POSKEY그룹코드
				sb.append( (String)map.get("SCAN_KEY_VAL") + "|" );			// POS 스캔키
				sb.append( (String)map.get("HNDL_KEY_VAL") + "|\r\n" );		// 조작키
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is created.");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[comcd : "+(String)m.get("com_cd")+"][storecd : "+(String)m.get("store_cd")+"] Filename : "+fileName+" is not created. There are no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
}
