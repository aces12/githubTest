package biz.cms_MasterCrtEx;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_MasterAgentEx.MasterAgentExPollingAction;
import biz.comm.COMMBiz;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class MasterCrtExDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(MasterAgentExPollingAction.class);
	
	public int spSMSSEND(String strMsg, String strSender) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("sysinq-sql", "PR_SMSSEND"));
			sql.setString(++i, strMsg);
			sql.setString(++i, strSender);
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
	/**
     * Search stores to create master data file(마스터데이터 파일을 생성할 점포 조회)
     * @return List Store List(점포목록)
     * @exception exception Description of Exception(예외사항설명)
     */
	public List<Object> selSTBDA120AT(String transYmd, String com, String store) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "SEL_STBDA120AT"));
			sql.setString(++i, transYmd);		// trans_ymd
			sql.setString(++i, store);			// store_cd
			sql.setString(++i, com);			// com_cd
			
			list = executeQuery(sql);
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
		} 
		
		return list;
	}
	
	/**
     * updSTBDA120AT0 - Modify status value after master file(마스터생성중 플래그세팅)
     * @param m
	 * m[0] = trans_ymd
	 * m[1] = store_cd
	 * m[2] = trans_id
	 * m[3] = trans_seq
	 * m[4] = com_cd
     * @return int Rowcount of updated data(update된 데이터 rowcount)
     * @exception exception 
     */
	public int updSTBDA120AT0(Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "UPD_STBDA120AT0"));
			sql.setString(++i, (String)map.get("trans_ymd"));	// trans_ymd
			sql.setString(++i, (String)map.get("store_cd"));	// store_cd
			sql.setString(++i, (String)map.get("trans_id"));	// trans_id
			sql.setString(++i, (String)map.get("trans_seq"));	// trans_seq
			sql.setString(++i, (String)map.get("com_cd"));		// com_cd

			rows = executeUpdate(sql);
		} catch (Exception e) {
			rollback();
			throw e;
		} finally {
			end();
		}
		
		return rows;
	}
	
	/**
     * updSTBDA120AT1 - Modify status value after master file(마스터생성완료 플래그세팅)
     * @param m
	 * m[0] = trans_ymd
	 * m[1] = store_cd
	 * m[2] = trans_id
	 * m[3] = trans_seq
	 * m[4] = urgent_yn
	 * m[5] = file_dir
     * @return int Rowcount of updated data(update된 데이터 rowcount)
     * @exception exception 
     */
	public int updSTBDA120AT1(Map<String, String> map, String OPER_ID) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i=0;
		int rows=-1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "UPD_STBDA120AT1"));
			sql.setString(++i, (String)map.get("trans_file_dir"));	// file_dir
			sql.setString(++i, OPER_ID);							// oper_id
			sql.setString(++i, (String)map.get("trans_ymd"));		// trans_ymd
			sql.setString(++i, (String)map.get("store_cd"));		// store_cd
			sql.setString(++i, (String)map.get("trans_id"));		// trans_id
			sql.setString(++i, (String)map.get("trans_seq"));		// trans_seq
			sql.setString(++i, (String)map.get("com_cd"));			// com_cd

			rows = executeUpdate(sql);
		} catch (Exception e) {
			rollback();
			throw e;
		} finally {
			end();
		}
		
		return rows;
	}
	
	/**
	 * selMSTGRPLIST - 마스터그룹 배신생성조건 조회
	 * @param com : 회사코드
	 * @return
	 * @throws Exception
	 */
	public List<Object> selMSTGRPLIST(String com) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "SEL_MSTGRPLIST"));
			sql.setString(++i, com);	// com_cd
			list = executeQuery(sql);
		} catch (Exception e) {
			logger.info("[ERROR]selMSTGRPLIST::" + e);
		}
		
		return list;
	}
	
	/**
	 * selectFFImg - Search FF-PLU image(FF-PLU 이미지 조회)
	 * @param m
	 * @param imgPath : FF-PLU Image File Path(FF-PLU 이미지파일 경로)
	 * @return
	 * @throws Exception
	 */
	public List<Object> selectFFImg(Map<String, String> map, String imgPath) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("stsys-sql", "SEL_FFIMG"));
			sql.setString(++i, imgPath);	// ff-plu imagefile path
			sql.setString(++i, (String)map.get("store_cd"));	// store_cd
			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		}
		return list;
	}
	
	/**
	 * selMSTGRPSETT - 마스터그룹 배신생성조건 조회
	 * @param com : 회사코드
	 * @return
	 * @throws Exception
	 */
	public List<Object> selMSTGRPSETT(String com, String grpCd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "SEL_MSTGRPSETT_EX"));
			sql.setString(++i, grpCd);	// 배포마스터그룹코드
			sql.setString(++i, com);	// 회사코드
			
			list = executeQuery(sql);
		} catch (Exception e) {
			logger.info("[ERROR]selMSTGRPSETT::" + e);
		}
		
		return list;
	}
	
	/**
	 * selTBLBELONGTOMSTGRP - 마스터그룹 배신생성조건 조회
	 * @param com : 회사코드
	 * @return
	 * @throws Exception
	 */
	public List<Object> selTBLBELONGTOMSTGRP(String com, String grpCd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "SEL_TBLBELONGTOMSTGRP_EX"));
			sql.setString(++i, grpCd);	// master group cd
			sql.setString(++i, com);	// com_cd
			
			list = executeQuery(sql);
		} catch (Exception e) {
			logger.info("[ERROR]selTBLBELONGTOMSTGRP::" + e);
		}
		
		return list;
	}
	
	/**
	 * selMSTGRPCHG - 배포마스터변경이력 조회
	 * @param com : 회사코드
	 * @param store : 점포코드
	 * @param grpCd : 마스터그룹코드
	 * @return
	 * @throws Exception
	 */
	public List<Object> selMSTGRPCHG(String com, String store, String grpCd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", "SEL_MSTGRPCHG_EX"));
			sql.setString(++i, "A16"+store);	// 사업장조직코드
			sql.setString(++i, grpCd);			// 배포마스터그룹코드
			sql.setString(++i, com);			// 회사코드
			
			list = executeQuery(sql);
		} catch (Exception e) {
			logger.info("[ERROR]selMSTGRPCHG::" + e);
		}
		
		return list;
	}
	
	/**
	 * selectGlobalMaster - Search Global Master Data(글로벌마스터데이터 조회)
	 * @param m
	 * @param sqlString : sqlname used in stsys-sql.xml(stsys-sql.xml에서 사용하는 sqlname)
	 * @param max : Variable to process paging (In the case of mass storage data, as it may have outofmemory, it is required to search data with paging)(paging 처리를 위한 변수 (대용량데이터일 경우 outofmemory에러가 발생할 수 있므로 paging처리해서 데이터 조회))
	 * @return List : Data List(데이터 목록)
	 * @throws Exception
	 */
	public List<Object> selectGlobalMaster(Map<String, String> map, String sqlString, int max) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("master-sql", sqlString));
			// Promotion Master, Promotion Item Master, Receipt Promotion Master, Receipt Promotion Item Master(판촉행사마스터, 판촉행사상품마스터, 영수증행사마스터, 영수증행사상품마스터)
			if (sqlString.equals("SEL_STBDM270AT")
			  ||sqlString.equals("SEL_STBDM102AT")||sqlString.equals("SEL_STBDM103AT")
			  ||sqlString.equals("SEL_STBDM110AT")||sqlString.equals("SEL_STBDM111AT")
			  ||sqlString.equals("SEL_STBDM640AT")||sqlString.equals("SEL_STBDM650AT")
			  ||sqlString.equals("SEL_STBDM660AT")||sqlString.equals("SEL_STBDM661AT")
			  ||sqlString.equals("SEL_STBDM300AT")||sqlString.equals("SEL_STBDM104AT")
			  ||sqlString.equals("SEL_STBDM112AT")
			) {
				if( sqlString.equals("SEL_STBDM102AT") || sqlString.equals("SEL_STBDM103AT") || sqlString.equals("SEL_STBDM104AT")
				 || sqlString.equals("SEL_STBDM110AT") || sqlString.equals("SEL_STBDM111AT") || sqlString.equals("SEL_STBDM112AT") ) {
					//if( (((String)map.get("trans_ver")).substring(8)).equals("01") ) {	// 정기배신
					if( ((String)map.get("urgent_yn")).equals("0") && ((String)map.get("trans_seq")).equals("1") ) {		// 정기 배신
						sql.setString(++i, "0");
						sql.setString(++i, "0");
					}else {	// 기타
						sql.setString(++i, "1");
						sql.setString(++i, "1");
					}
				}
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
			} else if(sqlString.equals("SEL_STBDM170AT")
			  ||sqlString.equals("SEL_STBDM020AT")||sqlString.equals("SEL_STBDM051AT")
			  ||sqlString.equals("SEL_STBDM052AT")||sqlString.equals("SEL_STBDM053AT")
			  ||sqlString.equals("SEL_STBDM271AT")||sqlString.equals("SEL_STBDM272AT")
			  ||sqlString.equals("SEL_STBDM273AT")||sqlString.equals("SEL_STBDM274AT")
			  ||sqlString.equals("SEL_STBDM275AT")||sqlString.equals("SEL_STBDM276AT")
			  ||sqlString.equals("SEL_STBDM011AT")
			  ||sqlString.equals("SEL_STBDM311AT")
			  ||sqlString.equals("SEL_STBDM350AT")||sqlString.equals("SEL_STBDM312AT")
			  ||sqlString.equals("SEL_STBDM662AT")
			  ||sqlString.equals("SEL_STBDM910AT")||sqlString.equals("SEL_STBDM920AT")
			  ||sqlString.equals("SEL_STBDM930AT")
			  ||sqlString.equals("SEL_STBDM152AT")
			  ||sqlString.equals("SEL_STBDM154AT")
			  ||sqlString.equals("SEL_STBDM156AT")||sqlString.equals("SEL_STBDM157AT")
			  ||sqlString.equals("SEL_STBDM158AT")
			  ||sqlString.equals("SEL_STBDM680AT")||sqlString.equals("SEL_STBDM480AT")
			  ||sqlString.equals("SEL_STBDM490AT")||sqlString.equals("SEL_STBDM280AT")
			  ||sqlString.equals("SEL_STBDM281AT")||sqlString.equals("SEL_STBDM671AT")
			  ) {
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
			} else if(sqlString.equals("SEL_STBDM150AT")||sqlString.equals("SEL_STBDM151AT")
			  ) {
				sql.setString(++i, (String)map.get("store_cd"));	// store_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
			} else if(sqlString.equals("SEL_STBDM670AT")
			  ) {
				Calendar calendar = new GregorianCalendar(Locale.KOREA);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				calendar.setTime(new Date());
				String adjt_dt = "";
				
				sql.setString(++i, (String)map.get("com_cd"));		// com_cd
				if( ((String)map.get("urgent_yn")).equals("0") && ((String)map.get("trans_seq")).equals("1") ) {		// 정기 배신
					calendar.add(Calendar.DATE, 1);
					adjt_dt = sdf.format(calendar.getTime());
				}else {
					adjt_dt = sdf.format(calendar.getTime());
				}
				sql.setString(++i, adjt_dt);
				
//				logger.info("[SQL][" + sqlString + "]" + sql.debug());
			}
		

//			logger.info("[SQL][" + sqlString + "]" + sql.debug());
//			System.out.println("[DEBUG] [SQL][" + sqlString + "]" + sql.debug());
			list = executeQuery(sql);
//			System.out.println("[DEBUG] [SQL][" + sqlString + "] result count:" + list.size());
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
		} 
		
		return list;
	}
	
	/**
	 * selectMaster - Search Master Data(마스터데이터 조회)
	 * @param m
	 * @param sqlString : sqlname used in stsys-sql.xml(stsys-sql.xml에서 사용하는 sqlname)
	 * @param max : Variable to process paging (In the case of mass storage data, as it may have outofmemory, it is required to search data with paging)(paging 처리를 위한 변수 (대용량데이터일 경우 outofmemory에러가 발생할 수 있므로 paging처리해서 데이터 조회))
	 * @return List : Data List(데이터 목록)
	 * @throws Exception
	 */
	public List<Object> selectMaster( Map<String, String> map, String sqlString, int max) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			String flag = (String)map.get("urgent_yn");
			
			//sql.put(findQuery("stsys-sql", sqlString+flag));
			sql.put(findQuery("master-sql", sqlString));
			// Emergency(긴급)
			
//			if(flag.equals("1")) {
//				// Good Master(상품마스터)
//				if (sqlString.equals("SEL_STBDM130AT")) {
//					sql.setString(++i, (String)map.get("com_cd"));		// com_cd
//					sql.setString(++i, (String)map.get("store_cd"));	// store_cd
//					sql.setString(++i, (String)map.get("trans_ymd"));	// trans_ymd
//					sql.setInt(++i, max);		// paging from
//					sql.setInt(++i, max);		// paging to
//				} 
//				// Event Master, Event Good Master, Receipt Event Master, Receipt Event Good Master(행사마스터, 행사상품마스터, 영수증행사마스터, 영수증행사상품마스터) 
//				//if(sqlString.equals("SEL_STBDM100AT")||sqlString.equals("SEL_STBDM101AT")
//				// ||sqlString.equals("SEL_STBDM110AT")||sqlString.equals("SEL_STBDM111AT")) {
//				//	sql.setString(++i, (String)map.get("trans_ymd"));	// trans_ymd
//				//}
//
//			// Normal Time(정시)
//			} else {
				// PLU Master(PLU 마스터)
				if(sqlString.equals("SEL_STBDM130AT") || sqlString.equals("SEL_STBDM130AT2") ) {
//					System.out.println("[DEBUG] [trans_ymd]SEL_STBDM130AT"+flag+"=" + (String)map.get("trans_ymd")+"," + (String)map.get("store_cd"));
					sql.setString(++i, (String)map.get("store_cd"));		// store_cd
					sql.setString(++i, (String)map.get("com_cd"));			// com_cd
					sql.setInt(++i, max);		// paging from
					sql.setInt(++i, max);		// paging to
				}else if( sqlString.equals("SEL_STBDM130AT_PDA") ) {
					sql.setString(++i, (String)map.get("store_cd"));		// store_cd
					sql.setString(++i, (String)map.get("com_cd"));			// com_cd
					sql.setString(++i, (String)map.get("store_cd"));		// store_cd
					sql.setString(++i, (String)map.get("com_cd"));			// com_cd
					sql.setInt(++i, max);		// paging from
					sql.setInt(++i, max);		// paging to
				}
//			}

//			logger.info("[SQL][" + sqlString + "]" + sql.debug());
//			System.out.println("[DEBUG] [SQL][" + sqlString + "]" + sql.debug());
			list = executeQuery(sql);
//			System.out.println("[DEBUG] [SQL][" + sqlString + "] result count:" + list.size());
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
//			System.out.println("[DEBUG] [ERROR][" + sqlString + "]" + e);
		} 
		
		return list;
	}
	
	/**
	 * selUGTMSTGRPALL - 마스터그룹 배신생성조건 조회
	 * @param com : 회사코드
	 * @param transYmd : 영업일자
	 * @param storeCd : 점포코드
	 * @return
	 * @throws Exception
	 */
	public List<Object> selUGTMSTGRPALL(String com, String transYmd, String storeCd, String urgent_tp, String trans_ver) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("master-sql", "SEL_UGTMSTGRPALL"));
			sql.setString(++i, transYmd);	// TRANS_YMD
			sql.setString(++i, storeCd);	// STORE_CD
			sql.setString(++i, com);		// COM_CD
			sql.setString(++i, urgent_tp);	// URGENT_YN
			sql.setString(++i, trans_ver);	// TRANS_VER
			
			logger.info(sql.debug());
			
			list = executeQuery(sql);
		} catch (Exception e) {
//			System.out.println(e.getMessage());
			logger.info("[ERROR]selUGTMSTGRPALL::" + e);
		}
		
		return list;
	}
}
