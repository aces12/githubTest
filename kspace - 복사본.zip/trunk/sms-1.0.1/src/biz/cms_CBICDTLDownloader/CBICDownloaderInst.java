package biz.cms_CBICDTLDownloader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;


public class CBICDownloaderInst extends Thread {
	private static Logger logger = Logger.getLogger(CBICDTLDownloaderPollingAction.class);
	
	String path = "";

	public CBICDownloaderInst(String path) {
		this.path = path;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
	public void deleteFile(String path, String fileNM) {
		File file = new File(path + File.separator + fileNM);
		if( file.exists() ) {
			logger.info("File Name : " + path + File.separator + fileNM);
			if( file.delete() ) {
				logger.info("File(" + path + File.separator + fileNM + ") removed !!!");
			}
		}
	}
	
	public void copyFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdirs();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(orgFile);
			fos = new FileOutputStream(destFile);
			
			int data = 0;
			while( (data = fis.read()) != -1 ) {
				fos.write(data);
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			try {
				fis.close();
				fis = null;
				fos.flush();
				fos.close();
				fos = null;
				System.gc();
			}catch(Exception e) {
				logger.info(e.getMessage());
			}
		}
		
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public void run() {

		int ret = 0;
		BufferedReader bin = null;
		StringTokenizer st = null;
		String readedLine = "";
		
		try {			
			CBICDownloaderDAO dao = new CBICDownloaderDAO();
			
			logger.info(">>>>>>> path = " + path);
			List<File> list = getDirFileList(path);
			
			for(int i = 0;i < list.size();i++ ) {
				if( !(list.get(i)).isFile() ) {
					continue;
				}
				String targetFile = list.get(i).getName();
				bin = new BufferedReader(new FileReader(path + File.separator + targetFile));
								
				while( (readedLine = bin.readLine()) != null ) {
					logger.info("[DEBUG] File Name : " + targetFile + ", readedLine = " + readedLine);
					// '\t'와'\n' 구분자로 토큰 분리
					st = new StringTokenizer(readedLine, "\t\n");
					
					int col = 0;
					Map<String, String> map = new HashMap<String, String>();

					String strHeaders[] = {
				         "TRAN_YMD"                 //거래날짜
				         ,"STORE_CODE"              //점포코드
				         ,"POS_NO"                  //포스번호
				         ,"TRAN_NO"                 //거래번호
				         ,"TRAN_DIV"                //거래구분'0'캐시백출금  '1'현금IC
				         
				         ,"MCH_SEND_UNIQ_NO"        //가맹점 주문번호 거래날짜(8)+ 점포코드(5) + POS 번호(4) + 거래번호(4) + space(19)				         
				         ,"TERMINAL_ID"             //터미널아이디 가맹점코드(3)+ 점포코드(5) + POS 번호(4) + space(5)
				         ,"TRAN_AMT"                //거래금액
				         ,"ADMIT_NO"                //승인번호
				         ,"VAN_DIV"					//van구분코드
				         
				         ,"TRAN_TYPE"               //'0' 구매 '1' 환불
				         ,"ADMIT_DATE"              //승인일자
				         ,"ADMIT_TIME"				//승인시간
				         ,"MCH_FEE"					//가맹점 수수료
				         ,"ISS_FEE"					//발급사수수료
				         				         
				         ,"BUY_FEE"					//매입사수수료				         
				         ,"VAN_FEE"					//VAN사 수수료
				         ,"CASHBACK_YN"				//캐시백 거래여부
				         ,"CASHBACK_AMT"			//캐시백금액 
				         ,"ORG_ADMIT_DATE"			// 원거래승인일자
				         
				         ,"ORG_ADMIT_NO"			//원거래승인번호 
				         //,"ORG_MCH_SEND_UNIQ_NO"	//원거래가맹점고유번호
					};
					// 각 분리된 토큰을 저장
					
					while( st.hasMoreTokens() ) {			
					//while( st.hasMoreElements() ) {
						
						map.put(strHeaders[col++], st.nextToken());
						//map.put(strHeaders[col], st.nextToken());
						
						//logger.info("☆  value[" + Integer.toString(col-1) + "] = " + map.get(strHeaders[col-1]));
						//System.out.println("☆  value[" + Integer.toString(col-1) + "] = " + map.get(strHeaders[col-1]));
						logger.info("["+ strHeaders[col-1]+"] =="+ map.get(strHeaders[col-1]));
					}
						logger.info("[neo0531 insert before ]");
						
						String tmpTD = map.get("TRAN_DIV");
						logger.info("TRAN_DIV 0:withraw , 1: buy=" + tmpTD );
						
						if ("1".equals(tmpTD)){
							logger.info("buy" );
							ret = dao.insCBICBDailyDTL(map);
						}
						else if ("0".equals(tmpTD)){
							logger.info("withdrwal" );
							ret = dao.insCBICWDailyDTL(map);
						}
						else 
							ret = -1;
					if( ret != 1 ) {
						//logger.info("["+targetFile.substring(18, 19)+"]"+"There is an Error on inserting data");
						logger.info("["+ret+"]"+"There is an Error on inserting data");
						System.out.println("["+ret+"]"+"There is an Error on inserting data");
					}					
				}
				
				bin.close();
				bin = null;

				this.moveFile(path, targetFile, path + File.separator + "backup");
				
				File fileOK = new File(path + File.separator + "backup" + File.separator + targetFile);
			    File file = new File(path + File.separator + "backup" + File.separator
			      + targetFile.substring(0, targetFile.length()-3));
			    
			    logger.info("[debug]" + path + File.separator + "backup" + File.separator + targetFile);
			    
			    fileOK.renameTo(file);//moveFile후 파일명 끝에 .ok 삭제
			    
				logger.info("Data insert OK.  FTP work well done");	
			}		
			
		}catch(Exception e) {
			logger.info("[ERROR1] " + e.getMessage());
			System.out.println("[ERROR1] " + e.getMessage());
		}finally {
			try {
				if( bin != null ) bin.close();
			}catch(Exception e) {
				logger.info("exception occur"+ e.getMessage());
				//System.out.println("exception occur"+ e.getMessage());
			}
		}
	}
}
