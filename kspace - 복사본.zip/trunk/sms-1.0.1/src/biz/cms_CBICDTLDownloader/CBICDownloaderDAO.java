package biz.cms_CBICDTLDownloader;

import java.io.File;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class CBICDownloaderDAO extends GenericDAO{
private static Logger logger = Logger.getLogger(CBICDTLDownloaderPollingAction.class);
	
	
	public int  insCBICBDailyDTL    (Map<String, String> map) {
		
		SqlWrapper sql = new SqlWrapper();
		
		int i = 0;
		int rows = -1;

		String tmp_sql = "";
		try {
		
			//transaction 발생
			begin();
		
			//DB Connection(DB 접속)
			connect("CMGNS");			

			sql.put(findQuery("service-sql", "INS_CBICBVENDAILY_TRN"));			
					logger.info("[SQL1][INS_CBICBVENDAILY_TRN]		findQuery ok"  );
			sql.setString(++i, (String)map.get("TRAN_YMD"));			//거래날짜
			sql.setString(++i, (String)map.get("STORE_CODE"));			//점포코드
			sql.setString(++i, (String)map.get("POS_NO"));				//포스번호
			sql.setString(++i, (String)map.get("TRAN_NO"));				//거래번호
			sql.setString(++i, (String)map.get("TRAN_DIV"));			//거래구분'0'캐시백출금  '1'현금IC
			
			sql.setString(++i, (String)map.get("MCH_SEND_UNIQ_NO"));	//가맹점 주문번호 거래날짜(8)+ 점포코드(5) + POS 번호(4) + 거래번호(4) + space(19)
			sql.setString(++i, (String)map.get("TERMINAL_ID"));			//터미널아이디 가맹점코드(3)+ 점포코드(5) + POS 번호(4) + space(5)
			sql.setString(++i, (String)map.get("TRAN_AMT"));			//거래금액
			sql.setString(++i, (String)map.get("ADMIT_NO"));			//승인번호
			sql.setString(++i, (String)map.get("VAN_DIV"));				//van구분코드
					
			sql.setString(++i, (String)map.get("TRAN_TYPE"));			//	'0' 구매 '1' 환불	
			sql.setString(++i, (String)map.get("ADMIT_DATE"));			//승인일자
			sql.setString(++i, (String)map.get("ADMIT_TIME"));			//승인시간
			sql.setString(++i, (String)map.get("MCH_FEE"));				//가맹점 수수료
			sql.setString(++i, (String)map.get("ISS_FEE"));				//	발급사수수료
			
			sql.setString(++i, (String)map.get("BUY_FEE"));				//매입사수수료
			sql.setString(++i, (String)map.get("VAN_FEE")); 			//VAN사 수수료 
			sql.setString(++i, (String)map.get("CASHBACK_YN"));			//캐시백 거래여부 
			sql.setString(++i, (String)map.get("CASHBACK_AMT"));		//캐시백금액
			sql.setString(++i, (String)map.get("ORG_ADMIT_DATE"));		//원거래승인일자
			
			sql.setString(++i, (String)map.get("ORG_ADMIT_NO"));		//원거래승인번호
			//sql.setString(++i, (String)map.get("ORG_MCH_SEND_UNIQ_NO"));//원거래가맹점고유번호
			
			//logger.info("[SQL1][INS_CASHBACKVENDAILY_TRN]" + sql.debug() );
			tmp_sql = sql.debug();
			//System.out.println("[SQL1][INS_CASHBACKVENDAILY_TRN]" + sql.debug() );
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			logger.info("[SQL1][INS_CBICBVENDAILY_TRN]" + tmp_sql );
			logger.info("[ERROR1] " + e.getMessage());
			//System.out.println("[ERROR1] " + e.getMessage());
			rollback();
			
		}finally {
			//transaction 종료
			end();
		}
		
		return rows;
	}
	
	
	
	public int  insCBICWDailyDTL    (Map<String, String> map) {
		
		SqlWrapper sql = new SqlWrapper();
		
		int i = 0;
		int rows = -1;

		String tmp_sql = "";
		try {
		
			//transaction 발생
			begin();
		
			//DB Connection(DB 접속)
			connect("CMGNS");			

			sql.put(findQuery("service-sql", "INS_CBICWVENDAILY_TRN"));			
					logger.info("[SQL1][INS_CBICWVENDAILY_TRN]		findQuery ok"  );
			sql.setString(++i, (String)map.get("TRAN_YMD"));			//거래날짜
			sql.setString(++i, (String)map.get("STORE_CODE"));			//점포코드
			sql.setString(++i, (String)map.get("POS_NO"));				//포스번호
			sql.setString(++i, (String)map.get("TRAN_NO"));				//거래번호
			sql.setString(++i, (String)map.get("TRAN_DIV"));			//거래구분'0'캐시백출금  '1'현금IC
			
			sql.setString(++i, (String)map.get("MCH_SEND_UNIQ_NO"));	//가맹점 주문번호 거래날짜(8)+ 점포코드(5) + POS 번호(4) + 거래번호(4) + space(19)
			sql.setString(++i, (String)map.get("TERMINAL_ID"));			//터미널아이디 가맹점코드(3)+ 점포코드(5) + POS 번호(4) + space(5)
			sql.setString(++i, (String)map.get("TRAN_AMT"));			//거래금액
			sql.setString(++i, (String)map.get("ADMIT_NO"));			//승인번호
			sql.setString(++i, (String)map.get("VAN_DIV"));				//van구분코드
					
			sql.setString(++i, (String)map.get("TRAN_TYPE"));			//	'0' 구매 '1' 환불	
			sql.setString(++i, (String)map.get("ADMIT_DATE"));			//승인일자
			sql.setString(++i, (String)map.get("ADMIT_TIME"));			//승인시간
			sql.setString(++i, (String)map.get("MCH_FEE"));				//가맹점 수수료
			sql.setString(++i, (String)map.get("ISS_FEE"));				//	발급사수수료
			
			sql.setString(++i, (String)map.get("BUY_FEE"));				//매입사수수료
			sql.setString(++i, (String)map.get("VAN_FEE")); 			//VAN사 수수료 
			sql.setString(++i, (String)map.get("CASHBACK_YN"));			//캐시백 거래여부 
			sql.setString(++i, (String)map.get("CASHBACK_AMT"));		//캐시백금액
			sql.setString(++i, (String)map.get("ORG_ADMIT_DATE"));		//원거래승인일자
			
			sql.setString(++i, (String)map.get("ORG_ADMIT_NO"));		//원거래승인번호
			//sql.setString(++i, (String)map.get("ORG_MCH_SEND_UNIQ_NO"));//원거래가맹점고유번호
			
			//logger.info("[SQL1][INS_CASHBACKVENDAILY_TRN]" + sql.debug() );
			tmp_sql = sql.debug();
			//System.out.println("[SQL1][INS_CASHBACKVENDAILY_TRN]" + sql.debug() );
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			logger.info("[SQL1][INS_CBICWVENDAILY_TRN]" + tmp_sql );
			logger.info("[ERROR1] " + e.getMessage());
			//System.out.println("[ERROR1] " + e.getMessage());
			rollback();
			
		}finally {
			//transaction 종료
			end();
		}
		
		return rows;
	}
	
	
	
	
	
}
