package biz.cms_DGBSender;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

public class DGBSenderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(DGBSenderPollingAction.class);
	
	public static void main(String args[]) throws Exception {
		DGBSenderPollingAction action = new DGBSenderPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[0]]=" + args[1] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			if( cmd.length() != 3 ) return;
			
			if( cmd.charAt(0) == '1' ) {
				System.out.println("creating DGB Payment tran file.");
				action.createDGBPAYTranFile();
			}
			
			if( cmd.charAt(1) == '1' ) {
				System.out.println("creating DGB Charge tran file.");
				action.createDGBCHGTranFile();
			}
			
			if( cmd.charAt(2) == '1' ) {
				System.out.println("transfering DGB tran files.");
				(new DGBSenderFileTransfer()).transfer();
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		DGBSenderDAO dao = new DGBSenderDAO();
		List<Object> list = null;
		int totalCnt = 0;
		
		try {
			int ret = -1;
			
			// actionMode : 0-POLLING_PERIOD에 주기적으로 무조건 수행, 1-ACTION_TIME에 한 번 수행
			logger.info("actionMode[" + actionMode + "]");
			if( actionMode == "1" ) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String stdYmd = sdf.format(new Date());
				String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
				
				//(금일 대사파일 생성 유무 조회)
				list = dao.selSVCFILEDAILY(stdYmd, "DGB", "%", com_cd);
				totalCnt = list.size();
				
				//금일 대사파일 생성 row가 없으면 생성
				if( totalCnt <= 0 ) {
					HashMap<String, String> hm = new HashMap<String, String>();
					hm.put("COM_CD", com_cd);
					hm.put("STD_YMD", stdYmd);
					hm.put("SVC_ID", "DGB");
					hm.put("CMD_TY", "00");
					
					ret = dao.insSVCFILEINFO(hm);
						
					if( ret > 0 ) {
						createDGBCHGTranFile();
						Thread.sleep(50);
						
						createDGBPAYTranFile();
						Thread.sleep(50);
						
						try {
							(new DGBSenderFileTransfer()).transfer();
						}catch(Exception e) {
							logger.info("[ERROR]" + e.getMessage());
						}
						hm.put("CMD_TY", "01");
						ret = dao.updSVCFILEINFO(hm);
					}
				}
			}else if( actionMode == "0") {
				
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	public boolean createDGBPAYTranFile() {
		boolean bIsCreatedFile = false;
		
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			DGBSenderDAO dao = new DGBSenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			//String toDay = sdf.format(calendar.getTime());
			//calendar.setTime(sdf.parse(toDay));
			calendar.setTime(new Date());
			String curDate = sdf.format(calendar.getTime());
			calendar.add(Calendar.DATE, -1);
			String adjDate = sdf.format(calendar.getTime());
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String withme_dgb_id = PropertyUtil.findProperty("service-property", "WITHME_DGB_ID"); //가맹점ID
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "dgb";
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			
			String withme_corp_no = PropertyUtil.findProperty("service-property", "WITHME_CORP_NO");
			
//			list = dao.getWITHMEBizCoNo(com_cd);제목에사업자번호넣을거가져옴
//			String strWithMeBizCoNo = (String)((Map<String, String>)list.get(0)).get("BIZCO_NO");
						
			//카드발행사정보		:ISIF####
			//온라인충전거래명세	:L3TR####	WMLT
			//온라인지불거래명세	:P3TR####	WMPT
			//온라인충전정산내역	:L3AC####	WMLC
			//온라인지불정산내역	:P3AC####	WMPC
			
			String JOB_TP = "WMPT";
			String strTRANFileNM = JOB_TP + curDate.substring(4, 8); //#### 확인
			
			list = null;
			list = dao.selDGBPAYTRAN(com_cd, card_key, double_card_key);
			int iPayCnt = list.size();
//			for(int i=0; i<=iPayCnt; i++){logger.info(list.get(i));
			logger.info("list[" + list + "]");
			// 거래내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_TP", "H");
			hmHeader.put("FILE_NM", strTRANFileNM);
			hmHeader.put("FILE_DT", curDate.substring(0, 8));
			hmHeader.put("ADJT_DT", adjDate.substring(0, 8));
			
			hmHeader.put("ID", withme_dgb_id); //가맹점ID
			hmHeader.put("FILLER", " ");
			
			String strMark = " ";
			byte[] mark = strMark.getBytes();
			mark[0] = (byte)0x0a;
			strMark = new String(mark);
			hmHeader.put("MARK", strMark); //0x0a개행문자
			
//			hmHeader.put("JOB_TP", JOB_TP);
//			hmHeader.put("FILE_CRTD_YMDHMS", curDate);
//			hmHeader.put("TRANS_CNT", String.format("%07d", iPayCnt));
//			hmHeader.put("ADJ_YMD", adjDate.substring(0, 8));
			
			sbFile.append(makeHeaderOfFile(hmHeader));
			for(int i = 0;i < iPayCnt;i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);

				hmData.put("RECORD_TP", "D");
				
				hmData.put("RECORD_NO", String.format("%08d", i + 1));
				hmData.put("STORE_ID", map.get("STORE_ID"));
				hmData.put("TRAN_ID", map.get("TRAN_ID"));
				hmData.put("DEAL_YMDHMS", map.get("DEAL_YMDHMS"));
				
				
				hmData.put("TERMINAL_ID", map.get("TERMINAL_ID"));
				hmData.put("CARD_CD", map.get("CARD_CD"));//카드사코드
				hmData.put("ALG_EP", map.get("ALG_EP"));
				hmData.put("ID_CENTER", map.get("ID_CENTER"));
				hmData.put("VK_IND_KEY2", map.get("VK_IND_KEY2"));
				
				
				hmData.put("VK_IND_KEY", map.get("VK_IND_KEY"));
				hmData.put("ID_SAM", map.get("ID_SAM"));
				hmData.put("NC_SAM", map.get("NC_SAM"));
				hmData.put("NI_SAM", map.get("NI_SAM"));
				hmData.put("TOT_SAM", String.format("%010d", Integer.parseInt(((String)map.get("TOT_SAM").trim()))));
				
				
				hmData.put("DGB_TRAN_TP", map.get("DGB_TRAN_TP"));
				hmData.put("CARD_NO", (map.get("CARD_NO").trim())); 
				hmData.put("NT_EP", String.format("%010d", Integer.parseInt((String)map.get("NT_EP").trim())));
				hmData.put("BAL_EP", String.format("%010d", Integer.parseInt((String)map.get("BAL_EP").trim())));
				hmData.put("DEAL_AMT", String.format("%010d", Integer.parseInt((String)map.get("DEAL_AMT").trim())));
				//20
				hmData.put("NT_SAM", map.get("NT_SAM"));
				hmData.put("SIGN_IND", map.get("SIGN_IND"));
				hmData.put("SIGN_IND2", map.get("SIGN_IND2"));
				hmData.put("CARD_USER_CD", map.get("CARD_USER_CD"));
				hmData.put("CARD_USER_TP", map.get("CARD_USER_TP"));				
				
				hmData.put("RID", map.get("RID"));
				hmData.put("PAY_BEF_TP", map.get("PAY_BEF_TP"));
				hmData.put("PAY_BEF_AMT", String.format("%08d", Integer.parseInt((String)map.get("PAY_BEF_AMT").trim())));
				hmData.put("PAY_BEF_NTEP", map.get("PAY_BEF_NTEP"));
				hmData.put("PAY_REQ_AMT", String.format("%08d", Integer.parseInt((String)map.get("PAY_REQ_AMT").trim())));			
				
				hmData.put("PAY_BEF_ID_SAM", map.get("PAY_BEF_ID_SAM"));
				hmData.put("PAY_BEF_NT_SAM", map.get("PAY_BEF_NT_SAM"));
				hmData.put("PAY_BEF_YMDHMS", map.get("PAY_BEF_YMDHMS"));
				hmData.put("FILLER", " ");
				hmData.put("MARK", strMark);
				logger.info("hmData " + i + " [" + hmData + "]");
				sbFile.append(makeDataOfDGBPAYFile(hmData));
			}
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			
			hmTailer.put("RECORD_TP", "T");
			hmTailer.put("FILE_NM", strTRANFileNM);
			hmTailer.put("FILE_DT", curDate.substring(0, 8));
			logger.info("Integer.toString(iPayCnt) [" + Integer.toString(iPayCnt) + "]");
			hmTailer.put("SEND_CNT", String.format("%07d", iPayCnt));    //
			logger.info("String.format('%07d', iPayCnt) [" + String.format("%07d", iPayCnt) + "]");
			hmTailer.put("FILLER", " ");
			hmTailer.put("MARK", strMark);
			logger.info("hmTailer[" + hmTailer + "]");
	
			sbFile.append(makeTailerOfDGBTranFile(hmTailer));
			// 거래내역 파일 생성                                                         
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRANFileNM);
			
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRANFileNM);
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					dao.updDGBPAYTRAN("1", (String)map.get("COM_CD"), (String)map.get("TRAN_ID"));
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
	
	public boolean createDGBCHGTranFile() {
		boolean bIsCreatedFile = false;
		
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			DGBSenderDAO dao = new DGBSenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			//String toDay = sdf.format(calendar.getTime());
			//calendar.setTime(sdf.parse(toDay));
			calendar.setTime(new Date());
			String curDate = sdf.format(calendar.getTime());
			calendar.add(Calendar.DATE, -1);
			String adjDate = sdf.format(calendar.getTime());
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			String withme_dgb_id = PropertyUtil.findProperty("service-property", "WITHME_DGB_ID");
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "dgb";
			
			list = dao.getWITHMEBizCoNo(com_cd);
			String strWithMeBizCoNo = (String)((Map<String, String>)list.get(0)).get("BIZCO_NO");
			
			//카드발행사정보		:ISIF####
			//온라인충전거래명세	:L3TR####	WMLT
			//온라인지불거래명세	:P3TR####	WMPT
			//온라인충전정산내역	:L3AC####	WMLC
			//온라인지불정산내역	:P3AC####	WMPC		
			
			String JOB_TP = "WMLT";
			String strTRANFileNM = JOB_TP + curDate.substring(4, 8); //#### 확인
			
			list = null;
			list = dao.selDGBCHGTRAN(com_cd, card_key, double_card_key);
			int iChgCnt = list.size();
			
			// 거래내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_TP", "H");
			hmHeader.put("FILE_NM", strTRANFileNM);
			hmHeader.put("FILE_DT", curDate.substring(0, 8));
			hmHeader.put("ADJT_DT", adjDate.substring(0, 8)); //String.format("%07d", iChgCnt)?
			hmHeader.put("ID", withme_dgb_id); //가맹점ID
			hmHeader.put("FILLER", " ");
			
			String strMark = " ";
			byte[] mark = strMark.getBytes();
			mark[0] = (byte)0x0a;
			strMark = new String(mark);
			hmHeader.put("MARK", strMark); //0x0a개행문자
			
			sbFile.append(makeHeaderOfFile(hmHeader));
			
			for(int i = 0;i < iChgCnt;i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				hmData.put("RECORD_TP", "D");
				hmData.put("RECORD_NO", String.format("%08d", i + 1));
				hmData.put("STORE_ID", map.get("STORE_ID"));
				hmData.put("TRAN_ID", map.get("TRAN_ID"));
				hmData.put("DEAL_YMDHMS", map.get("DEAL_YMDHMS"));
				
				hmData.put("TERMINAL_ID", map.get("TERMINAL_ID"));
				hmData.put("CARD_CD", map.get("CARD_CD"));//카드사코드
				hmData.put("CARD_NO", map.get("CARD_NO")); 
				hmData.put("NT_EP", String.format("%08d", Integer.parseInt(map.get("NT_EP").trim())));
				
				//DB레코드 업체레코드 매칭
				if(map.get("DGB_TRAN_TP").equals("40")){map.put("DGB_TRAN_TP", "41");}//반품충전
				else if(map.get("DGB_TRAN_TP").equals("80")){map.put("DGB_TRAN_TP", "02");}//충전
				else if(map.get("DGB_TRAN_TP").equals("81")){map.put("DGB_TRAN_TP", "04");}//충전취소
				else if(map.get("DGB_TRAN_TP").equals("88")){map.put("DGB_TRAN_TP", "03");}//환불
				hmData.put("DGB_TRAN_TP", map.get("DGB_TRAN_TP"));
				
				hmData.put("DEAL_AMT", String.format("%08d", Integer.parseInt((String)map.get("DEAL_AMT").trim())));
				hmData.put("CHRG_BEF_AMT", String.format("%08d", Integer.parseInt((String)map.get("CHRG_BEF_AMT").trim())));
				hmData.put("CHRG_AFT_AMT", String.format("%08d", Integer.parseInt((String)map.get("CHRG_AFT_AMT").trim())));
				hmData.put("RETURN_TP", map.get("RETURN_TP"));
				hmData.put("ORG_DEAL_UNIQ_NO", map.get("ORG_DEAL_UNIQ_NO"));
				
				hmData.put("ERR_CD", "0001");
				hmData.put("FILLER", " ");
				hmData.put("MARK", strMark);
				
				sbFile.append(makeDataOfDGBCHGFile(hmData));
			}
			
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			
			hmTailer.put("RECORD_TP", "T");                                      
			hmTailer.put("FILE_NM", strTRANFileNM);                                      
			hmTailer.put("FILE_DT", curDate.substring(0, 8));          
			logger.info("Integer.toString(iPayCnt) [" + Integer.toString(iChgCnt) + "]");
			hmTailer.put("SEND_CNT", String.format("%07d", iChgCnt));    //
			logger.info("String.format('%07d', iPayCnt) [" + String.format("%07d", iChgCnt) + "]");
			hmTailer.put("FILLER", " ");
			hmTailer.put("MARK", strMark);

			sbFile.append(makeTailerOfDGBTranFile(hmTailer));
			
			// 거래내역 파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRANFileNM);
			
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRANFileNM);
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					if("03".equals((String)map.get("DGB_TRAN_TP"))){
						dao.updDGBCHGTRAN_2("1", (String)map.get("COM_CD"), (String)map.get("TRAN_ID"));
					}else{
						dao.updDGBCHGTRAN("1", (String)map.get("COM_CD"), (String)map.get("TRAN_ID"));
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
	
	private String makeHeaderOfFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,8,8,8,8,416,1};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_NM",
			"FILE_DT",
			"ADJT_DT",
			"ID",
			
			"FILLER", 
			"MARK"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {		
//			logger.info("i:"+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		return sb.toString();
	}
	
	private String makeDataOfDGBPAYFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,8,13,18,14
					  ,10,2,2,2,2
					  ,2,16,10,5,10
					  ,2,16,10,10,10
					  ,10,8,8,2,4
					  ,10,2,8,8,8
					  ,16,8,14,180,1};
		String strHeaders[] = {
				"RECORD_TP",
				"RECORD_NO", 
				"STORE_ID",
				"TRAN_ID", 
				"DEAL_YMDHMS", 
				
				"TERMINAL_ID", 
				"CARD_CD",       
				"ALG_EP",
				"ID_CENTER", 
				"VK_IND_KEY2",
				
				"VK_IND_KEY", 
				"ID_SAM", 
				"NC_SAM", 
				"NI_SAM", 
				"TOT_SAM",
				
				"DGB_TRAN_TP",
				"CARD_NO",
				"NT_EP", 
				"BAL_EP", 
				"DEAL_AMT",
				
				"NT_SAM", 
				"SIGN_IND", 
				"SIGN_IND2", 
				"CARD_USER_CD", 
				"CARD_USER_TP", 
				
				"RID",              
				"PAY_BEF_TP", 
				"PAY_BEF_AMT",
				"PAY_BEF_NTEP", 
				"PAY_REQ_AMT", 
				
				"PAY_BEF_ID_SAM",
				"PAY_BEF_NT_SAM",
				"PAY_BEF_YMDHMS",
				"FILLER",
				"MARK"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info(i+":"+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		logger.info(sb.toString());
		return sb.toString();
	}
	
	private String makeDataOfDGBCHGFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,8,13,18,14
					  ,10,2,16,8,2
					  ,8,8,8,2,18
					  ,4,309,1};
		String strHeaders[] = {
				"RECORD_TP",      
				"RECORD_NO",      
				"STORE_ID",       
				"TRAN_ID",   
				"DEAL_YMDHMS",    
				
				"TERMINAL_ID",    
				"CARD_CD",        
				"CARD_NO",        
				"NT_EP",          
				"DGB_TRAN_TP",  
				
				"DEAL_AMT",       
				"CHRG_BEF_AMT",   
				"CHRG_AFT_AMT",   
				"RETURN_TP",      
				"ORG_DEAL_UNIQ_NO",
				
				"ERR_CD",
				"FILLER",
				"MARK"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {		
//			logger.info(i+":"+(String) hm.get(strHeaders[i].toString()));
//			System.out.println(strHeaders[i].toString()+"="+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeTailerOfDGBTranFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,8,8,7,425,	1};
		String strHeaders[] = {
			"RECORD_TP",       
			"FILE_NM",         
			"FILE_DT",         
			"SEND_CNT",        
			"FILLER",
			
			"MARK"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
//			System.out.println(strHeaders[i].toString()+"="+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
}
