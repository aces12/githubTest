package biz.cms_TMoneyIrt;

import java.util.HashMap;
import java.util.regex.Pattern;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class TMoneyIrtProtocol {
	//private static Logger logger = Logger.getLogger(TMoneyIrtProtocol.class);
	
	public int getRcvTMoneyIrtDATA(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret = 0;		
		int nlens[] = {2};
		
		String strHeaders[] = {
			"INQ_TYPE"			  // INQ Type(INQ 종별)
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if( Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE")) ){
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		
		return ret;
	}
	
	// POS에서 보낸 예치금 잔액조회 요청 전문 파싱
	public HashMap<String, String> getParseSvcDepstInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,5,2};
		String strHeaders[] = {
			"INQ_TYPE",
			"STORE_CODE",
			"SERVICE_TP"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 충전/직전충전취소/환불 요청 전문 파싱
	public HashMap<String, String> getParseTMoneyCHRGInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,20,16,2
					  ,14,2,2,10,10
					  ,10,16,8,9,7
					  ,16,10,10,10,14
					  ,20,8,5};
		String strHeaders[] = {
			"INQ_TYPE" 			,
			"COMMAND_TY" 		,
			"TRANSACTION_ID"	,
			"CARD_NO"			,
			"CARD_OWNER_ID"		,
			
			"CHRG_REQ_YMDHMS"	,
			"KEYSET_VER"		,
			"ALGM_ID"			,
			"CARD_DEAL_SNO"		,
			"CHRG_BEF_RAMT"		,
			
			"CHRG_REQ_AMT"		,
			"RAND_NUM"			,
			"SIGN1_VAL"			,
			"TERMINAL_ID"		,
			"MEMBER_ID"			,
			
			"ORG_SAM_ID"		,
			"ORG_SAM_DEAL_SNO"	,
			"ORG_CARD_DEAL_SNO"	,
			"ORG_CHRG_AMT"		,
			"ORG_SALEDATE"		,
			
			"ORG_TRANSACTION_ID",
			"ORG_POS_SALEDATE"	,
			"ORG_POS_BILL_NO"
		};
		
		//logger.info("▶ getParseTMoneyCHRGInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// 티머니에서 보낸 충전/직전충전취소/환불 응답 전문 파싱
	public HashMap<String, String> getParseTMoneyCHRGRsp(String rcvBuf, COMMLog df) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,50,20,16
					  ,16,10,2,14,2
					  ,2,10,10,10,10
					  ,10,10,10,16,8
					  ,9,7,14,4,4
					  ,2,30,100};
		String strHeaders[] = {
			"COMMAND_TY" ,
			"RECORD_LEN" ,
			"MEMBER_USE_FIELD" ,
			"TRANSACTION_ID" ,
			"CARD_NO" ,
			
			"SAM_ID" ,
			"SAM_DEAL_SNO" ,
			"CARD_OWNER_ID" ,
			"CHRG_REQ_YMDHMS" ,
			"KEYSET_VER" ,
			
			"ALGM_ID" ,
			"CARD_DEAL_SNO" ,
			"CHRG_BEF_RAMT" ,
			"CHRG_REQ_AMT" ,
			"CHRG_AFT_RAMT" ,
			
			"CHRG_FEE" ,
			"CARD_DEPOSIT" ,
			"PENALTY_AMT" ,
			"RAND_NUM" ,
			"SIGN2_VAL" ,
			
			"TERMINAL_ID" ,
			"MEMBER_ID" ,
			"CHRG_DEAL_YMDHMS" ,
			"CARD_STATUS_CD" ,
			"TERMINAL_STATUS_CD" ,
			
			"RES_CD" ,
			"ERR_MSG" ,
			"FILLER"
		};
		
//		df.CommLogger( "▶ getParseTMoneyCHRGRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 충전/직전충전취소/환불 완료 전문 파싱
	public HashMap<String, String> getParseTMoneyCHRGCompleteInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,20,16,16
					  ,10,2,14,2,2
					  ,10,10,10,10,10
					  ,10,10,16,8,9
					  ,7,14,4,4,2
					  ,30};
		String strHeaders[] = {
			"INQ_TYPE" ,
			"COMMAND_TY" ,
			"TRANSACTION_ID" ,
			"CARD_NO" ,
			"SAM_ID" ,
			
			"SAM_DEAL_SNO" ,
			"CARD_OWNER_ID" ,
			"CHRG_REQ_YMDHMS" ,
			"KEYSET_VER" ,
			"ALGM_ID" ,
			
			"CARD_DEAL_SNO" ,
			"CHRG_BEF_RAMT" ,
			"CHRG_REQ_AMT" ,
			"CHRG_AFT_RAMT" ,
			"CHRG_FEE" ,
			
			"CARD_DEPOSIT" ,
			"PENALTY_AMT" ,
			"RAND_NUM" ,
			"SIGN2_VAL" ,
			"TERMINAL_ID" ,
			
			"MEMBER_ID" ,
			"CHRG_DEAL_YMDHMS" ,
			"CARD_STATUS_CD" ,
			"TERMINAL_STATUS_CD" ,
			"RES_CD" ,
			
			"ERR_MSG"
		};
		
		//logger.info("▶ getParseTMoneyCHRGCompleteInq-" + rcvBuf );
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
	// POS에서 보낸 권종변경 요청 전문 파싱
	public HashMap<String, String> getParseTMoneyCardTPCHGInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,20,2,2
					  ,2,2,2,10,2
					  ,16,10,16,8,14
					  ,8,20,20,20,2
					  ,9,7,7};
		
		String strHeaders[] = {
			"INQ_TYPE" ,
			"COMMAND_TY" ,
			"TRANSACTION_ID",
			"INSTITUTION_ID" ,
			"REQ_JOB_ID" ,
			
			"SYSTEM_ID" ,
			"ALGM_ID" ,
			"KEY_VER" ,
			"CARD_RAMT" ,
			"KEYSET_VER" ,
			
			"CARD_NO" ,
			"CARD_DEAL_SNO" ,
			"RAND_NUM" ,
			"SIGN1_VAL" ,
			"INST_REQ_YMDHMS" ,
			
			"BEF_PARAM_DATA" ,
			"WORK_INFO1" ,
			"WORK_INFO2" ,
			"WORK_INFO3" ,
			"WORK_INFO4" ,
			
			"TERMINAL_ID" ,
			"MEMBER_ID" ,
			"CARD_PUB_ID"
		};
		
		//logger.info("▶ getParseTMoneyCHRGCompleteInq-" + rcvBuf );
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
	// 티머니에서 보낸 권종변경 승인 전문 파싱
	public HashMap<String, String> getParseTMoneyCardTPCHGRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,20,2,2
					  ,2,16,10,32,8
					  ,14,2,30,9,7
					  ,7,35};
		
		String strHeaders[] = {
			"COMMAND_TY",
			"RECORD_LEN",
			"TRANSACTION_ID",
			"INSTITUTION_ID",
			"REQ_JOB_ID",
			
			"SYSTEM_ID",
			"SAM_ID",
			"SAM_DEAL_SNO",
			"ENCODED_PARAM_VAL",
			"SIGN2_VAL",
			
			"KSCC_RSP_YMDHMS",
			"RES_CD",
			"ERR_MSG",
			"TERMINAL_ID",
			"MEMBER_ID",
			
			"CARD_PUB_ID",
			"FILLER"
		};
		
		//logger.info("▶ getParseTMoneyCardTPCHGRsp-" + rcvBuf );
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
	// POS에서 보낸 권종변경 결과 전문 파싱
	public HashMap<String, String> getParseTMoneyTPCHGCompleteInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,20,2,2
					  ,2,8,14,8,4
					  ,2,30,9,7,7};
		
		String strHeaders[] = {
			"INQ_TYPE",
			"COMMAND_TY",
			"TRANSACTION_ID",
			"INSTITUTION_ID",
			"REQ_JOB_ID",
			
			"SYSTEM_ID",
			"SIGN3_VAL",
			"UPDATE_YMDHMS",
			"FINAL_PARAM_VAL",
			"CARD_STATUS_CD",
			
			"RES_CD",
			"ERR_MSG",
			"TERMINAL_ID",
			"MEMBER_ID",
			"CARD_PUB_ID"
		};
		
		//logger.info("▶ getParseTMoneyCardTPCHGRsp-" + rcvBuf );
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
	// POS에서 보낸 단말기ID/SAM ID 정보 전송 전문 파싱
	public HashMap<String, String> getParseTMoneyClientInfoSnd(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,7,9,16};
		
		String strHeaders[] = {
			"INQ_TYPE",
			"MEMBER_ID",
			"TERMINAL_ID",
			"SAM_ID"
		};
		
		//logger.info("▶ getParseTMoneyCardTPCHGRsp-" + rcvBuf );
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
}