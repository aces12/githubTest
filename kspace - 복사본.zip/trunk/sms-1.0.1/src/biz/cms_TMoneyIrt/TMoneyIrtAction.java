package biz.cms_TMoneyIrt;

import java.util.HashMap;
import java.net.Socket;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class TMoneyIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(TMoneyIrtAction.class);
	
	private String server_ip = "";
	private int server_port = 0;
	
	/**
	 * Receive data from SC through 9012 PORT(SC로부터 데이타를 9012 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(ActionSocket actionSocket) throws Exception {
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		TMoneyIrtDAO dao = new TMoneyIrtDAO();
		TMoneyIrtProtocol protocol = new TMoneyIrtProtocol();
		COMMLog df = new COMMLog();
		
		Socket extClntSock = null;
		TMoneyIrtConveyer conveyer = null;
		this.server_ip = PropertyUtil.findProperty("communication-property", "TMONEY_COMM_IP");
		this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "TMONEY_COMM_PORT"));
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress()
					.getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,
					"TMoneyIRT");
			
			df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지
			// 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}

			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			inq_type = protocol.getRcvTMoneyIrtDATA(rcvDataBuf);
			switch(inq_type) {
				// 30: 예치금 조회
				case 30:
					df.execute("TMoneyIrt-SVCDEPST");
					hmData = protocol.getParseSvcDepstInq(rcvDataBuf);
					dataMsg = dao.getSvcDepstInq(hmCommon, hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 단말기 ID/SAM ID 정보 전송 전문
				case 40:
					df.execute("TMoneyIrt-TML ID/SAM ID");
					hmData = protocol.getParseTMoneyClientInfoSnd(rcvDataBuf);
					
					dataMsg = dao.getTMoneyClientInfo(hmCommon, hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 충전/충전오류보정/직전충전취소/환불/지불취소(반품충전) 요청 전문
				case 41:
					df.execute("TMoneyIrt-CHRG");
					hmData = protocol.getParseTMoneyCHRGInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new TMoneyIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getTMoneyCHRGInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 충전/충전직전취소/환불/지불취소(반품충전) 완료 전문
				case 42:
					df.execute("TMoneyIrt-CHRGComplete");
					hmData = protocol.getParseTMoneyCHRGCompleteInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new TMoneyIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getTMoneyCHRGCompleteInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = "";
					break;
				// 권종변경 요청 전문
				case 51:
					df.execute("TMoneyIrt-CardTPCHG");
					hmData = protocol.getParseTMoneyCardTPCHGInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new TMoneyIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getTMoneyCardTPCHGInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 권종변경 결과 전문
				case 52:
					df.execute("TMoneyIrt-CardTPCHGComplete");
					hmData = protocol.getParseTMoneyTPCHGCompleteInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new TMoneyIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getTMoneyCardTPCHGComplete(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				default:
					df.CommLogger("▶ INQ Type Code(INQ 종별 코드):   [" + inq_type
							+ "]" + rcvBuf.length());
					ret = 99;
					break;
			}
		}catch(Exception e) {
			ret = 29;
			retValue = "[ERROR]2:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			if( extClntSock != null ) {
				extClntSock.close();
			}
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "]:[INQ_TYPE:]:[" + totalMsg + "]");
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(totalMsg)) {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		}catch(Exception e) {
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("TMoneyIRT", retValue);
		}
	}
}