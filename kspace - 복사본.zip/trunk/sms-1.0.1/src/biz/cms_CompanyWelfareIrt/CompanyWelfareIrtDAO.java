package biz.cms_CompanyWelfareIrt;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMLog;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;

public class CompanyWelfareIrtDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(CompanyWelfareIrtAction.class);
	CompanyWelfareIrtProtocol CompanyWelfareIrtProtocol = new CompanyWelfareIrtProtocol(); 
	/**
	 * 관계사 식대 - 승인
	 */
	public String getCompanyWelfareApprInfo(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();			
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
		int rows = -1;
		
		String dataMsg = "";		
		String ret = "00";
		
		try {
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			begin();

			logger.info("hm [" + hm + "]");
			logger.info("STORE_CD [" + (String)hm.get("STORE_CD") + "]");
			logger.info("COM_CD [" + "1002" + "]");
			logger.info("EMPLOYEE_ID [" + (String)hm.get("EMPLOYEE_ID") + "]");
			logger.info("COMP_CD [" + (String)hm.get("COMP_CD") + "]");
			logger.info("REQ_TYPE [" + (String)hm.get("REQ_TYPE") + "]");
			logger.info("PAY_AMT[" + (String)hm.get("PAY_AMT") + "] ");
			logger.info("CTL_TRAN_NO [" + (String)hm.get("CTL_TRAN_NO") + "]");
			
			sql.put(findQuery("service-sql", "SEL_COMPANY_WELFARE_INFO"));
			sql.setString(++i, "0");     						// 
			sql.setString(++i, "0");     						// 
			sql.setString(++i, (String)hm.get("COMP_CD"));      // 소속사 코드
			sql.setString(++i, "1002");   // 회사코드
			sql.setString(++i, (String)hm.get("COMP_CD"));      // 소속사 코드
			sql.setString(++i, (String)hm.get("EMPLOYEE_ID"));  // 사번

			logger.info("sql[" + sql + "] ");
			logger.info("sql.toString()[" + sql.toString() + "] ");
			logger.info("sql.debug()[" + sql.debug() + "] ");
			
			list = executeQuery(sql);
			logger.info("list[" + list + "] ");
			logger.info("list.size()[" + list.size() + "] ");
			if( list.size() == 1 ) {
				map = (Map)list.get(0);
				if(("0000".equals((String)map.get("RESP_CODE")))){
					hm.put("RESP_CODE", (String)map.get("RESP_CODE"));  // 응답코드
					hm.put("RESP_MSG", "정상");    						// 응답메시지
					hm.put("USE_CNT", (String)map.get("USE_CNT"));      // 사용횟수
					hm.put("USE_AMT", (String)map.get("USE_AMT"));      // 사용금액	
				}else{
					hm.put("RESP_CODE", "0001"); // 응답코드       
					hm.put("RESP_MSG", "거래 가능한 회사 혹은 시간이 아닙니다.");      // 응답메시지     
					hm.put("USE_CNT", "");       // 사용횟수      
					hm.put("USE_AMT", "");       // 사용금액      
				}
			} else if(list.size() == 0) {
				hm.put("RESP_CODE", "0002"); // 응답코드       
				hm.put("RESP_MSG", "조회 오류");      // 응답메시지     
				hm.put("USE_CNT", "");       // 사용횟수      
				hm.put("USE_AMT", "");       // 사용금액      
			}else {
				hm.put("RESP_CODE", "0003"); // 응답코드       
				hm.put("RESP_MSG", "조회 오류");      // 응답메시지     
				hm.put("USE_CNT", "");       // 사용횟수      
				hm.put("USE_AMT", "");       // 사용금액      
			}
			logger.info("hm" + hm + "] ");
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			dataMsg = ret + CompanyWelfareIrtProtocol.makeSendDataStrStockNow(hm, df);
			logger.info("dataMsg" + dataMsg + "] ");
			end();
		}
		
		return dataMsg;
	}
	
	/**
	 * 관계사 식대 - 승인요청
	 */
	public String getCompanyWelfareApprReq(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();			
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
		int rows = -1;
		
		String dataMsg = "";		
		String ret = "00";
		
		try {
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			begin();

			logger.info("hm [" + hm + "]");
			logger.info("STORE_CD [" + (String)hm.get("STORE_CD") + "]");
			logger.info("COM_CD [" + "1002" + "]");
			logger.info("EMPLOYEE_ID [" + (String)hm.get("EMPLOYEE_ID") + "]");
			logger.info("COMP_CD [" + (String)hm.get("COMP_CD") + "]");
			logger.info("REQ_TYPE [" + (String)hm.get("REQ_TYPE") + "]");
			logger.info("PAY_AMT[" + (String)hm.get("PAY_AMT") + "] ");
			logger.info("CTL_TRAN_NO [" + (String)hm.get("CTL_TRAN_NO") + "]");
			
			sql.put(findQuery("service-sql", "SEL_COMPANY_WELFARE_INFO"));
			sql.setString(++i, (String)hm.get("PAY_AMT"));     // 결제요청금액
			sql.setString(++i, "1");     					   // 사용가능횟수
			sql.setString(++i, (String)hm.get("COMP_CD"));      // 소속사 코드
			sql.setString(++i, "1002");   // 회사코드
			sql.setString(++i, (String)hm.get("COMP_CD"));      // 소속사 코드
			sql.setString(++i, (String)hm.get("EMPLOYEE_ID"));  // 사번

			logger.info("sql[" + sql + "] ");
			logger.info("sql.toString()[" + sql.toString() + "] ");
			logger.info("sql.debug()[" + sql.debug() + "] ");
			
			list = executeQuery(sql);
			logger.info("list[" + list + "] ");
			logger.info("list.size()[" + list.size() + "] ");
			if( list.size() == 1 ) {
				map = (Map)list.get(0);
				hm.put("RESP_CODE", (String)map.get("RESP_CODE"));  // 응답코드
				hm.put("RESP_MSG", "정상");    						// 응답메시지
				hm.put("USE_CNT", (String)map.get("USE_CNT"));      // 사용횟수
				hm.put("USE_AMT", (String)map.get("USE_AMT"));      // 사용금액	
				if("0000".equals((String)map.get("RESP_CODE")) && Integer.parseInt(map.get("USE_CNT")) >= 0 && Integer.parseInt(map.get("USE_AMT")) >= 0){
	
					logger.info("TRAN_DT[" + (String)hm.get("TRAN_DT") + "] ");
					logger.info("COM_CD[" +  "1002" + "] ");
					logger.info("COMP_CD[" + (String)hm.get("COMP_CD") + "] ");
					logger.info("EMPLOYEE_ID[" + (String)hm.get("EMPLOYEE_ID") + "] ");
					logger.info("REQ_TRANNO" + (String)hm.get("CTL_TRAN_NO") + "] ");
					logger.info("REQ_TYPE[" + (String)hm.get("REQ_TYPE") + "] ");
					logger.info("PAY_AMT[" + (String)hm.get("PAY_AMT") + "] ");
					logger.info("등록/수정자 ID[" + (String)hm.get("STORE_CD")+(String)hm.get("POS_NO")+"0001" + "] ");
					
					// sql 초기화
					sql.close();
					i = 0;
					
					sql.put(findQuery("service-sql", "INS_COMPANY_WELFARE_HIST"));
					sql.setString(++i, (String)hm.get("TRAN_DT"));                        		                            // 거래일시
					sql.setString(++i, "1002"); 													    // 회사코드
					sql.setString(++i, (String)hm.get("COMP_CD"));                                                	        // 소속사코드
					sql.setString(++i, (String)hm.get("EMPLOYEE_ID"));                                                      // 사번
					sql.setString(++i, (String)hm.get("CTL_TRAN_NO"));                                                      // 거래요청번호
					sql.setString(++i, (String)hm.get("REQ_TYPE"));													        // 요청구분 0:승인요청 1:취소 2:망취소
					sql.setString(++i, (String)hm.get("PAY_AMT"));													        // 결제요청금액
					sql.setString(++i, (String)hm.get("STORE_CD")+(String)hm.get("POS_NO")+"0005");  // 등록/수정자 ID 
					sql.setString(++i, (String)hm.get("STORE_CD")+(String)hm.get("POS_NO")+"0005");  // 등록/수정자 ID
	
					logger.info("sql[" + sql + "] ");
					logger.info("sql.toString()[" + sql.toString() + "] ");
					logger.info("sql.debug()[" + sql.debug() + "] ");
					rows = executeUpdate(sql);
					logger.info("rows[" + rows + "] ");
					
					if(rows == 0){
						hm.put("RESP_CODE", "0010"); // 응답코드       
						hm.put("RESP_MSG", "이력 생성 오류");      // 응답메시지     
						hm.put("USE_CNT", "");       // 사용횟수      
						hm.put("USE_AMT", "");       // 사용금액      
						rollback();
					}else if(rows > 1){
						hm.put("RESP_CODE", "0011"); // 응답코드       
						hm.put("RESP_MSG", "이력 생성 오류");      // 응답메시지     
						hm.put("USE_CNT", "");       // 사용횟수      
						hm.put("USE_AMT", "");       // 사용금액      
						rollback();
					}
				}else if(!"0000".equals((String)map.get("RESP_CODE"))){
					hm.put("RESP_CODE", "0012");  // 응답코드
					hm.put("RESP_MSG", "거래 가능한 회사 혹은 시간이 아닙니다.");  // 응답메시지
					logger.info("RESP_CODE[0006]");
				}else if(Integer.parseInt(map.get("USE_CNT")) < 0){
					hm.put("RESP_CODE", "0013");  // 응답코드
					hm.put("RESP_MSG", "이용가능 횟수가 초과 되었습니다.");  // 응답메시지
					logger.info("RESP_CODE[0007]");
				}else if(Integer.parseInt(map.get("USE_AMT")) < 0){
					hm.put("RESP_CODE", "0014");  // 응답코드
					hm.put("RESP_MSG", "이용가능 금액이 초과 되었습니다.");  // 응답메시지
				    logger.info("RESP_CODE[0008]");
				}else{
					hm.put("RESP_CODE", "0015");  // 응답코드
				}
			} else {
				hm.put("RESP_CODE", "0016"); // 응답코드       
				hm.put("RESP_MSG", "-");      // 응답메시지     
				hm.put("USE_CNT", "");       // 사용횟수      
				hm.put("USE_AMT", "");       // 사용금액      
			}
			logger.info("hm" + hm + "] ");
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			logger.info("finally");
			dataMsg = ret + CompanyWelfareIrtProtocol.makeSendDataStrStockNow(hm, df);
			logger.info("dataMsg" + dataMsg + "] ");
			end();
		}
		
		return dataMsg;
	}

	/**
	 * 관계사 식대 - 취소
	 */
	public String getCompanyWelfareRetr(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();		
		List<Object> list = null;
		int i = 0;
		int rows = -1;
		
		String dataMsg = "";		
		String ret = "00";
		
		try {
			// DB Connection(DB 접속)
			connect("CMGNS");

			logger.info("hm [" + hm + "]");
			logger.info("STORE_CD [" + (String)hm.get("STORE_CD") + "]");
			logger.info("COM_CD [" + "1002" + "]");
			logger.info("EMPLOYEE_ID [" + (String)hm.get("EMPLOYEE_ID") + "]");
			logger.info("COMP_CD [" + (String)hm.get("COMP_CD") + "]");
			logger.info("REQ_TYPE [" + (String)hm.get("REQ_TYPE") + "]");
			logger.info("CTL_TRAN_NO [" + (String)hm.get("CTL_TRAN_NO") + "]");

			begin();
			
			sql.put(findQuery("service-sql", "UPD_COMPANY_WELFARE_HIST"));
			sql.setString(++i, (String)hm.get("REQ_TYPE"));                                                         // 요청구분 0:승인요청 1:취소 2:망취소         
			sql.setString(++i, (String)hm.get("STORE_CD")+(String)hm.get("POS_NO")+"0005");  // 등록/수정자 ID                      
			sql.setString(++i, (String)hm.get("TRAN_DT"));                                                          // 거래일시                           
			sql.setString(++i, "1002");                                                       // 회사코드                           
			sql.setString(++i, (String)hm.get("COMP_CD"));                                                          // 소속사코드                          
			sql.setString(++i, (String)hm.get("EMPLOYEE_ID"));                                                      // 사번                             
			sql.setString(++i, (String)hm.get("CTL_TRAN_NO"));                                                       // 거래번호                           

			logger.info("sql[" + sql + "] ");
			logger.info("sql.toString()[" + sql.toString() + "] ");
			logger.info("sql.debug()[" + sql.debug() + "] ");

			rows = executeUpdate(sql);
			logger.info("rows[" + rows + "] ");
			
			if( rows == 1 ) {			
				hm.put("RESP_CODE", "0000"); // 응답코드       
				hm.put("RESP_MSG", "정상");   // 응답메시지 
				hm.put("USE_CNT", "");       // 사용횟수      
				hm.put("USE_AMT", "");       // 사용금액      
			}else if(rows == 0){
				hm.put("RESP_CODE", "0020"); // 응답코드       
				hm.put("RESP_MSG", "이력 생성 오류");      // 응답메시지     
				hm.put("USE_CNT", "");       // 사용횟수      
				hm.put("USE_AMT", "");       // 사용금액      
				rollback();
			}else if(rows > 1){
				hm.put("RESP_CODE", "0021"); // 응답코드       
				hm.put("RESP_MSG", "이력 생성 오류");      // 응답메시지     
				hm.put("USE_CNT", "");       // 사용횟수      
				hm.put("USE_AMT", "");       // 사용금액      
				rollback();
			}
			
			logger.info("hm" + hm + "] ");
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			dataMsg = ret + CompanyWelfareIrtProtocol.makeSendDataStrStockNow(hm, df);
			logger.info("dataMsg" + dataMsg + "] ");
			end();
		}
		
		return dataMsg;
	}
}
