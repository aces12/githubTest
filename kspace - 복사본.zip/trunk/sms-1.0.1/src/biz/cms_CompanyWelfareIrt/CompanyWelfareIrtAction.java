package biz.cms_CompanyWelfareIrt;

import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;

import org.apache.log4j.Logger;

import biz.cms_CompanyWelfareIrt.CompanyWelfareIrtProtocol;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class CompanyWelfareIrtAction extends ServerAction {

	private static Logger logger = Logger.getLogger(CompanyWelfareIrtAction.class);		
	
	public void execute(ActionSocket actionSocket) throws Exception {
		
		int ret = 0; //결과값
		int inq_type = 0; //구분자
		
		String sendMsg = ""; 
		String dataMsg = ""; 
		String totalRcvBuf = ""; 
		String rcvDataBuf = ""; 
		String retValue = "OK!"; 
		HashMap<String, String> hmCommon = new HashMap<String, String>(); 
		HashMap<String, String> hmData = new HashMap<String, String>(); 
		CompanyWelfareIrtProtocol CompanyWelfareIrtProtocol = new CompanyWelfareIrtProtocol(); 
		CompanyWelfareIrtDAO dao = new CompanyWelfareIrtDAO();
		COMMLog df = new COMMLog(); //로그		
		
		try{
			totalRcvBuf = ((String) actionSocket.receive()); 
			logger.info("totalRcvBuf [" + totalRcvBuf + "]");
			
			if( totalRcvBuf.length() < COMMBiz.CM_LENS + 2 ) return; // 길이 검증
			
			df.setStartTime(); 
			
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,	"COMPANYWELFARE");
			
			hmCommon = COMMBiz.getData(totalRcvBuf, COMMBiz.CM_HEADER);
			logger.info("hmCommon [" + hmCommon + "]");
						
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) { 
				return;
			}
			logger.info("MSG_LEN [" + hmCommon.get("MSG_LEN") + "]");
			
			rcvDataBuf = totalRcvBuf.substring(COMMBiz.CM_LENS); 
			logger.info("rcvDataBuf [" + rcvDataBuf + "]");
			
			logger.info("CompanyWelfareIrtProtocol.getCompanyWelfareIrtInq(rcvDataBuf [" + CompanyWelfareIrtProtocol.getCompanyWelfareIrtInq(rcvDataBuf) + "]");
			
			inq_type = COMMBiz.getInqTypeCHG(CompanyWelfareIrtProtocol.getCompanyWelfareIrtInq(rcvDataBuf));
			logger.info("inq_type [" + inq_type + "]");
			
			switch(inq_type) {//승인요청
			case 2069: //승인(A6)
				//df.execute("INQ_COMPANYWELFAREIRT_APPR_INFO");
				logger.info("INQ_COMPANYWELFAREIRT_APPR_INFO");
				hmData = CompanyWelfareIrtProtocol.getCompanyWelfareReqsvr(rcvDataBuf);
				logger.info("hmData [" + hmData + "]");
				dataMsg = dao.getCompanyWelfareApprInfo(hmCommon, hmData, df);
				logger.info("dataMsg [" + dataMsg + "]");
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				logger.info("ret [" + ret + "]");
				dataMsg = dataMsg.substring(2);
				logger.info("dataMsg [" + dataMsg + "]");
				break;
			case 2070: //승인(A7)
				//df.execute("INQ_COMPANYWELFAREIRT_APPR_REQ");
				logger.info("INQ_COMPANYWELFAREIRT_APPR_REQ");
				hmData = CompanyWelfareIrtProtocol.getCompanyWelfareReqsvr(rcvDataBuf);
				logger.info("hmData [" + hmData + "]");
				dataMsg = dao.getCompanyWelfareApprReq(hmCommon, hmData, df);
				logger.info("dataMsg [" + dataMsg + "]");
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				logger.info("ret [" + ret + "]");
				dataMsg = dataMsg.substring(2);
				logger.info("dataMsg [" + dataMsg + "]");
				break;
			case 2071: //취소(A8)
				//df.execute("INQ_COMPANYWELFAREIRT_REQR");
				logger.info("INQ_COMPANYWELFAREIRT_REQR");
				hmData = CompanyWelfareIrtProtocol.getCompanyWelfareReqsvr(rcvDataBuf);
				logger.info("hmData [" + hmData + "]");
				dataMsg = dao.getCompanyWelfareRetr(hmCommon, hmData, df);
				logger.info("dataMsg [" + dataMsg + "]");
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				logger.info("ret [" + ret + "]");
				dataMsg = dataMsg.substring(2);
				logger.info("dataMsg [" + dataMsg + "]");
				break;
				}
			}catch(Exception e) {
				ret = 29;
				retValue = "[ERROR]2:" + e.getMessage();
				df.CommLogger("▶ " + retValue);
			}finally {  }

			try{// Make Response Message Data(응답 전문데이타 만들기)
				sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
				logger.info("sendMsg [" + sendMsg + "]");
				String totalMsg = sendMsg + dataMsg;
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + totalMsg + "]");
				// Send Response Data(응답 데이타 전송)
				if (actionSocket.send(totalMsg)) {
					df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] OK");
				} else {
					df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] ERROR");
				}
			}catch(Exception e) {
				retValue = "[ERROR] " + e.getMessage();
				df.CommLogger("▶ " + retValue);
			}finally {
				// IRT Work Finish Log(IRT 업무 종료 로그)
				df.close("CompanyWelfareIrt", retValue);
			}
		}
}
