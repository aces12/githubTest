package biz.cms_PURCARDDTLDownloader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;



public class PURCARDDTLDownloaderInst extends Thread {
	private static Logger logger = Logger.getLogger(PURCARDDTLDownloaderPollingAction.class);
	
	String path = "";
	String stdDate = "";
	String stdDate1 = "";
	
	PURCARDDTLDownloaderPollingAction action = null;
	
	private final int LENGTH_BY_RSLT_RECORD = 260;
	
	public PURCARDDTLDownloaderInst(String path, PURCARDDTLDownloaderPollingAction action, String stdDate, String stdDate1) {
		this.path = path;
		this.action = action;
		this.stdDate = stdDate;
		this.stdDate1 = stdDate1;
	}
	
	public List<File> getDirFileList(String dirPath) {
		System.out.println("dirPath = " + dirPath );
		List<File> dirFileList = null;
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public void run() {
		try {
			logger.info("===============Insert START====================" );
			List<File> list = getDirFileList(path);
			System.out.println("list.size() = " + list.size() );
			
			for(int i = 0;i < list.size();i++) {
				if( !(list.get(i)).isFile() ) {
					continue;
				}else if( (list.get(i)).length() == 0 ){
					continue;
				}
				String targetFile = list.get(i).getName();
				
				/*Calendar calendar = new GregorianCalendar(Locale.KOREA);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				calendar.setTime(new Date());
				String stdDate = sdf.format(calendar.getTime());
				calendar.add(Calendar.DATE, -1);
				String stdDate1 = sdf.format(calendar.getTime());*/
				
				logger.info("[INFO] file:" + targetFile);
				
				if( (targetFile.substring(0, 8)).equals(stdDate) &&targetFile.length() == 12 ) {
					logger.info("[INFO] start.");
					int len = 0;
					int totLen = 0;
					String adjtDT = targetFile.substring(0, 8);
					long fileSize = (list.get(i)).length();
					
					byte buf[] = new byte[(int)fileSize];
					InputStream is = new FileInputStream(list.get(i));
					
					StringBuffer sb = new StringBuffer();
					
					while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
						sb.append(new String(buf));
						totLen += len;
						if( totLen == fileSize ) {
							break;
						}
					}
					
					is.close();
					logger.info("targetFile.length():" + targetFile.length());
					logger.info("targetFile.substring(8, 12)) :" + targetFile.substring(8, 12));
					logger.info("adjtDT :" + adjtDT);
					if( (targetFile.substring(8, 12)).equals("_ATC") ) { 		// 승인결과전문
						this.insertDB(1, sb.toString(), adjtDT);
					}
				} 
				if( (targetFile.substring(0, 8)).equals(stdDate1) &&targetFile.length() == 12 ) {
					logger.info("start");
					int len = 0;
					int totLen = 0;
					//String adjtDT = targetFile.substring(0, 8);
					System.out.println("adjtDT:" + stdDate);
					
					long fileSize = (list.get(i)).length();
					
					byte buf[] = new byte[(int)fileSize];
					InputStream is = new FileInputStream(list.get(i));
					
					StringBuffer sb = new StringBuffer();
					
					while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
						sb.append(new String(buf));
						totLen += len;
						if( totLen == fileSize ) {
							break;
						}
					}
					
					is.close();
					logger.info("targetFile.length():" + targetFile.length());
					logger.info("targetFile.substring(8, 12)) :" + targetFile.substring(8, 12));
					logger.info("adjtDT :" + stdDate);
					if( (targetFile.substring(8, 12)).equals("_DEF") ) {	// 입금금액전문
						this.insertDB(2, sb.toString(), stdDate);
					}else if( (targetFile.substring(8, 12)).equals("_ACQ") ) {	// 카드발급전문
						this.insertDB(3, sb.toString(), stdDate);
					}
				} 
				// 파일 옮기기...
				this.moveFile(path, targetFile, path + File.separator + "backup");
				System.out.println("[DEBUG] File " + targetFile + " was moved.");
				logger.info("[DEBUG] File " + targetFile + " was moved.");
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertDB(int type, String readData, String adjtDT) {
		try {
			System.out.println("start insertDB");
			HashMap<String, String> hm = new HashMap<String, String>();
			PURCARDDTLDownloaderDAO dao = new PURCARDDTLDownloaderDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			
			logger.info("bytes.length :" + bytes.length);
			for(int i = 1;totLen < bytes.length;i++) {

				
				if( type == 1 ) {
					String strRecord = new String(bytes, (i*117), 116);
					hm = getPURCARDSale(strRecord);
					
					logger.info(hm);
					totLen = (i*117) + 117;
				}
				else if( type == 2 ) {
					String strRecord = new String(bytes, 14 + ((i-1)*147), 146);
					hm = getPURCARDDepo(strRecord);
					totLen = (i*147) + 14;
				}
				else if( type == 3 ) {
					String strRecord = new String(bytes, 14 + ((i-1)*49), 48);
					hm = getPURCARDMst(strRecord);
					totLen = (i*49) + 14;
				}
				hm.put("CO_CD", com_cd);
				hm.put("CRT_YMD", adjtDT);
				
				try {
					dao.insPURCARDRslt(type, hm);
				}catch(Exception e) {
					System.out.println("[ERROR] Error for inserting data : " + e.getMessage());
					logger.info("[ERROR] Error for inserting data : " + e.getMessage());
				}
			}
			if(type == 1) dao.spBATCHCARDLOANREC("1");
			else if(type == 2) dao.spBATCHCARDLOANREC("2");
		}catch(Exception e) {
			System.out.println("[ERROR] " + e.getMessage());
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private HashMap<String, String> getPURCARDSale(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {12,11,5,18,8
				  ,8,8,6,4,18
				  ,18};
		String strHeaders[] = {
				"OFF_ID",
				"CARD_STR_ID",
				"MON_CNT",
				"CONF_AMT",
				"YMD1",
				
				"YMD2",
				"YMD3",
				"CONT_ID",
				"CODE",
				"AMT",
				
				"AMT2"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getPURCARDDepo(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {11, 8, 18, 18, 18,
					   18, 1, 18, 18 ,18};
		String strHeaders[] = {
			"CARD_STR_ID",
			"CONF_YMD",
			"CARD_AMT",
			"CARD_AMT_ORI",
			"CARD_AMT_OVER_FEE",
			
			"CARD_OVER_AMT",
			"OVER_FLAG",			
			"OVER_AMT_ORI",
			"OVER_FEE",
			"OVER_AMT"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}

	private HashMap<String, String> getPURCARDMst(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {8,10,11,1,18};
		String strHeaders[] = {
			"CARD_YMD",
			"BIZCO_NO",
			"CARD_STR_ID",
			"CARD_ID_BIT",
			"CARD_LOAN_AMT"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
}
