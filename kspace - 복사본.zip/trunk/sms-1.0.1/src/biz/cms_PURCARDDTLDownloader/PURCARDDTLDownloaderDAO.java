package biz.cms_PURCARDDTLDownloader;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class PURCARDDTLDownloaderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(PURCARDDTLDownloaderPollingAction.class);
	
	public int spSMSSEND(String strMsg, String strSender) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("sysinq-sql", "PR_SMSSEND"));
			sql.setString(++i, strMsg);
			sql.setString(++i, strSender);
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int insPURCARDRslt(int type, HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
		int rows = -1;
		System.out.println("==========insPURCARDRslt start ====");
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
//			i = 0;
//			sql.put(findQuery("service-sql", "SEL_PURCARDORGCD"));
//			sql.setString(++i, (String)hm.get("CO_CD"));
//			sql.setString(++i, (String)hm.get("FCSTR_ID"));
//			sql.setString(++i, (String)hm.get("ADJT_DT"));
//			
//			list = executeQuery(sql);
//			sql.close();
//			
//			if( list.size() > 0 ) map = (Map<String, String>)list.get(0);
//			else map.put("ORG_CD", "N/A");
			
			i = 0;
			sql.clearParameter();			
			if( type == 1 ) {
				sql.put(findQuery("service-sql", "INS_HQ_CARDLOAN_REC"));
				sql.setString(++i, (String)hm.get("CO_CD"));
				sql.setString(++i, (String)hm.get("CRT_YMD"));
				sql.setString(++i, (String)hm.get("CARD_STR_ID"));
				sql.setString(++i, (String)hm.get("CRT_YMD"));
				sql.setString(++i, (String)hm.get("CONF_AMT"));
				sql.setString(++i, (String)hm.get("CODE"));
				sql.setString(++i, (String)hm.get("AMT"));
				sql.setString(++i, (String)hm.get("AMT2"));
			}else if( type == 2 ) {
				sql.put(findQuery("service-sql", "INS_HQ_CARDLOAN_REC_HIS"));
				sql.setString(++i, (String)hm.get("CO_CD"));
				sql.setString(++i, (String)hm.get("CRT_YMD"));
				sql.setString(++i, (String)hm.get("CARD_STR_ID"));
				sql.setString(++i, (String)hm.get("CONF_YMD"));
				sql.setString(++i, (String)hm.get("CARD_AMT"));
				
				sql.setString(++i, (String)hm.get("CARD_AMT_ORI"));
				sql.setString(++i, (String)hm.get("CARD_AMT_OVER_FEE"));
				sql.setString(++i, (String)hm.get("CARD_OVER_AMT"));
				sql.setString(++i, (String)hm.get("OVER_FLAG"));
				sql.setString(++i, (String)hm.get("OVER_AMT_ORI"));
				
				sql.setString(++i, (String)hm.get("OVER_FEE"));
				sql.setString(++i, (String)hm.get("OVER_AMT"));
			}else if( type == 3 ) {
				sql.put(findQuery("service-sql", "INS_HQ_CARDMST_REC"));
				sql.setString(++i, (String)hm.get("CO_CD"));
				sql.setString(++i, (String)hm.get("CRT_YMD"));
				sql.setString(++i, (String)hm.get("CARD_YMD"));
				sql.setString(++i, (String)hm.get("BIZCO_NO"));
				sql.setString(++i, (String)hm.get("CARD_STR_ID"));
				sql.setString(++i, (String)hm.get("CARD_ID_BIT"));
				sql.setString(++i, (String)hm.get("CARD_LOAN_AMT"));
			}
			System.out.println("SQL=" + sql.debug());
			logger.info("SQL=" + sql.debug());
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int spBATCHCARDLOANREC(String strType){
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("sysinq-sql", "PR_BATCH_CARDLOAN_REC"));
			sql.setString(++i, strType);
			
			System.out.println("SQL=" + sql.debug());
			logger.info("SQL=" + sql.debug());
			ret = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
}
