package biz.cms_PURCARDDTLDownloader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.apache.log4j.Logger;

import biz.cms_TMoneySender.TMoneySenderDAO;
import biz.comm.SFTPManager;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

public class PURCARDDTLDownloaderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(PURCARDDTLDownloaderPollingAction.class);
	
	private String purcard_ftp_ip = "";
	private int purcard_ftp_port = 0;
	private String purcard_ftp_id = "";
	private String purcard_ftp_pwd = "";
	
	public final String TOTSELL_CD = "WMPT";
	
	public static void main(String args[]) throws Exception {
		PURCARDDTLDownloaderPollingAction action = new PURCARDDTLDownloaderPollingAction();
		if( args == null || args.length < 1 ) {
			logger.info("------ master main args null");
		}
		System.out.println("[DEBUG] [args[0]]=" + args[0] );
		
		String path          = nvl(args[0].replaceFirst("-path:", ""));
		String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));
		String fileNm		 = nvl(args[2].replaceFirst("-file:", ""));
		String stdDate		 = nvl(args[3].replaceFirst("-stdDate:", ""));
		String stdDate1		 = nvl(args[4].replaceFirst("-stdDate1:", ""));
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		
		if( cmd.length() != 2 ) return;
		
		if( cmd.charAt(0) == '1' ) {
			System.out.println("downloading file" );
			action.downloadSpecifiedFile(fileNm);
		}
		if( cmd.charAt(1) == '1' ) {
			System.out.println("inserting to DB" );
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "purcard";
			
			PURCARDDTLDownloaderInst dailyInsert = new PURCARDDTLDownloaderInst(destPath, action, stdDate, stdDate1);
			dailyInsert.start();
		}
	}
	
	private void downloadSpecifiedFile(String fileNM) {
		SFTPManager sFtpMgr = null;
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK = false;
		
		try {
			this.purcard_ftp_ip = PropertyUtil.findProperty("communication-property", "PURCARD_FTP_SERVER_IP");
			this.purcard_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "PURCARD_FTP_SERVER_PORT"));
			this.purcard_ftp_id = PropertyUtil.findProperty("communication-property", "PURCARD_FTP_SERVER_ID");
			this.purcard_ftp_pwd = PropertyUtil.findProperty("communication-property", "PURCARD_FTP_SERVER_PWD");
			
			sFtpMgr = new SFTPManager(purcard_ftp_ip, purcard_ftp_port, purcard_ftp_id, purcard_ftp_pwd);
			
			logger.info("Connected to " + purcard_ftp_ip + ":" + purcard_ftp_port);
			
			sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "Samsung"); // 경로변경(현재경로+Samsung폴더)
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "purcard";
			
			File destDir = new File(destPath);
			if( !destDir.exists() ) {
				destDir.mkdir();
			}
			
			isDownOK = false;
			
			String targetFileNM = fileNM;
			iRetry = 0;
			try {
				logger.info("[INFO]fileNm::["+targetFileNM+"]");
				bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + targetFileNM));
				
				while( iRetry < 2 ) {
					if( isDownOK = sFtpMgr.get(targetFileNM, bos)) {
						break;
					}
					iRetry++;
				}
			}catch(Exception e) {
				logger.info("[ERROR_1] Can't get file on FTP server");
				logger.info("[ERROR_1]"+e.getMessage());
			}
			if( bos != null ) {
				bos.flush();
				bos.close();
				bos = null;
			}
			System.gc();
			
			if( isDownOK ) {
				logger.info("[DEBUG] successfuly downloaded file [" + targetFileNM + "]");
			}else {
				File file = new File(destPath + File.separator + targetFileNM);
				if( !file.delete() ) {
					logger.info("[ERROR_2] Failed to delete empty file [" + targetFileNM + "]");
				}
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			if( bos != null ) {
				try {
					bos.close();
					bos = null;
				}catch(Exception e) {}
			}
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {}
		}
	}

	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		SFTPManager sFtpMgr = null;
		
		BufferedOutputStream bos = null;
		int iRetry = 0;
		boolean isDownOK = false;

		try {
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = "";
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "purcard";
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
//			if( actionMode != "1" ) return;
			
			this.purcard_ftp_ip = PropertyUtil.findProperty("communication-property", "PURCARD_FTP_SERVER_IP");
			this.purcard_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "PURCARD_FTP_SERVER_PORT"));
			this.purcard_ftp_id = PropertyUtil.findProperty("communication-property", "PURCARD_FTP_SERVER_ID");
			this.purcard_ftp_pwd = PropertyUtil.findProperty("communication-property", "PURCARD_FTP_SERVER_PWD");
			
			sFtpMgr = new SFTPManager(purcard_ftp_ip, purcard_ftp_port, purcard_ftp_id, purcard_ftp_pwd);
			
			System.out.println("Connected to " + purcard_ftp_ip + ":" + purcard_ftp_port);
			logger.info("Connected to " + purcard_ftp_ip + ":" + purcard_ftp_port);

			sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "Samsung"); // 경로변경(현재경로+Samsung폴더)
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "purcard";
			
			File destDir = new File(destPath);
			if( !destDir.exists() ) {
				destDir.mkdir();
			}
			
			isDownOK = false;
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			String stdDate = sdf.format(calendar.getTime());
			calendar.add(Calendar.DATE, -1);
			String stdDate1 = sdf.format(calendar.getTime());
			
			String targetFileNM = stdDate + "_ATC";
			iRetry = 0;
			try {
				bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + targetFileNM));
				logger.info("targetFileNM : " + targetFileNM);
				logger.info("bos : " + bos);
				while( iRetry < 2 ) {
					if( isDownOK = sFtpMgr.get(targetFileNM, bos)) {
						break;
					}
					iRetry++;
				}
			}catch(Exception e) {
				System.out.println("[ERROR_1] Can't get file on FTP server");
				logger.info("[ERROR_1] Can't get file on FTP server : " + e.getMessage());
//				(new PURCARDDTLDownloaderDAO()).spSMSSEND("카드여신 " + targetFileNM + " 수신 실패", "cms_PURCARDDTLDownloader");
			}
			if( bos != null ) {
				bos.flush();
				bos.close();
				bos = null;
			}
			System.gc();
			
			if( isDownOK ) {
				logger.info("[DEBUG] successfuly downloaded file [" + targetFileNM + "]");
				// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
				if( sFtpMgr.rename(targetFileNM, targetFileNM.concat(".ok")) ) {
					logger.info("[DEBUG] Succeeded to rename.");
				}else {
					logger.info("[DEBUG] Failed to rename.");
				}
			}else {
				File file = new File(destPath + File.separator + targetFileNM);
				if( !file.delete() ) {
					logger.info("[ERROR_2] Failed to delete empty file [" + targetFileNM + "]");
				}
			}
			
			isDownOK = false;
			
			targetFileNM = stdDate1 + "_DEF";
			iRetry = 0;
			try {
				bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + targetFileNM));
				logger.info("targetFileNM : " + targetFileNM);
				logger.info("bos : " + bos);
							
				while( iRetry < 2 ) {
					if( isDownOK = sFtpMgr.get(targetFileNM, bos)) {
						break;
					}
					iRetry++;
				}
			}catch(Exception e) {
				logger.info("[ERROR_3] Can't get file on FTP server");
//				(new PURCARDDTLDownloaderDAO()).spSMSSEND("카드여신 " + targetFileNM + " 수신 실패", "cms_PURCARDDTLDownloader");
			}
			if( bos != null ) {
				bos.flush();
				bos.close();
				bos = null;
			}
			System.gc();
			
			if( isDownOK ) {
				logger.info("[DEBUG] successfuly downloaded file [" + targetFileNM + "]");
				// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
				if( sFtpMgr.rename(targetFileNM, targetFileNM.concat(".ok")) ) {
					logger.info("[DEBUG] Succeeded to rename.");
				}else {
					logger.info("[DEBUG] Failed to rename.");
				}
			}else {
				File file = new File(destPath + File.separator + targetFileNM);
				if( !file.delete() ) {
					logger.info("[ERROR_4] Failed to delete empty file [" + targetFileNM + "]");
				}
			}
			
			isDownOK = false;
			targetFileNM = stdDate1 + "_ACQ";
			iRetry = 0;
			try {
				bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + targetFileNM));
				logger.info("targetFileNM : " + targetFileNM);
				logger.info("bos : " + bos);
							
				while( iRetry < 2 ) {
					if( isDownOK = sFtpMgr.get(targetFileNM, bos)) {
						break;
					}
					iRetry++;
				}
			}catch(Exception e) {
				logger.info("[ERROR_5] Can't get file on FTP server");
//				(new PURCARDDTLDownloaderDAO()).spSMSSEND("카드여신 " + targetFileNM + " 수신 실패", "cms_PURCARDDTLDownloader");
			}
			if( bos != null ) {
				bos.flush();
				bos.close();
				bos = null;
			}
			System.gc();
			
			if( isDownOK ) {
				logger.info("[DEBUG] successfuly downloaded file [" + targetFileNM + "]");
				// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
				if( sFtpMgr.rename(targetFileNM, targetFileNM.concat(".ok")) ) {
					logger.info("[DEBUG] Succeeded to rename.");
				}else {
					logger.info("[DEBUG] Failed to rename.");
				}
			}else {
				File file = new File(destPath + File.separator + targetFileNM);
				if( !file.delete() ) {
					logger.info("[ERROR_6] Failed to delete empty file [" + targetFileNM + "]");
				}
			}			
			
			// 파일 읽어서 DB Insert
			PURCARDDTLDownloaderInst dailyInsert = new PURCARDDTLDownloaderInst(destPath, this, stdDate, stdDate1);
			dailyInsert.start();
		}catch(Exception e) {
			System.out.println(e.getMessage());
			logger.info(e.getMessage());
		}finally {
			if( bos != null ) {
				try {
					bos.close();
					bos = null;
				}catch(Exception e) {}
			}
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {}
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
}
