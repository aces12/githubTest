package biz.cms_SSGMbsTran;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class SSGMbsTranDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(SSGMbsTranPollingAction.class);
	
	public List<Object> selSVCFILEDAILY(String stdYmd, String svcID, String cmdTp, String comCD) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SVCCRTDAILY"));
			sql.setString(++i, stdYmd);
			sql.setString(++i, svcID);
			sql.setString(++i, cmdTp);
			sql.setString(++i, comCD);
			
			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		} 
		
		return list;
	}
	
	public int insSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	public int insSSGPointRslt(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_SSGPOINTRESULT"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("APPROVAL_DT"));
			sql.setString(++i, (String)hm.get("TRAN_ID"));
			sql.setString(++i, (String)hm.get("USE_SAVE_TP"));
			sql.setString(++i, (String)hm.get("APPROVAL_NO"));
			
			sql.setString(++i, "A16" + (String)hm.get("TRAN_ID").substring(8, 13));
			sql.setString(++i, (String)hm.get("TRANS_DATE"));
			sql.setString(++i, (String)hm.get("TYPE"));
			sql.setString(++i, ((String)hm.get("POINT")).replaceFirst("^0+", ""));
			sql.setString(++i, (String)hm.get("CARD_NO"));
			sql.setString(++i, (String)hm.get("CARD_NO"));
			
			sql.setString(++i, (String)hm.get("TRAN_DT"));
			sql.setString(++i, (String)hm.get("ORGTRAN_APPR_DT"));
			sql.setString(++i, (String)hm.get("ORGTRAN_APPR_NO"));
			sql.setString(++i, (String)hm.get("CARD_OWNER_NM"));
			
//			logger.info("sql=" + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}

	
	public List<Object> selSSGMBSUSETRAN(String com_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SSGMBSUSETRAN"));
			sql.setString(++i, com_cd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	
	public int updSSGMBSUSETRAN(String proc_id, HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGMBSUSETRAN"));
			sql.setString(++i, proc_id);
			sql.setString(++i, (String)hm.get("TRAN_YMD"));
			sql.setString(++i, (String)hm.get("STORE_CD"));
			sql.setString(++i, (String)hm.get("POS_NO"));
			sql.setString(++i, (String)hm.get("TRAN_NO"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public List<Object> selSSGMBSSAVETRAN(String com_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SSGMBSSAVETRAN"));
			sql.setString(++i, com_cd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	
	public int updSSGMBSSAVETRAN(String proc_id, HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SSGMBSSAVETRAN"));
			sql.setString(++i, proc_id);
			sql.setString(++i, (String)hm.get("TRAN_YMD"));
			sql.setString(++i, (String)hm.get("STORE_CD"));
			sql.setString(++i, (String)hm.get("POS_NO"));
			sql.setString(++i, (String)hm.get("TRAN_NO"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	
	
	public int insSSGPointCardBin(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_SSGPOINTCARDBIN"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("PREFIX_ST_NO"));
			sql.setString(++i, (String)hm.get("PREFIX_END_NO"));
			sql.setString(++i, (String)hm.get("CARD_TP_TP"));	
			
			logger.info("sql=" + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	

	public int  delSSGPointCardBin()throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "DEL_SSGPOINTCARDBIN"));
			
			logger.info("sql=" + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
		
	}	
	
	
	public int updSSGPointCardBin(String co_cd)throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			if ( co_cd.equals("9090909090") ){ // 기존 데이터 백업용
				sql.put(findQuery("service-sql", "UPD_SSGPOINTCARDBIN"));
				sql.setString(++i, co_cd);
			}else { //9090909090 로 백업된 데이터를 다시 복원
				sql.put(findQuery("service-sql", "UPD_SSGPOINTCARDBIN_BACKUP"));
			}
			logger.info("sql=" + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;		
	}
	
	
	
	
	
	
}