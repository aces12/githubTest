package biz.cms_SSGMbsTran;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class SSGMbsCardBinInst extends Thread {
	private static Logger logger = Logger.getLogger(SSGMbsTranPollingAction.class);
	
	private final int LENGTH_BY_RSLT_RECORD = 201;
	
	String path = "";
	
	public SSGMbsCardBinInst(String path) {
		this.path = path;
	}
	
	public void run() {
		String fileNM = "";
		
		try {
			List<File> file = getDirFileList(path);
			logger.info(" >>>>>>>>>>>>>>>>>>> file cnt : " + Integer.toString(file.size()));
			
			for(int i = 0;i < file.size();i++) {
				fileNM = file.get(i).getName();
				
				logger.info(" >>>>>>>>>>>>>>>>>>> file name : " + fileNM);
				
				int len = 0;
				int totLen = 0;
				int pointBinCount = 0;
				String readLine = "";
				
				long fileSize = (file.get(i)).length();
				
				byte buf[] = new byte[(int)fileSize];
				InputStream is = new FileInputStream(file.get(i));
				
				StringBuffer sb = new StringBuffer();
				
				logger.info(" >>>>>>>>>>>>>>>>>>>  while fileSizecount=["+fileSize+"]");
				
				while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
					sb.append(new String(buf));
					totLen += len;
					
					if( totLen == fileSize ) {
						break;
					}
				}
				logger.info(" >>>>>>>>>>>>>>>>>>>  totLen=["+totLen+"] len=["+len+"]");
				
				is.close();
				// 신세계 포인트 빈의 데이터가 있어야 하고, 데이터가 없는 경우 삭제, 실행 안되도록 함.
				if( fileNM.substring(0, 10).equals("2500CV0023") && (int)fileSize > 0 &&  totLen == len ) {		// 신세계포인트 카드빈 정보
					
					this.updateDB("9090909090");//기존데이터 백업 
					//this.insertDB( sb.toString()); //20180823 수정
					if (this.insertDB( sb.toString() ) > 0 )
					{
						this.deleteBackup();//백업 삭제
					}
					else
					{
						this.updateDB("1002");//기존데이터 백업된 내용을 다시 원복
					}
				}else{
					logger.info(" >>>>>>>>>>>>>>>>>>> file name : " + fileNM+" No Data !!! Count= ["+pointBinCount+"]");
				}
				// 파일 옮기기...
				moveFile(path, fileNM, path + File.separator + "backup");
				logger.info("[DEBUG] File " + fileNM + " processed successfuly.");
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	private void updateDB( String co_cd) {
		try {
			SSGMbsTranDAO dao = new SSGMbsTranDAO();
			dao.updSSGPointCardBin(co_cd);	
		}catch(Exception e) {
			logger.info("[ERROR] Error for updateDB data : " + e.getMessage());
			if(co_cd.equals("9090909090")){
				logger.info("[ERROR] STOP getCardBin : " + e.getMessage());
				return;
			}
		}
	}
	private void deleteBackup() {
		try {
			SSGMbsTranDAO dao = new SSGMbsTranDAO();
			dao.delSSGPointCardBin();
		}catch(Exception e) {
			logger.info("[ERROR] Error for deleteBackup data : " + e.getMessage());
			logger.info("[ERROR] Plz delete backup data manually : " + e.getMessage());
		}
	}
	private int insertDB( String readData) {
		int pointBinCountBD = 0;
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			SSGMbsTranDAO dao = new SSGMbsTranDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String trans_date = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*LENGTH_BY_RSLT_RECORD, LENGTH_BY_RSLT_RECORD);
				totLen += LENGTH_BY_RSLT_RECORD;

				if( strRecord.substring(0, 2).equals("BH") ) {
					hm = getSSGPointRslt_HDR(strRecord);
					trans_date = (String)hm.get("TRANS_DATE");
				}else if( strRecord.substring(0, 2).equals("BD") ) {
					hm = getSSGPointRslt_DTL(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("TRANS_DATE", trans_date);
					pointBinCountBD++;
					try {
						dao.insSSGPointCardBin(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
						pointBinCountBD = 0;
						this.updateDB("1002");//백업데이터 원복 
					}
				}
			}
		}catch(Exception e) {
			pointBinCountBD = 0;
			logger.info("[ERROR] " + e.getMessage());
			this.updateDB("1002");//백업데이터 원복
		}
		
		return pointBinCountBD;
	}
	
	private HashMap<String, String> getSSGPointRslt_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,8,190};
		String strHeaders[] = {
			"RECORD_TP",
			"TRANS_DATE",
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
//		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info("[DEBUG] " + strHeaders[i] + "=" + (String)hm.get(strHeaders[i]));
//		}
		
		return hm;
	}
	
	private HashMap<String, String> getSSGPointRslt_DTL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,7,7,22,2
					  ,5,155};
		String strHeaders[] = {
			"RECORD_TP",
			"PREFIX_ST_NO",
			"PREFIX_END_NO",
			"CARD_NM",
			"CARD_PAY_TP",
			
			"CARD_TP_TP",			
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
//		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info("[DEBUG] " + strHeaders[i] + "=" + (String)hm.get(strHeaders[i]));
//		}
		
		return hm;
	}
	
	public void moveFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdir();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		logger.info("orgFile = " + orgPath + File.separator + fileNM);
		logger.info("destFile = " + destPath + File.separator + fileNM);
		
		if( destFile.exists() ) {
			if( orgFile.delete() ) {
				logger.info("[DEBUG] File(" + orgFile.getPath() + " / "+ orgFile.getName() + ") Deleted");
			}else {
				logger.info("[DEBUG] Fail to remove file(" + orgFile.getPath() + " / "+ orgFile.getName() + ")");
			}
		}else {
			for(int i = 0;i < 20;i++) {
				if( orgFile.renameTo(destFile) ) {
					logger.info(">> MOVE OK : " + destFile.getName());
					break;
				}
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
//			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
}