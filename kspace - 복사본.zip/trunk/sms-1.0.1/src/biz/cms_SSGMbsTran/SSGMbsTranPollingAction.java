package biz.cms_SSGMbsTran;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
//import org.apache.commons.net.util.Base64;
import org.apache.log4j.Logger;

import com.cyberpass.seed.Seed;

import sun.misc.BASE64Decoder;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

public class SSGMbsTranPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(SSGMbsTranPollingAction.class);
	
	public static void main(String args[]) throws Exception {
		SSGMbsTranPollingAction action = new SSGMbsTranPollingAction();
		try {
			if(args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[1]]=" + args[1] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd			 = nvl(args[1].replaceFirst("-cmd:", ""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			// 20180821 JMH 신세계 포인트 빈 추가로 인한 값 변경. 기존거에 추가로 1 됨.
			//if( cmd.length() != 3 ) return;
			if( cmd.length() != 4 ) return;
			
			if( cmd.charAt(0) == '1' ) {
				System.out.println("[DEBUG] execute createSaveListToFile()" );
				action.createSaveListToFile();
			}
			Thread.sleep(50);
			if( cmd.charAt(1) == '1' ) {
				System.out.println("[DEBUG] execute createUseListToFile()" );
				action.createUseListToFile();
			}
			Thread.sleep(50);
			if( cmd.charAt(2) == '1' ) {
				System.out.println("[DEBUG] execute giveAndTake()" );
				action.giveAndTake();
			}
			//neo0531 
			Thread.sleep(50);
			if( cmd.charAt(3) == '1' ) {
				System.out.println("[DEBUG] execute getCardBin()" );
				action.getCardBin();
			}
			
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(String actionMode) {
		SSGMbsTranDAO dao = new SSGMbsTranDAO();
		List<Object> list = null;
		int totalCnt = 0;
		
		try {
			int ret = -1;
			if( actionMode != "1" ) return;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String stdYmd = sdf.format(new Date());
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			//(금일 대사파일 생성 유무 조회)
			list = dao.selSVCFILEDAILY(stdYmd, "SSG", "01", com_cd);
			totalCnt = list.size();
			
			logger.info("SSGMbsTranPollingAction selSVCFILEDAILY.size >>> ["+totalCnt+"]");
			
			//금일 대사파일 생성 row가 없으면 생성
			if( totalCnt <= 0 ) {
				HashMap<String, String> hm = new HashMap<String, String>();
				hm.put("COM_CD", com_cd);
				hm.put("STD_YMD", stdYmd);
				hm.put("SVC_ID", "SSG");
				hm.put("CMD_TY", "01");
				
				ret = dao.insSVCFILEINFO(hm);
				logger.info("SSGMbsTranPollingAction insSVCFILEINFO ret >>> ["+ret+"]");
				if( ret > 0 ) {
					createSaveListToFile();
					Thread.sleep(50);
					
					createUseListToFile();
					Thread.sleep(50);
					
					giveAndTake();
					Thread.sleep(50);
					
					getCardBin();
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	public void createSaveListToFile() {
		String strTRFileNM = "";
		boolean bIsCreatedFile = false;
		
		try {
			logger.info("<<< SSGMbsTranPollingAction ::: createSaveListToFile START >>>");
			
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			SSGMbsTranDAO dao = new SSGMbsTranDAO();
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String stdDate = sdf.format(calendar.getTime());

			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "ssgpoint";

			Seed seed = Seed.getInstance("CBC/PKCS5Padding");
			String keyData = PropertyUtil.findProperty("service-property", "KEY_DATA");
			String ivData = PropertyUtil.findProperty("service-property", "IV_DATA");
			seed.setKey(keyData.getBytes());
			seed.setIV(ivData.getBytes());
			BASE64Decoder decoder = new BASE64Decoder();
			
			// 적립내역 통합파일명
			// 위드미->신세계포인트 : 2500CV0002.YYYYMMDD	.HHMMSS 붙는 것은 하루에 한 번 받는 것이라 필요 없기 때문에 신세계I&C 한준호K과 협의 후 삭제 
			// 신세계포인트->위드미 : 2500CV0022.YYYYMMDD	
			strTRFileNM = "2500CV0002." + stdDate;
			
//			List<File> filesInFolder = getDirFileList(destPath);
//			boolean bExist = false;
//			for(int i = 0;i < filesInFolder.size();i++) {
//				if( (filesInFolder.get(i).getName().substring(0, 19)).equals(strTRFileNM.substring(0, 19)) ) {
//					bExist = true;
//					break;
//				}
//			}
			
			list = dao.selSSGMBSSAVETRAN(com_cd);
			logger.info("<<< SSGMbsTranPollingAction ::: SAVE DATA CNT >>> ["+list.size()+"]");
			if( list.size() <= 0 ) {
				logger.info("[INFO] Nothing details. So file can't be created.");
				return;
			}
			
			// 적립내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_TP", "BH");
			hmHeader.put("TRANS_DATE", stdDate);
			hmHeader.put("FILLER", " ");
			
			sbFile.append(makeHeaderOfSaveListFile(hmHeader));
			
//			list = dao.selSSGMBSSAVETRAN(com_cd);
			for(int i = 0;i < list.size();i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				hmData.put("RECORD_TP", "BD");
				hmData.put("APPROVAL_DT", (String)map.get("APPROVAL_DT"));
				hmData.put("APPROVAL_NO", (String)map.get("APPROVAL_NO"));
				hmData.put("TRAN_ID", (String)map.get("TRAN_YMD") + (String)map.get("STORE_CD")
										+ (String)map.get("POS_NO") + (String)map.get("TRAN_NO"));
				hmData.put("SAVE_CNCL_TP", (String)map.get("SAVE_CNCL_TP"));
				hmData.put("SAVE_POINT", (String)map.get("SAVE_POINT"));
				
				// 암호화 필드 Decoding(Base64 decoding -> seed128 decoding)
				if("".equals((String)map.get("CARD_NO_ENCODED")) || (String)map.get("CARD_NO_ENCODED") == null){
					hmData.put("CARD_NO", "");
				}else{
					hmData.put("CARD_NO", new String(seed.decrypt(decoder.decodeBuffer((String)map.get("CARD_NO_ENCODED")))));
				}
			
				hmData.put("TRAN_DT", (String)map.get("TRAN_DT"));
				hmData.put("ORGTRAN_APPR_DT", (String)map.get("ORGTRAN_APPR_DT"));
				hmData.put("ORGTRAN_APPR_NO", (String)map.get("ORGTRAN_APPR_NO"));
				hmData.put("FILLER", " ");

				sbFile.append(makeDataOfSaveListFile(hmData));
			}
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			hmTailer.put("RECORD_TP", "BT");
			hmTailer.put("RECORD_CNT", String.format("%09d", list.size()));
			hmTailer.put("FILLER", " ");
			
			sbFile.append(makeTailerOfSaveListFile(hmTailer));
			
			// 적립내역 파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRFileNM);
			logger.info("<<< SSGMbsTranPollingAction ::: CREATE SAVE FILE RSLT ::: bIsCreatedFile >>> ["+bIsCreatedFile+"]");
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRFileNM);
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					dao.updSSGMBSSAVETRAN("1", (HashMap<String, String>)map);
				}
			}
			
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
	}
	
	private String makeHeaderOfSaveListFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,8,190};
		String strHeaders[] = {
			"RECORD_TP",
			"TRANS_DATE",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeDataOfSaveListFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,8,20,21,1
					  ,10,20,8,8,20
					  ,82};
		String strHeaders[] = {
			"RECORD_TP",
			"APPROVAL_DT",
			"APPROVAL_NO",
			"TRAN_ID",
			"SAVE_CNCL_TP",
			
			"SAVE_POINT",
			"CARD_NO",
			"TRAN_DT",
			"ORGTRAN_APPR_DT",
			"ORGTRAN_APPR_NO",
			
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeTailerOfSaveListFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,9,189};
		String strHeaders[] = {
			"RECORD_TP",
			"RECORD_CNT",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public void createUseListToFile() {
		String strTRFileNM = "";
		boolean bIsCreatedFile = false;
		
		try {
			logger.info("<<< SSGMbsTranPollingAction ::: createUseListToFile START >>>");
			
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			SSGMbsTranDAO dao = new SSGMbsTranDAO();
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String stdDate = sdf.format(calendar.getTime());
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "ssgpoint";
			
			Seed seed = Seed.getInstance("CBC/PKCS5Padding");
			String keyData = PropertyUtil.findProperty("service-property", "KEY_DATA");
			String ivData = PropertyUtil.findProperty("service-property", "IV_DATA");
			seed.setKey(keyData.getBytes());
			seed.setIV(ivData.getBytes());
			BASE64Decoder decoder = new BASE64Decoder();
			
			// 사용내역 통합파일명
			// 위드미->신세계포인트 : 2500CV0001.YYYYMMDD.HHMMSS	.HHMMSS 붙는 것은 하루에 한 번 받는 것이라 필요 없기 때문에 신세계I&C 한준호K과 협의 후 삭제 
			// 신세계포인트->위드미 : 2500CV0021.YYYYMMDD.HHMMSS
			strTRFileNM = "2500CV0001." + stdDate;
			
//			List<File> filesInFolder = getDirFileList(destPath);
//			boolean bExist = false;
//			for(int i = 0;i < filesInFolder.size();i++) {
//				if( (filesInFolder.get(i).getName().substring(0, 19)).equals(strTRFileNM.substring(0, 19)) ) {
//					bExist = true;
//					break;
//				}
//			}
//			if( bExist ) {
//				return;
//			}
			
			list = dao.selSSGMBSUSETRAN(com_cd);
			logger.info("<<< SSGMbsTranPollingAction ::: USE DATA CNT >>> ["+list.size()+"]");
			if( list.size() <= 0 ) {
				logger.info("[INFO] Nothing details. So file can't be created.");
				return;
			}
			
			// 사용내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_TP", "BH");
			hmHeader.put("TRANS_DATE", stdDate);
			hmHeader.put("FILLER", " ");
			
			sbFile.append(makeHeaderOfUseListFile(hmHeader));

//			list = dao.selSSGMBSUSETRAN(com_cd);
			for(int i = 0;i < list.size();i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				hmData.put("RECORD_TP", "BD");
				hmData.put("APPROVAL_DT", (String)map.get("APPROVAL_DT"));
				hmData.put("APPROVAL_NO", (String)map.get("APPROVAL_NO"));
				hmData.put("TRAN_ID", (String)map.get("TRAN_YMD") + (String)map.get("STORE_CD")
						+ (String)map.get("POS_NO") + (String)map.get("TRAN_NO"));
				hmData.put("USE_CNCL_TP", (String)map.get("USE_CNCL_TP"));
				hmData.put("USE_POINT", (String)map.get("USE_POINT"));

				// 암호화 필드 Decoding(Base64 decoding -> seed128 decoding)
				hmData.put("CARD_NO", new String(seed.decrypt(decoder.decodeBuffer((String)map.get("CARD_NO_ENCODED")))));

				hmData.put("TRAN_DT", (String)map.get("TRAN_DT"));
				hmData.put("ORGTRAN_APPR_DT", (String)map.get("ORGTRAN_APPR_DT"));
				hmData.put("ORGTRAN_APPR_NO", (String)map.get("ORGTRAN_APPR_NO"));
				hmData.put("FILLER", " ");
				
				sbFile.append(makeDataOfUseListFile(hmData));
			}
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			hmTailer.put("RECORD_TP", "BT");
			hmTailer.put("RECORD_CNT", String.format("%09d", list.size()));
			hmTailer.put("FILLER", " ");
			
			sbFile.append(makeTailerOfUseListFile(hmTailer));
			
			// 사용내역 파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRFileNM);
			logger.info("<<< SSGMbsTranPollingAction ::: CREATE USE FILE RSLT ::: bIsCreatedFile >>> ["+bIsCreatedFile+"]");
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRFileNM);
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					dao.updSSGMBSUSETRAN("1", (HashMap<String, String>)map);
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
	}
	
	private String makeHeaderOfUseListFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,8,190};
		String strHeaders[] = {
			"RECORD_TP",
			"TRANS_DATE",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeDataOfUseListFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,8,20,21,1
					  ,10,20,8,8,20
					  ,82};
		String strHeaders[] = {
			"RECORD_TP",
			"APPROVAL_DT",
			"APPROVAL_NO",
			"TRAN_ID",
			"USE_CNCL_TP",
			
			"USE_POINT",
			"CARD_NO",
			"TRAN_DT",
			"ORGTRAN_APPR_DT",
			"ORGTRAN_APPR_NO",
			
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeTailerOfUseListFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,9,189};
		String strHeaders[] = {
			"RECORD_TP",
			"RECORD_CNT",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public void giveAndTake() {
		FTPClient client = null;
		InputStream input = null;
		BufferedOutputStream bos = null;
		String basePath = "";
		String upPath = "";
		String downPath = "";
		
		String ssg_ftp_ip = "";
		int ssg_ftp_port = 0;
		String ssg_ftp_id = "";
		String ssg_ftp_pwd = "";
		int iRetry = 0;
		
		try {
			logger.info("<<< SSGMbsTranPollingAction ::: giveAndTake START >>>");
			
			ssg_ftp_ip = PropertyUtil.findProperty("communication-property", "SSGPOINT_FTP_SERVER_IP");
			ssg_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGPOINT_FTP_SERVER_PORT"));
			ssg_ftp_id = PropertyUtil.findProperty("communication-property", "SSGPOINT_FTP_SERVER_ID");
			ssg_ftp_pwd = PropertyUtil.findProperty("communication-property", "SSGPOINT_FTP_SERVER_PWD");
			
			logger.info("SSGMbsTranPollingAction ::: SET SSGPOINT SERVER INFO FIN.");
			client = new FTPClient();
			client.setControlEncoding("euc-kr");
			client.connect(ssg_ftp_ip, ssg_ftp_port);
			
			int resultCode = client.getReplyCode();
			logger.info("SSGMbsTranPollingAction ::: SET SSGPOINT SERVER CONN CODE >>> ["+resultCode+"]");
			
			if( !FTPReply.isPositiveCompletion(resultCode) ) {
				logger.info("[ERROR1] Can't connect on FTP server");
				throw new Exception();
			}else {
				logger.info("<<< SSGMbsTranPollingAction ::: SEND EMART24 FILES TO SSGPOINT SERVER START >>>");
				client.setSoTimeout(5000);
				boolean isLogin = false;
				isLogin = client.login(ssg_ftp_id, ssg_ftp_pwd);
				if( !isLogin ) {
					logger.info("[ERROR2] Can't login on FTP server");
					throw new Exception();
				}
				
				client.setFileType(FTP.BINARY_FILE_TYPE);
				client.enterLocalPassiveMode();
				
				basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");
				upPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "ssgpoint";
				
				List<File> upFolder = getDirFileList(upPath);
				
				boolean isUploadOK = false;
				if( upFolder.size() > 0 ) {
					logger.info("upFolder size : " + Integer.toString(upFolder.size()));
					for(int i = 0;i < upFolder.size();i++) {
						if( !upFolder.get(i).isFile() ) {
							continue;
						}
						String targetFileNM = upFolder.get(i).getName();
						logger.info("FileNM : " + targetFileNM);
						
						try {
							iRetry = 0;
							
							input = new FileInputStream(new File(upPath + File.separator + targetFileNM));
							while( iRetry < 2 ) {
								if( isUploadOK = client.storeFile("/CnvToSpoint/" + targetFileNM, input) ) {
									logger.info("File " + targetFileNM + "successfuly uploaded");
									break;
								}
								iRetry++;
							}
							input.close();
							input = null;
							System.gc();
							
							if( isUploadOK ) {
								moveFile(upPath, targetFileNM, upPath + File.separator + "backup");
								logger.info("moved File!");
							}
						}catch(Exception e) {
							logger.info("[ERROR3] File " + targetFileNM + "upload error.");
							throw new Exception();
						}
					}
				}
				
				downPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "ssgpoint";
				
				File downDir = new File(downPath);
				
				if( !downDir.exists() ) {
					downDir.mkdir();
				}
				
				boolean isDownOK = false;
				boolean bIsChanged = client.changeWorkingDirectory("/SpointToCnv");
				logger.info(client.getReplyString());
				if( bIsChanged ) {
					logger.info("successfully changed working deirectory.");
				}else {
					logger.info("Failed to change working deirectory.");
				}
				Calendar calendar = new GregorianCalendar(Locale.KOREA);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String stdDate = sdf.format(calendar.getTime());
				
//				String[] files = client.listNames();
//				if( files != null && files.length > 0 ) {
//					for(String aFile:files) {
//						logger.info("[DEBUG] File list : " + aFile);
//						if( aFile.length() < 19 ) {
//							continue;
//						}
//						if( !(aFile.substring(11, 19)).equals(stdDate) ) {
//							continue;
//						}
//						iRetry = 0;
//						bos = new BufferedOutputStream(new FileOutputStream(downPath + File.separator + aFile));
//						while( iRetry < 2 ) {
//							if( isDownOK = client.retrieveFile(aFile, bos) ) {
//								break;
//							}
//							iRetry++;
//						}
//						bos.flush();
//						bos.close();
//						bos = null;
//						System.gc();
//						
//						if( isDownOK ) {
//							logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + aFile + "]");
//							// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
//							if( client.rename(aFile, aFile.concat(".ok")) ) {
//								logger.info("[DEBUG] Succeeded to rename.");
//							}else {
//								logger.info("[DEBUG] Failed to rename.");
//							}
//						}else {
//							logger.info("[ERROR4] Can't get file from FTP server");
//						}
//					}
//				}
				String targetFileNM = "";
				for(int i = 0;i < 2;i++) {
					targetFileNM = "2500CV002" + Integer.toString(i + 1) + "." + stdDate;
					iRetry = 0;
					bos = new BufferedOutputStream(new FileOutputStream(downPath + File.separator + targetFileNM));
					while( iRetry < 2 ) {
						if( isDownOK = client.retrieveFile(targetFileNM, bos) ) {
							break;
						}
						iRetry++;
					}
					bos.flush();
					bos.close();
					bos = null;
					System.gc();
				}
				
				// 파일 읽어서 DB Insert
				logger.info("SSGMbsTranPollingAction ::: SSGPOINT INSERT START");
				SSGMbsTranInst insert = new SSGMbsTranInst(downPath);
				insert.start();
				
				client.logout();
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			if( input != null ) {
				try { input.close(); }catch(Exception e) {}
			}
			if( bos != null ) {
				try { bos.close(); }catch(Exception e) {}
			}
			if( client != null && client.isConnected() ) {
				try { client.disconnect(); }catch(Exception e) {}
			}
		}
	}
	
	
//neo0531
	public void getCardBin() {
		FTPClient client = null;
		InputStream input = null;
		BufferedOutputStream bos = null;
		String basePath = "";
		String upPath = "";
		String downPath = "";
		
		String ssg_ftp_ip = "";
		int ssg_ftp_port = 0;
		String ssg_ftp_id = "";
		String ssg_ftp_pwd = "";
		int iRetry = 0;
		
		try {
			logger.info("<<< SSGMbsTranPollingAction ::: getCardBin START >>>");
			
			ssg_ftp_ip = PropertyUtil.findProperty("communication-property", "SSGPOINT_FTP_SERVER_IP");
			ssg_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGPOINT_FTP_SERVER_PORT"));
			ssg_ftp_id = PropertyUtil.findProperty("communication-property", "SSGPOINT_FTP_SERVER_ID");
			ssg_ftp_pwd = PropertyUtil.findProperty("communication-property", "SSGPOINT_FTP_SERVER_PWD");
			
			logger.info("SSGMbsTranPollingAction ::: SET SSGPOINT SERVER INFO FIN.");
			client = new FTPClient();
			client.setControlEncoding("euc-kr");
			client.connect(ssg_ftp_ip, ssg_ftp_port);
			
			int resultCode = client.getReplyCode();
			logger.info("SSGMbsTranPollingAction ::: SET SSGPOINT SERVER CONN CODE >>> ["+resultCode+"]");
			
			if( !FTPReply.isPositiveCompletion(resultCode) ) {
				logger.info("[ERROR1] Can't connect on FTP server");
				throw new Exception();
			}else {
				logger.info("<<< SSGMbsTranPollingAction ::: SEND EMART24 FILES TO SSGPOINT SERVER START >>>");
				client.setSoTimeout(5000);
				boolean isLogin = false;
				isLogin = client.login(ssg_ftp_id, ssg_ftp_pwd);
				if( !isLogin ) {
					logger.info("[ERROR2] Can't login on FTP server");
					throw new Exception();
				}
				
				client.setFileType(FTP.BINARY_FILE_TYPE);
				client.enterLocalPassiveMode();
				
				basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");
//				upPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "ssgpoint";
//				
//				List<File> upFolder = getDirFileList(upPath);
//				
//				boolean isUploadOK = false;
//				if( upFolder.size() > 0 ) {
//					logger.info("upFolder size : " + Integer.toString(upFolder.size()));
//					for(int i = 0;i < upFolder.size();i++) {
//						if( !upFolder.get(i).isFile() ) {
//							continue;
//						}
//						String targetFileNM = upFolder.get(i).getName();
//						logger.info("FileNM : " + targetFileNM);
//						
//						try {
//							iRetry = 0;
//							
//							input = new FileInputStream(new File(upPath + File.separator + targetFileNM));
//							while( iRetry < 2 ) {client.g
//								if( isUploadOK = client.storeFile("/CnvToSpoint/" + targetFileNM, input) ) {
//									logger.info("File " + targetFileNM + "successfuly uploaded");
//									break;
//								}
//								iRetry++;
//							}
//							input.close();
//							input = null;
//							System.gc();
//							
//							if( isUploadOK ) {
//								moveFile(upPath, targetFileNM, upPath + File.separator + "backup");
//								logger.info("moved File!");
//							}
//						}catch(Exception e) {
//							logger.info("[ERROR3] File " + targetFileNM + "upload error.");
//							throw new Exception();
//						}
//					}
//				}
				
				downPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "ssgpoint";
				
				File downDir = new File(downPath);
				
				if( !downDir.exists() ) {
					downDir.mkdir();
				}
				
				boolean isDownOK = false;
				boolean bIsChanged = client.changeWorkingDirectory("/SpointToCnv");
				logger.info(client.getReplyString());
				if( bIsChanged ) {
					logger.info("successfully changed working deirectory.");
				}else {
					logger.info("Failed to change working deirectory.");
				}
				Calendar calendar = new GregorianCalendar(Locale.KOREA);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String stdDate = sdf.format(calendar.getTime());
				
//				String[] files = client.listNames();
//				if( files != null && files.length > 0 ) {
//					for(String aFile:files) {
//						logger.info("[DEBUG] File list : " + aFile);
//						if( aFile.length() < 19 ) {
//							continue;
//						}
//						if( !(aFile.substring(11, 19)).equals(stdDate) ) {
//							continue;
//						}
//						iRetry = 0;
//						bos = new BufferedOutputStream(new FileOutputStream(downPath + File.separator + aFile));
//						while( iRetry < 2 ) {
//							if( isDownOK = client.retrieveFile(aFile, bos) ) {
//								break;
//							}
//							iRetry++;
//						}
//						bos.flush();
//						bos.close();
//						bos = null;
//						System.gc();
//						
//						if( isDownOK ) {
//							logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + aFile + "]");
//							// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
//							if( client.rename(aFile, aFile.concat(".ok")) ) {
//								logger.info("[DEBUG] Succeeded to rename.");
//							}else {
//								logger.info("[DEBUG] Failed to rename.");
//							}
//						}else {
//							logger.info("[ERROR4] Can't get file from FTP server");
//						}
//					}
//				}
				String targetFileNM = "";
				//for(int i = 0;i < 2;i++) {
					targetFileNM = "2500CV0023" + "." + stdDate;
					iRetry = 0;
					bos = new BufferedOutputStream(new FileOutputStream(downPath + File.separator + targetFileNM));
					while( iRetry < 2 ) {
						if( isDownOK = client.retrieveFile(targetFileNM, bos) ) {
							break;
						}
						iRetry++;
					}
					bos.flush();
					bos.close();
					bos = null;
					System.gc();
				//}
				
				// 파일 읽어서 DB Insert
				logger.info("SSGMbsTranPollingAction ::: SSGPOINT CARD BIN INSERT START");
				SSGMbsCardBinInst insert = new SSGMbsCardBinInst(downPath);
				insert.start();
				
				client.logout();
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			if( input != null ) {
				try { input.close(); }catch(Exception e) {}
			}
			if( bos != null ) {
				try { bos.close(); }catch(Exception e) {}
			}
			if( client != null && client.isConnected() ) {
				try { client.disconnect(); }catch(Exception e) {}
			}
		}
	}
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();

			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
		}
		
		return dirFileList;
	}
	
	public void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}else {
					if( sendingFile.renameTo(sendedFile) ) {
						break;
					}
				}
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("[ERROR] " + ie.getMessage());
				}
			}
		}
	}
}