package biz.cms_RailPlusReceiver;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class RailPlusReceiverInst extends Thread {
	private static Logger logger = Logger.getLogger(RailPlusReceiverAction.class);
	
	String path = "";
	
	public RailPlusReceiverInst(String path) {
		this.path = path;
	}
	
	public void run() {
		String fileNM = "";
		
		try {
			List<File> file = getDirFileList(path);
			
			logger.info(" >>>>>>>>>>>>>>>>>>>> file cnt : " + Integer.toString(file.size()));
			
			for(int i = 0;i < file.size();i++) {
				fileNM = file.get(i).getName();
				
				logger.info(" >>>>>>>>>>>>>>>>>>> file name : " + fileNM);
				
				int len = 0;
				int totLen = 0;
				String readLine = "";
				
				long fileSize = (file.get(i)).length();
				
				byte buf[] = new byte[(int)fileSize];
				InputStream is = new FileInputStream(file.get(i));
				
//				BufferedReader br = new BufferedReader(new FileReader(file.get(i)));
				StringBuffer sb = new StringBuffer();
				
				while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
					logger.info("fileSize="+Integer.toString((int)fileSize));
					sb.append(new String(buf));
					totLen += len;
					logger.info("totLen="+Integer.toString((int)totLen));
					if( totLen == fileSize ) {
						break;
					}
				}
				
				is.close();
				
				logger.info("fileNM="+fileNM);
				
				String[] fileNMSplited = fileNM.split("[.]");
				
				logger.info("file name="+fileNMSplited[0]);
				
				if( fileNMSplited[0].equals("KPP1") ) {					// 지불반송
					this.insertFileKPP1(sb.toString());					
				}else if( fileNMSplited[0].equals("KA05") ) {			// 환불반송
					this.insertFileKA05(sb.toString());					
				}else if( fileNMSplited[0].equals("KCR1") ) {			// 충전대사내역
					this.insertFileKCR1(sb.toString());
				}else if( fileNMSplited[0].equals("KWR1") ) {			// 가맹점별온라인충전정산결과 (가맹점별 온라인 충전 정산결과)
					this.insertFileKWR1(sb.toString());
				}else if( fileNMSplited[0].equals("KWP1") ) {			// 가맹점별지불거래정산결과 (가맹점별 지불거래내역 정산결과)				
					this.insertFileKWP1(sb.toString());
				}
				
				// 파일 옮기기...
				this.moveFile(path, fileNM, path + File.separator + "backup");
				logger.info("[DEBUG] File " + fileNM + " processed successfuly.");
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	// 지불반송 파일
	private void insertFileKPP1(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			RailPlusReceiverDAO dao = new RailPlusReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*RailPlusReceiverProtocol.LENGTH_BY_RECORD, RailPlusReceiverProtocol.LENGTH_BY_RECORD);
				totLen += RailPlusReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(6) == 'H' ) {
					hm = getRailPlusPAYRslt_HDR(strRecord);
					adjt_dt = hm.get("ADJ_YMD");
				}else if( strRecord.charAt(6) == 'D' ) {
					hm = getRailPlusPAYRslt_DAT(strRecord);
					hm.put("CO_CD", com_cd);
					// 정산결과코드가 정상('00') or 중복('01') 이라면 정산확정
					if( (((String)hm.get("ADJT_RSLT_CD")).trim()).equals("0000") || (((String)hm.get("ADJT_RSLT_CD")).trim()).equals("0001") ) {
						logger.info(" >>>>>>>>> 정상");
						hm.put("PROC_ID", "4");
					}else {
						logger.info(" >>>>>>>>> 반송");
						hm.put("PROC_ID", "3");
					}
					
					hm.put("FILE_MK_DT", adjt_dt);
					try {
						dao.updRailPlusPAYMENT_DTL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}else if( strRecord.charAt(6) == 'T' ) {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	// 환불반송 파일
	private void insertFileKA05(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			RailPlusReceiverDAO dao = new RailPlusReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*RailPlusReceiverProtocol.LENGTH_BY_RECORD, RailPlusReceiverProtocol.LENGTH_BY_RECORD);
				totLen += RailPlusReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(6) == 'H' ) {
					hm = getRailPlusREFRslt_HDR(strRecord);
					adjt_dt = hm.get("ADJ_YMD");
				}else if( strRecord.charAt(6) == 'D' ) {
					hm = getRailPlusREFRslt_DAT(strRecord);
					hm.put("CO_CD", com_cd);					
					// 정산결과코드가 정상('00') or 중복('01') 이라면 정산확정
					if( (((String)hm.get("ADJT_RSLT_CD")).trim()).equals("0000") || (((String)hm.get("ADJT_RSLT_CD")).trim()).equals("0001") ) {
						logger.info(" >>>>>>>>> 정상");
						hm.put("PROC_ID", "4");
					}else {
						logger.info(" >>>>>>>>> 반송");
						hm.put("PROC_ID", "3");
					}
					
					hm.put("FILE_MK_DT", adjt_dt);
					
					try {
						dao.updRailPlusREFUND_DTL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}else if( strRecord.charAt(6) == 'T') {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	// 충전대사내역 파일
	private void insertFileKCR1(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			RailPlusReceiverDAO dao = new RailPlusReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*RailPlusReceiverProtocol.LENGTH_BY_RECORD, RailPlusReceiverProtocol.LENGTH_BY_RECORD);
				totLen += RailPlusReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getRailPlusCHRGRslt_HDR(strRecord);
					hm.put("CO_CD", com_cd);
					adjt_dt = hm.get("ADJT_YMD");
					
					try {
						dao.insRailPlusCHRGRslt_HDR(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getRailPlusCHRGRslt_DAT(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("CARD_KEY", card_key);
					hm.put("DOUBLE_CARD_KEY", double_card_key);
					
					try {
						dao.insRailPlusCHRGRslt_DAT(hm, adjt_dt);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}					
				}else if( strRecord.charAt(0) == 'T' ) {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	// 가맹점별 온라인충전정산결과 파일
	private void insertFileKWR1(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			RailPlusReceiverDAO dao = new RailPlusReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*RailPlusReceiverProtocol.LENGTH_BY_RECORD, RailPlusReceiverProtocol.LENGTH_BY_RECORD);
				totLen += RailPlusReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(6) == 'H' ) {
					hm = getRailPlusCHRGADJTRsltByFcstr_HDR(strRecord);
					adjt_dt = hm.get("ADJT_YMD");
				}else if( strRecord.charAt(6) == 'D' ) {
					hm = getRailPlusCHRGADJTRsltByFcstr_DAT(strRecord);
					hm.put("CO_CD", com_cd);
					
					try {
						dao.insRailPlusCHRGADJTRsltByFcstr(hm, adjt_dt);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}else if( strRecord.charAt(6) == 'T' ) {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	// 가맹점별 온라인지불거래정산결과 파일
	private void insertFileKWP1(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			RailPlusReceiverDAO dao = new RailPlusReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*RailPlusReceiverProtocol.LENGTH_BY_RECORD, RailPlusReceiverProtocol.LENGTH_BY_RECORD);
				totLen += RailPlusReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(6) == 'H' ) {
					hm = getRailPlusPAYADJTRsltByRcstr_HDR(strRecord);
					adjt_dt = hm.get("ADJT_YMD");
				}else if( strRecord.charAt(6) == 'D' ) {
					hm = getRailPlusPAYADJTRsltByFcstr_DAT(strRecord);
					hm.put("CO_CD", com_cd);
					
					try {
						dao.insRailPlusPAYADJTRsltByFcstr(hm, adjt_dt);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}else if( strRecord.charAt(6) == 'T' ) {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private HashMap<String, String> getRailPlusPAYRslt_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {3,3,1,14,8
					  ,5,12,353,1};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",			
			"FILE_CRTD_YMDHMS",
			"ADJ_YMD",
			
			"TRANS_CNT",
			"TRANS_AMT",
			"FILLER",
			"NEWLN_CHAR"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getRailPlusREFRslt_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {3,3,1,8,14
					  ,8,5,12,345,1};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",
			"FCSTR_ID",			
			"FILE_CRTD_YMDHMS",
			
			"ADJ_YMD",			
			"TRANS_CNT",
			"TRANS_AMT",
			"FILLER",
			"NEWLN_CHAR"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getRailPlusCHRGADJTRsltByFcstr_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {3,3,1,14,8
					  ,370,1};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",
			"FILE_CRTD_YMDHMS",
			"ADJT_YMD",
			
			"FILLER",
			"NEWLN_CHAR"				
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getRailPlusPAYADJTRsltByRcstr_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {3,3,1,14,8
					  ,370,1};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",
			"FILE_CRTD_YMDHMS",
			"ADJT_YMD",
			
			"FILLER",
			"NEWLN_CHAR"				
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getRailPlusCHRGADJTRsltByFcstr_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {3,3,1,4,7
					  ,7,13,10,7,13
					  ,10,7,13,10,292};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",
			"SEQ_NO",
			"DEAL_BRANCH_CD",
			
			"TOT_CHRG_CNT",
			"TOT_CHRG_AMT",
			"TOT_CHRG_FEE",
			"TOT_CHRGCNCL_CNT",
			"TOT_CHRGCNCL_AMT",
			
			"TOT_CHRGCNCL_FEE",
			"TOT_REFCHRG_CNT",
			"TOT_REFCHRG_AMT",
			"TOT_REFCHRG_FEE",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getRailPlusPAYADJTRsltByFcstr_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {3,3,1,4,7
					  ,7,13,10,7,13
					  ,10,322};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",
			"SEQ_NO",
			"DEAL_BRANCH_CD",
			
			"TOT_PAY_CNT",
			"TOT_PAY_AMT",
			"TOT_PAY_FEE",
			"TOT_RET_CNT",
			"TOT_RET_AMT",
			
			"TOT_RET_FEE",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getRailPlusCHRGRslt_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,7,7,13,10
					  ,7,13,10,7,13
					  ,10,8,14,279,1};
		String strHeaders[] = {
			"RECORD_TP",
			"TOT_RECORD_CNT",
			"TOT_CHRG_CNT",
			"TOT_CHRG_AMT",
			"TOT_CHRG_FEE",
			
			"TOT_CHRGCNCL_CNT",
			"TOT_CHRGCNCL_AMT",
			"TOT_CHRGCNCL_FEE",
			"TOT_REFCHRG_CNT",
			"TOT_REFCHRG_AMT",
			
			"TOT_REFCHRG_FEE",
			"ADJT_YMD",
			"FILE_CRTD_YMDHMS",
			"FILLER",
			"NEWLN_CHAR"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getRailPlusPAYRslt_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {3,3,1,5,8
					  ,20,10,40,10,14
					  ,1,2,7,10,4
					  ,10,20,10,10,10
					  ,10,3,3,3,3
					  ,16,10,10,10,10
					  ,5,10,8,10,1
					  ,10,8,4,67,1};
		String strHeaders[] = {
			"RECORD_LEN",
			"JOB_TP",
			"RECORD_TP",
			"SEQ_NO",
			"FCSTR_ID",
			
			"TRAN_ID",
			"DEAL_BRANCH_CD",
			"DEAL_BRANCH_NM",
			"TMNAL_ID",
			"TRAN_DTM",
			
			"CARD_TP_VAL",
			"RAILPLUS_HOLDER_TP",
			"PUBCO_ID",
			"ORG_DEAL_AMT",  				// 원거래금액
			"PAYMENT_DIS_RATE",  			// 지불할인율
			
			"PAYMENT_DIS_AMT",  			// 지불할인금액
			"PPCARD_NO",  					// ID_EP(교통카드번호)
			"PPCARD_TRAN_SEQ_NO",  			// NT_EP(카드거래일련번호)
			"PAY_AMT",  					// 거래금액(MPDA)
			"PPCARD_PRE_REM_AMT",  			// BAL_EP_BEFORE(거래전 카드잔액)
			
			"PPCARD_REM_AMT",  				// BAL_EP(거래후 카드잔액)
			"TRAN_TP",
			"ALGO_ID",
			"KEYSET_VER",
			"ELE_MONY_IDTY",  				// ID_CENTER(전자화폐식별자)
			
			"PSAM_ID",
			"BEF_DEAL_SAM_AMT",  			// BAL_SAM_BEFORE(거래전 SAM잔액)
			"AFT_DEAL_SAM_AMT",  			// BAL_SAM(거래후 SAM잔액)
			"PSAM_TRAN_SEQ_NO",
			"PSAM_TOT_AMT_COLECT_SEQ_NO",
			
			"PSAM_SPBY_COLECT_CNT",
			"PSAM_ACCM_TOT_AMT",
			"SIGN_VAL_IND",  				// SIGN_IND
			"ALIAS_NO",  					// Alias 번호
			"CARDPLSTS_YN",
			
			"REFUND_FEE",  					// 지불수수료
			"ASK_DT",  						// 청구일자
			"ADJT_RSLT_CD",					// 정산결과코드
			"FILLER",
			"NEWLN_CHAR"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getRailPlusCHRGRslt_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,7,20,7,10
					  ,40,10,16,2,4
					  ,14,14,10,3,2
					  ,14,10,10,10,10
					  ,1,2,8,174,1};
		String strHeaders[] = {
			"RECORD_TP",					// 레코드구분
			"SEQ_NO",						// 일련번호
			"TRAN_ID",						// TRANSACTION ID
			"FCSTR_ID",						// 가맹점ID
			"DEAL_BRANCH_CD",				// 거래지점코드
			
			"DEAL_BRANCH_NM",				// 거래지점명
			"TMNAL_ID",						// 단말기ID
			"PPCARD_NO",					// 선불카드ID
			"PPCARD_HOLDER_TP",				// 교통카드 사용자 구분코드
			"PPCARD_STS_CD",				// 카드상태코드
			
			"CHRG_REQ_YMDHMS",				// 충전요청일시
			"COMP_TRANS_YMDHMS",			// 완료전문전송일시
			"CARD_TRN_SEQ_NO",				// 카드거래일련번호
			"JOB_TP",						// 작업구분('002':충전,'003':반환,'004':직전충전취소,'005':쿠폰충전)
			"PAY_TP",						// 결제구분
			
			"CHRG_YMDHMS",					// 충전일시
			"BEF_DEAL_REM_AMT",				// 충전전잔액
			"DEAL_REQ_AMT",					// 충전요청금액
			"AFT_DEAL_REM_AMT",				// 충전후잔액
			"DEAL_FEE",						// 충전수수료
			
			"HSM_STS",						// HSM상태
			"JOB_RSLT",						// 작업결과
			"RAILPLUS_FCSTR_ID",			// 레일플러스가맹점ID
			"FILLER",						// FILLER
			"NEWLN_CHAR"					// 개행문자
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getRailPlusREFRslt_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {3,3,1,4,20
				  	  ,10,40,10,2,14
				  	  ,2,1,20,10,3
				  	  ,2,10,10,10,10
				  	  ,3,3,16,10,10
				  	  ,5,10,8,8,4
				  	  ,137,1};
		String strHeaders[] = {
				"RECORD_LEN",
				"JOB_TP",
				"RECORD_TP",
				"SEQ_NO",
				"TRAN_ID",
				
				"DEAL_BRANCH_CD",
				"DEAL_BRANCH_NM",
				"TMNAL_ID",
				"TMNAL_TP",
				"TRAN_DTM",
				
				"PPCARD_HOLDER_TP",
				"PPCARD_TP",
				"PPCARD_NO",
				"PPCARD_TRN_SEQ_NO",			// 카드거래일련번호
				"TRN_TP",						// 거래유형
				
				"REFUND_TP",					// 환불유형
				"REFUND_AMT",					// 거래금액
				"BEF_TRN_REM_AMT",				// 거래전카드잔액
				"AFT_TRN_REM_AMT",				// 거래후카드잔액
				"REFUND_FEE",					// 환불수수료
				
				"ELEC_MNY_ID",					// 전자화폐식별자
				"KEYSET_VER",					// 키셋버전
				"SAM_ID",						// SAM ID
				"SAM_TRN_SEQ_NO",				// SAM거래일련번호
				"SAM_TOT_AMT_TRN_COL_CNT",		// SAM총액거래수집건수
				
				"SAM_SPY_TRN_COL_CNT",			// SAM개별거래수집건수
				"SAM_ACC_TRN_COL_CNT",			// SAM누적거래수집건수
				"SIGN_VAL_ID",					// SIGN_IND
				"DEM_DT",						// 청구일자
				"ADJT_RSLT_CD",					// 정산결과코드
				
				"FILLER",						// FILLER
				"NEWLN_CHAR"					// 개행문자
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getRailPlusCHRGRslt_TAL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,6,7,7,13
					  ,10,7,13,10,7
					  ,13,10,196};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"TOT_RECORD_CNT",
			"TOT_RECHRG_CNT",
			"TOT_RECHRG_AMT",
			
			"TOT_RECHRG_FEE",
			"TOT_RECHRGCNCL_CNT",
			"TOT_RECHRGCNCL_AMT",
			"TOT_RECHRGCNCL_FEE",
			"TOT_RETRECHRG_CNT",
			
			"TOT_RETRECHRG_AMT",
			"TOT_RETRECHRG_FEE",
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
//			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
}
