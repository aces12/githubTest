package biz.cms_ScAgentSender;

import java.net.Socket;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

/** 
 * ScAgentSenderPollingAction
 * ScAgent 명령문 전송
 * @created  on 1.0,  16/05/10
 * @created  by wkh
 *  
 * @modified on 
 * @modified by ok
 * @caused   by 
 */ 
public class ScAgentSenderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(ScAgentSenderPollingAction.class);
	
	private String server_ip = "";
	private int server_port = 0;
	ScAgentSenderConveyer conveyer = null;
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public static void main(String args[]) throws Exception {
		ScAgentSenderPollingAction action = new ScAgentSenderPollingAction();
		
		String path          = nvl(args[0].replaceFirst("-path:"  ,""));
//		String path          = "";
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);

		try {
			if (args == null || args.length < 1) {
				logger.info("------ SvArrivalSync main args null");
			}

			action.execute("");
			
		}catch(Exception e) {
			System.out.println("[ERROR]" + e.getMessage());
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	@Override
	public void execute(String actionMode) {
		Socket extClntSock = null;
		ScAgentSenderDAO dao = new ScAgentSenderDAO(); 
		COMMLog df = new COMMLog();
		HashMap<String, String> hm = new HashMap<String, String>();
		String scflag  = null;
		
		// TODO Auto-generated method stub
		try {
			List<Object> list = null;
			int totalCount = 0; 
			int i = 0;

			scflag = PropertyUtil.findProperty("communication-property", "SCAGENT_COMM_FLAG");
			list = dao.selScAgentSend(scflag); 
			logger.info("▶ sc전송 [" + list.size() + "]건 진행 시작");
			totalCount = list.size();
			
			if( totalCount > 0) {
				
				this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SCAGENT_COMM_PORT"));

				for(i = 0; i < list.size(); i++){	
					logger.info("▶ sc전송 [" + (i+1) + "]" + list.get(i) + " 진행 시작");	
					hm = (HashMap<String, String>) list.get(i);
					this.server_ip = (String)hm.get("SC_IP");
					
					logger.info("▶ sc전송  ip : " + server_ip + ", port : " + server_port);	
					
					extClntSock = new Socket(server_ip, server_port);	
					conveyer = new ScAgentSenderConveyer(extClntSock, df);		
					conveyer.ScAgentSenderConveyer(list.get(i));	
				}

/*
				this.server_ip = PropertyUtil.findProperty("communication-property", "SCAGENT_COMM_IP");
				this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SCAGENT_COMM_PORT"));			

				logger.info("▶ sc전송  ip : " + server_ip + ", port : " + server_port);	

				extClntSock = new Socket(server_ip, server_port);	
				conveyer = new ScAgentSenderConveyer(extClntSock, df);		

				for(i = 0; i < list.size(); i++){	
					logger.info("▶ sc전송 [" + (i+1) + "]" + list.get(i) + " 진행 시작");			 
					conveyer.ScAgentSenderConveyer(list.get(i));	
				}
*/				
				
			}			
			logger.info("▶ sc전송 [" + list.size() + "]건 진행 종료");		
		}catch(Exception e) {
			logger.info("", e);
		}
	}

}
