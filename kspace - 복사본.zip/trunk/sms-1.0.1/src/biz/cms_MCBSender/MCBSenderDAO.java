package biz.cms_MCBSender;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

// 송신하기 위한 전문생성?
public class MCBSenderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(MCBSenderPollingAction.class);
	//  sms 송신
	public int spSMSSEND(String strMsg, String strSender) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("sysinq-sql", "PR_SMSSEND"));
			sql.setString(++i, strMsg);
			sql.setString(++i, strSender);
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
			rollback();
		}finally {
			end();
		}
		
		return ret;
	}
	// STBDA200AT 에 등록된 내역 조회
	public List<Object> selSVCFILEDAILY(String stdYmd, String svcID, String cmdTp, String comCD) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SVCCRTDAILY"));
			sql.setString(++i, stdYmd);
			sql.setString(++i, svcID);
			sql.setString(++i, cmdTp);
			sql.setString(++i, comCD);
			System.out.println(" sql : " + sql.debug());
			
			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		} 
		
		return list;
	}
	// STBDA200AT 에 신규 값 등록
	public int insSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			
			System.out.println(" sql : " + sql.debug());
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	// STBDA200AT 에 값 업데이트
	public int updSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			//df.CommLogger("▶ SEL Error : " + e);
			//df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			rollback();	
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	// HQ_CO_MST 에서 이마트24의 사업자번호를 복호화 해서 출력
//	public List<Object> getWITHMEBizCoNo(String co_cd) {
//		SqlWrapper sql = new SqlWrapper();
//		List<Object> list = null;
//		int i = 0;
//		
//		try {
//			//DB Connection(DB 접속)
//			connect("CMGNS");
//			
//			sql.put(findQuery("service-sql", "SEL_WITHMEBIZCONUM"));
//			sql.setString(++i, "A110010");
//			sql.setString(++i, co_cd);			
//			
//			list = executeQuery(sql);
//		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
//		}
//		
//		return list;
//	}
	// 카드 사용 내역에 대해서 조회 하여 출력 (이게 실제로 등록되어야 하는 데이터 조회 부분)
	public List<Object> selMCBPAYTRAN() throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			// 조회 해야 하는 것은 처리 되지 않은 내역만 보면 됨.
			sql.put(findQuery("service-sql", "SEL_MCBPAYTRAN")); 
			System.out.println(" sql : " + sql.debug());
			list = executeQuery(sql);
			
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	// 카드 사용 내역에 대해서 조회 하여 출력
	public List<Object> selMCBCHGTRAN(String com_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_MCBPAYTRAN"));
			sql.setString(++i, com_cd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	// 카드 사용 내역에 대해서 조회 하여 출력
	public int updMCBCHGTRAN(String proc_id, String com_cd, String tran_id) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_MCBCHGTRAN"));
			sql.setString(++i, proc_id);
			sql.setString(++i, com_cd);
			sql.setString(++i, tran_id);
			
			logger.info(" sql : " + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	// ???? 없음. 실행 안하는듯
	public int updMCBCHGTRAN_2(String proc_id, String com_cd, String tran_id) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_MCBCHGTRAN_2"));
			sql.setString(++i, proc_id);
			sql.setString(++i, com_cd);
			sql.setString(++i, tran_id);
			
//			logger.info(" sql : " + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int updMCBTRAN(  String proc_id
			              , String com_cd
			              , String tran_ymd
			              , String store_cd
			              , String pos_no
			              , String tran_no
			              , String item_seq
	) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_MCBTRAN"));
			sql.setString(++i, proc_id);
			sql.setString(++i, com_cd);
			sql.setString(++i, tran_ymd);
			sql.setString(++i, store_cd);
			sql.setString(++i, pos_no);
			sql.setString(++i, tran_no);
			sql.setString(++i, item_seq);
			logger.info(" sql : " + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
}
