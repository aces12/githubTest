package biz.cms_MCBSender;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;
import biz.comm.SFTPManager;

public class MCBSenderFileTransfer {
	private static Logger logger = Logger.getLogger(MCBSenderPollingAction.class);
	
	private String server_ip = "";
	private int server_port = 0;
	
	private Socket sock = null;
	private ActionSocket actSock = null;
	
	private String mcb_ftp_ip = "";
	private int mcb_ftp_port = 0;
	private String mcb_ftp_id = "";
	private String mcb_ftp_pwd = "";
	
	/*
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();

			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
		}
		
		return dirFileList;
	}
	*/
	public void moveFile(String orgPath, String fileNM, String destPath, COMMLog df) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdir();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		logger.info("orgFile = " + orgPath + File.separator + fileNM);
		logger.info("destFile = " + destPath + File.separator + fileNM);
		
		if( destFile.exists() ) {
			if( orgFile.delete() ) {
				logger.info("[DEBUG] File(" + orgFile.getPath() + " / "+ orgFile.getName() + ") Deleted");
			}else {
				logger.info("[DEBUG] Fail to remove file(" + orgFile.getPath() + " / "+ orgFile.getName() + ")");
			}
		}else {
			for(int i = 0;i < 20;i++) {
				if( orgFile.renameTo(destFile) ) {
					logger.info(">> MOVE OK : " + destFile.getName());
					break;
				}
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					df.CommLogger("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}

	public void transferMST() {
		System.out.println("transferMST() " );
		SFTPManager sFtpMgr = null;

		
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isSendOK = false;
		String targetPathNm = "";  
		String stdDate = "";
		
		String targetFileNm = "";
		
		try {			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			//neo0531 for test
			//basePath = "C:\\CMBO";			
			destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "MCB";		
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

			calendar.setTime(new Date());
//			calendar.add(Calendar.DATE, 1);
			stdDate = sdf.format(calendar.getTime());
			
			targetFileNm = "EMART24_" + stdDate.substring(0,8) + ".txt";

			this.mcb_ftp_ip = PropertyUtil.findProperty("communication-property", "MCB_FTP_SERVER_IP");
			this.mcb_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "MCB_FTP_SERVER_PORT"));
			this.mcb_ftp_id = PropertyUtil.findProperty("communication-property", "MCB_FTP_SERVER_ID");
			this.mcb_ftp_pwd = PropertyUtil.findProperty("communication-property", "MCB_FTP_SERVER_PWD");

			try{
				sFtpMgr = new SFTPManager(mcb_ftp_ip, mcb_ftp_port, mcb_ftp_id, mcb_ftp_pwd);
				logger.info("TRY Connected to " + mcb_ftp_ip + ":" + mcb_ftp_port);
			}catch(Exception e){
				System.out.println("exception ["+e.getMessage()+"]");
				logger.info("exception occur"+e.getMessage());
				logger.info(" SFTP Connect fail exception occur ");
				return;
			}					
			System.out.println(" SFTP Connection is Success ");	
			logger.info(" SFTP Connection is Success ");	
							
			targetPathNm = destPath + File.separator + targetFileNm;
			isSendOK = false;
			
			iRetry = 0;	
			sFtpMgr.cd(sFtpMgr.pwd()); // 경로변경(현재경로+Emart폴더)
			
			while( iRetry < 2 ) {				
				if( isSendOK = sFtpMgr.put(targetPathNm)) {		
				//if( isSendOK = sFtpMgr.put(destPath)) {
					break;
				}
				iRetry++;
			}			
		}catch(Exception e) {
			System.out.println("[ERROR1] " + e.getMessage());
			logger.info("[ERROR1] " + e.getMessage());
		}finally {
			try {					
				File oldFileNm = new File(targetPathNm);			
				if(isSendOK ) {
					logger.info(" >>>>>>>>>>>>> successfully upload file [" + targetFileNm + "]");
					// 송신완료한 파일은 rename을 통해 송신완료한 파일인지 구분한다.					
					File newFileNm = new File(targetPathNm +".ok");
					targetFileNm = targetPathNm +".ok";
				
					if(oldFileNm.renameTo(newFileNm))
						logger.info("rename work well done");	
					else
						logger.info("[DEBUG] Failed to rename.");
					
					moveFile(destPath, newFileNm.getName(), destPath + File.separator + "backup");
					logger.info("FTP work well done");
				

										
				}else {
					logger.info("[ERROR2] Can't put " + targetFileNm + " to FTP server");
					File newFileNm = new File(targetPathNm +".sendfail");
					targetFileNm = targetPathNm +".sendfail";
					if(oldFileNm.renameTo(newFileNm)){					
						logger.info("[DEBUG] Succeeded to rename.");
					}else {
						logger.info("[DEBUG] Failed to rename.");				
					logger.info("[ERROR2] Can't put file on FTP server");
				}			
			}
			}catch(Exception e) {}
		}		
	}		
	
	public  void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//					logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}	
}
