package biz.cms_ETCTransCardIrt;

import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;



public class ETCTransCardIrtConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;

	COMMLog df = null;
	
	//전문종류 코드
	private final String MID_TMNLOPEN = "INTR1012";			//제휴 단말기 개통/변경 
	private final String MID_OLCHRGREQ = "CHAR0219";		//온라인 충전/충전취소 요청
	private final String MID_OLCHRGRSLT = "CHAR0220";		//온라인 충전/충전취소 결과 수신
	private final String MID_COUPCHECK = "CHAR0213";		//쿠폰충전 PIN번호 유효성 확인요청
	private final String MID_CARDCHECK = "INTR2001";		//실시간 한페이카드 BL 체크
	
	private final String WITHME_HELPDESK_TEL = "02 6916 1500";	//위드미 헬프데스크 전화번호
	
	public ETCTransCardIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}
	
	static class ErrorCD {
		public static String getErrorMsg(int workType, String code) {
			String strMsg = "";
			switch( workType ) {
				case 0:		//온라인 충전
					if( code.equals("00") ) {
						strMsg = "송신";
					}else if( code.equals("01") ) {
						strMsg = "정상";
					}else if( code.equals("11") ) {
						strMsg = "송신 구분코드 오류";
					}else if( code.equals("13") ) {
						strMsg = "업무 구분코드 오류";
					}else if( code.equals("15") ) {
						strMsg = "정산일자 오류";
					}else if( code.equals("16") ) {
						strMsg = "해당 전문 기수신 오류";
					}else if( code.equals("17") ) {
						strMsg = "기관코드 오류";
					}else if( code.equals("18") ) {
						strMsg = "전문포맷 오류";
					}else if( code.equals("20") ) {
						strMsg = "Record 길이 오류";
					}else if( code.equals("21") ) {
						strMsg = "수집센터 코드 오류";
					}else if( code.equals("22") ) {
						strMsg = "일련번호 중복";
					}else if( code.equals("23") ) {
						strMsg = "가맹점번호 오류(미등록)";
					}else if( code.equals("24") ) {
						strMsg = "거래종류 오류";
					}else if( code.equals("25") ) {
						strMsg = "충전한도 초과 오류";
					}else if( code.equals("26") ) {
						strMsg = "인증자 오류";
					}else if( code.equals("27") ) {
						strMsg = "거래금액 오류";
					}else if( code.equals("28") ) {
						strMsg = "결제 실패";
					}else if( code.equals("29") ) {
						strMsg = "진행중 재시도";
					}else if( code.equals("30") ) {
						strMsg = "미등록 카드";
					}else if( code.equals("31") ) {
						strMsg = "진행중(응답없음)";
					}else if( code.equals("35") ) {
						strMsg = "미등록 단말기";
					}else if( code.equals("37") ) {
						strMsg = "환불 진행중";
					}else if( code.equals("98") ) {
						strMsg = "단말기 미수신 후 재요청 시 충전금액과 이체완료 금액 상이";
					}else if( code.equals("99") ) {
						strMsg = "시스템오류";
					}
					break;
				case 1:		//개통
					if( code.equals("00") ) {
						strMsg = "송신";
					}else if( code.equals("01") ) {
						strMsg = "정상";
					}else if( code.equals("11") ) {
						strMsg = "송신 구분코드 오류";
					}else if( code.equals("14") ) {
						strMsg = "전문종류 오류";
					}else if( code.equals("16") ) {
						strMsg = "해당전문 기수신 오류";
					}else if( code.equals("17") ) {
						strMsg = "기관코드 오류";
					}else if( code.equals("18") ) {
						strMsg = "전문포맷 오류";
					}else if( code.equals("19") ) {
						strMsg = "Record 길이 오류";
					}else if( code.equals("20") ) {
						strMsg = "수집센터 코드 오류";
					}else if( code.equals("21") ) {
						strMsg = "미등록 단말기";
					}else if( code.equals("22") ) {
						strMsg = "미등록 단말기";
					}else if( code.equals("31") ) {
						strMsg = "미등록 SAM카드";
					}else if( code.equals("32") ) {
						strMsg = "미점용 SAM카드";
					}else if( code.equals("33") ) {
						strMsg = "등록 SAM카드";
					}else if( code.equals("34") ) {
						strMsg = "점용 SAM카드";
					}else if( code.equals("52") ) {
						strMsg = "DATA부 Record 길이 오류";
					}else if( code.equals("99") ) {
						strMsg = "시스템오류";
					}
					break;
				case 2:		//지불
					if( code.equals("01") ) {
						strMsg = "정상";
					}else if( code.equals("99") ) {
						strMsg = "시스템오류(모든인증오류)";
					}
					break;
			}
			
			return strMsg;
		}
	}
	
	private String makeSendDataHanPayHeader(String messageID) {
		HashMap<String, String> hm = new HashMap<String, String>();
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,8,2,8
					  ,6,8};
		String strHeaders[] = { "COL_CENTER_CD"
							  , "AGENT_CD"
							  , "MSG_CD"
							  , "RESP_CD"
							  , "TRANS_YMD"
							  
							  , "TRANS_HMS"
							  , "DATA_LEN"
							  };
		
		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		calendar.setTime(new Date());
		String sys_ymdhms = sdf.format(calendar.getTime());
		
		hm.put(strHeaders[0], "29");						// 수집센터코드
		hm.put(strHeaders[1], "19");						// 기관코드
		hm.put(strHeaders[2], messageID);					// 전문종류코드
		hm.put(strHeaders[3], "00");						// 응답코드
		hm.put(strHeaders[4], sys_ymdhms.substring(0, 8));	// 전송일자
		hm.put(strHeaders[5], sys_ymdhms.substring(8, 14));	// 전송시간
		if( messageID.equals(MID_TMNLOPEN) ) {		// 제휴 단말기 개통/변경
			hm.put(strHeaders[6], "00000350");				// 전문 DATA 길이
		}else if( messageID.equals(MID_OLCHRGREQ) ) {	// 온라인 충전/충전취소 요청
			hm.put(strHeaders[6], "00000300");				// 전문 DATA 길이
		}else if( messageID.equals(MID_OLCHRGRSLT) ) {	// 온라인 충전/충전취소 결과 수신
			hm.put(strHeaders[6], "00000180");				// 전문 DATA 길이
		}else if( messageID.equals(MID_COUPCHECK) ) {	// 쿠폰충전 PIN 번호 유효성 확인요청
			hm.put(strHeaders[6], "00000070");				// 전문 DATA 길이
		}else if( messageID.equals(MID_CARDCHECK) ) {	// 실시간 한페이카드 BL 체크
			hm.put(strHeaders[6], "00000060");				// 전문 DATA 길이
		}
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send HanPayHeader : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getHanPayCARDBLCHKInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		ETCTransCardIrtProtocol protocol = new ETCTransCardIrtProtocol();
		ETCTransCardIrtDAO dao = new ETCTransCardIrtDAO();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 한페이로 보낼 송신 전문
		String recvBuf = "";	// 한페이에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.HANPAY_RT_FILTER)));
			
//			hm.put("FCSTR_NO", (String)hm.get("FCSTR_NO"));
//			hm.put("REQ_YMDHMS", (String)hm.get("REQ_YMDHMS"));
//			hm.put("CCARD_NO", (String)hm.get("CCARD_NO"));
			hm.put("FILLER", " ");
			
			sendMsg = makeSendDataHanPayHeader(MID_CARDCHECK) + makeSendDataHanPayCARDBLCHKInq(hm);
			df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "][" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("HanPay server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<hanpay] RECV[" + recvBuf.getBytes().length + "][" + recvBuf + "]");
			
			hmRecv = protocol.getParseHanPayCARDBLCHKRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataHanPayCARDBLCHKRsp(hmRecv);
		}
		
		return dataMsg;
	}
	
	public String getHanPayCPNPINCHKInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		ETCTransCardIrtProtocol protocol = new ETCTransCardIrtProtocol();
		ETCTransCardIrtDAO dao = new ETCTransCardIrtDAO();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 한페이로 보낼 송신 전문
		String recvBuf = "";	// 한페이에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.HANPAY_RT_FILTER)));
			
//			hm.put("FCSTR_NO", (String)hm.get("FCSTR_NO"));
//			hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID"));
//			hm.put("COUPON_PIN", (String)hm.get("COUPON_PIN"));
//			hm.put("REQ_YMDHMS", (String)hm.get("REQ_YMDHMS"));
			hm.put("FILLER", " ");
			
			sendMsg = makeSendDataHanPayHeader(MID_COUPCHECK) + makeSendDataHanPayCPNPINCHKInq(hm);
			df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "][" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("HanPay server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<hanpay] RECV[" + recvBuf.getBytes().length + "][" + recvBuf + "]");
			
			hmRecv = protocol.getParseHanPayCPNPINCHKRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			hmRecv.put("RESP_MSG", ErrorCD.getErrorMsg(0, (String)hmRecv.get("RESP_CD")));
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataHanPayCPNPINCHKRsp(hmRecv);
		}
		
		return dataMsg;
	}
	
	public String getHanPayCHRGCHRGCNCLRSLTInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		ETCTransCardIrtProtocol protocol = new ETCTransCardIrtProtocol();
		ETCTransCardIrtDAO dao = new ETCTransCardIrtDAO();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 한페이로 보낼 송신 전문
		String recvBuf = "";	// 한페이에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.HANPAY_RT_FILTER)));
			
//			hm.put("DEAL_UNIQ_NO", (String)hm.get("DEAL_UNIQ_NO"));
//			hm.put("FCSTR_NO", (String)hm.get("FCSTR_NO"));
//			hm.put("TRT", (String)hm.get("TRT"));
//			hm.put("IDCENTER", (String)hm.get("IDCENTER"));
//			hm.put("IDEP", (String)hm.get("IDEP"));
//			hm.put("BALEP", (String)hm.get("BALEP"));
//			hm.put("NTEP", (String)hm.get("NTEP"));
//			hm.put("IDLSAM", (String)hm.get("IDLSAM"));
//			hm.put("NTLSAM", (String)hm.get("NTLSAM"));
//			hm.put("RHSM", (String)hm.get("RHSM"));
//			hm.put("SIND3", (String)hm.get("SIND3"));
//			hm.put("REP", (String)hm.get("REP"));
//			hm.put("DEAL_STS_TP", (String)hm.get("DEAL_STS_TP"));
			hm.put("FILLER", " ");
			
			sendMsg = makeSendDataHanPayHeader(MID_OLCHRGRSLT) + makeSendDataHanPayCHRGCHRGCNCLRSLTInq(hm);
			df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "][" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("HanPay server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<hanpay] RECV[" + recvBuf.getBytes().length + "][" + recvBuf + "]");
			
			hmRecv = protocol.getParseHanPayCHRGCHRGCNCLRSLTRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			hmRecv.put("RESP_MSG", ErrorCD.getErrorMsg(0, (String)hmRecv.get("RESP_CD")));
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataHanPayCHRGCHRGCNCLRSLTRsp(hmRecv);
		}
		
		return dataMsg;
	}
	
	public String getHanPayCHRGCHRGCNCLInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		ETCTransCardIrtProtocol protocol = new ETCTransCardIrtProtocol();
		ETCTransCardIrtDAO dao = new ETCTransCardIrtDAO();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 한페이로 보낼 송신 전문
		String recvBuf = "";	// 한페이에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.HANPAY_RT_FILTER)));
			
//			hm.put("DEAL_UNIQ_NO", (String)hm.get("DEAL_UNIQ_NO"));
//			hm.put("FCSTR_NO", (String)hm.get("FCSTR_NO"));
//			hm.put("ISSU_CORP_CD", (String)hm.get("ISSU_CORP_CD"));
//			hm.put("DEAL_YMDHMS", (String)hm.get("DEAL_YMDHMS"));
//			hm.put("ADJT_YMD", (String)hm.get("ADJT_YMD"));
//			hm.put("CARD_TP", (String)hm.get("CARD_TP"));
//			hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID"));
//			hm.put("PROC_CD", (String)hm.get("PROC_CD"));
//			hm.put("CARD_CORP_TP", (String)hm.get("CARD_CORP_TP"));
//			hm.put("PAYMENT_TP", (String)hm.get("PAYMENT_TP"));
//			hm.put("PAYMENT_TP_PIN_CD", (String)hm.get("PAYMENT_TP_PIN_CD"));
//			hm.put("COUPON_ISSU_CORP_CD", (String)hm.get("COUPON_ISSU_CORP_CD"));
//			hm.put("TRT", (String)hm.get("TRT"));
//			hm.put("IDCENTER", (String)hm.get("IDCENTER"));
//			hm.put("IDEP", (String)hm.get("IDEP"));
//			hm.put("ALGEP", (String)hm.get("ALGEP"));
//			hm.put("VKDL_KEY", (String)hm.get("VKDL_KEY"));
//			hm.put("BALEP", (String)hm.get("BALEP"));
//			hm.put("NTEP", (String)hm.get("NTEP"));
//			hm.put("IDLSAM_CENTER", (String)hm.get("IDLSAM_CENTER"));
//			hm.put("IDLSAM", (String)hm.get("IDLSAM"));
//			hm.put("NTLSAM", (String)hm.get("NTLSAM"));
//			hm.put("MLDA", (String)hm.get("MLDA"));
//			hm.put("SIND1", (String)hm.get("SIND1"));
//			hm.put("REP", (String)hm.get("REP"));
//			hm.put("CCARD_NO", (String)hm.get("CCARD_NO"));
//			hm.put("CCARD_AUTH_NO", (String)hm.get("CCARD_AUTH_NO"));
//			hm.put("CCARD_TP", (String)hm.get("CCARD_TP"));
//			hm.put("ORG_DEAL_UNIQ_NO", (String)hm.get("ORG_DEAL_UNIQ_NO"));
			hm.put("FILLER", " ");
			
			sendMsg = makeSendDataHanPayHeader(MID_OLCHRGREQ) + makeSendDataHanPayCHRGCHRGCNCLInq(hm);
			
			df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "][" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("HanPay server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<hanpay] RECV[" + recvBuf.getBytes().length + "][" + recvBuf + "]");
			
			hmRecv = protocol.getParseHanPayCHRGCHRGCNCLRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			hmRecv.put("RESP_MSG", ErrorCD.getErrorMsg(0, (String)hmRecv.get("RESP_CD")));
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataHanPayCHRGCHRGCNCLRsp(hmRecv);
		}
		
		return dataMsg;
	}
	
	public String getHanPayTMNLOPENInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		ETCTransCardIrtProtocol protocol = new ETCTransCardIrtProtocol();
		ETCTransCardIrtDAO dao = new ETCTransCardIrtDAO();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 한페이로 보낼 송신 전문
		String recvBuf = "";	// 한페이에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		List<Object> list = null;
		Map<String, String> map = null;
		String strBizCoNo = "";
		String strPostCD = "";
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.HANPAY_RT_FILTER)));
			
//			hm.put("DEAL_TYPE_CD", (String)hm.get("DEAL_TYPE_CD"));						//거래종류코드
//			hm.put("JOB_TP", (String)hm.get("JOB_TP"));									//업무구분
//			hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID"));						//단말기번호
//			hm.put("SAM_ID", (String)hm.get("SAM_ID"));									//SAM ID
//			hm.put("BEFORE_SAM_ID", (String)hm.get("BEFORE_SAM_ID"));					//교체 전 SAM ID
//			hm.put("FCSTR_NM", (String)hm.get("FCSTR_NM"));								//가맹점명
//			hm.put("FCSTR_OWNER_NM", (String)hm.get("FCSTR_OWNER_NM"));					//가맹점 점주 성명
			hm.put("TEL_NO", WITHME_HELPDESK_TEL);										//전화번호
			
			list = dao.getBizLocMst((String)hmComm.get("COM_CD"), (String)hmComm.get("STORE_CD"));
			if( list.size() > 0 ) {
				map = (Map<String, String>)list.get(0);
				strPostCD = map.get("ZIP_CD");
			}
			
			hm.put("POST_CD", strPostCD);												//우편번호
//			hm.put("FCSTR_ADDR", (String)hm.get("FCSTR_ADDR"));							//가맹점 주소
			
			list = null;
			map = null;
			list = dao.getHQBizCoNo((String)hmComm.get("COM_CD"));
			if( list.size() > 0 ) {
				map = (Map<String, String>)list.get(0);
				strBizCoNo = map.get("BIZCO_NO");						
			}
			
			hm.put("HQ_CORP_REG_NO", strBizCoNo);										//유통제휴사사업자번호
//			hm.put("FCSTR_CORP_REG_NO", (String)hm.get("FCSTR_CORP_REG_NO"));			//가맹점사업자번호
//			hm.put("BEF_FCSTR_CORP_REG_NO", (String)hm.get("BEF_FCSTR_CORP_REG_NO"));	//양수도 전 가맹점사업자번호
			hm.put("FILLER", " ");
			
			sendMsg = makeSendDataHanPayHeader(MID_TMNLOPEN) + makeSendDataHanPayTMNLOPENInq(hm);
			
			df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "][" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>hanpay] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("HanPay server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<hanpay] RECV[" + recvBuf.getBytes().length + "][" + recvBuf + "]");
			
			hmRecv = protocol.getParseHanPayTMNLOPENRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			hmRecv.put("RESP_MSG", ErrorCD.getErrorMsg(1, (String)hmRecv.get("RESP_CD")));
			
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataHanPayTMNLOPENRsp(hmRecv);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataHanPayCARDBLCHKInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {15,14,16,15};
		String strHeaders[] = {
			"FCSTR_NO",
			"REQ_YMDHMS",
			"CCARD_NO",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataHanPayCPNPINCHKInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {15,10,20,14,11};
		String strHeaders[] = { "FCSTR_NO",
								"TERMINAL_ID",
								"COUPON_PIN",
								"REQ_YMDHMS",
								"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataHanPayCHRGCHRGCNCLRSLTInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {18,15,2,2,16
					  ,8,8,16,8,16
					  ,8,16,2,45};
		String strHeaders[] = { "DEAL_UNIQ_NO",
								"FCSTR_NO",
								"TRT",
								"IDCENTER",
								"IDEP",
								"BALEP",
								"NTEP",
								"IDLSAM",
								"NTLSAM",
								"RHSM",
								"SIND3",
								"REP",
								"DEAL_STS_TP",
								"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			df.CommLogger("★ make send HanPayCHRGCHRGCNCLRSLTInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataHanPayCHRGCHRGCNCLInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {18,15,6,14,8
					  ,4,10,2,2,2
					  ,20,6,2,2,16
					  ,2,2,8,8,2
					  ,16,8,8,8,16
					  ,16,8,2,20,49};
		String strHeaders[] = { "DEAL_UNIQ_NO",
								"FCSTR_NO",
								"ISSU_CORP_CD",
								"DEAL_YMDHMS",
								"ADJT_YMD",
								
								"CARD_TP",
								"TERMINAL_ID",
								"PROC_CD",
								"CARD_CORP_TP",
								"PAYMENT_TP",
								
								"PAYMENT_TP_PIN_CD",
								"COUPON_ISSU_CORP_CD",
								"TRT",
								"IDCENTER",
								"IDEP",
								
								"ALGEP",
								"VKDL_KEY",
								"BALEP",
								"NTEP",
								"IDLSAM_CENTER",
								
								"IDLSAM",
								"NTLSAM",
								"MLDA",
								"SIND1",
								"REP",
								
								"CCARD_NO",
								"CCARD_AUTH_NO",
								"CCARD_TP",
								"ORG_DEAL_UNIQ_NO",
								"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			df.CommLogger("★ make send HanPayCHRGCHRGCNCLInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataHanPayTMNLOPENInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,1,10,16,16
					  ,40,40,20,6,150
					  ,10,10,10,20};
		String strHeaders[] = { "DEAL_TYPE_CD" 
							  , "JOB_TP"
							  , "TERMINAL_ID"
							  , "SAM_ID"
							  , "BEFORE_SAM_ID"
							  
							  , "FCSTR_NM"
							  , "FCSTR_OWNER_NM"
							  , "TEL_NO"
							  , "POST_CD"
							  , "FCSTR_ADDR"
							  
							  , "HQ_CORP_REG_NO"
							  , "FCSTR_CORP_REG_NO"
							  , "BEF_FCSTR_CORP_REG_NO"
							  , "FILLER"
							  };
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataHanPayCPNPINCHKRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,100,15,10
					  ,20,2,6,10,8
					  ,8,4};
		String strHeaders[] = {
			"INQ_TYPE",
			"RESP_CD",
			"RESP_MSG",
			"FCSTR_NO",
			"TERMINAL_ID",
			
			"COUPON_PIN",
			"PIN_USEABLE",
			"COUP_ISSU_CORP_CD",
			"COUPON_AMT",
			"VAL_START_DT",
			
			"VAL_END_DT",
			"ERR_CD"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			df.CommLogger("★ make send HanPayCARDBLCHKRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataHanPayCARDBLCHKRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,15,14,16,2};
		String strHeaders[] = {
			"INQ_TYPE",
			"FCSTR_NO",
			"REQ_YMDHMS",
			"CCARD_NO",
			"USE_YN"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send HanPayCARDBLCHKRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataHanPayCHRGCHRGCNCLRSLTRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,100,18,16
					  ,8};
		String strHeaders[] = {
			"INQ_TYPE",
			"RESP_CD",
			"RESP_MSG",
			"DEAL_UNIQ_NO",
			"IDEP",
			
			"BALEP"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeTMNLINSTALLRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataHanPayCHRGCHRGCNCLRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,100,18,16
					  ,8,8,2};
		String strHeaders[] = {
			"INQ_TYPE",
			"RESP_CD",
			"RESP_MSG",
			"DEAL_UNIQ_NO",
			"RHSM",
			
			"NTLSAM",
			"SIND2",
			"CHRG_RESP_CD"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeTMNLINSTALLRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataHanPayTMNLOPENRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,100,1,1
					  ,10,16,16,40,40
					  ,20,6,150,10,10
					  ,10,15};
		String strHeaders[] = {
			"INQ_TYPE",
			"RESP_CD",
			"RESP_MSG",
			"DEAL_TYPE_CD",
			"JOB_TP",
			
			"TERMINAL_ID",
			"SAM_ID",
			"BEFORE_SAM_ID",
			"FCSTR_NM",
			"FCSTR_OWNER_NM",
			
			"TEL_NO",
			"POST_CD",
			"FCSTR_ADDR",
			"HQ_CORP_REG_NO",
			"FCSTR_CORP_REG_NO",
			
			"BEF_FCSTR_CORP_REG_NO",
			"FCSTR_NO"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send CashBeeTMNLINSTALLRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// 레일플러스 충전/충전직전거래취소/반품충전 요청/응답
	public String getRailPlusCHRGCHRGCNCLInq(HashMap<String, String> hm) throws Exception {
		ETCTransCardIrtProtocol protocol = new ETCTransCardIrtProtocol();
		ETCTransCardIrtDAO dao = new ETCTransCardIrtDAO();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
//		ActionSocket actSock2 = null;
		
		String sendMsg = "";	// 레일플러스로 보낼 송신 전문
		String recvBuf = "";	// 레일플러스에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.RAILPLUS_RT_FILTER)));
			
			String RAILPLUS_FCSTR_ID = ""; //레일플러스 가맹점ID
			RAILPLUS_FCSTR_ID = PropertyUtil.findProperty("service-property", "RAILPLUS_FCSTR_ID");
						
//			hm.put("TASK_TP", (String)hm.get("TASK_TP"));
			hm.put("RECORD_LEN", " ");        // 레코드 길이
			hm.put("MEMBER_USE_FIELD", " ");  // 제휴사 사용 영역
//			hm.put("TRANSACTION_ID", (String)hm.get("TRANSACTION_ID"));
//			hm.put("CARD_NO", (String)hm.get("CARD_NO"));
//			hm.put("CARD_OWNER_TP", (String)hm.get("CARD_OWNER_TP"));
//			hm.put("OCCU_YMDHMS", (String)hm.get("OCCU_YMDHMS"));
			
//			hm.put("KEYSET_VER", (String)hm.get("KEYSET_VER"));
//			hm.put("ALGO_ID", (String)hm.get("ALGO_ID"));
//			hm.put("CARD_DEAL_SEQ_NO", (String)hm.get("CARD_DEAL_SEQ_NO"));
//			hm.put("PPCARD_REM_AMT", (String)hm.get("PPCARD_REM_AMT"));
//			hm.put("PPCARD_REQ_AMT", (String)hm.get("PPCARD_REQ_AMT"));
			
//			hm.put("RAND_VAL", (String)hm.get("RAND_VAL"));
//			hm.put("SIGN1_VAL", (String)hm.get("SIGN1_VAL"));
//			hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID"));
//			hm.put("FCSTR_DIS_CD", (String)hm.get("FCSTR_DIS_CD"));
//			hm.put("BEFDEAL_SAM_ID", (String)hm.get("BEFDEAL_SAM_ID"));
			
//			hm.put("BEFDEAL_CARD_TRAN_SEQ_NO", (String)hm.get("BEFDEAL_CARD_TRAN_SEQ_NO"));
//			hm.put("BEFDEAL_CHRG_AMT", (String)hm.get("BEFDEAL_CHRG_AMT"));
//			hm.put("ORG_CARD_NO", (String)hm.get("ORG_CARD_NO"));
//			hm.put("ORG_DEAL_YMDHMS", (String)hm.get("ORG_DEAL_YMDHMS"));
//			hm.put("ORG_CARD_DEAL_SEQ_NO", (String)hm.get("ORG_CARD_DEAL_SEQ_NO"));
			
//			hm.put("ORG_TERMINAL_ID", (String)hm.get("ORG_TERMINAL_ID"));
//			hm.put("PAY_TP", (String)hm.get("PAY_TP"));
//			hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));
			hm.put("REP_FCSTR_ID", RAILPLUS_FCSTR_ID);  // 레일플러스 가맹점ID
//			hm.put("DEAL_BRANCH_NO", (String)hm.get("DEAL_BRANCH_NO"));
//			hm.put("DEAL_BRANCH_NM", (String)hm.get("DEAL_BRANCH_NM"));
			hm.put("FILLER", " ");
			
			// C1:충전요청, H1:충전 직전거래 취소요청, R1:반품충전요청			
			if( ((String)hm.get("TASK_TP")).equals("C1")
					|| ((String)hm.get("TASK_TP")).equals("H1") ) {
				sendMsg = makeSendDataRailPlusCHRGInq(hm);
			} else if( ((String)hm.get("TASK_TP")).equals("R1") ){
				sendMsg = makeSendDataRailPlusRtnCHRGInq(hm);
			} else {
				throw new Exception("invalid TASK_TP value");
			}
			
			// 전송할 메시지를  byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문 길이 0x018C(396) 설정
			sendBytes[2] = (byte)0x01;
			sendBytes[3] = (byte)0x8c;
			
			df.CommLogger("[sms>railplus] SEND[" + sendBytes.length + "][" + (new String(sendBytes)) + "]");
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>railplus] SEND[" + sendBytes.length + "] OK");
			}else {
				df.CommLogger("[sms>railplus] SEND[" + sendBytes.length + "] ERROR");
			}
			
			// 충전/직전거래취소/반품충전 응답
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<railplus] RECV[" + recvBuf.getBytes().length + "][" + recvBuf + "]");
			
			// 응답에 대한 ACK전문은 소켓을 끊고 다시 새로운 소켓으로 전송 함(여찬일K, 2015/09/30)
			// 응답에 대한 ACK전문 전송 시 Delay Time 0.5 sec 요청(여찬일K, 2015/09/30)
//			actSock.close();
//			actSock = null;
			Thread.sleep(500);
			
//			actSock2 = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.RAILPLUS_RT_FILTER)));
			
			hmRecv = protocol.getParseRailPlusCHRGCHRGCNCLRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			hmRecv.put("RESP_MSG", ErrorCD.getErrorMsg(0, (String)hmRecv.get("RESP_CD")));
			
			// 충전/충전직전거래취소/반품충전 응답수신 ack
			// 수신 확인 전문 전송(정상이든 오류발생이든 수신 확인 전문 전송)
			HashMap<String, String> hmSend = new HashMap<String, String>();
			hmSend = hmRecv;
			if( ((String)hm.get("TASK_TP")).equals("C1") ) {			// 충전요청
				hmSend.put("TASK_TP", "C3");
			}else if( ((String)hm.get("TASK_TP")).equals("H1") ) {		// 충전직전거래취소요청
				hmSend.put("TASK_TP", "H3");
			}else if( ((String)hm.get("TASK_TP")).equals("R1") ) {		// 반품충전요청
				hmSend.put("TASK_TP", "R3");
			}
			hmSend.put("RECORD_LEN", "  ");
			sendMsg = "";
			sendMsg = makeSendDataRailPlusCHRGCHRGCNCLCheck(hmSend);
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes2[] = sendMsg.getBytes();
			
			// 전문 길이 0x018C(396) 설정
			sendBytes2[2] = (byte)0x01;
			sendBytes2[3] = (byte)0x8c;
			
			df.CommLogger("[sms>railplus] SEND[" + sendBytes2.length + "][" + (new String(sendBytes2)) + "]");
			
			if( actSock.send(sendBytes2, sendBytes2.length) ) {
				df.CommLogger("[sms>railplus] SEND[" + sendBytes2.length + "] OK");
			}else {
				df.CommLogger("[sms>railplus] SEND[" + sendBytes2.length + "] ERROR");
			}
			
			if( ((String)hm.get("TASK_TP")).equals("C1") ) {
				hmRecv.put("TASK_TP", "C2");
			}else if( ((String)hm.get("TASK_TP")).equals("H1") ) {
				hmRecv.put("TASK_TP", "H2");
			}else if( ((String)hm.get("TASK_TP")).equals("R1") ) {
				hmRecv.put("TASK_TP", "R2");
			}		
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			actSock.close();
//			actSock2.close();
			dataMsg = ret + makeSendDataRailPlusCHRGCHRGCNCLRsp(hmRecv);
		}
		
		return dataMsg;
	}
	// 레일플러스 충전/충전직전거래취소/반품충전 결과
	public String getRailPlusCHRGCHRGCNCLRSLTInq(HashMap<String, String> hm) throws Exception {
		String sendMsg = "";	// 레일플러스로 보낼 송신 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.RAILPLUS_RT_FILTER)));
					
			String RAILPLUS_FCSTR_ID = ""; //레일플러스 가맹점ID
			RAILPLUS_FCSTR_ID = PropertyUtil.findProperty("service-property", "RAILPLUS_FCSTR_ID");
//			hm.put("TASK_TP", (String)hm.get("TASK_TP"));
			hm.put("RECORD_LEN", " ");        // 레코드 길이
			hm.put("MEMBER_USE_FIELD", " ");  // 제휴사 사용 영역
//			hm.put("TRANSACTION_ID", (String)hm.get("TRANSACTION_ID"));
//			hm.put("CARD_NO", (String)hm.get("CARD_NO"));
//			hm.put("SAM_ID", (String)hm.get("SAM_ID"));
//			hm.put("SAM_DEAL_SEQ_NO", (String)hm.get("SAM_DEAL_SEQ_NO"));
			
//			hm.put("CARD_OWNER_TP", (String)hm.get("CARD_OWNER_TP"));
//			hm.put("OCCU_YMDHMS", (String)hm.get("OCCU_YMDHMS"));
//			hm.put("KEYSET_VER", (String)hm.get("KEYSET_VER"));
//			hm.put("ALGO_ID", (String)hm.get("ALGO_ID"));
//			hm.put("CARD_TRAN_SEQ_NO", (String)hm.get("CARD_TRAN_SEQ_NO"));
			
//			hm.put("CHRG_BEF_RAMT", (String)hm.get("CHRG_BEF_RAMT"));
//			hm.put("CHRG_REQ_RAMT", (String)hm.get("CHRG_REQ_RAMT"));
//			hm.put("CHRG_AFT_RAMT", (String)hm.get("CHRG_AFT_RAMT"));
//			hm.put("FEE", (String)hm.get("FEE"));
//			hm.put("CARD_DEPOSIT", (String)hm.get("CARD_DEPOSIT"));
			
//			hm.put("PENALTY_AMT", (String)hm.get("PENALTY_AMT"));
//			hm.put("RAND_VAL", (String)hm.get("RAND_VAL"));
//			hm.put("SIGN3_VAL", (String)hm.get("SIGN3_VAL"));
//			hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID"));
//			hm.put("FCSTR_DIS_CD", (String)hm.get("FCSTR_DIS_CD"));
			
//			hm.put("DEAL_YMDHMS", (String)hm.get("DEAL_YMDHMS"));
//			hm.put("CARD_STS_CD", (String)hm.get("CARD_STS_CD"));
//			hm.put("TERMINAL_STS_CD", (String)hm.get("TERMINAL_STS_CD"));
//			hm.put("RESP_CD", (String)hm.get("RESP_CD"));
//			hm.put("ERR_MSG", (String)hm.get("ERR_MSG"));
			
//			hm.put("PREDEAL_ID_HOST", (String)hm.get("PREDEAL_ID_HOST"));
//			hm.put("DEAL_BRANCH_NO", (String)hm.get("DEAL_BRANCH_NO"));
			hm.put("REP_FCSTR_ID", RAILPLUS_FCSTR_ID);  // 레일플러스 가맹점ID
//			hm.put("CHRG_FEE_RATE", (String)hm.get("CHRG_FEE_RATE"));
			hm.put("FILLER", " ");

			sendMsg = makeSendDataRailPlusCHRGRSLTInq(hm);
			df.CommLogger("[sms>railplus] SEND[" + sendMsg.getBytes().length + "][" + sendMsg + "]");
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문 길이 0x018C(396) 설정
			sendBytes[2] = (byte)0x01;
			sendBytes[3] = (byte)0x8c;
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>railplus] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>railplus] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("RailPlus server is no response");
			}
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret;
		}
		
		return dataMsg;
	}
	// 레일플러스 카드 PL 상태 요청/응답
	public String getRailPlusCARDPLCHKInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		ETCTransCardIrtProtocol protocol = new ETCTransCardIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 레일플러스로 보낼 송신 전문
		String recvBuf = "";	// 레일플러스에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.RAILPLUS_RT_FILTER)));
			
			String RAILPLUS_FCSTR_ID = ""; //레일플러스 가맹점ID
			RAILPLUS_FCSTR_ID = PropertyUtil.findProperty("service-property", "RAILPLUS_FCSTR_ID");
			
//			hm.put("TASK_TP", (String)hm.get("TASK_TP"));
			hm.put("RECORD_LEN", " ");        								// 레코드 길이
			hm.put("MEMBER_USE_FIELD", " ");  								// 제휴사 사용 영역
//			hm.put("TRANSACTION_ID", (String)hm.get("TRANSACTION_ID"));
//			hm.put("CARD_NO", (String)hm.get("CARD_NO"));
//			hm.put("ALIAS_NO", (String)hm.get("ALIAS_NO"));
			hm.put("REP_FCSTR_ID", RAILPLUS_FCSTR_ID);  					// 레일플러스 가맹점ID
//			hm.put("REQ_YMDHMS", (String)hm.get("REQ_YMDHMS"));
			hm.put("FILLER", " ");
			
			sendMsg = makeSendDataRailPlusCARDPLCHKInq(hm);
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes2[] = sendMsg.getBytes();
			
			// 전문 길이 0x018C(396) 설정
			sendBytes2[2] = (byte)0x01;
			sendBytes2[3] = (byte)0x8c;
			
			df.CommLogger("[sms>railplus] SEND[" + sendBytes2.length + "][" + (new String(sendBytes2)) + "]");
			
			if( actSock.send(sendBytes2, sendBytes2.length) ) {
				df.CommLogger("[sms>railplus] SEND[" + sendBytes2.length + "] OK");
			}else {
				df.CommLogger("[sms>railplus] SEND[" + sendBytes2.length + "] ERROR");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<railplus] RECV[" + recvBuf.getBytes().length + "][" + recvBuf + "]");
			
			hmRecv = protocol.getParseRailPlusCARDBLCHKRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataRailPlusCARDBLCHKRsp(hmRecv);
		}
		
		return dataMsg;
	}
	// 레일플러스 C1:충전요청, H1:충전 직전거래 취소요청
	private String makeSendDataRailPlusCHRGInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,50,20,16
					  ,2,14,2,2,10
					  ,10,10,16,8,10
					  ,7,16,10,10,2
					  ,16,8,10,40,107};
		
		String strHeaders[] = { "TASK_TP",                  // 업무구분
								"RECORD_LEN" ,				// 레코드 길이
				                "MEMBER_USE_FIELD" ,		// 제휴사 사용 영역
								"TRANSACTION_ID",           // TRANSACTION ID
								"CARD_NO",                  // 선불카드 ID
								
								"CARD_OWNER_TP",            // 카드소지자 구분
								"OCCU_YMDHMS",              // 충전일시								
								"KEYSET_VER",               // 키셋버전
								"ALGO_ID",                  // 알고리즘ID
								"CARD_DEAL_SEQ_NO",         // 카드거래 일련번호
								
								"PPCARD_REM_AMT",           // 선불카드 잔액
								"PPCARD_REQ_AMT",           // 선불카드 충전요청금액								
								"RAND_VAL",                 // 난수
								"SIGN1_VAL",                // SIGN1
								"TERMINAL_ID",              // 단말기ID
								
								"FCSTR_DIS_CD",             // 가맹점구분코드
								"BEFDEAL_SAM_ID",           // 직전거래 SAM ID
								"BEFDEAL_CARD_TRAN_SEQ_NO", // 직전거래 카드 거래 일련번호 
								"BEFDEAL_CHRG_AMT",         // 직전거래 충전금액								
								"PAY_TP",                   // 결제구분
								
								"MEMBER_ID",                // 멤버쉽번호
								"REP_FCSTR_ID",             // 가맹점ID
								"DEAL_BRANCH_NO",           // 거래지점
								"DEAL_BRANCH_NM",           // 거래지점명
								"FILLER"                    // FILLER
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			df.CommLogger("★ make send RailPlusCHRGInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// 레일플러스 R1:반품충전(환불)요청
	private String makeSendDataRailPlusRtnCHRGInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,50,20,16
					  ,2,14,2,2,10
					  ,10,10,16,8,10
					  ,7,16,10,10,16
					  ,14,10,10,2,16
					  ,8,10,40,57};
		
		String strHeaders[] = { "TASK_TP",                  // 업무구분
								"RECORD_LEN" ,				// 레코드 길이
				                "MEMBER_USE_FIELD" ,		// 제휴사 사용 영역
								"TRANSACTION_ID",           // TRANSACTION ID
								"CARD_NO",                  // 선불카드 ID
								
								"CARD_OWNER_TP",            // 카드소지자 구분
								"OCCU_YMDHMS",              // 충전일시								
								"KEYSET_VER",               // 키셋버전
								"ALGO_ID",                  // 알고리즘ID
								"CARD_DEAL_SEQ_NO",         // 카드거래 일련번호
								
								"PPCARD_REM_AMT",           // 선불카드 잔액
								"PPCARD_REQ_AMT",           // 선불카드 충전요청금액								
								"RAND_VAL",                 // 난수
								"SIGN1_VAL",                // SIGN1
								"TERMINAL_ID",              // 단말기ID
								
								"FCSTR_DIS_CD",             // 가맹점구분코드
								"BEFDEAL_SAM_ID",           // 직전거래 SAM ID
								"BEFDEAL_CARD_TRAN_SEQ_NO", // 직전거래 카드 거래 일련번호 
								"BEFDEAL_CHRG_AMT",         // 직전거래 충전금액	
								"ORG_CARD_NO",              // 원거래 카드번호
								
								"ORG_DEAL_YMDHMS",          // 원거래 카드거래 일시
								"ORG_CARD_DEAL_SEQ_NO",     // 원거래 카드거래 일련번호
								"ORG_TERMINAL_ID",          // 원거래 단말기 ID
								"PAY_TP",                   // 결제구분
								"MEMBER_ID",                // 멤버쉽번호
								
								"REP_FCSTR_ID",             // 가맹점ID
								"DEAL_BRANCH_NO",           // 거래지점
								"DEAL_BRANCH_NM",           // 거래지점명
								"FILLER"                    // FILLER
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			df.CommLogger("★ make send RailPlusRtnCHRGInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// 레일플러스 C4:충전결과, H4:충전 직전거래 취소결과, R4:반품충전(환불)결과
	private String makeSendDataRailPlusCHRGRSLTInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,50,20,16
					  ,16,10,2,14,2
					  ,2,10,10,10,10
					  ,10,10,10,16,8					  
					  ,10,7,14,4,4
					  ,2,20,8,4,97};
		
		String strHeaders[] = { "TASK_TP",                  // 업무구분
								"RECORD_LEN" ,				// 레코드 길이
				                "MEMBER_USE_FIELD" ,		// 제휴사 사용 영역
								"TRANSACTION_ID",           // TRANSACTION ID
								"CARD_NO",                  // 선불카드 ID
								
								"SAM_ID",                   // SAM ID								
								"SAM_DEAL_SEQ_NO",          // SAM 거래 일련번호								
								"CARD_OWNER_TP",            // 카드소지자 구분
								"OCCU_YMDHMS",              // 충전일시/직전거래 충전취소 일시/반환일시								
								"KEYSET_VER",               // 키셋버전
								
								"ALGO_ID",                  // 알고리즘 ID
							    "CARD_TRAN_SEQ_NO",         // 카드거래 일련번호
							    "CHRG_BEF_RAMT",            // 선불카드잔액/직전거래 충전취소 잔액/반환전잔액
							    "CHRG_REQ_RAMT",            // 선불카드충전요청금액/직전거래 충전취소요청금액/반환요청금액
							    "CHRG_AFT_RAMT",            // 선불카드 충전후 잔액
							  
							    "FEE",                      // 충전수수료/직전거래 충전취소 수수료/반환수수료
							    "CARD_DEPOSIT",             // 카드보증금
							    "PENALTY_AMT",              // PENALTY 금액
							    "RAND_VAL",                 // 난수							  
							    "SIGN3_VAL",                // SIGN3
							  
							    "TERMINAL_ID",              // 단말기ID
							    "FCSTR_DIS_CD",	            // 가맹점구분코드
							    "DEAL_YMDHMS",              // 충전거래 일시/직전거래 충전취소 거래일시/반환거래 일시
							    "CARD_STS_CD",              // 카드상태코드
							    "TERMINAL_STS_CD",          // 단말기상태코드
							   
							    "RESP_CD",                  // 응답코드
							    "ERR_MSG",                  // 오류메시지
							    "REP_FCSTR_ID",             // 가맹점ID
							    "CHRG_FEE_RATE",            // 충전수수료율/반환수수료율
							    "FILLER"                    // FILLER
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			df.CommLogger("★ make send RailPlusCHRGRSLTInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// 레일플러스 카드 PL 상태 요청
	private String makeSendDataRailPlusCARDPLCHKInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,50,20,8
					  ,14,16,10,278};
		
		String strHeaders[] = { "TASK_TP",                  // 업무구분
								"RECORD_LEN" ,				// 레코드 길이
				                "MEMBER_USE_FIELD" ,		// 제휴사 사용 영역
				                "TRANSACTION_ID",			// TRANSACTION ID
				                "REP_FCSTR_ID",             // 가맹점ID
				                
				                "REQ_YMDHMS",               // 요청일시
								"CARD_NO",                  // 선불카드 ID
								"ALIAS_NO",                 // Alias 번호
								"FILLER"                    // FILLER
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			df.CommLogger("★ make send RailPlusCARDPLCHKInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// 레일플러스 충전/충전직전거래취소/반품충전 응답
	private String makeSendDataRailPlusCHRGCHRGCNCLRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,20,16,16
					  ,10,2,14,2,2
					  ,10,10,10,10,10
					  ,10,10,16,8,10
					  ,7,14,4,4,2
					  ,20,10,4};
		
		String strHeaders[] = { "INQ_TYPE",                 // INQ종별
								"TASK_TP",                  // 업무구분
								"TRANSACTION_ID",           // TRANSACTION ID
								"CARD_NO",                  // 선불카드 ID
								"SAM_ID",                   // SAM ID
								
								"SAM_DEAL_SEQ_NO",          // SAM 거래 일련번호
								"CARD_OWNER_TP",		    // 카드소지자 구분
								"OCCU_YMDHMS",              // 충전일시/직전거래 충전취소 일시/반환일시
								"KEYSET_VER",               // 키셋버전
								"ALGO_ID",                  // 알고리즘 ID
								
								"CARD_TRAN_SEQ_NO",         // 카드거래 일련번호
								"CHRG_BEF_RAMT",            // 선불카드잔액/직전거래 충전취소 잔액/반환전잔액
							    "CHRG_REQ_RAMT",            // 선불카드충전요청금액/직전거래 충전취소요청금액/반환요청금액
							    "CHRG_AFT_RAMT",            // 선불카드 충전후 잔액
								"FEE",                      // 충전수수료/직전거래 충전취소 수수료/반환수수료
								
								"CARD_DEPOSIT",             // 카드보증금
							    "PENALTY_AMT",              // PENALTY 금액
							    "RAND_VAL",                 // 난수
								"SIGN2_VAL",                // SIGN2
								"TERMINAL_ID",              // 단말기ID
								
								"FCSTR_DIS_CD",	            // 가맹점구분코드
							    "DEAL_YMDHMS",              // 충전거래 일시/직전거래 충전취소 거래일시/반환거래 일시
							    "CARD_STS_CD",              // 카드상태코드
							    "TERMINAL_STS_CD",          // 단말기상태코드
								"RESP_CD",                  // 응답코드
								
								"ERR_MSG",                  // 오류메시지
								"FRANCHISE_ID",           	// 거래지점번호
								"CHRG_FEE_RATE"             // 충전수수료율/반환수수료율
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send RailPlusCHRGCHRGCNCLRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// 레일플러스 충전/충전직전거래취소/반품충전 응답 수신 ack
	private String makeSendDataRailPlusCHRGCHRGCNCLCheck(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,50,20,16
					  ,16,10,2,14,2
					  ,2,10,10,10,10
					  ,10,10,10,16,8					  
					  ,10,7,14,4,4
					  ,2,20,8,4,97};
		
		String strHeaders[] = { "TASK_TP",                  // 업무구분
				                "RECORD_LEN", 				// 레코드 길이
				                "MEMBER_USE_FIELD",  		// 제휴사 사용 영역
				                "TRANSACTION_ID",           // TRANSACTION ID
				                "CARD_NO",                  // 선불카드 ID
				              
				                "SAM_ID",                   // SAM ID				              
				  			    "SAM_DEAL_SEQ_NO",          // SAM 거래 일련번호
				                "CARD_OWNER_TP",		    // 카드소지자 구분		              
							    "OCCU_YMDHMS",              // 충전일시/직전거래 충전취소 일시/반환일시
							    "KEYSET_VER",               // 키셋버전
							  
							    "ALGO_ID",                  // 알고리즘 ID
							    "CARD_TRAN_SEQ_NO",         // 카드거래 일련번호
							    "CHRG_BEF_RAMT",            // 선불카드잔액/직전거래 충전취소 잔액/반환전잔액
							    "CHRG_REQ_RAMT",            // 선불카드충전요청금액/직전거래 충전취소요청금액/반환요청금액
							    "CHRG_AFT_RAMT",            // 선불카드 충전후 잔액
							  
							    "FEE",                      // 충전수수료/직전거래 충전취소 수수료/반환수수료
							    "CARD_DEPOSIT",             // 카드보증금
							    "PENALTY_AMT",              // PENALTY 금액
							    "RAND_VAL",                 // 난수							  
							    "SIGN2_VAL",                // SIGN3
							  
							    "TERMINAL_ID",              // 단말기ID
							    "FCSTR_DIS_CD",	            // 가맹점구분코드
							    "DEAL_YMDHMS",              // 충전거래 일시/직전거래 충전취소 거래일시/반환거래 일시
							    "CARD_STS_CD",              // 카드상태코드
							    "TERMINAL_STS_CD",          // 단말기상태코드
							  
							    "RESP_CD",                  // 응답코드
							    "ERR_MSG",                  // 오류메시지
							    "FRANCHISE_ID",             // 가맹점ID
							    "CHRG_FEE_RATE",            // 충전수수료율/반환수수료율
							    "FILLER"                    // FILLER
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send RailPlusCHRGCHRGCNCLCheck : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// 레일플러스 카드 PL 상태 응답
	private String makeSendDataRailPlusCARDBLCHKRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,20,16,10
					  ,14,1,1};
		String strHeaders[] = { "INQ_TYPE",                 // INQ종별
								"TASK_TP",                  // 업무구분
								"TRANSACTION_ID",           // TRANSACTION ID
								"CARD_NO",                  // 선불카드 ID								
								"ALIAS_NO",                 // Alias 번호
								
								"REQ_YMDHMS",               // 요청일시
								"REGDEL_INFO",              // 등록/해제 정보
								"STUD_REQ_TP",              // 학생등록 구분
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send RailPlusCARDBLCHKRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
}
