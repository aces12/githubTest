package biz.cms_ETCTransCardIrt;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;


import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;

public class ETCTransCardIrtDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(ETCTransCardIrtDAO.class);
	
	public List<Object> getHQBizCoNo(String co_cd) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_WITHMEBIZCONUM"));
			sql.setString(++i, "A110010");
			sql.setString(++i, co_cd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return list;
	}
	
	public List<Object> getBizLocMst(String co_cd, String store_cd) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_HQBIZLOCMST"));
			sql.setString(++i, co_cd);
			sql.setString(++i, store_cd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return list;
	}
	
	public String getSTOTOTranExtnc(String co_cd, HashMap<String, String> hm) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		String ret = "00";
		String dataMsg = "";
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_STOTOTRANEXTNC"));
			sql.setString(++i, co_cd);
			sql.setString(++i, (String)hm.get("DATE_DDD").trim());
			sql.setString(++i, (String)hm.get("TIME_SSSSS").trim());
			sql.setString(++i, (String)hm.get("FCSTR_ID").trim());
			sql.setString(++i, (String)hm.get("PAY_TP"));
			
			list = executeQuery(sql);
			
			Map map = (Map<String, String>)list.get(0);
			
			hm.put("RES_CD", (Integer.parseInt((String)map.get("COUNT")) == 0 ? "00" : "01"));
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
			ret = "29";
		}finally {
			dataMsg = ret + makeSTOTOTranExtncSendData(hm);
		}
		
		return dataMsg;
	}
	
	private String makeSTOTOTranExtncSendData(HashMap<String, String> hmData) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,3,5,5,1
					  ,1,1,3,2};
		String strHeaders[] = {
				"INQ_TYPE",
				"DATE_DDD",
				"TIME_SSSSS",
				"FCSTR_ID",
				"PAY_TP",
				
				"ITEM_GRP_CD",
				"ITEM_CD",
				"GAME_NTH",
				"RES_CD"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hmData.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
}
