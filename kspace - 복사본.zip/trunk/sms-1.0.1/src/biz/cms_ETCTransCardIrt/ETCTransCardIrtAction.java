package biz.cms_ETCTransCardIrt;

import java.net.Socket;
import java.util.HashMap;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;

public class ETCTransCardIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(ETCTransCardIrtAction.class);
	
	private String hanpay_server_ip = "";
	private int hanpay_server_port = 0;
	private String railplus_server_ip = "";
	private int railplus_server_port = 0;
	
	@Override
	public void execute(ActionSocket actionSocket) throws Exception {
		// TODO Auto-generated method stub
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		ETCTransCardIrtDAO dao = new ETCTransCardIrtDAO();
		ETCTransCardIrtProtocol protocol = new ETCTransCardIrtProtocol();
		COMMLog df = new COMMLog();
		
		Socket extClntSock = null;
		ETCTransCardIrtConveyer conveyer = null;
		this.hanpay_server_ip = PropertyUtil.findProperty("communication-property", "HANPAY_COMM_IP");
		this.hanpay_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "HANPAY_COMM_PORT"));
		this.railplus_server_ip = PropertyUtil.findProperty("communication-property", "RAILPLUS_COMM_IP");
		this.railplus_server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "RAILPLUS_COMM_PORT"));
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress()
					.getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,
					"ETCTransCardIrt");
			
			df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지
			// 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}
			
			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			inq_type = protocol.getRcvETCTransCardIrtDATA(rcvDataBuf);
			
			switch( inq_type ) {
				// 스포츠토토 등록 확인
				case 27:
					df.execute("SPORTS TOTO TRAN CHECK");
					hmData = protocol.getParseSTOTOTRANCHKInq(rcvDataBuf);
					
					dataMsg = dao.getSTOTOTranExtnc((String)hmCommon.get("COM_CD"), hmData);
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 한페이 제휴 단말기 개통/변경
				case 66:
					df.execute("HanPay-Terminal OPEN/CHANGE");
					hmData = protocol.getParseHanPayTMNLOPENInq(rcvDataBuf);
					
					extClntSock = new Socket(hanpay_server_ip, hanpay_server_port);
					conveyer = new ETCTransCardIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getHanPayTMNLOPENInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 한페이 충전/충전취소
				case 67:
					df.execute("HanPay-Charge/ChargeCancel");
					hmData = protocol.getParseHanPayCHRGCHRGCNCLInq(rcvDataBuf);
					
					extClntSock = new Socket(hanpay_server_ip, hanpay_server_port);
					conveyer = new ETCTransCardIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getHanPayCHRGCHRGCNCLInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 한페이 충전/충전취소 결과
				case 68:
					df.execute("HanPay-Charge/ChargeCancel Result");
					hmData = protocol.getParseHanPayCHRGCHRGCNCLRSLTInq(rcvDataBuf);
					
					extClntSock = new Socket(hanpay_server_ip, hanpay_server_port);
					conveyer = new ETCTransCardIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getHanPayCHRGCHRGCNCLRSLTInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 한페이 쿠폰충전 PIN 유효성 확인
				case 69:
					df.execute("HanPay-Coupon Check");
					hmData = protocol.getParseHanPayCPNPINCHKInq(rcvDataBuf);
					
					extClntSock = new Socket(hanpay_server_ip, hanpay_server_port);
					conveyer = new ETCTransCardIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getHanPayCPNPINCHKInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
//					dataMsg = "6901정상                                                                                                40402015110620415000999039320002010410       00123456000005000019000101299912310000";
					break;
				// 한페이 카드 BL체크
				case 70:
					df.execute("HanPay-Card BL Check");
					hmData = protocol.getParseHanPayCARDBLCHKInq(rcvDataBuf);
					
					extClntSock = new Socket(hanpay_server_ip, hanpay_server_port);
					conveyer = new ETCTransCardIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getHanPayCARDBLCHKInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
//					dataMsg = rcvDataBuf + "00";
					break;
				// 레일플러스 충전/충전직전거래취소/반품충전 요청/응답
				case 71:
					df.execute("RailPlus-Charge/ChargeCancel");
					hmData = protocol.getParseRailPlusCHRGCHRGCNCLInq(rcvDataBuf);
					
					extClntSock = new Socket(railplus_server_ip, railplus_server_port);
					conveyer = new ETCTransCardIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getRailPlusCHRGCHRGCNCLInq(hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 레일플러스 충전/충전직전거래취소/반품충전 결과
				case 72:
					df.execute("RailPlus-Charge/ChargeCancel Result");
					hmData = protocol.getParseRailPlusCHRGCHRGCNCLRSLTInq(rcvDataBuf);
					
					extClntSock = new Socket(railplus_server_ip, railplus_server_port);
					conveyer = new ETCTransCardIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getRailPlusCHRGCHRGCNCLRSLTInq(hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					break;
				// 레일플러스 카드 PL 상태 요청/응답
				case 73:
					df.execute("RailPlus-Card PL Check");
					hmData = protocol.getParseRailPlusCARDPLCHKInq(rcvDataBuf);
					
					extClntSock = new Socket(railplus_server_ip, railplus_server_port);
					conveyer = new ETCTransCardIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getRailPlusCARDPLCHKInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
//					dataMsg = "73A21511030099900015934 209905000001255400000125542015110317005500";
//					ret = 0;
					break;
			}
		}catch(Exception e) {
			ret = 29;
			retValue = "[ERROR]2:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			if( extClntSock != null ) {
				extClntSock.close();
			}
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + totalMsg + "]");
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(totalMsg)) {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		}catch(Exception e) {
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("ETCTransCardIrt", retValue);
		}
	}
}
