package biz.cms_KISDTLDownloader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class KISDTLDownloaderInst extends Thread {
	private static Logger logger = Logger.getLogger(KISDTLDownloaderPollingAction.class);
	
	String path = "";
	String fileNm = "";	
	String folderNm = "";
//	String stdDate = "";
	
	public void setFileNm(String filenm){
		this.fileNm = filenm;
	}
	
	public void setFolderNm(String foldernm){
		this.folderNm = foldernm;
	}
	
	
	public KISDTLDownloaderInst(String path) {
		this.path = path;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
	public void deleteFile(String path, String fileNM) {
		File file = new File(path + File.separator + fileNM);
		if( file.exists() ) {
			logger.info("File Name : " + path + File.separator + fileNM);
			if( file.delete() ) {
				logger.info("File(" + path + File.separator + fileNM + ") removed !!!");
			}
		}
	}
	
	public void copyFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdirs();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(orgFile);
			fos = new FileOutputStream(destFile);
			
			int data = 0;
			while( (data = fis.read()) != -1 ) {
				fos.write(data);
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			try {
				fis.close();
				fis = null;
				fos.flush();
				fos.close();
				fos = null;
				System.gc();
			}catch(Exception e) {
				logger.info(e.getMessage());
			}
		}
		
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public void run() {
		logger.info("=fileNm ["+fileNm+ "] insert thread start==============================================================");
		int ret = 0;
		BufferedReader bin = null;
		StringTokenizer st = null;

		
	    String readedLine = new String("ASCII");

		try {			
			KISDTLDownloaderDAO dao = new KISDTLDownloaderDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			logger.info(">>>>>>> path = " + path);
			System.out.println(">>>>>>> path = " + path);
			Map<String, String> map = new HashMap<String, String>();
			
//			Calendar calendar = new GregorianCalendar(Locale.KOREA);
//			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//
//			calendar.setTime(new Date());			//calendar.add(Calendar.DATE,0);
//			String stdDate = sdf.format(calendar.getTime());
			
			//List<File> list = getDirFileList(path);	
//			for(int i = 0;i < list.size();i++ ) {
//				if( !(list.get(i)).isFile() ) {
//					continue;
//				}
				//bin = new BufferedReader(new FileReader(path + File.separator + targetFile));
			System.out.println("bin source : "+ path + File.separator + fileNm);
			bin = new BufferedReader(new FileReader(path + File.separator + fileNm));
			
			String van_cd = "";
			String file_dt = "";

			if (fileNm.substring(0,3).equals("KIS")){
				van_cd = "KIS";
			}else if (fileNm.substring(0,3).equals("NIC")){
				van_cd = "NICE";
			}else if (fileNm.substring(0,3).equals("KIC")){
				van_cd = "KICC";
			}
			
			logger.info("van_cd=>"+ van_cd);
			file_dt = fileNm.substring(fileNm.length()-8, fileNm.length());
			
			//logger.info("FILE_DT=>"+ fileNm.substring(fileNm.length()-8, fileNm.length()));
			String TLF_REP_TP = fileNm.substring(fileNm.length()-12, fileNm.length()-9);
			logger.info("TLF_REP_TP=>"+ TLF_REP_TP);

			int insCnt = 0;
			//neo0531 for test dont insert tlf data
			if (TLF_REP_TP.equals("TLF")){//거래내역 
				map.put("FILE_NM", fileNm);
				map.put("PROC_STAT", "01");
				dao.updLogStat(map);
				while((readedLine = bin.readLine() )!= null){
					//logger.info("[DEBUG] File Name : " + fileNm );
					//logger.info("readedLine = [" + readedLine +"]");

					String recId = readedLine.substring(0,1);
					if (recId.equals("H")){  
						//header 인경우 								  
						map = COMMBiz.getParseData(KISDTLData.nlensTLF_H, KISDTLData.strHeadersTLF_H, readedLine);
						map.put("VAN_CD",van_cd);
						map.put("FILE_DT", file_dt);
						map.put("FILE_NM",fileNm);
						ret = dao.insKISDailyDTL_TLF_H(map);							
					}else if(recId.equals("D")){		
						//data인경우 
						map = COMMBiz.getParseData(KISDTLData.nlensTLF_D, KISDTLData.strHeadersTLF_D, readedLine);
						map.put("VAN_CD",van_cd);
						map.put("FILE_DT", file_dt);
						map.put("FILE_NM",fileNm);
						ret = dao.insKISDailyDTL_TLF_D(map);
					}else if (recId.equals("T")){ 
						//trailer  인경우 						
						map = COMMBiz.getParseData(KISDTLData.nlensTLF_T, KISDTLData.strHeadersTLF_T, readedLine);
						map.put("VAN_CD",van_cd);
						map.put("FILE_DT", file_dt);
						map.put("FILE_NM",fileNm);
						ret = dao.insKISDailyDTL_TLF_T(map);
					}
					
					if( ret != 1 ) {
						logger.info("["+readedLine+"]"+"There is an Error on inserting data");
						System.out.println("["+readedLine+"]"+"There is an Error on inserting data");						
						
						map.put("ERR",(String)map.get("ERR_INFO"));
						map.put("FILE_NM",fileNm);
						dao.updLogError(map);
						
						
						bin.close();
						bin = null;
						return;
					}	
					insCnt++;
				}
				
				logger.info("TOTAL TLF INSERT COUNT [["+insCnt+"]]");
				map.put("FILE_NM",fileNm);
				int retP = dao.procCardTLFDatMap(map);
				if (retP ==0){//완료
					
					map.put("FILE_NM", fileNm);
					dao.updLogOK(map);
					
				}else {//오류
					map.put("ERR",Integer.toString(retP));
					map.put("FILE_NM",fileNm);
				dao.updLogError(map);
				}
				logger.info("=fileNm ["+fileNm+ "] insert thread END==============================================================");	

				
				
			}else if(TLF_REP_TP.equals("REP")){// 입반송내역
				map.put("FILE_NM", fileNm);
				map.put("PROC_STAT", "01");
				dao.updLogStat(map);
				String ht_seq = "";
				while((readedLine = bin.readLine() )!= null){
					String recId = readedLine.substring(0,2);
					if (recId.equals("51")){  
						//EDI START 인경우 								
						map = COMMBiz.getParseData(KISDTLData.nlensREP_S, KISDTLData.strHeadersREP_S, readedLine);
						map.put("VAN_CD",van_cd);
						map.put("FILE_DT", file_dt);
						map.put("FILE_NM",fileNm);
						ret = dao.insKISDailyDTL_REP_S(map);				
					}else if (recId.equals("52")){ 
						//header  인경우
						ht_seq = dao.selKISDAILYDTL_REP_HT_SEQ();
						//logger.info("ht_seq["+ht_seq+"]");
						map = COMMBiz.getParseData(KISDTLData.nlensREP_H, KISDTLData.strHeadersREP_H, readedLine);
						map.put("VAN_CD",van_cd);
						map.put("FILE_DT", file_dt);
						map.put("HT_SEQ", ht_seq );
						map.put("FILE_NM",fileNm);
						ret = dao.insKISDailyDTL_REP_H(map);
					}else if (recId.equals("60")||recId.equals("61")||recId.equals("62")||recId.equals("63")
							||recId.equals("64")||recId.equals("65")||recId.equals("66")||recId.equals("67")){ 
						//data  인경우 						
						map = COMMBiz.getParseData(KISDTLData.nlensREP_D, KISDTLData.strHeadersREP_D, readedLine);
						map.put("VAN_CD",van_cd);
						map.put("FILE_DT", file_dt);
						map.put("HT_SEQ", ht_seq );
						map.put("FILE_NM",fileNm);
						ret = dao.insKISDailyDTL_REP_D(map);
					}else if (recId.equals("53")){ 
						//total  인경우 						
						map = COMMBiz.getParseData(KISDTLData.nlensREP_T, KISDTLData.strHeadersREP_T, readedLine);
						map.put("VAN_CD",van_cd);
						map.put("FILE_DT", file_dt);
						map.put("HT_SEQ", ht_seq );
						map.put("FILE_NM",fileNm);
						ret = dao.insKISDailyDTL_REP_T(map);
					}else if (recId.equals("54")){ 
						//EDI END  인경우 						
						map = COMMBiz.getParseData(KISDTLData.nlensREP_E, KISDTLData.strHeadersREP_E, readedLine);
						map.put("VAN_CD",van_cd);
						map.put("FILE_DT", file_dt);
						map.put("FILE_NM",fileNm);
						ret = dao.insKISDailyDTL_REP_E(map);
					}
				
					if( ret != 1 ) {
						logger.info("["+readedLine+"]"+"There is an Error on inserting data");
						System.out.println("["+readedLine+"]"+"There is an Error on inserting data");
						
						map.put("ERR",(String)map.get("ERR_INFO"));
						map.put("FILE_NM",fileNm);
						dao.updLogError(map);
						
						bin.close();
						bin = null;
						return;
					}	
					insCnt++;
				}//end while
				logger.info("TOTAL INSERT COUNT [["+insCnt+"]]");
				map.put("FILE_NM",fileNm);
				// 입반송데이터 등록 후 매칭 처리
				int retP = dao.procCardREPDatMap(map);
				if (retP ==0){//완료					
					map.put("FILE_NM", fileNm);
					dao.updLogOK(map);
					logger.info("=fileNm ["+fileNm+ "] insert thread kakao start=======================");
					// 입반송데이터 등록 완료 후 카카오페이 데이터 이관 및 삭제 처리
					int retPKakao = dao.procKAKAOPAYTLFDatMap(map);
					if (retPKakao ==0){//완료					
						map.put("FILE_NM", fileNm);
						dao.updLogOK(map);
						
					}else {//오류
						map.put("ERR",Integer.toString(retPKakao));
						map.put("FILE_NM",fileNm);
						dao.updLogError(map);
					}
					logger.info("=fileNm ["+fileNm+ "] insert thread kakao end  =======================");
					
				}else {//오류
					map.put("ERR",Integer.toString(retP));
					map.put("FILE_NM",fileNm);
					dao.updLogError(map);
				}
				logger.info("=fileNm ["+fileNm+ "] insert thread END==============================================================");
			}//end rep
				// call procedure			
				//TODO ::dao.updKISDailyDTL_TLF				
							 				
				bin.close();
				bin = null;

				this.moveFile(path, fileNm+".gz", path + File.separator + "backup");
				this.moveFile(path, fileNm+".INF", path + File.separator + "backup");
				this.deleteFile(path, fileNm);
				//File fileOK = new File(path + File.separator + "backup" + File.separator + targetFile);
			    //File file = new File(path + File.separator + "backup" + File.separator
			    //  + targetFile.substring(0, targetFile.length()-3));
			    logger.info("[debug]" + path + File.separator + "backup" + File.separator + fileNm);
			    //fileOK.renameTo(file);//moveFile후 파일명 끝에 .ok 삭제
			    
				logger.info("Data insert OK.  FTP work well done");	
			

			/*				
			if ((readedLine = bin.readLine() )!= null){ 
			
				logger.info("[DEBUG] File Name : " + fileNm + ", readedLine = " + readedLine);
				logger.info("[DEBUG] File Name : " + fileNm );
				logger.info("readedLine = [" + readedLine +"]");
				int totSize = readedLine.length();
				int totLoopNum =totSize / 160 ;
				logger.info("totSize = [" + totSize +"] totLoopNum = [" + totLoopNum +"]");
				String van_cd = "";
				String fild_dt = "";
				System.out.println("neo0531----1");
				if (fileNm.substring(0,3).equals("KIS")){
					van_cd = "KIS";
				}else if (fileNm.substring(0,3).equals("NIC")){
					van_cd = "NICE";
				}else if (fileNm.substring(0,3).equals("KIC")){
					van_cd = "KICC";
				}
				
				logger.info("van_cd=>"+ van_cd);
				fild_dt = fileNm.substring(fileNm.length()-8, fileNm.length());
				
				//logger.info("FILE_DT=>"+ fileNm.substring(fileNm.length()-8, fileNm.length()));
				String TLF_REP_TP = fileNm.substring(fileNm.length()-12, fileNm.length()-9);
				String tmpStr = "";
				logger.info("TLF_REP_TP=>"+ TLF_REP_TP);
				if (TLF_REP_TP.equals("TLF")){//거래내역 
					for (int idx = 0 ; idx<totLoopNum ; idx++){
						
						tmpStr = readedLine.substring(160*idx, 160*(idx+1));
						logger.info("idx = [" + idx +"]");
						logger.info("tmpStr = [" + tmpStr +"]");
						if (idx==0){  
							//header 인경우 		
							  
							map = COMMBiz.getParseData(KISDTLData.nlensTLF_H, KISDTLData.strHeadersTLF_H, tmpStr);
							map.put("VAN_CD",van_cd);
							map.put("FILE_DT", fild_dt);
							ret = dao.insKISDailyDTL_TLF_H(map);
						}else if (idx == totLoopNum -1 ){ 
							//trailer  인경우 						
							map = COMMBiz.getParseData(KISDTLData.nlensTLF_T, KISDTLData.strHeadersTLF_T, tmpStr);
							map.put("VAN_CD",van_cd);
							map.put("FILE_DT", fild_dt);
							ret  = dao.insKISDailyDTL_TLF_T(map);
						}else{		
							//data인경우 
							map = COMMBiz.getParseData(KISDTLData.nlensTLF_D, KISDTLData.strHeadersTLF_D, tmpStr);
							map.put("VAN_CD",van_cd);
							map.put("FILE_DT", fild_dt);
							ret = dao.insKISDailyDTL_TLF_D(map);
						}
						if( ret != 1 ) {
							logger.info("["+tmpStr+"]"+"There is an Error on inserting data");
							System.out.println("["+tmpStr+"]"+"There is an Error on inserting data");						
						}		

					}
					//TODO ::dao.updKISDailyDTL_TLF
					
				}else if(TLF_REP_TP.equals("REP")){// 입반송내역
					for (int idx = 0 ; idx<totLoopNum ; idx++){
						
						tmpStr = readedLine.substring(150*idx, 150*(idx+1));
						String recId = tmpStr.substring(0,2);
						if (recId.equals("51")){  
							//EDI START 인경우 						
							map = COMMBiz.getParseData(KISDTLData.nlensREP_S, KISDTLData.strHeadersREP_S, tmpStr);
							map.put("VAN_CD",van_cd);
							map.put("FILE_DT", fild_dt);
							ret = dao.insKISDailyDTL_REP_S(map);
						}else if (recId.equals("52")){ 
							//header  인경우 						
							map = COMMBiz.getParseData(KISDTLData.nlensREP_H, KISDTLData.strHeadersREP_H, tmpStr);
							map.put("VAN_CD",van_cd);
							map.put("FILE_DT", fild_dt);
							ret = dao.insKISDailyDTL_REP_H(map);
						}else if (recId.equals("60")||recId.equals("61")||recId.equals("62")||recId.equals("63")
								||recId.equals("64")||recId.equals("65")||recId.equals("66")||recId.equals("67")){ 
							//data  인경우 						
							map = COMMBiz.getParseData(KISDTLData.nlensREP_D, KISDTLData.strHeadersREP_D, tmpStr);
							map.put("VAN_CD",van_cd);
							map.put("FILE_DT", fild_dt);
							ret = dao.insKISDailyDTL_REP_D(map);
						}else if (recId.equals("53")){ 
							//total  인경우 						
							map = COMMBiz.getParseData(KISDTLData.nlensREP_T, KISDTLData.strHeadersREP_T, tmpStr);
							map.put("VAN_CD",van_cd);
							map.put("FILE_DT", fild_dt);
							ret = dao.insKISDailyDTL_REP_T(map);
						}else if (recId.equals("54")){ 
							//EDI END  인경우 						
							map = COMMBiz.getParseData(KISDTLData.nlensREP_E, KISDTLData.strHeadersREP_E, tmpStr);
							map.put("VAN_CD",van_cd);
							map.put("FILE_DT", fild_dt);
							ret = dao.insKISDailyDTL_REP_E(map);
						}
						
						if( ret != 1 ) {
							logger.info("["+tmpStr+"]"+"There is an Error on inserting data");
							System.out.println("["+tmpStr+"]"+"There is an Error on inserting data");						
						}		

					}
					//TODO ::dao.updKISDailyDTL_TLF
					
				} 	
				
							 				
				bin.close();
				bin = null;

				this.moveFile(path, fileNm, path + File.separator + "backup");
				
				//File fileOK = new File(path + File.separator + "backup" + File.separator + targetFile);
			    //File file = new File(path + File.separator + "backup" + File.separator
			    //  + targetFile.substring(0, targetFile.length()-3));
			    logger.info("[debug]" + path + File.separator + "backup" + File.separator + fileNm);
			    //fileOK.renameTo(file);//moveFile후 파일명 끝에 .ok 삭제
			    
				logger.info("Data insert OK.  FTP work well done");	
			}	
			*/
		}catch(Exception e) {
			
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[ERROR1] " + readedLine);
			System.out.println("[ERROR1] " + e.getMessage());
		}finally {
			try {
				if( bin != null ){ bin.close(); bin = null;}
			}catch(Exception e) {
				logger.info("exception occur"+ e.getMessage());
				System.out.println("exception occur"+ e.getMessage());
			}
		}
			
	}
}