package biz.cms_KISDTLDownloader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.cms_MFCIrt.MFCIrtData;
import biz.comm.COMMBiz;

public class KISDTLExtractLogging {
	private static Logger logger = Logger.getLogger(KISDTLDownloaderPollingAction.class);
	 
	String path = "";
	String fileNm = "";	
	String infFileNm = "";
//	String stdDate = "";
	long zipSize_inf = 0;
	long oriSize_inf = 0;
	long zipSize = 0;
	long oriSize = 0;
	
	public KISDTLExtractLogging(String path, String fileNm , String infFileNm) {
		this.path = path;
		this.fileNm = fileNm;
		this.infFileNm = infFileNm;
	
	}
	
	
	public void execute()  {	
	    String zipFilePath = path;
	    String destDirectory = path;
	    BufferedReader bin = null;
	    
	    byte inbytes[] = new byte[30];

		String readedLine = new String("ASCII");

	    String tmp = "";
	    KISDTLDownloaderDAO dao = new KISDTLDownloaderDAO();
	    Map<String, String> map = new HashMap<String, String>();
	    int ret = 0;
	    //1. log file read  but  log file not exist then return, calling method							
		 try{
			 
	     bin = new BufferedReader(new FileReader(path + File.separator + infFileNm));
			System.out.println("[path]"+ this.path
					+ " [fileNm]"+ this.fileNm
					+ " [infFileNm]"+ this.infFileNm);
		 }catch (Exception e) {
				System.out.println("exception =>"+ e.getMessage() );
				System.out.println("INF FILE read Error " + infFileNm +" insert work is halt");
	        logger.info(e.getMessage());
	        logger.info("INF FILE read Error " + infFileNm +" insert work is halt");
	        
	        
	    	map.put("FILE_NM", fileNm );
	    	map.put("ERR_INFO", "["+fileNm +"]exception =>"+ e.getMessage()  );	    	
	    	try {
				dao.insLoggingErr(map);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
	    	
	    	
			bin = null;
		    return;
		 }
		try {
			while( (readedLine = bin.readLine()) != null ) {	//logger.info("[DEBUG] File Name : " + targetFile + ", readedLine = " + readedLine);			
				int col = 0;
				//HashMap hm = new HashMap();
				System.out.println("readedLine =>"+ readedLine );
			    //2. log file parsing 
				//hm = COMMBiz.getParseData(nlens, strHeaders, readedLine);
				map = COMMBiz.getParseData(KISDTLData.nlensLog, KISDTLData.strHeadersLog, readedLine);
				zipSize = Long.parseLong(map.get("ZIP_SIZE"));
				oriSize = Long.parseLong(map.get("ORI_SIZE"));
				System.out.println("zipSize =>"+ zipSize
						+ "oriSize =>"+ oriSize);
			}
		} catch (IOException e) {
			System.out.println("exception =>"+ e.getMessage() );
			System.out.println("INF FILE read Error " + infFileNm +" insert work is halt");
			
			logger.info(e.getMessage());
	        logger.info("INF FILE read Error " + infFileNm +" insert work is halt");
			try {
				bin.close();
			} catch (IOException e1) {
				System.out.println("exception =>"+ e1.getMessage() );
				e1.printStackTrace();
			}
			bin = null;
		}							
		try {
			bin.close();
		} catch (IOException e2) {
			System.out.println("exception =>"+ e2.getMessage() );
			e2.printStackTrace();
		}
		bin = null;
	
	    //3. 압축해제
		String extractFileNm = fileNm.substring(0, fileNm.length()-3);
		
		FileGzip unzipper = new FileGzip ();
		try {
	    	System.out.println("unzip path =>"+  path + File.separator + fileNm );
	        unzipper.unGunzipFile(path + File.separator + fileNm, path + File.separator + extractFileNm);
	        
	    } catch (Exception e) {
	    	map.put("FILE_NM", fileNm );
	    	map.put("ERR_INFO", "File Extract fault:" +fileNm + e.getMessage());	    	
	    	try {
				dao.insLoggingErr(map);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
	    	
	    	
	        logger.info(e.getMessage());
	        System.out.println("exception =>"+ e.getMessage() );
	        return;
	    }
//	    UnzipUtility unzipper = new UnzipUtility();
//	    try {
//	    	System.out.println("unzip path =>"+  path + File.separator + fileNm );
//	        unzipper.unzip(path + File.separator + fileNm, path);
//	        
//	    } catch (Exception e) {
//	        logger.info(e.getMessage());
//	        System.out.println("exception =>"+ e.getMessage() );
//	    }

	    //4. file compare
	    
	    File zipFile =new File(path + File.separator +fileNm);
//	    String extractFileNm = fileNm.substring(0, fileNm.length()-4);
	    File oriFile =new File(path + File.separator +extractFileNm);
	    System.out.println("fileNm[" + path + File.separator +fileNm +"] extractFileNm[" +path + File.separator + extractFileNm+"]");
	    System.out.println("real zipFileSize[" + zipFile.length() +"] real oriFileSize[" + oriFile.length()+"]");      
	    System.out.println("inf zipFileSize[" + zipSize +"] inf oriFileSize[" + oriSize +"]");                         
        logger.info(extractFileNm+"real zipFileSize[" + zipFile.length() +"] real oriFileSize[" + oriFile.length()+"]");
        logger.info(extractFileNm+"inf zipFileSize[" + zipSize +"] inf oriFileSize[" + oriSize +"]");
        
	    //5. log data(result of compare) insert	   
    			
    	
    	map.put("FILE_NM", extractFileNm );
    	map.put("ZIP_FILE_SIZE_INF", Long.toString(zipSize) );	    	
    	map.put("ZIP_FILE_SIZE", Long.toString(zipFile.length()) );
    	map.put("ORG_FILE_SIZE_INF", Long.toString(oriSize ));
    	map.put("ORG_FILE_SIZE", Long.toString(oriFile.length() ));
    	              
    	try {
			ret = dao.insLoggingData(map);
		} catch (Exception e) {
			logger.info("logging exception"+ e.getMessage());
			e.printStackTrace();
			map.put("ERR",e.getMessage());
			try {
				dao.updLogError(map);
			} catch (Exception e1) {
				logger.info("logging exception2"+ e.getMessage());
				e1.printStackTrace();
			}
		}
    	 
    	//if (ret>1)
	    if((zipFile.length() ==zipSize) && (oriFile.length() ==oriSize)){	    	
	    	System.out.println("zip, ori size are same");
			//6. real data insert 
	    	
		    KISDTLDownloaderInst dailyInsert = new KISDTLDownloaderInst(path);
		    dailyInsert.setFileNm(extractFileNm);
		    dailyInsert.setFolderNm(path);
			dailyInsert.start();
			logger.info("KISDTLDownloaderInst is end but maybe insert thread is trying to insert");	
	    }else{
	    	System.out.println(extractFileNm+"zip, ori size are N.O.T. same");	    	
	    	logger.info(extractFileNm+"zip, ori size are N.O.T. same");
	    	
	    	map.put("FILE_NM", fileNm );
	    	map.put("ERR_INFO", "File Extract fault:" +fileNm + "zip, ori size are N.O.T. same");	    	
	    	try {
				dao.insLoggingErr(map);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
	    	
	    }
	    
	    
	}

	

	
	
	
	
	
}
