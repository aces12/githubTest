package biz.cms_POSServiceIrt;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.regex.Pattern;

import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class POSServiceIrtProtocol {
	
	private static Logger logger = Logger.getLogger(POSServiceIrtAction.class);
	
	/***
	 * getRcvEConIrtDATA
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	
	public String getRcvEConIrtDATA(String rcvBuf){		
		HashMap<String, String> hm = new HashMap<String, String>();
		 
		logger.info("EConIrtDATA::rcvBuf::["+rcvBuf+"]"); 
		
		int nlens[]= {2};
		String strHeaders[] = { "INQ_TYPE" };		
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		logger.info("EConIrtDATA::hm::["+hm+"]");
		
		return (String)hm.get("INQ_TYPE");
	}
	
	
	//2018326 KSN 비상벨 SMS 요청
	public HashMap<String, String> getParseEmSMSReq(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 
			2, 1, 2, 64
		};//69
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"EMER_TP"			, // 신고구분
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
	
	//2018328 KSN PT 출퇴근등록 요청
	public HashMap<String, String> getParsePTPunchInOutReq(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 
			2, 1, 50, 2, 64
		};//119
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"WORK_TP"			, // 출퇴근 구분(1: 출근, 2: 퇴근)
			"CARD_DATA"			, // 카드센싱 정보
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
	
	//20180515 KSN 바리스타 부재중등록 요청/응답
	public HashMap<String, String> getParseBTPunchInOutReq(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 
			2, 5, 1, 2, 64
		};//74
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"STORE_CD"			, // 점포코드
			"WORK_TP"			, // 근무여부 구분(1: 근무중, 2: 자리비움)
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		return hm;
	}
	 
	//2018705 leeseungho 현금영수증 부정적립 방지  
	public HashMap<String, String> getParseFindWorkerReq(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 
			2, 30, 2, 64
		};//98
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"MOBILE_NO"			, // 점포코드
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		return hm;
	}
	
}