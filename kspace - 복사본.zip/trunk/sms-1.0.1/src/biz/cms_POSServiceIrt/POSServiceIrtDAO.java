package biz.cms_POSServiceIrt;


import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;

import org.apache.log4j.Logger;

import biz.comm.COMMLog;

public class POSServiceIrtDAO extends GenericDAO {
	
	private static Logger logger = Logger.getLogger(POSServiceIrtAction.class);
	
	public List<Object> selStoreInfo(String storeCd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			connect("CMGNS"); //DB Connection(DB 접속)
			
			sql.put(findQuery("pos-sql", "SEL_STOREINFO"));
			sql.setString(++i, storeCd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR] POSServiceIrtDAO::getStoreInfo::" + sql.debug());
			throw e;
		}
		
		return list;
	}
	
	
	public String selEmerSMSSeq() throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		
		String sequence = "";
		
		try {
			begin();
			connect("CMGNS");	//DB Connection(DB 접속)
			
			sql.put(findQuery("pos-sql", "SEL_EMERSMS_SEQ"));
			list = executeQuery(sql);
			sql.close();
			
			if( list.size() > 0 ){
				sequence = (String)((Map<String, String>)list.get(0)).get("SEQ");
			}
		}catch(Exception e){
			logger.info("[ERROR] selEmerSMSSeq::errMsg::["+e.getMessage()+"]");
		}
		
		return sequence;
	}
	
	
	public int insEmerSMSClient(HashMap<String, String> hmData, String sendMsg, String seq, String svcTp) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		
		int i     = 0;
		int rows  = -1;
		int rows1 = -1; 
		
		//String rcvNum = "112";
		String rcvNum = "01022330112"; //테스트용 번호 (운영반영 시 112로 변경필수!!!)
		//String rcvNum = "01088206746"; //테스트용 번호 (운영반영 시 112로 변경필수!!!)
		

		String store_tel = (String)hmData.get("STORE_TEL");
		
		try {
			begin();
			connect("CMGNS");	//DB Connection(DB 접속)
			
			sql.put(findQuery("pos-sql", "INS_EMERSMS_CLIENT"));
			sql.setString(++i, seq);
			sql.setString(++i, rcvNum);
			logger.info("수신번호 = ["+ rcvNum + "]");
			rows = executeUpdate(sql);
				
			i = 0;
			sql1.clearParameter();
			
			logger.info("seq::["+seq+"]::storeTel::["+store_tel+"]::sendMsg::["+sendMsg+"]");
			
			sql1.put(findQuery("pos-sql", "INS_EMERSMS_SSGTRAN"));
			sql1.setString(++i, seq);
			sql1.setString(++i, svcTp);
			sql1.setString(++i, store_tel);
			sql1.setString(++i, sendMsg);
			
			rows1 = executeUpdate(sql1);
				
		}catch(Exception e){
			logger.info("[ERROR] insEmerSMSClient::errMsg::["+e.getMessage()+"::"+e.getCause()+"]");
			rows = 0;
			rollback();
		}finally{
			if(rows > 0 && rows1 > 0){
				logger.info("rows::["+rows+"]::rows1::["+rows1+"]");
				
				sql.close();
				sql1.close();
			}else{
				rollback();
				rows = 0;
			}
			end();
		}
		
		return rows;
	}
	
	
	public List<Object> selPTInfo(String ptCardNo) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			connect("CMGNS"); //DB Connection(DB 접속)
			
			sql.put(findQuery("pos-sql", "SEL_PTINFO"));
			sql.setString(++i, ptCardNo);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR] POSServiceIrtDAO::selPTInfo::" + sql.debug());
			throw e;
		}
		
		return list;
	}
	
	
	public int selPTPunchInfo(String empNo, String punchTp) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		int punchCnt = 0;
		
		try {
			connect("CMGNS"); //DB Connection(DB 접속)
			
			sql.put(findQuery("pos-sql", "SEL_PTPUNCHINFO"));
			sql.setString(++i, empNo);
			sql.setString(++i, punchTp);
			
			list = executeQuery(sql);
			punchCnt = list.size();
		}catch(Exception e) {
			logger.info("[ERROR] POSServiceIrtDAO::selPTInfo::" + sql.debug());
			throw e;
		}
		
		return punchCnt;
	}

	
	public String setPTPunchCheck(HashMap<String, String> hmComm, HashMap<String, String> hm, String punchTp) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		
		int i = 0;
		
		String ret = "00";
		String res_cd = "00";
		String retMsg = "";
		String regYmdhms = "";
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		regYmdhms = sdf.format(new Date());
		
		try{
			begin();
			connect("CMGNS");	// DB Connection(DB 접속)
			
			logger.info("[DEBUG] [setPTPunchCheck][SP_HQ_SVSTRARR_TRN] Begin");
			proc.put("SP_HQ_SVSTRARR_TRN", 9);
			proc.setString(++i, (String)hmComm.get("COM_CD"));
			proc.setString(++i, (String)hmComm.get("STORE_CD"));
			proc.setString(++i, (String)hmComm.get("POS_NO"));
			proc.setString(++i, (String)hm.get("EMP_NO"));
			proc.setString(++i, punchTp);	//0:출근, 1:퇴근
			proc.setString(++i, regYmdhms.substring(0, 8));
			proc.setString(++i, regYmdhms.substring(8, 14));
			proc.registerOutParameter(++i, DataTypes.INTEGER); // RESP_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR); // RESP_MSG
			ProcedureResultSet prs = super.executeUpdateProcedure(proc);
			res_cd = String.format("%02d", prs.getInt(8));
			retMsg = prs.getString(9);
			logger.info("[DEBUG] [setPTPunchCheck][SP_HQ_SVSTRARR_TRN] ResultMsg:" + retMsg);
			logger.info("[DEBUG] [setPTPunchCheck][SP_HQ_SVSTRARR_TRN] End");
			
			if( prs.getInt(8) != 0 ) {
				res_cd = "99";
			}
			
		}catch(Exception e) {
			rollback();
			ret = "29";
			throw e;
		}finally {
			end();
		}
		
		return res_cd;
	}
	
	
	public int insRSVBTPunchInOut(String storeCd, String workTp) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		
		int i     = 0;
		int rows  = -1;
		
		try {
			begin();
			connect("CMGNS");	//DB Connection(DB 접속)
			
			sql.put(findQuery("pos-sql", "INS_RSVBTPUNCH_INOUT"));
			sql.setString(++i, storeCd);
			sql.setString(++i, workTp);
		
			rows = executeUpdate(sql);
			
			logger.info("[INFO]sql.debug::"+sql.debug());
				
		}catch(Exception e){
			logger.info("[ERROR] insEmerSMSClient::errMsg::["+e.getMessage()+"::"+e.getCause()+"]");
			rows = 0;
			rollback();
		}finally{
			sql.close();
			end();
		} 
		return rows;
	}
	
	 
	public List<Object> selRSVBTPunch(String storeCd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			connect("CMGNS"); //DB Connection(DB 접속)
			
			sql.put(findQuery("pos-sql", "SEL_RSVBTPUNCH_INFO"));
			sql.setString(++i, storeCd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR] POSServiceIrtDAO::selRSVBTPunch::" + sql.debug());
			throw e;
		}
		
		return list;
	}
	
	

	//2018705 leeseungho 현금영수증 부정적립 방지   //PT 직원 전화번호 조회 추가
	public List<Object> getPTPhoneNumber(String hp_num, String sys_ymd, String store_cd) throws Exception  {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		String ret = "00"; 
		String dataMsg = "";
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_PTHPNUMBER"));
			sql.setString(++i, hp_num);
			sql.setString(++i, store_cd);
			sql.setString(++i, sys_ymd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	/*
	 * insEmerSMSClientInsrtHqm
	 * HQ_EM_SMS_TBL 긴급 메시지 전송 내역 에 내역을 등록하기 위한 테이블 내역 
	 * */
	public int insEmerSMSClientInsrtHqm(HashMap<String, String> hmComm ,HashMap<String, String> hmData, String sendMsg, String seq) throws Exception {
		SqlWrapper sql = new SqlWrapper();

		List<Object> list = null;
		int i     = 0;
		int rows  = -1;

		try {
			begin();
			connect("CMGNS");	//DB Connection(DB 접속)
			
			i = 0;
			
			sql.put(findQuery("pos-sql", "INS_HQ_EM_SMS_TBL"));
			sql.setString(++i, (String)hmComm.get("COM_CD"  ));
			sql.setString(++i, (String)hmComm.get("TRAN_YMD"));
			sql.setString(++i, (String)hmComm.get("STORE_CD"));
			sql.setString(++i, (String)hmComm.get("POS_NO"  ));
			sql.setString(++i, (String)hmComm.get("TRAN_NO" ));
			sql.setString(++i, (String)hmComm.get("MSG_TYPE")); // INQ Type(INQ 종별)
			sql.setString(++i, (String)hmData.get("EMER_TP" )); // EMER_TP          신고구분
			sql.setString(++i, seq							 ); // PUSH_SEQ         전송순번
			sql.setString(++i, sendMsg						 ); // PUSH_MSG         전송메시지
			sql.setString(++i, "N"							 ); // PUSH_TP         처리 여부 (기본 N)
			sql.setString(++i, (String)hmData.get("EMP_NO")  ); // REG_EMP_ID      등록자ID
			sql.setString(++i, (String)hmData.get("EMP_NO")  ); // MOD_EMP_ID      수정자ID
			rows = executeUpdate(sql);
			
			sql.close();
		}catch(Exception e){
			logger.info("[ERROR] insEmerSMSClient::errMsg::["+e.getMessage()+"::"+e.getCause()+"]");
			rows = 0;
			rollback();
		}finally{
			end();
		}
		
		return rows;
	}
	
	public int spSMSEmerSEND(String strMsg, String strSender) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			sql.put(findQuery("pos-sql", "PR_SMSSEND_HQM_FALES"));
			sql.setString(++i, strMsg);
			sql.setString(++i, strSender);
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
	
}