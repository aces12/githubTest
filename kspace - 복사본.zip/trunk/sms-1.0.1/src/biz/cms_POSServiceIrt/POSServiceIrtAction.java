package biz.cms_POSServiceIrt;

import java.security.Key;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.net.Socket;
 
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.util.StringUtil;

import oracle.sql.DATE;

import org.apache.commons.net.util.Base64;
import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class POSServiceIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(POSServiceIrtAction.class);
	POSServiceIrtDAO dao = new POSServiceIrtDAO();
	POSServiceIrtProtocol protocol = new POSServiceIrtProtocol();
	
	/**
	 * Receive data from SC through 9034 PORT(SC로부터 데이타를 9034 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(ActionSocket actionSocket) throws Exception {
		// TODO Auto-generated method stub
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		StringBuffer sb = null;
		List<Object> list = null; 
		
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		
		POSServiceIrtProtocol protocol = new POSServiceIrtProtocol();
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			logger.info("[INFO] POSServiceIrt::rcvBuf::[" + rcvBuf + "]"); 
			
			rcvBuf = ((String) actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			logger.info("[INFO] POSServiceIrt::rcvBuf::[" + rcvBuf + "]");
			logger.info("[INFO] POSServiceIrt::hmCommon::["+hmCommon+"]");
			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}

			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			logger.info("[INFO] POSServiceIrt::rcvDataBuf::["+rcvDataBuf+"]");
			inq_type = COMMBiz.getInqTypeCHG(protocol.getRcvEConIrtDATA(rcvDataBuf));
			
			boolean bIsExtended = false;
			
			logger.info("[INFO] POSServiceIrt::inq_type::["+inq_type+"]");
			switch(inq_type) {
			case 2196:	// E9(2196): 비상벨 SMS전송 서비스 요청/응답
				logger.info("Emer SMS Service START");
				
				if (rcvDataBuf.length() == 69) {	//전문길이 체크 (3bytes)
					hmData = protocol.getParseEmSMSReq(rcvDataBuf);
					
					logger.info("[INFO] POSServiceIrt::hmCommon::["+hmCommon+"]");
					logger.info("[INFO] POSServiceIrt::hmData::["+hmData+"]");
					
					dataMsg = SendEmerSms(hmCommon, hmData); //비상벨 SMS 전송
					logger.info("[INFO] POSServiceIrt::dataMsg::["+dataMsg+"]");
				} else {
					logger.info("[ERROR] IRT Length unmatched");
					hmData.put("RSLT_CD", "10");
					hmData.put("RSLT_MSG", "IRT 전문길이 오류");
					return;
				}
				
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			
			case 2219:	// F1(2219): PT 출퇴근 요청/응답
				logger.info("PT punch in/out Service START");
				
				//전문길이 체크 (3bytes)
				if (rcvDataBuf.length() == 119) {
					hmData = protocol.getParsePTPunchInOutReq(rcvDataBuf);
					
					logger.info("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
					logger.info("[INFO] EConIRT::hmData::["+hmData+"]");
					
					dataMsg = PTPunchInOut(hmCommon, hmData); //비상벨 SMS 전송
					logger.info("[INFO] EConIRT::dataMsg::["+dataMsg+"]");
				} else {
					logger.info("[ERROR] IRT Length unmatched");
					hmData.put("RSLT_CD", "10");
					hmData.put("RSLT_MSG", "IRT 전문길이 오류");
					
					//dao.insEConIssLog(hmCommon, hmData);	//로그테이블 이력 쌓기(ST_COUPONISS_LOG)
					return;
				}
				
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
				
			case 2220:	// F2(2220): 바리스타 직원 조회(리저브점 self-pos대응)
				logger.info("RSV BARISTA SEARCH SERVICE START");
				
				//전문길이 체크 (3bytes)
				if (rcvDataBuf.length() == 119) {
					hmData = protocol.getParsePTPunchInOutReq(rcvDataBuf);
					
					logger.info("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
					logger.info("[INFO] EConIRT::hmData::["+hmData+"]");
					
					dataMsg = RSVBTSearch(hmCommon, hmData); //바리스타 직원 조회(리저브점 self-pos 대응)
					logger.info("[INFO] EConIRT::dataMsg::["+dataMsg+"]");
				} else {
					logger.info("[ERROR] IRT Length unmatched");
					hmData.put("RSLT_CD", "10");
					hmData.put("RSLT_MSG", "IRT 전문길이 오류");
					
					return;
				}
				
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
				
			case 2221:	// F3(2221): 바리스타 부재중 등록 요청/응답(리저브점 self-pos대응)
				logger.info("RSV BARISTA punch in/out Service START");
				
				//전문길이 체크 (74bytes)
				if (rcvDataBuf.length() == 74) {
					hmData = protocol.getParseBTPunchInOutReq(rcvDataBuf);
					
					logger.info("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
					logger.info("[INFO] EConIRT::hmData::["+hmData+"]");
					
					dataMsg = RSVBTPunchInOut(hmCommon, hmData); //바리스타 직원 조회(리저브점 self-pos 대응)
					logger.info("[INFO] EConIRT::dataMsg::["+dataMsg+"]");
				} else {
					logger.info("[ERROR] IRT Length unmatched");
					hmData.put("RSLT_CD", "10");
					hmData.put("RSLT_MSG", "IRT 전문길이 오류");
					
					return;
				}
				
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
				
			case 2222:	// F4(2222): 바리스타 부재중 조회 요청/응답(리저브점 self-pos대응)
				logger.info("RSV BARISTA punch Search START");
				
				//전문길이 체크 (74bytes)
				if (rcvDataBuf.length() == 74) {
					hmData = protocol.getParseBTPunchInOutReq(rcvDataBuf);
					
					logger.info("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
					logger.info("[INFO] EConIRT::hmData::["+hmData+"]");
					
					dataMsg = RSVBTPunchSearch(hmCommon, hmData); //바리스타 직원 조회(리저브점 self-pos 대응)
					logger.info("[INFO] EConIRT::dataMsg::["+dataMsg+"]");
				} else {
					logger.info("[ERROR] IRT Length unmatched");
					hmData.put("RSLT_CD", "10");
					hmData.put("RSLT_MSG", "IRT 전문길이 오류");
					
					return;
				}
				
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;

			case 2250:	// G1(2250): 현금영수증 부정적립방지 //2018705 leeseungho 현금영수증 부정적립 방지 
				logger.info("cashRcpt_find_worker START");
					hmData = protocol.getParseFindWorkerReq(rcvDataBuf);
					
					//PT 직원 번호인지 조회 
					int sv_str_tp = 0;
					String mobile_num = hmData.get("MOBILE_NO");
					String sys_ymd = hmCommon.get("SYS_YMD");
					String store_cd = hmCommon.get("STORE_CD");
					list = null;
					
					//암호화 키 만들기
					String tran_no = hmCommon.get("TRAN_NO");
					String pos_no = hmCommon.get("POS_NO");
					
					logger.info("[INFO]모바일 번호" + mobile_num);
					int tran_00 = Integer.parseInt(tran_no.substring(0, 1));
					int tran_01 = Integer.parseInt(tran_no.substring(1, 2));
					int tran_02 = Integer.parseInt(tran_no.substring(2, 3));
					int tran_03 = Integer.parseInt(tran_no.substring(3, 4));

					int pos_00 = Integer.parseInt(pos_no.substring(0, 1));
					int pos_01 = Integer.parseInt(pos_no.substring(1, 2));
					int pos_02 = Integer.parseInt(pos_no.substring(2, 3));
					int pos_03 = Integer.parseInt(pos_no.substring(3, 4));

					logger.info("[INFO]tran_no" + tran_no);
					logger.info("[INFO]tran_no_00" + tran_00);
					logger.info("[INFO]tran_01" + tran_01);
					logger.info("[INFO]tran_02" + tran_02);
					logger.info("[INFO]tran_03" + tran_03);
					logger.info("[INFO]pos_no" + pos_no);
				    StringBuilder sbHPDecKey = new StringBuilder();
				    sbHPDecKey.append((int)((tran_03 ^ pos_03) % 10));
				    sbHPDecKey.append((int)(tran_01 ^ pos_01) % 10);
				    sbHPDecKey.append((int)(tran_02 ^ pos_00) % 10);
				    sbHPDecKey.append((int)(tran_03 ^ pos_02) % 10);
				    sbHPDecKey.append((int)(pos_01 ^ tran_03) % 10);
				    sbHPDecKey.append((int)(pos_01 ^ tran_00) % 10);
				    sbHPDecKey.append((int)(pos_02 ^ tran_03) % 10);
				    sbHPDecKey.append((int)(pos_00 ^ tran_02) % 10);
				    sbHPDecKey.append((int)(tran_03 ^ pos_03) % 10);
				    sbHPDecKey.append((int)(tran_01 ^ pos_01) % 10);
				    sbHPDecKey.append((int)(tran_02 ^ pos_00) % 10);
				    sbHPDecKey.append((int)(tran_03 ^ pos_02) % 10);
				    sbHPDecKey.append((int)(pos_01 ^ tran_03) % 10);
				    sbHPDecKey.append((int)(pos_01 ^ tran_00) % 10);
				    sbHPDecKey.append((int)(pos_02 ^ tran_03) % 10);
				    sbHPDecKey.append((int)(pos_00 ^ tran_02) % 10);
				    
				    
				    String secretKey = sbHPDecKey.toString();				    
				    logger.info("[INFO]secretKey" + secretKey);
				    
					//모바일 번호 복호화 필요

					logger.info("[INFO]mobile_num 1 [" + mobile_num+"]");
									
					//String personal_info = (new AES()).decAES(mobile_num, secretKey);
					String personal_info = decAES(mobile_num, secretKey);

					logger.info("[INFO]mobile_num 1 " + personal_info);
					logger.info("[INFO]sys_ymd 1 " + sys_ymd);
					logger.info("[INFO] store_cd 1 " + store_cd);
					list = dao.getPTPhoneNumber(personal_info, sys_ymd, store_cd);
					
					logger.info("[INFO]getPTPhoneNumber list.size()" + list.size());
					
				
					boolean chkValue = true;
					if( list.size() > 0 ) {
						for( int i = 0;i < list.size();i++ ) {
							Map<String, String> map = (Map<String, String>)list.get(i);
							logger.info("[INFO] SV_STRARR_TP : " + ((String)map.get("SV_STRARR_TP")));
							if(((String)map.get("SV_STRARR_TP")).equals("0")) {
								logger.info("[INFO] 출근중!!!!!!!!!");
								ret = 00;
								hmData.put("RESP_CD", "99");
								hmData.put("RESP_MSG", "근무중");
								dataMsg = "00" + makeSendDatafindWorkerRsp(hmData);
								logger.info("<----- 11 ----->"+dataMsg);
								chkValue = false;
							}
						}						
					} 
					if(chkValue) {
						logger.info("[INFO] 출근아님!!!!!!!!!");					
						hmData.put("RESP_CD", "00");
						hmData.put("RESP_MSG", "근무아님");						
						dataMsg = "00" + makeSendDatafindWorkerRsp(hmData);
						logger.info("<----- 12 ----->"+ dataMsg);
					}
					
				
				
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;				
				
				default:
					logger.info("[INFO] INQ Type Code::["+inq_type+"]::LEN::["+rcvBuf.length()+"]");
					ret = 99;
					break;
			}
		} catch (Exception e) {
			ret = 29; // 029=HOST APPL ERR
			retValue = "[ERROR]2:" + e.getMessage();
			logger.info("▶ " + retValue);
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			logger.info("dataMsg[" + dataMsg + "]");
			logger.info("sendMsg[" + sendMsg + "]");
					
			logger.info("================ 4-2) POS<-SMS 응답전문 ===================");
			logger.info("전문길이=[" + totalMsg.getBytes().length + "]");
			logger.info("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
			logger.info("전문내용=[" + totalMsg + "]");
			
			// Send Response Data (응답 데이타 전송)
			if (actionSocket.send(totalMsg)) {
				logger.info("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
			} else {
				logger.info("[pos<sms] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		} catch (Exception e) {
			retValue = "[ERROR]4" + e.getMessage();
			logger.info(retValue);
		} finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			logger.info("[INFO] EConIrtAction IRT FINISH.");
		}
	}
	
	
	//비상벨 SMS 전송
	private String SendEmerSms(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		logger.info("[INFO] POSServiceIRT::hmCom::["+hmCom+"]");
		logger.info("[INFO] POSServiceIRT::hmData::["+hmData+"]");
		
		String dataMsg  = "";
		String storeCd  = (String)hmCom.get("STORE_CD");
		String storeNm  = "";
		String storeAdd = "";
		String storeTel = "";
		String emerTp   = (String)hmData.get("EMER_TP");	//sms신고/취소 구분 (1:신고, 2:취소)
		String sendMsg  = "";
		String seq		= "";
		String ret		= "00";
		String respMsg  = "";
		String respCd   = "00";
		String svcTp	= "0";
		
		//점포정보 조회
		List storeInfo = null;
		HashMap<String, String> storeMap = new HashMap<String, String>();
		
		try {
			storeInfo = (List)dao.selStoreInfo(storeCd);
		
			logger.info("[INFO] SendEmerSms::storeInfoSize::["+storeInfo.size()+"]::storeInfo::["+storeInfo+"]");
			if(storeInfo.size() > 0){
				for(int i=0; i<storeInfo.size(); i++){
					storeMap = (HashMap<String, String>)storeInfo.get(i);
					logger.info("[INFO] POSServiceIRT::emerTp::["+emerTp+"]::storeMap::["+storeMap+"]");
					
					storeNm = (String)storeMap.get("STORE_NM");
					storeAdd = (String)storeMap.get("STORE_ADD");
					storeTel = (String)storeMap.get("STORE_TEL");
					
					if("1".equals(emerTp)){
						//신고 sms
						sendMsg = "긴급 이마트24 "+storeNm;
						svcTp = "0";
					}else if("2".equals(emerTp)){
						//취소 sms
						sendMsg = "취소 이마트24 "+storeNm;
						svcTp = "0";
					}
					
					try {
						seq = dao.selEmerSMSSeq();
						 
						try{
							int rsltNum = 0;
							rsltNum = dao.insEmerSMSClient(storeMap, sendMsg, seq, svcTp);
							
							logger.info("rsltNum::["+rsltNum+"]");
							if(rsltNum > 0){
								respMsg = "정상완료";
								// 20180720 JMH 비상벨 발송 되면 HQM 테이블에 등록 비상벨 발송후 메시지 내용 등록
								dao.insEmerSMSClientInsrtHqm( hmCom, hmData, sendMsg, seq);
							}else{
								respCd  = "99";
								respMsg = "SMS전송실패";
								dao.spSMSEmerSEND("비상벨 SMS 발송 실패 ("+sendMsg+")", "cms_POSServiceIrt");
							}
						}catch (Exception e) {
							respCd  = "99";
							respMsg = "SMS전송실패";
							logger.info("[ERROR] SendEmerSms::insEmerSMSClient::["+e.getMessage()+"]::["+e.getCause()+"]");
							dao.spSMSEmerSEND("비상벨 SMS 발송 실패 ("+sendMsg+")", "insEmerSMSClient");
						}
					}catch(Exception e){
						respCd  = "99";
						respMsg = "SMS전송실패";
						logger.info("[ERROR] selEmerSMSSeq::errMsg::["+e.getMessage()+"]::["+e.getCause()+"]");
					}
				}
			}
		} catch (Exception e) {
			ret = "29";
			respCd  = "99";
			respMsg = "SMS전송실패";
			logger.info("[ERROR] SendEmerSms::selStoreInfo::["+e.getMessage()+"]::["+e.getCause()+"]");
		} finally {
			storeMap.put("INQ_TYPE", "E9");
			storeMap.put("EMER_TP", "");
			storeMap.put("RESP_CD",  respCd);
			storeMap.put("RESP_MSG", respMsg);
			
			dataMsg = ret + makeSendDataEmerSMSRsp(storeMap);
		}
		
		return dataMsg;
	}
	
	
	//20180329 KSN PT 출퇴근등록
	private String PTPunchInOut(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		logger.info("[INFO] POSServiceIrt::hmCom::["+hmCom+"]");
		logger.info("[INFO] POSServiceIrt::hmData::["+hmData+"]");
		
		String dataMsg  = "";
		String ptCardNo = (String)hmData.get("CARD_DATA");	//PT출퇴근 카드정보
		String workTp   = (String)hmData.get("WORK_TP");	//출퇴근 구분 (1:출근, 2:퇴근)
		String workNm   = ""; 								//출퇴근 구분명(1:출근, 2:퇴근)
		String punchTp  = "";
		String dutyCd   = ""; 								//직원구분코드
		String dutyNm	= "";								//직원구분명
		String empNo	= "";								//임직원번호
		String ret		= "00";
		String respCd   = "00";
		String respMsg  = "";
		
		int punchCnt = 0;
		
		//1. PT직원여부 조회
		List ptInfo = null;
		HashMap<String, String> ptInfoMap = new HashMap<String, String>();
		HashMap<String, String> respMap = new HashMap<String, String>();
		
		try {
			if("1".equals(workTp)){
				workNm  = "출근";
				punchTp = "0";
			}else if("2".equals(workTp)){
				workNm  = "퇴근";
				punchTp = "1";
			}
			
			logger.info("[INFO] selPTInfo::ptCardNo::["+ptCardNo+"]");
			ptInfo = (List)dao.selPTInfo(ptCardNo);
		
			logger.info("[INFO] selPTInfo::ptInfoSize::["+ptInfo.size()+"]::ptInfo::["+ptInfo+"]");
			if(ptInfo.size() > 0){
				for(int i=0; i<ptInfo.size(); i++){
					ptInfoMap = (HashMap<String, String>)ptInfo.get(i);
					logger.info("[INFO] EConIRT::workTp::["+workTp+"]::ptCardNo::["+ptCardNo+"]");
					
					dutyCd = (String)ptInfoMap.get("DUTY_CD");
					dutyNm = (String)ptInfoMap.get("DUTY_NM");
					empNo  = (String)ptInfoMap.get("EMP_NO");
					
					if("W22".equals(dutyCd) && "PT".equals(dutyNm)){
						punchCnt = dao.selPTPunchInfo(empNo, punchTp); //금일 출/퇴근등록여부 체크
						if(punchCnt == 0){
							try{
								respCd = dao.setPTPunchCheck(hmCom, ptInfoMap, punchTp);
								if("00".equals(respCd)){
									respMsg = (String)ptInfoMap.get("EMP_NM") + "PT " + workNm + " 등록완료";
								}else{
									respMsg = (String)ptInfoMap.get("EMP_NM") + "PT " + workNm + " 등록실패";
								}
							}catch (Exception e) {
								respCd  = "99";
								respMsg = workNm + " 등록실패";
								logger.info("[ERROR] SendEmerSms::insEmerSMSClient::["+e.getMessage()+"]::["+e.getCause()+"]");
							}
						}else{
							//기등록처리 메시지 전달
							respCd  = "99";
							respMsg = "금일 " + (String)ptInfoMap.get("EMP_NM") + "PT " + workNm+ " 등록이 이미 완료되었습니다.";
						}
					}else{
						//PT직원아님, 등록불가 메시지 전달
						respCd  = "99";
						respMsg = "PT직원아님, " + workNm + " 등록불가";
					}
				}
			}else{
				//PT직원없음, 등록불가 메시지 전달
				respCd  = "99";
				respMsg = "PT직원없음, " + workNm + " 등록불가";
			}
		} catch (Exception e) {
			ret = "29";
			respCd  = "99";
			respMsg = workNm + " 등록실패";
			logger.info("[ERROR] SendEmerSms::selStoreInfo::["+e.getMessage()+"]::["+e.getCause()+"]");
		} finally {
			respMap.put("INQ_TYPE", "F1");
			respMap.put("WORK_TP",  "");
			respMap.put("CARD_DATA",  "");
			respMap.put("RESP_CD",  respCd);
			respMap.put("RESP_MSG", respMsg);
			
			dataMsg = ret + makeSendDataPTPunchRsp(respMap);
		}
		
		return dataMsg;
	}
	
	
	//20180511 KSN 바리스타 직원 조회
	private String RSVBTSearch(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		logger.info("[INFO] POSServiceIrt::hmCom::["+hmCom+"]");
		logger.info("[INFO] POSServiceIrt::hmData::["+hmData+"]");
		
		String dataMsg  = "";
		String ptCardNo = (String)hmData.get("CARD_DATA");	//PT출퇴근 카드정보
		String workTp   = (String)hmData.get("WORK_TP");	//바리스타 유무 (3)
		String workNm   = ""; 								//존재 유무(1:유, 2:무)
		String punchTp  = "";
		String dutyCd   = ""; 								//직원구분코드
		String dutyNm	= "";								//직원구분명
		String empNo	= "";								//임직원번호
		String ret		= "00";
		String respCd   = "00";
		String respMsg  = "";
		
		int punchCnt = 0;
		
		//1. 바리스타 직원 조회
		List ptInfo = null;
		HashMap<String, String> respMap = new HashMap<String, String>();
		
		try {
			logger.info("[INFO] selPTInfo::ptCardNo::["+ptCardNo+"]");
			ptInfo = (List)dao.selPTInfo(ptCardNo);
		
			logger.info("[INFO] selPTInfo::ptInfoSize::["+ptInfo.size()+"]::ptInfo::["+ptInfo+"]");
			if(ptInfo.size() > 0){
				respMsg = "정상";
			}else{
				respCd  = "99";	//바리스타 직원 없음 메시지 전달
				respMsg = "해당 직원없음.";
			}
		} catch (Exception e) {
			ret = "29";
			respCd  = "99";
			respMsg = "바리스타 직원 조회 실패";
			logger.info("[ERROR] RSVPunchInOut::selPTInfo::["+e.getMessage()+"]::["+e.getCause()+"]");
		} finally {
			respMap.put("INQ_TYPE", "F2");
			respMap.put("WORK_TP",  "");
			respMap.put("CARD_DATA",  "");
			respMap.put("RESP_CD",  respCd);
			respMap.put("RESP_MSG", respMsg);
			
			dataMsg = ret + makeSendDataRSVPunchRsp(respMap);
		}
		
		return dataMsg;
	}
	
	
	//20180515 KSN 바리스타 부재중 등록 요청/응답
	private String RSVBTPunchInOut(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		logger.info("[INFO] POSServiceIrt::hmCom::["+hmCom+"]");
		logger.info("[INFO] POSServiceIrt::hmData::["+hmData+"]");
		
		String dataMsg  = "";
		String workTp   = (String)hmData.get("WORK_TP");	//바리스타 유무(1)
		String storeCd  = (String)hmData.get("STORE_CD");	//점포코드(5)
		String ret		= "00";
		String respCd   = "00";
		String respMsg  = "";
		
		int punchCnt = 0;
		
		//1. 바리스타 직원 조회
		List ptInfo = null;
		HashMap<String, String> respMap = new HashMap<String, String>();
		
		try {
			logger.info("[INFO] RSVBTPunchInOut::storeCd::["+storeCd+"]");
			punchCnt = dao.insRSVBTPunchInOut(storeCd, workTp);
		
			logger.info("[INFO] selPTInfo::punchCnt::["+punchCnt+"]");
			if(punchCnt > 0){
				respMsg = "정상";
			}else{
				respCd  = "99";	//바리스타 직원 없음 메시지 전달
				respMsg = "바리스타 근무여부 등록 실패";
			}
		} catch (Exception e) {
			ret = "29";
			respCd  = "99";
			respMsg = "바리스타 근무여부 등록 실패";
			logger.info("[ERROR] RSVPunchInOut::selPTInfo::["+e.getMessage()+"]::["+e.getCause()+"]");
		} finally {
			respMap.put("INQ_TYPE", "F3");
			respMap.put("STORE_CD",  "");
			respMap.put("WORK_TP",  "");
			respMap.put("RESP_CD",  respCd);
			respMap.put("RESP_MSG", respMsg);
			
			dataMsg = ret + makeSendDataRSVBTPunchRsp(respMap);
			
		}
		
		return dataMsg;
	}
	
	
	//20180515 KSN 바리스타 부재중 등록 요청/응답
	private String RSVBTPunchSearch(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		logger.info("[INFO] POSServiceIrt::hmCom::["+hmCom+"]");
		logger.info("[INFO] POSServiceIrt::hmData::["+hmData+"]");
		
		String dataMsg  = "";
		String workTp   = "";	//바리스타 유무(1)
		String storeCd  = (String)hmData.get("STORE_CD");	//점포코드(5)
		String ret		= "00";
		String respCd   = "00";
		String respMsg  = "";
		
		//1. 바리스타 직원 조회
		List rsvBtPunchInfo = null;
		HashMap<String, String> respMap = new HashMap<String, String>();
		HashMap<String, String> rsvBtPunchInfoMap = new HashMap<String, String>();
		
		try {
			logger.info("[INFO] RSVBTPunchInOut::storeCd::["+storeCd+"]");
			rsvBtPunchInfo = dao.selRSVBTPunch(storeCd);
		
			logger.info("[INFO] selPTInfo::ptInfoSize::["+rsvBtPunchInfo.size()+"]::ptInfo::["+rsvBtPunchInfo+"]");
			if(rsvBtPunchInfo.size() > 0){
				for(int i=0; i<rsvBtPunchInfo.size(); i++){
					rsvBtPunchInfoMap = (HashMap<String, String>)rsvBtPunchInfo.get(i);
				}
				respMsg = "정상";
				
			}else{
				respCd  = "99";	//바리스타 직원 없음 메시지 전달
				respMsg = "바리스타 근무여부 조회 실패";
			}
		} catch (Exception e) {
			ret = "29";
			respCd  = "99";
			respMsg = "바리스타 근무여부 조회 실패";
			logger.info("[ERROR] RSVPunchInOut::selPTInfo::["+e.getMessage()+"]::["+e.getCause()+"]");
		} finally {
			respMap.put("INQ_TYPE", "F4");
			respMap.put("STORE_CD",  rsvBtPunchInfoMap.get("STORE_CD"));
			respMap.put("WORK_TP",  rsvBtPunchInfoMap.get("WORK_TP"));
			respMap.put("RESP_CD",  respCd);
			respMap.put("RESP_MSG", respMsg);
			
			dataMsg = ret + makeSendDataRSVBTPunchRsp(respMap);
		}
		
		return dataMsg;
	}
	
	//2018326 KSN 비상벨 SMS 응답
	private String makeSendDataEmerSMSRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 1, 2, 64
		};//69
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"EMER_TP"			, // 신고구분
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//2018329 KSN PT출퇴근 등록
	private String makeSendDataPTPunchRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 1, 50, 2, 64
		};//119
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"WORK_TP"			, // 출퇴근 구분
			"CARD_DATA"			, // 카드센싱 정보
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//2018511 KSN 바리스타 직원 조회
	private String makeSendDataRSVPunchRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 1, 50, 2, 64
		};//119
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"WORK_TP"			, // 출퇴근 구분
			"CARD_DATA"			, // 카드센싱 정보
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//2018515 KSN 바리스타 부재중 등록 요청/응답
	private String makeSendDataRSVBTPunchRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 5, 1, 2, 64
		};//74
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"STORE_CD"			, // 점포코드
			"WORK_TP"			, // 근무여부 구분(1:근무중, 2:자리비움)
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	

	//2018705 leeseungho 현금영수증 부정적립 방지 
	private String makeSendDatafindWorkerRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 30, 2, 64
		};//74
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"MOBILE_NO"			, // 점포코드
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public Key getAESKey(String secretkey) throws Exception {
	    String iv;
	    Key keySpec;

	    String key = secretkey;
	    iv = key.substring(0, 16);	    
	    byte[] keyBytes = new byte[16];	    
	    byte[] b = key.getBytes("UTF-8");	   
	    int len = b.length;	   
	    if (len > keyBytes.length) {
	       len = keyBytes.length;
	    }
	    logger.info("<----- 1 ----->");
	    System.arraycopy(b, 0, keyBytes, 0, len);
	    logger.info("<----- 2 ----->");
	    keySpec = new SecretKeySpec(keyBytes, "AES");
	    logger.info("<----- 22 ----->");
	    return keySpec;
	}
	
	// 복호화
	public String decAES(String enStr, String secretKey) throws Exception {
	    Key keySpec = getAESKey(secretKey);
	    String iv = secretKey;
	    Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
	    c.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(iv.getBytes("UTF-8")));
	    logger.info("<----- 3 ----->");
	    byte[] byteStr = Base64.decodeBase64(enStr.getBytes("UTF-8"));
	    logger.info("<----- 4 ----->");
	    String decStr = new String(c.doFinal(byteStr), "UTF-8");
	    logger.info("<----- 5 ----->");
	    return decStr;
	}
	
}



