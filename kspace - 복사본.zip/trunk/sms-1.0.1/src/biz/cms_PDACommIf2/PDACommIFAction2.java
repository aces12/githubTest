package biz.cms_PDACommIf2;

import java.util.HashMap;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMBiz_PDA;
import biz.comm.COMMLog;

/** 
 * PDACommIFAction2
 * 
 * blah..blah..A Class that has inherited ServerAction(ServerAction을 상속받은 클래스)
 * blah..blah..A class to receive and process Tran data through 9020 port(트란데이타를 9020포트로 수신 받아 처리하는 클래스) 
 * @created  on 1.0,  14/02/10
 * @created  by topco(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */ 
public class PDACommIFAction2 extends ServerAction {

	private static Logger logger = Logger.getLogger(PDACommIFAction2.class);

	/**
	 * Receive data from SC through 9020 PORT(SC로부터 데이타를 9020 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	@Override
	public void execute(ActionSocket actionSocket) throws Exception {
		// TODO Auto-generated method stub
		//
		int 	ret = 0;
		int		inq_type = 0;
		String  sendMsg = "";
		String  dataMsg = "";
		String	rcvBuf = "";
		String 	rcvDataBuf = "";
		String  retValue = "OK!";
		HashMap hmCommon = new HashMap();
		HashMap hmData = new HashMap();
		PDACommIFDAO2 dao = new PDACommIFDAO2();
		PDACommIFProtocol2 protocol = new PDACommIFProtocol2();
		COMMLog df = new COMMLog();
		//
		try {
			// Data received from SC(SC로부터 받은 Data)
			rcvBuf = (String)actionSocket.receive();
			
			// Server TEST Packet
			if(rcvBuf.toString().length()<54)
				return;
			
			// set work start time(업무시작시간  설정)
			df.setStartTime();
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),
								 String.valueOf(actionSocket.getSocket().getPort()),
								 logger,
								 "PDACommIF2");
			
			df.CommLogger("▶ 0: Receive Data :[" + rcvBuf+"]");
			
			hmCommon = COMMBiz_PDA.getData(rcvBuf, COMMBiz_PDA.CM_HEADER_PDA);
			// Compare to see if MsgType message type value is PDA(전문구분값이 PDA인지
			// 비교한다).
			if( !COMMBiz_PDA.getCommMsgType(hmCommon, COMMBiz_PDA.PDA) ) // COMMBiz_PDA.PDA
				return;
			// Get Tran Date(트란 일자를 가져온다.)
			String tranYmd = COMMBiz_PDA.getCommTranYMD(hmCommon);
		
			rcvDataBuf = rcvBuf.substring(COMMBiz_PDA.CM_LENS_PDA);
//			df.CommLogger("▶ 1: Receive INQ Data: " + rcvDataBuf);
			
			inq_type = protocol.getRcvPDAInqType(rcvDataBuf);
			
			
			inq_type = COMMBiz.getInqTypeCHG(protocol.getRcvPDAIrtDATA(rcvDataBuf));
			boolean bIsExtended = false;
			logger.error("inq_type[" + inq_type + "]");
			
			
			switch( inq_type ) {
			// 10: Inquire User(점포 사용자 조회) :
			case 10: 
				df.execute("USER STORE LOGIN");
				hmData = protocol.getParseInqUser(rcvDataBuf); 
				dataMsg = dao.selUserInfoStore(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						(String)hmData.get("USER_ID"),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 11: // 시스템시간 동기화(DB시간)
				df.execute("IQ_SYSTEM_DATE_REQ");
				hmData = protocol.getSystemDate(rcvDataBuf);
				dataMsg = dao.setSystemDate(hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);				
				dataMsg = dataMsg.substring(2);
				break;
			case 21: // 진열대 마스터 정보 요청 
				df.execute("IQ_MASTER_STAND_REQ");
				hmData = protocol.getParseMasterStandReq(rcvDataBuf); 
				dataMsg = dao.getParseMasterStandReq((String)hmCommon.get("COM_CD"), hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 22: // 버전 정보 요청 
				df.execute("IQ_MASTER_VER_REQ");
				hmData = protocol.getAppVersion(rcvDataBuf); 
				dataMsg = dao.getAppVersion((String)hmCommon.get("COM_CD"), hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 23: // 정전시 PDA판매 거래정보 전송 요청
				df.execute("IQ_PDAEMEGR_TRN_REQ");
				hmData = protocol.getPDAEmegrTran(rcvDataBuf);
				dataMsg = dao.setPDAEmergencyTran((String)hmCommon.get("COM_CD"), hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 24: // 발주 여신금액 조회 요청
				df.execute("IQ_STORE_LOAN_REQ");
				hmData = protocol.getStoreLoan(rcvDataBuf);
				dataMsg = dao.setStoreLoan(hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 25://점상품 조회요청
				df.execute("IQ_STORE_ITEM_SEARCH_REQ");
				hmData = protocol.getStoreITMINFO(rcvDataBuf);
				dataMsg = dao.getStoreITEMINFOS(hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0,2),99);
				dataMsg = dataMsg.substring(2);
				break;
			case 30: // 점포 상품 바코드 확인을 위한 임시 사용
				df.execute("IQ_PLU_TEMP_REQ");
				hmData = protocol.getPLU_TEMP(rcvDataBuf,df); 
				dataMsg = dao.setPLU_TEMP((String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			///
			/// 점포
			///
			case 31://점포 발주- 긴급발주 상품정보 요청 - 발주가능금액, 상품대 제외 배송처
				df.execute("(ED)IQ_SCAN_ORDER_REQ");
				hmData = protocol.getScanPluInfo(rcvDataBuf);
				dataMsg = dao.selScanPluInfo3(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 27: //(신)점포발주-스캔방식 상품정보 수정 요청 (여신 체크)
			case 32: // 점포발주-긴급발주 상품정보 수정 요청 (여신 체크)
				df.execute("(New)IQ_SCAN_ORDER_UPDATE_REQ");
				hmData = protocol.getScanPluUpdate(rcvDataBuf, df);
				dataMsg = dao.setScanPluUpdate(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 33://점포발주 진열대 상품정보 요청 - 발주가능금액, 상품대 제외 배송처
				df.execute("N_STAND_ORDER_REQ");
				hmData = protocol.getStandPluInfo(rcvDataBuf);
				dataMsg = dao.selStandPluInfo3( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 34://점포 발주- 긴급발주 상품정보 요청 - 이익율,행사,반품구분 등 추가 I.G 2015.06.01
				df.execute("(ED)IQ_SCAN_ORDER_REQ");
				hmData = protocol.getScanPluInfo(rcvDataBuf);				
				dataMsg = dao.selScanPluInfo4(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 35://점포발주 진열대 상품정보 요청 - 이익율,행사,반품구분 등 추가 I.G 2015.06.10
				df.execute("N_STAND_ORDER_REQ");
				hmData = protocol.getStandPluInfo(rcvDataBuf);
				dataMsg = dao.selStandPluInfo4( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 36://점포발주 신상품 상품정보 요청 I.G
				df.execute("N_STAND_ORDER_REQ");
				hmData = protocol.getStandPluInfo(rcvDataBuf);
				dataMsg = dao.selStandPluInfo5( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 37://점포발주 상품정보 요청 I.G
				df.execute("N_ORDER_LIST_REQ");
				hmData = protocol.getOrderPluInfo(rcvDataBuf);
				dataMsg = dao.selOrderPluInfo( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 38://점포발주-발주제외 조회요청 I.G
				df.execute("IQ_EXCEPT_SEARCH_REQ");
				hmData = protocol.getStoreITMINFO(rcvDataBuf);
				dataMsg = dao.getStoreEXCEPTINFOS(hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0,2),99);
				dataMsg = dataMsg.substring(2);
				break;
			case 39://점포발주-발주제외 수정요청 I.G
				df.execute("IQ_EXCEPT_UPDATE_REQ");
				hmData = protocol.setExceptOrd(rcvDataBuf);
				dataMsg = dao.insExceptOrd(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData,df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0,2),99);
				dataMsg = dataMsg.substring(2);
				break;
			case 40://점포 발주- 긴급발주 상품정보 요청 - 발주 상품조회 시 메시지 추가 I.G 2015.12.07 (selScanPluInfo5 -> selScanPluInfo6 :PLU(바코드) 체크 추가 2015.12.23)
				df.execute("IQ_SCAN_ORDER_REQ2");
				hmData = protocol.getScanPluInfo(rcvDataBuf);				
				dataMsg = dao.selScanPluInfo6(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 41://점포 발주- 긴급발주 상품정보 요청 (selScanPluInfo6 -> selScanPluInfo7 : 2줄 출력 제거2016.07.19)
				df.execute("IQ_SCAN_ORDER_REQ2");
				hmData = protocol.getScanPluInfo(rcvDataBuf);				
				dataMsg = dao.selScanPluInfo7(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 42://[점포 발주] 스캔(조회) - FF발주 선마감 반영 2016.10.21 I.G
				df.execute("IQ_SCAN_ORDER_REQ2");
				hmData = protocol.getScanPluInfo(rcvDataBuf);				
				dataMsg = dao.selScanPluInfo8(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 43: //[점포 발주] 스캔(저장) - FF발주 선마감 반영 2016.10.21 I.G
				df.execute("IQ_SCAN_ORDER_UPDATE_REQ2");
				hmData = protocol.getScanPluUpdate(rcvDataBuf, df);				
				//dataMsg = dao.setScanPluUpdate2(
				dataMsg = dao.setScanPluUpdate3( // 신발주 180309 I.G
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 44://[점포 발주] 분류별(조회) - FF발주 선마감 반영 2016.10.21 I.G
				df.execute("N_STAND_ORDER_REQ");
				hmData = protocol.getStandPluInfo(rcvDataBuf);
				dataMsg = dao.selStandPluInfo6( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 45://[점포 발주] 신상품(조회) - FF발주 선마감 반영 2016.10.21 I.G
				df.execute("N_NEW_STAND_ORDER_REQ");
				hmData = protocol.getStandPluInfo(rcvDataBuf);
				dataMsg = dao.selStandPluInfo7( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 46: //[점포 발주] 분류별/신상품(저장) - FF발주 선마감 반영 2016.10.21 I.G 
				df.execute("(New)IQ_STAND_UPDATE_REQ");
				hmData = protocol.getStandPluUpdate(rcvDataBuf, df);
				dataMsg = dao.setStandPluUpdate2(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 47://[점포 발주] 발주수정(조회) - FF발주 선마감 반영 2016.10.21 I.G 
				df.execute("N_ORDER_LIST_REQ");
				hmData = protocol.getOrderPluInfo(rcvDataBuf);
				dataMsg = dao.selOrderPluInfo2( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 48: //[점포 발주] 발주수정(저장) - FF발주 선마감 반영 2016.10.21 I.G
				df.execute("(New)IQ_STAND_UPDATE_REQ");
				hmData = protocol.getStandPluUpdate(rcvDataBuf, df);
				//dataMsg = dao.setStandPluUpdate3(
				dataMsg = dao.setStandPluUpdate4( // 신발주 180309 I.G
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 49://[점포 발주] 스캔(조회) - 5대행사/발주불가 체크 추가 2016.11.21 I.G
				df.execute("IQ_SCAN_ORDER_REQ2");
				hmData = protocol.getScanPluInfo(rcvDataBuf);				
				dataMsg = dao.selScanPluInfo9(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 51://[반품등록] 한도반품 일자/한도 조회
				df.execute("IQ_LIMIT_RTN_DATE_REQ");
				hmData = protocol.getLimitRtnInfo(rcvDataBuf);
				dataMsg = dao.selLimitRtnDateInfo( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 52://[반품등록] 한도반품(조회)
				df.execute("IQ_LIMIT_RTN_REQ");
				hmData = protocol.getLimitRtnInfo(rcvDataBuf);
				dataMsg = dao.selLimitRtnInfo( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 53://[반품등록] 한도반품 상품(조회)
				df.execute("IQ_RTN_GDS_REQ");
				hmData = protocol.getRtnGdsInfo(rcvDataBuf);
				dataMsg = dao.selLimitRtnGdsInfo( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 54://[반품등록] 반품등록(저장)
				df.execute("IQ_RTN_UPDATE_REQ");
				hmData = protocol.getRtnMgrUpdate(rcvDataBuf, df);
				dataMsg = dao.setRtnMgrUpdate( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 55://[반품등록] 초도반품 일자/한도 조회
				df.execute("IQ_FIRST_RTN_DATE_REQ");
				hmData = protocol.getLimitRtnInfo(rcvDataBuf);
				dataMsg = dao.selFirstRtnDateInfo( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 56://[반품등록] 초도반품(조회)
				df.execute("IQ_FIRST_RTN_REQ");
				hmData = protocol.getLimitRtnInfo(rcvDataBuf);
				dataMsg = dao.selFirstRtnInfo( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 57://[반품등록] 리콜반품 일자/한도 조회
				df.execute("IQ_RECALL_RTN_DATE_REQ");
				hmData = protocol.getLimitRtnInfo(rcvDataBuf);
				dataMsg = dao.selRecallRtnDateInfo( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 58://[반품등록] 리콜반품(조회)
				df.execute("IQ_RECALL_RTN_REQ");
				hmData = protocol.getLimitRtnInfo(rcvDataBuf);
				dataMsg = dao.selRecallRtnInfo( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 28: //(신)점포발주-진열대 진열대 상품 정보 수정 요청 (여신 체크)
				df.execute("(New)IQ_STAND_UPDATE_REQ");
				hmData = protocol.getStandPluUpdate(rcvDataBuf, df);
				dataMsg = dao.setStandPluUpdate(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 72://가격표 이전내역 삭제
				df.execute("IQ_PRINT_DEL_REQ");
				hmData = protocol.DelPrintMst(rcvDataBuf);
				dataMsg = dao.DelPrintMst(
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData,
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0,2),99);
				dataMsg = dataMsg.substring(2);
				break;
			case 73://가격표 스캔
				df.execute("IQ_PRINT_REQ");// 2014-12-31 가격표 슼캔 INSERT
				hmData = protocol.setPrintMst(rcvDataBuf);
				dataMsg = dao.insPrintMst(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData,df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0,2),99);
				dataMsg = dataMsg.substring(2);
				break;
			case 74:
				df.execute("(YS)IQ_STAND_PLU_INFO_REQ"); //2014-12-31 진열대 전일발주수량
				/* 코드 추가 */
				hmData = protocol.getStandPluInfo(rcvDataBuf);
				dataMsg = dao.selStandPluInfo2( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				
				break;
			case 75: //점포 스캔발주 정보 요청 [ 전일발주수량 ] --0401 수정해야함
				df.execute("IQ_SCAN_ORDER_REQ");
				hmData = protocol.getScanPluInfo(rcvDataBuf);
				dataMsg = dao.selScanPluInfo2(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 76: //점포PDA버전체크
				df.execute("IQ_PDAVERSION");
				hmData = protocol.getPDAVersion(rcvDataBuf);
				dataMsg = dao.insPDAVersion(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 77: //점포 현금판매시 상품판매 가능여부 요청
				df.execute("IQ_SALECHK");
				hmData = protocol.getSaleChk(rcvDataBuf);
				dataMsg = dao.selSaleChk(
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						(String)hmData.get("PLU_CD").toString(),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0,2),99);
				dataMsg = dataMsg.substring(2);
				break;
			case 78: //점포 현금판매시 위해상품 여부 요청
				df.execute("IQ_NOXMSR");
				hmData = protocol.getNoxChk(rcvDataBuf);
				dataMsg = dao.selNoxChk((String)hmData.get("PLU_CD").toString(), hmData, df); 
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0,2),99);
				dataMsg = dataMsg.substring(2);
				break;
			case 80: //점포발주-스캔방식 상품정보 요청
				df.execute("IQ_SCAN_ORDER_REQ_old2");
				hmData = protocol.getScanPluInfo(rcvDataBuf);
				dataMsg = dao.selScanPluInfo(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 81: //(구)점포발주-스캔방식 상품정보 수정 요청
				df.execute("(Old)IQ_SCAN_ORDER_UPDATE_REQ");
				hmData = protocol.getOldScanPluUpdate(rcvDataBuf, df);
				dataMsg = dao.setOldScanPluUpdate(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 82: //점포발주-진열대 진열대 정보 요청
				df.execute("IQ_STAND_REQ");
				hmData = protocol.getStandInfo(rcvDataBuf);
				dataMsg = dao.selStandInfo(
						(String)hmCommon.get("COM_CD"),
						// (String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break; 
			case 83: //점포발주-진열대 진열대 상품 정보 요청
				df.execute("IQ_STAND_ORDER_REQ");				
				hmData = protocol.getStandPluInfo(rcvDataBuf);
				dataMsg = dao.selStandPluInfo( 
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 84: //(구)점포발주-진열대 진열대 상품 정보 수정 요청
				df.execute("(Old)IQ_STAND_UPDATE_REQ");
				hmData = protocol.getOldStandPluUpdate(rcvDataBuf, df);
				dataMsg = dao.setOldStandPluUpdate(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 85: // Incom : GetIncomInfo 입고상품 정보
				df.execute("IQ_INCOM2_ITEM_REQ");
				hmData = protocol.getIncomInfo(rcvDataBuf);
				dataMsg = dao.selIncomInfo(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				//df.CommLogger("▶ dataMsg : " + dataMsg);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				//df.CommLogger("▶ ERROR_CD : " + ret);
				dataMsg = dataMsg.substring(2);
				break;
			case 86: // Incom : SetIncomUpdate 입고상품  정보 수정
				df.execute("IQ_INCOM2_UPDATE_REQ");
				hmData = protocol.getIncomInfoUpdate(rcvDataBuf);
				dataMsg = dao.setIncomUpdate(
							(String)hmCommon.get("COM_CD"),
							(String)hmCommon.get("STORE_CD").toString().substring(2),
							hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;	
			case 87: // Inventory : GetInventoryAdjustment 상품재고정보
				df.execute("IQ_INV_AD_REQ");
				hmData = protocol.getInventoryAdjustment(rcvDataBuf);
				dataMsg = dao.selInventoryAdjustment(
							(String)hmCommon.get("COM_CD"),
							(String)hmCommon.get("STORE_CD").toString().substring(2),
							hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 88: // Inventory : SetInventoryUpdate 상품재고조정 수정
				df.execute("IQ_INV_UPDATE_REQ");
				hmData = protocol.getInventoryUpdate(rcvDataBuf, df);
				dataMsg = dao.setInventoryUpdate(
							(String)hmCommon.get("COM_CD"),
							(String)hmCommon.get("STORE_CD").toString().substring(2),
							hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 89: // Close Order Time : 발주가능 시간, 금액 조회
				df.execute("IQ_CLOSE_ORDER_TIME_REQ");
				hmData = protocol.getCloseOrderTime(rcvDataBuf);
				dataMsg = dao.getCloseOrderTime(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
			case 90://재고조정 이력조회 I.G
				df.execute("IQ_STOCK_CHG_REQ");
				hmData = protocol.getStockChgReq(rcvDataBuf);
				dataMsg = dao.getStoreStockChgList(
							(String)hmCommon.get("COM_CD"),
							(String)hmCommon.get("STORE_CD").toString().substring(2),
							hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 91: //점포발주-분류별 : 대분류 정보 요청
				df.execute("IQ_STAND_REQ2");
				hmData = protocol.getStandInfo2(rcvDataBuf);
				dataMsg = dao.selStandInfo2(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, 
						df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 92: // Inventory : GetInventoryAdjustment 상품재고정보 I.G (87 -> 92)
				df.execute("IQ_INV_AD_REQ2");
				hmData = protocol.getInventoryAdjustment(rcvDataBuf);
				dataMsg = dao.selInventoryAdjustment2(
							(String)hmCommon.get("COM_CD"),
							(String)hmCommon.get("STORE_CD").toString().substring(2),
							hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;	
			case 93: // Inventory : SetInventoryUpdate 상품재고조정 수정 I.G (88 -> 93)
				df.execute("IQ_INV_UPDATE_REQ2");
				hmData = protocol.getInventoryUpdate(rcvDataBuf, df);
				dataMsg = dao.setInventoryUpdate2(
							(String)hmCommon.get("COM_CD"),
							(String)hmCommon.get("STORE_CD").toString().substring(2),
							hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 94://재고조정 이력조회 I.G (90 -> 94)
				df.execute("IQ_STOCK_CHG_REQ2");
				hmData = protocol.getStockChgReq(rcvDataBuf);
				dataMsg = dao.getStoreStockChgList2(
							(String)hmCommon.get("COM_CD"),
							(String)hmCommon.get("STORE_CD").toString().substring(2),
							hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			case 95: // 점포 현금판매시 상품판매 가능여부 요청 : PLU(바코드) 체크추가 I.G (77 -> 95)
				df.execute("IQ_SALECHK2");
				hmData = protocol.getSaleChk(rcvDataBuf);
				dataMsg = dao.selSaleChk2(
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						(String)hmData.get("PLU_CD").toString(),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0,2),99);
				dataMsg = dataMsg.substring(2);
				break;
			case 96://점포발주-발주제외 조회요청 : PLU(바코드) 체크추가  I.G (38->96)
				df.execute("IQ_EXCEPT_SEARCH_REQ2");
				hmData = protocol.getStoreITMINFO(rcvDataBuf);
				dataMsg = dao.getStoreEXCEPTINFOS2(hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0,2),99);
				dataMsg = dataMsg.substring(2);
				break;
			case 97://발주금액이 최대로 떨어지는값 -50000 프로세스변경 MAX_ORDER_AMT 값이 발주가능최대금액 //leeseungho 180719
				df.execute("IQ_MAX_ORDER_AMT_REQ");
				hmData = protocol.getMaxOrderAmt(rcvDataBuf);
				
				dataMsg = dao.setMaxOrderAmt(hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);				
				dataMsg = dataMsg.substring(2);			
				break;	
			case 98: // Incom : GetIncomInfo 통합전표기준 입고상품 정보 //leeseungho 180719
				df.execute("IQ_INCOM2_ITEM_REQ98");
				hmData = protocol.getIncomInfo(rcvDataBuf);
				dataMsg = dao.selIncomInfo98(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				//df.CommLogger("▶ dataMsg : " + dataMsg);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				//df.CommLogger("▶ ERROR_CD : " + ret);
				dataMsg = dataMsg.substring(2);
				break;	
			case 99: // Incom : SetIncomUpdate99 입고검수 입고상품  정보 수정
				df.execute("IQ_INCOM2_UPDATE_REQ99");
				hmData = protocol.getIncomInfoUpdate(rcvDataBuf);
				dataMsg = dao.setIncomUpdate99(
							(String)hmCommon.get("COM_CD"),
							(String)hmCommon.get("STORE_CD").toString().substring(2),
							hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;	
			case 2063: // A0 : 입고검수 검수상품 PLU 를 받아  낱개 PLU 와 입수 수량 을 리턴 
				df.execute("IQ_INCOM2_UPDATE_REQA0");
				hmData = protocol.getIncomInfoA0(rcvDataBuf);
				dataMsg = dao.selIncomInfoA0(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;	
			case 2064: // A1 : 2064 유통기한관리 상품조회 leeseungho 
				df.execute("IQ_EXPIRY_DATE_REQA1");
				hmData = protocol.getExpiryDateInfoA1(rcvDataBuf);
				dataMsg = dao.selExpiryDateInfoA1(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				df.CommLogger("▶ dataMsg : [" + dataMsg+"]");
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				//df.CommLogger("▶ ERROR_CD : " + ret);
				dataMsg = dataMsg.substring(2);
				break;
			case 2065: // A2 : 2065 유통기한 관리 유통기한 조회 leeseungho 180719
				df.execute("IQ_DUE_DATE_REQ_A2");
				hmData = protocol.getExpiryDateInfoA2(rcvDataBuf);
				dataMsg = dao.selExpiryDateInfoA2(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				//df.CommLogger("▶ dataMsg : " + dataMsg);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				//df.CommLogger("▶ ERROR_CD : " + ret);
				dataMsg = dataMsg.substring(2);
				break;				
			case 2066: // A3 : 2066 유통기한 관리 유통기한 저장및, 삭제 처리 leeseungho 180719
				df.execute("IQ_DUE_DATE_UPD_REQ_A3");
				hmData = protocol.getExpiryDateMegA3(rcvDataBuf);
				dataMsg = dao.updExpiryDateInfoA3(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				//df.CommLogger("▶ dataMsg : " + dataMsg);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				//df.CommLogger("▶ ERROR_CD : " + ret);
				dataMsg = dataMsg.substring(2);
				break;					
			case 2067: // A4 : 2067 입수 추가 Incom : GetIncomInfo 통합전표기준 입고상품 정보 //leeseungho 180719			
				df.execute("IQ_INCOM2_ITEM_REQA4");
				hmData = protocol.getIncomInfo(rcvDataBuf);
				dataMsg = dao.selIncomInfoA4(
						(String)hmCommon.get("COM_CD"),
						(String)hmCommon.get("STORE_CD").toString().substring(2),
						hmData, df);
				//df.CommLogger("▶ dataMsg : " + dataMsg);
				ret = COMMBiz_PDA.toInteger(dataMsg.substring(0, 2), 99);
				//df.CommLogger("▶ ERROR_CD : " + ret);
				dataMsg = dataMsg.substring(2);
				break;
			}
	
		} catch(Exception e) {
			ret = 20;
			retValue = "[ERROR]1:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}
		
		try {
			//df.CommLogger("--- makeSendData_PDA:(" + dataMsg.getBytes().length + ")" + dataMsg);
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz_PDA.makeSendData_PDA(hmCommon, dataMsg.getBytes().length, ret);
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(sendMsg + dataMsg)) {
				df.CommLogger("▶ 2: SEND DATA: [" + sendMsg + dataMsg + "]/"
						+ sendMsg.getBytes().length);
			} else {
				df.CommLogger("▶ [ERROR]3: " + sendMsg + " ==>LEN: "
						+ sendMsg.getBytes().length);
			}
		} catch (Exception e) {
			retValue = "[ERROR]2" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		} finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("SYSINQ", retValue);
		}
	}
}
