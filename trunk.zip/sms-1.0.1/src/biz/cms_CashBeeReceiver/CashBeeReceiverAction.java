package biz.cms_CashBeeReceiver;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;

import biz.cms_CashBeeSender.CashBeeSenderProtocol;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.util.StringUtil;

/**
 * Receive data from SC through 9013 PORT(SC로부터 데이타를 9013 PORT로 받음).
 * 
 * @param ActionSocket
 * @return
 * @throws Exception
 */
public class CashBeeReceiverAction extends ServerAction {
	private static Logger logger = Logger.getLogger(CashBeeReceiverAction.class);
	
	public static void main(String args[]) throws Exception {
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "cashbee";
			CashBeeReceiverInst inst = new CashBeeReceiverInst(destPath);
			
			inst.start();
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(ActionSocket actionSocket) throws Exception {
		int iTotSeqNo = 0;
		boolean bIsStarted = false;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
		String destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "cashbee";
		String fileNM = "";
		File file = null;
		long fileSZ = 0;
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		CashBeeReceiverProtocol protocol = new CashBeeReceiverProtocol();
		
		String bufferedStr[] = new String[100];
		StringBuffer checkSB = new StringBuffer();
		StringBuffer totData = new StringBuffer();
		
//		COMMLog df = new COMMLog();
		try {
			//while( true ) {
			do {
//				logger.info(" >>>>>>>>>>>> ready to receive ...");
//				// Set Work Start Time(업무시작시간설정)
//				df.setStartTime();
//				df.setConnectionInfo(actionSocket.getSocket().getInetAddress()
//						.getHostAddress().toString(),
//						String.valueOf(actionSocket.getSocket().getPort()), logger,
//						"CashBeeReceiver");
				
				// Data received from SC(SC로부터 받은 데이타)
				//try {
					rcvBuf = ((String) actionSocket.receive());
				//}catch(Exception e) {
				//	Thread.sleep(10000L);
				//	break;
				//}
				
				if( rcvBuf.length() < COMMBiz.CASHBEE_CM_LENS ) {
					Thread.sleep(100);
					return;
				}
				
				logger.info("[cashbee>sms] RECV[" + rcvBuf.getBytes().length + "]:[JOB_CODE:" + rcvBuf.substring(11, 15) + "]:[" + rcvBuf + "]");
				
				hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CASHBEE_CM_HEADER);
	
				rcvDataBuf = rcvBuf.substring(COMMBiz.CASHBEE_CM_LENS);
				//inq_type = Integer.parseInt((String)hmCommon.get("TLGM_CD"));
				
				if( ((String)hmCommon.get("TLGM_CD")).equals("0600") ) {		// 업무개시 요청(001), 파일송신 완료 요청(002/003), 업무 종료 요청(004)
					hmData = protocol.getReceiver0600(rcvDataBuf);

					if( ((String)hmData.get("MANAGE_INFO")).equals("001") ) {		// 업무개시 요청
						if( !bIsStarted ) {
							bIsStarted = true;
							hmCommon.put("RES_CD", "000");
						}else {
							hmCommon.put("RES_CD", "999");
						}
					}else if( ((String)hmData.get("MANAGE_INFO")).equals("002") ) {	// 파일송신 완료 and 다음 전송파일 존재
					}else if( ((String)hmData.get("MANAGE_INFO")).equals("003") ) {	// 파일송신 완료 and 다음 전송파일 없음
						CashBeeReceiverInst inst = new CashBeeReceiverInst(destPath);
						inst.start();
					}
					
					hmCommon.put("TLGM_CD", "0610");
					hmCommon.put("SNDRCV_FG", "E");
					hmData.put("TRANS_TIME", (new SimpleDateFormat("yyMMddhhmm")).format(new Date()));
					hmData.put("SENDER_NM", "WITHME");
					hmData.put("SENDER_PW", "withme");
					
					dataMsg = makeSendData0610(hmData);

					// Make Response Message Data(응답 전문데이타 만들기)
					sendMsg = COMMBiz.makeCashBeeSendData(hmCommon, dataMsg.getBytes().length + 16);
					logger.info("[sms>cashbee] SEND[" + (sendMsg + dataMsg).getBytes().length + "]:[JOB_CODE:0610]:[" + (sendMsg + dataMsg) + "]");
					
					// Send Response Data(응답 데이타 전송)
					if (actionSocket.send(sendMsg + dataMsg)) {
						logger.info("[sms>cashbee] SEND[" + (sendMsg + dataMsg).getBytes().length + "] OK");
					} else {
						logger.info("▶ [ERROR] Data(0610) send error!");
						Thread.sleep(500);
						break;
					}
					
					if( ((String)hmData.get("MANAGE_INFO")).equals("004") ) {	// 업무종료 요청
						bIsStarted = false;
//						inst.start();
						Thread.sleep(500);
						break;
					}
				}else if( ((String)hmCommon.get("TLGM_CD")).equals("0630") ) {	// 파일정보 수신 요청
					// 업무 개시 요청이 이루어 졌다면...
					if( bIsStarted ) {
						hmData = protocol.getReceiver0630(rcvDataBuf);
						fileNM = ((String)hmData.get("FILE_NAME")).trim();
						fileSZ = Long.parseLong((String)hmData.get("FILE_SIZE"));
						
						//String backupPath = destPath + File.separator + "backup";
						//File backupFile = new File(backupPath + File.separator + fileNM);
						file = new File(destPath + File.separator + fileNM);
						long rcvFileSZ = 0;
						
						initStringBuffer(checkSB);
						
						HashMap<String, Integer> hmTemp = new HashMap<String, Integer>();
						
						if( file.exists() ) {	// 파일이 존재하면
							rcvFileSZ = file.length();
							
							if( rcvFileSZ < fileSZ ) {	// 파일 이어받기
								hmCommon.put("RES_CD", "000");
								hmData.put("FILE_SIZE", String.format("%012d", rcvFileSZ));
								hmTemp = this.getBLCKSEQ(rcvFileSZ);
								for(int i = 0;i < ((int)hmTemp.get("SEQUENCE") - 1);i++ ) {
									checkSB.setCharAt(i, '1');
									iTotSeqNo++;
								}
								for( int i = 0;i < 100;i++ ) {
									bufferedStr[i] = "";
								}
							}else {						// 파일 기수신 완료
								hmCommon.put("RES_CD", "630");
								hmData.put("FILE_SIZE", String.format("%012d", rcvFileSZ));
							}
						}else {					// 파일이 존재하지 않으면 최초 수신
							rcvFileSZ = 0;
							hmCommon.put("RES_CD", "000");
							hmData.put("FILE_SIZE", String.format("%012d", rcvFileSZ));
							
//							initStringBuffer(checkSB);
						}
						hmCommon.put("TLGM_CD", "0640");
						hmCommon.put("SNDRCV_FG", "E");
						dataMsg = makeSendData0640(hmData);
					}else {
						hmData = protocol.getReceiver0630(rcvDataBuf);
						hmCommon.put("TLGM_CD", "0640");
						hmCommon.put("RES_CD", "999");
						dataMsg = makeSendData0640(hmData);
					}
					
					// Make Response Message Data(응답 전문데이타 만들기)
					sendMsg = COMMBiz.makeCashBeeSendData(hmCommon, dataMsg.getBytes().length + 16);
					logger.info("[sms>cashbee] SEND[" + (sendMsg + dataMsg).getBytes().length + "]:[JOB_CODE:0640]:[" + (sendMsg + dataMsg) + "]");
					
					// Send Response Data(응답 데이타 전송)
					if (actionSocket.send(sendMsg + dataMsg)) {
						logger.info("[sms>cashbee] SEND[" + (sendMsg + dataMsg).getBytes().length + "] OK");
					} else {
						logger.info("▶ [ERROR] Data(0640) send error!");
						Thread.sleep(500);
						break;
					}
				}else if( ((String)hmCommon.get("TLGM_CD")).equals("0310") || ((String)hmCommon.get("TLGM_CD")).equals("0320") ) {
					// 업무 개시 요청이 이루어 졌다면
					if( bIsStarted && file != null ) {
						hmData = protocol.getReceiver0320(rcvDataBuf);
						bufferedStr[Integer.parseInt((String)hmData.get("SEQUENCE_NO")) - 1] = (String)hmData.get("DATA");
						checkSB.setCharAt(Integer.parseInt((String)hmData.get("SEQUENCE_NO")) - 1, '1');
						iTotSeqNo++;
						continue;
					}else {
						logger.info("▶ [ERROR] Data(0310/0320) recv error!");
						Thread.sleep(500);
						break;
					}
				}else if( ((String)hmCommon.get("TLGM_CD")).equals("0620") ) {	// 결번 확인 요청
					int totalOutNo = 0;
					
					hmData = protocol.getReceiver0620(rcvDataBuf);
				
					for(int i = 0;i < iTotSeqNo;i++ ) {
						if( checkSB.charAt(i) == '0' ) {
							totalOutNo++;
						}
					}
					
					hmCommon.put("TLGM_CD", "0300");
					hmCommon.put("SNDRCV_FG", "E");
					hmCommon.put("RES_CD", "000");
					hmData.put("OUT_NUMBER", String.format("%03d", totalOutNo));
					hmData.put("CHECK_OUT", (checkSB.toString()).substring(0, iTotSeqNo));
					
					dataMsg = makeSendData0300(hmData);
					if( totalOutNo == 0 ) {
						for( int i = 0;i < iTotSeqNo;i++ ) {
							if( bufferedStr[i] != null && bufferedStr[i].length() > 0 ) {
								totData.append(bufferedStr[i]);
							}
						}
						
						File destDir = new File(destPath);
						
						if( !destDir.exists() ) {
							destDir.mkdir();
						}
						
						iTotSeqNo = 0;
						OutputStream out = new FileOutputStream(file, true);
						out.write((totData.toString()).getBytes());	// 파일에 이어서 쓰기
						out.flush();
						out.close();
						
						totData.delete(0, totData.length());
						initStringBuffer(checkSB);
						for( int i = 0;i < 100;i++ ) {
							bufferedStr[i] = "";
						}
					}
					// Make Response Message Data(응답 전문데이타 만들기)
					sendMsg = COMMBiz.makeCashBeeSendData(hmCommon, dataMsg.getBytes().length + 16);
					logger.info("[sms>cashbee] SEND[" + (sendMsg + dataMsg).getBytes().length + "]:[JOB_CODE:0300]:[" + (sendMsg + dataMsg) + "]");
					
					// Send Response Data(응답 데이타 전송)
					if (actionSocket.send(sendMsg + dataMsg)) {
						logger.info("[sms>cashbee] SEND[" + (sendMsg + dataMsg).getBytes().length + "] OK");
					} else {
						logger.info("▶ [ERROR] Data(0300) send error!");
						Thread.sleep(500);
						break;
					}
				}else {
					Thread.sleep(500);
					throw new Exception("Unknown TLGM_CD value.");
				}
				
				Thread.sleep(500);
			}//end of while
			while( bIsStarted );
		}catch(Exception e) {
			retValue = "[ERROR] " + e.getMessage();
			logger.info("▶ " + retValue);
		}
	}
	
	private void initStringBuffer(StringBuffer sb) {
		for(int i = 0;i < 100;i++) {
			sb.append('0');
		}
	}
	
	private String makeSendData0610(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {24,10,3,20,16};
		String strHeaders[] = {
			"FILE_NAME",
			"TRANS_TIME",
			"MANAGE_INFO",
			"SENDER_NM",
			"SENDER_PW"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			df.CommLogger(" >>>>>>>>> " + strHeaders[i].toString() + " = " + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendData0640(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {24,12,4};
		String strHeaders[] = {
			"FILE_NAME",
			"FILE_SIZE",
			"TLGM_BYTE_NUM"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendData0300(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {24,4,3,3};
		String strHeaders[] = {
			"FILE_NAME",
			"BLOCK_NO",
			"SEQUENCE_NO",
			"OUT_NUMBER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			df.CommLogger(" >>>>>>>>> " + strHeaders[i].toString() + " = " + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		StringUtil.appendSpace(sb, (String)hm.get("CHECK_OUT"), ((String)hm.get("CHECK_OUT")).length());
		
		return sb.toString();
	}
	
	private HashMap<String, Integer> getBLCKSEQ(long fileSize) {
		int block = 0;
		int sequence = 0;
		HashMap<String, Integer> hm = new HashMap<String, Integer>();
		//int temp1 = (int)(fileSize / (long)(TMoneyReceiverProtocol.LENGTH_BY_RECORD));
		//int temp2 = (int)(TMoneySenderProtocol.LENGTH_BY_SEQUENCE / TMoneyReceiverProtocol.LENGTH_BY_RECORD);
		int quotient = (int)(fileSize / (long)(CashBeeSenderProtocol.LENGTH_BY_SEQUENCE));
		int rest = (int)(fileSize % (long)(CashBeeSenderProtocol.LENGTH_BY_SEQUENCE));
		//int quotient = temp1 / temp2;
		//int rest = temp1 % temp2;
		
		sequence = quotient;
		
		if( rest > 0 ) {
			sequence++;
		}
		
		block = sequence / 100;
		sequence = sequence % 100;
		
		if( sequence > 0 ) {
			block++;
		}else if( sequence == 0 ) {
			sequence = 100;
		}
		block = (block == 0 ? 1 : block);
		
		// 여기까지 구해진 sequence가 마지막 받은 sequence 이므로 요청할 데이터는 한 시퀀스 앞이다.
		sequence = (sequence + 1) % 100;
		block = block + ((sequence + 1) / 100);

		hm.put("BLOCK", block);
		hm.put("SEQUENCE", sequence);
		
		return hm;
	}
}