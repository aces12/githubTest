package biz.cms_CashBeeReceiver;

import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.daemon.net.filter.Filter;


public class CashBeeReceiverSocketFilter implements Filter {
	private static Logger logger = Logger.getLogger(CashBeeReceiverAction.class);
	
	public Object receive(InputStream in) throws Exception {
		StringBuilder ret = new StringBuilder();
		String getData = "";
		int readLen = 0;
		
		try {
			byte[] buffer = new byte[4];
			if( (readLen=in.read(buffer)) < 4 ) return "ERROR";
			
			//byte[] byteLength = readData(in, 4);
			//String strLength = new String(byteLength);
			//ret.append(strLength);
			String strLength = new String(buffer);
			ret.append(strLength);
				
			int len = Integer.parseInt(strLength);
			byte[] data = readData(in, len);
			ret.append(new String(data));
			
			if (ret.length()>0){
				getData=(String)ret.toString();
			}
		}catch(Exception e) {
//			throw e;
//			logger.error("[ERROR]:receive error:: " + e.getMessage());
//			logger.error("[ERROR]:receive data:: " + (String)ret.toString());
		}
		
		return getData;
	}
	
	public boolean send(OutputStream out, Object obj) throws Exception {
		PrintWriter pw = null;
		boolean ok = false;
		
		try {
			if( pw == null ) {
				pw = new PrintWriter(out);
			}
			pw.write((String)obj);
			pw.flush();
			if (!pw.checkError()) ok = true;
			else {
				throw new Exception("java.net.SocketException: " +
						"Connection reset by peer: socket write error");
			}
		}catch (Exception e) {
			throw e;
		}
		
		return ok;
	}
	
	public void close() {
		
	}
	
	public byte[] readData(InputStream in, int len) throws Exception {
		int bcount = 0, n = 0;
		byte buf[] = new byte[len];
		
		while (true) {
			n = in.read(buf, bcount, len - bcount);
			
			bcount += n;
			
			if( bcount == len ) {
				break;
			}
		}

		return buf;
	}

	public Object receive(InputStream arg0, int arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public Object receive(InputStream arg0, int arg1, int arg2)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean send(OutputStream out, int len, Object obj)
			throws Exception {
		// TODO Auto-generated method stub
		DataOutputStream dOut = null;
		boolean ok = false;
		
		try {
			if( dOut == null ) {
				dOut = new DataOutputStream(out);
				
				if( len > 0 ) {
					dOut.write((byte[])obj, 0, len);
					dOut.flush();
					ok = true;
				}
			}
		}catch(Exception e) {
			throw e;
		}
		
		return ok;
	}

	public boolean send(OutputStream arg0, int arg1, int arg2, Object arg3)
			throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
}