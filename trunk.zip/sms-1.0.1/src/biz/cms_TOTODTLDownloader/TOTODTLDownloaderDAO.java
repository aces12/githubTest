package biz.cms_TOTODTLDownloader;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class TOTODTLDownloaderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(TOTODTLDownloaderPollingAction.class);
	
	public int spSMSSEND(String strMsg, String strSender) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("sysinq-sql", "PR_SMSSEND"));
			sql.setString(++i, strMsg);
			sql.setString(++i, strSender);
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int insTOTORslt(int type, HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			i = 0;
			sql.put(findQuery("service-sql", "SEL_TOTOORGCD"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("FCSTR_ID"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
			
			list = executeQuery(sql);
			sql.close();
			
			if( list.size() > 0 ) map = (Map<String, String>)list.get(0);
			else map.put("ORG_CD", "N/A");
			
			i = 0;
			sql.clearParameter();			
			if( type == 0 ) {
				sql.put(findQuery("service-sql", "INS_TOTOSALE"));
				sql.setString(++i, (String)hm.get("CO_CD"));
				sql.setString(++i, (String)hm.get("ADJT_DT"));
				sql.setString(++i, (String)hm.get("GAME_TP"));
				sql.setString(++i, (String)hm.get("GAME_YYYY"));
				sql.setString(++i, (String)hm.get("GAME_NTH"));
				sql.setString(++i, (String)hm.get("FCSTR_ID"));
				sql.setString(++i, (String)map.get("ORG_CD"));
				sql.setString(++i, (String)hm.get("BRANCH_CD"));
				sql.setString(++i, (String)hm.get("WORK_TP"));
				sql.setString(++i, (String)hm.get("PAY_TP"));
				sql.setString(++i, (String)hm.get("PUBER_CD"));
				sql.setString(++i, (String)hm.get("WORK_YMDHMS"));
				sql.setString(++i, (String)hm.get("AMT_1"));
				sql.setString(++i, (String)hm.get("AMT_2"));
			}else if( type == 1 ) {
				sql.put(findQuery("service-sql", "INS_TOTOCNCL"));
				sql.setString(++i, (String)hm.get("CO_CD"));
				sql.setString(++i, (String)hm.get("ADJT_DT"));
				sql.setString(++i, (String)hm.get("GAME_TP"));
				sql.setString(++i, (String)hm.get("GAME_YYYY"));
				sql.setString(++i, (String)hm.get("GAME_NTH"));
				sql.setString(++i, (String)hm.get("FCSTR_ID"));
				sql.setString(++i, (String)map.get("ORG_CD"));
				sql.setString(++i, (String)hm.get("BRANCH_CD"));
				sql.setString(++i, (String)hm.get("WORK_TP"));
				sql.setString(++i, (String)hm.get("PAY_TP"));
				sql.setString(++i, (String)hm.get("PUBER_CD"));
				sql.setString(++i, (String)hm.get("WORK_YMDHMS"));
				sql.setString(++i, (String)hm.get("AMT_1"));
				sql.setString(++i, (String)hm.get("AMT_2"));
				sql.setString(++i, (String)hm.get("ORGDEAL_YMDHMS"));
			}
			
//			logger.info("SQL=" + sql.debug());
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
}
