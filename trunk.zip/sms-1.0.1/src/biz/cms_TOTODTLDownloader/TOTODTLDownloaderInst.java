package biz.cms_TOTODTLDownloader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;



public class TOTODTLDownloaderInst extends Thread {
	private static Logger logger = Logger.getLogger(TOTODTLDownloaderPollingAction.class);
	
	String path = "";
	TOTODTLDownloaderPollingAction action = null;
	
	private final int LENGTH_BY_RSLT_RECORD = 260;
	
	public TOTODTLDownloaderInst(String path, TOTODTLDownloaderPollingAction action) {
		this.path = path;
		this.action = action;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
	public void deleteFile(String path, String fileNM) {
		File file = new File(path + File.separator + fileNM);
		if( file.exists() ) {
			logger.info("File Name : " + path + File.separator + fileNM);
			if( file.delete() ) {
				logger.info("File(" + path + File.separator + fileNM + ") removed !!!");
			}
		}
	}
	
	public void copyFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdirs();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(orgFile);
			fos = new FileOutputStream(destFile);
			
			int data = 0;
			while( (data = fis.read()) != -1 ) {
				fos.write(data);
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			try {
				fis.close();
				fis = null;
				fos.flush();
				fos.close();
				fos = null;
				System.gc();
			}catch(Exception e) {
				logger.info(e.getMessage());
			}
		}
		
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public void run() {
		try {
			List<File> list = getDirFileList(path);
			
			for(int i = 0;i < list.size();i++) {
				if( !(list.get(i)).isFile() ) {
					continue;
				}else if( (list.get(i)).length() == 0 ){
					continue;
				}
				String targetFile = list.get(i).getName();
				
				logger.info("file:" + targetFile);
				
				// 발매/환급/환불/취소 정보 파일일 경우에만 get file.
				if( (targetFile.substring(0, 4)).equals(action.TOTSELL_CD) && (targetFile.length() == 17 || targetFile.length() == 22) ) {
					int len = 0;
					int totLen = 0;
					String adjtDT = targetFile.substring(5, 13);
					
					long fileSize = (list.get(i)).length();
					
					byte buf[] = new byte[(int)fileSize];
					InputStream is = new FileInputStream(list.get(i));
					
					StringBuffer sb = new StringBuffer();
					
					while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
						sb.append(new String(buf));
						totLen += len;
						if( totLen == fileSize ) {
							break;
						}
					}
					
					is.close();
//					logger.info("DATA=["+sb.toString()+"]");
					if( targetFile.length() == 17 ) { 		// 발매/환급/환불 정보 파일
						this.insertDB(0, sb.toString(), adjtDT);
					}else if( targetFile.length() == 22 ) {	// 취소 정보 파일
						this.insertDB(1, sb.toString(), adjtDT);
					}
				}
				
				// 파일 옮기기...
				this.moveFile(path, targetFile, path + File.separator + "backup");
				logger.info("[DEBUG] File " + targetFile + " was moved.");
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertDB(int type, String readData, String adjtDT) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			TOTODTLDownloaderDAO dao = new TOTODTLDownloaderDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*LENGTH_BY_RSLT_RECORD, LENGTH_BY_RSLT_RECORD);

				totLen += LENGTH_BY_RSLT_RECORD;
				
				if( type == 0 ) hm = getTOTOSale(strRecord);
				else if( type == 1 ) hm = getTOTOCncl(strRecord);
				hm.put("CO_CD", com_cd);
				hm.put("ADJT_DT", adjtDT);
				
				try {
					dao.insTOTORslt(type, hm);
				}catch(Exception e) {
					logger.info("[ERROR] Error for inserting data : " + e.getMessage());
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private HashMap<String, String> getTOTOSale(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {3,4,4,5,3
					  ,2,2,5,14,15
					  ,15,186,2};
		String strHeaders[] = {
			"GAME_TP",
			"GAME_YYYY",
			"GAME_NTH",
			"FCSTR_ID",
			"BRANCH_CD",
			
			"WORK_TP",
			"PAY_TP",
			"PUBER_CD",
			"WORK_YMDHMS",
			"AMT_1",
			
			"AMT_2",
			"FILLER",
			"NLCHR"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getTOTOCncl(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {3,4,4,5,3
				  	  ,2,2,5,14,15
				  	  ,15,14,172,2};
		String strHeaders[] = {
			"GAME_TP",
			"GAME_YYYY",
			"GAME_NTH",
			"FCSTR_ID",
			"BRANCH_CD",
			
			"WORK_TP",
			"PAY_TP",
			"PUBER_CD",
			"WORK_YMDHMS",
			"AMT_1",
			
			"AMT_2",
			"ORGDEAL_YMDHMS",
			"FILLER",
			"NLCHR"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
}
