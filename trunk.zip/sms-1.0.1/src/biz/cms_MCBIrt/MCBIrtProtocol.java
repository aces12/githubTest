package biz.cms_MCBIrt;

import java.util.HashMap;
import java.util.regex.Pattern;

import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class MCBIrtProtocol {
	private static Logger logger = Logger.getLogger(MCBIrtAction.class);
// 0 수신 테이터 거래 종별 구분	
	public int getRcvMCBIrtDATA(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret = 0;
		int nlens[] = {2};
		
		String strHeaders[] = {
			"INQ_TYPE"		// INQ Type(INQ 종별)
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		ret = COMMBiz.getInqTypeCHG((String)hm.get("INQ_TYPE"));
		
		return ret;
	}
	
	

// 1. 잔액조회req IRT ( POS -> SERVER )
	public HashMap<String, String> getParseBalanceMCBInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 2,20,10,40,4
					   //,16 암호화로 인해
						,80
					   ,8,6,1,15,265
 					  };
		String strHeaders[] = {
  			"INQ_TYPE"  //F7 : 잔액조회
			, "STORECODE" // 사용처 코드
			, "SUBMEMBERCODE" // 사용처 점포코드
			, "SUBMEMBERNAME" // 사용처 점포명
			, "POSCODE"       // 사용처 pos코드
			
			, "PINSCRACHNO" //모바일 문화상품권 번호 
			, "REQUESTDATE" // 요청일자(YYYYMMDD)
			, "REQUESTTIME" // 요청시간(HHMMSS) 
			, "INPUTTYPE"   // 0 scan , 1 keyin
			, "MEMBERIP"    // 사용처 점포 POS IP
			, "FILLER"      // space
		};
		

		
//		logger.info( "▶ getParseBalanceMCBInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
//		for (int i = 0; i < nlens.length; i++) {
//			logger.info("★ getParseBalanceMCBInq  : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
//		}
		
		return hm;
	}
	
	
	
// 2. 잔액조회rcv IRT (  SERVER <- 문화진흥  ) : 수신이기 때문에 문화 진흥원용 구조 사용 : 복호화 이후에 사용
	public HashMap<String, String> getParseBalanceMCBRcv(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,4,7,20,10,40,4
						,4
						,16
						,9,9
						,8,6,60,199
					  };
		String strHeaders[] = {
			  "HEADNO"
			  ,"MASSGAELENGTH"
			  ,"MEMBERCODE"
			  ,"STORECODE"
			  ,"SUBMEMBERCODE"
			  ,"SUBMEMBERNAME"
			  ,"POSCODE"
			  
			  ,"RESULTCODE"
			  ,"PINSCRACHNO"
			  ,"PINFACEVALUE"
			  ,"PINBALANCE"
			  
			  ,"RESPONSEDATE"
			  ,"RESPONSETIME"
			  ,"ERRORMESSAGE"
			  ,"FILLER"
		};
		
//		logger.info( "▶ getParseBalanceMCBRcv-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}

// 3. 사용요청req IRT ( POS -> SERVER )
	public HashMap<String, String> getParseUseMCBInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 2,20,10,40,4
						//,16 암호화로 인해
						, 80
				        , 9,50,8,6
				        , 1,50,15,156
 						};
		String strHeaders[] = {
  			  "INQ_TYPE"  //F8 : 모바일문화상품권 사용 요청
			, "STORECODE" // 사용처 코드
			, "SUBMEMBERCODE" // 사용처 점포코드
			, "SUBMEMBERNAME" // 사용처 점포명
			, "POSCODE"       // 사용처 pos코드
			
			, "PINSCRACHNO" //모바일 문화상품권 번호
			, "REQUESTAMOUNT"
			, "MEMBERCONTROLCODE"
			, "REQUESTDATE"
			, "REQUESTTIME"
			
			, "INPUTTYPE"
			, "PRODUCTNAME"
			, "MEMBERIP"
			, "FILLER"      // SPACE
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
//		for (int i = 0; i < nlens.length; i++) {
//			logger.info("★ getParseBalanceMCBInq  : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
//		}
		
		return hm;
		
	}
	
	
// 4. 사용응답rcv IRT ( SERVER <- 문화진흥원 ): 복호화 이후에 사용
	public HashMap<String, String> getParseUseMCBRcv(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,4,7,20,10,40,4
					,	4,16,25,50,8,6
					,9,9,9,60,115
		               };
		String strHeaders[] = {
				"HEADNO"
				  ,"MASSGAELENGTH"
				  ,"MEMBERCODE"
				  ,"STORECODE"
				  ,"SUBMEMBERCODE"
				  ,"SUBMEMBERNAME"
				  ,"POSCODE"
				  
				  , "RESULTCODE"   // 응답코드 0000 정상 / XXXX ERROR CODE
				  , "PINSCRACHNO"  // 문화상품권 번호
					, "CONTROLCODE"  // 컬쳐랜드 거래번호
					, "MEMBERCONTROLCODE" // 사용처 거래번호
					, "RESPONSEDATE"  //사용일자
					, "RESPONSETIME" // 사용시간
					
					, "PINFACEVALUE" // 모바일문화상품권 금액(액면)
					, "LEVYAMOUNT"   // 모바일문화상품권 사용금액
					, "PINBALANCE"   // 모바일문화상품권 잔액
					, "ERRORMESSAGE" // 응답메시지
					, "FILLER"       // SPACE
		};
		
//		logger.info( "▶ getParseUseMCBRcv-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}



// 6. 취소요청req IRT ( POS -> SERVER)
	public HashMap<String, String> getParseCancelMCBInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 2,20,10,40,4
						, 2,80,25,50,50
						, 9,8,6,1,15
						,129
 						 };
		String strHeaders[] = {
  			"INQ_TYPE"  //F8 : 모바일문화상품권 사용 요청
			, "STORECODE" // 사용처 코드
			, "SUBMEMBERCODE" // 사용처 점포코드
			, "SUBMEMBERNAME" // 사용처 점포명
			, "POSCODE"       // 사용처 pos코드
			
			, "CANCLETYPE"
			, "PINSCRACHNO"
			, "CONTROLCODE"
			, "MEMBERCONTROLCODE"
			, "MEMBERCANCELCODE"
			
			, "CANCELAMOUNT"
			, "REQUESTDATE"
			, "REQUESTTIME"
			, "INPUTTYPE"
			, "MEMBERIP"
			
			, "FILLER"      // SPACE
		};
		
//		logger.info( "▶ getParseCancelMCBInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
//		for (int i = 0; i < nlens.length; i++) {
//			logger.info("★ getParseBalanceMCBInq  : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
//		}
		
		return hm;
	}

// 7. 취소응답rcv IRT (  SERVER <- 문화진흥원 ) : 복호화 이후에 사용
	public HashMap<String, String> getParseCancelMCBRcv(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,4,7,20,10,40,4
						,4,16,25,25,50
						,50,8,6
						,9,9,9,60,40
		               };
		
		String strHeaders[] = {
				  "HEADNO"
				  ,"MASSGAELENGTH"
				  ,"MEMBERCODE"
				  ,"STORECODE"
				  ,"SUBMEMBERCODE"
				  ,"SUBMEMBERNAME"
				  ,"POSCODE"
				  
				  ,"RESULTCODE"
				  ,"PINSCRACHNO"
				  , "CANCELCONTROLCODE"  // 컬쳐랜드 거래번호
				  , "CONTROLCODE"  // 컬쳐랜드 거래번호
				  , "MEMBERCONTROLCODE"

				  , "MEMBERCANCELCONTROL"
				  , "CANCELDATE"
				  , "CANCELTIME"
				  
				  , "PINFACEVALUE" // 모바일문화상품권 금액(액면)
				  , "CANCELAMOUNT"   // 모바일문화상품권 사용금액
				  , "PINBALANCE"   // 모바일문화상품권 잔액
				  ,"ERRORMESSAGE"
				  ,"FILLER"
			};
		
//		logger.info( "▶ getParseCancelMCBRcv-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
//		for (int i = 0; i < nlens.length; i++) {
//			logger.info("★ getParseCancelMCBRcv  : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
//		}
		
		return hm;
	}
}