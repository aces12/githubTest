package biz.cms_WineIrt;

import java.security.Key;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.net.Socket;
 
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.util.StringUtil;

import oracle.sql.DATE;

import org.apache.commons.net.util.Base64;
import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class WineIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(WineIrtAction.class);
	WineIrtDAO dao = new WineIrtDAO();
	WineIrtProtocol protocol = new WineIrtProtocol();
	
	/**
	 * Receive data from SC through 9034 PORT(SC로부터 데이타를 9034 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(ActionSocket actionSocket) throws Exception {
		// TODO Auto-generated method stub
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		StringBuffer sb = null;
		List<Object> list = null; 
		
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		
		WineIrtProtocol protocol = new WineIrtProtocol();
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			logger.info("[INFO] WineIrt::rcvBuf::[" + rcvBuf + "]"); 
			
			rcvBuf = ((String) actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			logger.info("[INFO] WineIrt::rcvBuf::[" + rcvBuf + "]");
			logger.info("[INFO] WineIrt::hmCommon::["+hmCommon+"]");
			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}

			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			logger.info("[INFO] WineIrt::rcvDataBuf::["+rcvDataBuf+"]");
			inq_type = COMMBiz.getInqTypeCHG(protocol.getRcvEConIrtDATA(rcvDataBuf));
			
			boolean bIsExtended = false;
			
			logger.info("[INFO] WineIrt::inq_type::["+inq_type+"]");
			switch(inq_type) {
			case 2255:	// G6 : 2255 와인
				
					logger.info("wine START");
					
					hmData = protocol.getParseWineReq(rcvDataBuf);
					
					//PT 직원 번호인지 조회 
					int sv_str_tp = 0;
					
					String store_cd = hmCommon.get("STORE_CD");
					String wine = hmData.get("WINE_CODE");
					list = null;
					list = dao.WindSearch(store_cd, wine);
					
					logger.info("[INFO]getPTPhoneNumber list.size()" + list.size());
					
				
					boolean chkValue = true;
					if( list.size() > 0 ) {
						for( int i = 0;i < list.size();i++ ) {
							Map<String, String> map = (Map<String, String>)list.get(i);
							ret = 00;
							hmData.put("RESP_CD", "0000");
							hmData.put("RESP_MSG", "정상");
							hmData.put("INQ_TYPE", "G6");
							hmData.put("USER_NM", map.get("NAME"));
							hmData.put("USER_PHONE", map.get("TEL_NO"));
							hmData.put("STATUS", map.get("STATUS"));
							hmData.put("SAL_YN", map.get("SAL_YN"));
							hmData.put("PLU_CNT", map.get("CNT"));
							hmData.put("PLU_MSG", map.get("MSG"));
							dataMsg = "00" + makeSendDataWineInfoRsp(hmData);
							logger.info("<----- G6 ----->"+dataMsg);
							chkValue = false;
						}						
					} 
					if(chkValue) {
						hmData.put("RESP_CD", "9999");
						hmData.put("RESP_MSG", "조회 불가");						
						dataMsg = "00" + makeSendDataWineInfoRsp(hmData);
						logger.info("<----- G6 ----->"+ dataMsg);
					}
					
				
				
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;				
				
				default:
					logger.info("[INFO] INQ Type Code::["+inq_type+"]::LEN::["+rcvBuf.length()+"]");
					ret = 99;
					break;
			}
		} catch (Exception e) {
			ret = 29; // 029=HOST APPL ERR
			retValue = "[ERROR]2:" + e.getMessage();
			logger.info("▶ " + retValue);
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			logger.info("dataMsg[" + dataMsg + "]");
			logger.info("sendMsg[" + sendMsg + "]");
					
			logger.info("================ 4-2) POS<-SMS 응답전문 ===================");
			logger.info("전문길이=[" + totalMsg.getBytes().length + "]");
			logger.info("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
			logger.info("전문내용=[" + totalMsg + "]");
			
			// Send Response Data (응답 데이타 전송)
			if (actionSocket.send(totalMsg)) {
				logger.info("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
			} else {
				logger.info("[pos<sms] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		} catch (Exception e) {
			retValue = "[ERROR]4" + e.getMessage();
			logger.info(retValue);
		} finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			logger.info("[INFO] EConIrtAction IRT FINISH.");
		}
	}
	

	private String makeSendDataWineInfoRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			 2, 20, 4, 20, 4
			,60, 1, 1, 2, 10
			,30,5,36
		};//74
		
		String strHeaders[] = {
			  "INQ_TYPE"			 // INQ Type(INQ 종별)
			, "USER_NM"
			, "USER_PHONE"
			, "RESP_CD"			 // 응답코드
			, "RESP_MSG"			  // 응답메시지
			, "STATUS"
			, "SAL_YN"
			, "PLU_CNT"
			, "PLU_MSG"
			, "FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
}



