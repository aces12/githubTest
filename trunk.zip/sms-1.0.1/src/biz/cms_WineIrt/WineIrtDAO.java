package biz.cms_WineIrt;


import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;

import org.apache.log4j.Logger;

import biz.comm.COMMLog;

public class WineIrtDAO extends GenericDAO {
	
	private static Logger logger = Logger.getLogger(WineIrtAction.class);
	
	
	public List<Object>  WindSearch(String str_code, String wine_code) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			connect("CMGNS"); //DB Connection(DB 접속)
			
			sql.put(findQuery("service-sql", "SEL_WINEINFO"));
			sql.setString(++i, str_code);
			sql.setString(++i, wine_code);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR] WineIrtDAO::getWineInfo::" + sql.debug());
			throw e;
		}
		
		return list;
	}

	
	
	
	
}