package biz.cms_HJParcelTran;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class HJParcelTranInst extends Thread {
	private static Logger logger = Logger.getLogger(HJParcelTranPollingAction.class);
	private final int LENGTH_BY_HD_RECORD = 73;
	private final int LENGTH_BY_RSLT_RECORD = 179;
	
	String path = "";
	String stdDate = "";
	
	public HJParcelTranInst(String path, String stdDate) {
		this.path = path;
		this.stdDate = stdDate;
	}
	
	public void run() {
		String fileNM = "";
		
		try {
			System.out.println(path);
			List<File> file = getDirFileList(path);
			logger.info(" >>>>>>>>>>>>>>>>>>> file cnt : " + Integer.toString(file.size()));
			System.out.println(" >>>>>>>>>>>>>>>>>>> file cnt : " + Integer.toString(file.size()));
			
			for(int i = 0;i < file.size();i++) {
				fileNM = file.get(i).getName();
				
				logger.info(" >>>>>>>>>>>>>>>>>>> file name : " + fileNM);
				System.out.println(" >>>>>>>>>>>>>>>>>>> file name : " + fileNM);
				
				int len = 0;
				int totLen = 0;
				String readLine = "";
				
				long fileSize = (file.get(i)).length();
				logger.info(" >>>>>>>>>>>>>>>>>>> fileSize : " + fileSize);
				System.out.println(" >>>>>>>>>>>>>>>>>>> fileSize : " + fileSize);
				
				byte buf[] = new byte[(int)fileSize];
				InputStream is = new FileInputStream(file.get(i));
				
				StringBuffer sb = new StringBuffer();
				
				while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
					sb.append(new String(buf));
					totLen += len;
					logger.info(" >>>>>>>>>>>>>>>>>>> fileSize : " + fileSize);
					System.out.println(" >>>>>>>>>>>>>>>>>>> fileSize : " + fileSize);
					if( totLen == fileSize ) {
						break;
					}
				}
				
				is.close();
				
				logger.info("info ::: "+fileNM.substring(0, 11));
				
				if( fileNM.substring(0, 11).equals("HANJIN.TRAN") ) { // 한진택배 접수/반품 대사파일
					logger.info("insert start");
					logger.info("info ::: "+sb.toString());
					System.out.println("info ::: "+sb.toString());
					this.insertDB(sb.toString());
				}
				
				// 파일 옮기기...
				moveFile(path, fileNM, path + File.separator + "backup");
				logger.info("[DEBUG] File " + fileNM + " processed successfuly.");
				System.out.println("[DEBUG] File " + fileNM + " processed successfuly.");
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
			System.out.println("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertDB(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			HJParcelTranDAO dao = new HJParcelTranDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String trans_date = "";
			
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			
			logger.info("insertDB ::: bytes.length ::: "+ bytes.length);
			
			for(int i = 0; totLen<bytes.length; i++) {
				String strRecord = "";
				
				if(i == 0){
					strRecord = new String(bytes, i*LENGTH_BY_HD_RECORD, LENGTH_BY_HD_RECORD);
					totLen += LENGTH_BY_HD_RECORD;
					logger.info("insertDB ::: strRecord ::: "+ strRecord);
//					System.out.println("insertDB ::: strRecord ::: "+ strRecord);
				}else{
					strRecord = new String(bytes, totLen, LENGTH_BY_RSLT_RECORD);
					totLen += LENGTH_BY_RSLT_RECORD;
					
					logger.info("insertDB ::: strRecord ::: "+ strRecord);
//					System.out.println("insertDB ::: strRecord ::: "+ strRecord);
					
					hm = getHJParcelTran_DTL(strRecord);
					
					if("PP".equals((String)hm.get("PAY_CON"))){
						hm.put("PAYMENT_TP", "01");
					}else if("CC".equals((String)hm.get("PAY_CON"))){
						hm.put("PAYMENT_TP", "02");
					}else if("CA".equals((String)hm.get("PAY_CON"))){
						hm.put("PAYMENT_TP", "03");
					}
					
					hm.put("CO_CD", com_cd);
					hm.put("ADJT_DT", stdDate);
					
					logger.info("insertDB ::: hm ::: "+ hm);
//					System.out.println("insertDB ::: hm ::: "+ hm);
					
					try {
						dao.insHJParcelTranRslt(hm);
						dao.updHJParcelRCVTRAN(com_cd, hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
						System.out.println("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
			System.out.println("[ERROR] " + e.getMessage());
		}
	}
	
	
	private HashMap<String, String> getHJParcelTran_DTL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {
			2, 6, 1, 21, 1,
			1, 15, 8, 5, 4,
			4, 2, 9, 9, 9,
			9, 2, 14, 15, 10,
			30, 1
		};
		String strHeaders[] = {
			"MSG_TYPE",
			"MSG_LEN",
			"DEAL_TYPE",
			"TRAN_ID",
			"ENP_DIV",
			
			"DLV_TYP",
			"WBL_NUM",
			"TRAN_YMD",
			"STORE_CD",
			"POS_NO",
			
			"TRAN_NO",
			"PAYMENT_TP",
			"TRN_FEE",
			"ETC_FEE",
			"EXT_FEE",
			
			"SAL_FEE",
			"PAY_CON",
			"RCV_DATETIME",
			"RSV_WBL",
			"CSR_NUM",
			
			"RTN_NUM",
			"RCV_TAG"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public void moveFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdir();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		logger.info("orgFile = " + orgPath + File.separator + fileNM);
		logger.info("destFile = " + destPath + File.separator + fileNM);
		
		if( destFile.exists() ) {
			if( orgFile.delete() ) {
				logger.info("[DEBUG] File(" + orgFile.getPath() + " / "+ orgFile.getName() + ") Deleted");
			}else {
				logger.info("[DEBUG] Fail to remove file(" + orgFile.getPath() + " / "+ orgFile.getName() + ")");
			}
		}else {
			for(int i = 0;i < 20;i++) {
				if( orgFile.renameTo(destFile) ) {
					logger.info(">> MOVE OK : " + destFile.getName());
					break;
				}
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
//			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
}