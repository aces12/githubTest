package biz.cms_HJParcelTran;

import java.util.HashMap;
import java.util.List;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;

import org.apache.log4j.Logger;

public class HJParcelTranDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(HJParcelTranPollingAction.class);
	
	public List<Object> selSVCFILEDAILY(String stdYmd, String svcID, String cmdTp, String comCD) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SVCCRTDAILY"));
			sql.setString(++i, stdYmd);
			sql.setString(++i, svcID);
			sql.setString(++i, cmdTp);
			sql.setString(++i, comCD);
			
			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		} 
		
		return list;
	}
	
	
	public int insSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	
	public int updHJParcelRCVTRAN(String com_cd, HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			//TRAN_YMD||STORE_CD||POS_NO||TRAN_NO
			String tran_id = (String)hm.get("TRAN_YMD") 
			               + (String)hm.get("STORE_CD") 
			               + (String)hm.get("POS_NO") 
			               + (String)hm.get("TRAN_NO");
			
			sql.put(findQuery("service-sql", "UPD_HJ_PARCEL_RCV_TRAN"));
			sql.setString(++i, com_cd);
			sql.setString(++i, tran_id);
			
//			logger.info(" sql : " + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	
	public int insHJParcelTranRslt(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			connect("CMGNS"); //DB Connection(DB 접속)
			
			System.out.println("insHJParcelTranRslt ::: hm ::: " + hm);
			int tot_amt = Integer.parseInt((String)hm.get("TRN_FEE"))
					    + Integer.parseInt((String)hm.get("ETC_FEE"))
					    + Integer.parseInt((String)hm.get("EXT_FEE"));
			
			sql.put(findQuery("service-sql", "INS_HJ_PARCEL_TRAN_RSLT"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("TRAN_YMD"));
			sql.setString(++i, (String)hm.get("STORE_CD"));
			sql.setString(++i, (String)hm.get("POS_NO"));
			sql.setString(++i, (String)hm.get("TRAN_NO"));
			sql.setString(++i, (String)hm.get("WBL_NUM"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
			sql.setString(++i, "02");
			sql.setString(++i, (String)hm.get("PAYMENT_TP"));
			sql.setString(++i, (String)hm.get("MSG_TYPE"));
			sql.setString(++i, "1");
			sql.setString(++i, Integer.toString(tot_amt));
			sql.setString(++i, (String)hm.get("TRN_FEE"));
			sql.setString(++i, (String)hm.get("ETC_FEE"));
			sql.setString(++i, (String)hm.get("EXT_FEE"));
			sql.setString(++i, (String)hm.get("SAL_FEE"));
			sql.setString(++i, (String)hm.get("ENP_DIV"));
			sql.setString(++i, (String)hm.get("DEAL_TYPE"));
			sql.setString(++i, (String)hm.get("RCV_DATETIME"));
			
			rows = executeUpdate(sql);
			
			System.out.println(sql.debug());
		}catch(Exception e){
			rollback();
			logger.info("[ERROR]"+e.getMessage());
			logger.info("[ERROR]"+sql.debug());
			logger.info("[ERROR]"+e.toString());
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
}
