package biz.cms_SmartconDTLDownloader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import biz.cms_TranDivide.TranDivideDAO;
import biz.comm.COMMLog;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;


public class TESTSmartconDN {
	final static String destPath = "C:\\CMBO\\workspace\\sms-1.0.1\\dat";
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	private static DaemonConfigLocator locator = null;
	
	
	 
	public static void main(String arg[]){

//		///////////////////////////////////////////////
//		///접속테스트//
//		///////////////////////////////////////////////
//		String args[] = {"-path:C:\\CMBO\\workspace\\sms-1.0.1\\xml\\daemon-config.xml"};
//			
//		try {
//			if (args == null || args.length < 1) {
//				System.out.println("------ master main args null");
//			}
//			System.out.println("[DEBUG] [args[0]]=" + args[0] );			
//			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
//			
//			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
//			
//		}catch(Exception e) {
//			System.out.println("[ERROR] " + e.getMessage());
//		}
//		
//		
//		System.out.println("===============File parsing START====================");
//		GTFDTLDownloaderPollingAction action = new GTFDTLDownloaderPollingAction();
//		action.execute("1");
//			
		
		
		
		///////////////////////////////////////////////
		///파싱테스트//
		///////////////////////////////////////////////
		String args[] = {"-path:C:\\CMBO\\workspace\\sms-1.0.1\\xml\\daemon-config.xml"};
			
		try {
			if (args == null || args.length < 1) {
				System.out.println("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
		}catch(Exception e) {
			System.out.println("[ERROR] " + e.getMessage());
		}
		
		
		System.out.println("===============File parsing START====================");
		test(destPath);
		

	}
	
	private static void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					//logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	public static List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
	public static void test(String path) {
		int ret = 0;
		BufferedReader bin = null;
		StringTokenizer st = null;
		String readedLine = "";
		try {			
			SmartconDTLDownloaderDAO dao = new SmartconDTLDownloaderDAO();

			//logger.info(">>>>>>> path = " + path);
			List<File> list = getDirFileList(path);
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			for(int i = 0;i < list.size();i++ ) {
				if( !(list.get(i)).isFile() ) {
					continue;
				}
				String targetFile = list.get(i).getName();
				bin = new BufferedReader(new FileReader(path + File.separator + targetFile));
				
				/*logger.info(">>>>>>>>> daily = " + targetFile.substring(18, 19));				
				if( targetFile.substring(18, 19).equals("D") ) {
					bIsDaily = true;
				}else if( targetFile.substring(18, 19).equals("M") ) {
					bIsDaily = false;
				}*/
				while( (readedLine = bin.readLine()) != null ) {
					//logger.info("[DEBUG] File Name : " + targetFile + ", readedLine = " + readedLine);
					// '\t'와'\n' 구분자로 토큰 분리
					st = new StringTokenizer(readedLine, "\t\n");
					
					int col = 0;
					Map<String, String> map = new HashMap<String, String>();

					String strHeaders[] = {
				    	"COM_CD",				
						"SERVICE_ID",
						"TRAN_TYPE",
						"TRAN_YMD",
						"STORE_CODE",
																
						"POS_NO",							
						"TRAN_NO",					
						"COUPON_NUM",					
						"ADMIT_NUM",								
						"ADMIT_DATE",
												
						"ADMIT_TIME",				
						"FEE_P",						
						"FEE_AMT",		
						"SALE_AMT",			
						"ADJ_AMT",
										
						"BAL_AMT",							
						"ORG_COUPON_NUM",	
						"ORG_ADMIT_NUM",
						"ORG_ADMIT_DATE",
						"ORG_ADMIT_TIME",
						
//						"REG_DATE",			
//						"REG_DTM",
//						"REG_EMP_ID"	
					};
					// 각 분리된 토큰을 저장
					while( st.hasMoreTokens() ) {
						map.put(strHeaders[col++], st.nextToken());
						System.out.println("☆  value[" + Integer.toString(col-1) + "] = " + map.get(strHeaders[col-1]));							
					}
					ret = dao.insSmartconDailyDTL(map);

					if( ret != 1 ) {
						//logger.info("["+targetFile.substring(18, 19)+"]"+"There is an Error on inserting data");
					}					
				}
				bin.close();
				bin = null;
				moveFile(path, targetFile, path + File.separator + "backup");
				//logger.info("Data insert OK.  FTP work well done");
			}										
		}catch(Exception e) {
			//logger.info("[ERROR1] " + e.getMessage());
		}finally {
			try {
				if( bin != null ) bin.close();
			}catch(Exception e) {}
		}
	}

	
	
	
	
	
	
}

/* POS->server->GTF 상호간 IRT 전문 테스트 
//for 101 TEST  	
final static String recvDat = "00036506555554444dddd88888888hhhhhhhh666666000100288101TTTTTTTTTTTTTTTTTTTTNAAAAAAAAAAaaaaaaaaaaAAAAAAAAAA141414141414144444999999999888888881N4040404040404040404040404040404040404040242424242424242424242424333M7705311605110001303030303030303030303030303030Y212121212121212121212002122snacksnacksnacksnacksnacksnacksnacksnacksnacksnack000100009999900009999900000999";
	
public static void main (String args[]){
	GTFIrtAction action = new GTFIrtAction();
	action.exeTest(recvDat);			
}*/



/*	 private static String nvl(String param) {
	return param != null ? param: "";
}

private String getDataLen(int rcvIrtDataLen){
		int  sendGTFDataLen = rcvIrtDataLen -2 + 5 ; 
		String str_sendGTFDataLen = String.valueOf(sendGTFDataLen);
		return str_sendGTFDataLen;
	}

@SuppressWarnings("null")
static public void main (String arg[]){
			
	 String args[] = {"-path:C:\\CMBO\\workspace\\sms-1.0.1\\xml\\daemon-config.xml"};
		
	try {
		if (args == null || args.length < 1) {
			System.out.println("------ master main args null");
		}
		System.out.println("[DEBUG] [args[0]]=" + args[0] );			
		String path          = nvl(args[0].replaceFirst("-path:"  ,""));
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		
	}catch(Exception e) {
		System.out.println("[ERROR] " + e.getMessage());
	}

	
	System.out.println("===============TESTDB START====================");
	
	COMMLog cLog = new COMMLog();
	TranDivideDAO dao = new TranDivideDAO();
	SqlWrapper sql = new SqlWrapper();
	TESTGTFDN ht = new TESTGTFDN();
}*/





