package biz.cms_SmartconDTLDownloader;

import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class SmartconDTLDownloaderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(SmartconDTLDownloaderPollingAction.class);
	
	
	public int insSmartconDailyDTL(Map<String, String> map) {
		SqlWrapper sql = new SqlWrapper();
		String sqlDbg = "";
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();			
			//DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("service-sql", "INS_SMARTCONVENDAILY_TRN"));
			
			sql.setString(++i, map.get("COM_CD"));
			sql.setString(++i, map.get("SERVICE_ID"));
			sql.setString(++i, map.get("TRAN_TYPE"));		
			sql.setString(++i, map.get("TRAN_YMD"));
			sql.setString(++i, map.get("STORE_CODE"));
			
			sql.setString(++i, map.get("POS_NO"));
			sql.setString(++i, map.get("TRAN_NO"));
			sql.setString(++i, map.get("COUPON_NUM"));
			sql.setString(++i, map.get("ADMIT_NUM"));
			sql.setString(++i, map.get("ADMIT_DATE"));
			
			sql.setString(++i, map.get("ADMIT_TIME"));			
			sql.setString(++i, map.get("FEE_P"));			
			sql.setString(++i, map.get("FEE_AMT"));
			sql.setString(++i, map.get("SALE_AMT"));
			sql.setString(++i, map.get("ADJ_AMT"));
			
			sql.setString(++i, map.get("BAL_AMT"));			
			sql.setString(++i, map.get("ORG_COUPON_NUM"));			
			sql.setString(++i, map.get("ORG_ADMIT_NUM"));
			sql.setString(++i, map.get("ORG_ADMIT_DATE"));
			sql.setString(++i, map.get("ORG_ADMIT_TIME"));

//			sql.setString(++i, map.get("REG_DATE"));
//			sql.setString(++i, map.get("REG_DTM"));	
//			sql.setString(++i, map.get("REG_EMP_ID"));
			sql.setString(++i, map.get("COUPON_TYPE"));
			
			sqlDbg = sql.debug();						
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			logger.info("[SQL1][INS_TAXFREEVENDAILY_TRN]" + sqlDbg );
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info(sqlDbg);
			System.out.println("[ERROR1] " + e.getMessage());
		}finally {
			//transaction 종료
			end();
			logger.info("[Data Insert well done]");
		}
		
		return rows;
	}
	
	public int delSmartconDailyDTL(Map<String, String> map) {
		SqlWrapper sql = new SqlWrapper();
		String sqlDbg = "";
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();			
			//DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("service-sql", "DEL_SMARTCONVENDAILY_TRN"));
				
			sql.setString(++i, map.get("TRAN_YMD"));
			
			sqlDbg = sql.debug();						
			rows = executeUpdate(sql);
			logger.info("[Data delete well done]");
		}catch(Exception e) {
			logger.info("[SQL1][DEL_TAXFREEVENDAILY_TRN]" + sqlDbg );
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info(sqlDbg);
			System.out.println("[ERROR1] " + e.getMessage());
		}finally {
			//transaction 종료
			end();
			
		}
		
		return rows;
	}
	
}


/*public int insCGDailyDTL(Map<String, String> map) {
	SqlWrapper sql = new SqlWrapper();
	int i = 0;
	int rows = -1;
	
	try {
		//transaction 발생
		begin();
		
		//DB Connection(DB 접속)
		connect("CMGNS");
		
		sql.put(findQuery("service-sql", "INS_CGVENDAILYAPPR_TRN"));
		sql.setString(++i, (String)map.get("CO_CD"));
		sql.setString(++i, (String)map.get("ADJT_DT"));
		sql.setString(++i, "A16" + (String)map.get("STORE_CD"));
		sql.setString(++i, (String)map.get("APPR_NO"));
		sql.setString(++i, (String)map.get("NOR_CNCL_TP"));
		sql.setString(++i, (String)map.get("APPR_ELECDOC_UNQ_ID"));
		sql.setString(++i, (String)map.get("CNCL_ELECDOC_UNQ_ID"));
		sql.setString(++i, (String)map.get("GDS_BARCD_NO"));
		sql.setString(++i, (String)map.get("AMT"));
		sql.setString(++i, (String)map.get("APPR_DTM"));
		sql.setString(++i, (String)map.get("CNCL_DTM"));
		
		logger.info("[SQL1][INS_CGVENDAILYAPPR_TRN]" + sql.debug() );
								
		rows = executeUpdate(sql);
		
	}catch(Exception e) {
		rollback();
		logger.info("[ERROR1] " + e.getMessage());
	}finally {
		//transaction 종료
		end();
	}
	
	return rows;
}*/





		
		
		
		
