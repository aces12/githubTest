/*
 * TranCallDAO.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_TranCall;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

import com.mysql.jdbc.StringUtils;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;

/**
 * TranCallDAO
 * A class that has inherited GenericDAO(GenericDAO를 상속받은 클래스)
 * It is responsible for functions to access DB to retrieve respective information(DB에 접속하여 해당 정보를 조회해 오거나)
 * or update DB information(DB정보를 업데이트 하는 기능을 담당한다).
 * @created on 1.0, 11/03/17
 * @created by oki(FUJITSU KOREA LTD.)
 * 
 * @modified on
 * @modified by
 * @caused by
 */
public class TranCallDAO extends GenericDAO {

	/***************************************************************************
	 * getTranCall : Result of Deployment Order Check Reflection(거래호출정보처리결과)
	 * 
	 * @param tranYmd
	 * @param hm
	 * @return datamsg
	 * @throws Exception
	 */
	public String getTranCall(HashMap hmCommon, HashMap hmData, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String transID = "";
		String fileAppTy = "";
		String dataMsg = "";
		String ret = "00";
		boolean bSucc = false;
		// DB Connection(DB 접속)
		connect("CMGNS");
		try {
//			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_SEL_STTRP010DT));
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, "SEL_STTRP010DT2"));
			sql.setString(++i, (String) hmData.get("REQ_TRAN_YMD"));
			sql.setString(++i, (String) hmCommon.get("COM_CD"));
			sql.setString(++i, (String) hmData.get("REQ_STORE_CD"));
			sql.setString(++i, (String) hmData.get("REQ_POS_NO"));
			sql.setString(++i, (String) hmData.get("REQ_TRAN_NO"));

//			df.CommLogger("★ make send SQL: "+ sql.debug());
			list = executeQuery(sql);
			if (list.size() > 0) {
				map = (Map) list.get(0);

				String tranTy = (String) map.get("TRAN_TYPE");
				String returnYN = (String) map.get("RFND_YN");
				//조회 거래가 환불거래 일경우
				if (tranTy.equals("1")) 
					map.put("RES_CD", "02");
				//조회 거래가 기반품된 거래 일경우
				else if (returnYN.equals("1")) 
					map.put("RES_CD", "01");
				else
					map.put("RES_CD", "00");

				String dealDat = (String) map.get("DEAL_DAT");
				int tranLen = Integer.parseInt(dealDat.substring(0, 6)) + COMMBiz.CM_LENS;
				map.put("TRAN_LEN", StringUtil.lPad(String.valueOf(tranLen),6,"0")) ;
				map.put("TRAN_DATA", dealDat);
				bSucc = true;
			} else {
				//조회 거래가 없을 경우
				map.put("RES_CD", "09");
				map.put("TRAN_LEN", "000000");
			}

			hmData.put("INQ_TYPE", "08");
			hmData.put("RES_CD", (String) map.get("RES_CD"));
			hmData.put("TRAN_LEN", (String) map.get("TRAN_LEN"));
			hmData.put("TRAN_DATA", (String) map.get("TRAN_DATA"));

		} catch(SQLException e){ 	
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		} catch (Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			throw e;
		} finally {
			dataMsg = ret + makeTranCallSendData(hmData, df);
			df.CommLogger("★ make: " + dataMsg);
		}

		return dataMsg;
	}

	/***************************************************************************
	 * makeOrderCheckSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeTranCallSendData(HashMap hmData, COMMLog df) {
		
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2,2,8,5,4,4,6};
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별 : 08)    
				"RES_CD"			, // Result Code(응답코드) 
				"REQ_TRAN_YMD"		, // Tran Date(거래일자)
				"REQ_STORE_CD"		, // Store Code(점포코드)
				"REQ_POS_NO"		, // POS No.(포스번호)
				"REQ_TRAN_NO"		, // Tran No(거래번호)
				"TRAN_LEN"			  // Tran Data Length(거래데이터 길이)
			};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hmData.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hmData.get(strHeaders[i].toString()), nlens[i]);
		}
		if ((String) hmData.get("TRAN_LEN") != "000000") {
			// Tran Data(거래데이터)
			StringUtil.appendSpace(sb, (String) hmData.get("TRAN_DATA"), 0);
		}

		return sb.toString();
	}

}
