package biz.cms_EConIrt;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.cms_KISDTLDownloader.KISDTLData;
import biz.comm.COMMBiz;

public class EConIrtAction_test extends ServerAction {
	private static Logger logger = Logger.getLogger(EConIrtAction.class);
	EConIrtDAO dao = new EConIrtDAO();
	
	public static void main(String args[]) throws Exception {
		EConIrtAction_test action = new EConIrtAction_test();
		
		try {
			String path = "C:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			HashMap<String, String> map = new HashMap<String, String>();
			String readedLine = new String("ASCII");
			
			readedLine = "604100180212180213941117******9646   000000009000000000             0000000225정상완료            18021256606C        39202779            30000337  05";
			
			map = COMMBiz.getParseDataMultibyte2(KISDTLData.nlensREP_D, KISDTLData.strHeadersREP_D, readedLine);
			
			//action.execute("");
			
			System.out.println("[Received Data]=FINISH DOWN HJPARCELTRAN DATA.");
			/*System.out.println("[Received Data]=" + retMsg);*/
		}catch(Exception e) {
			System.out.println("[Received Data]=" + e.getMessage());
		}
	}
	
	/**
	 * Receive data from SC through 9033 PORT(SC로부터 데이타를 9033 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(String data) throws Exception {
		// TODO Auto-generated method stub
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		StringBuffer sb = null;
		
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		
		EConIrtProtocol protocol = new EConIrtProtocol();
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			//rcvBuf = ((String) actionSocket.receive());
			
			//헤더데이터 : 00008006009990003102520180205201802051125280001002
			//상세데이터 발행요청 : E21310201801199999        200000000001000000001000000000001500000001007                    
			//상세데이터 조회요청 : E43102018012277323100120180205
			//상세데이터 승인요청 : E6002018020515161231020180122773231001000000001000                                                                 
			rcvBuf = "00015306012400003102520180205201802051125280001002E21310201801199999        200000000001000000001000000000001500000001007                    ";
			System.out.println("[INFO] EConIRT::rcvBuf::[" + rcvBuf + "]");
			
			System.out.println("compareValue::["+"20180206".compareTo("20180208")+"]"); //">"
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			System.out.println("[INFO] EConIrt::hmCommon::["+hmCommon+"]");
			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}

			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			System.out.println("[INFO] EConIRT::rcvDataBuf::["+rcvDataBuf+"]");
			inq_type = COMMBiz.getInqTypeCHG(protocol.getRcvEConIrtDATA(rcvDataBuf));
			
			boolean bIsExtended = false;
			
			System.out.println("[INFO] EConIRT::inq_type::["+inq_type+"]");
			switch(inq_type) {
				case 2189:	// E2(2189): 쿠폰 발행 요청
					System.out.println("ECon Issue Request START");
					
					//전문길이 체크 (71bytes)
					if (rcvDataBuf.length() == 91) {
						hmData = protocol.getParseEConIssReq(rcvDataBuf);
						//System.out.println("[pos>sms] RECV["+rcvBuf.getBytes().length+"]:[INQ_TYPE:"+rcvBuf.substring(50, 52)+"]:["+sb.toString()+"]");
						
						System.out.println("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
						System.out.println("[INFO] EConIRT::hmData::["+hmData+"]");
						
						//쿠폰발행시작
						dataMsg = EConIssueFunc(hmCommon, hmData);
						System.out.println("[INFO] EConIRT::dataMsg::["+dataMsg+"]");
					} else {
						System.out.println("[ERROR] IRT Length unmatched");
						hmData.put("RSLT_CD", "10");
						hmData.put("RSLT_MSG", "IRT 전문길이 오류");
						
						dao.insEConIssLog(hmCommon, hmData);	//로그테이블 이력 쌓기(ST_COUPONISS_LOG)
						return;
					}
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
			
				case 2191:	// E4(2191): 쿠폰 조회 요청
					System.out.println("ECon Select Request START");
					
					if (rcvDataBuf.length() == 30) {
						hmData = protocol.getParseEConSelReq(rcvDataBuf);
						
						System.out.println("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
						System.out.println("[INFO] EConIRT::hmData::["+hmData+"]");
						
						//쿠폰조회시작
						dataMsg = EConSelFunc(hmCommon, hmData);
					} else {
						System.out.println("[ERROR] IRT Length unmatched");
						hmData.put("RSLT_CD", "10");
						hmData.put("RSLT_MSG", "IRT 전문길이 오류");
						return;
					}
					break;
					
				case 2193:	// E6(2193): 쿠폰 승인/취소 요청
					System.out.println("ECon Approve/Cancel Request START");
					System.out.println(rcvDataBuf.length());
					if (rcvDataBuf.length() == 115) {
						hmData = protocol.getParseEConAppReq(rcvDataBuf);
						
						System.out.println("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
						System.out.println("[INFO] EConIRT::hmData::["+hmData+"]");
						
						//쿠폰 승인/취소
						dataMsg = EConApprFunc(hmCommon, hmData);
					} else {
						System.out.println("[ERROR] IRT Length unmatched");
						hmData.put("RSLT_CD", "10");
						hmData.put("RSLT_MSG", "IRT 전문길이 오류");
						return;
					}
					break;
						
				default:
					System.out.println("[INFO] INQ Type Code::["+inq_type+"]::LEN::["+rcvBuf.length()+"]");
					ret = 99;
					break;
			}
		} catch (Exception e) {
			ret = 29; // 029=HOST APPL ERR
			retValue = "[ERROR]2:" + e.getMessage();
			System.out.println("▶ " + retValue);
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			System.out.println("dataMsg[" + dataMsg + "]");
			System.out.println("sendMsg[" + sendMsg + "]");
					
			System.out.println("================ 4-2) POS<-SMS 응답전문 ===================");
			System.out.println("전문길이=[" + totalMsg.getBytes().length + "]");
			System.out.println("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
			System.out.println("전문내용=[" + totalMsg + "]");
			
			// Send Response Data (응답 데이타 전송)
			System.out.println("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
		} catch (Exception e) {
			retValue = "[ERROR]4" + e.getMessage();
			System.out.println("▶ " + retValue);
		} finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			System.out.println("SSGMBSIRT END");
		}
	}
	
	
	//쿠폰 발행 로직
	private String EConIssueFunc(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		System.out.println("[INFO] EConIRT::hmCom::["+hmCom+"]");
		System.out.println("[INFO] EConIRT::hmData::["+hmData+"]");
		
		int cpAmt	    = 0;
		int reqCnt		= Integer.parseInt(hmData.get("ISSUE_REQ_CNT"));
		int cpRate 	    = Integer.parseInt(hmData.get("COUPON_AMT"));
		int trAmt  	    = Integer.parseInt(hmData.get("TRADE_AMT"));
		int cpStdAmt    = Integer.parseInt(hmData.get("COUPON_STD_AMT"));
		int duration    = Integer.parseInt(hmData.get("COUPON_DURATION"));
		long chkDigit    = 0;
		
		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdftm = new SimpleDateFormat("yyyyMMddHHmmss");
		calendar.add(Calendar.DATE, duration);
		
		String cpNo 	= ""; // 발행쿠폰번호
		String prefix 	= hmData.get("COUPON_TP"); // 쿠폰유형
		String flag 	= hmData.get("ISSUE_SYS"); // 플래그
		String rdNum 	= ""; // 랜덤숫자
		String rsltCd   = "00";
		String rsltMsg  = "정상";
		String dataMsg  = "";
		String startDt  = sdf.format(new Date());
		String expireDt = sdf.format(calendar.getTime());
		String pluCd 	= "";
		String issDt	= sdf.format(new Date());
		String issTm	= sdftm.format(new Date()).substring(8, 14);
		
		if(!"310".equals(prefix) && !"320".equals(prefix) && !"330".equals(prefix) && !"340".equals(prefix)){ //쿠폰유형 체크
			System.out.println("[ERROR] unknown coupon type.");
			rsltCd = "99";
			rsltMsg = "알 수 없는 쿠폰 유형";
			
			try{
				hmData.put("SEQ_NO", "0");
				hmData.put("RSLT_CD", rsltCd);
				hmData.put("RSLT_MSG", rsltMsg);
				
				dao.insEConIssLog(hmCom, hmData);
			}catch(Exception e){
				System.out.println("[ERROR] 로그 등록 INSERT 오류");
			}
		}else{
			if(!"1".equals(flag) && !"2".equals(flag) && !"3".equals(flag) && !"4".equals(flag)){
				System.out.println("[ERROR] unknown system.");
				rsltCd = "99";
				rsltMsg = "알 수 없는 발행요청 시스템";
				
				try{
					hmData.put("SEQ_NO", "0");
					hmData.put("RSLT_CD", rsltCd);
					hmData.put("RSLT_MSG", rsltMsg);
					
					dao.insEConIssLog(hmCom, hmData);
				}catch(Exception e){
					System.out.println("[ERROR] 로그 등록 INSERT 오류");
				}
			}else{
				try{
					for(int i = 0; i < reqCnt; i++){// 발행요청 개수만큼
						//0. SEQ_NO SETTING --공통
						hmData.put("SEQ_NO", String.valueOf(i));
						
						//1. 쿠폰번호 발행 --공통
						Random rd = new Random();
						rdNum = String.valueOf(rd.nextInt(10));
						
						cpNo = prefix
							 + hmCom.get("SYS_YMD")
							 + flag
							 + hmCom.get("SYS_HMS").substring(3, 6)
							 + rdNum
							 + hmCom.get("SYS_HMS").substring(0, 3);
						
						chkDigit = Long.parseLong(cpNo) % 8;
						cpNo = cpNo	+ String.valueOf(chkDigit);
						
						System.out.println("[INFO] EConIRT::cpNo::["+cpNo+"]");
						hmData.put("ISSUE_CPN_NO", cpNo);
						
						//2. 쿠폰금액 지정 (율/금액 구분) -- 금액형/할인형
						if(trAmt >= cpStdAmt){	//2-1) 쿠폰발행대상 거래인지 체크
							if("310".equals(prefix)){	//2-2) 쿠폰유형체크
								if("2".equals(hmData.get("COUPON_AMT_TP"))){	//2-3) 쿠폰 금액/율 구분 체크 -- 율인 경우, COUPON_AMT 계산해줘야 함
									cpAmt = cpStdAmt / cpRate;
								}else{
									cpAmt = cpRate;
								}
							}
						}else{
							System.out.println("[ERROR] 쿠폰 발행기준금액 미달");
							rsltCd = "10";
							rsltMsg = "쿠폰 발행기준금액 미달";
						}
						
						System.out.println("[INFO] cpAmtTp::["+hmData.get("COUPON_AMT_TP")+"]::trAmt::["+trAmt+"]::cpStdAmt::["+cpStdAmt+"]::cpRate::["+cpRate+"]::cpAmt::["+cpAmt+"]");
						
						hmData.put("COUPON_RM_AMT", String.format("%012d", cpAmt));
						
						//3. 쿠폰사용기간 지정 --공통
						hmData.put("START_DT", startDt);
						hmData.put("EXPIRE_DT", expireDt);
						
						//4. 쿠폰 마스터테이블 insert -- 쿠폰발행요청 시스템이 POS가 아닌 경우에만 해당
						if(!"1".equals(flag)){
							if("00".equals(rsltCd)){
								try{
									System.out.println("[INFO] 쿠폰 마스터테이블 INSERT");
									//dao.insEConMaster(hmCom, hmData);
								}catch(Exception e){
									System.out.println("[ERROR] 쿠폰 마스터 등록 INSERT 오류");
									rsltCd = "30";
									rsltMsg = "쿠폰 마스터 등록 INSERT 오류";
								}
							}
						}
						
						//5. 쿠폰발행 이력 쌓기 --공통
						try{
							hmData.put("RSLT_CD", rsltCd);
							hmData.put("RSLT_MSG", rsltMsg);
							
							dao.insEConIssLog(hmCom, hmData);
						}catch(Exception e){
							System.out.println("[ERROR] 로그 등록 INSERT 오류");
							rsltCd = "99";
							rsltMsg = "로그 등록 INSERT 오류";
						}
					}
				}catch(Exception e){
					try{
						hmData.put("RSLT_CD", rsltCd);
						hmData.put("RSLT_MSG", rsltMsg);
						
						dao.insEConIssLog(hmCom, hmData);
					}catch(Exception e1){
						System.out.println("[ERROR] 로그 등록 INSERT 오류 :: "+e1.getMessage());
						rsltCd = "99";
						rsltMsg = "로그 등록 INSERT 오류";
					}
					System.out.println("[ERROR] EConIrtAction::"+e.getMessage());
				}finally{
					//6. POS로 내려줄 데이터 만들기
					if("1".equals(flag)){
						hmData.put("INQ_TYPE", "E3");
						hmData.put("RESP_CD", rsltCd);
						hmData.put("RESP_MSG", rsltMsg);
						hmData.put("ISSUE_DT", issDt);
						hmData.put("ISSUE_TM", issTm);
						
						System.out.println(hmData);
						
						dataMsg = rsltCd + makeSendDataEConIssRsp(hmData);
					}
				}
			}
		}
		
		return dataMsg;
	}
	
	
	//쿠폰 조회 요청
	private String EConSelFunc(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		System.out.println("[INFO] EConIRT::hmCom::["+hmCom+"]");
		System.out.println("[INFO] EConIRT::hmData::["+hmData+"]");
		
		String cpStsId  = "0";
		String rsltCd   = "00";
		String rsltMsg  = "정상";
		String dataMsg  = "";
		
		HashMap<String, String> econMap = new HashMap<String, String>();
		
		try{
			List econInfo = (List)dao.selEConInfo(hmData);
			
			System.out.println("[INFO] econInfo.size::["+econInfo.size()+"]");
			if(econInfo.size() > 0){
				for(int i = 0; i<econInfo.size(); i++){
					econMap = (HashMap<String, String>) econInfo.get(i);
					System.out.println(econMap);
					
					cpStsId = econMap.get("COUPON_STS_ID");
					
					if("9".equals(cpStsId)){
						System.out.println("[INFO] 유효기간이 만료된 쿠폰입니다.");
						rsltCd = "10";
						rsltMsg = "유효기간이 만료된 쿠폰입니다.";
					}else if ("1".equals(cpStsId)){
						System.out.println("[INFO] 사용완료된 쿠폰입니다.");
						rsltCd = "20";
						rsltMsg = "사용완료된 쿠폰입니다.";
					}else if ("0".equals(cpStsId)){
						System.out.println("[INFO] 사용가능 쿠폰입니다.");
					}else{
						System.out.println("[ERROR] 쿠폰상태값 오류입니다. 시스템 담당자에게 문의하세요.");
						rsltCd = "30";
						rsltMsg = "쿠폰상태값 오류입니다. 시스템 담당자에게 문의하세요.";
					}
				}
			}else{
				//유효하지 않은 쿠폰번호 오류
				System.out.println("[ERROR] 쿠폰이 존재하지 않습니다. 쿠폰번호를 확인해주세요. ["+hmData.get("COUPON_NO")+"]");
				rsltCd = "40";
				rsltMsg = "쿠폰이 존재하지 않습니다.";
			}
			
		}catch(Exception e){
			
		}finally{
			//6. POS로 내려줄 데이터 만들기
			econMap.put("INQ_TYPE", "E5");
			econMap.put("RESP_CD", rsltCd);
			econMap.put("RESP_MSG", rsltMsg);
			
			System.out.println(econMap);
			dataMsg = rsltCd + makeSendDataEConSelRsp(econMap);
		}
		
		return dataMsg;
	}
	
	
	//20180205 -- 쿠폰 승인/취소 요청
	private String EConApprFunc(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		
		String cpStsId  = "0";
		String rsltCd   = "00";
		String rsltMsg  = "정상";
		String dataMsg  = "";
		String cpNo 	= hmData.get("COUPON_NO");
		String othYn	= "N";
		String storeCd	= hmCom.get("STORE_CD");
		String tradeDt  = hmData.get("TRADE_DT");
		
		int tradeAmt  = Integer.parseInt(hmData.get("TRADE_AMT"));
		int remainAmt = 0;
		
		boolean apprEcon = true;
		
		HashMap<String, String> econMap = new HashMap<String, String>();
		
		try{
			List econInfo = (List)dao.selEConInfo(hmData);
			
			if(econInfo.size() > 0){
				for(int i = 0; i<econInfo.size(); i++){
					econMap = (HashMap<String, String>) econInfo.get(i);
					
					cpStsId = econMap.get("COUPON_STS_ID");
					othYn   = econMap.get("OTH_STORE_YN");
					remainAmt = Integer.parseInt(econMap.get("COUPON_RM_AMT"));
					
					if("N".equals(othYn)){ //타점 사용불가 쿠폰
						if(!storeCd.equals(econMap.get("STORE_CD"))){ //store_cd 체크
							System.out.println("쿠폰을 사용할 수 없는 점포입니다.");
							apprEcon = false;
							rsltCd  = "99";
							rsltMsg = "쿠폰을 사용할 수 없는 점포입니다.";
						}
					}
					
					if(apprEcon){
						if("00".equals(hmData.get("TRADE_TP"))){ //승인
							if("0".equals(cpStsId)){
								if("310".equals(cpNo.substring(0, 3))){
									if(tradeAmt <= remainAmt){
										Random rd = new Random();
										econMap.put("AUTH_NO", String.valueOf(rd.nextInt(100000000)));
										econMap.put("AUTH_DT", sdf.format(new Date()).substring(0, 8));
										econMap.put("AUTH_TM", sdf.format(new Date()).substring(8, 14));
										
										//2. 잔여금액계산
										remainAmt = remainAmt - tradeAmt;	
										
										//3. update mst table (잔액, 쿠폰상태값)
										econMap.put("COUPON_RM_AMT", String.valueOf(remainAmt));	
										if(remainAmt == 0){
											econMap.put("COUPON_STS_ID", "1");
										}
										
										try{
											dao.updEConMst(econMap);
										}catch(Exception e){
											System.out.println(e.getMessage());
										}
									}else{
										System.out.println("[INFO] 잔액이 부족합니다. 사용가능 금액 ["+remainAmt+"원]");
										rsltCd  = "99";
										rsltMsg = "잔액이 부족합니다. 사용가능 금액 ["+remainAmt+"원]";
									}
								}else{
									rsltCd  = "99";
									rsltMsg = "금액형 쿠폰이 아닙니다.";
								}
							}else{
								if("1".equals(cpStsId)){
									System.out.println("[ERROR] 사용완료 된 쿠폰입니다.");
									rsltCd = "99";
									rsltMsg = "사용완료 된 쿠폰입니다.";
								}else if("9".equals(cpStsId)){
									System.out.println("[ERROR] 기간만료 된 쿠폰입니다.");
									rsltCd = "99";
									rsltMsg = "기간만료 된 쿠폰입니다.";
								}else{
									System.out.println("[ERROR] 사용할 수 없는 쿠폰입니다.");
									rsltCd = "99";
									rsltMsg = "사용할 수 없는 쿠폰입니다.";
								}
							}
						}else if("01".equals(hmData.get("TRADE_TP"))){	//취소
							if("310".equals(cpNo.substring(0, 3))){	//금액형
								Random rd = new Random();
								econMap.put("AUTH_NO", String.valueOf(rd.nextInt(100000000)));
								econMap.put("AUTH_DT", sdf.format(new Date()).substring(0, 8));
								econMap.put("AUTH_TM", sdf.format(new Date()).substring(8, 14));
								
								//2. 잔여금액계산
								remainAmt = remainAmt + tradeAmt;
								econMap.put("COUPON_RM_AMT", String.valueOf(remainAmt));
								
								//3. update mst table (잔액, 쿠폰상태값)
								if(remainAmt > 0 && (tradeDt.compareTo(econMap.get("START_DT")) > 0) && (tradeDt.compareTo(econMap.get("EXPIRE_DT")) < 0)){
									econMap.put("COUPON_STS_ID", "0");
								}
							}
						}else{
							System.out.println("[ERROR] 거래유형오류");	//오류 리턴
							rsltCd = "99";
							rsltMsg = "거래유형오류";
						}
					}
				}
			}else{
				//유효하지 않은 쿠폰번호 오류
				System.out.println("[ERROR] 쿠폰이 존재하지 않습니다. 쿠폰번호를 확인해주세요. ["+hmData.get("COUPON_NO")+"]");
				rsltCd = "99";
				rsltMsg = "쿠폰번호를 확인해주세요.["+hmData.get("COUPON_NO")+"]";
			}
			
		}catch(Exception e){
			System.out.println(e.getMessage());
		}finally{
			//6. POS로 내려줄 데이터 만들기
			econMap.put("INQ_TYPE", "E7");
			econMap.put("RESP_CD", rsltCd);
			econMap.put("RESP_MSG", rsltMsg);
			econMap.put("TRADE_TP", hmData.get("TRADE_TP"));
			
			if(!"00".equals(rsltCd)){
				econMap.put("AUTH_NO", "");
				econMap.put("AUTH_DT", "");
				econMap.put("AUTH_TM", "");
			}
			
			dataMsg = rsltCd + makeSendDataEConAppRsp(econMap);
		}
		
		return dataMsg;
	}
	
	
	//20180129 KSN 쿠폰 발행 응답
	private String makeSendDataEConIssRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 2, 64, 8, 8,
			20, 12, 12, 20, 8, 
			6
		};//150
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			, // 응답메시지
			"START_DT"			, // 사용가능시작일
			"EXPIRE_DT"			, // 사용가능종료일
			
			"ISSUE_CPN_NO"		, // 쿠폰번호
			"COUPON_AMT"		, // 금액(율)
			"COUPON_RM_AMT"		, // 쿠폰잔액
			"COUPON_PLU_CD"	, // 교환상품코드
			"ISSUE_DT"			, // 쿠폰발행일자
			
			"ISSUE_TM"	 		  // 쿠폰발행시간
		};
		
		for (int i = 0; i < nlens.length; i++) {
			System.out.println(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//20180205 KSN 쿠폰 조회 응답
	private String makeSendDataEConSelRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 2, 64, 20, 3,
			1, 12, 12, 20, 1
		};//137
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			, // 응답메시지
			"COUPON_NO"			, // 쿠폰번호
			"COUPON_TP"			, // 쿠폰유형
			
			"COUPON_AMT_TP"		, // 금액/율 구분
			"COUPON_AMT"		, // 금액(율)
			"COUPON_RM_AMT"		, // 쿠폰잔여금액
			"COUPON_PLU_CD"		, // 교환상품코드
			"COUPON_STS_ID"		  // 쿠폰상태값
		};
		
		for (int i = 0; i < nlens.length; i++) {
			System.out.println(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//20180205 KSN 쿠폰 조회 응답
	private String makeSendDataEConAppRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 2, 64, 2, 20,
			8, 8, 12, 10, 8,
			6
		};//142
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			, // 응답메시지
			"TRADE_TP"			, // 거래유형
			"COUPON_NO"			, // 쿠폰번호
			
			"START_DT"			, // 사용가능시작일
			"EXPIRE_DT"			, // 사용가능종료일
			"COUPON_RM_AMT"		, // 쿠폰잔여금액
			"AUTH_NO"			, // 승인번호
			"AUTH_DT"			, // 승인일자
			
			"AUTH_TM"			  // 승인시간
		};
		
		for (int i = 0; i < nlens.length; i++) {
			System.out.println(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	@Override
	public void execute(ActionSocket arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
}



