package biz.cms_EConIrt;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class EConIrtDAO extends GenericDAO {
	
	private static Logger logger = Logger.getLogger(EConIrtAction.class);
	
	public int insEConIssLog(HashMap<String, String> hmComm, HashMap<String, String> hmData) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			connect("CMGNS"); //DB Connection(DB 접속)
			
			System.out.println("[INFO] EConIrtDAO::insEConIssLog::hmComm" + hmComm);
			System.out.println("[INFO] EConIrtDAO::insEConIssLog::hmData" + hmData);
			
			sql.put(findQuery("service-sql", "INS_ECONISSLOG"));
			sql.setString(++i, (String)hmComm.get("TRAN_YMD"));
			sql.setString(++i, (String)hmComm.get("STORE_CD"));
			sql.setString(++i, (String)hmComm.get("POS_NO"));
			sql.setString(++i, (String)hmComm.get("TRAN_NO"));
			sql.setString(++i, (String)hmData.get("SEQ_NO"));
			
			sql.setString(++i, (String)hmData.get("ISSUE_SYS"));
			sql.setString(++i, (String)hmData.get("ISSUE_REQ_CNT"));
			sql.setString(++i, (String)hmData.get("RSLT_CD"));
			sql.setString(++i, (String)hmData.get("RSLT_MSG"));
			sql.setString(++i, (String)hmData.get("ISSUE_CPN_NO"));
			
			sql.setString(++i, (String)hmData.get("COUPON_TP"));
			sql.setString(++i, (String)hmData.get("COUPON_AMT_TP"));
			sql.setString(++i, (String)hmData.get("COUPON_AMT"));
			sql.setString(++i, (String)hmData.get("COUPON_RM_AMT"));
			sql.setString(++i, (String)hmData.get("ISSUE_CPN_PLU_CD"));
			sql.setString(++i, (String)hmData.get("EVT_CD"));
			
			rows = executeUpdate(sql);
			
			System.out.println("[INFO] EConIrtDAO::insEConIssLog::" + sql.debug());
			
		}catch(Exception e) {
			rollback();
			System.out.println("[ERROR] EConIrtDAO::insEConIssLog::" + sql.debug());
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	
	
	public int insEConMaster(HashMap<String, String> hmComm, HashMap<String, String> hmData) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			connect("CMGNS"); //DB Connection(DB 접속)
			
			System.out.println("[INFO] EConIrtDAO::insEConMaster::hmComm" + hmComm);
			System.out.println("[INFO] EConIrtDAO::insEConMaster::hmData" + hmData);
			
			sql.put(findQuery("service-sql", "INS_ECONMASTER"));
			sql.setString(++i, (String)hmComm.get("TRAN_YMD"));
			sql.setString(++i, (String)hmComm.get("STORE_CD"));
			sql.setString(++i, (String)hmComm.get("POS_NO"));
			sql.setString(++i, (String)hmComm.get("TRAN_NO"));
			sql.setString(++i, (String)hmData.get("ISSUE_SYS"));
			
			sql.setString(++i, (String)hmData.get("ISSUE_REQ_CNT"));
			sql.setString(++i, (String)hmData.get("RSLT_CD"));
			sql.setString(++i, (String)hmData.get("RSLT_MSG"));
			sql.setString(++i, (String)hmData.get("ISSUE_CPN_NO"));
			sql.setString(++i, (String)hmData.get("COUPON_TP"));
			
			sql.setString(++i, (String)hmData.get("COUPON_AMT_TP"));
			sql.setString(++i, (String)hmData.get("COUPON_AMT"));
			sql.setString(++i, (String)hmData.get("ISSUE_CPN_PLU_CD"));
			sql.setString(++i, (String)hmData.get("EVT_CD"));
			
			rows = executeUpdate(sql);
			
			System.out.println("[INFO] EConIrtDAO::insEConIssLog::" + sql.debug());
			
		}catch(Exception e) {
			rollback();
			System.out.println("[ERROR] EConIrtDAO::insEConIssLog::" + sql.debug());
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public List<Object> selEConInfo(HashMap<String, String> hmData, HashMap<String, String> hmCom) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			connect("CMGNS"); //DB Connection(DB 접속)
			
			System.out.println(hmData.get("COUPON_NO"));
			
			sql.put(findQuery("service-sql", "SEL_ECONINFO"));
			sql.setString(++i, hmData.get("TRADE_DT"));
			sql.setString(++i, hmData.get("TRADE_DT"));
			sql.setString(++i, hmData.get("COUPON_NO"));
			sql.setString(++i, hmCom.get("STORE_CD"));
			
			list = executeQuery(sql);
		}catch(Exception e) {
			System.out.println("[ERROR] Exception::["+e.getMessage()+"]");
			throw e;
		}
		
		return list;
	}
	
	public int updEConMst(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			connect("CMGNS");	//DB Connection(DB 접속)
			
			sql.put(findQuery("service-sql", "UPD_ECONMST"));
			sql.setString(++i, (String)hm.get("COUPON_RM_AMT"));
			sql.setString(++i, (String)hm.get("COUPON_STS_ID"));
			sql.setString(++i, (String)hm.get("COUPON_NO"));
			
			System.out.println(">>>sql:" + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	
	public List<Object> selEConIssInfo(HashMap<String, String> hmData) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			connect("CMGNS"); //DB Connection(DB 접속)
			
			sql.put(findQuery("service-sql", "SEL_ECONISSINFO"));
			sql.setString(++i, hmData.get("TRAN_YMD"));
			sql.setString(++i, hmData.get("STORE_CD"));
			sql.setString(++i, hmData.get("POS_NO"));
			sql.setString(++i, hmData.get("TRAN_NO"));
			sql.setString(++i, hmData.get("COUPON_NO"));
			
			list = executeQuery(sql);
		}catch(Exception e) {
			System.out.println("[ERROR] Exception::["+e.getMessage()+"]");
			throw e;
		}
		
		return list;
	}

}