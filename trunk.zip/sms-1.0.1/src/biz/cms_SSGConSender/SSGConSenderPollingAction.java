package biz.cms_SSGConSender;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

import org.apache.log4j.Logger;

import biz.comm.SFTPManager;

public class SSGConSenderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(SSGConSenderPollingAction.class);
	
	public static void main(String args[]) throws Exception {
		SSGConSenderPollingAction action = new SSGConSenderPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[1]]=" + args[1] );
			System.out.println("[DEBUG] [args[2]]=" + args[2] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd           = nvl(args[1].replaceFirst("-cmd:"  ,""));
			String fileDt        = nvl(args[2].replaceFirst("-fileDt:"  ,""));
			
			
			/*String path          = "C:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
			String cmd 	         = "3";
			String fileDt        = "20180109";*/
			
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			String retMsg = "";
			if("0".equals(cmd)){		//전일자 파일생성 및 전송처리
				action.execute("1");
			}else if("1".equals(cmd)){	//특정일자 파일생성 및 전송
				action.createSSGConTranToFile(fileDt);
				
				Thread.sleep(50);
				
				action.transferSSGConSendFile(fileDt);
			}else if("2".equals(cmd)){	//파일전송만
				action.createSSGConTranToFile(fileDt);
			}else if("3".equals(cmd)){	//파일생성만
				action.createSSGConTranToFile(fileDt);
			}
			
			System.out.println("[Send Data]=" + retMsg);
		}catch(Exception e) {
			System.out.println("[Send Data]=" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	//20171211 KSN SSGCON 전송파일 생성
	@Override
	public void execute(String actionMode) {
		logger.info(":::SEND SSGCON TRAN DATA START:::");
		SSGConSenderDAO dao = new SSGConSenderDAO();
		List<Object> list = null;
		int totalCnt = 0;
		
		try{
			int ret =  -1;
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode != "1" ) return;
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String stdYmd = sdf.format(new Date());
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			//(금일 대사파일 생성 유무 조회)
			list = dao.selSVCFILEDAILY(stdYmd, "SCO", "01", com_cd);
			totalCnt = list.size();
			
			//금일 대사파일 생성 row가 없으면 생성
			if(totalCnt <= 0){
				HashMap<String, String> hm = new HashMap<String, String>();
				hm.put("COM_CD", com_cd);
				hm.put("STD_YMD", stdYmd);
				hm.put("SVC_ID", "SCO");
				hm.put("CMD_TY", "01");
				
				ret = dao.insSVCFILEINFO(hm);
				System.out.println("[INFO] ret::["+ret+"]");
				logger.info("[INFO] ret::["+ret+"]");
				if( ret > 0 ) {
					createSSGConTranToFile(stdYmd);
					
					Thread.sleep(50);
					
					transferSSGConSendFile(stdYmd);
				}
			}
		}catch(Exception e){
			System.out.println("[ERROR] error occur::["+e.getMessage()+"]");
			logger.info("[ERROR] error occur::["+e.getMessage()+"]");
		}
			
	}
	
	public void createSSGConTranToFile(String fileDt) {
		String strTRFileNM = "";
		boolean bIsCreatedFile = false;
		
		try {
			System.out.println("[INFO]:::SSGConSenderPollingAction:::createSSGConTranToFile START.");
			logger.info("[INFO]:::SSGConSenderPollingAction:::createSSGConTranToFile START.");
			
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			SSGConSenderDAO dao = new SSGConSenderDAO();

			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "ssgcon";
			
			strTRFileNM = "EMART24_SSG." + fileDt.substring(2,8);
			System.out.println("[INFO] strTRFileNM::["+strTRFileNM+"]");
			logger.info("[INFO] strTRFileNM::["+strTRFileNM+"]");
			
			list = dao.selSSGConTRAN(com_cd, fileDt);
			System.out.println("[INFO] file_cnt::["+list.size()+"]");
			logger.info("[INFO] file_cnt::["+list.size()+"]");

			// SSG CON 사용내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("HEADER", "10");
			hmHeader.put("SEND_DATE", fileDt);
			hmHeader.put("REQ_CO_NM", "EMART24");
			hmHeader.put("WORK_CNT", "1");
			hmHeader.put("TOT_CNT", String.format("%09d", list.size()));
			hmHeader.put("LF", "\n");
			
			System.out.println("[INFO] hmHeader::["+hmHeader+"]");
			logger.info("[INFO] hmHeader::["+hmHeader+"]");
			sbFile.append(makeHeaderOfSaveListFile(hmHeader));
			
			System.out.println("[INFO] sbFile::["+sbFile+"]");
			logger.info("[INFO] sbFile::["+sbFile+"]");
			
			for(int i = 0;i < list.size();i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				logger.info("[INFO] map::["+map+"]");
				System.out.println("[INFO] map::["+map+"]");
				
				hmData.put("MSG_SEND_DT",			(String)map.get("MSG_SEND_DT"));
				hmData.put("MSG_TRACE_NO",			(String)map.get("TRACE_NO"));
				hmData.put("PTR_ID",				"FM00010770");
				hmData.put("PTR_MCH_ID",			(String)map.get("PTR_MCH_ID"));
				hmData.put("SER_COM_CD",			"5700");
				
				hmData.put("ST_CODE",				(String)map.get("STORE_CD"));
				hmData.put("TM_NO",					(String)map.get("POS_NO"));
				hmData.put("SHOP_NO",				"00000");
				hmData.put("CD_NO",					(String)map.get("CD_NO"));
				hmData.put("TRAN_NO",				"0"+(String)map.get("TRAN_NO"));
				
				hmData.put("CASHER_NO",				(String)map.get("CASHER_NO"));
				hmData.put("TRAN_TYPE",				(String)map.get("TRAN_TYPE"));
				hmData.put("SALE_DATE",				(String)map.get("SALE_DATE"));
				hmData.put("KEY_IN_TYPE",			(String)map.get("KEY_IN_TYPE"));
				hmData.put("TRADE_TYPE",			(String)map.get("TRADE_TYPE"));
				
				hmData.put("USE_FUNC_GUBUN",		(String)map.get("USE_FUNC_GUBUN"));
				hmData.put("USE_GUBUN",				(String)map.get("USE_GUBUN"));
				hmData.put("DELEGATE_BARCODE_NO",	"");
				hmData.put("CPN_NO",				"");
				hmData.put("TOT_TRADE_AMT",			String.format("%012d", Integer.parseInt((String)map.get("TOT_TRADE_AMT"))));
				
				hmData.put("TRADE_AMT",				String.format("%012d", Integer.parseInt((String)map.get("TRADE_AMT"))));
				hmData.put("REMAIN_AMT",			String.format("%012d", Integer.parseInt((String)map.get("REMAIN_AMT"))));
				hmData.put("AUTH_DATE",				(String)map.get("AUTH_DATE"));
				hmData.put("AUTH_TIME",				(String)map.get("AUTH_TIME"));
				hmData.put("AUTH_NO",				(String)map.get("AUTH_NO"));
				
				hmData.put("PRD_ID",				(String)map.get("PRD_ID"));
				hmData.put("PRD_TYPE",				(String)map.get("PRD_TYPE"));
				hmData.put("LF", "\n");

				sbFile.append(makeDataOfSSGConFile(hmData));
			}
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			hmTailer.put("TRAILER", "30");
			hmTailer.put("LF", "\n");
			
			sbFile.append(makeTailerOfSSGConFile(hmTailer));
			
			System.out.println("[INFO] sbFile::["+sbFile+"]");
			logger.info("[INFO] sbFile::["+sbFile+"]");
			
			// SSG CON 전송할 대사파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRFileNM);
			logger.info("<<< SSGMbsTranPollingAction ::: CREATE SAVE FILE RSLT ::: bIsCreatedFile >>> ["+bIsCreatedFile+"]");
			
			if( bIsCreatedFile ) {
				logger.info("[INFO] File ["+strTRFileNM+"] created succ.");
			}else{
				logger.info("[INFO] File ["+strTRFileNM+"] created fail.");
			}
		}catch(Exception e) {
			System.out.println("[ERROR]" + e);
			logger.info("[ERROR]" + e);
		}
	}
	
	
	public void transferSSGConSendFile(String fileDt) {
		logger.info("[INFO] START SEND SSGCON TRAN FILE." );
		
		String ssgcon_ftp_ip = "";
		int ssgcon_ftp_port = 0;
		String ssgcon_ftp_id = "";
		String ssgcon_ftp_pwd = ""; 
		SFTPManager sFtpMgr = null;
		
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isSendOK = false;
		String targetPathNm = ""; 
		String stdDate = "";
		
		String targetFileNm = "";
		
		try {			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "ssgcon";		
			
			if("".equals(fileDt) || fileDt == null){
				Calendar calendar = new GregorianCalendar(Locale.KOREA);
				SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
				calendar.setTime(new Date());
				calendar.add(Calendar.DATE, 1);
				stdDate = sdf.format(calendar.getTime());
			}else{
				stdDate = fileDt.substring(2,8);
			}
			
			logger.info("[INFO] stdDate::["+stdDate+"]");
			
			targetFileNm = "EMART24_SSG." + stdDate;
			
			logger.info("[INFO] targetFileNm::["+targetFileNm+"]");

			ssgcon_ftp_ip = PropertyUtil.findProperty("communication-property", "SSGCON_FTP_IP");
			ssgcon_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGCON_FTP_PORT"));
			ssgcon_ftp_id = PropertyUtil.findProperty("communication-property", "SSGCON_FTP_ID");
			ssgcon_ftp_pwd = PropertyUtil.findProperty("communication-property", "SSGCON_FTP_PW");	
			
			try{				
				sFtpMgr = new SFTPManager(ssgcon_ftp_ip, ssgcon_ftp_port, ssgcon_ftp_id, ssgcon_ftp_pwd);	
				logger.info("[INFO] TRY Connected to " + ssgcon_ftp_ip + ":" + ssgcon_ftp_port);
			}catch(Exception e){
				logger.info("[ERROR] exception occur. "+e.getMessage());
				logger.info("[ERROR] SFTP Connect fail exception occur.");
				return;
			}					
			logger.info("[INFO] SFTP Connection is Success.");	
							
			targetPathNm = destPath + File.separator + targetFileNm;
			isSendOK = false;
			
			iRetry = 0;	
			sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "up"); //up경로 설정(emart24 -> SSG플랫폼)
			
			while( iRetry < 2 ) {	//SSGCON 대사파일 upload 처리. (최대 2번요청처리)
				if( isSendOK = sFtpMgr.put(targetPathNm)) {		
					break;
				}
				iRetry++;
			}			
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}finally {
			try {					
				File oldFileNm = new File(targetPathNm);			
				if( isSendOK ) {
					logger.info("[INFO] successfully upload file ["+targetFileNm+"]");
										
					File newFileNm = new File(targetPathNm +".ok"); // 송신완료한 파일은 rename을 통해 송신완료한 파일인지 구분한다.
					targetFileNm = targetPathNm +".ok";
				
					if(oldFileNm.renameTo(newFileNm)){
						logger.info("[INFO] rename work well done");
					} else {
						logger.info("[ERROR] Failed to rename.");
					}
					
					moveFile(destPath, newFileNm.getName(), destPath + File.separator + "backup");
					logger.info("[INFO] Send SSG coupon tran file is finished.");
					
				}else {
					logger.info("[ERROR] Can't put " + targetFileNm + " to FTP server");
					File newFileNm = new File(targetPathNm +".sendfail");
					targetFileNm = targetPathNm +".sendfail";
					if(oldFileNm.renameTo(newFileNm)){					
						logger.info("[DEBUG] Succeeded to rename.");
					}else {
						logger.info("[DEBUG] Failed to rename.");				
						logger.info("[ERROR2] Can't put file on FTP server");
					}			
				}
			}catch(Exception e) {
				logger.info("[ERROR] Finally process is fail.");
				logger.info("[ERROR] err.msg::["+e.getMessage()+"]");
			}finally{
				try{
					if( !sFtpMgr.isClosed() ){ //ftp 연결종료
				    	sFtpMgr.logout();
				    }
				}catch(Exception e){
					
				}
			}
		}
	}
	
	
	private String makeHeaderOfSaveListFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2, 8, 64, 1, 9, 1};
		String strHeaders[] = {
			"HEADER",
			"SEND_DATE",
			"REQ_CO_NM",
			"WORK_CNT",
			"TOT_CNT",
			"LF"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	private String makeDataOfSSGConFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {8, 26, 15, 15, 4,
					   10, 4, 5, 4, 5,
					   10, 2, 8, 2, 2,
					   1, 1, 64, 64, 12,
					   12, 12, 8, 6, 8,
					   20, 4, 1
					  };
		String strHeaders[] = {
			"MSG_SEND_DT",
			"MSG_TRACE_NO",
			"PTR_ID",
			"PTR_MCH_ID",
			"SER_COM_CD",
			
			"ST_CODE",
			"TM_NO",
			"SHOP_NO",
			"CD_NO",
			"TRAN_NO",
			
			"CASHER_NO",
			"TRAN_TYPE",
			"SALE_DATE",
			"KEY_IN_TYPE",
			"TRADE_TYPE",
			
			"USE_FUNC_GUBUN",
			"USE_GUBUN",
			"DELEGATE_BARCODE_NO",
			"CPN_NO",
			"TOT_TRADE_AMT",
			
			"TRADE_AMT",
			"REMAIN_AMT",
			"AUTH_DATE",
			"AUTH_TIME",
			"AUTH_NO",
			
			"PRD_ID",
			"PRD_TYPE",
			"LF"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {	
			System.out.println("[INFO] "+strHeaders[i].toString()+"::["+(String) hm.get(strHeaders[i].toString())+"]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	private String makeTailerOfSSGConFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2, 1};
		String strHeaders[] = {
			"TRAILER",
			"LF"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();

			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
		}
		
		return dirFileList;
	}
	
	
	public void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}else {
					if( sendingFile.renameTo(sendedFile) ) {
						break;
					}
				}
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("[ERROR] " + ie.getMessage());
				}
			}
		}
	}
}
