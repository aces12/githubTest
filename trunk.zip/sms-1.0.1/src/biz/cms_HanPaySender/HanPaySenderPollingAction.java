package biz.cms_HanPaySender;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_CashBeeSender.CashBeeSenderDAO;
import biz.cms_CashBeeSender.CashBeeSenderFileTransfer;
import biz.cms_TMoneySender.TMoneySenderFileTransfer;
import biz.cms_TMoneySender.TMoneySenderPollingAction;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

public class HanPaySenderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(HanPaySenderPollingAction.class);
	
	public static void main(String args[]) throws Exception {
		HanPaySenderPollingAction action = new HanPaySenderPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[0]]=" + args[1] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			if( cmd.length() != 3 ) return;
			
			if( cmd.charAt(0) == '1' ) {
				System.out.println("creating HanPay Payment tran file.");
				action.createHanPayPAYTranFile();
			}
			
			if( cmd.charAt(1) == '1' ) {
				System.out.println("creating HanPay Charge tran file.");
				action.createHanPayCHGTranFile();
			}
			
			if( cmd.charAt(2) == '1' ) {
				System.out.println("transfering HanPay tran files.");
				(new HanPaySenderFileTransfer()).transfer();
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		HanPaySenderDAO dao = new HanPaySenderDAO();
		List<Object> list = null;
		int totalCnt = 0;
		
		try {
			int ret = -1;
			
			// actionMode : 0-POLLING_PERIOD에 주기적으로 무조건 수행, 1-ACTION_TIME에 한 번 수행
			if( actionMode == "1" ) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String stdYmd = sdf.format(new Date());
				String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
				
				//(금일 대사파일 생성 유무 조회)
				list = dao.selSVCFILEDAILY(stdYmd, "HAN", "%", com_cd);
				totalCnt = list.size();
				
				//금일 대사파일 생성 row가 없으면 생성
				if( totalCnt <= 0 ) {
					HashMap<String, String> hm = new HashMap<String, String>();
					hm.put("COM_CD", com_cd);
					hm.put("STD_YMD", stdYmd);
					hm.put("SVC_ID", "HAN");
					hm.put("CMD_TY", "00");
					
					ret = dao.insSVCFILEINFO(hm);
						
					if( ret > 0 ) {
						createHanPayCHGTranFile();
						Thread.sleep(50);
						
						createHanPayPAYTranFile();
						Thread.sleep(50);
						
						try {
							(new HanPaySenderFileTransfer()).transfer();
						}catch(Exception e) {
							logger.info("[ERROR]" + e.getMessage());
						}
						hm.put("CMD_TY", "01");
						ret = dao.updSVCFILEINFO(hm);
					}
				}
			}else if( actionMode == "0") {
				
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	public boolean createHanPayPAYTranFile() {
		boolean bIsCreatedFile = false;
		
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			HanPaySenderDAO dao = new HanPaySenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			//String toDay = sdf.format(calendar.getTime());
			//calendar.setTime(sdf.parse(toDay));
			calendar.setTime(new Date());
			String curDate = sdf.format(calendar.getTime());
			calendar.add(Calendar.DATE, -1);
			String adjDate = sdf.format(calendar.getTime());
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "hanpay";
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			
			list = dao.getWITHMEBizCoNo(com_cd);
			String strWithMeBizCoNo = (String)((Map<String, String>)list.get(0)).get("BIZCO_NO");
			
			// 전송 파일명 체계
			// 온라인충전 거래내역 파일    : 사업자번호.AC15.MMDD
			// 온라인충전 정산결과 파일    : 사업자번호.AC07.MMDD
			// 지불거래내역 파일               : 사업자번호.BC12.MMDD
			// 지불거래내역 정산결과 파일 : 사업자번호.BC02.MMDD
			// 카드발행사 정보 파일           : 사업자번호.BC06.MMDD
			String JOB_TP = "BC12";
			String strTRANFileNM = strWithMeBizCoNo + "." + JOB_TP + "." + curDate.substring(4, 8);
			
			list = null;
			list = dao.selHANPAYPAYTRAN(com_cd, card_key, double_card_key);
			int iPayCnt = list.size();
			
			// 거래내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_TP", "H");
			hmHeader.put("JOB_TP", JOB_TP);
			hmHeader.put("FILE_CRTD_YMDHMS", curDate);
			hmHeader.put("TRANS_CNT", String.format("%07d", iPayCnt));
			hmHeader.put("ADJ_YMD", adjDate.substring(0, 8));
			hmHeader.put("FILLER", " ");
			
			sbFile.append(makeHeaderOfFile(hmHeader));
			
			for(int i = 0;i < iPayCnt;i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				hmData.put("RECORD_TP", "D");
				hmData.put("JOB_TP", JOB_TP);
				hmData.put("SEQ_NO", String.format("%07d", i + 1));
				hmData.put("FCSTR_CO_REG_NO", map.get("FCSTR_CO_REG_NO"));
				hmData.put("TRAN_UNQ_NO", map.get("TRAN_UNQ_NO"));
				hmData.put("BEF_TRAN_UNQ_NO", " ");
				hmData.put("TRAN_DTM", map.get("TRAN_DTM"));
				hmData.put("TMNAL_ID", map.get("TMNAL_ID"));
				hmData.put("HANPY_HOLDER_TP", map.get("HANPY_HOLDER_TP"));
				hmData.put("CARD_TP_VAL", map.get("CARD_TP_VAL"));
				hmData.put("ALGO_ID", map.get("ALGO_NO"));
				hmData.put("KEY_VER_2", map.get("KEY_VER_2"));
				hmData.put("TRAN_TP", map.get("TRAN_TP"));
				hmData.put("KEY_VER_1", map.get("KEY_VER_1"));
				hmData.put("ELE_MONY_IDTY", map.get("ELE_MONY_IDTY"));
				hmData.put("PPCARD_NO", map.get("PPCARD_NO"));
				hmData.put("PPCARD_TRAN_SEQ_NO", map.get("PPCARD_TRAN_SEQ_NO"));
				hmData.put("PPCARD_REM_AMT", String.format("%08X", Integer.parseInt(((String)map.get("PPCARD_REM_AMT").trim()))));
				hmData.put("PPCARD_REQ_AMT", String.format("%08X", Integer.parseInt(((String)map.get("PPCARD_REQ_AMT").trim()))));
				hmData.put("PSAM_ID", map.get("PSAM_ID"));
				hmData.put("PSAM_TRAN_SEQ_NO", map.get("PSAM_TRAN_SEQ_NO"));
				hmData.put("PSAM_TOT_AMT_COLECT_SEQ_NO", map.get("PSAM_TOT_AMT_COLECT_SEQ_NO"));
				hmData.put("PSAM_SPBY_COLECT_CNT", map.get("PSAM_SPBY_COLECT_CNT"));
				hmData.put("PSAM_ACCM_TOT_AMT", map.get("PSAM_ACCM_TOT_AMT"));
				hmData.put("SIGN_VAL_1", map.get("SIGN_VAL_1"));
				hmData.put("SIGN_VAL_2", map.get("SIGN_VAL_2"));
				hmData.put("REFUND_FEE", String.format("%013d", Integer.parseInt(((String)map.get("REFUND_FEE")).trim())));
				if( ((String)map.get("PROC_ID")).equals("0") ) {
					hmData.put("TRANS_TP", "00");
				}else {
					hmData.put("TRANS_TP", "01");
				}
				hmData.put("FILLER", " ");
				
				sbFile.append(makeDataOfHanPayPAYFile(hmData));
			}
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			hmTailer.put("RECORD_TP", "T");
			hmTailer.put("JOB_TP", JOB_TP);
			hmTailer.put("TRANS_CNT", String.format("%07d", iPayCnt));
			hmTailer.put("FILLER", " ");
			sbFile.append(makeTailerOfHanPayTranFile(hmTailer));
			
			// 거래내역 파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRANFileNM);
			
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRANFileNM);
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					dao.updHANPAYPAYTRAN("1", (String)map.get("COM_CD"), (String)map.get("TRAN_UNQ_NO"));
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
	
	public boolean createHanPayCHGTranFile() {
		boolean bIsCreatedFile = false;
		
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			HanPaySenderDAO dao = new HanPaySenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			//String toDay = sdf.format(calendar.getTime());
			//calendar.setTime(sdf.parse(toDay));
			calendar.setTime(new Date());
			String curDate = sdf.format(calendar.getTime());
			calendar.add(Calendar.DATE, -1);
			String adjDate = sdf.format(calendar.getTime());
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "hanpay";
			
			list = dao.getWITHMEBizCoNo(com_cd);
			String strWithMeBizCoNo = (String)((Map<String, String>)list.get(0)).get("BIZCO_NO");
			
			// 전송 파일명 체계
			// 온라인충전 거래내역 파일    : 사업자번호.AC15.MMDD
			// 온라인충전 정산결과 파일    : 사업자번호.AC07.MMDD
			// 지불거래내역 파일               : 사업자번호.BC12.MMDD
			// 지불거래내역 정산결과 파일 : 사업자번호.BC02.MMDD
			// 카드발행사 정보 파일           : 사업자번호.BC06.MMDD
			String JOB_TP = "AC15";
			String strTRANFileNM = strWithMeBizCoNo + "." + JOB_TP + "." + curDate.substring(4, 8);
			
			list = null;
			list = dao.selHANPAYCHGTRAN(com_cd, card_key, double_card_key);
			int iChgCnt = list.size();
			
			// 거래내역 파일(Header)
			HashMap<String, String> hmHeader = new HashMap<String, String>();
			hmHeader.put("RECORD_TP", "H");
			hmHeader.put("JOB_TP", JOB_TP);
			hmHeader.put("FILE_CRTD_YMDHMS", curDate);
			hmHeader.put("TRANS_CNT", String.format("%07d", iChgCnt));
			hmHeader.put("ADJ_YMD", adjDate.substring(0, 8));
			hmHeader.put("FILLER", " ");
			
			sbFile.append(makeHeaderOfFile(hmHeader));
			
			for(int i = 0;i < iChgCnt;i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				hmData.put("RECORD_TP", "D");
				hmData.put("JOB_TP", JOB_TP);
				hmData.put("SEQ_NO", String.format("%07d", i + 1));
				hmData.put("TRAN_UNQ_NO", map.get("TRAN_UNQ_NO"));
				hmData.put("FCSTR_ID", map.get("FCSTR_ID"));
				hmData.put("PPCARD_NO", map.get("PPCARD_NO"));
				hmData.put("CARD_CO_TP", map.get("CARD_CO_TP"));
				hmData.put("TRAN_DTM", map.get("TRAN_DTM"));
				hmData.put("ADJT_YMD", map.get("ADJT_YMD"));
				hmData.put("TMNAL_ID", map.get("TMNAL_ID"));
				hmData.put("LSAM_ID", map.get("LSAM_ID"));
				hmData.put("HANPY_TASK_TP", map.get("HANPY_TASK_TP"));
				hmData.put("HANPY_PAY_TP", map.get("HANPY_PAY_TP"));
				hmData.put("PPCARD_REQ_AMT", String.format("%010d", Integer.parseInt(((String)map.get("PPCARD_REQ_AMT")).trim())));
				hmData.put("PPCARD_REM_AMT", String.format("%010d", Integer.parseInt(((String)map.get("PPCARD_REM_AMT")).trim())));
				hmData.put("REFUND_TP", map.get("REFUND_TP"));
				hmData.put("ORG_TRAN_UNQ_NO", map.get("ORG_TRAN_UNQ_NO"));
				hmData.put("ERR_CD", "0001");
				hmData.put("CCARD_CO_TP", map.get("CCARD_CO_TP"));
				hmData.put("CCARD_FEE", " ");
				hmData.put("FILLER", " ");
				
				sbFile.append(makeDataOfHanPayCHGFile(hmData));
			}
			
			HashMap<String, String> hmTailer = new HashMap<String, String>();
			hmTailer.put("RECORD_TP", "T");
			hmTailer.put("JOB_TP", JOB_TP);
			hmTailer.put("TRANS_CNT", String.format("%07d", iChgCnt));
			hmTailer.put("FILLER", " ");
			sbFile.append(makeTailerOfHanPayTranFile(hmTailer));
			
			// 거래내역 파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRANFileNM);
			
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRANFileNM);
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					dao.updHANPAYCHGTRAN("1", (String)map.get("COM_CD"), (String)map.get("TRAN_UNQ_NO"));
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
	
	private String makeHeaderOfFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,6,14,7,8
					  ,264};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"FILE_CRTD_YMDHMS",
			"TRANS_CNT",
			"ADJ_YMD",
			
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeDataOfHanPayPAYFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,6,7,10,20
					  ,20,14,10,4,2
					  ,2,2,2,2,2
					  ,16,8,8,8,16
					  ,8,8,4,8,8
					  ,8,13,2,81};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"SEQ_NO",
			"FCSTR_CO_REG_NO",
			"TRAN_UNQ_NO",
			
			"BEF_TRAN_UNQ_NO",
			"TRAN_DTM",
			"TMNAL_ID",
			"HANPY_HOLDER_TP",
			"CARD_TP_VAL",
			
			"ALGO_ID",
			"KEY_VER_2",
			"TRAN_TP",
			"KEY_VER_1",
			"ELE_MONY_IDTY",
			
			"PPCARD_NO",
			"PPCARD_TRAN_SEQ_NO",
			"PPCARD_REM_AMT",
			"PPCARD_REQ_AMT",
			"PSAM_ID",
			
			"PSAM_TRAN_SEQ_NO",
			"PSAM_TOT_AMT_COLECT_SEQ_NO",
			"PSAM_SPBY_COLECT_CNT",
			"PSAM_ACCM_TOT_AMT",
			"SIGN_VAL_1",
			
			"SIGN_VAL_2",
			"REFUND_FEE",
			"TRANS_TP",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeDataOfHanPayCHGFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,6,7,18,15
					  ,16,2,14,8,10
					  ,16,2,2,10,10
					  ,2,20,4,2,8
					  ,127};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"SEQ_NO",
			"TRAN_UNQ_NO",
			"FCSTR_ID",
			
			"PPCARD_NO",
			"CARD_CO_TP",
			"TRAN_DTM",
			"ADJT_YMD",
			"TMNAL_ID",
			
			"LSAM_ID",
			"HANPY_TASK_TP",
			"HANPY_PAY_TP",
			"PPCARD_REQ_AMT",
			"PPCARD_REM_AMT",
			
			"REFUND_TP",
			"ORG_TRAN_UNQ_NO",
			"ERR_CD",
			"CCARD_CO_TP",
			"CCARD_FEE",
			
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
//			System.out.println(strHeaders[i].toString()+"="+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeTailerOfHanPayTranFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,6,7,286};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"TRANS_CNT",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
//			System.out.println(strHeaders[i].toString()+"="+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
}
