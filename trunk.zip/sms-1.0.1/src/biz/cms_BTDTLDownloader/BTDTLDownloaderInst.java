package biz.cms_BTDTLDownloader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

public class BTDTLDownloaderInst extends Thread {
	private static Logger logger = Logger.getLogger(BTDTLDownloaderPollingAction.class);
	
	String path = "";
	
	public BTDTLDownloaderInst(String path) {
		this.path = path;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
	public void deleteFile(String path, String fileNM) {
		File file = new File(path + File.separator + fileNM);
		if( file.exists() ) {
			logger.info("File Name : " + path + File.separator + fileNM);
			if( file.delete() ) {
				logger.info("File(" + path + File.separator + fileNM + ") removed !!!");
			}
		}
	}
	
	public void copyFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdirs();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(orgFile);
			fos = new FileOutputStream(destFile);
			
			int data = 0;
			while( (data = fis.read()) != -1 ) {
				fos.write(data);
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			try {
				fis.close();
				fis = null;
				fos.flush();
				fos.close();
				fos = null;
				System.gc();
			}catch(Exception e) {
				logger.info(e.getMessage());
			}
		}
		
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public void run() {
		int ret = 0;
//		boolean bIsDaily = true;
		BufferedReader bin = null;
		StringTokenizer st = null;
		String readedLine = "";
		try {
			BTDTLDownloaderDAO dao = new BTDTLDownloaderDAO();
			
			List<File> list = getDirFileList(path);
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			for(int i = 0;i < list.size();i++) {
				if( !(list.get(i)).isFile() ) {
					continue;
				}else if( (list.get(i)).length() == 0 ){
					(list.get(i)).delete();
					continue;
				}
				String targetFile = list.get(i).getName();
				bin = new BufferedReader(new FileReader(path + File.separator + targetFile));
				
//				if( targetFile.substring(17, 18).equals("D") ) {
//					bIsDaily = true;
//				}else if( targetFile.substring(17, 18).equals("W") ) {
//					bIsDaily = false;
//				}
				
				while( (readedLine = bin.readLine()) != null ) {
					logger.info("[DEBUG] File Name : " + targetFile + ", readedLine = " + readedLine);
					// '\t'와'\n' 구분자로 토큰 분리
					st = new StringTokenizer(readedLine, "\t\n");
					
					int col = 0;
					Map<String, String> map = new HashMap<String, String>();
					String strHeaders[] = {
						"APPR_NO",						// 1.승인번호
						"APPR_FCSTR_UNQ_NO",			// 2.승인전문고유ID
						"CNCL_FCSTR_UNQ_NO",			// 3.취소전문고유ID
						"STORE_CD",						// 4.점포코드(사업장조직코드)
						"PIN_BARCD_NO",					// 5.상품바코드번호
						"AMT",							// 6.금액
						"APPR_DTM",						// 7.승인일시
						"CNCL_DTM",						// 8.취소일시
						"NOR_CNCL_TP",					// 9.정상취소구분
						"MOBILE_PAY_METHOD_TP"			// 10.주결제수단
					};
					map.put("CO_CD", com_cd);
					map.put("ADJT_DT", targetFile.substring(8, 16));				// 정산일자
					map.put("MOBILE_VEN_TP", "01");									// 모바일업체구분
					// 각 분리된 토큰을 저장
					while( st.hasMoreTokens() ) {
						map.put(strHeaders[col++], st.nextToken().trim());
						logger.info("☆  value[" + Integer.toString(col-1) + "] = " + map.get(strHeaders[col-1]));
					}
//					if( bIsDaily ) {
						ret = dao.insBTDailyDTL(map);
//					}else {
//						ret = dao.insBTMonthlyDTL(map);
//					}
					if( ret != 1 ) {
						logger.info("["+targetFile+"]"+"There is an Error on inserting data");
					}
				}
				bin.close();
				bin = null;
				this.moveFile(path, targetFile, path + File.separator + "backup");
			}
		}catch(Exception e) {
			logger.info("[ERROR1] " + e.getMessage());
		}finally {
			try {
				if( bin != null ) bin.close();
			}catch(Exception e) {}
		}
	}
}