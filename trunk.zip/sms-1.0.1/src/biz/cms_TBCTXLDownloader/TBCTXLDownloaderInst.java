package biz.cms_TBCTXLDownloader;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.cms_TranRcv.TranRcvDAO;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class TBCTXLDownloaderInst extends Thread {
	private static Logger logger = Logger.getLogger(TBCTXLDownloaderPollingAction.class);
	private final int LENGTH_BY_DATA_RECORD = 1138;
	private final int LENGTH_BY_CARD_START = 1000; //714
	private final int LENGTH_BY_CARD_LEN = 20; //714
	String path = "";
	
	public TBCTXLDownloaderInst(String path) {
		this.path = path;
	}
	
	public void run() {
		String fileNM = "";
		
		try {
			List<File> file = getDirFileList(path);

			logger.info("[INFO] FILE_PATH::["+path+"]");
			logger.info("[INFO] FILE_CNT::["+Integer.toString(file.size())+"]::FILE_SIZE::["+Integer.toString(file.size())+"]");
			
			for(int i = 0;i < file.size();i++) {
				fileNM = file.get(i).getName();
				
				logger.info("[INFO] FILE_NM::["+fileNM+"]");
				
				int len = 0;
				int totLen = 0;
				long fileSize = (file.get(i)).length();
				logger.info("[INFO] FILE_SIZE::["+fileSize+"]");
				
				byte buf[] = new byte[(int)fileSize];
				InputStream is = new FileInputStream(file.get(i));
				
				StringBuffer sb = new StringBuffer();
				
				while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
					sb.append(new String(buf));
					totLen += len;
					logger.info("[INFO] FILE_SIZE::["+fileSize+"]::TOT_LEN::["+totLen+"]");
					if( totLen == fileSize ) {
						break;
					}
				}
				is.close();
				
				logger.info("[INFO] FILE_NM::["+fileNM.substring(0, 4)+"]");
				
				if( "EMT.".equals(fileNM.substring(0, 4)) ) { //담배자판기 I/F 파일명
					logger.info("[INFO] ===== TBC I/F DATA INSERT START =====");
					logger.info("[INFO] SB_DATA::["+sb.toString()+"]");
					this.insertDB(sb.toString());
				}
				
				// 파일 옮기기...
				moveFile(path, fileNM, path + File.separator + "backup");
				logger.info("[DEBUG] File " + fileNM + " processed successfuly.");
				System.out.println("[DEBUG] File " + fileNM + " processed successfuly.");
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
			System.out.println("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertDB(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			HashMap hmCommon = new HashMap(); 
			HashMap hmData = new HashMap();
			int ret = 0;			
			TranRcvDAO dao = new TranRcvDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			readData = readData.replaceAll("\r|\n", "");
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			
			logger.info("[INFO] BYTE_LEN::["+bytes.length+"]"); //파일 총 byte
			
			for(int i = 0; totLen<bytes.length; i++) {
				String strRecord = "";
				strRecord = new String(bytes, i*LENGTH_BY_DATA_RECORD, LENGTH_BY_DATA_RECORD);
				totLen += LENGTH_BY_DATA_RECORD;
				
				logger.info("[INFO] NEW_DATA::["+strRecord+"]::totLen::["+totLen+"]");
				
				hmCommon = COMMBiz.getData(strRecord, COMMBiz.CM_HEADER);
				
				if ( !(COMMBiz.getCommMsgType(hmCommon, COMMBiz.TRAN)) ) {	
					return;
				}
				
				hmData = COMMBiz.getData(strRecord, COMMBiz.TR_HEADER);
				if (COMMBiz.getTranType(hmData) == COMMBiz.ERR) {
					try{
						ret = dao.setErrData(strRecord);
					}catch(Exception e){
						logger.info("[ERROR] ERR_MSG::["+e.getMessage()+"]");
					}
				} else { 
					try{
						ret = dao.setData(hmData, strRecord, COMMBiz.TB_INS_STTRP010DT);
					}catch(Exception e){
						logger.info("[ERROR] ERR_MSG::["+e.getMessage()+"]");
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
			System.out.println("[ERROR] " + e.getMessage());
		}
	}
	
	
	public void moveFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdir();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		logger.info("orgFile = " + orgPath + File.separator + fileNM);
		logger.info("destFile = " + destPath + File.separator + fileNM);
		
		if( destFile.exists() ) {
			if( orgFile.delete() ) {
				logger.info("[DEBUG] File(" + orgFile.getPath() + " / "+ orgFile.getName() + ") Deleted");
			}else {
				logger.info("[DEBUG] Fail to remove file(" + orgFile.getPath() + " / "+ orgFile.getName() + ")");
			}
		}else {
			for(int i = 0;i < 20;i++) {
				if( orgFile.renameTo(destFile) ) {
					logger.info(">> MOVE OK : " + destFile.getName());
					
					File file = new File(destPath + File.separator + fileNM);
					File fileOK = new File(destPath + File.separator + fileNM.concat(".ok"));
					file.renameTo(fileOK);//다운로드 완료시 파일명에 .ok 추가
					break;
				}
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
//			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
}