package biz.cms_TBCTXLDownloader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;

import org.apache.log4j.Logger;

import biz.cms_CashBeeSender.CashBeeSenderProtocol;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;
import biz.comm.SFTPManager;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.util.StringUtil;

/**
 * Receive data from SC through 9013 PORT(SC로부터 데이타를 9013 PORT로 받음).
 * 
 * @param ActionSocket
 * @return
 * @throws Exception
 */
public abstract class TBCReceiverPollingAction_test extends ServerAction {
	private static Logger logger = Logger.getLogger(TBCReceiverPollingAction_test.class);
	
	private String ubcn_ftp_ip = "";
	private int ubcn_ftp_port = 0;
	private String ubcn_ftp_id = "";
	private String ubcn_ftp_pwd = "";
	
	public static void main(String args[]) throws Exception {
		try {
			/*if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}*/
			/*System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[1]]=" + args[1] );
			System.out.println("[DEBUG] [args[2]]=" + args[2] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String fileDt        = nvl(args[1].replaceFirst("-fileDt:"  ,""));
			String seq        	 = nvl(args[2].replaceFirst("-seq:"  ,""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);*/
			
			//String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			//String destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "ubcn";
			//TBCReceiverInst inst = new TBCReceiverInst(destPath);
			
			//inst.start();
			String actionMode = "1";
			//20171121 KTOTO 발매중단에 따른 대사파일 미수신 기간 설정 2017-11-21~2017-11-27
			Calendar sysCal = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			sysCal.setTime(new Date());
			String chkIcomSysDt = sdf.format(sysCal.getTime());
			if(("20171121".compareTo(chkIcomSysDt) == 0 || "20171121".compareTo(chkIcomSysDt) < 0 )
					&& ("20171127".compareTo(chkIcomSysDt) == 0 || "20171127".compareTo(chkIcomSysDt) > 0 )){
				actionMode = "0";
			}
			
			System.out.println("actionMode : "+actionMode);
			//20171121 KTOTO 발매중단에 따른 대사파일 미수신 기간 설정
			
			//TBCReceiverPollingAction_test.execute("1");
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public static void execute(String actionMode) throws Exception {
		
		System.out.println("===== TBCReceiverPollingAction START =====");
		
		/*SFTPManager sFtpMgr = null;
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";*/
		int iRetry = 0;
		boolean isDownOK = false;
		String FileNm = "";
		
		try{	
			//10분 주기마다 수행되는 배치
			
			//ubcn ftp 정보 set
			/*this.ubcn_ftp_ip = PropertyUtil.findProperty("communication-property", "UBCN_FTP_SERVER_IP");
			this.ubcn_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "UBCN_FTP_SERVER_PORT"));
			this.ubcn_ftp_id = PropertyUtil.findProperty("communication-property", "UBCN_FTP_SERVER_ID");
			this.ubcn_ftp_pwd = PropertyUtil.findProperty("communication-property", "UBCN_FTP_SERVER_PWD");
			
			System.out.println("[INFO] Trying UBCN SFTP Connection...");
			try{		
				System.out.println("[INFO] TRY Connected to " + ubcn_ftp_ip + ":" + ubcn_ftp_port);
				sFtpMgr = new SFTPManager(ubcn_ftp_ip, ubcn_ftp_port, ubcn_ftp_id, ubcn_ftp_pwd);	
			}catch(Exception e){
				System.out.println("[INFO] exception occur"+e.getMessage());
				System.out.println("[INFO] SFTP Connect fail exception occur.");
				return;
			}
			
			System.out.println("[INFO] SFTP Connection is Success.");
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "ubcn";
			
			File destDir = new File(destPath);
			
			if( !destDir.exists() ) {
				destDir.mkdir();
				System.out.println("[INFO] Try to make dir" );
			}
			*/
			isDownOK = false;
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
			calendar.setTime(new Date());
			String fileDt = sdf.format(calendar.getTime());
			fileDt = fileDt.substring(0,11);
			
			System.out.println("[INFO] fileDt:["+fileDt+"]");
			
			//파일명 UBCN.yyyyMMddHHmm
			iRetry = 0;
			String downTargetFileNM = "UBCN." + fileDt;
			FileNm = "UBCN." + fileDt;
			
			System.out.println("[INFO] TBCReceiverPollingAction::downTargetFileNM::["+downTargetFileNM+"]::FileNm::["+FileNm+"]");
			//bos = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + FileNm));
			
			/*while (iRetry < 2) {
				logger.info("[INFO] TBCReceiverPollingAction::iRetry::["+iRetry+"]");
		    	if ((isDownOK = sFtpMgr.get(downTargetFileNM, bos))) {
		    		logger.info("[INFO] Download file succ.");
		          break;
		        }
		        iRetry++;
	        }
			logger.info("[INFO] TBCReceiverPollingAction::isDownOK::["+isDownOK+"]");
			
			bos.flush();
	        bos.close();
		    bos = null;
		    System.gc();*/
		    
		    if(isDownOK){
		    	logger.info("[INFO] successfully downloaded file ["+downTargetFileNM+"]");
		    }else{
		    	
		    }
			
		}catch(Exception e){
			
		}
	}
}