package biz.cms_DGBReceiver;

import java.util.HashMap;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class DGBReceiverDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(DGBReceiverAction.class);
	
	public int insDGBCHRGADJTRslt_HDR(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_DGBCHRGADJTRSLT_HDR"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
			sql.setString(++i, (String)hm.get("TOT_RECHRG_CNT"));
			sql.setString(++i, (String)hm.get("TOT_CHRG_CNT"));
			sql.setString(++i, (String)hm.get("TOT_CHRG_AMT"));
			sql.setString(++i, (String)hm.get("TOT_CHRG_FEE"));
			sql.setString(++i, (String)hm.get("TOT_CHRG_CANCEL_CNT"));
			sql.setString(++i, (String)hm.get("TOT_CHRG_CANCEL_AMT"));
			sql.setString(++i, (String)hm.get("TOT_CHRG_CANCEL_FEE"));
			sql.setString(++i, (String)hm.get("TOT_RETURN_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RETURN_AMT"));
			sql.setString(++i, (String)hm.get("TOT_RETURN_FEE"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insDGBCHRGADJTRslt_DAT(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_DGBCHRGADJTRSLT_DTL"));
			sql.setString(++i, (String)hm.get("CO_CD")); //회사코드
			sql.setString(++i, (String)hm.get("ADJT_DT")); //정산일자
			sql.setString(++i, "A16" + (String)hm.get("FCSTR_ID")); //사업장조직코드
			sql.setString(++i, (String)hm.get("STORE_ID"));		//편의점ID[13]
			sql.setString(++i, (String)hm.get("TRAN_UNIQ_NO"));	//거래관리번호[18]
			sql.setString(++i, (String)hm.get("TRAN_DT"));		//거래일시[14]
			sql.setString(++i, (String)hm.get("TMNAL_ID"));		//단말기ID[10]
			sql.setString(++i, (String)hm.get("CARD_CORP_CD"));	//카드사코드[2]
			sql.setString(++i, (String)hm.get("CARD_NO"));		//카드일련번호[16]
			sql.setString(++i, (String)hm.get("CARD_KEY"));
			sql.setString(++i, (String)hm.get("DOUBLE_CARD_KEY"));
			sql.setString(++i, "");								//카드소지자구분[4] 대사내역없음
			sql.setString(++i, (String)hm.get("CARD_CNT"));		//카드거래카운트[8]
			sql.setString(++i, (String)hm.get("TRT"));			//거래유형코드[2]
			sql.setString(++i, (String)hm.get("TRAN_AMT"));		//거래금액[8]
			sql.setString(++i, (String)hm.get("RES_AMT"));		//거래전잔액[8]
			sql.setString(++i, (String)hm.get("REQ_AMT"));		//거래후잔액[8]
			sql.setString(++i, (String)hm.get("RETURN_TP"));	//반품충전구분[2]
			sql.setString(++i, (String)hm.get("ORG_UNIQ_NO"));	//지불거래관리번호[18]
			sql.setString(++i, (String)hm.get("ERR_CD"));		//제휴편의점개별오류코드[4]
			sql.setString(++i, (String)hm.get("RES_DT"));		//거래일시[14]
			sql.setString(++i, (String)hm.get("TOT_REQ_DT"));	//거래완료응답일시[14]
			sql.setString(++i, (String)hm.get("PENALTY_AMT"));	//거래수수료[8]
			sql.setString(++i, (String)hm.get("RESULT"));		//응답오류코드[2]
			//logger.info(sql.debug());
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insDGBCHRGADJTRsltByFcstrID_1_DAT(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();	
			//DB Connection(DB 접속)
			connect("CMGNS");                                           
			
			sql.put(findQuery("service-sql", "INS_DGBCHRGADJTRSLTBYFCSTRID_DTL_1"));
			sql.setString(++i, (String)hm.get("CO_CD"));				//회사코드
			sql.setString(++i, (String)hm.get("ADJT_DT"));				//정산일자
//			sql.setString(++i, (String)hm.get("WM_STORE_CD").trim());	//사업장조직코드 BIZLOC_ORG_CD
			sql.setString(++i, (String)hm.get("TOT_CHRG_CNT"));		//총충전건수
			sql.setString(++i, (String)hm.get("TOT_CHRG_AMT"));		//총충전금액
			sql.setString(++i, (String)hm.get("TOT_CHRG_FEE"));		//총충전수수료
			sql.setString(++i, (String)hm.get("TOT_CHRG_CANCLE_CNT"));	//취소건수
			sql.setString(++i, (String)hm.get("TOT_CHRG_CANCLE_AMT"));	//취소금액
			sql.setString(++i, (String)hm.get("TOT_CHRG_CANCLE_FEE"));	//취소수수료
			sql.setString(++i, (String)hm.get("TOT_RETURN_CNT"));	//반품건수
			sql.setString(++i, (String)hm.get("TOT_RETURN_AMT"));	//반품금액
			sql.setString(++i, (String)hm.get("TOT_RETURN_FEE"));	//반품수수료
			sql.setString(++i, (String)hm.get("TOT_REFUND_CNT"));	//환불
			sql.setString(++i, (String)hm.get("TOT_REFUND_AMT"));
			sql.setString(++i, (String)hm.get("TOT_REFUND_FEE"));

			logger.info("sql[" + sql.debug() + "]");
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insDGBCHRGADJTRsltByFcstrID_2_DAT(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();                             
			//DB Connection(DB 접속)
			connect("CMGNS");
                                                             
			sql.put(findQuery("service-sql", "INS_DGBCHRGADJTRSLTBYFCSTRID_DTL_2"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
//			sql.setString(++i, (String)hm.get("WM_STORE_CD").trim());
			sql.setString(++i, (String)hm.get("TOT_RESULT_CNT"));			//총지불건수
			sql.setString(++i, (String)hm.get("TOT_RESULT_AMT"));			//총지불금액
			sql.setString(++i, (String)hm.get("TOT_RESULT_FEE"));			//총지불수수료
			sql.setString(++i, (String)hm.get("TOT_ADJT_CNT"));			//총청구건수
			sql.setString(++i, (String)hm.get("TOT_ADJT_AMT"));			//총청구금액
			sql.setString(++i, (String)hm.get("TOT_RESEND_CNT"));		//총반송건수
			sql.setString(++i, (String)hm.get("TOT_RESEND_AMT"));		//총반송금액

			logger.info("sql[" + sql.debug() + "]");
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int updDGBPAYMENT_DTL(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			if( ((String)hm.get("PROC_ID")).equals("3") ) {	// 반송
				sql.put(findQuery("service-sql", "UPD_DGBPAYMENT_DTL2"));
			}else {	// 정상
				sql.put(findQuery("service-sql", "UPD_DGBPAYMENT_DTL"));
			}
			sql.setString(++i, (String)hm.get("FEE"));
			sql.setString(++i, (String)hm.get("RESULT"));
			sql.setString(++i, (String)hm.get("FILE_MK_DT"));
			sql.setString(++i, (String)hm.get("PROC_ID"));
			sql.setString(++i, ((String)hm.get("TRAN_UNIQ_NO")).trim());
			sql.setString(++i, (String)hm.get("CO_CD"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int updDGBPAYMENT_TRL(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_DGBPAYMENT_DTL2"));
			
			sql.setString(++i, (String)hm.get("FILE_DT"));
			sql.setString(++i, ((String)hm.get("TRAN_UNIQ_NO")).trim());
			sql.setString(++i, (String)hm.get("CO_CD"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int delDGBPUBCOMST(String com_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "DEL_DGBPUBCO_MST"));
			sql.setString(++i, com_cd);
			logger.info(sql.get());
			rows = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insDGBPUBCOMST(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)                                     
			connect("CMGNS");                                          
			                                                           
			sql.put(findQuery("service-sql", "INS_DGBPUBCO_MST"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("CARD_CORP_CD"));
			sql.setString(++i, (String)hm.get("BIN_NO"));
			sql.setString(++i, (String)hm.get("USE_YN"));
			sql.setString(++i, (String)hm.get("ST_DT"));
			sql.setString(++i, (String)hm.get("CARD_INFO"));
//			sql.setString(++i, ((String)hm.get("TMNAL_ID")));
			                                                           
//			logger.info(sql.debug());                                  
			
			rows = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	
	//20170714 DGB환불대사 수기처리 프로세스 개선
	public int updDGBRTNRslt(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)                                     
			connect("CMGNS");                                          
			                                                           
			sql.put(findQuery("service-sql", "UPD_DGBRTN_DAT"));
			sql.setString(++i, (String)hm.get("PROC_ID"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("TRAN_UNIQ_NO"));
			sql.setString(++i, (String)hm.get("FCSTR_ID"));
			
			rows = executeUpdate(sql);
			
			sql.close();
		}catch(Exception e) {
			logger.info("[SQL DEBUG]"+sql.debug());
			logger.info("[ERROR] error message : "+e.getMessage());
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
}
