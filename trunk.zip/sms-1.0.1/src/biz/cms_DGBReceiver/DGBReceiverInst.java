package biz.cms_DGBReceiver;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class DGBReceiverInst extends Thread {
	private static Logger logger = Logger.getLogger(DGBReceiverAction.class);
	
	String path = "";
	
	public DGBReceiverInst(String path) {
		this.path = path;
	}
	
	public void run() {
		String fileNM = "";
		
		try {
			List<File> file = getDirFileList(path);
			
			logger.info(" >>>>>>>>>>>>>>>>>>>> file cnt : " + Integer.toString(file.size()));
			
			for(int i = 0;i < file.size();i++) {
				fileNM = file.get(i).getName();
				
				logger.info(" >>>>>>>>>>>>>>>>>>> file name : " + fileNM);
				
				int len = 0;
				int totLen = 0;
				String readLine = "";
				
				long fileSize = (file.get(i)).length();
				
				byte buf[] = new byte[(int)fileSize];
				InputStream is = new FileInputStream(file.get(i));
				
//				BufferedReader br = new BufferedReader(new FileReader(file.get(i)));
				StringBuffer sb = new StringBuffer();
				

				while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
					logger.info("fileSize="+Integer.toString((int)fileSize));
					sb.append(new String(buf));
					totLen += len;
					logger.info("totLen="+Integer.toString((int)totLen));
					if( totLen == fileSize ) {
						break;
					}
				}
				
				is.close();
				
//				카드발행사정보		ISIF####
//				온라인충전거래명세	L3TR#### WMLT
//				온라인지불거래명세	P3TR#### WMPT
//				온라인충전정산내역	L3AC#### WMLC
//				온라인지불정산내역	P3AC#### WMPC
				if( fileNM.substring(0, 4).equals("ISIF") ) {				//카드발생사정보 ST_DGBPBCO_MST
					this.insertFileISIF(sb.toString());
				}else if( fileNM.substring(0, 4).equals("WMLT") ) {			//온라인충전거래명세 HQ_DGBRECHGADJT_DTL HQ_DGBRECHGADJT_HDR
//					this.insertFileL3TR(sb.toString());
				}else if( fileNM.substring(0, 4).equals("WMPT") ) {			//온라인지불거래명세 STTRP373DT
//					this.insertFileP3TR(sb.toString());
				}else if( fileNM.substring(0, 4).equals("WMLC") ) {			//온라인충전정산내역 HQ_DGBRECHGPMNTADJT_TRN
					this.insertFileL3AC(sb.toString());
				}else if( fileNM.substring(0, 4).equals("WMPC") ) {			//온라인지불정산내역 HQ_DGBRECHGPMNTADJT_TRN
					this.insertFileP3AC(sb.toString());
				}

				// 파일 옮기기...
				this.moveFile(path, fileNM, path + File.separator + "backup");
				logger.info("[DEBUG] File " + fileNM + " processed successfuly.");
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	private void insertFileL3TR(String readData) { //온라인충전거래명세
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			DGBReceiverDAO dao = new DGBReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			String adjt_dt = "";
			String fcstr_id = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*DGBReceiverProtocol.LENGTH_BY_RECORD, DGBReceiverProtocol.LENGTH_BY_RECORD);
				totLen += DGBReceiverProtocol.LENGTH_BY_RECORD; //수정 길이값
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getDGBL3TR_HDR(strRecord);
					adjt_dt = hm.get("ADJT_DT");
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getDGBL3TR_DAT(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("ADJT_DT", adjt_dt);
					hm.put("FCSTR_ID", ((String)hm.get("TRAN_UNIQ_NO")).substring(6, 11));//사업장조직코드
					fcstr_id = hm.get("FCSTR_ID");
					hm.put("CARD_KEY", card_key);
					hm.put("DOUBLE_CARD_KEY", double_card_key);
					hm.put("RES_DT", "");
					hm.put("TOT_REQ_DT", "");
					hm.put("PENALTY_AMT", "");
					hm.put("RESULT", "");
					try {
						dao.insDGBCHRGADJTRslt_DAT(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}			
				}else if( strRecord.charAt(0) == 'T') {
					hm = getDGBL3TR_TAL(strRecord);
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileL3AC(String readData) {//온라인충전정산내역
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			DGBReceiverDAO dao = new DGBReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			
			String adjt_dt = "";
			String fcstr_id = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*DGBReceiverProtocol.LENGTH_BY_RECORD, DGBReceiverProtocol.LENGTH_BY_RECORD);
				totLen += DGBReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getDGBL3TR_HDR(strRecord); //온라인충전거래명세 헤더와 같음, 참조
					adjt_dt = hm.get("ADJT_DT");
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getDGBL3AC_DAT(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("FCSTR_ID", ((String)hm.get("TRAN_UNIQ_NO")).substring(6, 11));//사업장조직코드
					fcstr_id = hm.get("FCSTR_ID");
					hm.put("ADJT_DT", adjt_dt);
					hm.put("CARD_KEY", card_key);
					hm.put("DOUBLE_CARD_KEY", double_card_key);
					try {
						dao.insDGBCHRGADJTRslt_DAT(hm); //DTL
						
						if("03".equals((String)hm.get("TRT"))){ //20170714 DGB환불대사 수기처리 프로세스 개선
							logger.info("[DGB REFUND PROCESS]");
							
							if( "00".equals((String)hm.get("RESULT")) ) {
								logger.info(">>>>>>>>>> refund return normal");
								hm.put("PROC_ID", "4");
							}else{
								logger.info(">>>>>>>>>> refund return abnormal");
								hm.put("PROC_ID", "3");
							}
							
							try{
								dao.updDGBRTNRslt(hm);
							}catch(Exception e){
								logger.info("[ERROR] Error for updating dgb refund data : " + e.getMessage());
							}
						}
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'T') {
					hm = getDGBL3AC_TAL(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("ADJT_DT", adjt_dt);
					hm.put("WM_STORE_CD", fcstr_id);//가맹점
					try {
						dao.insDGBCHRGADJTRslt_HDR(hm);
						dao.insDGBCHRGADJTRsltByFcstrID_1_DAT(hm); //TRN
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileP3TR(String readData) {//온라인지불거래명세
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			DGBReceiverDAO dao = new DGBReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*DGBReceiverProtocol.LENGTH_BY_RECORD, DGBReceiverProtocol.LENGTH_BY_RECORD);
				totLen += DGBReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getDGBP3TR_HDR(strRecord);
					adjt_dt = hm.get("ADJT_DT");
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getDGBP3TR_DAT(strRecord);
					hm.put("FEE", "");
					hm.put("RESULT", "");
					hm.put("PROC_ID", "");
					hm.put("CO_CD", com_cd);
					hm.put("FILE_MK_DT", adjt_dt);
					
					try {
						iRtn = dao.updDGBPAYMENT_DTL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'T' ) {
					hm = getDGBP3TR_TAL(strRecord);					
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileP3AC(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			DGBReceiverDAO dao = new DGBReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			String fcstr_id = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*DGBReceiverProtocol.LENGTH_BY_RECORD, DGBReceiverProtocol.LENGTH_BY_RECORD);
				totLen += DGBReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getDGBP3TR_HDR(strRecord); //온라인 지불거래명세 헤더 참조 getDGBP3AC_HDR
					adjt_dt = hm.get("ADJT_DT");
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getDGBP3AC_DAT(strRecord);
					fcstr_id = ((String)hm.get("TRAN_UNIQ_NO")).substring(6, 11);

					if( ((String)hm.get("RESULT")).equals("00") ) {
						logger.info(" >>>>>>>>> 정상");
						hm.put("PROC_ID", "4");
					}else {
						logger.info(" >>>>>>>>> 반송");
						hm.put("PROC_ID", "3");
					}
					hm.put("CO_CD", com_cd);
					hm.put("FILE_MK_DT", adjt_dt);
					
					try {
						iRtn = dao.updDGBPAYMENT_DTL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
					
				}else if( strRecord.charAt(0) == 'T') {
					hm = getDGBP3AC_TAL(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("ADJT_DT", adjt_dt);
					hm.put("WM_STORE_CD", fcstr_id);
					try {
						dao.insDGBCHRGADJTRsltByFcstrID_2_DAT(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileISIF(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			DGBReceiverDAO dao = new DGBReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*DGBReceiverProtocol.LENGTH_BY_CARDPUBCO_RECORD, DGBReceiverProtocol.LENGTH_BY_CARDPUBCO_RECORD);
				totLen += DGBReceiverProtocol.LENGTH_BY_CARDPUBCO_RECORD;
				if( strRecord.charAt(0) == 'H' ) {
					hm = getDGBISIF_HDR(strRecord);
					try {
						dao.delDGBPUBCOMST(com_cd);
					}catch(Exception e) {
						logger.info("[ERROR] Error for deleting data : " + e.getMessage());
					}
					continue;
					
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getDGBISIF_DTL(strRecord);
					hm.put("CO_CD", com_cd);
					if(hm.get("CARD_CORP_CD").equals("0")){hm.put("CARD_CORP_CD", "00");}
					if(hm.get("USE_YN").equals("Y")){hm.put("USE_YN", "1");}
												else{hm.put("USE_YN", "0");}
					try {
						dao.insDGBPUBCOMST(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
					
				}else if( strRecord.charAt(0) == 'T' ) {
					hm = getDGBISIF_TAL(strRecord);
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	
	private HashMap<String, String> getDGBISIF_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,3,58};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_NM",
			"BIN_CNT",
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBISIF_DTL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,2,6,30,	1,8,14};
		String strHeaders[] = {
				"RECORD_TP",
				"RECORD_NO",
				"CARD_CORP_CD",
				"BIN_NO",
				"CARD_INFO",
				
				"USE_YN",
				"ST_DT",
				"FILLER"
		};
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBISIF_TAL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,8,53};
		String strHeaders[] = {
				"RECORD_TP",
				"FILE_NM",
				"FILE_DT",
				
				"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBL3TR_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,8,8,8,416,1};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_NM",
			"FILE_DT",
			"ADJT_DT",//청구일자
			"FCSTR_ID",
			"FILLER",
			"MARK"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBL3TR_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,13,18,14
					  ,10,2,16,8,2
					  ,8,8,8,2,18
					  ,4,309,1};
		String strHeaders[] = {
			"RECORD_TP",	//데이터구분
			"RECORD_NO",	//레코드일련번호
			"STORE_ID",		//편의점ID
			"TRAN_UNIQ_NO",	//거래관리번호
			"TRAN_DT",		//거래일시
			
			"TMNAL_ID",		//단말기ID
			"CARD_CORP_CD",	//카드사코드2
			"CARD_NO",		//카드일련번호
			"CARD_CNT",		//카드거래카운트
			"TRT",			//거래유형코드
			
			"TRAN_AMT",		//거래금액
			"RES_AMT",		//거래전잔액
			"REQ_AMT",		//거래후잔액
			"RETURN_TP",	//반품충전구분2
			"ORG_UNIQ_NO",	//지불거래관리번호18
			
			"ERR_CD",		//응답코드2
			"FILLER",
			"MARK"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBP3TR_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,8,8,8,416,1};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_NM",
			"FILE_DT",
			"ADJT_DT",
			"FCSTRID",
			"FILLER",
			"MARK"
			
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBP3TR_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,13,18,14
					  ,10,2,2,2,2
					  ,2,16,10,5,10
					  ,2,16,10,10,10
					  ,10,8,8,2,4
					  ,10,2,8,8,8
					  ,16,8,14,180,1};
		String strHeaders[] = {
			"RECORD_TP",
			"RECORD_NO",
			"FCSTR_ID",
			"TRAN_UNIQ_NO",//거래관리번호
			"TRAN_DT",
			
			"TMNAL_ID",
			"CARD_CORP_CD",//카드사코드
			"ALGEP",
			"IDCENTER",
			"VKIND_KEY2",
			
			"VKIND_KEY1",
			"IDSAM",
			"NCSAM",
			"NISAM",
			"TOTSAM",
			
			"TRT",//거래유형코드
			"IDEP",
			"NTEP",
			"BALEP",//카드잔액
			"MPDA",
			
			"NTSAM",
			"SIGNIND",
			"SIGNIND2",
			"CARD_CD",//카드소지자코드
			"CARD_CD",//타카드소지자유형
			
			"RID",//발급자ID 삭제검토
			"BEF_TP",
			"BEF_AMT",
			"BEF_NTEP",
			"BEF_BALEP",
			
			"BEF_IDSAM",
			"BEF_NTSAM",
			"BEF_TRAN_DT",
			"FILLER",
			"MARK"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBP3TR_TAL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,8,7,425,1};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_NM",
			"FILE_DT",
			"SEND_CNT",
			"FILLER",
			"MARK"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBISIF2_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,2,6,30	,1,8,14};
		String strHeaders[] = {
			"DATA_TP",
			"RECORD_NO",
			"CARD_CD",
			"BIN_NO",
			"CARD_INFO",
			
			"USE_YN",
			"SET_DATE",
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBL3TR_TAL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,8,7,425,1};
		String strHeaders[] = {
			"RECORD_TP",	
			"FILE_NM",
			"FILE_DT,",
			"SEND_CNT",
			"FILLER",
			"ETX"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBL3AC_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {1,8,13,18,14
				  ,10,2,16,8,2
				  ,8,8,8,2,18
				  ,4,14,14,14,8
				  ,2,257,1};
		String strHeaders[] = {
			"RECORD_TP",
			"RECORD_NO",
			"STORE_ID",
			"TRAN_UNIQ_NO",
			"TRAN_DT",
			
			"TMNAL_ID",
			"CARD_CORP_CD",
			"CARD_NO",
			"CARD_CNT",
			"TRT",//거래유형코드
			
			"TRAN_AMT",
			"RES_AMT",
			"REQ_AMT",
			"RETURN_TP",
			"ORG_UNIQ_NO",
			
			"ERR_CD",
			"RES_DT",//거래시작전문 요청일시
			"TOT_RES_DT",//거래완료전문 요청일시
			"TOT_REQ_DT",//거래완료전문 응답일시
			"PENALTY_AMT",
			
			"RESULT",
			"FILLER",
			"MARK"

		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBL3AC_TAL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {1,8,8,8,8
					  ,12,10,8,12,10
					  ,8,12,10,8,12
					  ,10,8,296,1};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_NM",
			"FILE_DT",
			"TOT_RECHG_CNT",		//총정산건수
			"TOT_CHRG_CNT",			//총충전건수
			
			"TOT_CHRG_AMT",			//총충전금액
			"TOT_CHRG_FEE",			//총충전수수료
			"TOT_CHRG_CANCLE_CNT",	//총충전취소건수
			"TOT_CHRG_CANCLE_AMT",	//총충전취소금액
			"TOT_CHRG_CANCLE_FEE",	//총충전취소수수료
			
			"TOT_RETURN_CNT",		//총반품충전건수
			"TOT_RETURN_AMT",		//총반품충전금액
			"TOT_RETURN_FEE",		//총반품충전수수료
			"TOT_REFUND_CNT",		//총환불건수
			"TOT_REFUND_AMT",		//총환불금액
			
			"TOT_REFUND_FEE",		//총환불패널티금액
			"TOT_ERR_CNT",
			"FILLER",
			"MARK"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBP3AC_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,6,7,15,7
					  ,13,10,7,13,10
					  ,211};
		String strHeaders[] = {
			"RECORD_TP",
			"JOB_TP",
			"SEQ_NO",
			"BIZLOC_ORG_CD",
			"TOT_PMNT_CNT",
			
			"TOT_PMNT_AMT",
			"TOT_PMNT_FEE",
			"TOT_RTN_CNT",
			"TOT_RTN_AMT",
			"TOT_RTN_FEE",
			
			"FILLER"
		};	
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBP3AC_DAT(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,13,18,14
				  ,10,2,2,2,2
				  ,2,16,10,5,10
				  ,2,16,10,10,10
				  ,10,8,8,2,4
				  ,10,2,8,8,8
				  ,16,8,14,10,2
				  ,168,1};
		String strHeaders[] = {
			"RECORD_TP",
			"RECORD_NO",
			"FCSTR_ID",
			"TRAN_UNIQ_NO",//거래관리번호
			"TRAN_DT",
			
			"TMNAL_ID",
			"CARD_CORP_CD",//카드사코드
			"ALGEP",
			"IDCENTER",
			"VKIND_KEY2",
			
			"VKIND_KEY1",
			"IDSAM",
			"NCSAM",
			"NISAM",
			"TOTSAM",
			
			"TRT",//거래유형코드
			"IDEP",
			"NTEP",
			"BALEP",//카드잔액
			"MPDA",
			
			"NTSAM",
			"SIGNIND",
			"SIGNIND2",
			"CARD_CD",//카드소지자코드
			"CARD_CD",//타카드소지자유형
			
			"RID",//발급자ID 삭제검토
			"BEF_TP",
			"BEF_AMT",
			"BEF_NTEP",
			"BEF_BALEP",
			
			"BEF_IDSAM",
			"BEF_NTSAM",
			"BEF_TRAN_DT",
			"FEE",//지불수수료
			"RESULT",//정산결과
			
			"FILLER",
			"MARK"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getDGBP3AC_TAL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,8,7,12,7,12,7,12,8,375,1};
		
		String strHeaders[] = {
			"RECORD_TP",			//데이터구분
			"RESULT_DT",			//정산일자
			"TOT_ADJT_CNT",			//총청구건수
			"TOT_ADJT_AMT",			//총청구금액
			"TOT_RESEND_CNT",		//총반송건수
			
			"TOT_RESEND_AMT",		//총반송금액
			"TOT_RESULT_CNT",		//총정산건수
			"TOT_RESULT_AMT",		//총정산금액
			"TOT_RESULT_FEE",		//총정산지불수수료
			"FILLER",
			
			"MARK"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
//			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
}
