package biz.cms_DGBReceiver;

public class Query {
/*
 	DEL_DGBPUBCO_MST
 	
 	<query name="DEL_DGBPUBCO_MST"> 20170317
		<![CDATA[
		  	DELETE
		  	  FROM ST_DGBPBCO_MST
		  	 WHERE 1 = 1
		  	   AND CO_CD = ?
		]]>
	</query>
	
	INS_DGBPUBCO_MST
	
	<query name="INS_DGBPUBCO_MST">
		<![CDATA[
			INSERT INTO ST_DGBPBCO_MST
				(
					CO_CD
				, PBCO_CD
				, BIN_CD
				, CARD_INFO
				, USE_YN
				, ST_DT
				
				, REG_DTM
				, REG_EMP_ID
				)
			VALUES
				(
				  ?
				, TRIM(?)
				, TRIM(?)
				, TRIM(?)
				, TRIM(?)
				
				, FN_DATETIME2STR()
				, 'cms_DGBReceiver'
				)
		]]>
	</query>
	
	

	
	
	
	
	
	
	
*/
}
