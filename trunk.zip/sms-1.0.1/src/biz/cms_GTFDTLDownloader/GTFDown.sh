#!/bin/bash

echo "--start GTFPollingAction"

cd $SMS_HOME/bin

java biz.cms_GTFDTLDownloader.GTFDTLDownloaderPollingAction -path:$CONFIG_FILE -cmd:01

cd $APP_HOME/batch

