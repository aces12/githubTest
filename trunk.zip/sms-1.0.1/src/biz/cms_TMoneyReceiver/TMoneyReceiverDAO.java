package biz.cms_TMoneyReceiver;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class TMoneyReceiverDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(TMoneyReceiverAction.class);
	
	public int updDSTBMSTCHGHIS(String com_cd, String chg_dt, String bizloc_org_cd, String mst_grp_cd, String reg_emp_id, String mod_emp_id) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_DSTBMSTCHGHIS"));
			sql.setString(++i, com_cd);
			sql.setString(++i, chg_dt);
			sql.setString(++i, bizloc_org_cd);
			sql.setString(++i, mst_grp_cd);
			sql.setString(++i, reg_emp_id);
			sql.setString(++i, mod_emp_id);
			
//			logger.info("sql : " + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public List<Object> selTMONEYRECHRGDTL(String co_cd, String charge_date) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_TMONEYRECHGREPAYTRAN"));
			sql.setString(++i, co_cd);
			sql.setString(++i, charge_date);
			
			list = executeQuery(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			throw e;
		}
		
		return list;
	}
	
	public int updTMONEYPAYMENTREJECT_DTL(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			if( ((String)hm.get("PROC_ID")).equals("3") ) {	// 반송
				sql.put(findQuery("service-sql", "UPD_TMONEYPAYMENTREJECT_DTL2"));
			}else {	// 정상
				sql.put(findQuery("service-sql", "UPD_TMONEYPAYMENTREJECT_DTL"));
			}
			sql.setString(++i, (String)hm.get("ERR_OCCU_DTM"));
			sql.setString(++i, (String)hm.get("ERR_OCCU_CD"));
			sql.setString(++i, (String)hm.get("FILE_MK_DT"));
			sql.setString(++i, (String)hm.get("PROC_ID"));
			sql.setString(++i, (String)hm.get("TRAN_ID"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insTMONEYOPINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_TMONEYOPINFO"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("PBCO_ID"));
			sql.setString(++i, (String)hm.get("FILE_MK_DTM"));
			sql.setString(++i, (String)hm.get("APPLY_DTM"));
			sql.setString(++i, (String)hm.get("PBCO_FNC_DEFINE_VAL"));
			
			logger.info(" sql : " + sql.debug());
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int instTMONEYPMNTCNCL_HDR(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_TMONEYPMNTCNCLHDR"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("WORK_DT"));
			sql.setString(++i, (String)hm.get("TOT_CNT"));
			sql.setString(++i, (String)hm.get("TOT_PMNTCNCL_CNT"));
			sql.setString(++i, (String)hm.get("TOT_PMNTCNCL_AMT"));
			sql.setString(++i, (String)hm.get("FILE_MK_DTM"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int instTMONEYPMNTCNCL_DTL(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_TMONEYPMNTCNCLDTL"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("WORK_DT"));
			sql.setString(++i, (String)hm.get("TRANSACTION_ID"));
			sql.setString(++i, (String)hm.get("FCSTR_ID"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("FCSTR_ID"));
			sql.setString(++i, (String)hm.get("TMNAL_ID"));
			sql.setString(++i, (String)hm.get("CARD_NO"));
			sql.setString(++i, (String)hm.get("CARD_KEY"));
			sql.setString(++i, (String)hm.get("DOUBLE_CARD_KEY"));
			sql.setString(++i, (String)hm.get("CARD_TRAN_SNO"));
			sql.setString(++i, (String)hm.get("CARD_OWNER_ID"));
			sql.setString(++i, (String)hm.get("RECV_YMDHMS"));
			sql.setString(++i, (String)hm.get("WORK_ID"));
			sql.setString(++i, (String)hm.get("PMNTCNCL_YMDHMS"));
			sql.setString(++i, (String)hm.get("PMNTCNCL_BEF_RAMT"));
			sql.setString(++i, (String)hm.get("PMNTCNCL_REQ_AMT"));
			sql.setString(++i, (String)hm.get("PMNTCNCL_AFT_RAMT"));
			sql.setString(++i, (String)hm.get("RESULT"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insTMONEYRECHRGPMNTADJT_TAIL(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_TMONEYRECHRGPMNTADJT_TAIL"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
			sql.setString(++i, (String)hm.get("RECHG_PMNT_TP"));
			sql.setString(++i, (String)hm.get("TOT_CNT"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insTMONEYRECHRGPMNTADJT_DTL(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_TMONEYRECHRGPMNTADJT_DTL"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
			sql.setString(++i, (String)hm.get("RECHG_PMNT_TP"));
			//sql.setString(++i, (String)hm.get("SEQ_NO"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("FCSTR_ID"));
			
			sql.setString(++i, (String)hm.get("FCSTR_ID"));
			sql.setString(++i, (String)hm.get("NOR_CNT"));
			sql.setString(++i, (String)hm.get("NOR_AMT"));
			sql.setString(++i, (String)hm.get("NPROC_CNT"));
			sql.setString(++i, (String)hm.get("NPROC_AMT"));
			
			sql.setString(++i, (String)hm.get("RPROC_CNT"));
			sql.setString(++i, (String)hm.get("RPROC_AMT"));
			sql.setString(++i, (String)hm.get("ADJT_CNT"));
			sql.setString(++i, (String)hm.get("ADJT_AMT"));
			sql.setString(++i, (String)hm.get("FCSTR_FEE_RT"));
			
			sql.setString(++i, (String)hm.get("FCSTR_FEE"));
			sql.setString(++i, (String)hm.get("FCSTR_PAYAMT"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insTMONEYRECHRGCHRG_HDR(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_TMONEYRECHGREPAYTRAN_HDR"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("DMD_DT"));
			sql.setString(++i, (String)hm.get("TOT_DATA_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RECHG_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RECHG_AMT"));
			sql.setString(++i, (String)hm.get("TOT_RECHG_FEE"));
			sql.setString(++i, (String)hm.get("TOT_RECHG_CNCL_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RECHG_CNCL_AMT"));
			sql.setString(++i, (String)hm.get("TOT_RECHG_CNCL_FEE"));
			sql.setString(++i, (String)hm.get("TOT_REPAY_CNT"));
			sql.setString(++i, (String)hm.get("TOT_REPAY_AMT"));
			sql.setString(++i, (String)hm.get("TOT_REPAY_FEE"));
			sql.setString(++i, (String)hm.get("FILE_MK_DTM"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insTMONEYRECHRGCHRG_DTL(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_TMONEYRECHGREPAYTRAN_DTL"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("DMD_DT"));
			sql.setString(++i, (String)hm.get("TR_ID"));
			//sql.setString(++i, (String)hm.get("SEQ_NO"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("FCSTR_ID"));
			
			sql.setString(++i, (String)hm.get("FCSTR_ID"));
			sql.setString(++i, (String)hm.get("TMNAL_ID"));
			sql.setString(++i, (String)hm.get("PPCARD_NO"));
			sql.setString(++i, (String)hm.get("CARD_KEY"));
			sql.setString(++i, (String)hm.get("DOUBLE_CARD_KEY"));
			sql.setString(++i, (String)hm.get("CARD_TP_VAL"));
			sql.setString(++i, (String)hm.get("CARD_STAT_VAL"));
			
			sql.setString(++i, (String)hm.get("REQ_DTM"));
			sql.setString(++i, (String)hm.get("ELECDOC_SND_DTM"));
			sql.setString(++i, (String)hm.get("CARD_TRAN_SEQ_NO"));
			sql.setString(++i, (String)hm.get("TMONY_TASK_TP"));
			sql.setString(++i, (String)hm.get("STAT_DTM"));
			
			sql.setString(++i, (String)hm.get("PPCARD_PRE_REM_AMT"));
			sql.setString(++i, (String)hm.get("PPCARD_REQ_AMT"));
			sql.setString(++i, (String)hm.get("PPCARD_REM_AMT"));
			sql.setString(++i, (String)hm.get("FEE"));
			sql.setString(++i, (String)hm.get("HSM_STAT_TP"));
			
			sql.setString(++i, (String)hm.get("TASK_RSLT_RESPON_CD"));
						
			rows = executeUpdate(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
}