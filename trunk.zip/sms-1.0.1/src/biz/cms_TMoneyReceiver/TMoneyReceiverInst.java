package biz.cms_TMoneyReceiver;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class TMoneyReceiverInst extends Thread {
	private static Logger logger = Logger.getLogger(TMoneyReceiverInst.class);
	
	String path = "";
	
	public TMoneyReceiverInst(String path) {
		this.path = path;
	}
	
	public void run() {
		String fileNM = "";
		try {
			List<File> file = getDirFileList(path);
			
			for(int i = 0;i < file.size();i++) {
				fileNM = file.get(i).getName();
				logger.info(" >>>>>>>>>>>>>> file Name : " + fileNM);
				
				int len = 0;
				int totLen = 0;
				String readData = "";
				
				long fileSize = (file.get(i)).length();
				
				byte buf[] = new byte[(int)fileSize];
				InputStream is = new FileInputStream(file.get(i));
				StringBuffer sb = new StringBuffer();
				
//				while( (len = is.read(buf)) > 0 ) {
//					sb.append(new String(buf));
//				}
				while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
					sb.append(new String(buf));
					totLen += len;
					if( totLen == fileSize ) {
						break;
					}
				}
				
				is.close();
				
				readData = sb.toString();
				
				if( (fileNM.substring(0, 2)).equals("UV") ) {		// 충전청구/환불거래내역 파일
					// 충전 청구일자 저장
					String chargeDT = "";
					chargeDT = readData.substring(98, 106);
					
					this.insertFileUV(readData, chargeDT);
				}else if( (fileNM.substring(0, 2)).equals("TY") ) {	// 지불반송내역 파일
					this.insertFileTY(readData);
				}else if( (fileNM.substring(0, 2)).equals("GZ") ) {	// 지불취소(반품충전)내역 파일
					this.insertFileGZ(readData);
				}else if( (fileNM.substring(0, 2)).equals("Y2") ) {	// 지불정산결과내역 파일
					this.insertFileY2(readData);
				}else if( (fileNM.substring(0, 2)).equals("Y4") ) {	// 발행사ID 및 단말기 기능 정의 파일
					this.insertFileY4(readData);
				}
				// 파일 옮기기...
				this.moveFile(path, fileNM, path + File.separator + "backup");
				logger.info("[DEBUG] File " + fileNM + " processed successfuly.");
			}
		}catch(Exception e) {
			
		}
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	private void insertFileY4(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			TMoneyReceiverDAO dao = new TMoneyReceiverDAO();
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			String toDay = sdf.format(calendar.getTime());
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String fileCreatedYMDHMS = "";
			String applyYMDHMS = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for( int i = 0;totLen < bytes.length;i++ ) {
//				String strRecord = readData.substring(i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, (i + 1) * TMoneyReceiverProtocol.LENGTH_BY_RECORD - 1);
				byte tempBytes[] = new byte[TMoneyReceiverProtocol.LENGTH_BY_RECORD];
				System.arraycopy(bytes, i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, tempBytes, 0, tempBytes.length);
//				String strRecord = new String(bytes, i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, TMoneyReceiverProtocol.LENGTH_BY_RECORD);
				String strRecord = new String(tempBytes);
				totLen += TMoneyReceiverProtocol.LENGTH_BY_RECORD;
				
//				logger.info(" recvLen : " + Integer.toString(bytes.length) + ", totLen : " + Integer.toString(totLen));
//				logger.info(" >>>>>>>>>>>>>> i : " + Integer.toString(i));
//				logger.info(" >>>>>>>>>>>>>> strRecord = " + strRecord);
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getTMoneyOPInfoHDR(strRecord);
					
					fileCreatedYMDHMS = (String)hm.get("FILE_MK_DTM");
					applyYMDHMS = (String)hm.get("APPLY_DTM");
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getTMoneyOPInfoDTL(strRecord);
					
					hm.put("CO_CD", com_cd);
					hm.put("FILE_MK_DTM", fileCreatedYMDHMS);
					hm.put("APPLY_DTM", applyYMDHMS);
					try {
						iRtn = dao.insTMONEYOPINFO(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting Data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'T' ) {
					break;
				}
			}
			dao.updDSTBMSTCHGHIS(com_cd, toDay, "%", "0014", "cms_TMoneyReceiver", "cms_TMoneyReceiver");
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileY2(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			TMoneyReceiverDAO dao = new TMoneyReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for( int i = 0;totLen < bytes.length;i++ ) {
//				String strRecord = readData.substring(i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, (i + 1) * TMoneyReceiverProtocol.LENGTH_BY_RECORD - 1);
				
//				logger.info(" recvLen : " + Integer.toString(bytes.length) + ", totLen : " + Integer.toString(totLen));
//				logger.info(" >>>>>>>>>>>>>> i : " + Integer.toString(i));
				
				String strRecord = new String(bytes, i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, TMoneyReceiverProtocol.LENGTH_BY_RECORD);
				totLen += TMoneyReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'D' ) {
					hm = getTMoneyRechrgPmntCalDTL(strRecord);
					adjt_dt = (String)hm.get("ADJT_DT");
					
					hm.put("CO_CD", com_cd);
					hm.put("RECHG_PMNT_TP", "2");
					try {
						iRtn = dao.insTMONEYRECHRGPMNTADJT_DTL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting Data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'T' ) {
					hm = getTMoneyRechrgPmntCalTAIL(strRecord);
					
					hm.put("CO_CD", com_cd);
					hm.put("ADJT_DT", adjt_dt);
					hm.put("RECHG_PMNT_TP", "2");
					try {
						iRtn = dao.insTMONEYRECHRGPMNTADJT_TAIL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting Tail data : " + e.getMessage());
					}
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileGZ(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			TMoneyReceiverDAO dao = new TMoneyReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			String work_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for( int i = 0;totLen < bytes.length;i++ ) {
				String strRecord = new String(bytes, i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, TMoneyReceiverProtocol.LENGTH_BY_RECORD);
				totLen += TMoneyReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getTMoneyPmntCnclHDR(strRecord);
					work_dt = (String)hm.get("WORK_DT");
					
					hm.put("CO_CD", com_cd);
					try {
						iRtn = dao.instTMONEYPMNTCNCL_HDR(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting Header data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getTMoneyPmntCnclDTL(strRecord);
					
					hm.put("CO_CD", com_cd);
					hm.put("WORK_DT", work_dt);
					hm.put("CARD_KEY", card_key);
					hm.put("DOUBLE_CARD_KEY", double_card_key);
					try {
						iRtn = dao.instTMONEYPMNTCNCL_DTL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting Data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'T' ) {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileY1(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			TMoneyReceiverDAO dao = new TMoneyReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for( int i = 0;totLen < bytes.length;i++ ) {
//				String strRecord = readData.substring(i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, (i + 1) * TMoneyReceiverProtocol.LENGTH_BY_RECORD - 1);
				
//				logger.info(" recvLen : " + Integer.toString(bytes.length) + ", totLen : " + Integer.toString(totLen));
//				logger.info(" >>>>>>>>>>>>>> i : " + Integer.toString(i));
				
				String strRecord = new String(bytes, i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, TMoneyReceiverProtocol.LENGTH_BY_RECORD);
				totLen += TMoneyReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'D' ) {
					hm = getTMoneyRechrgPmntCalDTL(strRecord);
					adjt_dt = (String)hm.get("ADJT_DT");
					
					hm.put("CO_CD", com_cd);
					hm.put("RECHG_PMNT_TP", "1");
					try {
						iRtn = dao.insTMONEYRECHRGPMNTADJT_DTL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting Data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'T' ) {
					hm = getTMoneyRechrgPmntCalTAIL(strRecord);
					
					hm.put("CO_CD", com_cd);
					hm.put("ADJT_DT", adjt_dt);
					hm.put("RECHG_PMNT_TP", "1");
					try {
						iRtn = dao.insTMONEYRECHRGPMNTADJT_TAIL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting Tail data : " + e.getMessage());
					}
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileTY(String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			TMoneyReceiverDAO dao = new TMoneyReceiverDAO();
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			calendar.add(Calendar.DATE, -1);
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String adjt_dt = sdf.format(calendar.getTime());
			String fileCreatedDT = "";
			String tran_ymd = "";
			String store_cd = "";
			String pos_no = "";
			String tran_no = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			for( int i = 0;totLen < bytes.length;i++ ) {
//				String strRecord = readData.substring(i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, (i + 1) * TMoneyReceiverProtocol.LENGTH_BY_RECORD - 1);
				
//				logger.info(" recvLen : " + Integer.toString(bytes.length) + ", totLen : " + Integer.toString(totLen));
//				logger.info(" >>>>>>>>>>>>>> i : " + Integer.toString(i));
				
				String strRecord = new String(bytes, i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, TMoneyReceiverProtocol.LENGTH_BY_RECORD);
				totLen += TMoneyReceiverProtocol.LENGTH_BY_RECORD;
				
				if( strRecord.charAt(0) == 'H' ) {
					fileCreatedDT = strRecord.substring(1, 9);
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getTMoneyPaymentRejectDTL(strRecord);
					//tran_ymd = String.format("20%-6s", ((String)hm.get("TRAN_ID")).substring(0, 5));
					//store_cd = String.format("%-5s", ((String)hm.get("TRAN_ID")).substring(6, 10));
					//pos_no = String.format("%-4s", ((String)hm.get("TRAN_ID")).substring(11, 14));
					//tran_no = String.format("%-4s", ((String)hm.get("TRAN_ID")).substring(15, 18));
					
					hm.put("CO_CD", com_cd);
					if( ((String)hm.get("ERR_OCCU_CD")).equals("00") ) {
						logger.info(" >>>>>>>>> 정상");
						hm.put("PROC_ID", "4");
					}else if( ((String)hm.get("ERR_OCCU_CD")).equals("07") ) {
						logger.info(" >>>>>>>>> 중복오류");
						hm.put("PROC_ID", "4");
					}else {
						logger.info(" >>>>>>>>> 반송");
						hm.put("PROC_ID", "3");
					}
					// 정산일자가 들어와야 하는데 파일생성일자가 들어오기 때문에
					// 부득이하게 현재 대사 시점에서 -1 일을 한 일자를 구해서 정산확정일자로 Update 함 (2014/04/03)
					//hm.put("FILE_MK_DT", fileCreatedDT);
					hm.put("FILE_MK_DT", adjt_dt);
					//hm.put("TRAN_YMD", tran_ymd);
					//hm.put("STORE_CD", store_cd);
					//hm.put("POS_NO", pos_no);
					//hm.put("TRAN_NO", tran_no);
					//hm.put("", fileCreatedDT);
					try {
						iRtn = dao.updTMONEYPAYMENTREJECT_DTL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'T' ) {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertFileUV(String readData, String chargeDT) {
		List<Object> list = null;
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			TMoneyReceiverDAO dao = new TMoneyReceiverDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int iRtn = 0;
			
			list = dao.selTMONEYRECHRGDTL(com_cd, chargeDT);
			if( list.size() != 0 ) {
				return;
			}
			for( int i = 0;totLen < bytes.length;i++ ) {
//				String strRecord = readData.substring(i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, (i + 1) * TMoneyReceiverProtocol.LENGTH_BY_RECORD - 1);
				
//				logger.info(" recvLen : " + Integer.toString(bytes.length) + ", totLen : " + Integer.toString(totLen));
//				logger.info(" >>>>>>>>>>>>>> i : " + Integer.toString(i));
				
				String strRecord = new String(bytes, i*TMoneyReceiverProtocol.LENGTH_BY_RECORD, TMoneyReceiverProtocol.LENGTH_BY_RECORD);
				totLen += TMoneyReceiverProtocol.LENGTH_BY_RECORD;
				
				logger.info(" Record = " + strRecord + ", totLen = " + Integer.toString(totLen));
				
				if( strRecord.charAt(0) == 'H' ) {
					hm = getTMoneyRechrgChrgHDR(strRecord);
					hm.put("CO_CD", com_cd);
					try {
						iRtn = dao.insTMONEYRECHRGCHRG_HDR(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting Header data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'D' ) {
					hm = getTMoneyRechrgChrgDTL(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("DMD_DT", chargeDT);
					hm.put("CARD_KEY", card_key);
					hm.put("DOUBLE_CARD_KEY", double_card_key);
					try {
						iRtn = dao.insTMONEYRECHRGCHRG_DTL(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting Data : " + e.getMessage());
					}
				}else if( strRecord.charAt(0) == 'T' ) {
					break;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private HashMap<String, String> getTMoneyOPInfoDTL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,7,3,3,2,284};
		String strHeaders[] = {
			"RECORD_TP",
			"SEQ_NO",
			"PBCO_ID",
			"PBCO_FNC_DEFINE_VAL",
			"CRC16",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getTMoneyOPInfoHDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,14,14,271};
		String strHeaders[] = {
			"RECORD_TP",
			"FILE_MK_DTM",
			"APPLY_DTM",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getTMoneyPmntCnclHDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,7,7,13,8
					  ,14,250};
		String strHeaders[] = {
			"RECORD_TP",
			"TOT_CNT",
			"TOT_PMNTCNCL_CNT",
			"TOT_PMNTCNCL_AMT",
			"WORK_DT",
			
			"FILE_MK_DTM",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getTMoneyPmntCnclDTL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,7,20,7,9
					  ,16,10,2,14,3
					  ,14,10,10,10,2
					  ,165};
		String strHeaders[] = {
			"RECORD_TP",
			"SEQ_NO",
			"TRANSACTION_ID",
			"FCSTR_ID",
			"TMNAL_ID",
			
			"CARD_NO",
			"CARD_TRAN_SNO",
			"CARD_OWNER_ID",
			"RECV_YMDHMS",
			"WORK_ID",
			
			"PMNTCNCL_YMDHMS",
			"PMNTCNCL_BEF_RAMT",
			"PMNTCNCL_REQ_AMT",
			"PMNTCNCL_AFT_RAMT",
			"RESULT",
			
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getTMoneyRechrgPmntCalTAIL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,7,292};
		String strHeaders[] = {
			"RECORD_TP",
			"TOT_CNT",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getTMoneyRechrgPmntCalDTL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,7,8,7,7
					  ,13,7,13,7,13
					  ,7,13,5,13,13
					  ,166};
		String strHeaders[] = {
			"RECORD_TP",
			"SEQ_NO",
			"ADJT_DT",
			"FCSTR_ID",
			"NOR_CNT",
			
			"NOR_AMT",
			"NPROC_CNT",
			"NPROC_AMT",
			"RPROC_CNT",
			"RPROC_AMT",
			
			"ADJT_CNT",
			"ADJT_AMT",
			"FCSTR_FEE_RT",
			"FCSTR_FEE",
			"FCSTR_PAYAMT",
			
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getTMoneyRechrgChrgHDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,7,7,13,10
					,7,13,10,7,13
					,10,8,14,180};
		String strHeaders[] = {
			"RECORD_TP",
			"TOT_DATA_CNT",
			"TOT_RECHG_CNT",
			"TOT_RECHG_AMT",
			"TOT_RECHG_FEE",
			
			"TOT_RECHG_CNCL_CNT",
			"TOT_RECHG_CNCL_AMT",
			"TOT_RECHG_CNCL_FEE",
			"TOT_REPAY_CNT",
			"TOT_REPAY_AMT",
			
			"TOT_REPAY_FEE",
			"DMD_DT",
			"FILE_MK_DTM",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String,String> getTMoneyPaymentRejectDTL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,7,20,7,9
					  ,8,5,16,10,20
					  ,10,3,10,10,10
					  ,14,2,2,2,10
					  ,5,10,8,2,2
					  ,1,14,2,80};
		String strHeaders[] = {
			"RECORD_TP",
			"SEQ_NO",
			"TRAN_ID",
			"FCSTR_ID",
			"TMNAL_ID",
			
			"TRAN_YMD",
			"TRAN_NO",
			"PSAM_ID",
			"PSAM_TRAN_SEQ_NO",
			"PPCARD_NO",
			
			"PPCARD_TRAN_SEQ_NO",
			"TMONY_TASK_TP",
			"PPCARD_PRE_REM_AMT",
			"PPCARD_REQ_AMT",
			"PPCARD_AFT_REM_AMT",
			
			"TRAN_DTM",
			"ALGO_NO",
			"SPBY_TRAN_KEY_VER",
			"ELE_MONY_IDTY",
			"PSAM_TOT_AMT_COLECT_SEQ_NO",
			
			"PSAM_SPBY_COLECT_CNT",
			"PSAM_ACCM_TOT_AMT",
			"SIGN_VAL",
			"CARD_TP_VAL",
			"CARD_HOLDER_TP",
			
			"HSM_STAT_VAL",
			"ERR_OCCU_DTM",
			"ERR_OCCU_CD",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getTMoneyRechrgChrgDTL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,7,20,7,9
					  ,16,2,4,14,14
					  ,10,3,14,10,10
					  ,10,10,1,2,136};
		String strHeaders[] = {
			"RECORD_TP",
			"SEQ_NO",
			"TR_ID",
			"FCSTR_ID",
			"TMNAL_ID",
			
			"PPCARD_NO",
			"CARD_TP_VAL",
			"CARD_STAT_VAL",
			"REQ_DTM",
			"ELECDOC_SND_DTM",
			
			"CARD_TRAN_SEQ_NO",
			"TMONY_TASK_TP",
			"STAT_DTM",
			"PPCARD_PRE_REM_AMT",
			"PPCARD_REQ_AMT",
			
			"PPCARD_REM_AMT",
			"FEE",
			"HSM_STAT_TP",
			"TASK_RSLT_RESPON_CD",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
//			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
}