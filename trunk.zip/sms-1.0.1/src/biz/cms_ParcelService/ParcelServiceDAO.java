package biz.cms_ParcelService;

import java.util.List;

import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;

public class ParcelServiceDAO extends GenericDAO {
	public String procGETVALIDPACELITEM(String COM_CD) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		int i = 0;
		
		String dataMsg = "";
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			proc.put("SP_PS_PARCELITEM_TRN", 3);
			proc.setString(++i, COM_CD);
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// RES_CD
			
			ProcedureResultSet prs = super.executeUpdateProcedure(proc);
			
			dataMsg = prs.getString(3);		// 실시간 전송내역
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return dataMsg;
	}
}
