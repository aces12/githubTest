package biz.cms_MFCDTLDownloader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

import org.apache.log4j.Logger;

public class MFCDTLDownloaderInst extends Thread {
	private static Logger logger = Logger.getLogger(MFCDTLDownloaderPollingAction.class);
	
	String path = "";
//	String fileNM = "";	
//	String fileNM = "";
//	String stdDate = "";
	
	public MFCDTLDownloaderInst(String path) {
		this.path = path;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
	public void deleteFile(String path, String fileNM) {
		File file = new File(path + File.separator + fileNM);
		if( file.exists() ) {
			logger.info("File Name : " + path + File.separator + fileNM);
			if( file.delete() ) {
				logger.info("File(" + path + File.separator + fileNM + ") removed !!!");
			}
		}
	}
	
	public void copyFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdirs();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(orgFile);
			fos = new FileOutputStream(destFile);
			
			int data = 0;
			while( (data = fis.read()) != -1 ) {
				fos.write(data);
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			try {
				fis.close();
				fis = null;
				fos.flush();
				fos.close();
				fos = null;
				System.gc();
			}catch(Exception e) {
				logger.info(e.getMessage());
			}
		}
		
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public void run() {

		int ret = 0;
		BufferedReader bin = null;
		StringTokenizer st = null;
		String readedLine = "";
		String depotVen_cd = "";
		String feeVat_tp = "";
		try {			
			MFCDTLDownloaderDAO dao = new MFCDTLDownloaderDAO();

			logger.info(">>>>>>> path = " + path);
			List<File> list = getDirFileList(path);
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			for(int i = 0;i < list.size();i++ ) {
				if( !(list.get(i)).isFile() ) {
					continue;
				}
				String targetFile = list.get(i).getName();
				bin = new BufferedReader(new FileReader(path + File.separator + targetFile));
								
				while( (readedLine = bin.readLine()) != null ) {
					logger.info("[DEBUG] File Name : " + targetFile + ", readedLine = " + readedLine);
					// '\t'와'\n' 구분자로 토큰 분리
					st = new StringTokenizer(readedLine, "\t\n");
					
					int col = 0;
					Map<String, String> map = new HashMap<String, String>();

					String strHeaders[] = {
						"ADMIT_DATE",				//승인일자 
						"ADMIT_TIME",				//승인시간 
						"CARD_BIN",					//카드Bin 
						"ADMIT_NO",					//승인번호 
						"TRAN_TYPE",				//거래구분
						"TRADE_AMT",				// 거래금액
						"FEE_AMT",					// 수수료금액
						"ADJT_AMT",					// 정산금액
						"STORE_CD",					// 점포코드
						"ADJT_YMD",					// 정산예정일자
						"MBS_ID",					// 가맹점ID
						"MBS_AREA",					// 구분코드 6자리+전체 행정동 명칭
						"VAN_TRACE_NO",				// VAN사 전문 추적 번호
						"VEN_TRAN_NO",				// 푸르미 거래번호
						"VEN_ORG_TRAN_NO"			// 원거래의 푸르미 거래번호를 의미		
					};
					// 각 분리된 토큰을 저장
					while( st.hasMoreTokens() ) {
						map.put(strHeaders[col++], st.nextToken());
						logger.info("☆  value[" + Integer.toString(col-1) + "] = " + map.get(strHeaders[col-1]));
						System.out.println("☆  value[" + Integer.toString(col-1) + "] = " + map.get(strHeaders[col-1]));
																	
					}
						
//						String cardBin = (String)map.get("CARD_DATA").substring(0, 4) +  (String)map.get("CARD_DATA").substring(5,7);
						String admitDate = (String)map.get("ADMIT_DATE");
						List<Map<Object, Object>> tmpMap = dao.selDepotven_cd((String)map.get("CARD_BIN") , admitDate);
														
						if (tmpMap.size() !=0 ){
							for(Map<Object, Object> data : tmpMap)
							{
								depotVen_cd = (String)data.get("DEPOTVEN_CD");
								feeVat_tp  = (String)data.get("FEEVAT_TP");
							}	
						}else{			//if(depotVen_cd == null) {
							logger.info("There is no DEPOTVEN_CD. so Error on inserting data");
							logger.info("ADMIT_NO[" +(String)map.get("ADMIT_DATE") + "] CARD_DATA[" +(String)map.get("ADMIT_DATE") + "]"  );
							
							System.out.println("There are no DEPOTVEN_CD or FEEVAT_TP . Error on inserting data" );
							System.out.println("error data is ADMIT_NO[" +(String)map.get("ADMIT_DATE") + "] CARD_DATA[" +(String)map.get("CARD_DATA") + "]"  );													
						}
																	 
						map.put("DEPOTVEN_CD", depotVen_cd );
						map.put("FEEVAT_TP"	 , feeVat_tp );
//						map.put("CARDBIN"	 , cardBin );
						
						ret = dao.insMFCDailyDTL(map);
					if( ret != 1 ) {
						logger.info("["+targetFile.substring(18, 19)+"]"+"There is an Error on inserting data");
						System.out.println("["+targetFile.substring(18, 19)+"]"+"There is an Error on inserting data");						
					}					
				}				
				bin.close();
				bin = null;

				this.moveFile(path, targetFile, path + File.separator + "backup");
				
				File fileOK = new File(path + File.separator + "backup" + File.separator + targetFile);
			    File file = new File(path + File.separator + "backup" + File.separator
			      + targetFile.substring(0, targetFile.length()-3));
			    logger.info("[debug]" + path + File.separator + "backup" + File.separator + targetFile);
			    fileOK.renameTo(file);//moveFile후 파일명 끝에 .ok 삭제
			    
				logger.info("Data insert OK.  FTP work well done");	
			}		
			
		}catch(Exception e) {
			logger.info("[ERROR1] " + e.getMessage());
			System.out.println("[ERROR1] " + e.getMessage());
		}finally {
			try {
				if( bin != null ) bin.close();
			}catch(Exception e) {
				//logger.info("exception occur"+ e.getMessage());
				System.out.println("exception occur"+ e.getMessage());
			}
		}
			
	}
}