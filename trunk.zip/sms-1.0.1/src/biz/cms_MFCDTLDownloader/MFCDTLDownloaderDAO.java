package biz.cms_MFCDTLDownloader;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class MFCDTLDownloaderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(MFCDTLDownloaderDAO.class);
	
	
	public int  insMFCDailyDTL    (Map<String, String> map) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			

			sql.put(findQuery("service-sql", "INS_MFCVENDAILY_TRN"));			

			sql.setString(++i, (String)map.get("ADMIT_DATE")
								+(String)map.get("TRAN_TYPE")
								+(String)map.get("ADMIT_NO"));//P_TRAN_ID 승인일자+거래구분+승인번호
			sql.setString(++i, (String)map.get("CARD_BIN"));
			sql.setString(++i, (String)map.get("ADMIT_DATE"));
			sql.setString(++i, (String)map.get("ADMIT_NO"));
			sql.setString(++i, (String)map.get("DEPOTVEN_CD"));
			sql.setString(++i, (String)map.get("ADMIT_TIME"));
			
			sql.setString(++i, (String)map.get("TRAN_TYPE"));			
			sql.setString(++i, (String)map.get("TRADE_AMT"));
			sql.setString(++i, (String)map.get("FEE_AMT"));
			sql.setString(++i, (String)map.get("ADJT_AMT"));
			sql.setString(++i, (String)map.get("STORE_CD"));
			
			sql.setString(++i, (String)map.get("ADJT_YMD"));			
			sql.setString(++i, (String)map.get("MBS_ID"));
			sql.setString(++i, (String)map.get("MBS_AREA"));
			sql.setString(++i, (String)map.get("VAN_TRACE_NO"));
			sql.setString(++i, (String)map.get("VEN_TRAN_NO"));		
			sql.setString(++i, (String)map.get("VEN_ORG_TRAN_NO"));
			sql.setString(++i, (String)map.get("FEEVAT_TP"));
			
			
			logger.info("[SQL1][INS_MFCVENDAILY_TRN]" + sql.debug() );
									
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
		}finally {
			//transaction 종료
			end();
		}
		
		return rows;
	}
	

	public List<Map<Object, Object>> selDepotven_cd(String BinCD , String admitDate  ){		
		List<Map<Object, Object>> result = null;
		String sql_debug = null;
		int i = 0;
		
		connect("CMGNS"); // DB Connection
		try {
			SqlWrapper sql = new SqlWrapper();
			sql.put(findQuery("service-sql", "SEL_DEPOTVEN_CD"));	
			sql.setString(++i, BinCD);
			sql.setString(++i, admitDate);
			sql.setString(++i, admitDate);
			sql_debug = sql.debug(); // SQL debug
			result = executeQuery(sql);
		} catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
			System.out.println("[ERROR] " + e.getMessage());
		}
		
		return result;
	}

	
	public List<Map<Object, Object>> selCompareList(){
		List<Map<Object, Object>> result = null;
		String sql_debug = null;
		
		connect("CMGNS"); // DB Connection
		try {
			SqlWrapper sql = new SqlWrapper();
			sql.put(findQuery("service-sql", "SEL_COMPARE_LIST"));			
			sql_debug = sql.debug(); // SQL debug
			result = executeQuery(sql);
		} catch(Exception e) {
			logger.info("[ERROR] " + e);
			
		}
		
		return result;
	}

}