/*
 * TranAction.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */

package biz.cms_TranRcvSnv;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;


/** 
 * TranAction
 * 
 * A Class that has inherited ServerAction(ServerAction을 상속받은 클래스)
 * A class to receive and process Tran data through 9035 port(트란데이타를 9035포트로 수신 받아 처리하는 클래스) 

 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */ 
public class SnvTranRcvAction extends ServerAction {
    //Createlog4j instance( log4j의 인스턴스를 생성합니다).
    //At the moment, logger designate its own class name as PakageName.ClassName(이때 로거는 PakageName.ClassName으로 자신의 클래스명을 지정합니다)
	private static Logger logger = Logger.getLogger(SnvTranRcvAction.class);

    /**
     * Receive Tran data from SNV through 9035 PORT(SNV로부터 트란데이타를 9035 PORT로 받음).
     * 
     * @param ActionSocket
     * @return 
     * @throws Exception
     */
	public void execute(ActionSocket actionSocket) throws Exception  {
		// TODO Auto-generated method stub
		int ret=0;
		String sendMsg="";
		String rcvBuf="";		
		String retValue = "OK!";
		HashMap hmCommon = new HashMap(); 
		HashMap hmData = new HashMap();
		SnvTranRcvDAO dao = new SnvTranRcvDAO();	
		COMMLog df = new COMMLog();
	
		try {
			// Tran Data received from SNV(SNV로부터 받은 트란 데이타) 
			rcvBuf=((String)actionSocket.receive());
			//logger.info("rcvBuf=["+rcvBuf+"]");
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
//			// Set Work Start Time(업무시작시간설정) 
//			df.setStartTime();		
//			df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString(),
//					             String.valueOf(actionSocket.getSocket().getPort()), logger, "TRAN" );
			
			logger.info("▶ 1: Receive Data: " + rcvBuf);	
			// Save header of message data to hmCommon(전문데이타의 헤더부분을 hmCommon에 저장한다).
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			//logger.info("▶ 2: Receive Data: " + rcvBuf);
			// Compare to see if MsgType message type value is TRAN(MsgType 전문구분값이 TRAN 인지 비교한다).
			if ( !(COMMBiz.getCommMsgType(hmCommon, COMMBiz.TRAN)) ) {			
				return;
			}
			//logger.info("▶ 3: Receive Data: " + rcvBuf);
			// Save message part of message data to hmData(전문데이타의 메세지부분을 hmData에 저장한다).
			hmData = COMMBiz.getData(rcvBuf, COMMBiz.TR_HEADER);
			//logger.info("▶ 3.1: Receive Data: " + rcvBuf);	
			// Check type of transaction(거래종별 확인 하기)
			if (COMMBiz.getTranType(hmData) == COMMBiz.ERR) {
				//logger.info("▶ 4: Receive Data: " + rcvBuf);	
				// In the case of error, save it to COMMBiz.Err table(오류인경우 COMMBiz.Err 테이블에 저장하기).
//				ret = dao.setErrData(rcvBuf, df);
				ret = dao.setErrData(rcvBuf);
			} else { 
				// Save to STTRP010DT Table(STTRP010DT 저장함).
				//logger.info("▶ 5: Receive Data: " + rcvBuf);	
//				ret = dao.setData(hmData, rcvBuf, COMMBiz.TB_INS_STTRP010DT, df);
				ret = dao.setData(hmData, rcvBuf, COMMBiz.TB_INS_STTRP010DT);
			}
		
		} catch (Exception e) {
			//029=HOST APPL ERR
			ret = 29;
			retValue = "[ERROR]4: " + e.getMessage();
//			logger.info("▶ "+ retValue);			
			logger.info("▶ "+ retValue);
		} finally {
			if( ret != 0 ) {
				//dao.spSMSSEND("매출TRAN INSERT 오류", "cms_TranRcv");
			}
		}
		
		try {		 
			// logger.info("--- makeSendData:"+ret);
			// Make Response Message Data(응답 전문데이타 만들기) 
			
			String tmp =(String)hmCommon.get("POS_NO");
			
			if (Integer.parseInt(tmp)<2000){
				logger.info("▶ ▶ ▶ ▶POS");
				sendMsg = COMMBiz.makeSendData(hmCommon,0, ret); //leeseunghho				
			}else {
				logger.info("▶ ▶ ▶ ▶ SNV");	
				sendMsg = makeSendData(hmCommon,10, ret); //SNV 요청으로 tran 의 경우 10 byte 더미 응답 보냄 leeseunghho 	
			}
			
			if (actionSocket.send(sendMsg)) {			
				logger.info("▶ SEND MSG: "+sendMsg + " ==>LEN: " + sendMsg.length());	
			} else {
//				logger.info("▶[ERROR]5: "+sendMsg + " ==>LEN: " + sendMsg.length());
				logger.info("▶[ERROR]5: "+sendMsg + " ==>LEN: " + sendMsg.length());
			}
		} catch (Exception e) {
			retValue = "[ERROR]6: " + e.getMessage();
//			logger.info("▶ "+ retValue);
			logger.info("▶ "+ retValue);
		} finally {
			// Tran Work Finish Log(트란업무 종료 로그) 
//			df.close("TRAN", retValue);
		}
	}
	
	
	public static String makeSendData(HashMap hmCommon, int cmLens, int ret){
		StringBuffer sb = new StringBuffer();
		int nlens[]= {6,2,5,4,4,8,8,6,3,4,10};  
		
		String strHeaders[] = {
				"MSG_LEN",  	
				"MSG_TYPE", 	
				"STORE_CD",
				"POS_NO",  
				"TRAN_NO", 
				"TRAN_YMD",
				"SYS_YMD",
				"SYS_HMS", 
				"ERR_CD",   
				"COM_CD",
				"DUMMY"
			};	 
		
		hmCommon.put("MSG_LEN", StringUtil.lPad(String.valueOf(cmLens),6,"0")) ;
		hmCommon.put("SYS_YMD", (new SimpleDateFormat("yyyyMMdd")).format( new Date() )) ;
		hmCommon.put("SYS_HMS", (new SimpleDateFormat("HHmmss")).format( new Date() )) ;
		hmCommon.put("ERR_CD",   StringUtil.lPad(String.valueOf(ret),3,"0")) ;	
		hmCommon.put("DUMMY",   "0000000000") ;
		
		for (int i=0; i < nlens.length ; i++) {
			StringUtil.appendSpace(sb, (String)hmCommon.get(strHeaders[i].toString()), nlens[i]);   
		}

	    //sb.append("\n");
		//sb.append("\r\n");
		return sb.toString();
	}
	
	
	
	
	
	
}
