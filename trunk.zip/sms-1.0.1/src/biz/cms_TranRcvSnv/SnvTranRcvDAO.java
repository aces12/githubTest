/*
 * TranDAO.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */

package biz.cms_TranRcvSnv;

import java.sql.SQLException;
import java.util.HashMap;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;


public class SnvTranRcvDAO extends GenericDAO{	
	
	private static Logger logger = Logger.getLogger(SnvTranRcvAction.class);
	
	public int spSMSSEND(String strMsg, String strSender) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("stsys-sql", "PR_SMSSEND"));
			sql.setString(++i, strMsg);
			sql.setString(++i, strSender);
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
	/***
	 * Save to Sale FMCVS.STTRP010DT Table(Sale FMCVS.STTRP010DT 테이블에 저장)
	 * @param hm ReceiveMSG
	 * @param rcvBuf clobData
	 * @param tblTran Storage Data(저장테이타) 
	 * @param df Log(로그)
	 * @return retrun ERR MSG CODE
	 * @throws Exception
	 */
	public int setData(HashMap hmData, String rcvBuf, String tblTran) throws Exception{
		int rows=0;
		int ret=0;
		SqlWrapper sql = new SqlWrapper();
		
		connect("CMGNS");		
		try {
			// Save SET DATA Start Log(SET DATA시작  로그저장)
			//logger.info("▶ 2: SetData: " + tblTran);

			sql = new SqlWrapper();
			sql.put(findQuery(COMMBiz.XML_TRAN_SQL,  tblTran));
			sql.setString(1,  (String)hmData.get("TRAN_YMD"));
			sql.setString(2,  (String)hmData.get("COM_CD"));
			sql.setString(3,  (String)hmData.get("STORE_CD"));
			sql.setString(4,  (String)hmData.get("POS_NO"));
			sql.setString(5,  (String)hmData.get("TRAN_NO"));
			sql.setString(6,  (String)hmData.get("SYS_YMDHMS"));
			sql.setString(7,  (String)hmData.get("TRAN_TYPE"));
			sql.setString(8,  (String)hmData.get("TRAN_KIND"));
			sql.setString(9,  (String)hmData.get("OP_NO"));
			sql.setString(10, (String)hmData.get("PMOD_YN")); //sql.setString(10, (String)hmData.get("APPR_NO"));
			sql.setString(11, (String)hmData.get("STOP_YN"));
			sql.setString(12, getRfValue((String)hmData.get("TRAN_TYPE"), tblTran)); //RFND_YN
			sql.setString(13, (String)hmData.get("ORG_TRAN_YMD"));
			sql.setString(14, (String)hmData.get("ORG_STORE_CD"));
			sql.setString(15, (String)hmData.get("ORG_POS_NO"));
			sql.setString(16, (String)hmData.get("ORG_TRAN_NO"));
			sql.setString(17, (String)hmData.get("ORG_RES_ID"));
			sql.setString(18, (String)hmData.get("APP_OP_NO") );
			sql.setString(19, (String)hmData.get("CUST_CLS_ID"));
			sql.setString(20, (String)hmData.get("CUST_COUNT"));
			sql.setString(21, (String)hmData.get("ORDER_TYPE"));
			sql.setString(22, (String)hmData.get("FLOOR_CD"));
			sql.setString(23, (String)hmData.get("TABLE_NO"));
			sql.setString(24, (String)hmData.get("GSALE_AMT"));
			sql.setString(25, (String)hmData.get("GDC_AMT"));
			sql.setString(26, (String)hmData.get("NSALE_AMT"));
			sql.setString(27, (String)hmData.get("SCHARGE_AMT"));
			sql.setString(28, (String)hmData.get("DRAWER_CD"));
			sql.setStringForClob(29, (String)rcvBuf);  //clob or text

			begin();


			rows = executeUpdate(sql); 
			//logger.info("▶ [DEBUG]SQL:"+ sql.debug());
//			logger.info("▶ 3: executeUpdate STTRP010DT ROW: "+rows );	
			// Save POS Status to Table(POS상태 테이블에 저장 함). 
			rows = setPosState(hmData); 		
			ret = 0;
//			logger.info("▶ 4: executeUpdate STBDA090AT ROW: "+rows );	
//			logger.info("+0531+"+tblTran+"++");
			
		} catch(SQLException e){
			logger.info("▶ [DEBUG]SQL:"+ sql.debug());
			rows = executeUpdate(sql);
//			logger.info("▶ [ERROR]2:"+ e.getErrorCode());
//			logger.info("▶ [ERROR]2 Msg:"+ e.getMessage());
			logger.info("▶ [ERROR]2 Msg:"+ e.getMessage() + "(" + e.getErrorCode() + ")");
			
//			System.out.println("▶ [DEBUG]SQL:"+ sql.debug());
//			System.out.println("▶ [DEBUG]MSG:"+ e.getMessage() );
			// In the case of duplicated data, return value is normal, or otherwise, return 20 DB ERROR(데이타 중복인 경우는 리턴값이 정상이고, 그 외에는 20 DB ERROR 리턴) 
			// 중복키 에러 : 오라클 버전 에러코드 1 ??
			if (e.getErrorCode()!=1){
//				logger.info("▶ [DEBUG]SQL:"+ sql.debug());
				logger.info("▶ [DEBUG]SQL:"+ sql.debug());
				ret=20;
			}
//			// 접속 에러 : MSSQL 접속/로그인실패 0
//			if (e.getErrorCode()==0){
//				ret=20;
//			}
//			// 중복키 에러 : MSSQL 버전 에러코드 2627
//			if (e.getErrorCode()==2627){
//				ret=20;
//			}
			rollback();	
			
		} catch (Exception e) {		
//			logger.info("▶ [ERROR]3:" + e);	
			logger.info("▶ [ERROR]3:" + e);
			// HOST ERROR RETURN
			ret=29;
			rollback();
			throw e;
		} finally {			
			end();
			//logger.info("▶ 5: SetData END return: "+ret);				
		}
		
		return ret;
	}
	
	/***
	 * getRfValue
	 * @param tranTy
	 * @param tbl
	 * @return
	 */
	private String getRfValue(String tranTy, String tbl){
		String value="";
		boolean mode = false;

		if (tbl.equals(COMMBiz.TB_INS_STTRP020DT)||tbl.equals(COMMBiz.TB_INS_STTRP030DT)) {
			mode = true;
		}
		if (tranTy.equals("0")){
			value = (mode ?  "N" : "0");
		} else {
			value = (mode ?  "Y" : "1");
		}		
		return value;
	}
	
	/***
	 * setPosState  Save POS Status E Data(POS상태 E데이타 저장) 
	 * @param tranYmd Tran Date(트란일자)
	 * @param storeCd Store Code(점포 코드)
	 * @param posNo   POS No.(포스번호) 
	 * @return 
	 * @throws Exception
	 */
	private int setPosState(HashMap hmData) throws Exception{
		int ret=0;
		SqlWrapper sql = new SqlWrapper();

		try {			
			sql = new SqlWrapper();			
			sql.put(findQuery(COMMBiz.XML_TRAN_SQL, COMMBiz.TB_MER_STBDA090AT));
			sql.setString(1, (String)hmData.get("TRAN_YMD"));
			sql.setString(2, (String)hmData.get("COM_CD"));
			sql.setString(3, (String)hmData.get("STORE_CD"));
			sql.setString(4, (String)hmData.get("POS_NO"));
			sql.setString(5, (String)hmData.get("TRAN_NO"));
			ret = executeUpdate(sql); 
		} catch (Exception e) {
//			logger.info("▶ [DEBUG]SQL"+ sql.debug());
			logger.info("▶ [DEBUG]SQL"+ sql.debug());
//			System.out.println("▶ [DEBUG]SQL:"+ sql.debug());
			throw e;
		}
		return ret;
	}
	
	
	/***
	 * setErrData : Saved in Exception TRAN Table(예외 TRAN 테이블에 저장) 
	 * @param rcvBuf
	 * @param df
	 * @return
	 * @throws Exception
	 */
	public int setErrData(String rcvBuf) throws Exception{
		int row=0;	
		int rtn=0;
		SqlWrapper sql = new SqlWrapper();
		
		connect("CMGNS");		
		try {
			begin();
			sql = new SqlWrapper();
			sql.put(findQuery(COMMBiz.XML_TRAN_SQL, COMMBiz.TB_INS_STTRP000ZT));										
			sql.setStringForClob(1, rcvBuf.toString());  //clob		
			
			row = executeUpdate(sql); 
			//logger.info("▶ Tran_SetErrData ["+row + "]");
			
		} catch (Exception e) {
//			logger.info("▶ [ERROR1]: " + e.getMessage());
			logger.info("▶ [ERROR1]: " + e.getMessage());
			rtn = 99;
			rollback();
			throw e;
		}	
		finally {
			end();
		}
		
		return rtn;
	}	
		

}
