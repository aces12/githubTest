package biz.cms_MasterCrtEx;

import java.util.Iterator;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.CurrentContext;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.node.EngineContainer;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.cms_DeployReq.DeployReqClientAction;
import biz.cms_MasterAgentEx.MasterAgentExPollingAction;

public class MasterCrtExRunner extends Thread {
	private static Logger logger = Logger.getLogger(MasterAgentExPollingAction.class);
	
	private MasterCrtExClientAction action = null;
	private Map<String, String> map = null;
	private DaemonConfigLocator locator = null;
	
	/**
	 * Create MasterRunner(MasterRunner 생성)
	 * @param action
	 */
	public MasterCrtExRunner(MasterCrtExClientAction action) {
		this.action = action;
	}
	
	/**
	 * Set Map value transferred from MasterAction(MasterClientAction에서 넘어온 Map 값 셋팅) 
	 * @param map
	 */
	public void setMap(Map<String, String> map) {
		this.map = map;
	}
	
	public static String[] getMapKeys(Map<String, String> map) {
		if (map == null) {
			return null;
		}
		String[] ret = new String[map.size()];
		int inc = 0;
		for (Iterator<String> i = map.keySet().iterator(); i.hasNext();) {
			ret[inc++] = (String) i.next();
		}

		return ret;
	}
	
	/**
	 * Execute Generation of Deployment File(배신 파일 생성 실행)
	 */
	public void run(){
		try {
			// TODO Auto-generated method stub
			int ret = -1;
			
			// thread +		
			action.msControl.useThread();
			logger.info("★1");		

			ret = generateMasterFile(map);
			logger.info("★2");		  

			action.workIncrement();	
			logger.info("★3");		
			
			action.msControl.returnThread();
			logger.info("★4");		
					
			
			// Execute deploy(배신실행)
			// If total count equal to cumulative count, execute deployment. (작업갯수와 누적작업 갯수가 같으면 배신 실행)
			//logger.info("TotalCnt :"+action.getTotal()+"::: CurrentCnt: "+action.getCnt());
			logger.info("__WORK: " +  action.getWork());
			
			if (action.getStatus()) {
				logger.info("**************************   The end" );
				logger.info("**************************   Go Deploy" + action.getDeploy());
			}
			
			if(action.getStatus()) {
				// 점포 SC 존재시  본부서버->SC 소켓전송 Deploy,
				// 점포 SC 존재하지 않을시 POS의 배신요청에서만 처리하므로 하단 주석처리
				logger.info("1 : " + action.getDeploy());
				if (! action.getDeploy()) return;
				logger.info("2 : " + action.getDeploy());
				DeployReqClientAction deploy = new DeployReqClientAction();
				logger.info("3 : " + action.getDeploy());
				


				deploy.setDelay(0);
				deploy.setMaxThread(10);
				deploy.setTransID("MST");
				deploy.setComcd("%");
				deploy.setStore("%");
				deploy.setTransYmd(action.getTransYmd());
				deploy.setPath(action.getPath());

				logger.info("4 : " + action.getDeploy());
				
				locator = DaemonConfigLocator.getInstance("xml",action.getPath() );
				locator.setCurrentContext(new CurrentContext(locator.getDaemonConfig()
						.getNode().getEngineContainer("cms_DeployReq")));	
				
				String[] name = getMapKeys(locator.getDaemonConfig().getNode().getEngineContainers());
			    for(int i=0; i<name.length; i++) {
			    	logger.info( "5: Action " +
			    	locator.getDaemonConfig().getNode().getEngineContainer(name[i]).getAction()
			    	);
			    }
				
			    
			    logger.info(locator.getCurrentContext().getContext().getAction());
			    logger.info("6: " + action.getDeploy());
				//DaemonContainer container = new ActionClientContainer(locator.getCurrentContext().getContext());
				//Thread t = new Thread(container);
				//t.start();
								
				EngineContainer context = locator.getDaemonConfig().getNode().getEngineContainer("cms_DeployReq");
				logger.info("7: " + action.getDeploy());

				deploy.execute();

				
				/*
				DeployClientAction deploy = new DeployClientAction();
				DaemonConfigLocator locator = DaemonConfigLocator.getInstance();
				EngineContainer context = locator.getDaemonConfig().getNode().getEngineContainer("deploy");
				String port = context.getContainerManagement().getInternalPort();

				// Connect deploy (배신엔진 접속)
				InetSocketAddress endpoint = new InetSocketAddress("localhost", Integer.parseInt(port));
				Socket socket = new Socket();
				socket.connect(endpoint, 100);
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
				out.print("wakeup\n");	// Work order to deploy engine(deploy 엔진 작업명령 )
				out.flush();
				
				deploy.execute();
				*/
			}
			
			
		} catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
	}
	
	/**
	 * generateMasterFile - Generate Deployment File(배신 파일 생성)
	 * @param map
	 * @return int 
	 */
	private int generateMasterFile(Map<String, String> map) {
		MasterCrtExExecutor exe   = new MasterCrtExExecutor();
		MasterCrtExDAO dao   = new MasterCrtExDAO();
		String transId = (String)map.get("trans_id");
		String fileDir = null;
		int ret = -1;
		
		try {
			//System.out.println("trans_id : " + transId);
			// Generate Deployment File : POS Master(배신 파일 생성 : POS 마스터)
			if(transId.equals("MST")) {
				fileDir = exe.runMst(map);		// Return directory on whick file has been generated(파일이 생성된 디렉토리 리턴)
			} 
			// Generate Deployment File : Owner POS Master(배신 파일 생성 : 점주 POS 마스터)
			else if(transId.equals("POSDLL")) {
				fileDir = exe.runMst(map);		// Return directory on whick file has been generated(파일이 생성된 디렉토리 리턴)
			} 
//			// Generate Deployment File : FF-IMAGE Master(배신 파일 생성 : FF-IMAGE 마스터)
//			else if(transId.equals("FFIMG")) {
//				fileDir = exe.runFFImg(map);	// Return directory on whick file has been generated(파일이 생성된 디렉토리 리턴)
//			}

			//파일생성 경로를 FTP 다운로드 경로로 변환
			// 마스터 배포 방식 변경 시작(20131125/조충연)
			/*
			String basePath = PropertyUtil.findProperty("stsys-property", "FTP_ROOT");	// FTP 루트 
			String addPath  = ((String)map.get("urgent_yn")).equals("0") ? "deploy" : "urgent";
			String ftpPath = basePath+"/"+(String)map.get("trans_id")+"/"+(String)map.get("trans_ymd")+"/"+addPath+"/"+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+".zip"; // (FTP 다운로드 풀경로)
			*/
			if( !fileDir.equals("ERROR") ) {
				String basePath = PropertyUtil.findProperty("stsys-property", "FTP_ROOT");	// FTP 루트 
				String addPath = "";
				String ftpPath = "";
				if(((String)map.get("urgent_yn")).equals("0")) {		// 정기배신
					addPath = "deploy";
					ftpPath = basePath+"/"+(String)map.get("trans_id")+"/"+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+"/"+addPath+"/"+(String)map.get("trans_ymd")+"/"+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+".zip"; // (FTP 다운로드 풀경로)
				}else if(((String)map.get("urgent_yn")).equals("1")) {	// 긴급(전체)
					addPath = "urgent1";
					ftpPath = basePath+"/"+(String)map.get("trans_id")+"/"+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+"/"+addPath+"/"+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+".zip"; // (FTP 다운로드 풀경로)
				}else if(((String)map.get("urgent_yn")).equals("2")) {	// 긴급(변경row)
					addPath = "urgent2";
					ftpPath = basePath+"/"+(String)map.get("trans_id")+"/"+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+"/"+addPath+"/"+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+".zip"; // (FTP 다운로드 풀경로)
				}
				// 마스터 배포 방식 변경 끝(20131125/조충연)
	
				map.put("trans_file_dir", ftpPath);
	
				// DB Update - Correct Deployment status value(DB 업데이트 - 배신 상태값 수정)
	//System.out.println(">>>>>>>>>>>>>>>>>fileDir::" + fileDir);
	//System.out.println(">>>>>>>>>>>>>>>>>ftpDir::" + ftpPath);
	//System.out.println(">>>>>>>>>>>>>>>>>Before Deploy Update");
				ret = dao.updSTBDA120AT1(map, "2");  //마스터생성완료 플래그세팅
	//System.out.println(">>>>>>>>>>>>>>>>>After Deploy Update");
//				if(ret > 0) ret = 1;
			}else {
				dao.spSMSSEND("POS마스터파일 생성 실패", "cms_MasterCrt");
				// 배신생성실패 플래그세팅
				ret = dao.updSTBDA120AT1(map, "F");	
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return ret;
	}
}
