package biz.cms_MasterCrtEx;

import java.util.Date;
import java.util.List;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.cms_MasterAgentEx.MasterAgentExPollingAction;

public class MasterCrtExClientAction {
	private static Logger logger = Logger.getLogger(MasterAgentExPollingAction.class);
	
	public static MasterCrtExControl msControl = new MasterCrtExControl();
	private static int totalCount=0;
	private static int jobThread=0;
	private static int work=0;
	private int maxThread=0;
	private String Com = "";
	private String Store = "";
	private String transYmd = "";
	private boolean deploy = false;
	private String path = "";
	
	public void setCom(String com) {
		this.Com = com;
	}
	public String getCom() {
		return this.Com;
	}
	
	public void setStore(String store) {
		// TODO Auto-generated method stub
		this.Store = store;
	}
	public String getStore() {
		return this.Store;
	}
	
	public static void increment(){
		jobThread++;
	}

	public static void decrement(){
		jobThread--;
	}
	
	public static void workIncrement(){
		++work;
	}
	
	public int getWork(){
		return work;
	}
	
	public static int getJobThread(){
		return jobThread;
	}
	
	public static boolean getStatus(){
		if (work==totalCount) return true;
		return false;
	}
	
	public int getMaxThread(){
		return maxThread;
	}
	
	public void setMaxThread(int maxThread){
		this.maxThread = maxThread;
		this.jobThread = maxThread;
	}
	
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}

	public String getTransYmd(){
		return transYmd;
	}
	public void setTransYmd(String ymd){
		this.transYmd = ymd;
	}
	

	public boolean getDeploy(){
		return deploy;
	}
	public void setDeploy(boolean deploy){
		this.deploy = deploy;
	}
	
	public String getPath(){
		return path;
	}
	public void setPath(String path){
		this.path = path;
	}
	
	//thread_max, delay_time, tran_ymd, tran_id, store_cd
	public static void main(String args[]) throws Exception {
		MasterCrtExClientAction master = new MasterCrtExClientAction();
		
		if (args == null || args.length < 1) {
			logger.info("------ master main args null");
		}
		
		//System.out.println("[DEBUG] [path]=" + path);
		//System.out.println("[DEBUG] [fileName]=" + fileName);
		System.out.println("[DEBUG] [args[0]]=" + args[0] );
		System.out.println("[DEBUG] [args[1]]=" + args[1] );
		System.out.println("[DEBUG] [args[2]]=" + args[2] );
		System.out.println("[DEBUG] [args[3]]=" + args[3] );
		System.out.println("[DEBUG] [args[4]]=" + args[4] );
		System.out.println("[DEBUG] [args[5]]=" + args[5] );
		
		String thread_max    = nvl(args[0].replaceFirst("-tm:"    ,""));
		String trans_ymd     = nvl(args[1].replaceFirst("-ty:"    ,""));
		String com           = nvl(args[2].replaceFirst("-com:" ,""));
		String store         = nvl(args[3].replaceFirst("-store:" ,""));
		String path          = nvl(args[4].replaceFirst("-path:"  ,""));
		String deploy        = nvl(args[5].replaceFirst("-deploy:"  ,""));
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		//default_thread_max
		if (thread_max.equals("")) thread_max = "10"; 
		master.setMaxThread(Integer.parseInt(thread_max));
		//default trans_ymd = now
		if (trans_ymd.length()!=8) {
			Date now = new Date();
			trans_ymd = StringUtil.getDataFormat(now, "yyyyMMdd");
		}
		master.setTransYmd(trans_ymd);
		//com_cd
		if (com.equals("")) com = "%";
		master.setCom(com);
		//store_cd
		if (store.equals("")) store = "%";
		master.setStore(store);
		
		master.setPath(path);
		
		//SC가 있어 배신정보 전송을 할때
		//if (deploy.equals("true")) master.setDeploy(true);
		//else master.setDeploy(false);
		//SC가 없어 배신정보 전송을 하지 않을때
		master.setDeploy(false);
		
		logger.info("thread_max : " + thread_max);	
		logger.info("trans_ymd  : " + trans_ymd);	
		logger.info("com        : " + com);	
		logger.info("store      : " + store);	
		logger.info("path       : " + path);		
		logger.info("deploy     : " + deploy);	
		
		master.execute();
	}
	
	public void execute() {
		try {
			MasterCrtExDAO dao   = new MasterCrtExDAO();
			List<Object> list = null;

			list = dao.selSTBDA120AT(getTransYmd(), getCom(), getStore());
			totalCount = list.size();
//			logger.info("totalCount : " + totalCount);

			// If there is no subjective store, print log(대상 점포가 없으면 로그찍기)
			if(totalCount < 1) {
//				logger.info("[ERROR] There is no data.");
				return;
			}
		
			// Make master data as many as the No. of subjective stores as a file(대상 점포수 만큼 마스터데이터를 파일로 만듬)
			String trans_id = "";
			for(int j=0; j<totalCount; j++) {
//				logger.info("Max Thread:" + getMaxThread() + ", Job Thread:" + getJobThread());
				Map<String, String> map = (Map<String, String>)list.get(j);
				
				trans_id = (String)map.get("trans_id");
				if( trans_id.equals("MST") ) {
					dao.updSTBDA120AT0(map);	// 마스터생성중 플래그 세팅
				}
				
				// Create thread(쓰레드 생성)
				MasterCrtExRunner ms = new MasterCrtExRunner(this);
				
				// Transfer map(map을 넘겨 줌)
				ms.setMap(map);
				
				// Execute thread(쓰레드 실행)
				ms.start();					
			}
			
		} catch (Exception e) {
			logger.info("", e);
		}
	}
}
