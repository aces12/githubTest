package biz.cms_MasterCrtEx;

public class MasterCrtExControl {
	public synchronized void useThread() throws InterruptedException {
		//System.out.println( "lend :" + MasterCrtClientAction.getJobThread());
		if (MasterCrtExClientAction.getJobThread() <= 0) {
			//System.out.println(t.getName() + ": wating...");
			this.wait();
			//System.out.println(t.getName() + ": return...");
		}
		MasterCrtExClientAction.decrement();
	}
	
	public synchronized void returnThread() {
		MasterCrtExClientAction.increment();
		this.notify();
	}
}
