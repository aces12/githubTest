package biz.cms_DGBSender;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class DGBSenderProtocol {
	public static int COMM_LEN = 20;
	public static int LENGTH_BY_SEQUENCE = 3900;
	
	public String getResCD(String recvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3,4,4,1
					  ,1,3};
		String strHeaders[] = {
			"TLGM_LEN",
			"WORK_CD",
			"COMPANY_CD",
			"TLGM_CD",
			"DEAL_TP",
			
			"SNDRCV_FG",
			"RES_CD"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);
		
		return (String)hm.get("RES_CD");
	}
	
	public List<Integer> getRecvData0300(String recvBuf) {//전문포함길이라수정해야돼
		int totErrNum = 0;
		String chkStr = "";	
		List<Integer> array = new ArrayList<Integer>();
		
		int len = Integer.parseInt(recvBuf.substring(0,4));
		int lossChkLen = len - 54;
		
		totErrNum = Integer.parseInt((recvBuf.substring(51, 54)).trim());
		chkStr = recvBuf.substring(54, 54 + lossChkLen);
		for( int i = 0;i < lossChkLen;i++) {
			if( array.size() == totErrNum ) break;
			if( chkStr.charAt(i) == '0') {	// 결번 Sequence Number 확인
				array.add(i);
			}
		}
		
		return array;
	}
	
	public boolean get0610WhetherNormality(String recvBuf, String strMgrCd, COMMLog df) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3,4,4,1
					  ,1,3,24,10,3
					  ,20,16};
		boolean bRet = false;
		String strHeaders[] = {
			"TLGM_LEN",
			"WORK_CD",
			"COMPANY_CD",
			"TLGM_CD",
			"DEAL_TP",
			
			"SNDRCV_FG",
			"RES_CD",
			"FILE_NM",
			"TRANS_TIME",
			"MANAGE_INFO",
			
			"SENDER_NM",
			"SENDER_PW"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);

//		df.CommLogger(" >>>>>>>>>>>>>>>>>>>>>> here");
		
		if( ((String)hm.get("TLGM_CD")).equals("0610") 
				&& ((String)hm.get("MANAGE_INFO")).equals(strMgrCd) ) {
//			df.CommLogger(" >>>>>>>>>>>>>>>>>>>>>> here111111111");
			if( ((String)hm.get("RES_CD")).equals("000") ) {
//				df.CommLogger(" >>>>>>>>>>>>>>>>>>>>>> here2222222222");
				bRet = true;
			}
		}
		
		return bRet;
	}
	
	public String getRecvData0640(String recvBuf, String key) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3,4,4,1
				  	  ,1,3,24,12,4};
		
		String strHeaders[] = {
			"TLGM_LEN",
			"WORK_CD",
			"COMPANY_CD",
			"TLGM_CD",
			"DEAL_TP",
				
			"SNDRCV_FG",
			"RES_CD",	
			"FILE_NAME",
			"FILE_SIZE",
			"TLGM_BYTE_NUM"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);
		
		return (String)hm.get(key);
	}
}
