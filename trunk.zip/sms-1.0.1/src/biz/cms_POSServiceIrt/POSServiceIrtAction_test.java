package biz.cms_POSServiceIrt;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class POSServiceIrtAction_test extends ServerAction {
	private static Logger logger = Logger.getLogger(POSServiceIrtAction.class);
	POSServiceIrtDAO dao = new POSServiceIrtDAO();
	
	public static void main(String args[]) throws Exception {
		POSServiceIrtAction_test action = new POSServiceIrtAction_test();
		
		try {
			String path = "C:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			HashMap<String, String> map = new HashMap<String, String>();
			String readedLine = new String("ASCII");
			
			action.execute("");
			
		}catch(Exception e) {
			System.out.println("[Received Data]=" + e.getMessage());
		}
	}
	
	/**
	 * Receive data from SC through 9034 PORT(SC로부터 데이타를 9034 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(String data) throws Exception {
		// TODO Auto-generated method stub
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		StringBuffer sb = null;
		
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		
		POSServiceIrtProtocol protocol = new POSServiceIrtProtocol();
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			//rcvBuf = ((String) actionSocket.receive());
			
			//rcvBuf = "00005306009990001000120180326201803261328120001002E92";
			//rcvBuf = "00005306009990001000120180326201803261328120001002E91";
			rcvBuf = "00005306009990001000120180326201803261328120001002F122742885031                                                                                                          ";
			System.out.println("[INFO] EConIRT::rcvBuf::[" + rcvBuf + "]");
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			System.out.println("[INFO] EConIrt::hmCommon::["+hmCommon+"]");
			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}

			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			System.out.println("[INFO] EConIRT::rcvDataBuf::["+rcvDataBuf+"]");
			inq_type = COMMBiz.getInqTypeCHG(protocol.getRcvEConIrtDATA(rcvDataBuf));
			
			boolean bIsExtended = false;
			
			System.out.println("[INFO] EConIRT::inq_type::["+inq_type+"]");
			switch(inq_type) {
				case 2196:	// E9(2196): 비상벨 SMS전송 서비스 요청/응답
					System.out.println("Emergency Bell Service START");
					
					//전문길이 체크 (3bytes)
					if (rcvDataBuf.length() == 3) {
						hmData = protocol.getParseEmSMSReq(rcvDataBuf);
						
						System.out.println("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
						System.out.println("[INFO] EConIRT::hmData::["+hmData+"]");
						
						dataMsg = SendEmerSms(hmCommon, hmData); //비상벨 SMS 전송
						System.out.println("[INFO] EConIRT::dataMsg::["+dataMsg+"]");
					} else {
						System.out.println("[ERROR] IRT Length unmatched");
						hmData.put("RSLT_CD", "10");
						hmData.put("RSLT_MSG", "IRT 전문길이 오류");
						
						//dao.insEConIssLog(hmCommon, hmData);	//로그테이블 이력 쌓기(ST_COUPONISS_LOG)
						return;
					}
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
					
				case 2219:	// F1(2219): PT 출퇴근 요청/응답
					System.out.println("PT punch in/out Service START");
					
					//전문길이 체크 (3bytes)
					if (rcvDataBuf.length() == 119) {
						hmData = protocol.getParsePTPunchInOutReq(rcvDataBuf);
						
						System.out.println("[INFO] EConIRT::hmCommon::["+hmCommon+"]");
						System.out.println("[INFO] EConIRT::hmData::["+hmData+"]");
						
						dataMsg = PTPunchInOut(hmCommon, hmData); //비상벨 SMS 전송
						System.out.println("[INFO] EConIRT::dataMsg::["+dataMsg+"]");
					} else {
						System.out.println("[ERROR] IRT Length unmatched");
						hmData.put("RSLT_CD", "10");
						hmData.put("RSLT_MSG", "IRT 전문길이 오류");
						
						//dao.insEConIssLog(hmCommon, hmData);	//로그테이블 이력 쌓기(ST_COUPONISS_LOG)
						return;
					}
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
						
				default:
					System.out.println("[INFO] INQ Type Code::["+inq_type+"]::LEN::["+rcvBuf.length()+"]");
					ret = 99;
					break;
			}
		} catch (Exception e) {
			ret = 29; // 029=HOST APPL ERR
			retValue = "[ERROR]2:" + e.getMessage();
			System.out.println("▶ " + retValue);
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			System.out.println("dataMsg[" + dataMsg + "]");
			System.out.println("sendMsg[" + sendMsg + "]");
					
			System.out.println("================ 4-2) POS<-SMS 응답전문 ===================");
			System.out.println("전문길이=[" + totalMsg.getBytes().length + "]");
			System.out.println("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
			System.out.println("전문내용=[" + totalMsg + "]");
			
			// Send Response Data (응답 데이타 전송)
			System.out.println("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
		} catch (Exception e) {
			retValue = "[ERROR]4" + e.getMessage();
			System.out.println("▶ " + retValue);
		} finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			System.out.println("SSGMBSIRT END");
		}
	}
	
	
	//비상벨 SMS 전송
	private String SendEmerSms(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		System.out.println("[INFO] EConIRT::hmCom::["+hmCom+"]");
		System.out.println("[INFO] EConIRT::hmData::["+hmData+"]");
		
		String dataMsg  = "";
		String storeCd  = (String)hmCom.get("STORE_CD");
		String storeNm  = "";
		String storeAdd = "";
		String storeTel = "";
		String emerTp   = (String)hmData.get("EMER_TP");	//sms신고/취소 구분 (1:신고, 2:취소)
		String sendMsg  = "";
		String seq		= "";
		String ret		= "00";
		String respMsg  = "";
		String respCd   = "00";
		
		//점포정보 조회
		List storeInfo = null;
		HashMap<String, String> storeMap = new HashMap<String, String>();
		
		try {
			storeInfo = (List)dao.selStoreInfo(storeCd);
		
			System.out.println("[INFO] SendEmerSms::storeInfoSize::["+storeInfo.size()+"]::storeInfo::["+storeInfo+"]");
			if(storeInfo.size() > 0){
				for(int i=0; i<storeInfo.size(); i++){
					storeMap = (HashMap<String, String>)storeInfo.get(i);
					System.out.println("[INFO] EConIRT::emerTp::["+emerTp+"]::storeMap::["+storeMap+"]");
					
					storeNm = (String)storeMap.get("STORE_NM");
					storeAdd = (String)storeMap.get("STORE_ADD");
					storeTel = (String)storeMap.get("STORE_TEL");
					
					if("1".equals(emerTp)){
						//신고 sms
						sendMsg = "이마트24 "+storeNm+" 점포 긴급상황 발생. "+storeAdd;
					}else if("2".equals(emerTp)){
						//취소 sms
						sendMsg = "이마트24 "+storeNm+" 점포 접수 취소 바랍니다.";
					}
					
					try {
						seq = dao.selEmerSMSSeq();
						
						try{
							dao.insEmerSMSClient(storeMap, sendMsg, seq);
							respMsg = "정상완료";
						}catch (Exception e) {
							respCd  = "99";
							respMsg = "SMS전송실패";
							System.out.println("[ERROR] SendEmerSms::insEmerSMSClient::["+e.getMessage()+"]::["+e.getCause()+"]");
						}
					}catch(Exception e){
						respCd  = "99";
						respMsg = "SMS전송실패";
						System.out.println("[ERROR] selEmerSMSSeq::errMsg::["+e.getMessage()+"]::["+e.getCause()+"]");
					}
				}
			}
		} catch (Exception e) {
			ret = "29";
			respCd  = "99";
			respMsg = "SMS전송실패";
			System.out.println("[ERROR] SendEmerSms::selStoreInfo::["+e.getMessage()+"]::["+e.getCause()+"]");
		} finally {
			storeMap.put("INQ_TYPE", "E9");
			storeMap.put("RESP_CD",  respCd);
			storeMap.put("RESP_MSG", respMsg);
			
			dataMsg = ret + makeSendDataEmerSMSRsp(storeMap);
		}
		
		return dataMsg;
	}
	
	
	private HashMap<String, String> storeInfo(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	
	//2018326 KSN 비상벨 SMS 응답
	private String makeSendDataEmerSMSRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 2, 64
		};//68
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		for (int i = 0; i < nlens.length; i++) {
			System.out.println(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//20180329 KSN PT 출퇴근등록
	private String PTPunchInOut(HashMap<String, String> hmCom, HashMap<String, String> hmData){
		System.out.println("[INFO] POSServiceIrt::hmCom::["+hmCom+"]");
		System.out.println("[INFO] POSServiceIrt::hmData::["+hmData+"]");
		
		String dataMsg  = "";
		String ptCardNo = (String)hmData.get("CARD_DATA");	//PT출퇴근 카드정보
		String workTp   = (String)hmData.get("WORK_TP");	//출퇴근 구분 (1:출근, 2:퇴근)
		String workNm   = ""; 								//출퇴근 구분명(1:출근, 2:퇴근)
		String punchTp  = "";
		String dutyCd   = ""; 								//직원구분코드
		String dutyNm	= "";								//직원구분명
		String empNo	= "";								//임직원번호
		String ret		= "00";
		String respCd   = "00";
		String respMsg  = "";
		
		int punchCnt = 0;
		
		//1. PT직원여부 조회
		List ptInfo = null;
		HashMap<String, String> ptInfoMap = new HashMap<String, String>();
		HashMap<String, String> respMap = new HashMap<String, String>();
		
		try {
			if("1".equals(workTp)){
				workNm  = "출근";
				punchTp = "0";
			}else if("2".equals(workTp)){
				workNm  = "퇴근";
				punchTp = "1";
			}
			
			System.out.println("[INFO] selPTInfo::ptCardNo::["+ptCardNo+"]");
			ptInfo = (List)dao.selPTInfo(ptCardNo);
		
			System.out.println("[INFO] selPTInfo::ptInfoSize::["+ptInfo.size()+"]::ptInfo::["+ptInfo+"]");
			if(ptInfo.size() > 0){
				for(int i=0; i<ptInfo.size(); i++){
					ptInfoMap = (HashMap<String, String>)ptInfo.get(i);
					System.out.println("[INFO] EConIRT::workTp::["+workTp+"]::ptCardNo::["+ptCardNo+"]");
					
					dutyCd = (String)ptInfoMap.get("DUTY_CD");
					dutyNm = (String)ptInfoMap.get("DUTY_NM");
					empNo  = (String)ptInfoMap.get("EMP_NO");
					
					if("W22".equals(dutyCd) && "PT".equals(dutyNm)){
						punchCnt = dao.selPTPunchInfo(empNo, punchTp); //금일 출/퇴근등록여부 체크
						if(punchCnt == 0){
							try{
								respCd = dao.setPTPunchCheck(hmCom, ptInfoMap, punchTp);
								if("00".equals(respCd)){
									respMsg = "정상완료";
								}else{
									respMsg = workNm + " 등록실패";
								}
							}catch (Exception e) {
								respCd  = "99";
								respMsg = workNm + " 등록실패";
								System.out.println("[ERROR] SendEmerSms::insEmerSMSClient::["+e.getMessage()+"]::["+e.getCause()+"]");
							}
						}else{
							//기등록처리 메시지 전달
							respCd  = "99";
							respMsg = "금일 " + workNm + "등록이 이미 완료되었습니다.";
						}
					}else{
						//PT직원아님, 등록불가 메시지 전달
						respCd  = "99";
						respMsg = "PT직원아님, " + workNm + " 등록불가";
					}
				}
			}else{
				//PT직원없음, 등록불가 메시지 전달
				respCd  = "99";
				respMsg = "PT직원없음, " + workNm + " 등록불가";
			}
		} catch (Exception e) {
			ret = "29";
			respCd  = "99";
			respMsg = workNm + " 등록실패";
			System.out.println("[ERROR] SendEmerSms::selStoreInfo::["+e.getMessage()+"]::["+e.getCause()+"]");
		} finally {
			respMap.put("INQ_TYPE", "F1");
			respMap.put("WORK_TP",  "");
			respMap.put("CARD_DATA",  "");
			respMap.put("RESP_CD",  respCd);
			respMap.put("RESP_MSG", respMsg);
			
			dataMsg = ret + makeSendDataPTPunchRsp(respMap);
		}
		
		return dataMsg;
	}
	
	
	//2018329 KSN PT출퇴근 등록
	private String makeSendDataPTPunchRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 
			2, 1, 50, 2, 64
		};//119
		
		String strHeaders[] = {
			"INQ_TYPE"			, // INQ Type(INQ 종별)
			"WORK_TP"			, // 출퇴근 구분
			"CARD_DATA"			, // 카드센싱 정보
			"RESP_CD"			, // 응답코드
			"RESP_MSG"			  // 응답메시지
		};
		
		for (int i = 0; i < nlens.length; i++) {
			System.out.println(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	@Override
	public void execute(ActionSocket arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
}



