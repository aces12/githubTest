package biz.cms_ScAgentSender;

import java.util.List;

import org.apache.log4j.Logger;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class ScAgentSenderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(ScAgentSenderPollingAction.class);
	/**
	 * ScAgent 전송 대상 조회
	 * @return : ScAgent 전송 대상
	 */
	public List<Object> selScAgentSend(String val) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("acagent-sql", "SEL_SCAGENTSEND"));
			sql.setString(++i, val);
			list = executeQuery(sql);

		}catch(Exception e) {
			logger.info("[ERROR]SEL_SCAGENTSEND::" + e);
		} 
		
		return list;
	}
	
	public int upScAgentSend(String sc_dt, String store_cd, String sc_seq) {
		SqlWrapper sql = new SqlWrapper();
		int updateYn = 0;
		int i = 0;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");

			sql.clearParameter();
			sql.put(findQuery("acagent-sql", "UP_SCAGENTSEND"));
			sql.setString(++i, "8");
			sql.setString(++i, sc_dt);
			sql.setString(++i, store_cd);
			sql.setString(++i, sc_seq);

			updateYn = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]UP_SCAGENTSEND::" + e);
		}finally {
			end();
		}
		
		return updateYn;
	}

	public int upScAgentSendClear(String sc_dt, String store_cd, String sc_seq) {
		SqlWrapper sql = new SqlWrapper();
		int updateYn = 0;
		int i = 0;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");

			sql.clearParameter();
			sql.put(findQuery("acagent-sql", "UP_SCAGENTSEND_CLEAR"));

			updateYn = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]UP_SCAGENTSEND::" + e);
		}finally {
			end();
		}
		
		return updateYn;
	}
}
