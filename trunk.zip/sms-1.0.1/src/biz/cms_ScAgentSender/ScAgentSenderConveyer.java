package biz.cms_ScAgentSender;

import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.HashMap;

import org.apache.log4j.Logger;

import biz.cms_POSIrt.POSIrtProtocol;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

public class ScAgentSenderConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;
	private static Logger logger = Logger.getLogger(ScAgentSenderPollingAction.class);

	COMMLog df = null;

	public ScAgentSenderConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}

	public int ScAgentSenderConveyer(Object list) throws Exception {

		HashMap<String, String> hm = new HashMap<String, String>();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		HashMap<String, String> hmReq = new HashMap<String, String>();
		
		String sendMsg = "";	
		String recvBuf = "";
		int updateYn = 0;	

		hm = (HashMap<String, String>) list;
		
		try { 
			
			logger.info("▶ sc전송  ip : " + (String)hm.get("SC_IP") );			 

			//this.svrSock = new Socket((String)hm.get("SC_IP"),9006); //점포별 IP를 읽어온다.
			
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.STAFFCHECK_FILTER)));

			hmReq.put("SC_DT",        (String)hm.get("SC_DT"));     // SC작업일자           
			hmReq.put("STORE_CD",     (String)hm.get("STORE_CD"));    // SC작업순번           B.,B.,B.ACT_TEXT,B.FILE_NAME
			hmReq.put("SC_SEQ",       (String)hm.get("SC_SEQ"));    // SC작업순번           B.,B.,B.ACT_TEXT,B.FILE_NAME
			hmReq.put("SC_ACT",       (String)hm.get("SC_ACT"));    // SC작업구분            
//			hmReq.put("ACT_TEXT",     (String)hm.get("ACT_TEXT"));  // SC명령문            
			hmReq.put("FILE_NAME",    (String)hm.get("FILE_NAME")); // SC첨부파일            

			logger.info("▶ sc전송 : " + hmReq );			 

			sendMsg = makeSendDataScAgentSend(hmReq);
			
			logger.info("▶ sc전송  msg : " + sendMsg );		
			
			// Socket 통신 시작
			if( actSock.send(sendMsg) ) { // 요청 송신
				logger.info("[sms>ScAgent] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				logger.info("[sms>ScAgent] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("ScAgent server is no response");
			}
			
//			recvBuf = ((String)actSock.receive()); // 요청 수신
//			hmRecv = makeSendDataScAgentSendRsp(new String(recvBuf.getBytes("EUC-KR"),"ISO8859_1"));
			
//			ScAgentSenderDAO dao = new ScAgentSenderDAO(); 
//			updateYn = dao.upScAgentSend((String)hmRecv.get("SC_DT"), (String)hmRecv.get("STORE_CD"), hmRecv.get("SC_SEQ"));

		}catch(Exception e) { 
			logger.info("▶ [ERROR]1: " + e.getMessage());
			throw e;
		}finally {
			// Socket 통신 종료
			actSock.close(); 
		}
		
		return updateYn;
	}
	
	
	private String makeSendDataScAgentSend(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {8, 5, 5, 2, 20};
		String strHeaders[] = {
			"SC_DT",          // SC작업일자           
			"STORE_CD",       // SC점포           
			"SC_SEQ",         // SC작업순번           
			"SC_ACT",         // SC작업구분            
			"FILE_NAME"       // SC첨부파일            
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public HashMap<String, String> makeSendDataScAgentSendRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {8, 5, 5, 2, 100, 50};
		String strHeaders[] = {
				"SC_DT",          // SC작업일자           
				"STORE_CD",       // SC점포           
				"SC_SEQ",         // SC작업순번           
				"SC_ACT",         // SC작업구분            
				"ACT_TEXT",       // SC명령문            
				"FILE_NAME"       // SC첨부파일            
		};

		int bInx=0;
		int eInx=0;	
		HashMap hm_sub = new HashMap();

		eInx = nlens[0];
		
		for(int i=0; i<nlens.length; i++ ){
			
			try {
				hm_sub.put(strHeaders[i].toString(), new String(rcvBuf.substring(bInx, eInx).getBytes("ISO8859_1"),"EUC-KR"));
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			if (i<nlens.length-1){
				bInx = eInx;
				eInx = eInx+nlens[i+1];
			}
		}
		
		return hm_sub;
	}

}