package biz.cms_MTDTLDownloader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;


/** 
 * BTDTLDownloaderPollingAction
 * 바통(다날) 일별승인내역 수신
 * @created  on 1.0,  11/03/17
 * @created  by khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by 
 */ 
public class MTDTLDownloaderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(MTDTLDownloaderPollingAction.class);
	
	private String mt_ftp_ip = "";
	private int mt_ftp_port = 0;
	private String mt_ftp_id = "";
	private String mt_ftp_pwd = "";
	
	public static void main(String args[]) throws Exception {
		MTDTLDownloaderPollingAction action = new MTDTLDownloaderPollingAction();
		if( args == null || args.length < 1 ) {
			logger.info("------ master main args null");
		}
		System.out.println("[DEBUG] [args[0]]=" + args[0] );
		
		String path          = nvl(args[0].replaceFirst("-path:"  ,""));
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		
		action.execute("1");
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(String actionMode) {
		FTPClient client = null;
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		
		try {
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode != "1" ) return;
			
			this.mt_ftp_ip = PropertyUtil.findProperty("communication-property", "MT_FTP_SERVER_IP");
			this.mt_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "MT_FTP_SERVER_PORT"));
			this.mt_ftp_id = PropertyUtil.findProperty("communication-property", "MT_FTP_SERVER_ID");
			this.mt_ftp_pwd = PropertyUtil.findProperty("communication-property", "MT_FTP_SERVER_PWD");
			
			client = new FTPClient();
			client.setControlEncoding("euc-kr");
			client.connect(this.mt_ftp_ip, this.mt_ftp_port);
			
			int resultCode = client.getReplyCode();
			if( !FTPReply.isPositiveCompletion(resultCode) ) {
				logger.info("[ERROR1] Can't connect on FTP server");
				throw new Exception();
			}else {
				client.setSoTimeout(5000);
				boolean isLogin = client.login(this.mt_ftp_id, this.mt_ftp_pwd);
				if( !isLogin ) {
					logger.info("[ERROR2] Can't login on FTP server");
					throw new Exception();
				}
				
				client.setFileType(FTP.BINARY_FILE_TYPE);
				client.enterLocalPassiveMode();
				
				basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
				destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "mtic";
				
				File destDir = new File(destPath);
				
				if( !destDir.exists() ) {
					destDir.mkdir();
				}
				
				boolean isDownOK = false;
				String[] files = client.listNames();
				if( files != null && files.length > 0 ) {
					for(String aFile: files) {
						if( aFile.length() != 19 || (aFile.substring(16)).toLowerCase().equals("ok") ) {
							continue;
						}
						logger.info("[DEBUG] File list : " + aFile);
						int iRetry = 0;
						bos = new BufferedOutputStream(new FileOutputStream(destPath + File.separator + aFile));
						while( iRetry < 2 ) {
							if( isDownOK = client.retrieveFile(aFile, bos) ) {
								break;
							}
							iRetry++;
						}
						bos.flush();
						bos.close();
						bos = null;
						System.gc();
						
						if( isDownOK ) {
							logger.info("[DEBUG] successfuly downloaded file [" + aFile + "]");
							// 다운 받은 파일은 rename을 통해 다운로드한 파일인지 구분한다.
							client.rename(aFile, aFile.replace(aFile.substring(16), "ok"));
						}else {
							logger.info("[ERROR3] Can't get file on FTP server");
						}
					}
				}
				
				// 파일 읽어서 DB Insert
				MTDTLDownloaderInst dailyInsert = new MTDTLDownloaderInst(destPath);
				dailyInsert.start();				
				
				client.logout();
			}
		}catch(Exception e) {
			logger.info("", e);
		}finally {
			if( bos != null ) {
				try {
					bos.close();
				}catch(Exception e) {}
			}
			if( client != null && client.isConnected() ) {
				try {
					client.disconnect();
				}catch(Exception e) {}
			}
		}
	}
}
