package biz.cms_CompanyWelfareIrt;

import java.util.HashMap;
import java.util.regex.Pattern;

import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;


import biz.cms_CashBackIrt.CashBackData;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class CompanyWelfareIrtProtocol {
	private static Logger logger = Logger.getLogger(CompanyWelfareIrtAction.class);
	String ret = "";
	
	public String getCompanyWelfareIrtInq(String rcvBuf){
		HashMap hm = new HashMap();
		String ret = null;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};
		
		String strHeaders[] = {
			"INQ_TYPE"	// INQ Type(INQ 종별)
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return (String)hm.get("INQ_TYPE");
	}

	public HashMap<String, String> getCompanyWelfareReqsvr(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 8, 5, 4, 128, 10, 1, 23, 16, 8, 6};
		String strHeaders[] = {
			"INQ_TYPE",       // INQ종별
			"TRAN_DT",        // 거래일시
			"STORE_CD",       // 점포코드
			"POS_NO",         // POS번호
			"EMPLOYEE_ID",    // 사번
			"COMP_CD",        // 소속사코드
			"REQ_TYPE",       // 요청구분
			"CTL_TRAN_NO",    // 내부 거래번호
			"PAY_AMT",        // 결제요청금액
			"REG_YMD",        // 등록일자
			"REG_HMS"         // 등록시간
		};
		
		//logger.info( "▶ getParseCashBeeRTPaymentRcvRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public String makeSendDataStrStockNow(HashMap<String, String> hm, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 60, 5, 16};
		String strHeaders[] = {
				"INQ_TYPE",
				"RESP_CODE",
				"RESP_MSG",
				"USE_CNT",
				"USE_AMT"
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
}