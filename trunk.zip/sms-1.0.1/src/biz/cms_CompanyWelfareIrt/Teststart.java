package biz.cms_CompanyWelfareIrt;

import java.net.Socket;
import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

class Teststart {
	
	/**
	 * Receive data from SC through 9001 PORT(SC로부터 데이타를 9001 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	private static Logger logger = Logger.getLogger(CompanyWelfareIrtAction.class);		
	static COMMLog cLog = new COMMLog();
	
	public static void main(String[] a)  throws Exception {
		String path          = "D:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
		System.out.println("1");
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);

		String server_ip = "";
		int server_port = 0;
		int ret = 0;
		int inq_type = 0;
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		String sendMsg = "";
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		CompanyWelfareIrtProtocol CompanyWelfareIrtProtocol = new CompanyWelfareIrtProtocol();
		CompanyWelfareIrtDAO dao = new CompanyWelfareIrtDAO();
		
		try{
			
			cLog.setStartTime();
			cLog.setbizLogger(logger);
			System.out.println("@@@@");
			
			System.out.println("MSG_LEN [" + hmCommon.get("MSG_LEN") + "]");
			
			rcvDataBuf = "A720161206009990005WwZat6KKnbeWdztBf/5oaA==                                                                                                        IC0       020161206009990005470723000000000000430020161206163219"; 
			System.out.println("rcvDataBuf [" + rcvDataBuf + "]");
			
			System.out.println("CompanyWelfareIrtProtocol.getCompanyWelfareIrtInq(rcvDataBuf [" + CompanyWelfareIrtProtocol.getCompanyWelfareIrtInq(rcvDataBuf) + "]");
			
			inq_type = COMMBiz.getInqTypeCHG(CompanyWelfareIrtProtocol.getCompanyWelfareIrtInq(rcvDataBuf));
			System.out.println("inq_type [" + inq_type + "]");
			
			switch(inq_type) {//승인요청
			case 2069: //승인(A6)
				//df.execute("INQ_COMPANYWELFAREIRT_APPR_INFO");
				System.out.println("INQ_COMPANYWELFAREIRT_APPR");
				hmData = CompanyWelfareIrtProtocol.getCompanyWelfareReqsvr(rcvDataBuf);
				System.out.println("hmData [" + hmData + "]");
				dataMsg = dao.getCompanyWelfareApprInfo(hmCommon, hmData, cLog);
				System.out.println("dataMsg [" + dataMsg + "]");
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				System.out.println("ret [" + ret + "]");
				dataMsg = dataMsg.substring(2);
				System.out.println("dataMsg [" + dataMsg + "]");
				break;
			case 2070: //승인(A7)
				//df.execute("INQ_COMPANYWELFAREIRT_APPR_REQ");
				System.out.println("INQ_COMPANYWELFAREIRT_APPR");
				hmData = CompanyWelfareIrtProtocol.getCompanyWelfareReqsvr(rcvDataBuf);
				System.out.println("hmData [" + hmData + "]");
				dataMsg = dao.getCompanyWelfareApprReq(hmCommon, hmData, cLog);
				System.out.println("dataMsg [" + dataMsg + "]");
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				System.out.println("ret [" + ret + "]");
				dataMsg = dataMsg.substring(2);
				System.out.println("dataMsg [" + dataMsg + "]");
				break;
			case 2071: //취소(A8)
				//df.execute("INQ_COMPANYWELFAREIRT_REQR");
				System.out.println("INQ_COMPANYWELFAREIRT_REQR");
				hmData = CompanyWelfareIrtProtocol.getCompanyWelfareReqsvr(rcvDataBuf);
				System.out.println("hmData [" + hmData + "]");
				dataMsg = dao.getCompanyWelfareRetr(hmCommon, hmData, cLog);
				System.out.println("dataMsg [" + dataMsg + "]");
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				System.out.println("ret [" + ret + "]");
				dataMsg = dataMsg.substring(2);
				System.out.println("dataMsg [" + dataMsg + "]");
				break;
				}
			}catch(Exception e) {
				ret = 29;
				retValue = "[ERROR]2:" + e.getMessage();
				cLog.CommLogger("▶ " + retValue);
			}finally {  }

			try{// Make Response Message Data(응답 전문데이타 만들기)
				sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
				String totalMsg = sendMsg + dataMsg;
				System.out.println("[sms>pos] SEND[" + totalMsg.getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + totalMsg + "]");
				// Send Response Data(응답 데이타 전송)
				System.out.println("[sms>pos] SEND[" + totalMsg.getBytes().length + "] ");
			}catch(Exception e) {
				retValue = "[ERROR] " + e.getMessage();
				System.out.println("▶ " + retValue);
			}
		}
}