package biz.cms_CashBackDTLDownloader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;


public class CashBackDownloaderInst extends Thread {
	private static Logger logger = Logger.getLogger(CashBackDTLDownloaderPollingAction.class);
	
	String path = "";

	public CashBackDownloaderInst(String path) {
		this.path = path;
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
	
	public void deleteFile(String path, String fileNM) {
		File file = new File(path + File.separator + fileNM);
		if( file.exists() ) {
			logger.info("File Name : " + path + File.separator + fileNM);
			if( file.delete() ) {
				logger.info("File(" + path + File.separator + fileNM + ") removed !!!");
			}
		}
	}
	
	public void copyFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdirs();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(orgFile);
			fos = new FileOutputStream(destFile);
			
			int data = 0;
			while( (data = fis.read()) != -1 ) {
				fos.write(data);
			}
		}catch(Exception e) {
			logger.info(e.getMessage());
		}finally {
			try {
				fis.close();
				fis = null;
				fos.flush();
				fos.close();
				fos = null;
				System.gc();
			}catch(Exception e) {
				logger.info(e.getMessage());
			}
		}
		
	}
	
	private void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//				logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public void run() {

		int ret = 0;
		BufferedReader bin = null;
		StringTokenizer st = null;
		String readedLine = "";
		
		try {			
			CashBackDownloaderDAO dao = new CashBackDownloaderDAO();
			
			logger.info(">>>>>>> path = " + path);
			List<File> list = getDirFileList(path);
			
			for(int i = 0;i < list.size();i++ ) {
				if( !(list.get(i)).isFile() ) {
					continue;
				}
				String targetFile = list.get(i).getName();
				bin = new BufferedReader(new FileReader(path + File.separator + targetFile));
								
				while( (readedLine = bin.readLine()) != null ) {
					logger.info("[DEBUG] File Name : " + targetFile + ", readedLine = " + readedLine);
					// '\t'와'\n' 구분자로 토큰 분리
					st = new StringTokenizer(readedLine, "\t\n");
					
					int col = 0;
					Map<String, String> map = new HashMap<String, String>();

					String strHeaders[] = {
				         "TRAN_YMD",                //거래날짜
				         "STORE_CODE",              //점포코드
				         "POS_NO",                  //포스번호
				         "TRAN_NO",                 //거래번호
				         "TRAN_SEQ",                //거래순번
				         "MID",                     //가맹점ID
				         "TRAN_DIV",                //거래구분'0'캐시백출금
				         "MCH_SEND_UNIQ_NO",        //가맹점 주문번호
				         "TERMINAL_ID",             //터미널아이디
				         "TRANS_ID",                //청호PG거래번호
				         "TRAN_AMT",                //거래금액
				         "ADMIT_NO",                //승인번호
				         "BANK_CD",                 //거래은행코드
				         "TRAN_TYPE",               //'0' 승인 '1' 취소
				         "ADMIT_DATE",              //승인일자
				         "CANCLE_DATE",             //취소일자
				         "FEE",                     //수수료
				         "INQ_UNIQ_NO",             //단말전문 일련번호
				         "CONFIRM_YN"               //확정유무 Y 확정, N미확정	
					};
					// 각 분리된 토큰을 저장
					while( st.hasMoreTokens() ) {			
					//while( st.hasMoreElements() ) {
						
						map.put(strHeaders[col++], st.nextToken());
						//map.put(strHeaders[col], st.nextToken());
						
						logger.info("☆  value[" + Integer.toString(col-1) + "] = " + map.get(strHeaders[col-1]));
						System.out.println("☆  value[" + Integer.toString(col-1) + "] = " + map.get(strHeaders[col-1]));
					}
					
						ret = dao.insCashBackDailyDTL(map);
						
					if( ret != 1 ) {
//						logger.info("["+targetFile.substring(18, 19)+"]"+"There is an Error on inserting data");
//						System.out.println("["+targetFile.substring(18, 19)+"]"+"There is an Error on inserting data");
						logger.info("["+targetFile.trim()+"]"+"There is an Error on inserting data");
						System.out.println("["+targetFile.trim()+"]"+"There is an Error on inserting data");
					}					
				}
				
				bin.close();
				bin = null;

				this.moveFile(path, targetFile, path + File.separator + "backup");
				
				File fileOK = new File(path + File.separator + "backup" + File.separator + targetFile);
			    File file = new File(path + File.separator + "backup" + File.separator
			      + targetFile.substring(0, targetFile.length()-3));
			    
			    logger.info("[debug]" + path + File.separator + "backup" + File.separator + targetFile);
			    
			    fileOK.renameTo(file);//moveFile후 파일명 끝에 .ok 삭제
			    
				logger.info("Data insert OK.  FTP work well done");	
			}		
			
		}catch(Exception e) {
			logger.info("[ERROR1] " + e.getMessage());
			System.out.println("[ERROR1] " + e.getMessage());
		}finally {
			try {
				if( bin != null ) bin.close();
			}catch(Exception e) {
				//logger.info("exception occur"+ e.getMessage());
				System.out.println("exception occur"+ e.getMessage());
			}
		}
	}
}
