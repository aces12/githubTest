package biz.cms_TranDivide;

public class TranDivide_Define {
	
	static Object[][] get(String defName) {
		if("TRANDIVIDE_0000".equals(defName)) {
			return TRANDIVIDE_0000;
			
		} else if("TRANDIVIDE_0001".equals(defName)) {
			return TRANDIVIDE_0001;
			
		} else if("TRANDIVIDE_0001_NEW".equals(defName)) {
			return TRANDIVIDE_0001_NEW;
			
		} else if("TRANDIVIDE_0001_RENEW".equals(defName)) {
			return TRANDIVIDE_0001_RENEW; //상시할인/PLCC쿠폰할인 추가
			
		} else if("TRANDIVIDE_0018".equals(defName)) { 
			return TRANDIVIDE_0018;	
			
		} else if("TRANDIVIDE_0019".equals(defName)) { //STAFFDC
			return TRANDIVIDE_0019;	
			
		} else if("TRANDIVIDE_0020".equals(defName)) {
			return TRANDIVIDE_0020;
			
		} else if("TRANDIVIDE_0021".equals(defName)) {
			return TRANDIVIDE_0021;
			
		} else if("TRANDIVIDE_0021_OLD".equals(defName)) {
			return TRANDIVIDE_0021_OLD;

		} else if("TRANDIVIDE_0021_NEW".equals(defName)) {
			return TRANDIVIDE_0021_NEW;			
			
		} else if("TRANDIVIDE_0022".equals(defName)) {
			return TRANDIVIDE_0022;
			
		} else if("TRANDIVIDE_0023".equals(defName)) {
			return TRANDIVIDE_0023;
			
		} else if("TRANDIVIDE_0024".equals(defName)) {
			return TRANDIVIDE_0024;
			
		} else if("TRANDIVIDE_0025".equals(defName)) {
			return TRANDIVIDE_0025;
			
		} else if("TRANDIVIDE_0026".equals(defName)) {
			return TRANDIVIDE_0026;
			
		} else if("TRANDIVIDE_0027".equals(defName)) {
			return TRANDIVIDE_0027;
			
		} else if("TRANDIVIDE_0028".equals(defName)) {
			return TRANDIVIDE_0028;
			
		} else if("TRANDIVIDE_0029".equals(defName)) {
			return TRANDIVIDE_0029;
			
		} else if("TRANDIVIDE_0030".equals(defName)) {
			return TRANDIVIDE_0030;
			
		} else if("TRANDIVIDE_0031".equals(defName)) {
			return TRANDIVIDE_0031;
			
		} else if("TRANDIVIDE_0032".equals(defName)) {
			return TRANDIVIDE_0032;
			
		} else if("TRANDIVIDE_0033".equals(defName)) {
			return TRANDIVIDE_0033;
			
		} else if("TRANDIVIDE_0034".equals(defName)) {
			return TRANDIVIDE_0034;
			
		} else if("TRANDIVIDE_0035".equals(defName)) {
			return TRANDIVIDE_0035;
			
		} else if("TRANDIVIDE_0036".equals(defName)) {
			return TRANDIVIDE_0036;
			
		} else if("TRANDIVIDE_0037".equals(defName)) {
			return TRANDIVIDE_0037;
			
		} else if("TRANDIVIDE_0038".equals(defName)) {
			return TRANDIVIDE_0038;
			
		} else if("TRANDIVIDE_0039".equals(defName)) {
			return TRANDIVIDE_0039;
			
		} else if("TRANDIVIDE_0040".equals(defName)) {
			return TRANDIVIDE_0040;
			
		} else if("TRANDIVIDE_0041".equals(defName)) {
			return TRANDIVIDE_0041;
			
		} else if("TRANDIVIDE_0042".equals(defName)) { 
			return TRANDIVIDE_0042;		
		 
		} else if("TRANDIVIDE_0043".equals(defName)) {

			return TRANDIVIDE_0043;		//계좌결제
			
		} else if("TRANDIVIDE_0044".equals(defName)) { 
			return TRANDIVIDE_0044;		//스마트콘 헤더 
		
		} else if("TRANDIVIDE_0045".equals(defName)) { 
			return TRANDIVIDE_0045;		//스마트콘 디테일
			
		} else if("TRANDIVIDE_0045_noEvt".equals(defName)) { 
			return TRANDIVIDE_0045_noEvt;		//스마트콘 디테일(evt필드X)
			
		} else if("TRANDIVIDE_0046".equals(defName)) { 
			return TRANDIVIDE_0046;		
		
		} else if("TRANDIVIDE_0046_NEW".equals(defName)) { 
			return TRANDIVIDE_0046_NEW;		
		
		} else if("TRANDIVIDE_0046_COMM".equals(defName)) { 
			return TRANDIVIDE_0046_COMM;	//캐시백 공동망 	
		
		} else if("TRANDIVIDE_0047".equals(defName)) { 
			return TRANDIVIDE_0047;		//캐시백 사후출금
			
		} else if("TRANDIVIDE_0017".equals(defName)) {
			return TRANDIVIDE_0017;		//캐시백 공동망 
			
		}  else if("TRANDIVIDE_0048".equals(defName)) { 
			return TRANDIVIDE_0048;		//아동급식카드 참사랑
			
		} else if("TRANDIVIDE_0049".equals(defName)) { 
			return TRANDIVIDE_0049;		//관계사 식대
			
		} else if("TRANDIVIDE_0050".equals(defName)) {
			return TRANDIVIDE_0050;
			
		} else if("TRANDIVIDE_0051".equals(defName)) {
			return TRANDIVIDE_0051;
			
		} else if("TRANDIVIDE_0052".equals(defName)) {
			return TRANDIVIDE_0052;
			
		} else if("TRANDIVIDE_0052_NEW".equals(defName)) {
			return TRANDIVIDE_0052_NEW;
			
		} else if("TRANDIVIDE_0053".equals(defName)) {
			return TRANDIVIDE_0053;
			
		} else if("TRANDIVIDE_0053_NEW".equals(defName)) {
			return TRANDIVIDE_0053_NEW;
			
		} else if("TRANDIVIDE_0054".equals(defName)) {
			return TRANDIVIDE_0054;
			
		} else if("TRANDIVIDE_0055".equals(defName)) {
			return TRANDIVIDE_0055;
			
		} else if("TRANDIVIDE_0056".equals(defName)) {
			return TRANDIVIDE_0056;
			
		} else if("TRANDIVIDE_0057".equals(defName)) {
			return TRANDIVIDE_0057;
			
		} else if("TRANDIVIDE_0015".equals(defName)) { //20170829 한진택배서비스추가 KSN
			return TRANDIVIDE_0015;
			
		} else if("TRANDIVIDE_0058_RENEW".equals(defName)) {
			return TRANDIVIDE_0058_RENEW;
			
		} else if("TRANDIVIDE_0058".equals(defName)) {
			return TRANDIVIDE_0058;
			
		} else if("TRANDIVIDE_0058_OLD".equals(defName)) {
			return TRANDIVIDE_0058_OLD;
			
		} else if("TRANDIVIDE_0059".equals(defName)) {
			return TRANDIVIDE_0059;
			
		} else if("TRANDIVIDE_0064".equals(defName)) { //20170828 알리페이결제수단추가_LYH
			return TRANDIVIDE_0064;
		
		} else if("TRANDIVIDE_0065".equals(defName)) {
			return TRANDIVIDE_0065;
		
		} else if("TRANDIVIDE_0067".equals(defName)) {
			return TRANDIVIDE_0067;		//DGB-UPAY 충전
			
		} else if("TRANDIVIDE_0068".equals(defName)) {
			return TRANDIVIDE_0068;		//DGB-UPAY 지불
			
		} else if("TRANDIVIDE_0069".equals(defName)) {
			return TRANDIVIDE_0069;		//SSGPAY 상시할인
		
		} else if("TRANDIVIDE_0071".equals(defName)) {
			return TRANDIVIDE_0071;		//SPC 캐시비
		
		} else if("TRANDIVIDE_0081".equals(defName)) { //20171207 KSN SSG CON 결제수단추가
			return TRANDIVIDE_0081;		//SSG CON
			
		} else if("TRANDIVIDE_0081_PRD".equals(defName)) { //20180110 KSN SSG CON 결제수단추가
			return TRANDIVIDE_0081_PRD;		//SSG CON (PRD)
			
		} else if("TRANDIVIDE_0082".equals(defName)) { //20180206 KSN ECON 쿠폰발행마스터트란
			return TRANDIVIDE_0082;		//ECON 쿠폰발행마스터트란
			
		} else if("TRANDIVIDE_0083".equals(defName)) { //20180206 KSN ECON 쿠폰 매출분해
			return TRANDIVIDE_0083;		//ECON 쿠폰 매출분해
			
		} else if("TRANDIVIDE_0084".equals(defName)) { //20180213 무인택배(SCO), 한진 송수하인 정보
			return TRANDIVIDE_0084;
		} else if("TRANDIVIDE_0087".equals(defName)) { //20180702 모바일 문화 상품권
			return TRANDIVIDE_0087;
			
		} else if("TRANDIVIDE_0088".equals(defName)) { //카카오페이
			return TRANDIVIDE_0088;
			
		} else if("TRANDIVIDE_0088_OLD".equals(defName)) {//카카오페이
			return TRANDIVIDE_0088_OLD;

		} else if("TRANDIVIDE_0088_NEW".equals(defName)) {//카카오페이
			return TRANDIVIDE_0088_NEW;			
			
		} else if("TRANDIVIDE_0092".equals(defName)) {
			return TRANDIVIDE_0092;
			
		} else if("TRANDIVIDE_0093".equals(defName)) {	// onebarcode
			return TRANDIVIDE_0093;
			
		} else if("TRANDIVIDE_6060".equals(defName)) {
			return TRANDIVIDE_6060;
			
		} else if("TRANDIVIDE_7070".equals(defName)) {
			return TRANDIVIDE_7070;
			
		} else if("TRANDIVIDE_7074".equals(defName)) {
			return TRANDIVIDE_7074;
			
		} else if("TRANDIVIDE_7075".equals(defName)) {
			return TRANDIVIDE_7075;
			
		} else if("TRANDIVIDE_7076".equals(defName)) {
			return TRANDIVIDE_7076;
			
		} else if("TRANDIVIDE_7077".equals(defName)) {
			return TRANDIVIDE_7077;
			
		} else if("TRANDIVIDE_8080".equals(defName)) {
			return TRANDIVIDE_8080;
			
		} else if("TRANDIVIDE_9091".equals(defName)) {
			return TRANDIVIDE_9091;
			
		} else if("TRANDIVIDE_9099".equals(defName)) {
			return TRANDIVIDE_9099;
			
		} else if("TRANDIVIDE_2000".equals(defName)) {
			return TRANDIVIDE_2000;
			
		} else if("TRANDIVIDE_2001".equals(defName)) {
			return TRANDIVIDE_2001;
			
		} else if("TRANDIVIDE_4001".equals(defName)) {
			return TRANDIVIDE_4001;
			
		} else {
			return null;
		}
	}
	
	static final Object[][] TRANDIVIDE_0000 = {
			{"ITEM_LEN",	5}, 
			{"TR_ITEM_ID",	2},
			{"TR_ITEM_SEQ",	3}, // 명세 순번
			
			{"TRAN_TYPE",	1},
			{"PMOD_YN",		1},
			{"STOP_YN",		1},
			{"TRAN_KIND",	2},
			{"TRAN_YMD",	8},
			{"STORE_CD",	5},
			{"POS_NO",		4},
			{"TRAN_NO",		4},
			{"SYS_YMDHMS",	14},
			{"OP_NO",		13},
			{"ORG_TRAN_YMD",8},
			{"ORG_POS_NO",	4},
			{"ORG_TRAN_NO",	4},
			{"ORG_STORE_CD",5},
			{"ORG_RES_ID",	2},
			{"APP_OP_NO",	13},
			{"CUST_CLS_ID",	2},
			{"CUST_COUNT",	3},
			{"ORDER_TYPE",	1},
			{"FLOOR_CD",	4},
			{"TABLE_NO",	4},
			{"GSALE_AMT",	16},
			{"GDC_AMT",		16},
			{"NSALE_AMT",	16},
			{"SCHARGE_AMT",	16},
			{"COM_CD",		4},
			{"DRAWER_CD",	4},
	};
	
	static final Object[][] TRANDIVIDE_0001 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"ASGN_CANCEL_YN",	1},
		{"PLU_CD",			30},
		{"PLU_FLAG",		1},
		{"CATE_ID",			10},
		{"GRP_ID",			10},
		{"SGRP_ID",			10},
		{"BRAND_ID",		10},
		{"ITEM_ID",			2},
		{"SALE_QTY",		4},
		{"SALE_UPRC",		16},
		{"SALE_AMT",		16},
		{"PRICE_CHG_ID",	1},
		{"PRICE_CHG_UPRC",	16},
		{"ITEM_INPUT_ID",	1},
		{"SCAN_CD",			30},
		{"BTL_SUM_AMT",		16},
		{"BTL_PLU_CD",		30},
		{"ITEM_NM",			40},
		{"ITEM_TAX_ID",		1},
		{"ITEM_TAX_VALUE",	16},
		{"RECT_AMT",		16},
		{"POS_DC_ID",		1},
		{"POS_DC_RATE",		5},
		{"POS_DC_AMT",		16},
		{"EVT_DC_QTY",		4},
		{"EVT_DC_AMT",		16},
		{"CO_DC_ID",		1},
		{"CO_DC_QTY",		4},
		{"CO_DC_AMT",		16},
		{"SALE_UNIT_QTY",	3},
		{"SCRAP_RES_ID",	2},
		{"SERVICE_FLAG",	1},
		{"PACK_FLAG",		1},
		{"DISUSE_FLAG",		1},
		{"REASON_ID",		10},
		{"DBUYING_FLAG",	1},
		{"SERVICE_ITEM_TY",	2},
		{"ITEM_CD",			30},
		{"SALES_TYPE",		1},
		{"FILLER1",			1}, // 현금 영수증 제외
		
		{"EVT_CARD_TY",		1},
		{"EVT_CARD_QTY",	4},
		{"EVT_CARD_AMT",	16},
	};
	
	static final Object[][] TRANDIVIDE_0001_NEW = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"ASGN_CANCEL_YN",	1},
		{"PLU_CD",			30},//5
		{"PLU_FLAG",		1},
		{"CATE_ID",			10},
		{"GRP_ID",			10},
		{"SGRP_ID",			10},
		{"BRAND_ID",		10},//10
		{"ITEM_ID",			2},
		{"SALE_QTY",		4},
		{"SALE_UPRC",		16},
		{"SALE_AMT",		16},
		{"PRICE_CHG_ID",	1},//15
		{"PRICE_CHG_UPRC",	16},
		{"ITEM_INPUT_ID",	1},
		{"SCAN_CD",			30},
		{"BTL_SUM_AMT",		16},
		{"BTL_PLU_CD",		30},//20
		{"ITEM_NM",			40},
		{"ITEM_TAX_ID",		1},
		{"ITEM_TAX_VALUE",	16},
		{"RECT_AMT",		16},
		{"POS_DC_ID",		1},//25
		{"POS_DC_RATE",		5},
		{"POS_DC_AMT",		16},
		{"EVT_DC_QTY",		4},
		{"EVT_DC_AMT",		16},
		{"CO_DC_ID",		1},//30
		{"CO_DC_QTY",		4},
		{"CO_DC_AMT",		16},
		{"SALE_UNIT_QTY",	3},
		{"SCRAP_RES_ID",	2},
		{"SERVICE_FLAG",	1},//35
		{"PACK_FLAG",		1},
		{"DISUSE_FLAG",		1},
		{"REASON_ID",		10},
		{"DBUYING_FLAG",	1},
		{"SERVICE_ITEM_TY",	2}, //40 확인필요
		{"ITEM_CD",			30},
		{"SALES_TYPE",		1},
		{"FILLER1",			1}, // 현금 영수증 제외
		
		{"EVT_CARD_TY",		1},
		{"EVT_CARD_QTY",	4},//45
		{"EVT_CARD_AMT",	16},
		
		{"STAFF_DC_ID",		1},	//임직원 할인 구분
		{"STAFF_DC_QTY",	4},	//임직원 할인 수량
		{"STAFF_DC_AMT",	16}	//임직원 할인 금액
	};
	
	static final Object[][] TRANDIVIDE_0001_RENEW = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"ASGN_CANCEL_YN",	1},
		{"PLU_CD",			30},//5
		{"PLU_FLAG",		1},
		{"CATE_ID",			10},
		{"GRP_ID",			10},
		{"SGRP_ID",			10},
		{"BRAND_ID",		10},//10
		{"ITEM_ID",			2},
		{"SALE_QTY",		4},
		{"SALE_UPRC",		16},
		{"SALE_AMT",		16},
		{"PRICE_CHG_ID",	1},//15
		{"PRICE_CHG_UPRC",	16},
		{"ITEM_INPUT_ID",	1},
		{"SCAN_CD",			30},
		{"BTL_SUM_AMT",		16},
		{"BTL_PLU_CD",		30},//20
		{"ITEM_NM",			40},
		{"ITEM_TAX_ID",		1},
		{"ITEM_TAX_VALUE",	16},
		{"RECT_AMT",		16},
		{"POS_DC_ID",		1},//25
		{"POS_DC_RATE",		5},
		{"POS_DC_AMT",		16},
		{"EVT_DC_QTY",		4},
		{"EVT_DC_AMT",		16},
		{"CO_DC_ID",		1},//30
		{"CO_DC_QTY",		4},
		{"CO_DC_AMT",		16},
		{"SALE_UNIT_QTY",	3},
		{"SCRAP_RES_ID",	2},
		{"SERVICE_FLAG",	1},//35
		{"PACK_FLAG",		1},
		{"DISUSE_FLAG",		1},
		{"REASON_ID",		10},
		{"DBUYING_FLAG",	1},
		{"SERVICE_ITEM_TY",	2}, //40 확인필요
		{"ITEM_CD",			30},
		{"SALES_TYPE",		1},
		{"FILLER1",			1}, // 현금 영수증 제외
		
		{"EVT_CARD_TY",		1},
		{"EVT_CARD_QTY",	4},//45
		{"EVT_CARD_AMT",	16},
		
		{"STAFF_DC_ID",		1},	//임직원 할인 구분
		{"STAFF_DC_QTY",	4},	//임직원 할인 수량
		{"STAFF_DC_AMT",	16},//임직원 할인 금액
		
		{"APP_PAY_DC_ID",	1},	//간편결제 할인 구분
		{"APP_PAY_DC_QTY",	4},	//간편결제 할인 수량
		{"APP_PAY_DC_AMT",	16}	//간편결제 할인 금액
		
	};
	
	static final Object[][] TRANDIVIDE_0018 = { // 2017.03.17 OHT
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TRAN_YMD",		8}, 
		{"STORE_CD",		5}, 
		{"POS_NO",			4}, 
		{"TRAN_NO",			4}, 
		{"SEND_UNIQ_NO",	20}, 
		
		{"TRAN_TYPE",		2}, 
		{"GIFT_CARD_NO",	100}, 
		{"SPECIAL_GUBUN",	1}, 
		{"USE_GUBUN",		1}, 
		{"GOODS_GUBUN",		1}, 

		{"PART_GUBUN",		2}, 
		{"REQ_AMT",			16}, 
		{"PAY_AMT",			16}, 
		{"REMAIN_AMT",		16}, 
		{"AUTH_DATE",		8}, 
		
		{"AUTH_TIME",		6}, 
		{"AUTH_NO",			8}, 
		{"ORG_SALE_DATE",	8}, 
		{"ORG_ST_CODE",		10}, 
		{"ORG_TM_NO",		4}, 

		{"ORG_TRAN_NO",		4}, 
		{"ORG_SEND_UNIQ_NO",20}, 
		{"ORG_AUTH_DATE",	8}, 
		{"ORG_AUTH_NO",		8}, 
		{"IRT_NOMAL_TP",	1}, 
	};
	
	static final Object[][] TRANDIVIDE_0019 = { //20170208 STAFFDC
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"COMP_CD",			10}, 
		{"EMPLOYEE_NO",		128}, 
		{"PAY_AMT",			16}, 
		{"USE_AMT",			16}, 
		{"APPR_TYPE",		1},
		{"REQ_TRANNO",		23}, 
		{"APPLY_GUBUN",		1}, 
		{"ORG_POS_NO",		4},
		{"ORG_TRAN_DATE",	8}, 
		{"ORG_TRAN_NO",		4}, 
		{"REG_DATETIME",	14},
		{"IRT_NORMAL_TP",	1}
	};
	
	static final Object[][] TRANDIVIDE_0020 = {
		{"ITEM_LEN",	5}, 
		{"TR_ITEM_ID",	2},
		{"TR_ITEM_SEQ",	3}, // 명세 순번
		
		{"RECV_AMT",	16},
		{"PAY_AMT",		16},
		{"CHG_AMT",		16},
	};

	static final Object[][] TRANDIVIDE_0021_NEW = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"PAY_AMT",			16},
		{"CARD_INPUT_ID",	1},
		{"CARD_DATA",		128},
		{"INSTMNT_PRD",		2},
		{"AGREE_ID",		2},
		{"AGREE_NO",		12},
		{"AGREE_YMDHMS",	14},
		{"CARD_CORP_CD",	4},
		{"CARD_CORP_NM",	40},
		{"FRIEND_NO",		15},
		{"ORG_YMD",			14},
		{"ORG_AGREE_NO",	12},
		{"SERVICE_AMT",		16},
		{"CARD_DATA_VISIBLE", 20},
		{"CARD_KIND", 1},
		{"CARD_BUY_CD", 4},
		{"VAN_TID", 15}
	};
	
	static final Object[][] TRANDIVIDE_0021 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"PAY_AMT",			16},
		{"CARD_INPUT_ID",	1},
		{"CARD_DATA",		128},
		{"INSTMNT_PRD",		2},
		{"AGREE_ID",		2},
		{"AGREE_NO",		12},
		{"AGREE_YMDHMS",	14},
		{"CARD_CORP_CD",	4},
		{"CARD_CORP_NM",	40},
		{"FRIEND_NO",		15},
		{"ORG_YMD",			8},
		{"ORG_AGREE_NO",	12},
		{"SERVICE_AMT",		16},
		{"CARD_DATA_VISIBLE", 20},
		{"CARD_KIND", 1}
	};
	
	static final Object[][] TRANDIVIDE_0021_OLD = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"PAY_AMT",			16},
		{"CARD_INPUT_ID",	1},
		{"CARD_DATA",		128},
		{"INSTMNT_PRD",		2},
		{"AGREE_ID",		2},
		{"AGREE_NO",		12},
		{"AGREE_YMDHMS",	14},
		{"CARD_CORP_CD",	4},
		{"CARD_CORP_NM",	40},
		{"FRIEND_NO",		15},
		{"ORG_YMD",			8},
		{"ORG_AGREE_NO",	12},
		{"SERVICE_AMT",		16},
		{"CARD_DATA_VISIBLE", 20}
	};
	
	static final Object[][] TRANDIVIDE_0022 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TENDER_DATA3",	2},
		{"TENDER_DATA1",	30},
		{"TENDER_DATA8",	4},
		{"TENDER_VALUE4",	16},
		{"TENDER_AMT",		16},
		{"TENDER_VALUE3",	16},
		{"TENDER_VALUE2",	16},
		{"TENDER_DATA99",	40},
	};
	
	static final Object[][] TRANDIVIDE_0023 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TENDER_DATA3",	8},
		{"TENDER_DATA1",	20},
		{"TENDER_DATA11",	21},
		{"TENDER_DATA10",	1},
		{"TENDER_AMT",		10},
		
		{"TENDER_DATA5",	128},
		{"TENDER_DATA6",	8},
		{"TENDER_DATA14",	8},
		{"TENDER_DATA12",	20},
		{"TENDER_VALUE1",	20},
		
		{"TENDER_DATA9",	1},
		{"TENDER_VALUE2",	20},
	};
	
	static final Object[][] TRANDIVIDE_0024 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TENDER_DATA3",	2},
		{"TENDER_DATA1",	30},
		{"TENDER_DATA8",	4},
		{"TENDER_VALUE4",	16},
		{"TENDER_AMT",		16},
		
		{"TENDER_VALUE1",	30},
		{"TENDER_DATA99",	40},
	};
	
	static final Object[][] TRANDIVIDE_0025 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TENDER_DATA11",	20},
		{"TENDER_DATA10",	1},
		{"TENDER_DATA6",	10},
		{"TENDER_DATA99",	40},
		{"TENDER_VALUE2",	20},
		
		{"TENDER_AMT",		20},
		{"TENDER_VALUE3",	20},
	};
	
	static final Object[][] TRANDIVIDE_0026 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TENDER_DATA11",	20},
		{"TENDER_DATA10",	1},
		{"TENDER_DATA6",	10},
		{"TENDER_DATA99",	40},
		{"TENDER_VALUE2",	20},
		
		{"TENDER_AMT",		20},
		{"TENDER_VALUE3",	20},
	};
	
	static final Object[][] TRANDIVIDE_0027 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TENDER_DATA9",	1},
		{"TENDER_DATA10",	1},
		{"TENDER_DATA5",	128},
		{"TENDER_DATA8",	1},
		{"TENDER_DATA1",	40},
		
		{"TENDER_AMT",		20},
		{"TENDER_DATA7",	2},
		{"TENDER_VALUE1",	20},
	};
	
	static final Object[][] TRANDIVIDE_0028 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TRANSACTION_ID",	20},     
		{"MEMBER_ID",		7},
		{"TERMINAL_ID", 	10},
		{"PSAM_ID", 		16},
		{"PSAM_DEAL_SNO", 	10},
		{"CARD_NO", 		20},
		{"CARD_DEAL_SNO", 	10},
		{"WORK_ID", 		3},
		{"DEAL_BEF_RAMT", 	20},
		{"DEAL_REQ_AMT", 	20},
		{"DEAL_AFT_RAMT", 	20},
		{"DEAL_YMDHMS", 	14},
		{"ALGM_ID", 		2},
		{"CDEAL_KEY_VER", 	2},
		{"ECASH_ID", 		2},
		{"PSAM_TOTAMTDEAL_CNT", 10},
		{"PSAM_CDEAL_CNT", 	5},
		{"PSAM_DEAL_SUM_AMT", 20},
		{"SIGN_VAL", 		8},
		{"CARD_TYPE", 		2},
		{"CARD_OWNER_ID", 	2},
		{"RES_CD", 			2},
	};
	
	static final Object[][] TRANDIVIDE_0029 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TENDER_DATA8", 	1},   
		{"TENDER_DATA10", 	1},   
		{"TENDER_DATA7", 	2},   
		{"TENDER_DATA5", 	128}, 
		{"TENDER_DATA1", 	15},  
		{"TENDER_VALUE2", 	20},  
		{"TENDER_AMT", 		20},  
		{"TENDER_VALUE1", 	20},  
		{"PW", 				128}, 
		{"TENDER_DATA14", 	8},   
		{"TENDER_DATA12", 	15},  
		{"TENDER_DATA9", 	1},   
		{"TENDER_DATA3", 	8},   
		{"TENDER_DATA4", 	1},   
		{"TENDER_DATA6", 	15},
	};
	
	static final Object[][] TRANDIVIDE_0030 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"SEND_UNIQ_NO",		20},      
		{"CARD_NO_ENCODED",		128},     
		{"CARD_NO_VISIBLE",		20},      
		{"CONFIRM_NO",			50},      
		{"GIFT_CODE",			4},       
		{"PAY_AMT",				12},      
		{"REMAIN_AMT",			12},      
		{"SEND_DATE",			8},       
		{"AUTH_DATE",			8},       
		{"AUTH_TIME",			6},       
		{"AUTH_NO",				8},       
		{"ORG_SEND_DATE",		8},       
		{"ORG_AUTH_DATE",		8},       
		{"ORG_AUTH_NO",			8},       
		{"ORG_SEND_UNIQ_NO",	20},      
		{"DELEGATE_BARCODE_NO",	128},     
	};
	
	static final Object[][] TRANDIVIDE_0031 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"SERVICE_ID",		1},
		{"WORK_ID",			1},
		{"BARCODE_NO",		20},
		{"BARCODE_NO_EN",	128},
		{"INPUT_TY",		1},
		{"APPROVAL_NO",		20},
		{"COLLECT_CHECK",	1},
		{"COLLECT_MOBILE",	128},
		{"USED_BRANCH_CD",	10},
		{"USED_DATE",		8},
		{"USED_TIME",		6},
		{"OLD_APPROVAL_NO",	20},
		{"OLD_APPROVAL_DT",	8},
		{"TOT_ITEM_ROWS",	2},
		{"PRODUCT_BARCODE",	20},
		{"PRODUCT_QTY",		4},
		{"PRODUCT_COST",	10},
		{"PARTNER_AMT",		10},
		{"SUPPLY_AMT",		10},
		{"COUPON_TOT_AMT",	10},  
	};
	
	static final Object[][] TRANDIVIDE_0032 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TENDER_DATA10", 	1},
		{"TENDER_DATA7", 	1},
		{"TENDER_VALUE1", 	20},
		{"TENDER_DATA5", 	128},
		{"TENDER_DATA9", 	1},
		{"TENDER_DATA1", 	25},
		{"TENDER_DATA6", 	10},
		{"TENDER_DATA11", 	8},
		{"TENDER_DATA13", 	6},
		{"TENDER_VALUE2", 	9},
		{"TENDER_AMT", 		9},
		{"TENDER_VALUE3", 	9},
		{"TENDER_DATA99", 	25},
		{"TENDER_DATA14", 	8},
		{"TENDER_DATA4", 	1},
	};
	
	static final Object[][] TRANDIVIDE_0033 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"DAT_CMD",			2},
		{"DEAL_UNIQ_NO",	18},
		{"CO_REG_NO",		10},
		{"CARD_TP",			4},
		{"DEAL_YMDHMS",		14},
		{"TERMINAL_ID",		10},
		{"PAY_BEF_RAMT",	10},
		{"PAY_REQ_AMT",		10},
		{"PAY_AFT_RAMT",	10},
		{"DEAL_AMT",		10},
		{"TYPE_EP",			2},
		{"ALG_EP",			2},
		{"VK_IND2_KEY",		2},
		{"TRT_SAM",			2},
		{"VK_IND_KEY",		2},
		{"ID_CENTER",		2},
		{"ID_EP",			16},
		{"NT_EP",			8},
		{"ID_SAM",			16},
		{"NT_SAM",			8},
		{"NC_SAM",			8},
		{"NI_SAM",			4},
		{"TOT_SAM",			8},
		{"SIGN_IND",		8},
		{"SIGN_IND2",		8},
		{"PENALTY_AMT",		10},
	};
	
	static final Object[][] TRANDIVIDE_0034 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"DAT_CMD",			2},
		{"TRAN_ID",			20},
		{"DEAL_BRANCH_CD",	10},
		{"TERMINAL_ID",		10},
		{"DEAL_YMDHMS",		14},
		{"CARD_DIS_CD",		1},
		{"CARD_OWNER_CD",	2},
		{"PUBCO_ID",		7},
		{"ORG_DEAL_AMT",	10},
		{"CARD_NO",			16},
		{"CARD_DEAL_SEQ_NO",10},
		{"DEAL_BEF_RAMT",	10},
		{"DEAL_REQ_AMT",	10},
		{"DEAL_AFT_RAMT",	10},
		{"DEAL_TP",			3},
		{"ALGO_ID",			3},
		{"KEYSET_VER",		3},
		{"ELEC_MNY_ID",		3},
		{"SAM_ID",			16},
		{"SAM_DEAL_SEQ_NO",	10},
		{"SAM_TOT_AMT_COL_NO",10},
		{"SAM_SPY_TRN_COL_CNT",5},
		{"SAM_ACC_TRN_TOT_AMT",10},
		{"SIGN_IND",		8},
		{"ALIAS_NO",		10},
		{"CARDPLSTS_YN",	1},
		{"FEE",				10},
	};
	
	static final Object[][] TRANDIVIDE_0035 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_PARCEL_CD",	20},
	};
	
	static final Object[][] TRANDIVIDE_0036 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"DAT_CMD",				2},
		{"TRAN_ID",				20},
		{"DEAL_BRANCH_CD",		10},
		{"WORK_ID",				3},
		{"TERMINAL_ID",			10},
		{"PAYMENT_TP",			2},
		{"CARD_NO",				16},
		{"CARD_OWNER_TP",		2},
		{"CHRG_DEAL_YMDHMS",	14},
		{"CHRG_BEF_RAMT",		10},
		{"CHRG_REQ_AMT",		10},
		{"CHRG_AFT_RAMT",		10},
		{"CARD_DEAL_SEQ_NO",	10},
		{"RAND_VAL",			16},
		{"SIGN_VAL_1",			8},
		{"LSAM_ID",				16},
		{"LSAM_DEAL_SEQ_NO",	10},
		{"SIGN_VAL_2",			8},
		{"CARD_STS_CD",			4},
		{"TERMINAL_STS_CD",		4},
		{"CHRG_FEE",			10},
		{"REFUND_CARD_DEPOSIT",	10},
		{"REFUND_PENALTY_AMT",	10},
	};
	
	static final Object[][] TRANDIVIDE_0037 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TENDER_DATA4",	2},
		{"TENDER_VALUE1",	40},
		{"TENDER_DATA3",	10},
		{"TENDER_AMT",		10},
	};
	
	static final Object[][] TRANDIVIDE_0038 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"DATE_DDD",		3},
		{"TIME_SSSSS",		5},
		{"FCSTR_ID",		5},
		{"BRANCH_CD",		3},
		{"AGENT_CD",		3},
		{"PUBER_CD",		5},
		{"PAY_TP",			1},
		{"CNCL_PAY_TP",		1},
		{"ITEM_GRP_CD",		1},
		{"ITEM_CD",			1},
		{"GAME_NTH",		3},
		{"PAY_AMT",			16},
		{"POS_REG_DTM",		14},
	};
	
	static final Object[][] TRANDIVIDE_0039 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_SEND_UNIQ_NO",		20},
		{"V_CARD_NO_ENCODED",	128},
		{"V_CARD_NO_VISIBLE",	20},
		{"V_CONFIRM_NO",		50},
		{"V_GIFT_CODE",			4},
		{"V_SPECIAL_GUBUN",		1},
		{"V_PAY_TYPE",			2},
		{"V_PAY_AMT",			12},
		{"V_REMAIN_AMT",		12},
		{"V_SEND_DATE",			8},
		{"V_AUTH_DATE",			8},
		{"V_AUTH_TIME",			6},
		{"V_AUTH_NO",			8},
		{"V_ORG_SEND_DATE",		8},
		{"V_ORG_AUTH_DATE",		8},
		{"V_ORG_AUTH_NO",		8},
		{"V_ORG_SEND_UNIQ_NO",	20},
		{"V_DELEGATE_BARCODE_NO",128},
	};
	
	static final Object[][] TRANDIVIDE_0040 = {
		{"ITEM_LEN",			5}, 
		{"TR_ITEM_ID",			2},
		{"TR_ITEM_SEQ",			3}, // 명세 순번
		{"V_SEND_UNIQ_NO",		20},
		{"V_CARD_NO_ENCODED",	128},	
		
		{"V_CARD_NO_VISIBLE",	20},
		{"V_ITEM_TITLE",		127},
		{"V_PAY_CURRENCY",		3},
		{"V_PAY_KRW_AMOUNT",	13},
		{"V_SEND_DATE",			8},
		
		{"V_AUTH_DATE",			8},
		{"V_AUTH_TIME",			6},
		{"V_AUTH_NO",			32},
		{"V_ORG_SEND_DATE",		8},
		{"V_ORG_AUTH_DATE",		8},
		
		{"V_ORG_AUTH_NO",		32},
		{"V_ORG_SEND_UNIQ_NO",	20},
	};

	static final Object[][] TRANDIVIDE_0041 = {
			{"ITEM_LEN",		5}, 
			{"TR_ITEM_ID",		2},
			{"TR_ITEM_SEQ",		3}, // 명세 순번
			
			{"V_SEND_UNIQ_NO",	    20},
			{"V_CARD_NO_ENCODED",  128},
			{"V_CARD_NO_VISIBLE",	32},
			{"V_MD_CODE",	        20},
			{"V_TRADE_AMT",	        12},
			{"V_POSA_GUBUN",		 1},
			{"V_AUTH_DATE",			 8},
			{"V_AUTH_TIME",		     6},
			{"V_AUTH_NO",			 8},
			{"V_REMAIN_AMT",		12},
			{"V_ORG_SEND_DATE",		 8},
			{"V_ORG_SEND_UNIQ_NO",	20},
			{"V_ORG_AUTH_DATE",		 8},
			{"V_ORG_AUTH_NO",		 8},
			{"V_EVENT_AMT",		    12},
			{"V_SALE_AMT",			12},
		};
	
	static final Object[][] TRANDIVIDE_0042 = {
		{"ITEM_LEN",	5}, 
		{"TR_ITEM_ID",	2},
		{"TR_ITEM_SEQ",	3}, // 명세 순번
		
		{"MCH_SEND_UNIQ_NO",		21},		
		{"STORE_CD", 				5},
		
		{"POS_NO", 					4},
		{"TRAN_NO", 				4},
		{"DOCUMENT_CD",				3},
		{"BUY_SERIAL_NUM",			20},
		{"BUYER_CANCLE_CHECK",		1},
		
		{"TRADE_APPROVAL_NUM",		10},
		{"SELLER_BUSI_REGIST_NUM",	10},		
		{"TERMINAL_ID",				10},		
		{"SELL_TIME",				14},
		{"SELL_SUM_TOTAL",			4},
		
		{"SELL_SUM_MONEY",			9},
		{"REFUND_AMOUNT",			8},		
		{"PAYMENT_TYPE",			1},		/*{"PASSPORT_ENC_YN",			1},	*/	
		{"PASSPORT_NAME",			40},		
		{"PASSPORT_NUM",			24},
		
		{"PASSPORT_NUM_ENCODING",	128},
		{"PASSPORT_NATION",			3},		
		{"PASSPORT_SEX",			1},		
		{"PASSPORT_BIRTH",			6},		
		{"PASSPORT_EXPIRE",			6},	
			
		/*	{"SEQUENCE_COUNT",			4},		{"RCT_NO",					30},*/
		{"BEFORE_REFUND_YN",		1},				
		{"PAYMENT_AMOUNT",			9},		
		{"EXPORT_APPROVAL_NUM",		30},		
		{"BEFORE_LIMIT_AMOUNT",		10},		
		{"PLU_CD",		30},
		
		{"PLU_NM",		50},
		{"SALE_QTY",		4},		
		{"ORG_APPROVAL_NUM",		30},
		{"ORG_SELL_TIME",			14},		
		{"ORG_SEND_UNIQ_NO",		21},
		{"VAT", 		8},
		{"EXPORT_EXPIRY_DATE", 		8},
		{"SCT", 		8},
		{"ET", 		8},
		{"TOT_PAY_AMT", 		9},
		{"EXP_AMT", 		9}
	};
	
	static final Object[][] TRANDIVIDE_0043 = {
		{"ITEM_LEN",	                5}, 
		{"TR_ITEM_ID",					2},
		{"TR_ITEM_SEQ",					3}, // 명세 순번
		  
		{"MSG_ID",						8},		
		{"TRAN_TYPE", 					2},
		  
		{"SALE_DATE", 					8},
		{"SALE_TIME", 					6},
		{"DELEGATE_BARCODE_NO",			22},
		{"DELEGATE_BARCODE_NO_ENCODED", 64},
		{"BANK_CODE",		    		3},
		  
		{"BANK_NM",		        		30},
		{"BANK_VAN_FLAG",	    		4},		
		{"PLATFORM_M_ID",				20},		
		{"BANK_ACCOUNT_NO_ENCRPT",				96},
		{"BANK_TOT_TRADE_AMT",			12},
		  
		{"BANK_DIS_TRADE_AMT",			12},
		{"BANK_NET_TRADE_AMT",			12},		
		{"BANK_AUTH_DATE",				8},		/*{"PASSPORT_ENC_YN",			1},	*/	
		{"BANK_AUTH_TIME",				6},		
		{"BANK_AUTH_NO",				15},
		  
		{"ORG_BANK_AUTH_DATE",			8},
		{"ORG_BANK_AUTH_NO",			15},		
		{"CNCL_GUBUN",					2},		
		{"CNCL_USE_YN",					1},		
		{"ORG_DELEGATE_BARCODE",		64},	
			
		{"ORG_BANK_SUTH_AMT",			12},
		{"CARD_UNIQ_NO",			20}
		
	};
	
	static final Object[][] TRANDIVIDE_0044 = { //스마트콘
			{"ITEM_LEN",				5}, 
			{"TR_ITEM_ID",				2},
			{"TR_ITEM_SEQ",				3}, // 명세 순번	
			{"COUPON_TOT_AMT",			10},
			{"COUPON_COUNT",			4}			
		};
	
	static final Object[][] TRANDIVIDE_0045 = { //스마트콘 디테일 378byte
			{"ITEM_LEN",				5}, 
			{"TR_ITEM_ID",				2},
			{"TR_ITEM_SEQ",				3}, // 명세 순번	
			{"SERVICE_ID",				1},
			{"EXCHANGE_ID",				6},
			
			{"COUPON_NUM",				16},
			{"ADMIT_NUM",				20},
			{"ADMIT_DATE",				8},
			{"ADMIT_TIME",				6},
			{"ORG_ADMIT_NUM",			20},
			
			{"MANUFACTURE_CODE",		10},
			{"LARGE_CODE",				10},
			{"MEDIUM_CODE",				10},
			{"SMALL_CODE",				10},
			{"SELL_AMT",				10},	
			
			{"PRODUCT_BARCODE",			20},
			{"PRODUCT_COST",			10},
			{"PARTNER_AMT",				10},
			{"SUPPLY_AMT",				10},
			{"EVN_PRODUCT_YN",			1},
			
			{"EVN_PRODUCT_CNT",			2},
			{"EVN_PRODUCT_AMT",			6},
			{"COUPON_USED_AMT",			10},
			{"COUPON_REMAIN_AMT",		10},
			{"MANAGE_NO",				50},
			
			{"COMMISSION_RATE",			10},
			{"COMMISSION_AMT",			10},
			{"STATUS_CODE",				1},
			{"DISCOUNT_RATE",			4},	
			{"DISCOUNT_AMT",			10},
			
			{"COUPON_TYPE",				1},
			{"EVT_FLAG",				1},
			{"EVT_CODE",				15},
			{"EVT_PRODUCT_BARCODE1",	20},	//교환권 N+1 바코드
			{"EVT_PRODUCT_BARCODE2",	20},
			
			{"EVT_PRODUCT_BARCODE3",	20}
		};
	
	static final Object[][] TRANDIVIDE_0045_noEvt = { //20161115 스마트콘 디테일 EVT필드 추가 전 302byte
		{"ITEM_LEN",				5}, 
		{"TR_ITEM_ID",				2},
		{"TR_ITEM_SEQ",				3}, // 명세 순번	
		{"SERVICE_ID",				1},
		{"EXCHANGE_ID",				6},
		
		{"COUPON_NUM",				16},
		{"ADMIT_NUM",				20},
		{"ADMIT_DATE",				8},
		{"ADMIT_TIME",				6},
		{"ORG_ADMIT_NUM",			20},
		
		{"MANUFACTURE_CODE",		10},
		{"LARGE_CODE",				10},
		{"MEDIUM_CODE",				10},
		{"SMALL_CODE",				10},
		{"SELL_AMT",				10},
		
		{"PRODUCT_BARCODE",			20},			
		{"PRODUCT_COST",			10},
		{"PARTNER_AMT",				10},
		{"SUPPLY_AMT",				10},
		{"EVN_PRODUCT_YN",			1},
		
		{"EVN_PRODUCT_CNT",			2},
		{"EVN_PRODUCT_AMT",			6},
		{"COUPON_USED_AMT",			10},
		{"COUPON_REMAIN_AMT",		10},
		{"MANAGE_NO",				50},
		
		{"COMMISSION_RATE",			10},
		{"COMMISSION_AMT",			10},
		{"STATUS_CODE",				1},
		{"DISCOUNT_RATE",			4},	
		{"DISCOUNT_AMT",			10},
		
		{"COUPON_TYPE",				1}			
	};
	
	
	
	static final Object[][] TRANDIVIDE_0046 = {	//청호 이지캐시백
			{"ITEM_LEN",	5}, 
			{"TR_ITEM_ID",	2},
			{"TR_ITEM_SEQ",	3}, // 명세 순번	 					
			{"MCH_SEND_UNIQ_NO", 21},			
			{"TRADE_DATE", 		8},
			
			{"TRADE_TIME", 		6},
			{"MID",				10},
			{"TERMINAL_ID",		14},
			{"TRADE_AMT",		8},
			{"COM_AMT",			8},
			
			{"EVT_AMT",	 		8},
			{"TOTAL_AMT",		8},
			{"BANK_CD",	 		3},
			{"TRANS_ID",		30},
			{"AUTH_DATE",		8},
			
			{"AUTH_NO",			12},
			{"BEFORE_SALE_DATA",		8},
			{"BEFORE_STORE_CD",			5},
			{"BEFORE_POS_NO",			4},
			{"BEFORE_TRAN_NO",			4},
			
			{"BEFORE_SALE_AMT",			8},
			{"ORG_MCH_SEND_UNIQ_NO",	21},
			{"ORG_AUTH_DATE",	8},
			{"ORG_AUTH_NO",		12},
			{"INQ_UNIQ_NO",		6},
			
			{"DRAW_FLAG",		1},
			{"RESP_CODE",		4},
			{"RESP_MSG",		100},
			{"AFTER_FLAG",		1}
		};
	
	
	
	static final Object[][] TRANDIVIDE_0046_NEW = {	//청호 이지캐시백  //338
			{"ITEM_LEN",	5}, 
			{"TR_ITEM_ID",	2},
			{"TR_ITEM_SEQ",	3}, // 명세 순번	 					
			{"MCH_SEND_UNIQ_NO", 21},			
			{"TRADE_DATE", 		8},
			
			{"TRADE_TIME", 		6},
			{"MID",				10},
			{"TERMINAL_ID",		14},
			{"TRADE_AMT",		8},
			{"COM_AMT",			8},
			
			{"EVT_AMT",	 		8},
			{"TOTAL_AMT",		8},
			{"BANK_CD",	 		3},
			{"TRANS_ID",		30},
			{"AUTH_DATE",		8},
			
			{"AUTH_NO",			12},
			{"BEFORE_SALE_DATA",		8},
			{"BEFORE_STORE_CD",			5},
			{"BEFORE_POS_NO",			4},
			{"BEFORE_TRAN_NO",			4},
			
			{"BEFORE_SALE_AMT",			8},
			{"ORG_MCH_SEND_UNIQ_NO",	21},
			{"ORG_AUTH_DATE",	8},
			{"ORG_AUTH_NO",		12},
			{"INQ_UNIQ_NO",		6},
			
			{"DRAW_FLAG",		1},
			{"RESP_CODE",		4},
			{"RESP_MSG",		100},
			{"AFTER_FLAG",		1}
			//캐쉬백 VAN 추가	lys
			,{"VAN_CD",		2}
		};

	static final Object[][] TRANDIVIDE_0046_COMM = {	//캐시백 공동망작업 //490
		{"ITEM_LEN",				5} 
		,{"TR_ITEM_ID",				2}
		,{"TR_ITEM_SEQ",			3} // 명세 순번	 					
		,{"MCH_SEND_UNIQ_NO", 		40}			
		,{"TRADE_DATE", 			8}
		
		,{"TRADE_TIME", 			6}
		,{"MID",					10}
		,{"TERMINAL_ID",			17}
		,{"TRADE_AMT",				8}
		,{"COM_AMT",				8}
		
		,{"EVT_AMT",	 			8}
		,{"TOTAL_AMT",				8}
		,{"BANK_CD",	 			3}
		,{"TRANS_ID",				30}
		,{"AUTH_DATE",				8}
		
		,{"AUTH_NO",				13}
		,{"BEFORE_SALE_DATA",		8}
		,{"BEFORE_STORE_CD",		5}
		,{"BEFORE_POS_NO",			4}
		,{"BEFORE_TRAN_NO",			4}
		
		,{"BEFORE_SALE_AMT",		8}
		,{"ORG_MCH_SEND_UNIQ_NO",	40}
		,{"ORG_AUTH_DATE",			8}
		,{"ORG_AUTH_NO",			13}
		,{"INQ_UNIQ_NO",			6}
		
		,{"DRAW_FLAG",				1}
		,{"RESP_CODE",				4}
		,{"RESP_MSG",				200}
		,{"AFTER_FLAG",				1}
		,{"VAN_CD",					2}
		
		,{"ORG_POS_NO",				4}
		,{"ORG_TRAN_NO",    		4}
		,{"ISS_BANK_CD",			3}
		,{"VAN_TYPE_CD",			3}
		,{"PRT_ACCOUNT_NO",			20}
		
		,{"BUY_MCH_SEND_UNIQ_NO",	13}
						
		,{"MCH_CHARGE_AMT" ,16}
		,{"ISSINS_CHARGE_AMT" ,16}
		,{"BUYINS_CHARGE_AMT" ,16}
		,{"VAN_CHARGE_AMT" ,16}
	};	
	static final Object[][] TRANDIVIDE_0047 = {	//캐시백 사후출금
		{"ITEM_LEN",	5}, 
		{"TR_ITEM_ID",	2},
		{"TR_ITEM_SEQ",	3},		//명세 순번	 					
		{"ROD_CD",		2},		//입출금 코드
		{"ROD_AMT",		16},	//입출금 금액
		
		{"ROD_NM",		40},	//입출금 명
		{"ORG_SALE_DATE",8},	//원거래 일자
		{"ORG_STORE_CD", 5},	//원거래 점포코드
		{"ORG_POS_NO",	4},		//원거래 포스번호
		{"ORG_TRAN_NO",	4},		//원거래 거래번호
		
		{"INQ_UNIQ_NO",	6},		//단말거래일련번호
	};
	
	static final Object[][] TRANDIVIDE_0017 = {	//청호 이지캐시백 공동망 현금 IC 구매 
    	 {"ITEM_LEN",	5} 
		,{"TR_ITEM_ID",	2}
		,{"TR_ITEM_SEQ",3} 	 
		,{"TRAN_YMD" , 8}
		,{"STORE_CD" , 5}
		     
		,{"POS_NO" , 4}
		,{"TRAN_NO" , 4}
		,{"ORDER_UNIQ_NO", 13}			
		,{"TRAN_TYPE" ,2 }//00 승인 01 취소 , 03 망취소 
		,{"ISS_BANK_CD" , 3}
		
		,{"BUY_BANK_CD" , 3}
		,{"VAN_TYPE_CD" , 2}
		,{"PAY_AMT" , 16}
		,{"SERVICE_AMT" , 16}
		,{"VAT_AMT" , 16}
		
		,{"MCH_CHARGE_AMT" , 16}
		,{"ISSINS_CHARGE_AMT" , 16}
		,{"BUYINS_CHARGE_AMT" , 16}
		,{"VAN_CHARGE_AMT" , 16}
		,{"PRT_ACCOUNT_NO" , 20}
		
		,{"CASHBAG_TRAN_YN" , 1}
		,{"CASHBAG_TRAN_AMT" ,16 }
		,{"MCH_BUY_UNIQ_NO" , 13 }
		,{"ADMIT_DATE" , 8 }
		,{"ADMIT_TIME" , 6 }
		
		,{"ORG_TRAN_YMD" , 8}
		,{"ORG_POS_NO" , 4}		
		,{"ORG_TRAN_NO" , 4}
		,{"MCH_SEND_UNIQ_NO", 40}

	};
	static final Object[][] TRANDIVIDE_0048 = {	//아동급식카드 참사랑카드
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3},		//명세 순번	 					
		{"PAY_AMT",			16},
		{"CARD_INPUT_NO",	1},
		
		{"CARD_DATA",		20},
		{"CARD_ENC_DATA",	128},
		{"ADMIT_ID",		2},
		{"ADMIT_NO",		12},
		{"ADMIT_DATE",		8},
		
		{"ADMIT_TIME",		6},
		{"CARD_CORP_CD",	4},
		{"CARD_CORP_NM",	40},
		{"FRIEND_NO",		15},
		{"ORG_YMD",			8},
		
		{"ORG_ADMIT_NO",	12},
		{"SERVICE_AMT",		16},
		{"TAX_AMT",			16},
		{"TRAN_UNIQ_NO",	12},
		{"CUST_CD",			10}, //DEPOTVEN_CD
		
		{"MCH_SEND_UNIQ_NO",21},
		{"ORG_CD",			10},
		{"TRACE_NO",		10},
		{"STATUS_CD",		1},
		{"CARD_BIN",		10},
		
		{"IRT_SEND_DATE",		14}
	};

	

	
	static final Object[][] TRANDIVIDE_0049 = {	//관계사 식대
		{"ITEM_LEN",			5}, 
		{"TR_ITEM_ID",			2},
		{"TR_ITEM_SEQ",			3},						
		{"COMP_CD",				10},
		{"EMPLOYEE_NO",			128},

		{"PAY_AMT",				16},
		{"USE_AMT",				16},
		{"TAX_TARGET_AMT",		16},
		{"DUTYFREE_TARGET_AMT",	16},
		{"NONTAX_TARGET_AMT",	16},

		{"ZERO_TARGET_AMT",		16},
		{"APPR_TYPE",			1},
		{"REQ_TRANNO",			23},
		{"RFND_YN",				1},
		{"ORG_POS_NO",			4},
		
		{"ORG_TRAN_DT",			8},
		{"ORG_TRAN_NO",			4},
		{"REG_DATETIME",		14},
		{"IRT_NORMAL_TP",		1},
	};
	
	static final Object[][] TRANDIVIDE_0050 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TAX_ID",			4},
		{"TAX_NM",			50},
		{"TAX_TYPE",		1},
		{"TAX_FLAG",		1},
		{"AMT_TO_PERC",		16},
		{"TAX_TOT_AMT",		16},
	};
	
	static final Object[][] TRANDIVIDE_0051 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"PLU_CD",			30},
		{"DC_QTY",			4},
		{"DC_AMT",			16},
		{"DC_SUM_AMT",		16},
		{"EVT_CND",			1},
		{"EVT_ID",			2},
		{"EVT_CD",			13},
		{"EVT_GRP",			1},
		{"PLU_NM",			40},
	};
	
	static final Object[][] TRANDIVIDE_0052 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"APPR_DT",			8},
		{"APPR_NO",			20},
		{"TRAN_ID",			21},
		{"SAVE_CNCL_TP",	1},
		{"SAVE_POINT",		10},
		{"CARD_NO_ENCODED",	128},
		{"TRAN_DT",			8},
		{"ORG_APPR_DT",		8},
		{"ORG_APPR_NO",		20},
		{"CARD_NO",			20},
		{"TRAN_NORMAL_TP",	1},
		{"PAY_AMT",			20},
	};
	
	static final Object[][] TRANDIVIDE_0052_NEW = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"APPR_DT",			8},
		{"APPR_NO",			20},
		{"TRAN_ID",			21},
		{"SAVE_CNCL_TP",	1},
		{"SAVE_POINT",		10},
		{"CARD_NO_ENCODED",	128},
		{"TRAN_DT",			8},
		{"ORG_APPR_DT",		8},
		{"ORG_APPR_NO",		20},
		{"CARD_NO",			20},
		{"TRAN_NORMAL_TP",	1},
		{"PAY_AMT",			20},
		{"CUST_ID",			10}
	};
	
	static final Object[][] TRANDIVIDE_0053 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"IDENTI_TY",		1},
		{"INPUT_ID",		1},
		{"IDENTI_CONF_ENCODED",128},
		{"PAY_AMT",			16},
		{"TAX_AMT",			16},
		{"SERVICE_AMT",		16},
		{"AGREE_ID",		2},
		{"AGREE_NO",		9},
		{"AGREE_YMDHMS",	14},
		{"ORG_YMD",			8},
		{"ORG_AGREE_NO",	9},
		{"ORG_RES_ID",		1},
		{"IDENTI_CONF",		20},
	};
	
	static final Object[][] TRANDIVIDE_0053_NEW = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"IDENTI_TY",		1},
		{"INPUT_ID",		1},
		{"IDENTI_CONF_ENCODED",128},
		{"PAY_AMT",			16},
		{"TAX_AMT",			16},
		{"SERVICE_AMT",		16},
		{"AGREE_ID",		2},
		{"AGREE_NO",		9},
		{"AGREE_YMDHMS",	14},
		{"ORG_YMD",			8},
		{"ORG_AGREE_NO",	9},
		{"ORG_RES_ID",		1},
		{"IDENTI_CONF",		20},
		{"MUNWHA_FLAG",     1}
	};
	
	static final Object[][] TRANDIVIDE_0054 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"ASGN_CANCEL_YN",	1},
		{"DAT_CMD",			2},
		{"WORK_ID",			3},
		{"TRANSACTION_ID",	20},
		{"MEMBER_ID",		7},
		{"TERMINAL_ID",		9},
		{"CHRG_BEF_RAMT",	10},
		{"CHRG_REQ_AMT",	10},
		{"CHRG_AFT_RAMT",	10},
		{"DEAL_AMT",		10},
		{"ALGM_ID",			2},
		{"CARD_NO",			16},
		{"CARD_DEAL_SNO",	10},
		{"RAND_VAL",		16},
		{"SIGN1_VAL",		8},
		{"LSAM_ID",			16},
		{"LSAM_DEAL_SNO",	10},
		{"SIGN2_VAL",		8},
		{"CARD_OWNER_ID",	2},
		{"CHRG_FEE",		10},
		{"CARD_STS",		4},
		{"TERMINAL_STS",	4},
		{"CHRG_YMDHMS",		14},
		{"RES_CD",			5},
	};
	
	static final Object[][] TRANDIVIDE_0055 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"APPROVAL_NO",		32},
		{"TGMUNQ_ID",		64},
		{"BARCODE_NO",		48},
		{"PRODUCT_NM",		32},
		{"ACCT_FIXED_DT",	8},
		{"PAY_AMT",			20},
		{"APPR_YMDHMS",		14},
		{"CNCL_YMDHMS",		14},
		{"CELPHONE_NO",		12},
		{"IDNTFCN_NO",		6},
		{"CANCLE_YN",		1},
	};
	
	
	static final Object[][] TRANDIVIDE_0056 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_ASGN_CANCEL_YN",1},
		{"V_DAT_CMD",		2},
		{"V_WORK_ID",		3},
		{"V_TERMINAL_ID",	10},
		{"V_TRAN_ID",		10},
		{"V_SAM_TYPE",		2},
		{"V_SAM_ID",		16},
		{"V_CARD_NO",		20},
		{"V_CARD_DEAL_SNO",	10},
		{"V_DEAL_YMDHMS",	14},
		{"V_DEAL_BEF_RAMT",	10},
		{"V_DEAL_REQ_AMT",	10},
		{"V_DEAL_AFT_RAMT",	10},
		{"V_BEF_SAM_RAMT",	10},
		{"V_AFT_SAM_RAMT",	10},
		{"V_CARD_TYPE",		2},
		{"V_PAY_TYPE",		1},
		{"V_MBSCARD_EXP_DATE",4},
		{"V_MBSCARD_NO",	16},
		{"V_FIRST_CHRG_FG",	1},
		{"V_FRU",			3},
		{"V_FEE_RATE",		4},
		{"V_FEE_AMT",		10},
		{"V_SAM_DEAL_SNO",	10},
		{"V_SAM_TOT_CNT",	10},
		{"V_ALGM_ID",		2},
		{"V_KEYSET_VER",	2},
		{"V_CARD_DEPOSIT",	10},
		{"V_PENALTY_AMT",	10},
		{"V_CHRG_APPROVAL_NO",14},
		{"V_PUBCO_ID",		7},
		{"V_SIGN_VAL",		16},
		{"V_NCSAM",			10},
		{"V_NISAM", 		5},
		{"V_TOTSAM", 		10},
		{"V_IDCENTER",		2},
		{"V_MPSAM", 		10},
		{"V_MAXIDCENTER", 	10},
		{"V_BALIDCENTER", 	10},
		{"V_RFU",			8},
		{"V_RESULT",		1},
		{"V_SIGN_VAL_2",	8},
	};
	
	static final Object[][] TRANDIVIDE_0057 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_PARCEL_CMP",	2},
		{"V_PAY_DTL_ID",	2},
		{"V_SERVICE_CODE",	2},
		{"V_STORE_CD",		5},
		{"V_TOT_AMT",		9},
		{"V_INVOICE_CD",	20},
		{"V_PARCEL_IN_QTY",	4},
		{"V_INPUT_ID",		1},
		{"V_BASE_AMT",		9},
		{"V_PERRY_RTS_AMT",	9},
		{"V_ITEM_EXT_AMT",	9},
		{"V_DC_AMT",		9},
		{"V_BASE_AMT_BTN",	2},
		{"V_COMMISSION_TY",	1},
	};
	
	
	//20170809 KSN 한진택배서비스 추가
	static final Object[][] TRANDIVIDE_0015 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_PARCEL_CMP",	2},
		{"V_PARCEL_TP",		2}, 
		{"V_PAY_DTL_ID",	1},
		{"V_SERVICE_CODE",	2},
		{"V_ENP_DIV",		1},
		{"V_INVC_TYPE",		1},
		{"V_INVC_CD",		15},
		{"V_INVC_CD1",		15},
		{"V_INVC_CD2",		15},
		{"V_TOT_AMT",		9},
		{"V_BASE_AMT",		9},
		{"V_PERRY_RTS_AMT",	9},
		{"V_ITEM_EXT_AMT",	9},
		{"V_DC_AMT",		9},
		{"V_BASE_AMT_BTN",	2},
		{"V_COMMISSION_TY",	1},
		{"V_RCV_DATETIME",	14},
		{"V_PARCEL_IN_QTY",	4}
	};
	
	
	static final Object[][] TRANDIVIDE_0058_RENEW = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_MSG_ID",		8},
		{"V_TRAN_TYPE",		2},
		{"V_TERMINAL_ID",	15},
		{"V_SEND_DATE",		8},
		{"V_SEND_UNIQ_NO",	24},
		{"V_CASHER_NO",		10},
		{"V_SALE_DATE",		8},
		{"V_SALE_TIME",		6},
		{"V_DELEGATE_BARCODE_NO",	22},
		{"V_DELEGATE_BARCODE_NO_ENCODED",	64},
		{"V_EMP_ID_NO_PLAT_YN",		1},
		{"V_EMP_ID_NO_USE_YN",		1},
		{"V_EMP_ID_NO",				10},
		{"V_EMP_ID_NO_ENCODED",		32},
		{"V_S_POINT_PLAT_YN",		1},
		{"V_S_POINT_USE_YN",		1},
		{"V_S_POINT_CARD_NO",		16},
		{"V_S_POINT_CARD_NO_ENCODED",64},
		{"V_M_GIFT_CARD_PLAT_YN",	1},
		{"V_M_GIFT_CARD_USE_YN",	1},
		{"V_M_GIFT_CARD_NO",		16},
		{"V_M_GIFT_CARD_NO_ENCODED",64},
		{"V_M_GIFT_USE_AMT",		12},
		{"V_M_GIFT_AUTH_DATE",		8},
		{"V_M_GIFT_AUTH_NO",		12},
		{"V_ORG_M_GIFT_AUTH_DATE",	8},
		{"V_ORG_M_GIFT_AUTH_NO",	12},
		{"V_CREDIT_CARD_PLAT_YN",	1},
		{"V_CREDIT_CARD_YN",		1},
		{"V_CARD_CERT_FLAG",		2},
		{"V_CREDIT_CARD_NO",		16},
		{"V_CREDIT_CARD_NO_ENCODED",64},
		{"V_CREDIT_CARD_INS_MON",	2},
		{"V_CREDIT_CARD_USE_AMT",	12},
		{"V_CREDIT_CARD_AUTH_DATE",	8},
		{"V_CREDIT_CARD_AUTH_NO",	20},
		{"V_CREDIT_CARD_RECEIPT_A",	4},
		{"V_CREDIT_CARD_RECEIPT_A_EN",32},
		{"V_CREDIT_CARD_RECEIPT_D",	4},
		{"V_CREDIT_CARD_RECEIPT_D_EN",32},
		{"V_ORG_CREDIT_CARD_AUTH_DATE",8},
		{"V_ORG_CREDIT_CARD_AUTH_NO",20},
		{"V_CASH_RECEIPT_INFO_PLAT_YN",1},
		{"V_CASH_RECEIPT_INFO_USE_YN",1},
		{"V_CASH_RECEIPT_INFO",		11},
		{"V_CASH_RECEIPT_INFO_ENCODED",32},
		{"V_ETC_PAY_YN",			1},
		{"V_ETC_PAY_AMT",			12},
		{"V_ORG_SEND_DATE",			8},
		{"V_ORG_SEND_UNIQ_NO",		24},
		{"V_ORG_SER_COM_CD",		4},
		{"V_ORG_SALE_DATE",			8},
		{"V_ORG_ST_CODE",			10},
		{"V_ORG_TM_NO",				4},
		{"V_ORG_SHOP_NO",			4},
		{"V_ORG_CD_NO",				4},
		{"V_ORG_TRAN_NO",			4},
		{"V_ORG_CASHER_NO",			10},
		{"V_TOT_TRADE_AMT",			12},
		{"V_DIS_TRADE_AMT",			12},
		{"V_NET_TRADE_AMT",			12},
		{"V_MD_CNT",				4},
		{"V_MD_CODE",				50},
		{"V_MD_NAME",				100},
		{"V_BUY_FIRM_CODE",			4},
		{"V_BUY_FIRM_NM",			30},
		{"V_ISSUE_FIRM_CODE",		4},
		{"V_ISSUE_FIRM_NM",			30},
		{"V_EVENT_MD_IN_YN",		1},
		{"V_EVENT_YN",				1},
		{"V_BANK_YN",				1},
		{"V_BANK_ACCOUNT_NO_ENCRPT",96},
		{"V_BANK_RECEIPT",			15},
		{"V_BANK_AMT",				12},
		{"V_BANK_AUTH_NO",			15},
		{"V_BANK_AUTH_DATE",		8},
		{"V_BANK_ORG_AUTH_NO",		15},
		{"V_BANK_ORG_AUTH_DATE",	8},
		{"V_DC_MD_IN_YN",			1},
		{"V_SSGPAY_DC_YN",			1},
		{"V_SSGPAY_CP_PLAT_YN",		1},
		{"V_SSGPAY_CP_USE_YN",		1},
		{"V_SSGPAY_CP_AMT",			8},
	};
	
	static final Object[][] TRANDIVIDE_0058 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_MSG_ID",		8},
		{"V_TRAN_TYPE",		2},
		{"V_TERMINAL_ID",	15},
		{"V_SEND_DATE",		8},
		{"V_SEND_UNIQ_NO",	24},
		{"V_CASHER_NO",		10},
		{"V_SALE_DATE",		8},
		{"V_SALE_TIME",		6},
		{"V_DELEGATE_BARCODE_NO",	22},
		{"V_DELEGATE_BARCODE_NO_ENCODED",	64},
		{"V_EMP_ID_NO_PLAT_YN",		1},
		{"V_EMP_ID_NO_USE_YN",		1},
		{"V_EMP_ID_NO",				10},
		{"V_EMP_ID_NO_ENCODED",		32},
		{"V_S_POINT_PLAT_YN",		1},
		{"V_S_POINT_USE_YN",		1},
		{"V_S_POINT_CARD_NO",		16},
		{"V_S_POINT_CARD_NO_ENCODED",64},
		{"V_M_GIFT_CARD_PLAT_YN",	1},
		{"V_M_GIFT_CARD_USE_YN",	1},
		{"V_M_GIFT_CARD_NO",		16},
		{"V_M_GIFT_CARD_NO_ENCODED",64},
		{"V_M_GIFT_USE_AMT",		12},
		{"V_M_GIFT_AUTH_DATE",		8},
		{"V_M_GIFT_AUTH_NO",		12},
		{"V_ORG_M_GIFT_AUTH_DATE",	8},
		{"V_ORG_M_GIFT_AUTH_NO",	12},
		{"V_CREDIT_CARD_PLAT_YN",	1},
		{"V_CREDIT_CARD_YN",		1},
		{"V_CARD_CERT_FLAG",		2},
		{"V_CREDIT_CARD_NO",		16},
		{"V_CREDIT_CARD_NO_ENCODED",64},
		{"V_CREDIT_CARD_INS_MON",	2},
		{"V_CREDIT_CARD_USE_AMT",	12},
		{"V_CREDIT_CARD_AUTH_DATE",	8},
		{"V_CREDIT_CARD_AUTH_NO",	20},
		{"V_CREDIT_CARD_RECEIPT_A",	4},
		{"V_CREDIT_CARD_RECEIPT_A_EN",32},
		{"V_CREDIT_CARD_RECEIPT_D",	4},
		{"V_CREDIT_CARD_RECEIPT_D_EN",32},
		{"V_ORG_CREDIT_CARD_AUTH_DATE",8},
		{"V_ORG_CREDIT_CARD_AUTH_NO",20},
		{"V_CASH_RECEIPT_INFO_PLAT_YN",1},
		{"V_CASH_RECEIPT_INFO_USE_YN",1},
		{"V_CASH_RECEIPT_INFO",		11},
		{"V_CASH_RECEIPT_INFO_ENCODED",32},
		{"V_ETC_PAY_YN",			1},
		{"V_ETC_PAY_AMT",			12},
		{"V_ORG_SEND_DATE",			8},
		{"V_ORG_SEND_UNIQ_NO",		24},
		{"V_ORG_SER_COM_CD",		4},
		{"V_ORG_SALE_DATE",			8},
		{"V_ORG_ST_CODE",			10},
		{"V_ORG_TM_NO",				4},
		{"V_ORG_SHOP_NO",			4},
		{"V_ORG_CD_NO",				4},
		{"V_ORG_TRAN_NO",			4},
		{"V_ORG_CASHER_NO",			10},
		{"V_TOT_TRADE_AMT",			12},
		{"V_DIS_TRADE_AMT",			12},
		{"V_NET_TRADE_AMT",			12},
		{"V_MD_CNT",				4},
		{"V_MD_CODE",				50},
		{"V_MD_NAME",				100},
		{"V_BUY_FIRM_CODE",			4},
		{"V_BUY_FIRM_NM",			30},
		{"V_ISSUE_FIRM_CODE",		4},
		{"V_ISSUE_FIRM_NM",			30},
		{"V_EVENT_MD_IN_YN",		1},
		{"V_EVENT_YN",				1},
		{"V_BANK_YN",				1},
		{"V_BANK_ACCOUNT_NO_ENCRPT",96},
		{"V_BANK_RECEIPT",			15},
		{"V_BANK_AMT",				12},
		{"V_BANK_AUTH_NO",			15},
		{"V_BANK_AUTH_DATE",		8},
		{"V_BANK_ORG_AUTH_NO",		15},
		{"V_BANK_ORG_AUTH_DATE",	8},
		//{"V_EMPTY1",				118},
	};
	
	static final Object[][] TRANDIVIDE_0058_OLD = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_MSG_ID",		8},
		{"V_TRAN_TYPE",		2},
		{"V_TERMINAL_ID",	15},
		{"V_SEND_DATE",		8},
		{"V_SEND_UNIQ_NO",	24},
		{"V_CASHER_NO",		10},
		{"V_SALE_DATE",		8},
		{"V_SALE_TIME",		6},
		{"V_DELEGATE_BARCODE_NO",	22},
		{"V_DELEGATE_BARCODE_NO_ENCODED",	64},
		{"V_EMP_ID_NO_PLAT_YN",		1},
		{"V_EMP_ID_NO_USE_YN",		1},
		{"V_EMP_ID_NO",				10},
		{"V_EMP_ID_NO_ENCODED",		32},
		{"V_S_POINT_PLAT_YN",		1},
		{"V_S_POINT_USE_YN",		1},
		{"V_S_POINT_CARD_NO",		16},
		{"V_S_POINT_CARD_NO_ENCODED",64},
		{"V_M_GIFT_CARD_PLAT_YN",	1},
		{"V_M_GIFT_CARD_USE_YN",	1},
		{"V_M_GIFT_CARD_NO",		16},
		{"V_M_GIFT_CARD_NO_ENCODED",64},
		{"V_M_GIFT_USE_AMT",		12},
		{"V_M_GIFT_AUTH_DATE",		8},
		{"V_M_GIFT_AUTH_NO",		12},
		{"V_ORG_M_GIFT_AUTH_DATE",	8},
		{"V_ORG_M_GIFT_AUTH_NO",	12},
		{"V_CREDIT_CARD_PLAT_YN",	1},
		{"V_CREDIT_CARD_YN",		1},
		{"V_CARD_CERT_FLAG",		2},
		{"V_CREDIT_CARD_NO",		16},
		{"V_CREDIT_CARD_NO_ENCODED",64},
		{"V_CREDIT_CARD_INS_MON",	2},
		{"V_CREDIT_CARD_USE_AMT",	12},
		{"V_CREDIT_CARD_AUTH_DATE",	8},
		{"V_CREDIT_CARD_AUTH_NO",	20},
		{"V_CREDIT_CARD_RECEIPT_A",	4},
		{"V_CREDIT_CARD_RECEIPT_A_EN",32},
		{"V_CREDIT_CARD_RECEIPT_D",	4},
		{"V_CREDIT_CARD_RECEIPT_D_EN",32},
		{"V_ORG_CREDIT_CARD_AUTH_DATE",8},
		{"V_ORG_CREDIT_CARD_AUTH_NO",20},
		{"V_CASH_RECEIPT_INFO_PLAT_YN",1},
		{"V_CASH_RECEIPT_INFO_USE_YN",1},
		{"V_CASH_RECEIPT_INFO",		11},
		{"V_CASH_RECEIPT_INFO_ENCODED",32},
		{"V_ETC_PAY_YN",			1},
		{"V_ETC_PAY_AMT",			12},
		{"V_ORG_SEND_DATE",			8},
		{"V_ORG_SEND_UNIQ_NO",		24},
		{"V_ORG_SER_COM_CD",		4},
		{"V_ORG_SALE_DATE",			8},
		{"V_ORG_ST_CODE",			10},
		{"V_ORG_TM_NO",				4},
		{"V_ORG_SHOP_NO",			4},
		{"V_ORG_CD_NO",				4},
		{"V_ORG_TRAN_NO",			4},
		{"V_ORG_CASHER_NO",			10},
		{"V_TOT_TRADE_AMT",			12},
		{"V_DIS_TRADE_AMT",			12},
		{"V_NET_TRADE_AMT",			12},
		{"V_MD_CNT",				4},
		{"V_MD_CODE",				50},
		{"V_MD_NAME",				50},
		{"V_EMPTY1",				118},
	};
	
	static final Object[][] TRANDIVIDE_0059 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_DAT_CMD",		2},
		{"V_DEAL_UNIQ_NO",	18},
		{"V_FCSTR_ID",		15},
		{"V_PROC_CD",		2},
		{"V_CARD_NO",		16},
		{"V_CARD_TP",		4},
		{"V_CARD_CORP_TP",	2},
		{"V_PAYMENT_TP",	2},
		{"V_DEAL_YMDHMS",	14},
		{"V_ADJT_YMD",		8},
		{"V_TERMINAL_ID",	10},
		{"V_CHRG_BEF_RAMT",	10},
		{"V_CHRG_REQ_AMT",	10},
		{"V_CHRG_AFT_RAMT",	10},
		{"V_DEAL_AMT",		10},
		{"V_CARD_DEAL_SEQ_NO",8},
		{"V_RAND_VAL",		16},
		{"V_SIGN_VAL_1",	8},
		{"V_LSAM_ID",		16},
		{"V_LSAM_DEAL_SEQ_NO",8},
		{"V_SIGN_VAL_2",	8},
		{"V_CCARD_TP",		2},
		{"V_CCARD_FEE",		10},
		{"V_REFUND_TP",		2},
		{"V_ORG_DEAL_UNQ_NO",18},
		{"V_CHRG_RESP_CD",	2},
	};
	//20170828 알리페이결제수단추가_LYH
	static final Object[][] TRANDIVIDE_0064 = {
			{"ITEM_LEN"         , 5},     // ITEM 길이
			{"ITEM_ID"          , 2},     // '64' 알리페이 결제
			{"ITEM_SEQ"         , 3},     // 명세 순번
			{"SEND_UNIQ_NO"     , 12},    // 전송거래고유번호
			{"AUTH_CODE"        , 30},    // 알리페이 바코드

			{"PAY_CURRENCY"     , 3},     // 결제 요청 통화
			{"PAY_AMOUNT"       , 12},    // 결제 요청 금액
			{"SEND_DATE"        , 8},     // 전문전송일자
			{"AUTH_DATE"        , 14},    // 승인일자
			{"AUTH_NO"          , 12},    // 승인번호

			{"ORG_SEND_DATE"    , 8},     // 원거래전문전송일자
			{"ORG_SEND_UNIQ_NO" , 12},    // 원거래전송거래고유번호
			{"ORG_AUTH_DATE"    , 8},     // 원거래 승인일자
			{"ORG_AUTH_NO"      , 12},    // 원거래 승인번호
			{"AUTH_CODE_ENC"    , 128},   // 암호화된 알리페이 바코드

			{"INPUT_TYPE"       , 1},     // WCC
	};

	static final Object[][] TRANDIVIDE_0065 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_PLU_CD",		30},
		{"V_DC_QTY",		4},
		{"V_DC_AMT",		16},
		{"V_DC_SUM_AMT",	16},
		{"V_EVT_CND",		1},
		{"V_EVT_ID",		2},
		{"V_EVT_CD",		13},
		{"V_EVT_GRP",		1},
		{"V_PLU_NM",		40},
		{"V_VAN_CORP_CD",	2},
		{"V_CARD_CORP_CD",	4},
		{"V_EVT_PAY_CD",	1},
	};
	
	static final Object[][] TRANDIVIDE_0067 = {	//DGB충전 STTRP163DT
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"DGB_TRAN_TP",		2},
		{"DEAL_UNIQ_NO",	18},
		{"DEAL_YMDHMS",		14},
		{"ORG_DEAL_UNIQ_NO",18},
		{"TERMINAL_ID",		10},
		{"STORE_ID",		13},
		{"ADJT_YMD",		8},
		{"CARD_CD",		2},
		{"CARD_NO",			128},
		{"CARD_DATA",		20},
		{"CARD_USER_CD",	2},
		{"CARD_USER_TP",	4},
		{"CHRG_BEF_AMT",	10},
		{"DEAL_AMT",		10},
		{"CHRG_AFT_AMT",	10},
		{"NT_EP",			10},
		{"CARD_RANDOM_NO",	16},
		{"SAM_RANDOM_NO",	16},
		{"ID_SAM",			16},
		{"NT_SAM",			8},
		{"HOST_NO",			16},
		{"HOST_RANDOM_NO",	16},
		{"SIGN",			8},
		{"RETURN_TP",		2},
		{"RESP_CD",		15},
		{"TRAN_ID",			18}
	};
	
	static final Object[][] TRANDIVIDE_0068 = {	//DGB지불 STTRP373DT
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"DGB_TRAN_TP",		2},
		{"DEAL_UNIQ_NO",	18},
		{"DEAL_YMDHMS",		14},
		{"ORG_DEAL_UNIQ_NO",18},
		{"TERMINAL_ID",		10},
		{"STORE_ID",		13},
		{"CARD_CD ",		2},
		{"ALG_EP",			2},
		{"ID_CENTER",		2},
		{"VK_IND_KEY2",		2},
		{"VK_IND_KEY",		2},
		{"ID_SAM",			16},
		{"NC_SAM",			10},
		{"NI_SAM",			5},
		{"TOT_SAM",			10},
		{"CARD_NO",			128},
		{"CARD_DATA",		20},
		{"NT_EP",			10},
		{"BAL_EP",			10},
		{"DEAL_AMT",		10},
		{"NT_SAM",			10},
		{"SIGN_IND",		8},
		{"SIGN_IND2",		8},
		{"CARD_USER_CD",	2},
		{"CARD_USER_TP",	4},
		{"RID",				10},
		{"PAY_BEF_TP",		2},
		{"PAY_BEF_AMT",		8},
		{"PAY_BEF_NTEP",	8},
		{"PAY_REQ_AMT",		8},
		{"PAY_BEF_ID_SAM",	16},
		{"PAY_BEF_NT_SAM",	8},
		{"PAY_BEF_YMDHMS",	14},
		{"RESP_CD",		15},
		{"FEE",				10},
		{"TRAN_ID",			18}

	};
	
	
	static final Object[][] TRANDIVIDE_0069 = {	//SSGPAY 상시할인 STTRP181DT
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"SALE_DATE",		8},
		{"SALE_QTY",		4},
		{"SALE_AMT",	   16},
		{"DC_AMT",	   	   16},
		{"ORG_POS_NO",	    4},
		{"ORG_TRAN_DATE",	8},
		{"ORG_TRAN_NO",		4}
	};
	
	static final Object[][] TRANDIVIDE_0071 = { //SPC  캐시비
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_ASGN_CANCEL_YN",1},
		{"V_DAT_CMD",		2},
		{"V_WORK_ID",		3},
		{"V_TERMINAL_ID",	10},
		{"V_TRAN_ID",		10},
		{"V_SAM_TYPE",		2},
		{"V_SAM_ID",		16},
		{"V_CARD_NO",		20},
		{"V_CARD_DEAL_SNO",	10},
		{"V_DEAL_YMDHMS",	14},
		{"V_DEAL_BEF_RAMT",	10},
		{"V_DEAL_REQ_AMT",	10},
		{"V_DEAL_AFT_RAMT",	10},
		{"V_BEF_SAM_RAMT",	10},
		{"V_AFT_SAM_RAMT",	10},
		{"V_CARD_TYPE",		2},
		{"V_PAY_TYPE",		1},
		{"V_MBSCARD_EXP_DATE",4},
		{"V_MBSCARD_NO",	16},
		{"V_FIRST_CHRG_FG",	1},
		{"V_FRU",			3},
		{"V_FEE_RATE",		4},
		{"V_FEE_AMT",		10},
		{"V_SAM_DEAL_SNO",	10},
		{"V_SAM_TOT_CNT",	10},
		{"V_ALGM_ID",		2},
		{"V_KEYSET_VER",	2},
		{"V_CARD_DEPOSIT",	10},
		{"V_PENALTY_AMT",	10},
		{"V_CHRG_APPROVAL_NO",14},
		{"V_PUBCO_ID",		7},
		{"V_SIGN_VAL",		16},
		{"V_NCSAM",			10},
		{"V_NISAM", 		5},
		{"V_TOTSAM", 		10},
		{"V_IDCENTER",		2},
		{"V_MPSAM", 		10},
		{"V_MAXIDCENTER", 	10},
		{"V_BALIDCENTER", 	10},
		{"V_RFU",			8},
		{"V_RESULT",		1},
		{"V_SIGN_VAL_2",	8}
	};
	
	static final Object[][] TRANDIVIDE_0087 = { // 20180629 JMH 모바일 문화 상품권(MCB_Tran)
	      {"ITEM_LEN"         ,   5} 
	    , {"TR_ITEM_ID"       ,   2}
	    , {"TR_ITEM_SEQ"      ,   3} // 명세 순번
		, {"COM_CD"			  ,   4}
		, {"STORE_CD"		  , 5}
		, {"POS_NO",   	    4}
		, {"TRAN_NO",		4}
	    , {"TRAN_TP"          ,   1} // 취소구분 0사용 1취소
	    , {"PIN_NO"           ,  80} // 모바일 문화 상품권 바코드
	    , {"PIN_FACE_AMT"     ,   9} // 액면가                   
	    , {"PIN_TRADE_AMT"    ,   9} // 거래금액                 
	    , {"PIN_BAL_AMT"      ,   9} // 액면가                   
	    , {"CUL_TRACE_NO"     ,  25} // 컬처랜드거래번호(UNIQ)   
	    , {"TRACE_NO"         ,  50} // 사용처 거래번호(UNIQ)    
	    , {"REQ_DY"           ,   8} // 요청일자                 
	    , {"REQ_TM"           ,   6} // 요청시간                  
	    , {"INPUTTYPE"        ,   1} // 입력구분                 
	    , {"ITEM_NM"          ,  50} // 구매상품명               
	    , {"RESP_DY"          ,   8} // 승인일자                 
	    , {"RESP_TM"          ,   6} // 승인시간                 
	    , {"ORG_TRAN_YMD"     ,   8} // 원거래 일                
	    , {"ORG_STORE_CD"     ,   5} // 원거래 점포코드          
	    , {"ORG_POS_NO"       ,   4} // 원거래 포스번호          
	    , {"ORG_TRAN_NO"      ,   4} // 원거래 거래번호          
	    , {"ORG_CUL_TRACE_NO" ,  25} // 원거래 컬처랜드 거래번호 
	    , {"ORG_TRACE_NO"     ,  50} // 원거래 사용처 거래번호   
	    , {"ORG_RESP_DT"      ,   8} // 원거래 승인일자          
	    , {"ORG_RESP_TM"      ,   6} // 원거래 승인시간          
	  };
	
	
	
	
	static final Object[][] TRANDIVIDE_0081 = {	//20171207 KSN SSG CON STTRP182DT
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TRACE_NO",	   26},
		{"SEL_AUTH_NO",	   20},
		{"TRADE_TYPE",	    2},
		{"COUPON_NO",	   20},
		{"COUPON_NO_ENC",  64},
		
		{"BARCODE_NO",	   22},
		{"BARCODE_NO_ENC", 64},
		{"USED_AMT",	   12},
		{"REMAIN_AMT",	   12},
		{"SALE_DATE",	    8},
		
		{"SALE_TIME",	    6},
		{"AUTH_DATE",	    8},
		{"AUTH_TIME",		6},
		{"AUTH_NO",			8},
		{"ORG_TRACE_NO",   26},
		
		{"ORG_SALE_DATE",   8},
		{"ORG_AUTH_DATE",   8},
		{"ORG_AUTH_NO",     8},
		{"PRD_TYPE",        4},
		{"CLASS_GUBUN",     3},
		
		{"PRD_ID",     	   20},
		{"PRD_NM",     	   64},
		{"PRD_AMT",    	   12},
		{"MSG_SEND_DT",     8},
		{"MSG_SEND_TM",     6},
		
		{"PTR_MCH_ID",     15},
		{"CASHER_NO",      10},
		{"TRAN_TYPE",       2},
		{"KEY_IN_TYPE",     2},
		{"USE_FUNC_GUBUN",  1},
		
		{"USE_GUBUN",  		1},
		{"GRP_TYPE",  		2},
		{"TOT_TRADE_AMT",  12},
		{"ORG_MSG_SEND_DT", 8}
	};
	
	static final Object[][] TRANDIVIDE_0081_PRD = {	//20180110 KSN SSG CON PRD STTRP182DT
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"TRACE_NO",	   26},
		{"SEL_AUTH_NO",	   20},
		{"TRADE_TYPE",	    2},
		{"COUPON_NO",	   20},
		{"COUPON_NO_ENC",  64},
		
		{"BARCODE_NO",	   22},
		{"BARCODE_NO_ENC", 64},
		{"USED_AMT",	   12},
		{"REMAIN_AMT",	   12},
		{"SALE_DATE",	    8},
		
		{"SALE_TIME",	    6},
		{"AUTH_DATE",	    8},
		{"AUTH_TIME",		6},
		{"AUTH_NO",			8},
		{"ORG_TRACE_NO",   26},
		
		{"ORG_SALE_DATE",   8},
		{"ORG_AUTH_DATE",   8},
		{"ORG_AUTH_NO",     8},
		{"PRD_TYPE",        4},
		{"CLASS_GUBUN",     3},
		
		{"PRD_ID",     	   20},
		{"PRD_NM",     	   64},
		{"PRD_AMT",    	   12},
		{"MSG_SEND_DT",     8},
		{"MSG_SEND_TM",     6},
		
		{"PTR_MCH_ID",     15},
		{"CASHER_NO",      10},
		{"TRAN_TYPE",       2},
		{"KEY_IN_TYPE",     2},
		{"USE_FUNC_GUBUN",  1},
		
		{"USE_GUBUN",  		1},
		{"GRP_TYPE",  		2},
		{"TOT_TRADE_AMT",  12},
		{"ORG_MSG_SEND_DT", 8},
		{"PRD_SKU_CODE",   20}
	};
	
	
	static final Object[][] TRANDIVIDE_0082 = {	//20180206 KSN ECON CP_ECON_MST
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"COM_CD",	   	    4},
		{"TRAN_YMD",	    8},
		{"STORE_CD",	    5},
		{"POS_NO",   	    4},
		{"TRAN_NO",		    4},
		
		{"EVT_CD",	       20},
		{"EVT_NM",		   40},
		{"COUPON_NO",	   20},
		{"COUPON_TP",	    3},
		{"COUPON_AMT_TP",   1},
		
		{"COUPON_AMT",	   12},
		{"COUPON_RM_AMT",  12},
		{"COUPON_PLU_CD",  20},
		{"START_DT",	    8},
		{"EXPIRE_DT",	    8},
		
		{"ISSUE_SYS",		1},
		{"ISSUE_DT",		8},
		{"ISSUE_TM", 	    6},
		{"CP_MSG_01", 	  100},
		{"CP_MSG_02", 	  100},
		
		{"CP_MSG_03", 	  100},
		{"CP_MSG_04", 	  100},
		{"CP_MSG_05", 	  100},
		{"CP_MSG_06", 	  100},
		{"CP_MSG_07", 	  100},
		
		{"CP_MSG_08", 	  100},
		{"CP_MSG_09", 	  100},
		{"CP_MSG_10", 	  100},
		{"COUPON_USE_EXPR_AMT",  12},
		{"OTH_STR_ENBL_YN",       1},
		
		{"CP_AMTMNG_YN",    1}
	};
	
	
	static final Object[][] TRANDIVIDE_0083 = {	//20180206 KSN ECON STTRP830DT
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"COM_CD",	   	    4},
		{"TRAN_YMD",	    8},
		{"STORE_CD",	    5},
		{"POS_NO",   	    4},
		{"TRAN_NO",		    4},
		
		{"EVT_CD",	       20},
		{"COUPON_NO",	   20},
		{"COUPON_TP",	    3},
		{"COUPON_AMT_TP",   1},
		{"TRADE_AMT",	   12},
		
		{"REMAIN_AMT",     12},
		{"COUPON_PLU_CD",  20},
		{"ISSUE_SYS",		1},
		{"AUTH_NO",		   10},
		{"AUTH_DT", 	    8},
		
		{"AUTH_TM", 	    6},
		{"ORG_TRAN_YMD",    8},
		{"ORG_STORE_CD",    5},
		{"ORG_POS_NO", 	    4},
		{"ORG_TRAN_NO", 	4},
		
		{"ORG_AUTH_NO",    10},
		{"ORG_AUTH_DT",     8},
		{"ORG_AUTH_TM",     6}
	};

	static final Object[][] TRANDIVIDE_0084 = {
		{"ITEM_LEN",     5},	// ITEM 사이즈
		{"TR_ITEM_ID",      2},	// ITEM 식별ID
		{"TR_ITEM_SEQ",     3}, // 명세 순번
		{"PARCEL_CMP_TP",   2},	// 택배사구분(01:CJ택배, 02:한진택배)
		{"JOB_TYPE",        2},	// 업무구분(01:일반택배, 02:퀵택배)

		{"PAY_DTL_ID",      1},	// 결제구분(1:현금 선분, 2:착불, 3:신용카드 선불)
		{"TRAN_TP",         2},	// 거래유형(01:접수, 02:환불)
		{"ENP_DIV",         1},	// 택배구분(1:국내, 2:국제, 3:반품, 4:예약)
		{"INVC_TYPE",       1},	// 송장구분(1:수기송장, 2:라벨송장)
		{"PARCEL_CD",      15},	// 운송장번호

		{"TOT_AMT",         9},	// 택배금액
		{"BASE_AMT",        9},	// 기본운임금액
		{"PILOTAGE_AMT",    9},	// 도선료
		{"ITEM_EXT_AMT",    9},	// 할증 금액
		{"DC_AMT",          9},	// 할인 금액

		{"CUST_NO",        20},	// 회원번호
		{"SND_ZIP",         6},	// 송하인 우편번호
		{"SND_ADD1",      200},	// 송하인 동이상 주소
		{"SND_ADD2",      200},	// 송하인 동미만 주소
		{"SND_NAME",      100},	// 송하인명
		
		{"SND_TEL",        30},	// 송하인 전화번호
		{"SND_HPH",        30},	// 송하인 휴대폰번호
		{"RCV_ZIP",         6},	// 수하인 우편번호
		{"RCV_ADD1",      200},	// 수하인 동이상 주소
		{"RCV_ADD2",      200},	// 수하인 동미만 주소

		{"RCV_NAME",      100},	// 수하인명		
		{"RCV_TEL",	       30},	// 수하인 전화번호
		{"RCV_HPH",        30}	// 수하인 휴대폰번호
	};
	
	// 카카오페이 NEW JMH
	  static final Object[][] TRANDIVIDE_0088_NEW = {
			{"ITEM_LEN",		5}, 
			{"TR_ITEM_ID",		2},
			{"TR_ITEM_SEQ",		3}, // 명세 순번
			
			{"PAY_AMT",			16},
			{"CARD_INPUT_ID",	1},
			{"CARD_DATA",		128},
			{"INSTMNT_PRD",		2},
			{"AGREE_ID",		2},
			{"AGREE_NO",		12},
			{"AGREE_YMDHMS",	14},
			{"CARD_CORP_CD",	4},
			{"CARD_CORP_NM",	40},
			{"FRIEND_NO",		15},
			{"ORG_YMD",			14},
			{"ORG_AGREE_NO",	12},
			{"SERVICE_AMT",		16},
			{"CARD_DATA_VISIBLE", 20},
			{"CARD_KIND", 1},
			{"CARD_BUY_CD", 4},
			{"VAN_TID", 15}
		};
		// 카카오페이 JMH
		static final Object[][] TRANDIVIDE_0088 = {
			{"ITEM_LEN",		5}, 
			{"TR_ITEM_ID",		2},
			{"TR_ITEM_SEQ",		3}, // 명세 순번
			
			{"PAY_AMT",			16},
			{"CARD_INPUT_ID",	1},
			{"CARD_DATA",		128},
			{"INSTMNT_PRD",		2},
			{"AGREE_ID",		2},
			{"AGREE_NO",		12},
			{"AGREE_YMDHMS",	14},
			{"CARD_CORP_CD",	4},
			{"CARD_CORP_NM",	40},
			{"FRIEND_NO",		15},
			{"ORG_YMD",			8},
			{"ORG_AGREE_NO",	12},
			{"SERVICE_AMT",		16},
			{"CARD_DATA_VISIBLE", 20},
			{"CARD_KIND", 1}
		};
		// 카카오페이 OLD JMH
		static final Object[][] TRANDIVIDE_0088_OLD = {
			{"ITEM_LEN",		5}, 
			{"TR_ITEM_ID",		2},
			{"TR_ITEM_SEQ",		3}, // 명세 순번
			
			{"PAY_AMT",			16},
			{"CARD_INPUT_ID",	1},
			{"CARD_DATA",		128},
			{"INSTMNT_PRD",		2},
			{"AGREE_ID",		2},
			{"AGREE_NO",		12},
			{"AGREE_YMDHMS",	14},
			{"CARD_CORP_CD",	4},
			{"CARD_CORP_NM",	40},
			{"FRIEND_NO",		15},
			{"ORG_YMD",			8},
			{"ORG_AGREE_NO",	12},
			{"SERVICE_AMT",		16},
			{"CARD_DATA_VISIBLE", 20}
		};
	
	static final Object[][] TRANDIVIDE_0092 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_TRAN_YMD",		8},
		{"V_STORE_CD",		5},
		{"V_PDA_NO",		4},
		{"V_PDATRAN_NO",	4},
		{"V_SYS_YMDHMS",	14},
	};
	
	// onebarcode
	static final Object[][] TRANDIVIDE_0093 = {
		{"ITEM_LEN",		5}, 
		{"ITEM_ID",		2},
		{"ITEM_SEQ",		3}, // 명세 순번
		
		{"ENC_ONE_BARCODE",	128}
	};
	static final Object[][] TRANDIVIDE_6060 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_ROD_CD",		2},
		{"V_ROD_AMT",		16},
		{"V_ROD_NM",		40},
	};
	
	static final Object[][] TRANDIVIDE_7070 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_EXECUTE_TY",	1},
	};
	
	static final Object[][] TRANDIVIDE_7074 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_EXACT_CD",		4},
		{"V_EXACT_QTY",		10},
		{"V_EXACT_AMT",		16},
	};
	
	static final Object[][] TRANDIVIDE_7075 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_EXACT_CD",		4},
		{"V_EXACT_QTY",		10},
		{"V_EXACT_AMT",		16},
	};
	
	static final Object[][] TRANDIVIDE_7076 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_EXACT_CD",		4},
		{"V_EXACT_QTY",		10},
		{"V_EXACT_AMT",		16},
	};
	
	static final Object[][] TRANDIVIDE_7077 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_EXACT_CD",		4},
		{"V_EXACT_QTY",		10},
		{"V_EXACT_AMT",		16},
	};
	
	static final Object[][] TRANDIVIDE_8080 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_AOL_ID",		1},
		{"V_WORKER_PLU_CD",	13},
		{"V_AOL_YMDHMS",	14},
		{"V_AOL_NM",		40},
	};
	
	static final Object[][] TRANDIVIDE_9091 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_SALE_DT",		8},
		{"V_SALE_TIME",	4},
		{"V_CASHIER_NO",	13},
	};
	
	static final Object[][] TRANDIVIDE_9099 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_MNTY_MGT_YMDHMS",	14},
	};
	
	static final Object[][] TRANDIVIDE_2000 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_TRAN_TYPE",		1},
		{"V_PMOD_YN",		1},
		{"V_STOP_YN",		1},
		{"V_TRAN_KIND",		2},
		{"V_TRAN_YMD",		8},
		{"V_STORE_CD",		5},
		{"V_POS_NO",		4},
		{"V_TRAN_NO",		4},
		{"V_SYS_YMDHMS",	14},
		{"V_OP_NO",			13},
		{"V_ORG_TRAN_YMD",	8},
		{"V_ORG_POS_NO",	4},
		{"V_ORG_TRAN_NO",	4},
		{"V_ORG_STORE_CD",	5},
		{"V_ORG_RES_ID",	2},
		{"V_APP_OP_NO",		13},
		{"V_CUST_CLS_ID",	2},
		{"V_CUST_COUNT",	3},
		{"V_ORDER_TYPE",	1},
		{"V_FLOOR_CD",		4},
		{"V_TABLE_NO",		4},
		{"V_GSALE_AMT",		16},
		{"V_GDC_AMT",		16},
		{"V_NSALE_AMT",		16},
		{"V_SCHARGE_AMT",	16},
	};
	
	static final Object[][] TRANDIVIDE_2001 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_ASGN_CANCEL_YN",1},
		{"V_PLU_CD",30},
		{"V_PLU_FLAG",1},
		{"V_CATE_ID",10},
		{"V_GRP_ID",10},
		{"V_SGRP_ID",10},
		{"V_BRAND_ID",10},
		{"V_ITEM_ID",2},
		{"V_SALE_QTY",4},
		{"V_SALE_UPRC",16},
		{"V_SALE_AMT",16},
		{"V_PRICE_CHG_ID",1},
		{"V_PRICE_CHG_UPRC",16},
		{"V_ITEM_INPUT_ID",1},
		{"V_SCAN_CD",30},
		{"V_BTL_SUM_AMT",16},
		{"V_BTL_PLU_CD",30},
		{"V_ITEM_NM",40},
		{"V_ITEM_TAX_ID",1},
		{"V_ITEM_TAX_VALUE",16},
		{"V_RECT_AMT",16},
		{"V_POS_DC_ID",1},
		{"V_POS_DC_RATE",5},
		{"V_POS_DC_AMT",16},
		{"V_EVT_DC_QTY",4},
		{"V_EVT_DC_AMT",16},
		{"V_CO_DC_ID",1},
		{"V_CO_DC_QTY",4},
		{"V_CO_DC_AMT",16},
		{"V_SALE_UNIT_QTY",3},
		{"V_SCRAP_RES_ID",2},
		{"V_SERVICE_FLAG",1},
		{"V_PACK_FLAG",1},
		{"V_DISUSE_FLAG",1},
		{"V_REASON_ID",10},
		{"V_DBUYING_FLAG",1},
		{"V_SERVICE_ITEM_TY",2},
		{"V_ITEM_CD",30},
		{"V_SALES_TYPE",1},
	};
	
	static final Object[][] TRANDIVIDE_4001 = {
		{"ITEM_LEN",		5}, 
		{"TR_ITEM_ID",		2},
		{"TR_ITEM_SEQ",		3}, // 명세 순번
		
		{"V_ASGN_CANCEL_YN",1},
		{"V_PLU_CD",30},
		{"V_PLU_FLAG",1},
		{"V_CATE_ID",10},
		{"V_GRP_ID",10},
		{"V_SGRP_ID",10},
		{"V_BRAND_ID",10},
		{"V_ITEM_ID",2},
		{"V_SALE_QTY",4},
		{"V_SALE_UPRC",16},
		{"V_SALE_AMT",16},
		{"V_PRICE_CHG_ID",1},
		{"V_PRICE_CHG_UPRC",16},
		{"V_ITEM_INPUT_ID",1},
		{"V_SCAN_CD",30},
		{"V_BTL_SUM_AMT",16},
		{"V_BTL_PLU_CD",30},
		{"V_ITEM_NM",40},
		{"V_ITEM_TAX_ID",1},
		{"V_ITEM_TAX_VALUE",16},
		{"V_RECT_AMT",16},
		{"V_POS_DC_ID",1},
		{"V_POS_DC_RATE",5},
		{"V_POS_DC_AMT",16},
		{"V_EVT_DC_QTY",4},
		{"V_EVT_DC_AMT",16},
		{"V_CO_DC_ID",1},
		{"V_CO_DC_QTY",4},
		{"V_CO_DC_AMT",16},
		{"V_SALE_UNIT_QTY",3},
		{"V_SCRAP_RES_ID",2},
		{"V_SERVICE_FLAG",1},
		{"V_PACK_FLAG",1},
		{"V_DISUSE_FLAG",1},
		{"V_REASON_ID",10},
		{"V_DBUYING_FLAG",1},
		{"V_SERVICE_ITEM_TY",2},
		{"V_ITEM_CD",30},
		{"V_SALES_TYPE",1},
		{"V_EVT_CARD_TY",1},
		{"V_EVT_CARD_QTY",4},
		{"V_EVT_CARD_AMT",16},
	};
}
