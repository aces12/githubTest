package biz.cms_TranDivide;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import sun.misc.BASE64Decoder;
import biz.comm.AES;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import com.cyberpass.seed.Seed;

public class TranDivideDAO extends GenericDAO {
	
	/**
	 * SQLException
	 * ORA-00001(무결성 제약 조건 위배) => STTRP010DT 테이블에서 해당 데이터의 PROC_STS_ID 값을 '1'로 지정
	 **/
	private static Logger logger = Logger.getLogger(TranDividePollingAction.class);
	
	@SuppressWarnings("unchecked")
	public List<Map<Object, Object>> selDivideList(COMMLog cLog){
		List<Map<Object, Object>> result = null;
		String sql_debug = null;
		
		connect("CMGNS"); // DB Connection
		try {
			SqlWrapper sql = new SqlWrapper();
			sql.put(findQuery("tran-divide", "SEL_TRANDIVIDE_LIST"));
			sql.setString(1, "1002");
			sql_debug = sql.debug(); // SQL debug
			result = executeQuery(sql);
		} catch(Exception e) {
			logger.info("[ERROR] " + e);
			logger.info("[SQL DEBUG] " + sql_debug);
		}
		
		return result;
	}
	
	public void tranDivideModule(String procNO, Map<Object, Object> data, COMMLog cLog) {
		String result = "1";
		try {
			// 전문(원본)
			String deal_dat = (String)data.get("deal_dat");
			
			// 전문 길이(통신Header 50byte 제외한 길이)
			int len_all = Integer.parseInt(deal_dat.substring(0, 6));
			
			// 통신Header 50byte 제외한 전문
			String tran_data = deal_dat.substring(50);
			
			// TranHeader의 SYS_YMD 추출
			String sys_ymd = tran_data.substring(36, 44);
			
			int len_all_temp = 0;
			int offset = 0;
			
			// 인코딩한 전문의 Byte값
			byte[] b = tran_data.getBytes("MS949");
			logger.info("TranDivideDAO ::: tranDivideModule ::: len_b ["+b.length+"]");
			
			// 전문 길이와 인코딩한 데이터의 길이(Bytes)가 다른 경우
			if(len_all != b.length) {
				// 전문 분해를 하지 않고
				// STTRP010DT 테이블의 PROC_STS_ID = '9' 처리
				result = "9";
				procErrLog("tranDivideModule", "전문 길이와 인코딩한 데이터의 길이(Bytes)가 다른 경우", "WRONG LENGTH(bytes)", data, cLog);
				logger.info("TranDivideDAO ::: tranDivideModule ::: WRONG LENGTH(bytes)::: len_all ["+len_all+"], b.length ["+b.length+"]");
				
			} else {
				connect("CMGNS");
				begin(); // TRANSACTION = true
				
				SqlWrapper sql = new SqlWrapper();
				
				// 남은 전문의 길이
			    int len_rest = len_all;
			    int loop_num = 0;
				while(len_rest > 0) {
					loop_num ++;
					// 전문 ITEM 길이
					int len_item = Integer.parseInt(new String(b, offset, 5, "MS949"));
					
					// 전문 ITEM
					String item = new String(b, offset, len_item, "MS949");
					logger.info("TranDivideDAO ::: tranDivideModule ::: item ["+item+"]");
					
					// 전문 ITEM_ID
					String item_id = item.substring(5, 7);
					logger.info("TranDivideDAO ::: tranDivideModule ::: item_id ["+item_id+"]");
					
					// 전문 길이 검증을 위한 계산
					len_all_temp += len_item;
					//logger.info("len_all_temp : "+len_all_temp);
					
					// 전문 길이 오류 검증
					if(len_all_temp > len_all || len_item < 1 || len_rest < 0) {
						procErrLog("tranDivideModule", "전문 길이 오류 검증", "TRAN DATA ITEM LENGTH IS INCORRECT.", data, cLog);
						logger.info("TranDivideDAO ::: tranDivideModule ::: tran length error ::: len_all_temp ["+len_all_temp+"], len_all ["+len_all+"], len_item ["+len_item+"], len_rest ["+len_rest+"]");
						result = "9";
						break;
					}
					
					// offset 설정
					offset += len_item;
					len_rest -= len_item;
					//logger.info("len_rest : "+len_rest);
					
					// CM_TRANDIVIDE_00
					if("00".equals(procNO)) {
					/*	
					 * 기존 SP_TRANDIVIDE_00 프로시저의 기능을 수행
					 * 프로시저의 IF V_TR_ITEM_ID = '00' THEN... 조건문에서 call하는 하위 프로시저(SP_TRANDIVIDE_00XX)의
					 * name 형식을 판단하여 서술 한다.
					 * 
					 * ex.) SP_TRANDIVIDE_ || '00' || V_TR_ITEM_ID => procNM + procNO + item_id 
					 */
						if (!"56".equals(item_id) && "1".equals((String)data.get("stop_yn"))) 
						{
							// 일괄취소에 대한 별도 매출분해
							if("00".equals(item_id)) { // call "CM_TRANDIVIDE_0000"
								int ret = CM_TRANDIVIDE_0000_CANCEL(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("01".equals(item_id)) { // call "CM_TRANDIVIDE_0001"
								int ret = CM_TRANDIVIDE_0001_CANCEL(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							//} else if("10".equals(item_id)) { // call "CM_TRANDIVIDE_0010" 봉사료(매출거래)
							}							
						} 
						else 
						{
							if("00".equals(item_id)) { // call "CM_TRANDIVIDE_0000"
								int ret = CM_TRANDIVIDE_0000(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("01".equals(item_id)) { // call "CM_TRANDIVIDE_0001"
								int ret = CM_TRANDIVIDE_0001(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("18".equals(item_id)) { // SSGPAY 쿠폰
								String allItem1 = new String (b,"MS949");
//								logger.info("all tran data [" + allItem1 +  "]");		
								int ret = CM_TRANDIVIDE_0018(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("19".equals(item_id)) { // call "CM_TRANDIVIDE_0019" Staff DC
								int ret = CM_TRANDIVIDE_0019(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}		
							} else if("20".equals(item_id)) { // call "CM_TRANDIVIDE_0020"
								int ret = CM_TRANDIVIDE_0020(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("21".equals(item_id)) { // call "CM_TRANDIVIDE_0021"
								int ret = CM_TRANDIVIDE_0021(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("22".equals(item_id)) { // call "CM_TRANDIVIDE_0022"
								int ret = CM_TRANDIVIDE_0022(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("23".equals(item_id)) { // call "CM_TRANDIVIDE_0023"
								int ret = CM_TRANDIVIDE_0023(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("24".equals(item_id)) { // call "CM_TRANDIVIDE_0024"
								int ret = CM_TRANDIVIDE_0024(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("25".equals(item_id)) { // call "CM_TRANDIVIDE_0025"
								int ret = CM_TRANDIVIDE_0025(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("26".equals(item_id)) { // call "CM_TRANDIVIDE_0026"
								int ret = CM_TRANDIVIDE_0026(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("27".equals(item_id)) { // call "CM_TRANDIVIDE_0027"
								int ret = CM_TRANDIVIDE_0027(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("28".equals(item_id)) { // call "CM_TRANDIVIDE_0028"
								int ret = CM_TRANDIVIDE_0028(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("29".equals(item_id)) { // call "CM_TRANDIVIDE_0029"
								int ret = CM_TRANDIVIDE_0029(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("30".equals(item_id)) { // call "CM_TRANDIVIDE_0030"
								int ret = CM_TRANDIVIDE_0030(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("31".equals(item_id)) { // call "CM_TRANDIVIDE_0031"
								int ret = CM_TRANDIVIDE_0031(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("32".equals(item_id)) { // call "CM_TRANDIVIDE_0032"
								int ret = CM_TRANDIVIDE_0032(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("33".equals(item_id)) { // call "CM_TRANDIVIDE_0033"
								int ret = CM_TRANDIVIDE_0033(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("34".equals(item_id)) { // call "CM_TRANDIVIDE_0034"
								int ret = CM_TRANDIVIDE_0034(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("35".equals(item_id)) { // call "CM_TRANDIVIDE_0035"
								int ret = CM_TRANDIVIDE_0035(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("36".equals(item_id)) { // call "CM_TRANDIVIDE_0036"
								int ret = CM_TRANDIVIDE_0036(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("37".equals(item_id)) { // call "CM_TRANDIVIDE_0037"
								int ret = CM_TRANDIVIDE_0037(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("38".equals(item_id)) { // call "CM_TRANDIVIDE_0038"
								int ret = CM_TRANDIVIDE_0038(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("39".equals(item_id)) { // call "CM_TRANDIVIDE_0039"
								int ret = CM_TRANDIVIDE_0039(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("40".equals(item_id)) { // call "CM_TRANDIVIDE_0040" 위챗페이
								int ret = CM_TRANDIVIDE_0040(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("41".equals(item_id)) { // call "CM_TRANDIVIDE_0041"
								int ret = CM_TRANDIVIDE_0041(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("42".equals(item_id)) { //GTF
								String allItem = new String (b,"MS949");
								logger.info("all tran data [" + allItem + "]");				
								int ret = CM_TRANDIVIDE_0042(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("43".equals(item_id)) {  // SSGPAY 계좌 결제
								//String allItem = new String (b,"MS949");
								//logger.info("item_id [" + item_id +  "]");
								//logger.info("all tran data [" + allItem +  "]");		
								int ret = CM_TRANDIVIDE_0043(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							}else if("44".equals(item_id)) { //스마트콘 header
								String allItem = new String (b,"MS949");
								logger.info("all tran data [" + allItem +  "]");		
								int ret = CM_TRANDIVIDE_0044(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}	
							}else if("45".equals(item_id)) { //스마트콘 detail	
								int ret = CM_TRANDIVIDE_0045(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							}else if("46".equals(item_id)) { //청호 이지 캐시백
								String allItem1 = new String (b,"MS949");
								logger.info("all tran data [" + allItem1 +  "]");		
								int ret = CM_TRANDIVIDE_0046(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							}else if("47".equals(item_id)) { //캐시백 사후출금
								String allItem1 = new String (b,"MS949");
								logger.info("all tran data [" + allItem1 +  "]");		
								int ret = CM_TRANDIVIDE_0047(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							}else if("17".equals(item_id)) { // call "CM_TRANDIVIDE_0070"	neo0531 캐시백 공동망 현금ic 구매 
								logger.info("TranDivideDAO ::: Item_id ["+item_id+"] START");
								int ret = CM_TRANDIVIDE_0017(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}	
							}else if("48".equals(item_id)) { //아동급식카드
								String allItem1 = new String (b,"MS949");
								logger.info("all tran data [" + allItem1 +  "]");		
								int ret = CM_TRANDIVIDE_0048(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							}else if("49".equals(item_id)) { //관계사 식대
								String allItem1 = new String (b,"MS949");
								logger.info("all tran data [" + allItem1 +  "]");		
								int ret = CM_TRANDIVIDE_0049(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("50".equals(item_id)) { // call "CM_TRANDIVIDE_0050"
								int ret = CM_TRANDIVIDE_0050(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("51".equals(item_id)) { // call "CM_TRANDIVIDE_0051"
								int ret = CM_TRANDIVIDE_0051(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("52".equals(item_id)) { // call "CM_TRANDIVIDE_0052"
								int ret = CM_TRANDIVIDE_0052(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("53".equals(item_id)) { // call "CM_TRANDIVIDE_0053"
								//for 현금영수증
								String tran_type = tran_data.substring(10,11);
								String org_tran_ymd  = tran_data.substring(63,71);
								String org_pos_no = tran_data.substring(71,75);
								String org_tran_no = tran_data.substring(75,79);	
								
								logger.info("tran_type:"+tran_type+":");		
								logger.info("org_tran_ymd:"+org_tran_ymd+":");
								logger.info("org_pos_no:"+org_pos_no+":");
								logger.info("org_tran_no:"+org_tran_no+":");
								

								int ret = CM_TRANDIVIDE_0053(sql, loop_num, data, item, sys_ymd, cLog, tran_type, org_tran_ymd, org_pos_no, org_tran_no);
								
								//ori code int ret = CM_TRANDIVIDE_0053(sql, loop_num, data, item, sys_ymd, cLog, tran_type , org_pos_no , org_tran_no);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("54".equals(item_id)) { // call "CM_TRANDIVIDE_0054"
								int ret = CM_TRANDIVIDE_0054(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("55".equals(item_id)) { // call "CM_TRANDIVIDE_0055"
								int ret = CM_TRANDIVIDE_0055(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("56".equals(item_id)) { // call "CM_TRANDIVIDE_0056"
								int ret = CM_TRANDIVIDE_0056(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("57".equals(item_id)) { // call "CM_TRANDIVIDE_0057"
								int ret = CM_TRANDIVIDE_0057(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("15".equals(item_id)) { // call "CM_TRANDIVIDE_0015" //20170829 한진택배서비스추가 KSN
								int ret = CM_TRANDIVIDE_0015(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("58".equals(item_id)) { // call "CM_TRANDIVIDE_0058" SSGPAY 간편결제
								int ret = CM_TRANDIVIDE_0058(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("59".equals(item_id)) { // call "CM_TRANDIVIDE_0059"
								int ret = CM_TRANDIVIDE_0059(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("64".equals(item_id)) { // call "CM_TRANDIVIDE_0064" 20170828 알리페이결제수단추가_LYH
								int ret = CM_TRANDIVIDE_0064(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("65".equals(item_id)) { // call "CM_TRANDIVIDE_0065"
								int ret = CM_TRANDIVIDE_0065(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("67".equals(item_id)) { // call "CM_TRANDIVIDE_0067"	DGB Upay 충전
								int ret = CM_TRANDIVIDE_0067(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}	
							} else if("68".equals(item_id)) { // call "CM_TRANDIVIDE_0068"	DGB Upay 지불
								int ret = CM_TRANDIVIDE_0068(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}	
							} else if("69".equals(item_id)) { // call "CM_TRANDIVIDE_0069"	상시10%할인
								logger.info("TranDivideDAO ::: Item_id ["+item_id+"] START");
								int ret = CM_TRANDIVIDE_0069(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}	
								
							} else if("71".equals(item_id)) { // SPC  캐시비 매출 56-> 71
								int ret = CM_TRANDIVIDE_0071(sql, loop_num, data, item, sys_ymd, cLog);
								//int ret = CM_TRANDIVIDE_0056(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else if("81".equals(item_id)) { // call "CM_TRANDIVIDE_0081"	SSG CON
								logger.info("TranDivideDAO ::: Item_id ["+item_id+"] START");
								int ret = CM_TRANDIVIDE_0081(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}	
							} else if("82".equals(item_id)) { // call "CM_TRANDIVIDE_0082"	ECON MASTER
								logger.info("TranDivideDAO ::: Item_id ["+item_id+"] START");
								int ret = CM_TRANDIVIDE_0082(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}	
							} else if("83".equals(item_id)) { // call "CM_TRANDIVIDE_0083"	ECON TRAN
								logger.info("TranDivideDAO ::: Item_id ["+item_id+"] START");
								int ret = CM_TRANDIVIDE_0083(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}	
							} else if("84".equals(item_id)) { // call "CM_TRANDIVIDE_0084"	한진 송수하인 정보
								logger.info("TranDivideDAO ::: Item_id [" + item_id + "] START");
								int ret = CM_TRANDIVIDE_0084(sql, loop_num, data, item, sys_ymd, cLog);
								if (ret == 99) {
									result = "PK";
									break;
								} else if (ret != 0) {
									result = "9";
									break;
								}
							} else if("87".equals(item_id)) { // call "CM_TRANDIVIDE_0087"	모바일 문화 상품권 호출
								logger.info("TranDivideDAO ::: Item_id [" + item_id + "] START");
								int ret = CM_TRANDIVIDE_0087(sql, loop_num, data, item, sys_ymd, cLog);
								if (ret == 99) {
									result = "PK";
									break;
								} else if (ret != 0) {
									result = "9";
									break;
								}
							}else if("88".equals(item_id)) { // call "CM_TRANDIVIDE_0088" 카카오페이
								
								logger.info("-------------------TranDivideDAO ::: Item_id [" + item_id + "] START");
								
								int ret = CM_TRANDIVIDE_0088(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) { 
									result = "9";
									break;
								}
							}else if("92".equals(item_id)) { // call "CM_TRANDIVIDE_0092"
								int ret = CM_TRANDIVIDE_0092(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							}else if("93".equals(item_id)) { // call "CM_TRANDIVIDE_0093" 원바코드
								int ret = CM_TRANDIVIDE_0093(sql, loop_num, data, item, sys_ymd, cLog);
								if(ret == 99) {
									result = "PK";
									break;
								} else if(ret != 0) {
									result = "9";
									break;
								}
							} else {
								// 지정되지 않은 전문
								procErrLog("tranDivideModule", "CM_TRANDIVIDE_00", "TRAN DATA ITEM ID UNKNOWN.. item_id="+item_id, data, cLog);
								result = "9";
								break;
							}                                            
						}
						
					// CM_TRANDIVIDE_10
					} else if("10".equals(procNO)) {
						if("00".equals(item_id)) { // call "CM_TRANDIVIDE_2000"
							int ret = CM_TRANDIVIDE_2000(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("01".equals(item_id)) { // call "CM_TRANDIVIDE_2001"
							int ret = CM_TRANDIVIDE_2001(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						}/*else {
							// 지정되지 않은 전문
							procErrLog("tranDivideModule", "CM_TRANDIVIDE_10", "TRAN DATA ITEM ID UNKNOWN.. item_id="+item_id, data, cLog);
							result = "9";
							break;
						}*/
						
					// CM_TRANDIVIDE_20
					} else if("20".equals(procNO)) {
						if("00".equals(item_id)) { // call "CM_TRANDIVIDE_2000"
							int ret = CM_TRANDIVIDE_2000(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("01".equals(item_id)) { // call "CM_TRANDIVIDE_2001"
							int ret = CM_TRANDIVIDE_2001(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						}/*else {
							// 지정되지 않은 전문
							procErrLog("tranDivideModule", "CM_TRANDIVIDE_20", "TRAN DATA ITEM ID UNKNOWN.. item_id="+item_id, data, cLog);
							result = "9";
							break;
						}*/
						// CM_TRANDIVIDE_40
					} else if("40".equals(procNO)) {
						if("00".equals(item_id)) { // call "CM_TRANDIVIDE_0000"
							int ret = CM_TRANDIVIDE_0000(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("01".equals(item_id)) { // call "CM_TRANDIVIDE_4001"
							int ret = CM_TRANDIVIDE_4001(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("20".equals(item_id)) { // call "CM_TRANDIVIDE_0020"
							int ret = CM_TRANDIVIDE_0020(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						}
						
					// CM_TRANDIVIDE_60	
					} else if("60".equals(procNO)) {
						if("00".equals(item_id)) { // call "CM_TRANDIVIDE_0000"
							int ret = CM_TRANDIVIDE_0000(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("60".equals(item_id) || "61".equals(item_id) ||
								  "62".equals(item_id) || "63".equals(item_id)) { // call "CM_TRANDIVIDE_6060"
							int ret = CM_TRANDIVIDE_6060(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else {
							// 지정되지 않은 전문
							procErrLog("tranDivideModule", "CM_TRANDIVIDE_60", "TRAN DATA ITEM ID UNKNOWN.. item_id="+item_id, data, cLog);
							result = "9";
							break;
						}
						
					// CM_TRANDIVIDE_70
					} else if("70".equals(procNO)) {
						if("00".equals(item_id)) { // call "CM_TRANDIVIDE_0000"
							int ret = CM_TRANDIVIDE_0000(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("70".equals(item_id) || "71".equals(item_id) ||
								  "72".equals(item_id) || "73".equals(item_id)) { // call "CM_TRANDIVIDE_7070"
							int ret = CM_TRANDIVIDE_7070(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("74".equals(item_id)) { // call "CM_TRANDIVIDE_7074"
							int ret = CM_TRANDIVIDE_7074(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("75".equals(item_id)) { // call "CM_TRANDIVIDE_7075"
							int ret = CM_TRANDIVIDE_7075(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("76".equals(item_id)) { // call "CM_TRANDIVIDE_7076"
							int ret = CM_TRANDIVIDE_7076(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("77".equals(item_id)) { // call "CM_TRANDIVIDE_7077"
							int ret = CM_TRANDIVIDE_7077(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if(("78".equals(item_id))||("81".equals(item_id))) { // call "CM_TRANDIVIDE_7076"
							int ret = CM_TRANDIVIDE_7076(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("79".equals(item_id)) { // 시재 확인
							result = "1";
						} else {
							// 지정되지 않은 전문
							procErrLog("tranDivideModule", "CM_TRANDIVIDE_70", "TRAN DATA ITEM ID UNKNOWN.. item_id="+item_id, data, cLog);
							result = "9";
							break;
						}
						
					// CM_TRANDIVIDE_80	
					} else if("80".equals(procNO)) {
						if("00".equals(item_id)) { // call "CM_TRANDIVIDE_0000"
							int ret = CM_TRANDIVIDE_0000(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("80".equals(item_id)) { // call "CM_TRANDIVIDE_8080"
							int ret = CM_TRANDIVIDE_8080(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else {
							// 지정되지 않은 전문
							procErrLog("tranDivideModule", "CM_TRANDIVIDE_80", "TRAN DATA ITEM ID UNKNOWN.. item_id="+item_id, data, cLog);
							result = "9";
							break;
						}
						
					// CM_TRANDIVIDE_90	
					} else if("90".equals(procNO)) {
						if("00".equals(item_id)) { // call "CM_TRANDIVIDE_0000"
							int ret = CM_TRANDIVIDE_0000(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("91".equals(item_id)) { // call "CM_TRANDIVIDE_9091"
							int ret = CM_TRANDIVIDE_9091(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else if("99".equals(item_id)) { // call "CM_TRANDIVIDE_9099"
							int ret = CM_TRANDIVIDE_9099(sql, loop_num, data, item, sys_ymd, cLog);
							if(ret == 99) {
								result = "PK";
								break;
							} else if(ret != 0) {
								result = "9";
								break;
							}
						} else {
							// 지정되지 않은 전문
							procErrLog("tranDivideModule", "CM_TRANDIVIDE_90", "TRAN DATA ITEM ID UNKNOWN.. item_id="+item_id, data, cLog);
							result = "9";
							break;
						}
					
					// 처리 할 수 없는 전문
					} else {
						result = "9";
						break;
					}
				} // END while 
				
			}
		} catch(Exception e) {
			result = "9";
			//rollback();
			logger.info("[ERROR] Exception : " + e);
		} finally {
			if(!"1".equals(result)) {
				rollback();
			}
			end();
			updTranDivide00Flag(result, data, cLog);
			updTranDivideFlag(result, data, cLog);
			//logger.info("---------- [END] SP_TRANDIVIDE ----------");
			//cLog.close("END [SP_TRANDIVIDE on Module Log]", "[SUCCESS]");
		}
	}
	
	public int CM_TRANDIVIDE_0000(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		String sql_debug2 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0000", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0000"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TRAN_TYPE"));		// TRAN_TYPE
				sql.setString(7, item_data.get("PMOD_YN")); 		// PMOD_YN
				sql.setString(8, item_data.get("STOP_YN")); 		// STOP_YN
				sql.setString(9, item_data.get("TRAN_KIND")); 		// TRAN_KIND
				sql.setString(10, item_data.get("SYS_YMDHMS")); 	// SYS_YMDHMS
				
				sql.setString(11, item_data.get("OP_NO")); 			// OP_NO
				sql.setString(12, item_data.get("ORG_TRAN_YMD"));	// ORG_TRAN_YMD
				sql.setString(13, item_data.get("ORG_POS_NO")); 	// ORG_POS_NO
				sql.setString(14, item_data.get("ORG_TRAN_NO")); 	// ORG_TRAN_NO
				sql.setString(15, item_data.get("ORG_STORE_CD")); 	// ORG_STORE_CD
				
				sql.setString(16, item_data.get("ORG_RES_ID")); 	// ORG_RES_ID
				sql.setString(17, item_data.get("APP_OP_NO")); 		// APP_OP_NO
				sql.setString(18, item_data.get("CUST_CLS_ID")); 	// CUST_CLS_ID
				sql.setString(19, item_data.get("CUST_COUNT")); 	// CUST_COUNT
				sql.setString(20, item_data.get("ORDER_TYPE")); 	// ORDER_TYPE
				
				sql.setString(21, item_data.get("FLOOR_CD")); 		// FLOOR_CD
				sql.setString(22, item_data.get("TABLE_NO")); 		// TABLE_NO
				sql.setString(23, item_data.get("GSALE_AMT")); 		// GSALE_AMT
				sql.setString(24, item_data.get("GDC_AMT")); 		// GDC_AMT
				sql.setString(25, item_data.get("NSALE_AMT")); 		// NSALE_AMT
				
				sql.setString(26, item_data.get("SCHARGE_AMT")); 	// SCHARGE_AMT
				sql.setString(27, item_data.get("DRAWER_CD")); 		// DRAWER_CD
				boolean rfnd_flag = false;
				if("1".equals((String)data.get("tran_type")) && !"".equals(item_data.get("ORG_TRAN_YMD").trim()) && item_data.get("ORG_TRAN_YMD") != null && item_data.get("ORG_TRAN_YMD").trim().length() == 8) {
					rfnd_flag = true;
					sql.setString(28, "1"); // RFND_YN
				} else {
					sql.setString(28, ""); // RFND_YN
				}
				sql.setString(29, item_data.get("SYS_YMDHMS")); 	// SYS_YMDHMS
				sql.setString(30, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0000", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				if(rfnd_flag) {
					if(sql != null) {			
						sql.close();
					}
					sql.put(findQuery("tran-divide", "UPD_RFND_YN_STTRP110DT"));
					sql.setString(1, item_data.get("ORG_TRAN_YMD"));
					sql.setString(2, (String)data.get("com_cd"));
					sql.setString(3, item_data.get("ORG_STORE_CD"));
					sql.setString(4, item_data.get("ORG_POS_NO"));
					sql.setString(5, item_data.get("ORG_TRAN_NO"));
					sql_debug2 = sql.debug(); // SQL debug
					executeUpdate(sql);
				}
				/*
				logger.info("[SQL DEBUG 1] " + sql_debug1);
				if("".equals(sql_debug2) && sql_debug2 != null) {
					logger.info("[SQL DEBUG 2] " + sql_debug2);
				}
				*/
			} else {
				procErrLog("CM_TRANDIVIDE_0000", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0000", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0000", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if("".equals(sql_debug2) && sql_debug2 != null) {
				//logger.info("[SQL DEBUG 2] " + sql_debug2);
			}
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0000_CANCEL(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		String sql_debug2 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0000", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0000_CANCEL"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TRAN_TYPE"));		// TRAN_TYPE
				sql.setString(7, item_data.get("PMOD_YN")); 		// PMOD_YN
				sql.setString(8, item_data.get("STOP_YN")); 		// STOP_YN
				sql.setString(9, item_data.get("TRAN_KIND")); 		// TRAN_KIND
				sql.setString(10, item_data.get("SYS_YMDHMS")); 	// SYS_YMDHMS
				
				sql.setString(11, item_data.get("OP_NO")); 			// OP_NO
				sql.setString(12, item_data.get("ORG_TRAN_YMD"));	// ORG_TRAN_YMD
				sql.setString(13, item_data.get("ORG_POS_NO")); 	// ORG_POS_NO
				sql.setString(14, item_data.get("ORG_TRAN_NO")); 	// ORG_TRAN_NO
				sql.setString(15, item_data.get("ORG_STORE_CD")); 	// ORG_STORE_CD
				
				sql.setString(16, item_data.get("ORG_RES_ID")); 	// ORG_RES_ID
				sql.setString(17, item_data.get("APP_OP_NO")); 		// APP_OP_NO
				sql.setString(18, item_data.get("CUST_CLS_ID")); 	// CUST_CLS_ID
				sql.setString(19, item_data.get("CUST_COUNT")); 	// CUST_COUNT
				sql.setString(20, item_data.get("ORDER_TYPE")); 	// ORDER_TYPE
				
				sql.setString(21, item_data.get("FLOOR_CD")); 		// FLOOR_CD
				sql.setString(22, item_data.get("TABLE_NO")); 		// TABLE_NO
				sql.setString(23, item_data.get("GSALE_AMT")); 		// GSALE_AMT
				sql.setString(24, item_data.get("GDC_AMT")); 		// GDC_AMT
				sql.setString(25, item_data.get("NSALE_AMT")); 		// NSALE_AMT
				
				sql.setString(26, item_data.get("SCHARGE_AMT")); 	// SCHARGE_AMT
				sql.setString(27, item_data.get("DRAWER_CD")); 		// DRAWER_CD
				boolean rfnd_flag = false;
				if("1".equals((String)data.get("tran_type")) && !"".equals(item_data.get("ORG_TRAN_YMD").trim()) && item_data.get("ORG_TRAN_YMD") != null && item_data.get("ORG_TRAN_YMD").trim().length() == 8) {
					rfnd_flag = true;
					sql.setString(28, "1"); // RFND_YN
				} else {
					sql.setString(28, ""); // RFND_YN
				}
				sql.setString(29, item_data.get("SYS_YMDHMS")); 	// SYS_YMDHMS
				sql.setString(30, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0000", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				if(rfnd_flag) {
					if(sql != null) {			
						sql.close();
					}
					sql.put(findQuery("tran-divide", "UPD_RFND_YN_STTRP110DT"));
					sql.setString(1, item_data.get("ORG_TRAN_YMD"));
					sql.setString(2, (String)data.get("com_cd"));
					sql.setString(3, item_data.get("ORG_STORE_CD"));
					sql.setString(4, item_data.get("ORG_POS_NO"));
					sql.setString(5, item_data.get("ORG_TRAN_NO"));
					sql_debug2 = sql.debug(); // SQL debug
					executeUpdate(sql);
				}
				/*
				logger.info("[SQL DEBUG 1] " + sql_debug1);
				if("".equals(sql_debug2) && sql_debug2 != null) {
					logger.info("[SQL DEBUG 2] " + sql_debug2);
				}
				*/
			} else {
				procErrLog("CM_TRANDIVIDE_0000", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0000", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0000", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if("".equals(sql_debug2) && sql_debug2 != null) {
				//logger.info("[SQL DEBUG 2] " + sql_debug2);
			}
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0001(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data = null;
		try{
			String chk = item.substring(0, 5);
			
			if(chk.equals("00466")){ //20170615 SSGPAY 상시할인/PLCC 추가
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0001_RENEW", item, cLog);
				
			}else if(chk.equals("00445")){ //add STAFFDC field
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0001_NEW", item, cLog);
				
				//20170615 SSGPAY 상시할인/PLCC 추가 KSN START
				item_data.put("APP_PAY_DC_ID", "");
				item_data.put("APP_PAY_DC_QTY", "");
				item_data.put("APP_PAY_DC_AMT", "");
				//20170615 SSGPAY 상시할인/PLCC 추가 KSN END
			}else{
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0001", item, cLog);

				item_data.put("STAFF_DC_ID", "");   // STAFF_DC_ID     
				item_data.put("STAFF_DC_QTY", "");  // STAFF_DC_QTY    
				item_data.put("STAFF_DC_AMT", "");  // STAFF_DC_AMT  
				
				//20170615 SSGPAY 상시할인/PLCC 추가 KSN START
				item_data.put("APP_PAY_DC_ID", ""); 
				item_data.put("APP_PAY_DC_QTY", "");
				item_data.put("APP_PAY_DC_AMT", "");
				//20170615 SSGPAY 상시할인/PLCC 추가 KSN END
			}
			
				if(item_data != null) {
					if(sql != null) {
						sql.close();
					}
					sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0001"));
					sql.setString(1, sys_ymd);
					sql.setString(2, (String)data.get("com_cd"));
					sql.setString(3, (String)data.get("store_cd"));
					sql.setString(4, (String)data.get("pos_no"));
					sql.setString(5, (String)data.get("tran_no"));
					
					sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
					sql.setString(7, item_data.get("ASGN_CANCEL_YN")); 		// ASGN_CANCEL_YN
					sql.setString(8, item_data.get("ITEM_CD")); 		// ITEM_CD
					sql.setString(9, item_data.get("PLU_CD")); 		// PLU_CD
					sql.setString(10, item_data.get("PLU_FLAG")); 	// PLU_FLAG
					
					sql.setString(11, item_data.get("CATE_ID")); 			// CATE_ID
					sql.setString(12, item_data.get("GRP_ID"));	// GRP_ID
					sql.setString(13, item_data.get("SGRP_ID")); 	// SGRP_ID
					sql.setString(14, item_data.get("BRAND_ID")); 	// BRAND_ID
					sql.setString(15, item_data.get("ITEM_ID")); 	// ITEM_ID
					                  
					sql.setString(16, item_data.get("ITEM_NM")); 	// ITEM_NM
					sql.setString(17, item_data.get("SALE_QTY")); 		// SALE_QTY
					sql.setString(18, item_data.get("SALE_UPRC")); 	// SALE_UPRC
					sql.setString(19, item_data.get("SALE_AMT")); 	// SALE_AMT
					sql.setString(20, item_data.get("PRICE_CHG_ID")); 	// PRICE_CHG_ID
					                  
					sql.setString(21, item_data.get("PRICE_CHG_UPRC")); 		// PRICE_CHG_UPRC
					sql.setString(22, item_data.get("ITEM_INPUT_ID")); 		// ITEM_INPUT_ID
					sql.setString(23, item_data.get("SCAN_CD")); 		// SCAN_CD
					sql.setString(24, item_data.get("BTL_SUM_AMT")); 		// BTL_SUM_AMT
					sql.setString(25, item_data.get("BTL_PLU_CD")); 		// BTL_PLU_CD
					                  
					sql.setString(26, item_data.get("ITEM_TAX_ID")); 	// ITEM_TAX_ID
					sql.setString(27, item_data.get("ITEM_TAX_VALUE")); 		// ITEM_TAX_VALUE
					sql.setString(28, item_data.get("RECT_AMT")); 		// RECT_AMT
					sql.setString(29, item_data.get("POS_DC_ID")); 		// POS_DC_ID
					sql.setString(30, item_data.get("POS_DC_RATE")); 		// POS_DC_RATE
					                  
					sql.setString(31, item_data.get("POS_DC_AMT")); 		// POS_DC_AMT
					sql.setString(32, item_data.get("EVT_DC_QTY")); 		// EVT_DC_QTY
					sql.setString(33, item_data.get("EVT_DC_AMT")); 		// EVT_DC_AMT
					sql.setString(34, item_data.get("CO_DC_ID")); 		// CO_DC_ID
					sql.setString(35, item_data.get("CO_DC_QTY")); 		// CO_DC_QTY
					                  
					sql.setString(36, item_data.get("CO_DC_AMT")); 		// CO_DC_AMT
					sql.setString(37, item_data.get("SALE_UNIT_QTY")); 		// SALE_UNIT_QTY
					sql.setString(38, item_data.get("DISUSE_FLAG")); 		// DISUSE_FLAG
					sql.setString(39, item_data.get("SCRAP_RES_ID")); 		// SCRAP_RES_ID
					sql.setString(40, item_data.get("SERVICE_FLAG")); 		// SERVICE_FLAG
					                  
					sql.setString(41, item_data.get("PACK_FLAG")); 		// PACK_FLAG
					sql.setString(42, item_data.get("DBUYING_FLAG")); 		// DBUYING_FLAG
					sql.setString(43, item_data.get("REASON_ID")); 		// REASON_ID
					sql.setString(44, item_data.get("SALES_TYPE")); 		// SALES_TYPE
					                  
					sql.setString(45, item_data.get("EVT_CARD_TY")); 		// EVT_CARD_TY
					sql.setString(46, item_data.get("EVT_CARD_QTY")); 		// EVT_CARD_QTY
					sql.setString(47, item_data.get("EVT_CARD_AMT")); 		// EVT_CARD_AMT
					                  
					sql.setString(48, item_data.get("STAFF_DC_ID")); 		// STAFF_DC_ID
					sql.setString(49, item_data.get("STAFF_DC_QTY")); 		// STAFF_DC_QTY
					sql.setString(50, item_data.get("STAFF_DC_AMT")); 		// STAFF_DC_AMT
					
					//20170615 SSGPAY 상시할인/PLCC 추가 START
					sql.setString(51, item_data.get("APP_PAY_DC_ID"));	//APP_PAY_DC_ID
					sql.setString(52, item_data.get("APP_PAY_DC_QTY"));	//APP_PAY_DC_QTY
					sql.setString(53, item_data.get("APP_PAY_DC_AMT"));	//APP_PAY_DC_AMT
					//20170615 SSGPAY 상시할인/PLCC 추가 END
					
					sql.setString(54, (String)data.get("tran_ymd"));
					
					logger.info("TranDivideDAO ::: CM_TRANDIVIDE_0001 ::: tran_ymd ::: "+(String)data.get("tran_ymd"));
					
					sql_debug1 = sql.debug(); // SQL debug
					int sql_ret = executeUpdate(sql);
					
					logger.info("TranDivideDAO ::: CM_TRANDIVIDE_0001 ::: sql_ret ["+sql_ret+"]");
					if(sql_ret != 1) {
						ret = 9;
						procErrLog("CM_TRANDIVIDE_0001_selStaff", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
						logger.info("TranDivideDAO ::: CM_TRANDIVIDE_0001 ::: err sql_debug ["+sql_debug1+"]");
					}
					logger.info("TranDivideDAO ::: CM_TRANDIVIDE_0001 ::: sql_debug ["+sql_debug1+"]");
				}else {
					procErrLog("CM_TRANDIVIDE_0001", "loop_num:"+loop_num, "item_data => null", data, cLog);
					ret = 9;
				}

		}catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0001", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			
			logger.info("TranDivideDAO ::: CM_TRANDIVIDE_0001 ::: SQLException ["+se.getMessage()+"]");
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0001", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("TranDivideDAO ::: CM_TRANDIVIDE_0001 ::: Exception ["+e.getMessage()+"]");
			logger.info("sql["+sql_debug1+"]");
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		logger.info("TranDivideDAO ::: CM_TRANDIVIDE_0001 ::: ret ["+ret+"]");
		logger.info("TranDivideDAO ::: CM_TRANDIVIDE_0001 ::: END");
		return ret;
	}
	
	public int CM_TRANDIVIDE_0001_CANCEL(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data = null;
		
		try {
			String chk = item.substring(0, 5);
			if(chk.equals("00445")){
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0001_NEW", item, cLog);
			}else{
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0001", item, cLog);

				item_data.put("STAFF_DC_ID", "");   // STAFF_DC_ID     
				item_data.put("STAFF_DC_QTY", "");  // STAFF_DC_QTY    
				item_data.put("STAFF_DC_AMT", "");  // STAFF_DC_AMT  
			}
			
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0001_CANCEL"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("ASGN_CANCEL_YN")); 		// ASGN_CANCEL_YN
				sql.setString(8, item_data.get("ITEM_CD")); 		// ITEM_CD
				sql.setString(9, item_data.get("PLU_CD")); 			// PLU_CD
				sql.setString(10, item_data.get("PLU_FLAG")); 		// PLU_FLAG
				                  
				sql.setString(11, item_data.get("CATE_ID")); 			// CATE_ID
				sql.setString(12, item_data.get("GRP_ID"));		// GRP_ID
				sql.setString(13, item_data.get("SGRP_ID")); 	// SGRP_ID
				sql.setString(14, item_data.get("BRAND_ID")); 	// BRAND_ID
				sql.setString(15, item_data.get("ITEM_ID")); 	// ITEM_ID
				                  
				sql.setString(16, item_data.get("ITEM_NM")); 	// ITEM_NM
				sql.setString(17, item_data.get("SALE_QTY")); 	// SALE_QTY
				sql.setString(18, item_data.get("SALE_UPRC")); 	// SALE_UPRC
				sql.setString(19, item_data.get("SALE_AMT")); 	// SALE_AMT
				sql.setString(20, item_data.get("PRICE_CHG_ID")); 	// PRICE_CHG_ID
				                  
				sql.setString(21, item_data.get("PRICE_CHG_UPRC")); 		// PRICE_CHG_UPRC
				sql.setString(22, item_data.get("ITEM_INPUT_ID")); 		// ITEM_INPUT_ID
				sql.setString(23, item_data.get("SCAN_CD")); 			// SCAN_CD
				sql.setString(24, item_data.get("BTL_SUM_AMT")); 		// BTL_SUM_AMT
				sql.setString(25, item_data.get("BTL_PLU_CD")); 		// BTL_PLU_CD
				                  
				sql.setString(26, item_data.get("ITEM_TAX_ID")); 	// ITEM_TAX_ID
				sql.setString(27, item_data.get("ITEM_TAX_VALUE")); 	// ITEM_TAX_VALUE
				sql.setString(28, item_data.get("RECT_AMT")); 		// RECT_AMT
				sql.setString(29, item_data.get("POS_DC_ID")); 		// POS_DC_ID
				sql.setString(30, item_data.get("POS_DC_RATE")); 		// POS_DC_RATE
				                  
				sql.setString(31, item_data.get("POS_DC_AMT")); 		// POS_DC_AMT
				sql.setString(32, item_data.get("EVT_DC_QTY")); 		// EVT_DC_QTY
				sql.setString(33, item_data.get("EVT_DC_AMT")); 		// EVT_DC_AMT
				sql.setString(34, item_data.get("CO_DC_ID")); 		// CO_DC_ID
				sql.setString(35, item_data.get("CO_DC_QTY")); 		// CO_DC_QTY
				                  
				sql.setString(36, item_data.get("CO_DC_AMT")); 		// CO_DC_AMT
				sql.setString(37, item_data.get("SALE_UNIT_QTY")); 		// SALE_UNIT_QTY
				sql.setString(38, item_data.get("DISUSE_FLAG")); 		// DISUSE_FLAG
				sql.setString(39, item_data.get("SCRAP_RES_ID")); 		// SCRAP_RES_ID
				sql.setString(40, item_data.get("SERVICE_FLAG")); 		// SERVICE_FLAG
				                  
				sql.setString(41, item_data.get("PACK_FLAG")); 		// PACK_FLAG
				sql.setString(42, item_data.get("DBUYING_FLAG")); 		// DBUYING_FLAG
				sql.setString(43, item_data.get("REASON_ID")); 		// REASON_ID
				sql.setString(44, item_data.get("SALES_TYPE")); 		// SALES_TYPE
				                  
				sql.setString(45, item_data.get("EVT_CARD_TY")); 		// EVT_CARD_TY
				sql.setString(46, item_data.get("EVT_CARD_QTY")); 		// EVT_CARD_QTY
				sql.setString(47, item_data.get("EVT_CARD_AMT")); 		// EVT_CARD_AMT
				                  
				sql.setString(48, item_data.get("STAFF_DC_ID")); 		// STAFF_DC_ID
				sql.setString(49, item_data.get("STAFF_DC_QTY")); 		// STAFF_DC_QTY
				sql.setString(50, item_data.get("STAFF_DC_AMT")); 		// STAFF_DC_AMT
				
				
				
				sql.setString(51, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0001", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
			}else {
				procErrLog("CM_TRANDIVIDE_0001", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0001", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0001", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	//20170208 STAFFDC
	public int CM_TRANDIVIDE_0018(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0018", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				int i = 1 ;
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0018"));
				
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				sql.setString(i++, (String)data.get("tran_no"));
				
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));      	// V_ITEM_SEQ                     
				sql.setString(i++, item_data.get("SEND_UNIQ_NO"));      // V_SEND_UNIQ_NO                 
				sql.setString(i++, item_data.get("TRAN_TYPE"));      	// V_TRAN_TYPE                    
				sql.setString(i++, item_data.get("GIFT_CARD_NO"));      // V_GIFT_CARD_NO                 
				sql.setString(i++, item_data.get("SPECIAL_GUBUN"));     // V_SPECIAL_GUBUN     
                           
				sql.setString(i++, item_data.get("USE_GUBUN"));      	// V_USE_GUBUN		             
				sql.setString(i++, item_data.get("GOODS_GUBUN"));     	// V_GOODS_GUBUN	                 
				sql.setString(i++, item_data.get("PART_GUBUN"));     	// V_PART_GUBUN	                 
				sql.setString(i++, item_data.get("REQ_AMT"));      		// V_REQ_AMT		                 
				sql.setString(i++, item_data.get("PAY_AMT"));      		// V_PAY_AMT		
				
				sql.setString(i++, item_data.get("REMAIN_AMT"));     	// V_REMAIN_AMT	                 
				sql.setString(i++, item_data.get("AUTH_DATE"));      	// V_AUTH_DATE		             
				sql.setString(i++, item_data.get("AUTH_TIME"));      	// V_AUTH_TIME		             
				sql.setString(i++, item_data.get("AUTH_NO"));      		// V_AUTH_NO		                 
				sql.setString(i++, item_data.get("ORG_SALE_DATE"));     // V_ORG_SALE_DATE	
                  
				sql.setString(i++, item_data.get("ORG_ST_CODE"));       // V_ORG_ST_CODE	                 
				sql.setString(i++, item_data.get("ORG_TM_NO"));      	// V_ORG_TM_NO		             
				sql.setString(i++, item_data.get("ORG_TRAN_NO"));       // V_ORG_TRAN_NO	                 
				sql.setString(i++, item_data.get("ORG_SEND_UNIQ_NO"));  // V_ORG_SEND_UNIQ_NO             
				sql.setString(i++, item_data.get("ORG_AUTH_DATE"));     // V_ORG_AUTH_DATE  
                  
				sql.setString(i++, item_data.get("ORG_AUTH_NO"));       // V_ORG_AUTH_NO	                 
				sql.setString(i++, item_data.get("IRT_NOMAL_TP"));      // V_IRT_NOMAL_TP	                   
				sql.setString(i++, (String)data.get("tran_ymd"));   	// V_SYS_YMD 

//				logger.info("sql[" + sql + "] ");
//				logger.info("sql.toString()[" + sql.toString() + "] ");
//				logger.info("sql.debug()[" + sql.debug() + "] ");
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0018", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
			} else {
				procErrLog("CM_TRANDIVIDE_0018", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			
			procErrLog("CM_TRANDIVIDE_0018", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0018", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	//20170208 STAFFDC
	public int CM_TRANDIVIDE_0019(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0019", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				int i = 1 ;
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0019"));
				
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				sql.setString(i++, (String)data.get("tran_no"));
				
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(i++, item_data.get("COMP_CD"));
				sql.setString(i++, item_data.get("EMPLOYEE_NO"));
				sql.setString(i++, item_data.get("PAY_AMT"));
				sql.setString(i++, item_data.get("USE_AMT"));
				
				sql.setString(i++, item_data.get("APPR_TYPE"));
				sql.setString(i++, item_data.get("REQ_TRANNO"));
				sql.setString(i++, item_data.get("APPLY_GUBUN"));
				sql.setString(i++, item_data.get("ORG_POS_NO"));
				sql.setString(i++, item_data.get("ORG_TRAN_DATE"));
				
				sql.setString(i++, item_data.get("ORG_TRAN_NO"));
				sql.setString(i++, item_data.get("REG_DATETIME"));
				sql.setString(i++, item_data.get("IRT_NORMAL_TP"));
				sql.setString(i++, (String)data.get("tran_ymd"));

//				logger.info("sql[" + sql + "] ");
//				logger.info("sql.toString()[" + sql.toString() + "] ");
//				logger.info("sql.debug()[" + sql.debug() + "] ");
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0019", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				if(item_data.get("IRT_NORMAL_TP") == "1"){

					// sql 초기화
					sql.close();
					i = 0;
					
					sql.put(findQuery("tran-divide", "UPD_STAFF_DISCOUNT_HIST"));
					sql.setString(++i, "1");										// 요청구분 0:승인요청 1:취소 2:망취소
					sql.setString(++i, "CM_TRANDIVIDE_0019"); // 등록/수정자 ID
					sql.setString(++i, sys_ymd);              				        // 거래일시
					sql.setString(++i, (String)data.get("com_cd")); 				// 회사코드
					sql.setString(++i, item_data.get("COMP_CD"));                   // 소속사코드
					sql.setString(++i, item_data.get("EMPLOYEE_NO"));               // 사번
					sql.setString(++i, item_data.get("REQ_TRANNO"));                // 거래요청번호
					
					int rows = executeUpdate(sql);
					if(rows!=1){
						procErrLog("CM_TRANDIVIDE_0019", "loop_num:"+loop_num, "item_data => null", data, cLog);
						ret = 9;				
					}
				}//logger.info("[SQL DEBUG 1] " + sql_debug1);
			} else {
				procErrLog("CM_TRANDIVIDE_0019", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			
			procErrLog("CM_TRANDIVIDE_0019", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0019", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0020(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0020", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0020"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("RECV_AMT")); 		// RECV_AMT
				sql.setString(8, item_data.get("PAY_AMT")); 		// PAY_AMT
				sql.setString(9, item_data.get("CHG_AMT")); 		// CHG_AMT
				sql.setString(10, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0020", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0020", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0020", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0020", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0021(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data;
		try {
			logger.info("item.getBytes().length [" + item.getBytes().length + "]");
			logger.info( "item.getBytes().length [" + item.getBytes().length + "]");
			if(item.getBytes().length == 326){
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0021_NEW", item, cLog);
			}else if(item.getBytes().length == 301){
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0021", item, cLog);
				item_data.put("CARD_BUY_CD", "0");
				item_data.put("VAN_TID", "0");
			}else{
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0021_OLD", item, cLog);
				item_data.put("CARD_KIND", "0");
			}

			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0021"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("PAY_AMT")); 		// PAY_AMT
				sql.setString(8, item_data.get("CARD_INPUT_ID")); 		// CARD_INPUT_ID
				sql.setString(9, item_data.get("CARD_DATA_VISIBLE")); 		// CARD_DATA
				sql.setString(10, item_data.get("CARD_DATA")); 		//CARD_DATA_ENCODED
				
				sql.setString(11, item_data.get("INSTMNT_PRD"));		// INSTMNT_PRD
				sql.setString(12, item_data.get("AGREE_ID")); 		// AGREE_ID
				sql.setString(13, item_data.get("AGREE_NO")); 		// AGREE_NO
				sql.setString(14, item_data.get("AGREE_YMDHMS")); 		// AGREE_YMDHMS
				sql.setString(15, item_data.get("CARD_CORP_CD"));		// CARD_CORP_CD
				
				sql.setString(16, item_data.get("CARD_CORP_NM"));		// CARD_CORP_NM
				sql.setString(17, item_data.get("FRIEND_NO")); 		// FRIEND_NO
				sql.setString(18, item_data.get("ORG_YMD")); 		// ORG_YMD
				sql.setString(19, item_data.get("ORG_AGREE_NO")); 		// ORG_AGREE_NO
				sql.setString(20, item_data.get("SERVICE_AMT")); 		// SERVICE_AMT

				sql.setString(21, (String)data.get("tran_ymd"));
				sql.setString(22, item_data.get("CARD_KIND"));  // CUP_YN 0:일반카드,  1:은련카드,  3:BCPAY
				sql.setString(23, item_data.get("CARD_BUY_CD")); //매입사코드  
				sql.setString(24, item_data.get("VAN_TID"));  //VAN사 TID
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0021", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0021", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0021", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0021", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0022(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0022", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0022"));
				sql.setString(1, (String)data.get("tran_ymd"));
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID")); 		// TR_ITEM_ID
				sql.setString(8, item_data.get("TENDER_AMT")); 		// TENDER_AMT
				sql.setString(9, item_data.get("DC_AMT")); 		// DC_AMT
				sql.setString(10, item_data.get("TENDER_VALUE1")); 		//TENDER_VALUE1
				
				sql.setString(11, item_data.get("TENDER_VALUE2"));		// TENDER_VALUE2
				sql.setString(12, item_data.get("TENDER_VALUE3")); 		// TENDER_VALUE3
				sql.setString(13, item_data.get("TENDER_VALUE4")); 		// TENDER_VALUE4
				sql.setString(14, item_data.get("TENDER_DATA1")); 		// TENDER_DATA1
				sql.setString(15, item_data.get("TENDER_DATA2"));		// TENDER_DATA2
				
				sql.setString(16, item_data.get("TENDER_DATA3"));		// TENDER_DATA3
				sql.setString(17, item_data.get("TENDER_DATA4")); 		// TENDER_DATA4
				sql.setString(18, item_data.get("TENDER_DATA5")); 		// TENDER_DATA5
				sql.setString(19, item_data.get("TENDER_DATA6")); 		// TENDER_DATA6
				sql.setString(20, item_data.get("TENDER_DATA7")); 		// TENDER_DATA7
				
				sql.setString(21, item_data.get("TENDER_DATA8"));		// TENDER_DATA8
				sql.setString(22, item_data.get("TENDER_DATA9")); 		// TENDER_DATA9
				sql.setString(23, item_data.get("TENDER_DATA10")); 		// TENDER_DATA10
				sql.setString(24, item_data.get("TENDER_DATA11")); 		// TENDER_DATA11
				sql.setString(25, item_data.get("TENDER_DATA12")); 		// TENDER_DATA12

				sql.setString(26, item_data.get("TENDER_DATA13"));		// TENDER_DATA13
				sql.setString(27, item_data.get("TENDER_DATA14")); 		// TENDER_DATA14
				sql.setString(28, item_data.get("TENDER_DATA15")); 		// TENDER_DATA15
				sql.setString(29, item_data.get("TENDER_DATA16")); 		// TENDER_DATA16
				sql.setString(30, item_data.get("TENDER_DATA99")); 		// TENDER_DATA99

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0022", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0022", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0022", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0022", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0023(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0023", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0023"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID")); 		// TR_ITEM_ID
				sql.setString(8, item_data.get("TENDER_AMT")); 		// TENDER_AMT
				sql.setString(9, item_data.get("DC_AMT")); 		// DC_AMT
				sql.setString(10, item_data.get("TENDER_VALUE1")); 		//TENDER_VALUE1
				
				sql.setString(11, item_data.get("TENDER_VALUE2"));		// TENDER_VALUE2
				sql.setString(12, item_data.get("TENDER_VALUE3")); 		// TENDER_VALUE3
				sql.setString(13, item_data.get("TENDER_VALUE4")); 		// TENDER_VALUE4
				sql.setString(14, item_data.get("TENDER_DATA1")); 		// TENDER_DATA1
				sql.setString(15, item_data.get("TENDER_DATA2"));		// TENDER_DATA2
				
				sql.setString(16, item_data.get("TENDER_DATA3"));		// TENDER_DATA3
				sql.setString(17, item_data.get("TENDER_DATA4")); 		// TENDER_DATA4
				sql.setString(18, item_data.get("TENDER_DATA5")); 		// TENDER_DATA5
				sql.setString(19, item_data.get("TENDER_DATA6")); 		// TENDER_DATA6
				sql.setString(20, item_data.get("TENDER_DATA7")); 		// TENDER_DATA7
				
				sql.setString(21, item_data.get("TENDER_DATA8"));		// TENDER_DATA8
				sql.setString(22, item_data.get("TENDER_DATA9")); 		// TENDER_DATA9
				sql.setString(23, item_data.get("TENDER_DATA10")); 		// TENDER_DATA10
				sql.setString(24, item_data.get("TENDER_DATA11")); 		// TENDER_DATA11
				sql.setString(25, item_data.get("TENDER_DATA12")); 		// TENDER_DATA12

				sql.setString(26, item_data.get("TENDER_DATA13"));		// TENDER_DATA13
				sql.setString(27, item_data.get("TENDER_DATA14")); 		// TENDER_DATA14
				sql.setString(28, item_data.get("TENDER_DATA15")); 		// TENDER_DATA15
				sql.setString(29, item_data.get("TENDER_DATA16")); 		// TENDER_DATA16
				sql.setString(30, item_data.get("TENDER_DATA99")); 		// TENDER_DATA99
				
				sql.setString(31, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0023", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0023", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0023", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0023", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0024(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0024", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0024"));
				sql.setString(1, (String)data.get("tran_ymd"));
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID")); 		// TR_ITEM_ID
				sql.setString(8, item_data.get("TENDER_AMT")); 		// TENDER_AMT
				sql.setString(9, item_data.get("DC_AMT")); 		// DC_AMT
				sql.setString(10, item_data.get("TENDER_VALUE1")); 		//TENDER_VALUE1
				
				sql.setString(11, item_data.get("TENDER_VALUE2"));		// TENDER_VALUE2
				sql.setString(12, item_data.get("TENDER_VALUE3")); 		// TENDER_VALUE3
				sql.setString(13, item_data.get("TENDER_VALUE4")); 		// TENDER_VALUE4
				sql.setString(14, item_data.get("TENDER_DATA1")); 		// TENDER_DATA1
				sql.setString(15, item_data.get("TENDER_DATA2"));		// TENDER_DATA2
				
				sql.setString(16, item_data.get("TENDER_DATA3"));		// TENDER_DATA3
				sql.setString(17, item_data.get("TENDER_DATA4")); 		// TENDER_DATA4
				sql.setString(18, item_data.get("TENDER_DATA5")); 		// TENDER_DATA5
				sql.setString(19, item_data.get("TENDER_DATA6")); 		// TENDER_DATA6
				sql.setString(20, item_data.get("TENDER_DATA7")); 		// TENDER_DATA7
				
				sql.setString(21, item_data.get("TENDER_DATA8"));		// TENDER_DATA8
				sql.setString(22, item_data.get("TENDER_DATA9")); 		// TENDER_DATA9
				sql.setString(23, item_data.get("TENDER_DATA10")); 		// TENDER_DATA10
				sql.setString(24, item_data.get("TENDER_DATA11")); 		// TENDER_DATA11
				sql.setString(25, item_data.get("TENDER_DATA12")); 		// TENDER_DATA12

				sql.setString(26, item_data.get("TENDER_DATA13"));		// TENDER_DATA13
				sql.setString(27, item_data.get("TENDER_DATA14")); 		// TENDER_DATA14
				sql.setString(28, item_data.get("TENDER_DATA15")); 		// TENDER_DATA15
				sql.setString(29, item_data.get("TENDER_DATA16")); 		// TENDER_DATA16
				sql.setString(30, item_data.get("TENDER_DATA99")); 		// TENDER_DATA99
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0024", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0024", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0024", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0024", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0025(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0025", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0025"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID")); 		// TR_ITEM_ID
				sql.setString(8, item_data.get("TENDER_AMT")); 		// TENDER_AMT
				sql.setString(9, item_data.get("DC_AMT")); 		// DC_AMT
				sql.setString(10, item_data.get("TENDER_VALUE1")); 		//TENDER_VALUE1
				
				sql.setString(11, item_data.get("TENDER_VALUE2"));		// TENDER_VALUE2
				sql.setString(12, item_data.get("TENDER_VALUE3")); 		// TENDER_VALUE3
				sql.setString(13, item_data.get("TENDER_VALUE4")); 		// TENDER_VALUE4
				sql.setString(14, item_data.get("TENDER_DATA1")); 		// TENDER_DATA1
				sql.setString(15, item_data.get("TENDER_DATA2"));		// TENDER_DATA2
				
				sql.setString(16, item_data.get("TENDER_DATA3"));		// TENDER_DATA3
				sql.setString(17, item_data.get("TENDER_DATA4")); 		// TENDER_DATA4
				sql.setString(18, item_data.get("TENDER_DATA5")); 		// TENDER_DATA5
				sql.setString(19, item_data.get("TENDER_DATA6")); 		// TENDER_DATA6
				sql.setString(20, item_data.get("TENDER_DATA7")); 		// TENDER_DATA7
				
				sql.setString(21, item_data.get("TENDER_DATA8"));		// TENDER_DATA8
				sql.setString(22, item_data.get("TENDER_DATA9")); 		// TENDER_DATA9
				sql.setString(23, item_data.get("TENDER_DATA10")); 		// TENDER_DATA10
				sql.setString(24, item_data.get("TENDER_DATA11")); 		// TENDER_DATA11
				sql.setString(25, item_data.get("TENDER_DATA12")); 		// TENDER_DATA12

				sql.setString(26, item_data.get("TENDER_DATA13"));		// TENDER_DATA13
				sql.setString(27, item_data.get("TENDER_DATA14")); 		// TENDER_DATA14
				sql.setString(28, item_data.get("TENDER_DATA15")); 		// TENDER_DATA15
				sql.setString(29, item_data.get("TENDER_DATA16")); 		// TENDER_DATA16
				sql.setString(30, item_data.get("TENDER_DATA99")); 		// TENDER_DATA99
				
				sql.setString(31, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0025", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0025", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0025", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0025", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0026(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0026", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0026"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID")); 		// TR_ITEM_ID
				sql.setString(8, item_data.get("TENDER_AMT")); 		// TENDER_AMT
				sql.setString(9, item_data.get("DC_AMT")); 		// DC_AMT
				sql.setString(10, item_data.get("TENDER_VALUE1")); 		//TENDER_VALUE1
				
				sql.setString(11, item_data.get("TENDER_VALUE2"));		// TENDER_VALUE2
				sql.setString(12, item_data.get("TENDER_VALUE3")); 		// TENDER_VALUE3
				sql.setString(13, item_data.get("TENDER_VALUE4")); 		// TENDER_VALUE4
				sql.setString(14, item_data.get("TENDER_DATA1")); 		// TENDER_DATA1
				sql.setString(15, item_data.get("TENDER_DATA2"));		// TENDER_DATA2
				
				sql.setString(16, item_data.get("TENDER_DATA3"));		// TENDER_DATA3
				sql.setString(17, item_data.get("TENDER_DATA4")); 		// TENDER_DATA4
				sql.setString(18, item_data.get("TENDER_DATA5")); 		// TENDER_DATA5
				sql.setString(19, item_data.get("TENDER_DATA6")); 		// TENDER_DATA6
				sql.setString(20, item_data.get("TENDER_DATA7")); 		// TENDER_DATA7
				
				sql.setString(21, item_data.get("TENDER_DATA8"));		// TENDER_DATA8
				sql.setString(22, item_data.get("TENDER_DATA9")); 		// TENDER_DATA9
				sql.setString(23, item_data.get("TENDER_DATA10")); 		// TENDER_DATA10
				sql.setString(24, item_data.get("TENDER_DATA11")); 		// TENDER_DATA11
				sql.setString(25, item_data.get("TENDER_DATA12")); 		// TENDER_DATA12

				sql.setString(26, item_data.get("TENDER_DATA13"));		// TENDER_DATA13
				sql.setString(27, item_data.get("TENDER_DATA14")); 		// TENDER_DATA14
				sql.setString(28, item_data.get("TENDER_DATA15")); 		// TENDER_DATA15
				sql.setString(29, item_data.get("TENDER_DATA16")); 		// TENDER_DATA16
				sql.setString(30, item_data.get("TENDER_DATA99")); 		// TENDER_DATA99
				
				sql.setString(31, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0026", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0026", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0026", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0026", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0027(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0027", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0027"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID")); 		// TR_ITEM_ID
				sql.setString(8, item_data.get("TENDER_AMT")); 		// TENDER_AMT
				sql.setString(9, item_data.get("DC_AMT")); 		// DC_AMT
				sql.setString(10, item_data.get("TENDER_VALUE1")); 		//TENDER_VALUE1
				
				sql.setString(11, item_data.get("TENDER_VALUE2"));		// TENDER_VALUE2
				sql.setString(12, item_data.get("TENDER_VALUE3")); 		// TENDER_VALUE3
				sql.setString(13, item_data.get("TENDER_VALUE4")); 		// TENDER_VALUE4
				sql.setString(14, item_data.get("TENDER_DATA1")); 		// TENDER_DATA1
				sql.setString(15, item_data.get("TENDER_DATA2"));		// TENDER_DATA2
				
				sql.setString(16, item_data.get("TENDER_DATA3"));		// TENDER_DATA3
				sql.setString(17, item_data.get("TENDER_DATA4")); 		// TENDER_DATA4
				sql.setString(18, item_data.get("TENDER_DATA5")); 		// TENDER_DATA5
				sql.setString(19, item_data.get("TENDER_DATA6")); 		// TENDER_DATA6
				sql.setString(20, item_data.get("TENDER_DATA7")); 		// TENDER_DATA7
				
				sql.setString(21, item_data.get("TENDER_DATA8"));		// TENDER_DATA8
				sql.setString(22, item_data.get("TENDER_DATA9")); 		// TENDER_DATA9
				sql.setString(23, item_data.get("TENDER_DATA9")); 		// TENDER_DATA9
				sql.setString(24, item_data.get("TENDER_DATA10")); 		// TENDER_DATA10
				sql.setString(25, item_data.get("TENDER_DATA11")); 		// TENDER_DATA11
				
				sql.setString(26, item_data.get("TENDER_DATA12")); 		// TENDER_DATA12
				sql.setString(27, item_data.get("TENDER_DATA13"));		// TENDER_DATA13
				sql.setString(28, item_data.get("TENDER_DATA14")); 		// TENDER_DATA14
				sql.setString(29, item_data.get("TENDER_DATA15")); 		// TENDER_DATA15
				sql.setString(30, item_data.get("TENDER_DATA16")); 		// TENDER_DATA16
				
				sql.setString(31, item_data.get("TENDER_DATA99")); 		// TENDER_DATA99
				sql.setString(32, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0027", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0027", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0027", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0027", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0028(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0028", item, cLog);
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0028"));
				int i = 1 ;
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, item_data.get("TRANSACTION_ID"));		// TRANSACTION_ID
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				
				sql.setString(i++, (String)data.get("tran_no"));
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(i++, item_data.get("MEMBER_ID"));		// MEMBER_ID
				sql.setString(i++, item_data.get("TERMINAL_ID"));		// TERMINAL_ID
				sql.setString(i++, item_data.get("PSAM_ID"));		// PSAM_ID
				
				sql.setString(i++, item_data.get("PSAM_DEAL_SNO"));		// PSAM_DEAL_SNO
				sql.setString(i++, item_data.get("CARD_NO")); 		// CARD_NO
				sql.setString(i++, card_key); 		// CARD_NO
				sql.setString(i++, double_card_key); 		// CARD_NO
				sql.setString(i++, item_data.get("CARD_DEAL_SNO")); 		// CARD_DEAL_SNO
				sql.setString(i++, item_data.get("WORK_ID")); 		// WORK_ID
				sql.setString(i++, item_data.get("DEAL_BEF_RAMT")); 		// DEAL_BEF_RAMT
				
				sql.setString(i++, item_data.get("DEAL_REQ_AMT"));		// DEAL_REQ_AMT
				sql.setString(i++, item_data.get("DEAL_AFT_RAMT")); 		// DEAL_AFT_RAMT
				sql.setString(i++, item_data.get("DEAL_YMDHMS")); 		// DEAL_YMDHMS
				sql.setString(i++, item_data.get("ALGM_ID")); 		// ALGM_ID
				sql.setString(i++, item_data.get("CDEAL_KEY_VER")); 		// CDEAL_KEY_VER
				
				sql.setString(i++, item_data.get("ECASH_ID"));		// ECASH_ID
				sql.setString(i++, item_data.get("PSAM_TOTAMTDEAL_CNT")); 		// PSAM_TOTAMTDEAL_CNT
				sql.setString(i++, item_data.get("PSAM_CDEAL_CNT")); 		// PSAM_CDEAL_CNT
				sql.setString(i++, item_data.get("PSAM_DEAL_SUM_AMT")); 		// PSAM_DEAL_SUM_AMT
				sql.setString(i++, item_data.get("SIGN_VAL")); 		// SIGN_VAL
				
				sql.setString(i++, item_data.get("CARD_TYPE"));		// CARD_TYPE
				sql.setString(i++, item_data.get("CARD_OWNER_ID")); 		// CARD_OWNER_ID
				sql.setString(i++, item_data.get("RES_CD")); 		// RES_CD
				sql.setString(i++, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0028", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0028", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0028", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0028", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0029(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0029", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0029"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID")); 		// TR_ITEM_ID
				sql.setString(8, item_data.get("TENDER_AMT")); 		// TENDER_AMT
				sql.setString(9, item_data.get("DC_AMT")); 		// DC_AMT
				sql.setString(10, item_data.get("TENDER_VALUE1")); 		//TENDER_VALUE1
				
				sql.setString(11, item_data.get("TENDER_VALUE2"));		// TENDER_VALUE2
				sql.setString(12, item_data.get("TENDER_VALUE3")); 		// TENDER_VALUE3
				sql.setString(13, item_data.get("TENDER_VALUE4")); 		// TENDER_VALUE4
				sql.setString(14, item_data.get("TENDER_DATA1")); 		// TENDER_DATA1
				sql.setString(15, item_data.get("TENDER_DATA2"));		// TENDER_DATA2
				
				sql.setString(16, item_data.get("TENDER_DATA3"));		// TENDER_DATA3
				sql.setString(17, item_data.get("TENDER_DATA4")); 		// TENDER_DATA4
				sql.setString(18, item_data.get("TENDER_DATA5")); 		// TENDER_DATA5
				sql.setString(19, item_data.get("TENDER_DATA6")); 		// TENDER_DATA6
				sql.setString(20, item_data.get("TENDER_DATA7")); 		// TENDER_DATA7
				
				sql.setString(21, item_data.get("TENDER_DATA8"));		// TENDER_DATA8
				sql.setString(22, item_data.get("TENDER_DATA9")); 		// TENDER_DATA9
				sql.setString(23, item_data.get("TENDER_DATA10")); 		// TENDER_DATA10
				sql.setString(24, item_data.get("TENDER_DATA11")); 		// TENDER_DATA11
				sql.setString(25, item_data.get("TENDER_DATA12")); 		// TENDER_DATA12

				sql.setString(26, item_data.get("TENDER_DATA13"));		// TENDER_DATA13
				sql.setString(27, item_data.get("TENDER_DATA14")); 		// TENDER_DATA14
				sql.setString(28, item_data.get("TENDER_DATA15")); 		// TENDER_DATA15
				sql.setString(29, item_data.get("TENDER_DATA16")); 		// TENDER_DATA16
				sql.setString(30, item_data.get("TENDER_DATA99")); 		// TENDER_DATA99
				
				sql.setString(31, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0029", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0029", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0029", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0029", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0030(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0030", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0030"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("SEND_UNIQ_NO")); 		// SEND_UNIQ_NO
				sql.setString(8, item_data.get("CARD_NO_ENCODED")); 		// CARD_NO_ENCODED
				sql.setString(9, item_data.get("CARD_NO_VISIBLE")); 		// CARD_NO_VISIBLE
				sql.setString(10, item_data.get("CONFIRM_NO")); 		// CONFIRM_NO
				
				sql.setString(11, item_data.get("GIFT_CODE"));		// GIFT_CODE
				sql.setString(12, item_data.get("PAY_AMT")); 		// PAY_AMT
				sql.setString(13, item_data.get("REMAIN_AMT")); 		// REMAIN_AMT
				sql.setString(14, item_data.get("SEND_DATE")); 		// SEND_DATE
				sql.setString(15, item_data.get("AUTH_DATE"));		// AUTH_DATE
				
				sql.setString(16, item_data.get("AUTH_TIME"));		// AUTH_TIME
				sql.setString(17, item_data.get("AUTH_NO")); 		// AUTH_NO
				sql.setString(18, item_data.get("ORG_SEND_DATE")); 		// ORG_SEND_DATE
				sql.setString(19, item_data.get("ORG_AUTH_DATE")); 		// ORG_AUTH_DATE
				sql.setString(20, item_data.get("ORG_AUTH_NO")); 		// ORG_AUTH_NO
				
				sql.setString(21, item_data.get("ORG_SEND_UNIQ_NO"));		// ORG_SEND_UNIQ_NO
				sql.setString(22, item_data.get("DELEGATE_BARCODE_NO")); 		// DELEGATE_BARCODE_NO
				sql.setString(23, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0030", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0030", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0030", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0030", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0031(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0031", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0031"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("SERVICE_ID"));		
				sql.setString(8, item_data.get("WORK_ID"));			
				sql.setString(9, item_data.get("BARCODE_NO"));		
				sql.setString(10, item_data.get("BARCODE_NO_EN"));	
				sql.setString(11, item_data.get("INPUT_TY"));		
				sql.setString(12, item_data.get("APPROVAL_NO"));		
				sql.setString(13, item_data.get("COLLECT_CHECK"));	
				sql.setString(14, item_data.get("COLLECT_MOBILE"));	
				sql.setString(15, item_data.get("USED_BRANCH_CD"));	
				sql.setString(16, item_data.get("USED_DATE"));		
				sql.setString(17, item_data.get("USED_TIME"));		
				sql.setString(18, item_data.get("OLD_APPROVAL_NO"));	
				sql.setString(19, item_data.get("OLD_APPROVAL_DT"));	
				sql.setString(20, item_data.get("TOT_ITEM_ROWS"));	
				sql.setString(21, item_data.get("PRODUCT_BARCODE"));	
				sql.setString(22, item_data.get("PRODUCT_QTY"));		
				sql.setString(23, item_data.get("PRODUCT_COST"));	
				sql.setString(24, item_data.get("PARTNER_AMT"));		
				sql.setString(25, item_data.get("SUPPLY_AMT"));		
				sql.setString(26, item_data.get("COUPON_TOT_AMT"));	
				sql.setString(27, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0031", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0031", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0031", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0031", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0032(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0032", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0032"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID")); 		// TR_ITEM_ID
				sql.setString(8, item_data.get("TENDER_AMT")); 		// TENDER_AMT
				sql.setString(9, item_data.get("DC_AMT")); 		// DC_AMT
				sql.setString(10, item_data.get("TENDER_VALUE1")); 		//TENDER_VALUE1
				
				sql.setString(11, item_data.get("TENDER_VALUE2"));		// TENDER_VALUE2
				sql.setString(12, item_data.get("TENDER_VALUE3")); 		// TENDER_VALUE3
				sql.setString(13, item_data.get("TENDER_VALUE4")); 		// TENDER_VALUE4
				sql.setString(14, item_data.get("TENDER_DATA1")); 		// TENDER_DATA1
				sql.setString(15, item_data.get("TENDER_DATA2"));		// TENDER_DATA2
				
				sql.setString(16, item_data.get("TENDER_DATA3"));		// TENDER_DATA3
				sql.setString(17, item_data.get("TENDER_DATA4")); 		// TENDER_DATA4
				sql.setString(18, item_data.get("TENDER_DATA5")); 		// TENDER_DATA5
				sql.setString(19, item_data.get("TENDER_DATA6")); 		// TENDER_DATA6
				sql.setString(20, item_data.get("TENDER_DATA7")); 		// TENDER_DATA7
				
				sql.setString(21, item_data.get("TENDER_DATA8"));		// TENDER_DATA8
				sql.setString(22, item_data.get("TENDER_DATA9")); 		// TENDER_DATA9
				sql.setString(23, item_data.get("TENDER_DATA10")); 		// TENDER_DATA10
				sql.setString(24, item_data.get("TENDER_DATA11")); 		// TENDER_DATA11
				sql.setString(25, item_data.get("TENDER_DATA12")); 		// TENDER_DATA12

				sql.setString(26, item_data.get("TENDER_DATA13"));		// TENDER_DATA13
				sql.setString(27, item_data.get("TENDER_DATA14")); 		// TENDER_DATA14
				sql.setString(28, item_data.get("TENDER_DATA15")); 		// TENDER_DATA15
				sql.setString(29, item_data.get("TENDER_DATA16")); 		// TENDER_DATA16
				sql.setString(30, item_data.get("TENDER_DATA99")); 		// TENDER_DATA99
				
				sql.setString(31, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0032", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0032", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0032", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0032", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0033(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0033", item, cLog);
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0033"));
				int i = 1 ;
				sql.setString(i++, (String)data.get("com_cd")); 
				sql.setString(i++, item_data.get("DEAL_UNIQ_NO"));		// ITEM_SEQ
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				sql.setString(i++, (String)data.get("tran_no"));
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(i++, item_data.get("DAT_CMD")); 		// TENDER_AMT
				sql.setString(i++, item_data.get("CO_REG_NO"));   
				sql.setString(i++, item_data.get("CARD_TP"));     
				sql.setString(i++, item_data.get("DEAL_YMDHMS")); 
				sql.setString(i++, item_data.get("TERMINAL_ID")); 
				sql.setString(i++, item_data.get("PAY_BEF_RAMT"));
				sql.setString(i++, item_data.get("PAY_REQ_AMT")); 
				sql.setString(i++, item_data.get("PAY_AFT_RAMT"));
				sql.setString(i++, item_data.get("DEAL_AMT"));    
				sql.setString(i++, item_data.get("TYPE_EP"));     
				sql.setString(i++, item_data.get("ALG_EP"));      
				sql.setString(i++, item_data.get("VK_IND2_KEY")); 
				sql.setString(i++, item_data.get("TRT_SAM"));     
				sql.setString(i++, item_data.get("VK_IND_KEY"));  
				sql.setString(i++, item_data.get("ID_CENTER"));   
				sql.setString(i++, item_data.get("ID_EP"));    
				sql.setString(i++, card_key);    
				sql.setString(i++, double_card_key);       
				sql.setString(i++, item_data.get("NT_EP"));       
				sql.setString(i++, item_data.get("ID_SAM"));      
				sql.setString(i++, item_data.get("NT_SAM"));      
				sql.setString(i++, item_data.get("NC_SAM"));      
				sql.setString(i++, item_data.get("NI_SAM"));      
				sql.setString(i++, item_data.get("TOT_SAM"));     
				sql.setString(i++, item_data.get("SIGN_IND"));    
				sql.setString(i++, item_data.get("SIGN_IND2"));   
				sql.setString(i++, item_data.get("PENALTY_AMT"));
				sql.setString(i++, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0033", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0033", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0033", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0033", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0034(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0034", item, cLog);
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0034"));
				int i = 1;
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, item_data.get("TRAN_ID"));
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				
				sql.setString(i++, (String)data.get("tran_no"));
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(i++, item_data.get("DAT_CMD"));
				sql.setString(i++, item_data.get("DEAL_BRANCH_CD"));   
				sql.setString(i++, item_data.get("CARD_DIS_CD"));   
				
				sql.setString(i++, item_data.get("CARD_OWNER_CD")); 
				sql.setString(i++, item_data.get("DEAL_YMDHMS")); 
				sql.setString(i++, item_data.get("TERMINAL_ID"));
				sql.setString(i++, item_data.get("DEAL_BEF_RAMT")); 
				sql.setString(i++, item_data.get("DEAL_REQ_AMT"));
				
				sql.setString(i++, item_data.get("DEAL_AFT_RAMT"));   
				sql.setString(i++, item_data.get("DEAL_REQ_AMT"));
				sql.setString(i++, item_data.get("PUBCO_ID"));      
				sql.setString(i++, item_data.get("DEAL_TP")); 
				sql.setString(i++, item_data.get("ALGO_ID"));   
				
				sql.setString(i++, item_data.get("KEYSET_VER"));  
				sql.setString(i++, item_data.get("ELEC_MNY_ID"));   
				sql.setString(i++, item_data.get("CARD_NO"));       
				sql.setString(i++, card_key);       
				sql.setString(i++, double_card_key);       
				sql.setString(i++, item_data.get("CARD_DEAL_SEQ_NO"));       
				sql.setString(i++, item_data.get("SAM_ID"));  
				
				sql.setString(i++, item_data.get("SAM_DEAL_SEQ_NO"));      
				sql.setString(i++, item_data.get("SAM_TOT_AMT_COL_NO"));      
				sql.setString(i++, item_data.get("SAM_SPY_TRN_COL_CNT"));      
				sql.setString(i++, item_data.get("SAM_ACC_TRN_TOT_AMT"));     
				sql.setString(i++, item_data.get("SIGN_IND"));  
				
				sql.setString(i++, item_data.get("FEE"));   
				sql.setString(i++, item_data.get("ALIAS_NO"));
				sql.setString(i++, item_data.get("CARDPLSTS_YN"));
				sql.setString(i++, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0034", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0034", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0034", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0034", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0035(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0035", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0035"));
				sql.setString(1, (String)data.get("store_cd"));
				sql.setString(2, item_data.get("V_PARCEL_CD"));	
				sql.setString(3, (String)data.get("com_cd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0035", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0035", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0035", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0035", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0036(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0036", item, cLog);
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0036"));
				int i =1;
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, item_data.get("TRAN_ID"));
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				
				sql.setString(i++, (String)data.get("tran_no"));
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(i++, item_data.get("DAT_CMD"));
				sql.setString(i++, item_data.get("PAYMENT_TP"));   
				sql.setString(i++, item_data.get("WORK_ID"));   
				
				sql.setString(i++, item_data.get("DEAL_BRANCH_CD")); 
				sql.setString(i++, item_data.get("TERMINAL_ID")); 
				sql.setString(i++, item_data.get("CHRG_BEF_RAMT"));
				sql.setString(i++, item_data.get("CHRG_REQ_AMT")); 
				sql.setString(i++, item_data.get("CHRG_AFT_RAMT"));

				sql.setString(i++, item_data.get("CARD_NO"));   
				sql.setString(i++, card_key);   
				sql.setString(i++, double_card_key);   
				sql.setString(i++, item_data.get("CARD_DEAL_SEQ_NO"));
				sql.setString(i++, item_data.get("RAND_VAL"));      
				sql.setString(i++, item_data.get("SIGN_VAL_1")); 
				sql.setString(i++, item_data.get("LSAM_ID"));   
				
				sql.setString(i++, item_data.get("LSAM_DEAL_SEQ_NO"));  
				sql.setString(i++, item_data.get("SIGN_VAL_2"));   
				sql.setString(i++, item_data.get("CARD_OWNER_TP"));       
				sql.setString(i++, item_data.get("CARD_STS_CD"));       
				sql.setString(i++, item_data.get("TERMINAL_STS_CD"));  
				
				sql.setString(i++, item_data.get("CHRG_FEE"));      
				sql.setString(i++, item_data.get("REFUND_CARD_DEPOSIT"));      
				sql.setString(i++, item_data.get("REFUND_PENALTY_AMT"));      
				sql.setString(i++, item_data.get("CHRG_DEAL_YMDHMS"));     
				sql.setString(i++, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0036", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0036", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0036", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0036", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0037(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0037", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0037"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID")); 		// TR_ITEM_ID
				sql.setString(8, item_data.get("TENDER_AMT")); 		// TENDER_AMT
				sql.setString(9, item_data.get("DC_AMT")); 		// DC_AMT
				sql.setString(10, item_data.get("TENDER_VALUE1")); 		//TENDER_VALUE1
				
				sql.setString(11, item_data.get("TENDER_VALUE2"));		// TENDER_VALUE2
				sql.setString(12, item_data.get("TENDER_VALUE3")); 		// TENDER_VALUE3
				sql.setString(13, item_data.get("TENDER_VALUE4")); 		// TENDER_VALUE4
				sql.setString(14, item_data.get("TENDER_DATA1")); 		// TENDER_DATA1
				sql.setString(15, item_data.get("TENDER_DATA2"));		// TENDER_DATA2
				
				sql.setString(16, item_data.get("TENDER_DATA3"));		// TENDER_DATA3
				sql.setString(17, item_data.get("TENDER_DATA4")); 		// TENDER_DATA4
				sql.setString(18, item_data.get("TENDER_DATA5")); 		// TENDER_DATA5
				sql.setString(19, item_data.get("TENDER_DATA6")); 		// TENDER_DATA6
				sql.setString(20, item_data.get("TENDER_DATA7")); 		// TENDER_DATA7
				
				sql.setString(21, item_data.get("TENDER_DATA8"));		// TENDER_DATA8
				sql.setString(22, item_data.get("TENDER_DATA9")); 		// TENDER_DATA9
				sql.setString(23, item_data.get("TENDER_DATA10")); 		// TENDER_DATA10
				sql.setString(24, item_data.get("TENDER_DATA11")); 		// TENDER_DATA11
				sql.setString(25, item_data.get("TENDER_DATA12")); 		// TENDER_DATA12

				sql.setString(26, item_data.get("TENDER_DATA13"));		// TENDER_DATA13
				sql.setString(27, item_data.get("TENDER_DATA14")); 		// TENDER_DATA14
				sql.setString(28, item_data.get("TENDER_DATA15")); 		// TENDER_DATA15
				sql.setString(29, item_data.get("TENDER_DATA16")); 		// TENDER_DATA16
				sql.setString(30, item_data.get("TENDER_DATA99")); 		// TENDER_DATA99
				
				sql.setString(31, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0037", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0037", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0037", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0037", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0038(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0038", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0038"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, (String)data.get("tran_ymd"));	//SUBSTR(FN_CALC_TOTO_YMD..1, 8)
				sql.setString(8, item_data.get("DATE_DDD"));	//SUBSTR(FN_CALC_TOTO_YMD..1, 8)
				sql.setString(9, item_data.get("TIME_SSSSS"));	//SUBSTR(FN_CALC_TOTO_YMD..1, 8)
				sql.setString(10, (String)data.get("tran_ymd"));	//SUBSTR(FN_CALC_TOTO_YMD..9, 6)
				sql.setString(11, item_data.get("DATE_DDD")); 		//SUBSTR(FN_CALC_TOTO_YMD..9, 6)
				sql.setString(12, item_data.get("TIME_SSSSS")); 	//SUBSTR(FN_CALC_TOTO_YMD..9, 6)
				sql.setString(13, item_data.get("DATE_DDD")); 		
				sql.setString(14, item_data.get("TIME_SSSSS")); 
				sql.setString(15, item_data.get("FCSTR_ID")); 
				
				sql.setString(16, item_data.get("BRANCH_CD")); 
				sql.setString(17, item_data.get("AGENT_CD")); 
				sql.setString(18, item_data.get("PUBER_CD")); 
				sql.setString(19, item_data.get("PAY_TP")); 
				sql.setString(20, item_data.get("CNCL_PAY_TP")); 
				
				sql.setString(21, item_data.get("ITEM_GRP_CD")); 
				sql.setString(22, item_data.get("ITEM_CD")); 
				sql.setString(23, item_data.get("GAME_NTH")); 
				sql.setString(24, item_data.get("PAY_AMT")); 
				sql.setString(25, item_data.get("POS_REG_DTM")); 	
				
				sql.setString(26, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0038", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0038", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0038", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0038", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0039(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0039", item, cLog);
			
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0039"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("V_SEND_UNIQ_NO"));
				sql.setString(8, item_data.get("V_CARD_NO_ENCODED"));
				sql.setString(9, item_data.get("V_CARD_NO_VISIBLE"));
				sql.setString(10, item_data.get("V_CONFIRM_NO"));
				sql.setString(11, item_data.get("V_GIFT_CODE"));
				sql.setString(12, item_data.get("V_SPECIAL_GUBUN"));
				sql.setString(13, item_data.get("V_PAY_TYPE"));
				sql.setString(14, item_data.get("V_PAY_AMT"));
				sql.setString(15, item_data.get("V_REMAIN_AMT"));
				sql.setString(16, item_data.get("V_SEND_DATE"));
				sql.setString(17, item_data.get("V_AUTH_DATE"));
				sql.setString(18, item_data.get("V_AUTH_TIME"));
				sql.setString(19, item_data.get("V_AUTH_NO"));
				sql.setString(20, item_data.get("V_ORG_SEND_DATE"));
				sql.setString(21, item_data.get("V_ORG_AUTH_DATE"));
				sql.setString(22, item_data.get("V_ORG_AUTH_NO"));
				sql.setString(23, item_data.get("V_ORG_SEND_UNIQ_NO"));
				sql.setString(24, item_data.get("V_DELEGATE_BARCODE_NO"));
				sql.setString(25, card_key);
				sql.setString(26, double_card_key);
				sql.setString(27, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0039", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
//				logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0039", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0039", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0039", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0040(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0040", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0040"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("V_SEND_UNIQ_NO"));
				sql.setString(8, item_data.get("V_CARD_NO_ENCODED"));
				sql.setString(9, item_data.get("V_CARD_NO_VISIBLE"));
				sql.setString(10, item_data.get("V_ITEM_TITLE"));
				
				sql.setString(11, item_data.get("V_PAY_CURRENCY"));
				sql.setString(12, item_data.get("V_PAY_KRW_AMOUNT"));
				sql.setString(13, item_data.get("V_SEND_DATE"));
				sql.setString(14, item_data.get("V_AUTH_DATE"));
				sql.setString(15, item_data.get("V_AUTH_TIME"));

				sql.setString(16, item_data.get("V_AUTH_NO"));
				sql.setString(17, item_data.get("V_ORG_SEND_DATE"));
				sql.setString(18, item_data.get("V_ORG_AUTH_DATE"));
				sql.setString(19, item_data.get("V_ORG_AUTH_NO"));
				sql.setString(20, item_data.get("V_ORG_SEND_UNIQ_NO"));
				
				sql.setString(21, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0040", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
//				logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0040", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0040", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0040", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0041(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0041", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0041"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("V_SEND_UNIQ_NO"));
				sql.setString(8, item_data.get("V_CARD_NO_ENCODED"));
				sql.setString(9, item_data.get("V_CARD_NO_VISIBLE"));
				sql.setString(10, item_data.get("V_MD_CODE"));
				
				sql.setString(11, item_data.get("V_TRADE_AMT"));
				sql.setString(12, item_data.get("V_POSA_GUBUN"));
				sql.setString(13, item_data.get("V_AUTH_DATE"));
				sql.setString(14, item_data.get("V_AUTH_TIME"));
				sql.setString(15, item_data.get("V_AUTH_NO"));

				sql.setString(16, item_data.get("V_REMAIN_AMT"));
				sql.setString(17, item_data.get("V_ORG_SEND_DATE"));
				sql.setString(18, item_data.get("V_ORG_AUTH_DATE"));
				sql.setString(19, item_data.get("V_ORG_AUTH_NO"));
				sql.setString(20, item_data.get("V_ORG_SEND_UNIQ_NO"));
				
				sql.setString(21, item_data.get("V_EVENT_AMT"));
				sql.setString(22, item_data.get("V_SALE_AMT"));
				sql.setString(23, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0041", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
//				logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0041", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0041", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0041", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	


	public int CM_TRANDIVIDE_0042(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		
		String sql_debug1 = "";
		//String[] sql_debugG = new String[100]; 
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0042", item, cLog); 			

			if(item_data != null) {
				if(sql != null) {									
					sql.close();					
				}				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0042"));
				
				//20170602 KSN 여권번호암호화 수정
				Seed seed = Seed.getInstance("CBC/PKCS5Padding");
				String keyData = PropertyUtil.findProperty("service-property", "KEY_DATA");
				String ivData = PropertyUtil.findProperty("service-property", "IV_DATA");
				
				String passport_key = PropertyUtil.findProperty("decode-key-property", "PASSPORT_KEY");
				String double_passport_key = PropertyUtil.findProperty("double-decode-key-property", "PASSPORT_KEY");
				String encrypt_passport_num = (String)item_data.get("PASSPORT_NUM_ENCODING").trim();
				String passport_num = "";
				
				if(!"".equals(encrypt_passport_num) && encrypt_passport_num != null){
					seed.setKey(keyData.getBytes());
					seed.setIV(ivData.getBytes());
					BASE64Decoder decoder = new BASE64Decoder();
					
					passport_num = new String(seed.decrypt(decoder.decodeBuffer(encrypt_passport_num)));
				}
				
				int i = 1;
				sql.setString(i++, sys_ymd);								//		
				sql.setString(i++, item_data.get("STORE_CD"));				//STTRP010DT 의 데이터임	
				sql.setString(i++, item_data.get("POS_NO"));				//
				sql.setString(i++, (String)item_data.get("TRAN_NO"));		//	
				sql.setString(i++, (String)data.get("com_cd"));				//

				sql.setString(i++, item_data.get("MCH_SEND_UNIQ_NO"));		// 
				sql.setString(i++, item_data.get("DOCUMENT_CD"));			// 
				sql.setString(i++, item_data.get("BUY_SERIAL_NUM"));		//				
				sql.setString(i++, item_data.get("BUYER_CANCLE_CHECK"));	//			
				sql.setString(i++, item_data.get("TRADE_APPROVAL_NUM"));	//

				sql.setString(i++, (String)item_data.get("SELLER_BUSI_REGIST_NUM"));	// 
				sql.setString(i++, item_data.get("TERMINAL_ID"));			// 
				sql.setString(i++, item_data.get("SELL_TIME")); 			//				
				sql.setString(i++, item_data.get("SELL_SUM_TOTAL"));		//			
				sql.setString(i++, item_data.get("SELL_SUM_MONEY"));		// 15

				sql.setString(i++, item_data.get("REFUND_AMOUNT")); 		// 
				sql.setString(i++, item_data.get("PAYMENT_TYPE"));			//sql.setString(i++, item_data.get("PASSPORT_ENC_YN"));// 
				sql.setString(i++, item_data.get("PASSPORT_NAME")); 		// 
				sql.setString(i++, item_data.get("PASSPORT_NUM"));			//
				sql.setString(i++, passport_num);							//sql.setString(i++, item_data.get("PASSPORT_NUM_ENCODING"));
				sql.setString(i++, passport_key);
				sql.setString(i++, double_passport_key);
			
				sql.setString(i++, item_data.get("PASSPORT_NATION"));		//			
				sql.setString(i++, item_data.get("PASSPORT_SEX"));			// 
				sql.setString(i++, item_data.get("PASSPORT_BIRTH"));		//
				sql.setString(i++, item_data.get("PASSPORT_EXPIRE"));		///*sql.setString(i++, item_data.get("SEQUENCE_COUNT"));*//*sql.setString(i++, item_data.get("RCT_NO"));		*///				
				sql.setString(i++, item_data.get("BEFORE_REFUND_YN"));		//	
				
				sql.setString(i++, item_data.get("PAYMENT_AMOUNT"));		//
				sql.setString(i++, item_data.get("EXPORT_APPROVAL_NUM"));	//
				sql.setString(i++, item_data.get("BEFORE_LIMIT_AMOUNT"));	//
				sql.setString(i++, item_data.get("PLU_CD"));				//
				sql.setString(i++, item_data.get("PLU_NM"));				//
				sql.setString(i++, item_data.get("SALE_QTY"));				//
				
				sql.setString(i++, item_data.get("ORG_APPROVAL_NUM"));		//				
				sql.setString(i++, item_data.get("ORG_SELL_TIME")); 		//
				sql.setString(i++, item_data.get("ORG_SEND_UNIQ_NO"));		//
//				sql.setString(i++, item_data.get("REG_YMDHMS"));			//
//				sql.setString(i++, item_data.get("PROC_ID"));				//
//				
//				sql.setString(i++, item_data.get("PROC_YMDHMS"));			//
//				sql.setString(i++, item_data.get("PROC_PID"));				//
				sql.setString(i++, item_data.get("EXPORT_EXPIRY_DATE"));		
				sql.setString(i++, item_data.get("SCT"));		
				sql.setString(i++, item_data.get("ET"));		
				sql.setString(i++, item_data.get("VAT"));
				sql.setString(i++, item_data.get("TOT_PAY_AMT"));		
	 			
				sql.setString(i++, item_data.get("EXP_AMT"));
				sql.setString(i++, (String)data.get("TRAN_YMD"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0042", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
			} else {
				procErrLog("CM_TRANDIVIDE_0042", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;				
			}
		} catch(SQLException se) {
			logger.error("▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			logger.error("▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0042", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.error("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0042", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			logger.error("[SQL DEBUG 1] " + sql_debug1);
		}

		return ret;
	}
	

	


	public int CM_TRANDIVIDE_0043(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;

		String sql_debug1 = "";
		//String[] sql_debugG = new String[100]; 
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0043", item, cLog); 			
									

			if(item_data != null) {
				if(sql != null) {

					sql.close();					
				}				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0043"));
						
				int i = 1;
				sql.setString(i++, sys_ymd);									
				sql.setString(i++, (String)data.get("STORE_CD"));//STTRP010DT 의 데이터임	
				sql.setString(i++, (String)data.get("POS_NO"));
				sql.setString(i++, (String)data.get("TRAN_NO"));				
				sql.setString(i++, (String)data.get("com_cd"));

				sql.setString(i++, item_data.get("DELEGATE_BARCODE_NO"));		// 
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// 
				sql.setString(i++, item_data.get("DELEGATE_BARCODE_NO_ENCODED"));		//				
				sql.setString(i++, item_data.get("MSG_ID"));	//			
				sql.setString(i++, item_data.get("TRAN_TYPE"));			//

				sql.setString(i++, item_data.get("SALE_DATE"));	// 
				sql.setString(i++, item_data.get("SALE_TIME"));	// 
				sql.setString(i++, item_data.get("BANK_CODE")); 	//				
				sql.setString(i++, item_data.get("BANK_NM"));	//			
				sql.setString(i++, item_data.get("BANK_VAN_FLAG"));	// 
       
				sql.setString(i++, item_data.get("PLATFORM_M_ID")); 		// 
				sql.setString(i++, item_data.get("BANK_ACCOUNT_NO_ENCRPT"));	// /*sql.setString(i++, item_data.get("PASSPORT_ENC_YN"));		*/// 
				sql.setString(i++, item_data.get("BANK_TOT_TRADE_AMT")); 		// 
				sql.setString(i++, item_data.get("BANK_DIS_TRADE_AMT"));		//
				sql.setString(i++, item_data.get("BANK_NET_TRADE_AMT"));		
				
				sql.setString(i++, item_data.get("BANK_AUTH_DATE"));		//			
				sql.setString(i++, item_data.get("BANK_AUTH_TIME"));	// 
				sql.setString(i++, item_data.get("BANK_AUTH_NO"));		//
				sql.setString(i++, item_data.get("ORG_BANK_AUTH_DATE"));		//				/*sql.setString(i++, item_data.get("SEQUENCE_COUNT"));*//*sql.setString(i++, item_data.get("RCT_NO"));		*///				
				sql.setString(i++, item_data.get("ORG_BANK_AUTH_NO"));		//	
          
				sql.setString(i++, item_data.get("CNCL_GUBUN"));		//
				sql.setString(i++, item_data.get("CNCL_USE_YN"));		//
				sql.setString(i++, item_data.get("ORG_DELEGATE_BARCODE"));		//
				sql.setString(i++, item_data.get("ORG_BANK_SUTH_AMT"));		//
				sql.setString(i++, item_data.get("CARD_UNIQ_NO"));
				sql.setString(i++, (String)data.get("TRAN_YMD"));		//				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					//logger.info("[SQL DEBUG 1] " + sql_debug1);
					procErrLog("CM_TRANDIVIDE_0043", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
			} else {
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				procErrLog("CM_TRANDIVIDE_0043", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;				
			}
		} catch(SQLException se) { 		
			
			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0043", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0043", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
  
		return ret;
	}
	
	
	//스마트콘 헤더
	public int CM_TRANDIVIDE_0044(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		
		String sql_debug1 = "";
		//String[] sql_debugG = new String[100]; 
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0044", item, cLog); 			
			logger.info("item of CM_TRANDIVIDE_0044 ["+item+  "]");						

			if(item_data != null) {
				if(sql != null) {									
					sql.close();					
				}				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0044"));
				
				int i = 1;
				sql.setString(i++, (String)data.get("STORE_CD"));
				sql.setString(i++, (String)data.get("POS_NO"));
				sql.setString(i++, (String)data.get("TRAN_NO"));
				sql.setString(i++, sys_ymd);												
				sql.setString(i++, (String)data.get("com_cd"));
				
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));
				sql.setString(i++, item_data.get("COUPON_TOT_AMT"));	//
				sql.setString(i++, item_data.get("COUPON_COUNT"));		//
				sql.setString(i++, (String)data.get("TRAN_YMD"));
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0044", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
			} else {
				procErrLog("CM_TRANDIVIDE_0044", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;				
			}
		} catch(SQLException se) { 											
			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0044", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0044", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}

		return ret;
	}
	//스마트콘 디테일
	public int CM_TRANDIVIDE_0045(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		
		String sql_debug1 = "";

		try {
			String chk = item.substring(0, 5);
			if(chk.equals("00302")){//EVT필드 추가전 길이값 필드 302byte

				Map<String, String> item_data_noEvt = TranDivideUtil.getItemData("TRANDIVIDE_0045_noEvt", item, cLog);
				
				logger.info("item of CM_TRANDIVIDE_0045_noEvt ["+item+  "]");	
				
				if(item_data_noEvt != null) {
					if(sql != null) {									
						sql.close();					
					}

					logger.info("in if");		
					sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0045_noEvt"));
					
					int i = 1;
					sql.setString(i++, (String)data.get("STORE_CD"));
					sql.setString(i++, (String)data.get("POS_NO"));
					sql.setString(i++, (String)data.get("TRAN_NO"));
					sql.setString(i++, sys_ymd);
					sql.setString(i++, (String)data.get("com_cd"));

					sql.setString(i++, item_data_noEvt.get("TR_ITEM_SEQ"));
					sql.setString(i++, item_data_noEvt.get("SERVICE_ID"));
					sql.setString(i++, item_data_noEvt.get("EXCHANGE_ID"));
					sql.setString(i++, item_data_noEvt.get("COUPON_NUM"));
					sql.setString(i++, item_data_noEvt.get("ADMIT_NUM"));

					sql.setString(i++, item_data_noEvt.get("ADMIT_DATE"));
					sql.setString(i++, item_data_noEvt.get("ADMIT_TIME"));
					sql.setString(i++, item_data_noEvt.get("ORG_ADMIT_NUM"));
					sql.setString(i++, item_data_noEvt.get("MANUFACTURE_CODE"));
					sql.setString(i++, item_data_noEvt.get("LARGE_CODE"));
					 
					sql.setString(i++, item_data_noEvt.get("MEDIUM_CODE"));
					sql.setString(i++, item_data_noEvt.get("SMALL_CODE"));
					sql.setString(i++, item_data_noEvt.get("SELL_AMT"));
					sql.setString(i++, item_data_noEvt.get("PRODUCT_BARCODE"));
					sql.setString(i++, item_data_noEvt.get("PRODUCT_COST"));
					
					sql.setString(i++, item_data_noEvt.get("PARTNER_AMT"));
					sql.setString(i++, item_data_noEvt.get("SUPPLY_AMT"));
					sql.setString(i++, item_data_noEvt.get("EVN_PRODUCT_YN"));
					sql.setString(i++, item_data_noEvt.get("EVN_PRODUCT_CNT"));
					sql.setString(i++, item_data_noEvt.get("EVN_PRODUCT_AMT"));
					
					sql.setString(i++, item_data_noEvt.get("COUPON_USED_AMT"));
					sql.setString(i++, item_data_noEvt.get("COUPON_REMAIN_AMT"));
					sql.setString(i++, item_data_noEvt.get("MANAGE_NO")); 
					sql.setString(i++, item_data_noEvt.get("COMMISSION_RATE"));
					sql.setString(i++, item_data_noEvt.get("COMMISSION_AMT"));
					
//					sql.setString(i++, item_data.get("PROC_ID"));
//					sql.setString(i++, item_data.get("PROC_YMDHMS"));
//					sql.setString(i++, item_data.get("PROC_PID"));
					sql.setString(i++, item_data_noEvt.get("STATUS_CODE"));
					sql.setString(i++, item_data_noEvt.get("DISCOUNT_RATE"));
					
					sql.setString(i++, item_data_noEvt.get("DISCOUNT_AMT"));
					sql.setString(i++, item_data_noEvt.get("COUPON_TYPE"));
					sql.setString(i++, (String)data.get("TRAN_YMD"));
					
					sql_debug1 = sql.debug(); // SQL debug
					int sql_ret = executeUpdate(sql);
					if(sql_ret != 1) {
						ret = 9;
						procErrLog("CM_TRANDIVIDE_0045_before", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
					}
				} 
				
				}else if(chk.equals("00378")){//EVT필드 추가후 길이값 필드 378byte
					
					Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0045", item, cLog);
					logger.info("item of CM_TRANDIVIDE_0045 ["+item+  "]");		

					if(item_data != null) {
						if(sql != null) {									
							sql.close();					
						}

						sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0045"));
						
						int i = 1;
						sql.setString(i++, (String)data.get("STORE_CD"));
						sql.setString(i++, (String)data.get("POS_NO"));
						sql.setString(i++, (String)data.get("TRAN_NO"));
						sql.setString(i++, sys_ymd);																	
						sql.setString(i++, (String)data.get("com_cd"));

						sql.setString(i++, item_data.get("TR_ITEM_SEQ"));
						sql.setString(i++, item_data.get("SERVICE_ID"));
						sql.setString(i++, item_data.get("EXCHANGE_ID"));
						sql.setString(i++, item_data.get("COUPON_NUM"));	
						sql.setString(i++, item_data.get("ADMIT_NUM"));
						
						sql.setString(i++, item_data.get("ADMIT_DATE"));
						sql.setString(i++, item_data.get("ADMIT_TIME"));
						sql.setString(i++, item_data.get("ORG_ADMIT_NUM"));					
						sql.setString(i++, item_data.get("MANUFACTURE_CODE"));
						sql.setString(i++, item_data.get("LARGE_CODE"));
						 
						sql.setString(i++, item_data.get("MEDIUM_CODE"));
						sql.setString(i++, item_data.get("SMALL_CODE"));
						sql.setString(i++, item_data.get("SELL_AMT"));
						sql.setString(i++, item_data.get("PRODUCT_BARCODE"));
						sql.setString(i++, item_data.get("PRODUCT_COST"));
						
						sql.setString(i++, item_data.get("PARTNER_AMT"));
						sql.setString(i++, item_data.get("SUPPLY_AMT"));
						sql.setString(i++, item_data.get("EVN_PRODUCT_YN"));
						sql.setString(i++, item_data.get("EVN_PRODUCT_CNT"));
						sql.setString(i++, item_data.get("EVN_PRODUCT_AMT"));
						
						sql.setString(i++, item_data.get("COUPON_USED_AMT"));
						sql.setString(i++, item_data.get("COUPON_REMAIN_AMT"));
						sql.setString(i++, item_data.get("MANAGE_NO"));
						sql.setString(i++, item_data.get("COMMISSION_RATE"));
						sql.setString(i++, item_data.get("COMMISSION_AMT"));
						
//						sql.setString(i++, item_data.get("PROC_ID"));		//
//						sql.setString(i++, item_data.get("PROC_YMDHMS"));		//
//						sql.setString(i++, item_data.get("PROC_PID"));		//
						
						sql.setString(i++, item_data.get("STATUS_CODE"));
						sql.setString(i++, item_data.get("DISCOUNT_RATE"));
						sql.setString(i++, item_data.get("DISCOUNT_AMT"));
						sql.setString(i++, item_data.get("COUPON_TYPE"));
						sql.setString(i++, (String)data.get("TRAN_YMD"));
						
						sql.setString(i++, item_data.get("EVT_FLAG"));
						sql.setString(i++, item_data.get("EVT_CODE"));
						sql.setString(i++, item_data.get("EVT_PRODUCT_BARCODE1"));
						sql.setString(i++, item_data.get("EVT_PRODUCT_BARCODE2"));
						sql.setString(i++, item_data.get("EVT_PRODUCT_BARCODE3"));
						
						sql_debug1 = sql.debug(); // SQL debug
						int sql_ret = executeUpdate(sql);
						if(sql_ret != 1) {
							ret = 9;
							procErrLog("CM_TRANDIVIDE_0045", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
						}
					} else {
						procErrLog("CM_TRANDIVIDE_0045", "loop_num:"+loop_num, "item_data => null", data, cLog);
						ret = 9;				
					}
			} else {
				procErrLog("CM_TRANDIVIDE_0045", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;				
			}
		} catch(SQLException se) { 											
			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0045", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0045", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}

		return ret;
	}
	
	//청호 이지 캐쉬 
	public int CM_TRANDIVIDE_0046(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;

		logger.info( "CM_TRANDIVIDE_0046");
		String sql_debug1 = "";
		Map<String, String> item_data = null;
		//String[] sql_debugG = new String[100]; 
		try {
			String chk = item.substring(0, 5);
//			logger.info("chk["+chk+  "]");		
			if(chk.equals("00336")){ 
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0046", item, cLog);
				item_data.put("VAN_CD", "21");   
			}else if(chk.equals("00338")){   //캐시백 밴추가 
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0046_NEW", item, cLog);
			}else {//if(chk.equals("00488")){      //캐시백 공동망 
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0046_COMM", item, cLog);
			}			
//			logger.info("item of CM_TRANDIVIDE_0046 ["+item+  "]");						

			if(item_data != null) {
				if(chk.equals("00336") || chk.equals("00338") ){ 
					if(sql != null) {									
						sql.close();					
					}				
					sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0046"));
					
					int i = 1;
					sql.setString(i++, (String)data.get("STORE_CD"));
					sql.setString(i++, (String)data.get("POS_NO"));
					sql.setString(i++, (String)data.get("TRAN_NO"));
					sql.setString(i++, sys_ymd);																
					sql.setString(i++, (String)data.get("com_cd"));
	
					sql.setString(i++, item_data.get("TR_ITEM_SEQ"));
					sql.setString(i++, item_data.get("MCH_SEND_UNIQ_NO"));		// 
					sql.setString(i++, item_data.get("TRADE_DATE"));		// 
					sql.setString(i++, item_data.get("TRADE_TIME"));		//				
					sql.setString(i++, item_data.get("MID"));		//						
	
					sql.setString(i++, item_data.get("TERMINAL_ID"));		// 
					sql.setString(i++, item_data.get("TRADE_AMT"));		// 
					sql.setString(i++, item_data.get("COM_AMT"));		//							
					sql.setString(i++, item_data.get("EVT_AMT"));		//
					sql.setString(i++, item_data.get("TOTAL_AMT"));
					
					sql.setString(i++, item_data.get("BANK_CD"));
					sql.setString(i++, item_data.get("TRANS_ID"));
					sql.setString(i++, item_data.get("AUTH_DATE"));		//	
					sql.setString(i++, item_data.get("AUTH_NO"));		//
					sql.setString(i++, item_data.get("BEFORE_SALE_DATA"));
					
					sql.setString(i++, item_data.get("BEFORE_STORE_CD"));
					sql.setString(i++, item_data.get("BEFORE_POS_NO"));
					sql.setString(i++, item_data.get("BEFORE_TRAN_NO"));
					sql.setString(i++, item_data.get("BEFORE_SALE_AMT"));
					sql.setString(i++, item_data.get("ORG_MCH_SEND_UNIQ_NO"));		//
					
					sql.setString(i++, item_data.get("ORG_AUTH_DATE"));		//									
					sql.setString(i++, item_data.get("ORG_AUTH_NO"));		// 
					sql.setString(i++, item_data.get("INQ_UNIQ_NO"));		//
					//FN_DATETIME2STR()	--REG_YMDHMS
					//'0'				--PROC_ID
					
					//FN_DATETIME2STR()	--PROC_YMDHMS
					//'0'				--PROC_PID
					sql.setString(i++, (String)data.get("TRAN_YMD"));		// 
					//'0'				--TRAN_DIV
					sql.setString(i++, item_data.get("DRAW_FLAG"));
					
					sql.setString(i++, item_data.get("RESP_CODE"));
					sql.setString(i++, item_data.get("RESP_MSG"));
					sql.setString(i++, item_data.get("AFTER_FLAG"));
					//캐쉬백 VAN 추가 lys
					sql.setString(i++, item_data.get("VAN_CD"));
					
					
					sql_debug1 = sql.debug(); // SQL debug
	//				logger.info( "sql_debug1["+ sql_debug1 + "]");
					int sql_ret = executeUpdate(sql);
					if(sql_ret != 1) {
						ret = 9;
						logger.info("CM_TRANDIVIDE_0046 loop_num:"+loop_num + "trandivide_insert_error");
						logger.info("sql_debug1 = "+ sql_debug1 ); 
						procErrLog("CM_TRANDIVIDE_0046", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
					}
				}else {//if(chk.equals("00488")  ){
					if(sql != null) {									
						sql.close();					
					}				
					sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0046_COMM"));
					
					int i = 1;
					sql.setString(i++, (String)data.get("STORE_CD"));
					sql.setString(i++, (String)data.get("POS_NO"));
					sql.setString(i++, (String)data.get("TRAN_NO"));
					sql.setString(i++, sys_ymd);																
					sql.setString(i++, (String)data.get("com_cd"));
	
					sql.setString(i++, item_data.get("TR_ITEM_SEQ"));
					sql.setString(i++, item_data.get("MCH_SEND_UNIQ_NO"));		// 
					sql.setString(i++, item_data.get("TRADE_DATE"));		// 
					sql.setString(i++, item_data.get("TRADE_TIME"));		//				
					sql.setString(i++, item_data.get("MID"));		//						
	
					sql.setString(i++, item_data.get("TERMINAL_ID"));		// 
					sql.setString(i++, item_data.get("TRADE_AMT"));		// 
					sql.setString(i++, item_data.get("COM_AMT"));		//							
					sql.setString(i++, item_data.get("EVT_AMT"));		//
					sql.setString(i++, item_data.get("TOTAL_AMT"));
					
					sql.setString(i++, item_data.get("BANK_CD"));
					sql.setString(i++, item_data.get("TRANS_ID"));
					sql.setString(i++, item_data.get("AUTH_DATE"));		//	
					sql.setString(i++, item_data.get("AUTH_NO"));		//
					sql.setString(i++, item_data.get("BEFORE_SALE_DATA"));
					
					sql.setString(i++, item_data.get("BEFORE_STORE_CD"));
					sql.setString(i++, item_data.get("BEFORE_POS_NO"));
					sql.setString(i++, item_data.get("BEFORE_TRAN_NO"));
					sql.setString(i++, item_data.get("BEFORE_SALE_AMT"));
					sql.setString(i++, item_data.get("ORG_MCH_SEND_UNIQ_NO"));		//
					
					sql.setString(i++, item_data.get("ORG_AUTH_DATE"));		//									
					sql.setString(i++, item_data.get("ORG_AUTH_NO"));		// 
					sql.setString(i++, item_data.get("INQ_UNIQ_NO"));		//
					//FN_DATETIME2STR()	--REG_YMDHMS
					//'0'				--PROC_ID
					
					//FN_DATETIME2STR()	--PROC_YMDHMS
					//'0'				--PROC_PID
					sql.setString(i++, (String)data.get("TRAN_YMD"));		// 
					//'0'				--TRAN_DIV
					sql.setString(i++, item_data.get("DRAW_FLAG"));
					
					sql.setString(i++, item_data.get("RESP_CODE"));
					sql.setString(i++, item_data.get("RESP_MSG"));
					sql.setString(i++, item_data.get("AFTER_FLAG"));
					sql.setString(i++, item_data.get("VAN_CD"));//캐쉬백 VAN 추가 lys
					sql.setString(i++, item_data.get("ORG_POS_NO"));
					
					sql.setString(i++, item_data.get("ORG_TRAN_NO"));
					sql.setString(i++, item_data.get("ISS_BANK_CD"));
					sql.setString(i++, item_data.get("VAN_TYPE_CD"));
					sql.setString(i++, item_data.get("PRT_ACCOUNT_NO"));
					sql.setString(i++, item_data.get("BUY_MCH_SEND_UNIQ_NO"));
					
					sql.setString(i++, item_data.get("MCH_CHARGE_AMT"));
					sql.setString(i++, item_data.get("ISSINS_CHARGE_AMT"));
					sql.setString(i++, item_data.get("BUYINS_CHARGE_AMT"));
					sql.setString(i++, item_data.get("VAN_CHARGE_AMT"));
					
					 
					
					sql_debug1 = sql.debug(); // SQL debug
	//				logger.info( "sql_debug1["+ sql_debug1 + "]");
					int sql_ret = executeUpdate(sql);
					if(sql_ret != 1) {
						ret = 9;
						procErrLog("CM_TRANDIVIDE_0046", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
					}
				}
			} else {
				procErrLog("CM_TRANDIVIDE_0046", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;				
			}
		} catch(SQLException se) { 											
			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0046", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0046", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}

		return ret;
	}
	
	public int CM_TRANDIVIDE_0047(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		SqlWrapper sql_update = new SqlWrapper();
		
		String sql_debug1 = "";
		String sql_debug2 = "";
		//String[] sql_debugG = new String[100]; 
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0047", item, cLog); 			
			logger.info("item of CM_TRANDIVIDE_0047 ["+item+  "]");						

			if(item_data != null) {
				if(sql != null) {
					sql.close();					
				}
				int i = 1;
				
				sql_update.put(findQuery("tran-divide", "CM_TRANDIVIDE_0047_UPDATE"));

				sql_update.setString(i++, item_data.get("ORG_STORE_CD"));
				sql_update.setString(i++, item_data.get("ORG_POS_NO"));
				sql_update.setString(i++, item_data.get("ORG_TRAN_NO"));
				sql_update.setString(i++, item_data.get("ORG_SALE_DATE"));
						
				sql_debug1 = sql_update.debug();
				int sql_update_ret = executeUpdate(sql_update);
				
				if(sql_update_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0047", "loop_num:"+loop_num, "trandivide_update_error", data, cLog);
					return ret;
				}
				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0047"));
				i = 1;
				sql.setString(i++, (String)data.get("STORE_CD"));
				sql.setString(i++, (String)data.get("POS_NO"));
				sql.setString(i++, (String)data.get("TRAN_NO"));
				sql.setString(i++, sys_ymd);																
				sql.setString(i++, (String)data.get("com_cd"));

				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));
				sql.setString(i++, item_data.get("ROD_CD"));
				sql.setString(i++, item_data.get("ROD_AMT"));
				sql.setString(i++, item_data.get("ROD_NM"));
				sql.setString(i++, item_data.get("ORG_SALE_DATE"));
				
				sql.setString(i++, item_data.get("ORG_STORE_CD"));
				sql.setString(i++, item_data.get("ORG_POS_NO"));
				sql.setString(i++, item_data.get("ORG_TRAN_NO"));
				sql.setString(i++, (String)data.get("TRAN_YMD"));
				
				sql.setString(i++, item_data.get("INQ_UNIQ_NO"));

				sql_debug2 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0047", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
			} else {
				procErrLog("CM_TRANDIVIDE_0047", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;				
			}
		} catch(SQLException se) { 											
			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0047", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			logger.info("[SQL DEBUG 2] " + sql_debug2);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0047", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			logger.info("[SQL DEBUG 2] " + sql_debug2);
		}

		return ret;
	}	
	
	//캐시백 현금 ic 거래 
	public int CM_TRANDIVIDE_0017(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		logger.info( "CM_TRANDIVIDE_0017");
		logger.info( "CM_TRANDIVIDE_0017");
		String sql_debug1 = "";
		Map<String, String> item_data = null;
		//String[] sql_debugG = new String[100]; 
		try {     

			item_data = TranDivideUtil.getItemData("TRANDIVIDE_0017", item, cLog);
			logger.info("item of CM_TRANDIVIDE_0017 ["+item+  "]");
			logger.info("item of CM_TRANDIVIDE_0017 ["+item+  "]");
			if(item_data != null) {
				if(sql != null) {									
					sql.close();					
				}				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0017"));
				
				int i = 1;
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, (String)data.get("STORE_CD"));
				sql.setString(i++, (String)data.get("POS_NO"));
				sql.setString(i++, (String)data.get("TRAN_NO"));
				sql.setString(i++, sys_ymd);																
				

				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));
				sql.setString(i++, item_data.get("ORDER_UNIQ_NO"));		// 
				sql.setString(i++, item_data.get("TRAN_TYPE"));		// 
				sql.setString(i++, item_data.get("ISS_BANK_CD"));		//				
				sql.setString(i++, item_data.get("BUY_BANK_CD"));		//						

				sql.setString(i++, item_data.get("VAN_TYPE_CD"));		// 
				sql.setString(i++, item_data.get("PAY_AMT"));		// 
				sql.setString(i++, item_data.get("SERVICE_AMT"));		//							
				sql.setString(i++, item_data.get("VAT_AMT"));		//
				sql.setString(i++, item_data.get("MCH_CHARGE_AMT"));
				
				sql.setString(i++, item_data.get("ISSINS_CHARGE_AMT"));
				sql.setString(i++, item_data.get("BUYINS_CHARGE_AMT"));
				sql.setString(i++, item_data.get("VAN_CHARGE_AMT"));		//	
				sql.setString(i++, item_data.get("PRT_ACCOUNT_NO"));		//
				sql.setString(i++, item_data.get("CASHBAG_TRAN_YN"));
				
				sql.setString(i++, item_data.get("CASHBAG_TRAN_AMT"));
				sql.setString(i++, item_data.get("MCH_BUY_UNIQ_NO"));
				sql.setString(i++, item_data.get("ADMIT_DATE"));
				sql.setString(i++, item_data.get("ADMIT_TIME"));
				sql.setString(i++, item_data.get("ORG_TRAN_YMD"));
				sql.setString(i++, item_data.get("ORG_POS_NO"));
				
				sql.setString(i++, item_data.get("ORG_TRAN_NO"));		//				
				sql.setString(i++, item_data.get("TRAN_YMD"));		//									
				sql.setString(i++, item_data.get("MCH_SEND_UNIQ_NO"));		//
				sql_debug1 = sql.debug(); // SQL debug					
//				logger.info( "sql_debug1["+ sql_debug1 + "]");
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					logger.info("CM_TRANDIVIDE_0017 loop_num:"+loop_num+"trandivide_insert_error");
					logger.info("sql_debug1 = "+ sql_debug1);
					procErrLog("CM_TRANDIVIDE_0017", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
			} else {
				logger.info("CM_TRANDIVIDE_0017 loop_num:"+loop_num+ "item_data => null");
				procErrLog("CM_TRANDIVIDE_0017", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;				
			}
		} catch(SQLException se) { 											
			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			logger.info("sql_debug1["+sql_debug1+  "]");
			procErrLog("CM_TRANDIVIDE_0017", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			logger.info("e.getMessage()["+e.getMessage()+  "]");
			logger.info("sql_debug1["+sql_debug1+  "]");
			procErrLog("CM_TRANDIVIDE_0017", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}

		return ret;
	}		
	public int CM_TRANDIVIDE_0048(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		
		String sql_debug1 = "";
		//String[] sql_debugG = new String[100]; 
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0048", item, cLog); 			
			logger.info("item of CM_TRANDIVIDE_0048 ["+item+  "]");						

			if(item_data != null) {
				if(sql != null) {									
					sql.close();					
				}				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0048"));
				
				int i = 1;

				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, (String)data.get("STORE_CD"));
				sql.setString(i++, (String)data.get("POS_NO"));
				sql.setString(i++, (String)data.get("TRAN_NO"));
																	
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));
				sql.setString(i++, item_data.get("MCH_SEND_UNIQ_NO"));
				sql.setString(i++, item_data.get("CUST_CD")); //DEPOTVEN_CD
				sql.setString(i++, item_data.get("PAY_AMT"));
				sql.setString(i++, item_data.get("CARD_INPUT_NO"));
				
				sql.setString(i++, item_data.get("CARD_DATA"));
				sql.setString(i++, item_data.get("CARD_ENC_DATA"));
				sql.setString(i++, item_data.get("ADMIT_ID"));
				sql.setString(i++, item_data.get("ADMIT_NO"));
				sql.setString(i++, item_data.get("ADMIT_DATE"));
				
				sql.setString(i++, item_data.get("ADMIT_TIME"));
				sql.setString(i++, item_data.get("CARD_CORP_CD"));
				sql.setString(i++, item_data.get("CARD_CORP_NM"));
				sql.setString(i++, item_data.get("FRIEND_NO"));
				sql.setString(i++, item_data.get("ORG_YMD"));
				
				sql.setString(i++, item_data.get("ORG_ADMIT_NO"));
				sql.setString(i++, item_data.get("SERVICE_AMT"));
				sql.setString(i++, item_data.get("TAX_AMT"));
				sql.setString(i++, item_data.get("TRAN_UNIQ_NO"));
//				,FN_DATETIME2STR()	--REG_YMDHMS
				
//				,'0'				--PROC_ID
//				,FN_DATETIME2STR()	--PROC_YMDHMS
				sql.setString(i++, (String)data.get("TRAN_YMD"));//SYS_YMD
				sql.setString(i++, item_data.get("ORG_CD"));
				sql.setString(i++, item_data.get("STATUS_CD"));
				
				sql.setString(i++, item_data.get("CARD_BIN"));
				sql.setString(i++, item_data.get("TRACE_NO"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0048", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
			} else {
				procErrLog("CM_TRANDIVIDE_0048", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;				
			}
		} catch(SQLException se) { 											
			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0048", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0048", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}

		return ret;
	}
	
	public int CM_TRANDIVIDE_0049(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		
		String sql_debug1 = "";
		//String[] sql_debugG = new String[100]; 
		try {
			logger.info("item["+item+  "]");	
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0049", item, cLog); 			
			logger.info("item of CM_TRANDIVIDE_0049 ["+item+  "]");						

			if(item_data != null) {
				if(sql != null) {									
					sql.close();					
				}				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0049"));

				int i = 1;	
				sql.setString(i++, sys_ymd);												
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, (String)data.get("STORE_CD"));
				sql.setString(i++, (String)data.get("POS_NO"));	
				sql.setString(i++, (String)data.get("TRAN_NO"));	

				sql.setString(i++, item_data.get("COMP_CD"));
				sql.setString(i++, item_data.get("EMPLOYEE_NO"));
				sql.setString(i++, item_data.get("PAY_AMT"));
				sql.setString(i++, item_data.get("USE_AMT"));
				sql.setString(i++, item_data.get("TAX_TARGET_AMT"));
				
				sql.setString(i++, item_data.get("DUTYFREE_TARGET_AMT"));
				sql.setString(i++, item_data.get("NONTAX_TARGET_AMT"));
				sql.setString(i++, item_data.get("ZERO_TARGET_AMT"));
				sql.setString(i++, item_data.get("APPR_TYPE"));
				sql.setString(i++, item_data.get("REQ_TRANNO"));

				sql.setString(i++, item_data.get("RFND_YN"));
				sql.setString(i++, item_data.get("ORG_POS_NO"));
				sql.setString(i++, item_data.get("ORG_TRAN_DT"));
				sql.setString(i++, item_data.get("ORG_TRAN_NO"));
				sql.setString(i++, item_data.get("REG_DATETIME"));
				
				sql.setString(i++, item_data.get("IRT_NORMAL_TP"));
				
				sql_debug1 = sql.debug(); // SQL debug
				logger.info("sql_debug1["+sql_debug1+  "]");				
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0049", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
				if(item_data.get("IRT_NORMAL_TP") == "1"){

					// sql 초기화
					sql.close();
					i = 0;
					
					sql.put(findQuery("tran-divide", "UPD_COMPANY_WELFARE_HIST"));
					sql.setString(++i, "1");										// 요청구분 0:승인요청 1:취소 2:망취소
					sql.setString(++i, "CM_TRANDIVIDE_0049"); // 등록/수정자 ID
					sql.setString(++i, sys_ymd);              				        // 거래일시
					sql.setString(++i, (String)data.get("com_cd")); 				// 회사코드
					sql.setString(++i, item_data.get("COMP_CD"));                   // 소속사코드
					sql.setString(++i, item_data.get("EMPLOYEE_NO"));               // 사번
					sql.setString(++i, item_data.get("REQ_TRANNO"));                // 거래요청번호
					
					int rows = executeUpdate(sql);
					if(rows!=1){
						procErrLog("CM_TRANDIVIDE_0049", "loop_num:"+loop_num, "item_data => null", data, cLog);
						ret = 9;				
					}
				}
				
			} else {
				procErrLog("CM_TRANDIVIDE_0049", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;				
			}
		} catch(SQLException se) { 											
			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0049", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0049", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}

		return ret;
	}
	
	public int CM_TRANDIVIDE_0050(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0050", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0050"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TAX_ID"));		
				sql.setString(8, item_data.get("TAX_NM"));	
				sql.setString(9, item_data.get("TAX_TYPE"));
				sql.setString(10, item_data.get("TAX_FLAG"));
				
				sql.setString(11, item_data.get("AMT_TO_PERC")); 	
				sql.setString(12, item_data.get("TAX_TOT_AMT")); 
				sql.setString(13, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0050", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
//				logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0050", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0050", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0050", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0051(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0051", item, cLog);
			if(item_data != null) {
				String LCLSS_CD = "";
				String MCLSS_CD = "";
				String SCLSS_CD = "";
				if(!"".equals(item_data.get("PLU_CD").trim()) && item_data.get("PLU_CD") != null && "1".equals(item_data.get("EVT_GRP").trim())) {
					if(sql != null) {
						sql.close();
					}
					sql.put(findQuery("tran-divide", "SEL_SORT_GDS"));
					sql.setString(1, (String)data.get("com_cd"));
					sql.setString(2, "A16"+(String)data.get("store_cd"));
					sql.setString(3, item_data.get("PLU_CD"));	
					//logger.info("[SQL DEBUG 1] " + sql.debug());
					Map<?, ?> sort_info = executeQueryByMap(sql);
					if(!sort_info.isEmpty() && sort_info != null) {
						LCLSS_CD = (String)sort_info.get("lclss_cd");
						MCLSS_CD = (String)sort_info.get("mclss_cd");
						SCLSS_CD = (String)sort_info.get("sclss_cd");
						//logger.info("[LCLSS_CD] : " + LCLSS_CD);
						//logger.info("[MCLSS_CD] : " + MCLSS_CD);
						//logger.info("[SCLSS_CD] : " + SCLSS_CD);
					}
				}
				
				String PLU_CD = "";
				String OSALE_AMT = "";
				if(!"".equals(item_data.get("PLU_CD").trim()) && item_data.get("PLU_CD") != null && "0".equals(item_data.get("EVT_GRP").trim())) {
					PLU_CD = item_data.get("PLU_CD").substring(0, 2);
					OSALE_AMT = item_data.get("PLU_CD").substring(2);
				} else{
					PLU_CD = item_data.get("PLU_CD");
					OSALE_AMT = "0";
				}

				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0051"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, LCLSS_CD);	
				sql.setString(8, MCLSS_CD);	
				sql.setString(9, SCLSS_CD);	
				//sql.setString(10, item_data.get("PLU_CD"));
				sql.setString(10, PLU_CD);
				
				sql.setString(11, item_data.get("PLU_NM")); 	
				sql.setString(12, OSALE_AMT);
				sql.setString(13, item_data.get("DC_QTY"));
				sql.setString(14, item_data.get("DC_AMT")); 
				sql.setString(15, item_data.get("DC_SUM_AMT"));
				sql.setString(16, item_data.get("EVT_CND")); 
				
				sql.setString(17, item_data.get("EVT_ID")); 
				sql.setString(18, item_data.get("EVT_CD")); 
				sql.setString(19, item_data.get("EVT_GRP")); 
				sql.setString(20, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0051", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0051", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0051", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0051", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0052(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		String sqlNm = "";
		Map<String, String> item_data;
		try {
			if(item.length() == 285){
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0052_NEW", item, cLog);
				sqlNm = "CM_TRANDIVIDE_0052_NEW";
			}else{
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0052", item, cLog);
				sqlNm = "CM_TRANDIVIDE_0052";
			}
			
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", sqlNm));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("APPR_DT"));		
				sql.setString(8, item_data.get("APPR_NO"));	
				sql.setString(9, item_data.get("TRAN_ID"));
				sql.setString(10, item_data.get("SAVE_CNCL_TP"));
				
				sql.setString(11, item_data.get("SAVE_POINT")); 	
				sql.setString(12, item_data.get("CARD_NO")); 
				sql.setString(13, item_data.get("CARD_NO_ENCODED")); 	
				sql.setString(14, item_data.get("TRAN_DT")); 
				sql.setString(15, item_data.get("ORG_APPR_DT")); 	
				
				sql.setString(16, item_data.get("ORG_APPR_NO"));
				sql.setString(17, item_data.get("TRAN_NORMAL_TP")); 
				sql.setString(18, item_data.get("PAY_AMT"));
				sql.setString(19, (String)data.get("tran_ymd"));
				
				if(item.length() == 285){
					sql.setString(20, item_data.get("CUST_ID"));
				}
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0052", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0052", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0052", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0052", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.error("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	

	public int CM_TRANDIVIDE_0053(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog , String tran_type, String org_tran_ymd , String org_pos_no, String org_tran_no) {
	
		int ret = 0;
		String sql_debug1 = "";
		logger.info("tran_type:"+tran_type+":");		
		logger.info("org_tran_ymd:"+org_tran_ymd+":");
		logger.info("org_pos_no:"+org_pos_no+":");
		logger.info("org_tran_no:"+org_tran_no+":");
		
		Map<String, String> item_data;

		try {
			
			if(item.length() == 251){
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0053", item, cLog);
			}else{
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0053_NEW", item, cLog);
			}
			
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				if(item.length() == 251){
					sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0053"));
				}else{
					sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0053_NEW"));
				}
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("IDENTI_TY"));		
				sql.setString(8, item_data.get("INPUT_ID"));	
				sql.setString(9, item_data.get("IDENTI_CONF"));
				sql.setString(10, item_data.get("IDENTI_CONF_ENCODED"));
				
				sql.setString(11, item_data.get("PAY_AMT")); 	
				sql.setString(12, item_data.get("TAX_AMT")); 
				sql.setString(13, item_data.get("SERVICE_AMT")); 	
				sql.setString(14, item_data.get("AGREE_ID")); 
				sql.setString(15, item_data.get("AGREE_NO")); 	
				
				sql.setString(16, item_data.get("AGREE_YMDHMS"));
				sql.setString(17, item_data.get("ORG_YMD")); 
				sql.setString(18, item_data.get("ORG_AGREE_NO"));
				sql.setString(19, item_data.get("ORG_RES_ID"));
				sql.setString(20, (String)data.get("tran_ymd"));
				
				sql.setString(21, tran_type);
				sql.setString(22, org_tran_ymd);
				sql.setString(23, org_pos_no);
				sql.setString(24, org_tran_no);
				
				if(item.length() != 251){ //20180607 도서/문화비 현금영수증 대응
					sql.setString(25, item_data.get("MUNWHA_FLAG"));
				}
				
				sql_debug1 = sql.debug(); // SQL debug
				
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0053", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
					logger.info(sql_debug1);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0053", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0053", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0053", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.error("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0054(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0054", item, cLog);
			logger.info("item_data[" + item_data + "]");
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			logger.info("card_key[" + card_key + "]");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			logger.info("double_card_key[" + double_card_key + "]");
			if(item_data != null) {
				if(sql != null) { 
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0054"));
				int i = 1;
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				sql.setString(i++, (String)data.get("tran_no"));
				
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(i++, item_data.get("TRANSACTION_ID"));		
				sql.setString(i++, item_data.get("ASGN_CANCEL_YN"));	
				sql.setString(i++, item_data.get("DAT_CMD"));
				sql.setString(i++, item_data.get("WORK_ID"));
				
				sql.setString(i++, item_data.get("MEMBER_ID")); 	
				sql.setString(i++, item_data.get("TERMINAL_ID")); 
				sql.setString(i++, item_data.get("CHRG_BEF_RAMT")); 	
				sql.setString(i++, item_data.get("CHRG_REQ_AMT")); 
				sql.setString(i++, item_data.get("CHRG_AFT_RAMT")); 	
				
				sql.setString(i++, item_data.get("DEAL_AMT"));
				sql.setString(i++, item_data.get("ALGM_ID")); 
				sql.setString(i++, item_data.get("CARD_NO"));
				sql.setString(i++, card_key);
				sql.setString(i++, double_card_key);
				sql.setString(i++, item_data.get("CARD_DEAL_SNO"));
				sql.setString(i++, item_data.get("RAND_VAL"));
				
				sql.setString(i++, item_data.get("SIGN1_VAL"));
				sql.setString(i++, item_data.get("LSAM_ID"));
				sql.setString(i++, item_data.get("LSAM_DEAL_SNO"));
				sql.setString(i++, item_data.get("SIGN2_VAL"));
				sql.setString(i++, item_data.get("CARD_OWNER_ID"));
				
				sql.setString(i++, item_data.get("CHRG_FEE"));
				sql.setString(i++, item_data.get("CARD_STS"));
				sql.setString(i++, item_data.get("TERMINAL_STS"));
				sql.setString(i++, item_data.get("CHRG_YMDHMS"));
				sql.setString(i++, item_data.get("RES_CD"));
				
				sql.setString(i++, (String)data.get("tran_ymd"));
				logger.info("sql[" + sql + "] ");
				logger.info("sql.toString()[" + sql.toString() + "] ");
				logger.info("sql.debug()[" + sql.debug() + "] ");
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0054", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0054", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0054", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0054", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0055(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0055", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0055"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("APPROVAL_NO"));		
				sql.setString(8, item_data.get("TGMUNQ_ID"));	
				sql.setString(9, item_data.get("BARCODE_NO"));
				sql.setString(10, item_data.get("PRODUCT_NM"));
				
				sql.setString(11, item_data.get("ACCT_FIXED_DT")); 	
				sql.setString(12, item_data.get("PAY_AMT")); 
				sql.setString(13, item_data.get("APPR_YMDHMS")); 	
				sql.setString(14, item_data.get("CNCL_YMDHMS")); 
				sql.setString(15, item_data.get("CELPHONE_NO")); 	
				
				sql.setString(16, item_data.get("IDNTFCN_NO"));
				sql.setString(17, item_data.get("CANCLE_YN")); 
				sql.setString(18, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0055", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0055", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0055", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0055", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0056(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0056", item, cLog);
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0056"));
				int i =1;
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				sql.setString(i++, (String)data.get("tran_no"));
				
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(i++, item_data.get("V_TERMINAL_ID"));
				sql.setString(i++, item_data.get("V_TRAN_ID"));
				sql.setString(i++, item_data.get("V_ASGN_CANCEL_YN"));
				sql.setString(i++, item_data.get("V_WORK_ID"));
				sql.setString(i++, item_data.get("V_SAM_TYPE"));
				sql.setString(i++, item_data.get("V_SAM_ID"));
				sql.setString(i++, item_data.get("V_CARD_NO"));
				sql.setString(i++, card_key);
				sql.setString(i++, double_card_key);
				sql.setString(i++, item_data.get("V_CARD_DEAL_SNO"));
				sql.setString(i++, item_data.get("V_DEAL_YMDHMS"));
				sql.setString(i++, item_data.get("V_DEAL_BEF_RAMT"));
				sql.setString(i++, item_data.get("V_DEAL_REQ_AMT"));
				sql.setString(i++, item_data.get("V_DEAL_AFT_RAMT"));
				sql.setString(i++, item_data.get("V_BEF_SAM_RAMT"));
				sql.setString(i++, item_data.get("V_AFT_SAM_RAMT"));
				sql.setString(i++, item_data.get("V_CARD_TYPE"));
				sql.setString(i++, item_data.get("V_PAY_TYPE"));
				sql.setString(i++, item_data.get("V_MBSCARD_EXP_DATE"));
				sql.setString(i++, item_data.get("V_MBSCARD_NO"));
				sql.setString(i++, card_key);
				sql.setString(i++, double_card_key);
				sql.setString(i++, item_data.get("V_FIRST_CHRG_FG"));
				sql.setString(i++, item_data.get("V_FRU"));
				sql.setString(i++, item_data.get("V_FEE_RATE"));
				sql.setString(i++, item_data.get("V_FEE_AMT"));
				sql.setString(i++, item_data.get("V_SAM_DEAL_SNO"));
				sql.setString(i++, item_data.get("V_SAM_TOT_CNT"));
				sql.setString(i++, item_data.get("V_ALGM_ID"));
				sql.setString(i++, item_data.get("V_KEYSET_VER"));
				sql.setString(i++, item_data.get("V_CARD_DEPOSIT"));
				sql.setString(i++, item_data.get("V_PENALTY_AMT"));
				sql.setString(i++, item_data.get("V_CHRG_APPROVAL_NO"));
				sql.setString(i++, item_data.get("V_PUBCO_ID"));
				sql.setString(i++, item_data.get("V_SIGN_VAL"));
				sql.setString(i++, item_data.get("V_SIGN_VAL_2"));
				sql.setString(i++, item_data.get("V_NCSAM"));
				sql.setString(i++, item_data.get("V_NISAM"));
				sql.setString(i++, item_data.get("V_TOTSAM"));
				sql.setString(i++, item_data.get("V_IDCENTER"));
				sql.setString(i++, item_data.get("V_MPSAM"));
				sql.setString(i++, item_data.get("V_MAXIDCENTER"));
				sql.setString(i++, item_data.get("V_BALIDCENTER"));
				sql.setString(i++, item_data.get("V_RFU"));
				sql.setString(i++, item_data.get("V_RESULT"));
				sql.setString(i++, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0056", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0056", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0056", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0056", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0057(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0057", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0057"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("V_INVOICE_CD"));
				sql.setString(7, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(8, item_data.get("V_PARCEL_CMP"));
				sql.setString(9, item_data.get("V_PAY_DTL_ID"));
				sql.setString(10, item_data.get("V_SERVICE_CODE"));
				sql.setString(11, item_data.get("V_PARCEL_IN_QTY"));
				sql.setString(12, item_data.get("V_INPUT_ID"));
				sql.setString(13, item_data.get("V_BASE_AMT_BTN"));
				sql.setString(14, item_data.get("V_TOT_AMT"));
				sql.setString(15, item_data.get("V_BASE_AMT"));
				sql.setString(16, item_data.get("V_PERRY_RTS_AMT"));
				sql.setString(17, item_data.get("V_ITEM_EXT_AMT"));
				sql.setString(18, item_data.get("V_DC_AMT"));
				sql.setString(19, item_data.get("V_COMMISSION_TY"));
				sql.setString(20, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0057", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0057", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0057", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0057", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	
	//20170809 KSN 한진택배서비스 추가
	public int CM_TRANDIVIDE_0015(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data;
		
		try {
			item_data = TranDivideUtil.getItemData("TRANDIVIDE_0015", item, cLog);
			
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				
				String proc_id = "0";
				if("2".equals((String)item_data.get("V_PAY_DTL_ID"))||"3".equals((String)item_data.get("V_PAY_DTL_ID"))){
					proc_id = "1";
				}
				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0015"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("V_INVC_CD"));
				sql.setString(7, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(8, item_data.get("V_PARCEL_CMP"));
				sql.setString(9, String.format("%02d", Integer.parseInt(item_data.get("V_PAY_DTL_ID"))));
				sql.setString(10, item_data.get("V_SERVICE_CODE"));
				sql.setString(11, item_data.get("V_PARCEL_IN_QTY"));
				sql.setString(12, item_data.get("V_BASE_AMT_BTN"));
				sql.setString(13, item_data.get("V_TOT_AMT"));
				sql.setString(14, item_data.get("V_BASE_AMT"));
				sql.setString(15, item_data.get("V_PERRY_RTS_AMT"));
				sql.setString(16, item_data.get("V_ITEM_EXT_AMT"));
				sql.setString(17, item_data.get("V_DC_AMT"));
				sql.setString(18, item_data.get("V_COMMISSION_TY"));
				sql.setString(19, proc_id); //PROC_ID 선불:0, 착불:1
				sql.setString(20, (String)data.get("tran_ymd"));
				sql.setString(21, item_data.get("V_PARCEL_TP"));
				sql.setString(22, item_data.get("V_ENP_DIV"));
				sql.setString(23, item_data.get("V_INVC_TYPE"));
				sql.setString(24, item_data.get("V_INVC_CD1"));
				sql.setString(25, item_data.get("V_INVC_CD2"));
				sql.setString(26, item_data.get("V_RCV_DATETIME"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0015", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0015", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0015", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0015", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		return ret;
	}
	
	
	
	public int CM_TRANDIVIDE_0058(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data;
		try {
			if(item.getBytes().length != 1061){
				if(item.getBytes().length == 1243){
					item_data = TranDivideUtil.getItemData("TRANDIVIDE_0058_RENEW", item, cLog);
				}else{
					item_data = TranDivideUtil.getItemData("TRANDIVIDE_0058", item, cLog);

					item_data.put("V_DC_MD_IN_YN", "");
					item_data.put("V_SSGPAY_DC_YN", "");
					item_data.put("V_SSGPAY_CP_PLAT_YN", "");
					item_data.put("V_SSGPAY_CP_USE_YN", "");
					item_data.put("V_SSGPAY_CP_AMT", "");
				}
			}else{
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0058_OLD", item, cLog);
							
				item_data.put("V_BUY_FIRM_CODE", "");
				item_data.put("V_BUY_FIRM_NM", "");
				item_data.put("V_ISSUE_FIRM_CODE", "");
				item_data.put("V_ISSUE_FIRM_NM", "");
				item_data.put("V_EVENT_MD_IN_YN", "");
				item_data.put("V_EVENT_YN", "");				
				item_data.put("V_BANK_YN", "");
				item_data.put("V_BANK_ACCOUNT_NO_ENCRPT", "");
				item_data.put("V_BANK_RECEIPT", "");
				item_data.put("V_BANK_AMT", "");
				item_data.put("V_BANK_AUTH_NO", "");
				item_data.put("V_BANK_AUTH_DATE", "");
				item_data.put("V_BANK_ORG_AUTH_NO", "");
				item_data.put("V_BANK_ORG_AUTH_DATE", "");
				
				item_data.put("V_DC_MD_IN_YN", "");
				item_data.put("V_SSGPAY_DC_YN", "");
				item_data.put("V_SSGPAY_CP_PLAT_YN", "");
				item_data.put("V_SSGPAY_CP_USE_YN", "");
				item_data.put("V_SSGPAY_CP_AMT", "");
			}
			
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				String V_EVENT_MD_IN_YN = "";
				String V_EVENT_YN = "";
				byte[] b = item.getBytes("MS949");
				//if(b.length == 1061) {
					V_EVENT_MD_IN_YN = new String(b, 1059, 1, "MS949");
					V_EVENT_YN = new String(b, 1060, 1, "MS949");
				//}
				
				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0058"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("V_DELEGATE_BARCODE_NO"));
				sql.setString(8, item_data.get("V_DELEGATE_BARCODE_NO_ENCODED"));
				sql.setString(9, item_data.get("V_MSG_ID"));
				sql.setString(10, item_data.get("V_TRAN_TYPE"));
				sql.setString(11, item_data.get("V_TERMINAL_ID"));
				sql.setString(12, item_data.get("V_SEND_DATE"));
				sql.setString(13, item_data.get("V_SEND_UNIQ_NO"));
				sql.setString(14, item_data.get("V_CASHER_NO"));
				sql.setString(15, item_data.get("V_SALE_DATE"));
				sql.setString(16, item_data.get("V_SALE_TIME"));
				sql.setString(17, item_data.get("V_EMP_ID_NO_PLAT_YN"));
				sql.setString(18, item_data.get("V_EMP_ID_NO_USE_YN"));
				sql.setString(19, ""); // item_data.get("V_EMP_ID_NO") 개인정보 미저장 -- 2016.05.23 OHT
				sql.setString(20, item_data.get("V_EMP_ID_NO_ENCODED"));
				sql.setString(21, item_data.get("V_S_POINT_PLAT_YN"));
				sql.setString(22, item_data.get("V_S_POINT_USE_YN"));
				sql.setString(23, ""); // item_data.get("V_S_POINT_CARD_NO") 개인정보 미저장 -- 2016.05.23 OHT
				sql.setString(24, item_data.get("V_S_POINT_CARD_NO_ENCODED"));
				sql.setString(25, item_data.get("V_M_GIFT_CARD_PLAT_YN"));
				sql.setString(26, item_data.get("V_M_GIFT_CARD_USE_YN"));
				sql.setString(27, ""); // item_data.get("V_M_GIFT_CARD_NO") 개인정보 미저장 -- 2016.05.23 OHT
				sql.setString(28, item_data.get("V_M_GIFT_CARD_NO_ENCODED"));
				sql.setString(29, item_data.get("V_M_GIFT_USE_AMT"));
				sql.setString(30, item_data.get("V_M_GIFT_AUTH_DATE"));
				sql.setString(31, item_data.get("V_M_GIFT_AUTH_NO"));
				sql.setString(32, item_data.get("V_ORG_M_GIFT_AUTH_DATE"));
				sql.setString(33, item_data.get("V_ORG_M_GIFT_AUTH_NO"));
				sql.setString(34, item_data.get("V_CREDIT_CARD_PLAT_YN"));
				sql.setString(35, item_data.get("V_CREDIT_CARD_YN"));
				sql.setString(36, item_data.get("V_CARD_CERT_FLAG"));
				sql.setString(37, ""); // item_data.get("V_CREDIT_CARD_NO") 개인정보 미저장 -- 2016.05.23 OHT
				sql.setString(38, item_data.get("V_CREDIT_CARD_NO_ENCODED"));
				sql.setString(39, item_data.get("V_CREDIT_CARD_INS_MON"));
				sql.setString(40, item_data.get("V_CREDIT_CARD_USE_AMT"));
				sql.setString(41, item_data.get("V_CREDIT_CARD_AUTH_DATE"));
				sql.setString(42, item_data.get("V_CREDIT_CARD_AUTH_NO"));
				sql.setString(43, item_data.get("V_CREDIT_CARD_RECEIPT_A"));
				sql.setString(44, item_data.get("V_CREDIT_CARD_RECEIPT_A_EN"));
				sql.setString(45, item_data.get("V_CREDIT_CARD_RECEIPT_D"));
				sql.setString(46, item_data.get("V_CREDIT_CARD_RECEIPT_D_EN"));
				sql.setString(47, item_data.get("V_ORG_CREDIT_CARD_AUTH_DATE"));
				sql.setString(48, item_data.get("V_ORG_CREDIT_CARD_AUTH_NO"));
				sql.setString(49, item_data.get("V_CASH_RECEIPT_INFO_PLAT_YN"));
				sql.setString(50, item_data.get("V_CASH_RECEIPT_INFO_USE_YN"));
				sql.setString(51, ""); // item_data.get("V_CASH_RECEIPT_INFO") 개인정보 미저장 -- 2016.05.23 OHT
				sql.setString(52, item_data.get("V_CASH_RECEIPT_INFO_ENCODED"));
				sql.setString(53, item_data.get("V_ETC_PAY_YN"));
				sql.setString(54, item_data.get("V_ETC_PAY_AMT"));
				sql.setString(55, item_data.get("V_ORG_SEND_DATE"));
				sql.setString(56, item_data.get("V_ORG_SEND_UNIQ_NO"));
				sql.setString(57, item_data.get("V_ORG_SER_COM_CD"));
				sql.setString(58, item_data.get("V_ORG_SALE_DATE"));
				sql.setString(59, item_data.get("V_ORG_ST_CODE"));
				sql.setString(60, item_data.get("V_ORG_TM_NO"));
				sql.setString(61, item_data.get("V_ORG_SHOP_NO"));
				sql.setString(62, item_data.get("V_ORG_CD_NO"));
				sql.setString(63, item_data.get("V_ORG_TRAN_NO"));
				sql.setString(64, item_data.get("V_ORG_CASHER_NO"));
				sql.setString(65, item_data.get("V_TOT_TRADE_AMT"));
				sql.setString(66, item_data.get("V_DIS_TRADE_AMT"));
				sql.setString(67, item_data.get("V_NET_TRADE_AMT"));
				sql.setString(68, item_data.get("V_MD_CNT"));
				sql.setString(69, item_data.get("V_MD_CODE"));
				sql.setString(70, item_data.get("V_MD_NAME"));
				
				sql.setString(71, item_data.get("V_BUY_FIRM_CODE"));
				sql.setString(72, item_data.get("V_BUY_FIRM_NM"));
				sql.setString(73, item_data.get("V_ISSUE_FIRM_CODE"));
				sql.setString(74, item_data.get("V_ISSUE_FIRM_NM"));					
				sql.setString(75, V_EVENT_MD_IN_YN);
				sql.setString(76, V_EVENT_YN);
				
				sql.setString(77, (String)data.get("tran_ymd"));
				sql.setString(78, item_data.get("V_BANK_YN"));
				sql.setString(79, item_data.get("V_BANK_ACCOUNT_NO_ENCRPT"));
				sql.setString(80, item_data.get("V_BANK_RECEIPT"));
				sql.setString(81, item_data.get("V_BANK_AMT"));
				sql.setString(82, item_data.get("V_BANK_AUTH_NO"));
				sql.setString(83, item_data.get("V_BANK_AUTH_DATE"));
				sql.setString(84, item_data.get("V_BANK_ORG_AUTH_NO"));
				sql.setString(85, item_data.get("V_BANK_ORG_AUTH_DATE"));
				
				sql.setString(86, item_data.get("V_DC_MD_IN_YN"));
				sql.setString(87, item_data.get("V_SSGPAY_DC_YN"));
				sql.setString(88, item_data.get("V_SSGPAY_CP_PLAT_YN"));
				sql.setString(89, item_data.get("V_SSGPAY_CP_USE_YN"));
				sql.setString(90, item_data.get("V_SSGPAY_CP_AMT"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0058", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0058", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0058", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0058", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0059(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0059", item, cLog);
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0059"));
				int i =1;
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				sql.setString(i++, (String)data.get("tran_no"));
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(i++, item_data.get("V_DEAL_UNIQ_NO"));
				sql.setString(i++, item_data.get("V_DAT_CMD"));
				sql.setString(i++, item_data.get("V_FCSTR_ID"));
				sql.setString(i++, item_data.get("V_PROC_CD"));
				sql.setString(i++, item_data.get("V_CARD_NO"));
				sql.setString(i++, card_key);
				sql.setString(i++, double_card_key);
				sql.setString(i++, item_data.get("V_CARD_TP"));
				sql.setString(i++, item_data.get("V_CARD_CORP_TP"));
				sql.setString(i++, item_data.get("V_PAYMENT_TP"));
				sql.setString(i++, item_data.get("V_DEAL_YMDHMS"));
				sql.setString(i++, item_data.get("V_ADJT_YMD"));
				sql.setString(i++, item_data.get("V_TERMINAL_ID"));
				sql.setString(i++, item_data.get("V_CHRG_BEF_RAMT"));
				sql.setString(i++, item_data.get("V_CHRG_REQ_AMT"));
				sql.setString(i++, item_data.get("V_CHRG_AFT_RAMT"));
				sql.setString(i++, item_data.get("V_CARD_DEAL_SEQ_NO"));
				sql.setString(i++, item_data.get("V_RAND_VAL"));
				sql.setString(i++, item_data.get("V_SIGN_VAL_1"));
				sql.setString(i++, item_data.get("V_LSAM_ID"));
				sql.setString(i++, item_data.get("V_LSAM_DEAL_SEQ_NO"));
				sql.setString(i++, item_data.get("V_SIGN_VAL_2"));
				sql.setString(i++, item_data.get("V_CCARD_TP"));
				sql.setString(i++, item_data.get("V_CCARD_FEE"));
				sql.setString(i++, item_data.get("V_REFUND_TP"));
				sql.setString(i++, item_data.get("V_ORG_DEAL_UNQ_NO"));
				sql.setString(i++, item_data.get("V_CHRG_RESP_CD"));
				sql.setString(i++, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0059", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0059", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0059", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0059", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	// Alipay 20170828 알리페이결제수단추가_LYH
	public int CM_TRANDIVIDE_0064(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0064", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0064"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("SEND_UNIQ_NO"));
				sql.setString(8, item_data.get("AUTH_CODE"));
				sql.setString(9, item_data.get("PAY_CURRENCY"));
				sql.setString(10, item_data.get("PAY_AMOUNT"));
				
				sql.setString(11, item_data.get("SEND_DATE"));
				sql.setString(12, item_data.get("AUTH_DATE"));
				sql.setString(13, item_data.get("AUTH_NO"));
				sql.setString(14, item_data.get("ORG_SEND_DATE"));
				sql.setString(15, item_data.get("ORG_SEND_UNIQ_NO"));

				sql.setString(16, item_data.get("ORG_AUTH_DATE"));
				sql.setString(17, item_data.get("ORG_AUTH_NO"));
				sql.setString(18, item_data.get("AUTH_CODE_ENC"));
				sql.setString(19, item_data.get("INPUT_TYPE"));
				sql.setString(20, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0064", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
//				logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0064", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0064", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0064", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}

	public int CM_TRANDIVIDE_0065(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0065", item, cLog);
			if(item_data != null) {
				String LCLSS_CD = "";
				String MCLSS_CD = "";
				String SCLSS_CD = "";
				if(!"".equals(item_data.get("V_PLU_CD").trim()) && item_data.get("V_PLU_CD") != null) {
					if(sql != null) {
						//logger.info(":::::1 sql.close()");
						sql.close();
					}
					sql.put(findQuery("tran-divide", "SEL_SORT_GDS"));
					sql.setString(1, (String)data.get("com_cd"));
					sql.setString(2, "A16"+(String)data.get("store_cd"));
					sql.setString(3, item_data.get("V_PLU_CD"));	
					//logger.info("[SQL DEBUG 1] " + sql.debug());
					Map<?, ?> sort_info = executeQueryByMap(sql);
					if(!sort_info.isEmpty() && sort_info != null) {
						LCLSS_CD = (String)sort_info.get("lclss_cd");
						MCLSS_CD = (String)sort_info.get("mclss_cd");
						SCLSS_CD = (String)sort_info.get("sclss_cd");
						//logger.info("[LCLSS_CD] : " + LCLSS_CD);
						//logger.info("[MCLSS_CD] : " + MCLSS_CD);
						//logger.info("[SCLSS_CD] : " + SCLSS_CD);
					}
				}
				
				String V_ITEM_UPRC = "";
				byte[] b = item.getBytes("MS949");
				if(b.length > 140) {
					V_ITEM_UPRC = new String(b, 140, 16, "MS949");
				}
				
				if(sql != null) {
					//logger.info(":::::2 sql.close()");
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0065"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, LCLSS_CD);	
				sql.setString(8, MCLSS_CD);	
				sql.setString(9, SCLSS_CD);
				sql.setString(10, item_data.get("V_PLU_CD"));
				sql.setString(11, item_data.get("V_PLU_NM"));
				sql.setString(12, V_ITEM_UPRC);
				sql.setString(13, item_data.get("V_DC_QTY"));
				sql.setString(14, item_data.get("V_DC_AMT"));
				sql.setString(15, item_data.get("V_DC_SUM_AMT"));
				sql.setString(16, item_data.get("V_EVT_CND"));
				sql.setString(17, item_data.get("V_EVT_ID"));
				sql.setString(18, item_data.get("V_EVT_CD"));
				sql.setString(19, item_data.get("V_EVT_GRP"));
				sql.setString(20, item_data.get("V_VAN_CORP_CD"));
				sql.setString(21, item_data.get("V_CARD_CORP_CD"));
				sql.setString(22, item_data.get("V_EVT_PAY_CD"));
				sql.setString(23, (String)data.get("tran_ymd"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0065", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0065", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0065", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0065", "loop_num:"+loop_num, e.toString(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_0067(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0067", item, cLog);
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");

			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0067"));  
				int i =1;             
				sql.setString(i++, sys_ymd);                                             
				sql.setString(i++, (String)data.get("com_cd"));                          
				sql.setString(i++, (String)data.get("store_cd"));                        
				sql.setString(i++, (String)data.get("pos_no"));                          
				sql.setString(i++, (String)data.get("tran_no"));			               
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
     
				sql.setString(i++, item_data.get("DGB_TRAN_TP"));                        
				sql.setString(i++, item_data.get("DEAL_UNIQ_NO"));                       
				sql.setString(i++, item_data.get("DEAL_YMDHMS"));                        
				sql.setString(i++, item_data.get("ORG_DEAL_UNIQ_NO"));                  
				sql.setString(i++, item_data.get("TERMINAL_ID"));                       
				sql.setString(i++, item_data.get("STORE_ID"));                          
				sql.setString(i++, item_data.get("ADJT_YMD"));                          
				sql.setString(i++, item_data.get("CARD_CD"));             
				sql.setString(i++, (new AES()).decrypt((item_data.get("CARD_NO").trim())));                       
				sql.setString(i++, card_key);                          
				sql.setString(i++, double_card_key);                         
				sql.setString(i++, item_data.get("CARD_DATA"));                         
				sql.setString(i++, item_data.get("CARD_USER_CD"));                      
				sql.setString(i++, item_data.get("CARD_USER_TP"));                      
				sql.setString(i++, item_data.get("CHRG_BEF_AMT"));                      
				sql.setString(i++, item_data.get("DEAL_AMT"));                          
				sql.setString(i++, item_data.get("CHRG_AFT_AMT"));                      
				sql.setString(i++, item_data.get("NT_EP"));                             
				sql.setString(i++, item_data.get("CARD_RANDOM_NO"));                    
				sql.setString(i++, item_data.get("SAM_RANDOM_NO"));                     
				sql.setString(i++, item_data.get("ID_SAM"));                            
				sql.setString(i++, item_data.get("NT_SAM"));                            
				sql.setString(i++, item_data.get("HOST_NO"));                           
				sql.setString(i++, item_data.get("HOST_RANDOM_NO"));                    
				sql.setString(i++, item_data.get("SIGN"));
				sql.setString(i++, item_data.get("RETURN_TP"));

				sql.setString(i++, (String)data.get("tran_ymd"));

				sql.setString(i++, item_data.get("RESP_CD"));
				
				if(item_data.get("DGB_TRAN_TP").equals("01")){sql.setString(i++, "10");}
				else if(item_data.get("DGB_TRAN_TP").equals("40")){sql.setString(i++, "02");}
				else if(item_data.get("DGB_TRAN_TP").equals("80")){sql.setString(i++, "00");}
				else if(item_data.get("DGB_TRAN_TP").equals("81")){sql.setString(i++, "01");}
				else if(item_data.get("DGB_TRAN_TP").equals("88")){sql.setString(i++, "11");}
				sql.setString(i++, "00");
				sql.setString(i++, item_data.get("TRAN_ID"));
				
//				for(int i=1; i<=34;i++){logger.info(sql.getString(i));}				
				sql_debug1 = sql.debug(); // SQL debug 

				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0067", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0067", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
//			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
//			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0067", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0067", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 67] " + e);
		}
		return ret;
	}
	
	public int CM_TRANDIVIDE_0068(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0068", item, cLog);
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0068"));
				int i =1;
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				sql.setString(i++, (String)data.get("tran_no"));			
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ

				sql.setString(i++, item_data.get("DGB_TRAN_TP"));
				sql.setString(i++, item_data.get("DEAL_UNIQ_NO"));
				sql.setString(i++, item_data.get("DEAL_YMDHMS"));
				sql.setString(i++, item_data.get("ORG_DEAL_UNIQ_NO"));
				sql.setString(i++, item_data.get("TERMINAL_ID"));

				sql.setString(i++, item_data.get("STORE_ID"));
				sql.setString(i++, item_data.get("CARD_CD "));     
				sql.setString(i++, item_data.get("ALG_EP"));
				sql.setString(i++, item_data.get("ID_CENTER"));
				sql.setString(i++, item_data.get("VK_IND_KEY2"));

				sql.setString(i++, item_data.get("VK_IND_KEY"));
				sql.setString(i++, item_data.get("ID_SAM"));			
				sql.setString(i++, item_data.get("NC_SAM"));
				sql.setString(i++, item_data.get("NI_SAM"));
				sql.setString(i++, item_data.get("TOT_SAM"));
 
				sql.setString(i++, (new AES()).decrypt((item_data.get("CARD_NO").trim())));                  
				sql.setString(i++, card_key);                          
				sql.setString(i++, double_card_key);           
				sql.setString(i++, item_data.get("CARD_DATA"));
				sql.setString(i++, item_data.get("NT_EP"));
				sql.setString(i++, item_data.get("BAL_EP"));
				sql.setString(i++, item_data.get("DEAL_AMT"));

				sql.setString(i++, item_data.get("NT_SAM"));
				sql.setString(i++, item_data.get("SIGN_IND"));
				sql.setString(i++, item_data.get("SIGN_IND2"));
				sql.setString(i++, item_data.get("CARD_USER_CD"));
				sql.setString(i++, item_data.get("CARD_USER_TP"));

				sql.setString(i++, item_data.get("RID"));
				sql.setString(i++, item_data.get("PAY_BEF_TP"));
				sql.setString(i++, item_data.get("PAY_BEF_AMT"));
				sql.setString(i++, item_data.get("PAY_BEF_NTEP"));
				sql.setString(i++, item_data.get("PAY_REQ_AMT"));

				sql.setString(i++, item_data.get("PAY_BEF_ID_SAM"));
				sql.setString(i++, item_data.get("PAY_BEF_NT_SAM"));
				sql.setString(i++, item_data.get("PAY_BEF_YMDHMS"));
				sql.setString(i++, item_data.get("RESP_CD"));
				sql.setString(i++, item_data.get("FEE"));

				sql.setString(i++, (String)data.get("tran_ymd"));
				sql.setString(i++, item_data.get("TRAN_ID"));

				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0068", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0068", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
//			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
//			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0068", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0068", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 68] " + e);
		}
		return ret;
	}
	
	
	public int CM_TRANDIVIDE_0069(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0069", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				
				logger.info("CM_TRANDIVIDE_0069 ::: START");
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0069"));
				int i =1;
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				sql.setString(i++, (String)data.get("tran_no"));
				
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));
				sql.setString(i++, item_data.get("SALE_DATE"));
				sql.setString(i++, item_data.get("SALE_QTY"));
				sql.setString(i++, item_data.get("SALE_AMT"));
				sql.setString(i++, item_data.get("DC_AMT"));
				sql.setString(i++, item_data.get("ORG_POS_NO"));
				
				sql.setString(i++, item_data.get("ORG_TRAN_DATE"));     
				sql.setString(i++, item_data.get("ORG_TRAN_NO"));
				sql.setString(i++, item_data.get("PROC_ID"));
				sql.setString(i++, item_data.get("PROC_YMDHMS"));
				sql.setString(i++, (String)data.get("tran_ymd"));			

				logger.info( "▶ [TR_ITEM_SEQ] : "+ item_data.get("TR_ITEM_SEQ"));
				
				logger.info("CM_TRANDIVIDE_0069 ::: REG_YMDHMS" + item_data.get("REG_YMDHMS"));
				
				sql_debug1 = sql.debug(); // SQL debug
				logger.info("insert start");
				
				int sql_ret = executeUpdate(sql);
				
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0068", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
					logger.info("CM_TRANDIVIDE_0069 ::: trandivide_insert_error ret ["+sql_ret+"]");
				}
//				executeUpdate(sql);
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				logger.info("CM_TRANDIVIDE_0069 ::: sql_debug1 ["+sql_debug1+"]");
				
			} else {
				procErrLog("CM_TRANDIVIDE_0068", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
//			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
//			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0068", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("CM_TRANDIVIDE_0069 ::: SQLException ["+se.getMessage()+"]");
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0068", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("CM_TRANDIVIDE_0069 ::: Exception ["+e.getMessage()+"]");
//			logger.info("[SQL DEBUG 68] " + e);
		}
		logger.info("CM_TRANDIVIDE_0069 ::: END");
		return ret;
	}

	//SPC 캐시비매출
	public int CM_TRANDIVIDE_0071(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0071", item, cLog);
			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0071"));
				int i =1;
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("com_cd"));
				sql.setString(i++, (String)data.get("store_cd"));
				sql.setString(i++, (String)data.get("pos_no"));
				sql.setString(i++, (String)data.get("tran_no"));
				
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(i++, item_data.get("V_TERMINAL_ID"));
				sql.setString(i++, item_data.get("V_TRAN_ID"));
				sql.setString(i++, item_data.get("V_ASGN_CANCEL_YN"));
				sql.setString(i++, item_data.get("V_WORK_ID"));
				sql.setString(i++, item_data.get("V_SAM_TYPE"));
				sql.setString(i++, item_data.get("V_SAM_ID"));
				sql.setString(i++, item_data.get("V_CARD_NO"));
				sql.setString(i++, card_key);
				sql.setString(i++, double_card_key);
				sql.setString(i++, item_data.get("V_CARD_DEAL_SNO"));
				sql.setString(i++, item_data.get("V_DEAL_YMDHMS"));
				sql.setString(i++, item_data.get("V_DEAL_BEF_RAMT"));
				sql.setString(i++, item_data.get("V_DEAL_REQ_AMT"));
				sql.setString(i++, item_data.get("V_DEAL_AFT_RAMT"));
				sql.setString(i++, item_data.get("V_BEF_SAM_RAMT"));
				sql.setString(i++, item_data.get("V_AFT_SAM_RAMT"));
				sql.setString(i++, item_data.get("V_CARD_TYPE"));
				sql.setString(i++, item_data.get("V_PAY_TYPE"));
				sql.setString(i++, item_data.get("V_MBSCARD_EXP_DATE"));
				sql.setString(i++, item_data.get("V_MBSCARD_NO"));
				sql.setString(i++, card_key);
				sql.setString(i++, double_card_key);
				sql.setString(i++, item_data.get("V_FIRST_CHRG_FG"));
				sql.setString(i++, item_data.get("V_FRU"));
				sql.setString(i++, item_data.get("V_FEE_RATE"));
				sql.setString(i++, item_data.get("V_FEE_AMT"));
				sql.setString(i++, item_data.get("V_SAM_DEAL_SNO"));
				sql.setString(i++, item_data.get("V_SAM_TOT_CNT"));
				sql.setString(i++, item_data.get("V_ALGM_ID"));
				sql.setString(i++, item_data.get("V_KEYSET_VER"));
				sql.setString(i++, item_data.get("V_CARD_DEPOSIT"));
				sql.setString(i++, item_data.get("V_PENALTY_AMT"));
				sql.setString(i++, item_data.get("V_CHRG_APPROVAL_NO"));
				sql.setString(i++, item_data.get("V_PUBCO_ID"));
				sql.setString(i++, item_data.get("V_SIGN_VAL"));
				sql.setString(i++, item_data.get("V_SIGN_VAL_2"));
				sql.setString(i++, item_data.get("V_NCSAM"));
				sql.setString(i++, item_data.get("V_NISAM"));
				sql.setString(i++, item_data.get("V_TOTSAM"));
				sql.setString(i++, item_data.get("V_IDCENTER"));
				sql.setString(i++, item_data.get("V_MPSAM"));
				sql.setString(i++, item_data.get("V_MAXIDCENTER"));
				sql.setString(i++, item_data.get("V_BALIDCENTER"));
				sql.setString(i++, item_data.get("V_RFU"));
				sql.setString(i++, item_data.get("V_RESULT"));
				sql.setString(i++, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0071", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0071", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0071", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0071", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	

	//20171207 KSN SSG CON
	public int CM_TRANDIVIDE_0081(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data;
		
		try {
			logger.info("CM_TRANDIVIDE_0081::item Length::["+item.getBytes().length+"]");
			
			if(item.getBytes().length == 528){
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0081_PRD", item, cLog);
			}else{
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0081", item, cLog);
				item_data.put("PRD_SKU_CODE", "");
			}
			
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				
				logger.info("CM_TRANDIVIDE_0081:::START");
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0081"));
				int i =1;
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("COM_CD"));
				sql.setString(i++, (String)data.get("STORE_CD"));
				sql.setString(i++, (String)data.get("POS_NO"));
				sql.setString(i++, (String)data.get("TRAN_NO"));
				
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));
				sql.setString(i++, item_data.get("TRACE_NO"));
				sql.setString(i++, item_data.get("SEL_AUTH_NO"));
				sql.setString(i++, item_data.get("TRADE_TYPE"));
				sql.setString(i++, item_data.get("COUPON_NO"));
				
				sql.setString(i++, item_data.get("COUPON_NO_ENC"));
				sql.setString(i++, item_data.get("BARCODE_NO"));
				sql.setString(i++, item_data.get("BARCODE_NO_ENC"));
				sql.setString(i++, item_data.get("USED_AMT"));
				sql.setString(i++, item_data.get("REMAIN_AMT"));
				
				sql.setString(i++, item_data.get("SALE_DATE"));
				sql.setString(i++, item_data.get("SALE_TIME"));
				sql.setString(i++, item_data.get("AUTH_DATE"));
				sql.setString(i++, item_data.get("AUTH_TIME"));
				sql.setString(i++, item_data.get("AUTH_NO"));   
				
				sql.setString(i++, item_data.get("ORG_TRACE_NO"));
				sql.setString(i++, item_data.get("ORG_SALE_DATE"));
				sql.setString(i++, item_data.get("ORG_AUTH_DATE"));
				sql.setString(i++, item_data.get("ORG_AUTH_NO"));
				sql.setString(i++, item_data.get("PRD_TYPE"));    
				
				sql.setString(i++, item_data.get("CLASS_GUBUN"));
				sql.setString(i++, item_data.get("PRD_ID"));
				sql.setString(i++, item_data.get("PRD_NM"));
				sql.setString(i++, item_data.get("PRD_AMT"));
				sql.setString(i++, item_data.get("MSG_SEND_DT"));
				
				sql.setString(i++, item_data.get("MSG_SEND_TM"));     
				sql.setString(i++, item_data.get("PTR_MCH_ID"));
				sql.setString(i++, item_data.get("CASHER_NO"));
				sql.setString(i++, item_data.get("TRAN_TYPE"));
				sql.setString(i++, item_data.get("KEY_IN_TYPE"));
				
				sql.setString(i++, item_data.get("USE_FUNC_GUBUN"));
				sql.setString(i++, item_data.get("USE_GUBUN"));
				sql.setString(i++, item_data.get("GRP_TYPE"));
				sql.setString(i++, item_data.get("TOT_TRADE_AMT"));
				sql.setString(i++, item_data.get("ORG_MSG_SEND_DT"));
				
				sql.setString(i++, (String)data.get("TRAN_YMD"));
				sql.setString(i++, item_data.get("PRD_SKU_CODE"));

				logger.info( "▶ [TR_ITEM_SEQ] : "+ item_data.get("TR_ITEM_SEQ"));
				
				logger.info("CM_TRANDIVIDE_0081 ::: REG_YMDHMS" + item_data.get("REG_YMDHMS"));
				
				sql_debug1 = sql.debug(); // SQL debug
				logger.info("insert start");
				logger.info("[INFO] SQL_DEBUG::["+sql_debug1+"]");
				
				int sql_ret = executeUpdate(sql);
				
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0081", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
					logger.info("CM_TRANDIVIDE_0081 ::: trandivide_insert_error ret ["+sql_ret+"]");
				}
//				executeUpdate(sql);
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				logger.info("CM_TRANDIVIDE_0081 ::: sql_debug1 ["+sql_debug1+"]");
				
			} else {
				procErrLog("CM_TRANDIVIDE_0081", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
//			logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
//			logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0081", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("CM_TRANDIVIDE_0081 ::: SQLException ["+se.getMessage()+"]");
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			logger.info("[ERROR] SQL_DEBUG::["+sql_debug1+"]");
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0081", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("CM_TRANDIVIDE_0081 ::: Exception ["+e.getMessage()+"]");
//			logger.info("[SQL DEBUG 68] " + e);
			logger.info("[ERROR] SQL_DEBUG::["+sql_debug1+"]");
		}
		logger.info("CM_TRANDIVIDE_0081 ::: END");
		return ret;
	}
	
	
	//20171207 KSN SSG CON
	public int CM_TRANDIVIDE_0082(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data;
		
		try {
			logger.info("CM_TRANDIVIDE_0082::item Length::["+item.getBytes().length+"]");
			
			item_data = TranDivideUtil.getItemData("TRANDIVIDE_0082", item, cLog);
			
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				
				logger.info("CM_TRANDIVIDE_0082:::START");
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0082"));
				int i = 1;
				
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("COM_CD"));
				sql.setString(i++, (String)data.get("STORE_CD"));
				sql.setString(i++, (String)data.get("POS_NO"));
				sql.setString(i++, (String)data.get("TRAN_NO"));
				
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));
				sql.setString(i++, item_data.get("EVT_CD"));
				sql.setString(i++, item_data.get("EVT_NM"));
				sql.setString(i++, item_data.get("COUPON_NO"));
				sql.setString(i++, item_data.get("COUPON_TP"));
				
				sql.setString(i++, item_data.get("COUPON_AMT_TP"));
				sql.setString(i++, item_data.get("COUPON_AMT"));
				sql.setString(i++, item_data.get("COUPON_RM_AMT"));
				sql.setString(i++, item_data.get("COUPON_PLU_CD"));
				sql.setString(i++, item_data.get("START_DT"));
				
				sql.setString(i++, item_data.get("EXPIRE_DT"));
				sql.setString(i++, item_data.get("ISSUE_SYS"));
				sql.setString(i++, item_data.get("ISSUE_DT"));
				sql.setString(i++, item_data.get("ISSUE_TM"));
				sql.setString(i++, item_data.get("CP_MSG_01"));
				
				sql.setString(i++, item_data.get("CP_MSG_02"));
				sql.setString(i++, item_data.get("CP_MSG_03"));
				sql.setString(i++, item_data.get("CP_MSG_04"));
				sql.setString(i++, item_data.get("CP_MSG_05"));   
				sql.setString(i++, item_data.get("CP_MSG_06"));
				
				sql.setString(i++, item_data.get("CP_MSG_07"));
				sql.setString(i++, item_data.get("CP_MSG_08"));
				sql.setString(i++, item_data.get("CP_MSG_09"));
				sql.setString(i++, item_data.get("CP_MSG_10"));  
				sql.setString(i++, item_data.get("COUPON_USE_EXPR_AMT")); 
				
				sql.setString(i++, item_data.get("OTH_STR_ENBL_YN"));
				sql.setString(i++, item_data.get("CP_AMTMNG_YN"));
				
				sql_debug1 = sql.debug();
				
				logger.info( "▶ [TR_ITEM_SEQ] : "+ item_data.get("TR_ITEM_SEQ"));
				logger.info("[INFO] SQL_DEBUG::["+sql.debug()+"]");
				
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0082", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
			} else {
				procErrLog("CM_TRANDIVIDE_0082", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			procErrLog("CM_TRANDIVIDE_0082", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("[ERROR] SQL_DEBUG::["+sql_debug1+"]");
			
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0082", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[ERROR] SQL_DEBUG::["+sql_debug1+"]");
		}
		return ret;
	}
	
	
	//20171207 KSN SSG CON
	public int CM_TRANDIVIDE_0083(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data;
		
		try {
			logger.info("CM_TRANDIVIDE_0083::item Length::["+item.getBytes().length+"]");
			
			item_data = TranDivideUtil.getItemData("TRANDIVIDE_0083", item, cLog);
			
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				
				logger.info("CM_TRANDIVIDE_0083:::START");
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0083"));
				int i = 1;
				sql.setString(i++, sys_ymd);
				sql.setString(i++, (String)data.get("COM_CD"));
				sql.setString(i++, (String)data.get("STORE_CD"));
				sql.setString(i++, (String)data.get("POS_NO"));
				sql.setString(i++, (String)data.get("TRAN_NO"));
				
				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));
				sql.setString(i++, item_data.get("EVT_CD"));
				sql.setString(i++, item_data.get("COUPON_NO"));
				sql.setString(i++, item_data.get("COUPON_TP"));
				sql.setString(i++, item_data.get("COUPON_AMT_TP"));
				
				sql.setString(i++, item_data.get("TRADE_AMT"));
				sql.setString(i++, item_data.get("REMAIN_AMT"));
				sql.setString(i++, item_data.get("COUPON_PLU_CD"));
				sql.setString(i++, item_data.get("ISSUE_SYS"));
				sql.setString(i++, item_data.get("AUTH_NO"));
				
				sql.setString(i++, item_data.get("AUTH_DT"));
				sql.setString(i++, item_data.get("AUTH_TM"));
				sql.setString(i++, item_data.get("ORG_TRAN_YMD"));
				sql.setString(i++, item_data.get("ORG_STORE_CD"));
				sql.setString(i++, item_data.get("ORG_POS_NO"));
				
				sql.setString(i++, item_data.get("ORG_TRAN_NO"));   
				sql.setString(i++, item_data.get("ORG_AUTH_NO"));
				sql.setString(i++, item_data.get("ORG_AUTH_DT"));
				sql.setString(i++, item_data.get("ORG_AUTH_TM"));
				sql.setString(i++, (String)data.get("TRAN_YMD"));
				
				sql_debug1 = sql.debug();
				
				logger.info( "▶ [TR_ITEM_SEQ] : "+ item_data.get("TR_ITEM_SEQ"));
				logger.info("[INFO] SQL_DEBUG::["+sql.debug()+"]");
				
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0083", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				
			} else {
				procErrLog("CM_TRANDIVIDE_0083", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			procErrLog("CM_TRANDIVIDE_0083", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			logger.info("[ERROR] SQL_DEBUG::["+sql_debug1+"]");
			
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0083", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			logger.info("[ERROR] SQL_DEBUG::["+sql_debug1+"]");
		}
		return ret;
	}
	
	/**
	 * 한진 송수하인 정보
	 * @since 20180213
	 * @param sql
	 * @param loop_num
	 * @param data
	 * @param item
	 * @param sys_ymd
	 * @param cLog
	 * @return
	 */
	public int CM_TRANDIVIDE_0084(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data;

		try {
			logger.info("CM_TRANDIVIDE_0084::item Length::[" + item.getBytes().length + "]");

			item_data = TranDivideUtil.getItemData("TRANDIVIDE_0084", item, cLog);

			if (item_data != null) {
				if (sql != null) {
					sql.close();
				}

				logger.info("CM_TRANDIVIDE_0084:::START");

				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0084"));

				int i = 1;

				sql.setString(i++, sys_ymd);							// TRAN_YMD (거래일자)
				sql.setString(i++, (String)data.get("COM_CD"));			// COM_CD (회사코드)
				sql.setString(i++, (String)data.get("STORE_CD"));		// STORE_CD (점포코드)
				sql.setString(i++, (String)data.get("POS_NO"));			// POS_NO (포스번호)
				sql.setString(i++, (String)data.get("TRAN_NO"));		// TRAN_NO (거래번호)

				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ (명세순번)
				sql.setString(i++, item_data.get("PARCEL_CMP_TP"));		// PARCEL_CMP_TP (택배사구분 :: 01:CJ택배, 02:한진택배)
				sql.setString(i++, item_data.get("JOB_TYPE"));			// PARCEL_DELI_TP (배송구분 :: 01:일반택배, 02:퀵택배)
				sql.setString(i++, item_data.get("PAY_DTL_ID"));		// PARCEL_PAY_TP (결제구분 :: 1:현금선불, 2:착불, 3:신용카드선불)
				sql.setString(i++, item_data.get("TRAN_TP"));			// TRAN_TP (거래유형 :: 01:접수, 02:환불)
				sql.setString(i++, item_data.get("ENP_DIV"));			// PARCEL_ENP_DIV (택배구분 :: 1:국내, 2:국제, 3:반품, 4:예약)
				sql.setString(i++, item_data.get("INVC_TYPE"));			// PARCEL_TYPE (송장구분 :: 1:수기송장, 2:라벨송장)
				sql.setString(i++, item_data.get("PARCEL_CD"));			// PARCEL_CD (운송장번호)
				sql.setString(i++, item_data.get("TOT_AMT"));			// TOT_AMT (택배전체금액)
				sql.setString(i++, item_data.get("BASE_AMT"));			// BASE_AMT (기본운임금액)
				sql.setString(i++, item_data.get("PILOTAGE_AMT"));		// PILOTAGE_AMT (도선료금액)
				sql.setString(i++, item_data.get("ITEM_EXT_AMT"));		// ITEM_EXT_AMT (할증금액)
				sql.setString(i++, item_data.get("DC_AMT"));			// DC_AMT (할인금액)
				sql.setString(i++, item_data.get("CUST_NO"));			// CUST_NO (회원번호)
				sql.setString(i++, item_data.get("SND_ZIP"));			// SND_ZIP (송하인 우편번호)
				sql.setString(i++, item_data.get("SND_ADD1"));			// SND_ADD1 (송하인 동이상주소)
				sql.setString(i++, item_data.get("SND_ADD2"));			// SND_ADD2 (송하인 동미만주소)
				sql.setString(i++, item_data.get("SND_NAME"));			// SND_NAME (송하인 명)
				sql.setString(i++, item_data.get("SND_TEL"));			// SND_TEL (송하인 전화번호)
				sql.setString(i++, item_data.get("SND_HPH"));			// SND_HPH (송하인 휴대폰번호)
				sql.setString(i++, item_data.get("RCV_ZIP"));			// RCV_ZIP (수하인 우편번호)
				sql.setString(i++, item_data.get("RCV_ADD1"));			// RCV_ADD1 (수하인 동이상주소)
				sql.setString(i++, item_data.get("RCV_ADD2"));			// RCV_ADD2 (수하인 동미만주소)
				sql.setString(i++, item_data.get("RCV_NAME"));			// RCV_NAME (수하인 명)
				sql.setString(i++, item_data.get("RCV_TEL"));			// RCV_TEL (수하인 전화번호)
				sql.setString(i++, item_data.get("RCV_HPH"));			// RCV_HPH (수하인 휴대폰번호)

				logger.info("▶ [TR_ITEM_SEQ] : " + item_data.get("TR_ITEM_SEQ"));
				logger.info("CM_TRANDIVIDE_0084 ::: PARCEL_CD : " + item_data.get("PARCEL_CD"));

				sql_debug1 = sql.debug(); // SQL debug

				logger.info("[INFO] SQL_DEBUG::[" + sql_debug1 + "]");
				
				int sql_ret = executeUpdate(sql);

				if (sql_ret != 1) {
					ret = 9;

					procErrLog("CM_TRANDIVIDE_0084", "loop_num:" + loop_num, "trandivide_insert_error", data, cLog);
				}
			} else {
				procErrLog("CM_TRANDIVIDE_0084", "loop_num:" + loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			logger.info("▶ [SQLException ErrorCode] : " + se.getErrorCode());
			logger.info("▶ [SQLException ErrorMessage] : " + se.getMessage());

			procErrLog("CM_TRANDIVIDE_0084", "loop_num:" + loop_num, se.getMessage(), data, cLog);

			logger.info("[ERROR] SQL_DEBUG::[" + sql_debug1 + "]");

			if (se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0084", "loop_num:" + loop_num, e.getMessage(), data, cLog);

			logger.info("[ERROR] SQL_DEBUG::[" + sql_debug1 + "]");
		}

		logger.info("CM_TRANDIVIDE_0084:::END");

		return ret;
	}
	
	/**
	 * 모바일 문화상품권
	 * @since 20180629
	 * @param sql
	 * @param loop_num
	 * @param data
	 * @param item
	 * @param sys_ymd
	 * @param cLog
	 * @return
	 */
	public int CM_TRANDIVIDE_0087(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data;
 
		try {
			logger.info("CM_TRANDIVIDE_0087::item Length::[" + item.getBytes().length + "]");

			item_data = TranDivideUtil.getItemData("TRANDIVIDE_0087", item, cLog); 

			if (item_data != null) {
				if (sql != null) {
					sql.close();
				}

				logger.info("CM_TRANDIVIDE_0087:::START");

				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0087"));

				int i = 1;

				
				
				sql.setString(i++, sys_ymd);							// TRAN_YMD (거래일자)
				
				sql.setString(i++, (String)data.get("COM_CD"));			// COM_CD (회사코드)
				sql.setString(i++, (String)data.get("STORE_CD"));		// STORE_CD (점포코드)
				sql.setString(i++, (String)data.get("POS_NO"));			// POS_NO (포스번호)
				sql.setString(i++, (String)data.get("TRAN_NO"));		// TRAN_NO (거래번호)

				sql.setString(i++, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ (명세순번)
				sql.setString(i++, item_data.get("TRAN_TP"          ));		// 취소구분 0사용 1취소       
				sql.setString(i++, item_data.get("PIN_NO"           ));		// 모바일 문화 상품권 바코드  
				sql.setString(i++, item_data.get("PIN_FACE_AMT"     ));		// 액면가                     
				sql.setString(i++, item_data.get("PIN_TRADE_AMT"    ));		// 거래금액                   
				sql.setString(i++, item_data.get("PIN_BAL_AMT"      ));		// 액면가                     
				sql.setString(i++, item_data.get("CUL_TRACE_NO"     ));		// 컬처랜드거래번호(UNIQ)     
				sql.setString(i++, item_data.get("TRACE_NO"         ));		// 사용처 거래번호(UNIQ)      
				sql.setString(i++, item_data.get("REQ_DY"           ));		// 요청일자                   
				sql.setString(i++, item_data.get("REQ_TM"           ));		// 요청시간                   
				sql.setString(i++, item_data.get("INPUTTYPE"        ));		// 입력구분                   
				sql.setString(i++, item_data.get("ITEM_NM"          ));		// 구매상품명                 
				sql.setString(i++, item_data.get("RESP_DY"          ));		// 승인일자                   
				sql.setString(i++, item_data.get("RESP_TM"          ));		// 승인시간                   
				sql.setString(i++, item_data.get("ORG_TRAN_YMD"     ));		// 원거래 일                  
				sql.setString(i++, item_data.get("ORG_STORE_CD"     ));		// 원거래 점포코드            
				sql.setString(i++, item_data.get("ORG_POS_NO"       ));		// 원거래 포스번호            
				sql.setString(i++, item_data.get("ORG_TRAN_NO"      ));		// 원거래 거래번호            
				sql.setString(i++, item_data.get("ORG_CUL_TRACE_NO" ));		// 원거래 컬처랜드 거래번호   
				sql.setString(i++, item_data.get("ORG_TRACE_NO"     ));		// 원거래 사용처 거래번호     
				sql.setString(i++, item_data.get("ORG_RESP_DT"      ));		// 원거래 승인일자            
				sql.setString(i++, item_data.get("ORG_RESP_TM"      ));		// 원거래 승인시간            
				sql.setString(i++, (String)data.get("TRAN_YMD"));
				
				logger.info("▶ [TR_ITEM_SEQ] : " + item_data.get("TR_ITEM_SEQ"));
				//logger.info("CM_TRANDIVIDE_0087 ::: PARCEL_CD : " + item_data.get("PARCEL_CD"));
				logger.info("▶ [ sys_ymd           ] : " +  sys_ymd           );
				logger.info("▶ [COM_CD             ] : " + item_data.get("COM_CD"           ));
				logger.info("▶ [STORE_CD           ] : " + item_data.get("STORE_CD"         ));
				logger.info("▶ [POS_NO             ] : " + item_data.get("POS_NO"           ));
				logger.info("▶ [TRAN_NO            ] : " + item_data.get("TRAN_NO"          ));
				logger.info("▶ [TR_ITEM_SEQ        ] : " + item_data.get("TR_ITEM_SEQ"      ));
				logger.info("▶ [TRAN_TP            ] : " + item_data.get("TRAN_TP"          ));
				logger.info("▶ [PIN_NO             ] : " + item_data.get("PIN_NO"           ));
				logger.info("▶ [PIN_FACE_AMT       ] : " + item_data.get("PIN_FACE_AMT"     ));
				logger.info("▶ [PIN_TRADE_AMT      ] : " + item_data.get("PIN_TRADE_AMT"    ));
				logger.info("▶ [PIN_BAL_AMT        ] : " + item_data.get("PIN_BAL_AMT"      ));
				logger.info("▶ [CUL_TRACE_NO       ] : " + item_data.get("CUL_TRACE_NO"     ));
				logger.info("▶ [TRACE_NO           ] : " + item_data.get("TRACE_NO"         ));
				logger.info("▶ [REQ_DY             ] : " + item_data.get("REQ_DY"           ));
				logger.info("▶ [REQ_TM             ] : " + item_data.get("REQ_TM"           ));
				logger.info("▶ [INPUTTYPE          ] : " + item_data.get("INPUTTYPE"        ));
				logger.info("▶ [ITEM_NM            ] : " + item_data.get("ITEM_NM"          ));
				logger.info("▶ [RESP_DY            ] : " + item_data.get("RESP_DY"          ));
				logger.info("▶ [RESP_TM            ] : " + item_data.get("RESP_TM"          ));
				logger.info("▶ [ORG_TRAN_YMD       ] : " + item_data.get("ORG_TRAN_YMD"     ));
				logger.info("▶ [ORG_STORE_CD       ] : " + item_data.get("ORG_STORE_CD"     ));
				logger.info("▶ [ORG_POS_NO         ] : " + item_data.get("ORG_POS_NO"       ));
				logger.info("▶ [ORG_TRAN_NO        ] : " + item_data.get("ORG_TRAN_NO"      ));
				logger.info("▶ [ORG_CUL_TRACE_NO   ] : " + item_data.get("ORG_CUL_TRACE_NO" ));
				logger.info("▶ [ORG_TRACE_NO       ] : " + item_data.get("ORG_TRACE_NO"     ));
				logger.info("▶ [ORG_RESP_DT        ] : " + item_data.get("ORG_RESP_DT"      ));
				logger.info("▶ [ORG_RESP_TM        ] : " + item_data.get("ORG_RESP_TM"      ));
				logger.info("▶ [TRAN_YMD           ] : " + item_data.get("TRAN_YMD"         ));
				
				

				
				int sql_ret = executeUpdate(sql);
				sql_debug1 = sql.debug(); // SQL debug
				logger.info("[INFO] SQL_DEBUG::[" + sql_debug1 + "]");
				
				if (sql_ret != 1) {
					ret = 9;

					procErrLog("CM_TRANDIVIDE_0087", "loop_num:" + loop_num, "trandivide_insert_error", data, cLog);
				}
			} else {
				procErrLog("CM_TRANDIVIDE_0087", "loop_num:" + loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			logger.info("▶ [SQLException ErrorCode] : " + se.getErrorCode());
			logger.info("▶ [SQLException ErrorMessage] : " + se.getMessage());

			procErrLog("CM_TRANDIVIDE_0087", "loop_num:" + loop_num, se.getMessage(), data, cLog);

			logger.info("[ERROR] SQL_DEBUG::[" + sql_debug1 + "]");

			if (se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0087", "loop_num:" + loop_num, e.getMessage(), data, cLog);

			logger.info("[ERROR] SQL_DEBUG::[" + sql_debug1 + "]");
		}

		logger.info("CM_TRANDIVIDE_0087:::END");

		return ret;
	}
	
	/**
	 * 카카오페이
	 * @since 20180903
	 * @param sql
	 * @param loop_num
	 * @param data
	 * @param item
	 * @param sys_ymd
	 * @param cLog
	 * @return
	 */
	
	public int CM_TRANDIVIDE_0088(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data;
		try {
			logger.info("item.getBytes().length [" + item.getBytes().length + "]");
			logger.info( "item.getBytes().length [" + item.getBytes().length + "]");
			if(item.getBytes().length == 326){
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0088_NEW", item, cLog);
			}else if(item.getBytes().length == 301){
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0088", item, cLog);
				item_data.put("CARD_BUY_CD", "0");
				item_data.put("VAN_TID", "0");
			}else{
				item_data = TranDivideUtil.getItemData("TRANDIVIDE_0088_OLD", item, cLog);
				item_data.put("CARD_KIND", "0");
			}

			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0088"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd")		);
				sql.setString(3, (String)data.get("store_cd")	);
				sql.setString(4, (String)data.get("pos_no")		);
				sql.setString(5, (String)data.get("tran_no")	);
				sql.setString(6,  item_data.get("TR_ITEM_SEQ"			));		// ITEM_SEQ
				sql.setString(7,  item_data.get("PAY_AMT"				)); 		// PAY_AMT
				sql.setString(8,  item_data.get("CARD_INPUT_ID"			)); 		// CARD_INPUT_ID
				sql.setString(9,  item_data.get("CARD_DATA_VISIBLE"		)); 		// CARD_DATA
				sql.setString(10, item_data.get("CARD_DATA"				)); 		//CARD_DATA_ENCODED
				sql.setString(11, item_data.get("INSTMNT_PRD"			));		// INSTMNT_PRD
				sql.setString(12, item_data.get("AGREE_ID"				)); 		// AGREE_ID
				sql.setString(13, item_data.get("AGREE_NO"				)); 		// AGREE_NO
				sql.setString(14, item_data.get("AGREE_YMDHMS"			)); 		// AGREE_YMDHMS
				sql.setString(15, item_data.get("CARD_CORP_CD"			));		// CARD_CORP_CD
				sql.setString(16, item_data.get("CARD_CORP_NM"			));		// CARD_CORP_NM
				sql.setString(17, item_data.get("FRIEND_NO"				)); 		// FRIEND_NO
				sql.setString(18, item_data.get("ORG_YMD"				)); 		// ORG_YMD
				sql.setString(19, item_data.get("ORG_AGREE_NO"			)); 		// ORG_AGREE_NO
				sql.setString(20, item_data.get("SERVICE_AMT"			)); 		// SERVICE_AMT
				sql.setString(21, (String)data.get("tran_ymd"			));
				sql.setString(22, item_data.get("CARD_KIND"				));  // CUP_YN 0:일반카드,  1:은련카드,  3:BCPAY
				sql.setString(23, item_data.get("CARD_BUY_CD"			)); //매입사코드  
				sql.setString(24, item_data.get("VAN_TID"				));  //VAN사 TID
				
				//테스트 이후 제외 할것 KKKK
//		        logger.info("▶ [TR_ITEM_SEQ      ] : " + item_data.get("TR_ITEM_SEQ"       ));
//		        logger.info("▶ [PAY_AMT          ] : " + item_data.get("PAY_AMT"           ));
//		        logger.info("▶ [CARD_INPUT_ID    ] : " + item_data.get("CARD_INPUT_ID"     ));
//		        logger.info("▶ [CARD_DATA_VISIBLE] : " + item_data.get("CARD_DATA_VISIBLE" ));
//		        logger.info("▶ [CARD_DATA        ] : " + item_data.get("CARD_DATA"         ));
//		        logger.info("▶ [INSTMNT_PRD      ] : " + item_data.get("INSTMNT_PRD"       ));
//		        logger.info("▶ [AGREE_ID         ] : " + item_data.get("AGREE_ID"          ));
//		        logger.info("▶ [AGREE_NO         ] : " + item_data.get("AGREE_NO"          ));
//		        logger.info("▶ [AGREE_YMDHMS     ] : " + item_data.get("AGREE_YMDHMS"      ));
//		        logger.info("▶ [CARD_CORP_CD     ] : " + item_data.get("CARD_CORP_CD"      ));
//		        logger.info("▶ [CARD_CORP_NM     ] : " + item_data.get("CARD_CORP_NM"      ));
//		        logger.info("▶ [FRIEND_NO        ] : " + item_data.get("FRIEND_NO"         ));
//		        logger.info("▶ [ORG_YMD          ] : " + item_data.get("ORG_YMD"           ));
//		        logger.info("▶ [ORG_AGREE_NO     ] : " + item_data.get("ORG_AGREE_NO"      ));
//		        logger.info("▶ [SERVICE_AMT      ] : " + item_data.get("SERVICE_AMT"       ));
//		        logger.info("▶ [CARD_KIND        ] : " + item_data.get("CARD_KIND"         ));
//		        logger.info("▶ [CARD_BUY_CD      ] : " + item_data.get("CARD_BUY_CD"       ));
//		        logger.info("▶ [VAN_TID          ] : " + item_data.get("VAN_TID"           ));
//		        logger.info("▶ [tran_ymd         ] : " + (String)data.get("tran_ymd" ));
//		        logger.info("▶ [com_cd           ] : " + (String)data.get("com_cd"   ));
//		        logger.info("▶ [store_cd         ] : " + (String)data.get("store_cd" ));
//		        logger.info("▶ [pos_no           ] : " + (String)data.get("pos_no"   ));
//		        logger.info("▶ [tran_no          ] : " + (String)data.get("tran_no"  ));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0088", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				//테스트 이후 로그 제외 할것 KKKK
//				logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0088", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0088", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0088", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	
	public int CM_TRANDIVIDE_0092(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_0092", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0092"));
				sql.setString(1, item_data.get("V_TRAN_YMD"));
				sql.setString(2, item_data.get("V_STORE_CD"));
				sql.setString(3, item_data.get("V_PDA_NO"));
				sql.setString(4, item_data.get("V_PDATRAN_NO"));
				sql.setString(5, (String)data.get("com_cd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_0092", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_0092", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_0092", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0092", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	// onebarcode
	public int CM_TRANDIVIDE_0093(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		Map<String, String> item_data;
		try {
			item_data = TranDivideUtil.getItemData("TRANDIVIDE_0093", item, cLog);

			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_0093"));
				
				sql.setString(1, sys_ymd   );
				sql.setString(2, (String)data.get("com_cd")		);
				sql.setString(3, (String)data.get("store_cd")	);
				sql.setString(4, (String)data.get("pos_no")		);
				sql.setString(5, (String)data.get("tran_no")	);
				sql.setString(6,  item_data.get("ITEM_SEQ"			));		// ITEM_SEQ
				sql.setString(7,  item_data.get("ENC_ONE_BARCODE")); 		// ENC_ONE_BARCODE
				sql.setString(8, sys_ymd);
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("TRANDIVIDE_0093", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
				//테스트 이후 로그 제외 할것 KKKK
//				logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("TRANDIVIDE_0093_1", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("TRANDIVIDE_0093", "loop_num:"+loop_num, se.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_0093", "loop_num:"+loop_num, e.getMessage(), data, cLog);
			//logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_6060(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_6060", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_6060"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID"));
				sql.setString(8, (String)data.get("tran_ymd")+(String)data.get("tran_hms"));
				sql.setString(9, item_data.get("V_ROD_CD"));
				sql.setString(10, item_data.get("V_ROD_NM"));
				
				sql.setString(11, item_data.get("V_ROD_AMT")); 	
				sql.setString(12, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_6060", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_6060", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_6060", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_6060", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_7070(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_7070", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_7070"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID"));
				sql.setString(8, (String)data.get("tran_ymd"));
				sql.setString(9, (String)data.get("tran_hms"));
				sql.setString(10, item_data.get("V_EXECUTE_TY"));
				sql.setString(11, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_7070", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_7070", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_7070", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_7070", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_7074(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_7074", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_7074"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("V_EXACT_CD"));
				sql.setString(8, item_data.get("V_EXACT_QTY"));
				sql.setString(9, item_data.get("V_EXACT_AMT"));
				sql.setString(10, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_7074", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_7074", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_7074", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_7074", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_7075(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_7075", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				// DELETE
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_7075_1"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("store_cd"));
				sql.setString(3, (String)data.get("pos_no"));
				sql.setString(4, (String)data.get("tran_no"));
				
				sql_debug1 = sql.debug(); // SQL debug
				executeUpdate(sql);
				
//				logger.info("[SQL DEBUG DELETE] " + sql_debug1);
				
				if(sql != null) {
					sql.close();
				}
				// INSERT
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_7075_2"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("V_EXACT_CD"));
				sql.setString(8, item_data.get("V_EXACT_QTY"));
				sql.setString(9, item_data.get("V_EXACT_AMT"));
				sql.setString(10, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_7075", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
//				logger.info("[SQL DEBUG INSERT] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_7075", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_7075", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_7075", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_7076(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_7076", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_7076"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, (String)data.get("tran_kind"));	// IN_TRAN_ID
				sql.setString(8, item_data.get("V_EXACT_CD"));
				sql.setString(9, item_data.get("V_EXACT_QTY"));
				sql.setString(10, item_data.get("V_EXACT_AMT"));
				sql.setString(11, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_7076", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_7076", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_7076", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_7076", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_7077(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_7077", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_7077"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("V_EXACT_CD"));
				sql.setString(8, item_data.get("V_EXACT_QTY"));
				sql.setString(9, item_data.get("V_EXACT_AMT"));
				sql.setString(10, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_7077", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
//				logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_7077", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_7077", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_7077", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_8080(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_8080", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_8080"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("V_WORKER_PLU_CD"));
				sql.setString(8, item_data.get("V_AOL_YMDHMS"));
				sql.setString(9, item_data.get("V_AOL_ID"));
				sql.setString(10, item_data.get("V_AOL_NM"));
				sql.setString(11, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_8080", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_8080", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_8080", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_8080", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_9091(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_9091", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_9091"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("TR_ITEM_ID").substring(0, 1)); // V_TR_ITEM_DTL_ID
				sql.setString(8, item_data.get("V_SALE_DT"));
				sql.setString(9, item_data.get("V_SALE_TIME"));
				sql.setString(10, item_data.get("V_CASHIER_NO"));
				sql.setString(11, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_9091", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_9091", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_9091", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_9091", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_9099(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_9099", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_9099"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, (String)data.get("tran_kind"));	// IN_TRAN_ID
				sql.setString(8, item_data.get("V_MNTY_MGT_YMDHMS"));
				sql.setString(9, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_9099", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_9099", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_9099", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_9099", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_2000(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_2000", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_2000_1"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("V_SYS_YMDHMS"));
				sql.setString(7, item_data.get("V_TRAN_TYPE"));
				sql.setString(8, item_data.get("V_TRAN_KIND"));
				sql.setString(9, item_data.get("V_PMOD_YN"));
				sql.setString(10, item_data.get("V_STOP_YN"));
				sql.setString(11, item_data.get("V_RFND_YN"));
				sql.setString(12, item_data.get("V_OP_NO"));
				sql.setString(13, item_data.get("V_ORG_TRAN_YMD"));
				sql.setString(14, item_data.get("V_ORG_STORE_CD"));
				sql.setString(15, item_data.get("V_ORG_POS_NO"));
				sql.setString(16, item_data.get("V_ORG_TRAN_NO"));
				sql.setString(17, item_data.get("V_ORG_RES_ID"));
				sql.setString(18, item_data.get("V_APP_OP_NO"));
				sql.setString(19, item_data.get("V_CUST_CLS_ID"));
				sql.setString(20, item_data.get("V_CUST_COUNT"));
				sql.setString(21, item_data.get("V_ORDER_TYPE"));
				sql.setString(22, item_data.get("V_FLOOR_CD"));
				sql.setString(23, item_data.get("V_TABLE_NO"));
				sql.setString(24, item_data.get("V_GSALE_AMT"));
				sql.setString(25, item_data.get("V_GDC_AMT"));
				sql.setString(26, item_data.get("V_NSALE_AMT"));
				sql.setString(27, item_data.get("V_SCHARGE_AMT"));
				sql.setString(28, item_data.get("V_SYS_YMDHMS"));
				sql.setString(29, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_2000", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
				// 반품일 경우 원거래에 반품 플래그 세팅
				if("1".equals((String)data.get("tran_type")) && item_data.get("V_ORG_TRAN_YMD") != null && !"".equals(item_data.get("V_ORG_TRAN_YMD").trim())) {
					if(sql != null) {
						sql.close();
					}
					// UPDATE STTRP010DT
					sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_2000_2"));
					sql.setString(1, item_data.get("V_ORG_TRAN_YMD"));
					sql.setString(2, (String)data.get("com_cd"));
					sql.setString(3, item_data.get("V_ORG_STORE_CD"));
					sql.setString(4, item_data.get("V_ORG_POS_NO"));
					sql.setString(5, item_data.get("V_ORG_TRAN_NO"));
					
					sql_debug1 = sql.debug(); // SQL debug
					executeUpdate(sql);
					
					//logger.info("[SQL DEBUG 1] " + sql_debug1);
					
					//-----------------------------------------------------------------------//
					
					if(sql != null) {
						sql.close();
					}
					// UPDATE STTRP130DT
					sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_2000_3"));
					sql.setString(1, item_data.get("V_ORG_TRAN_YMD"));
					sql.setString(2, (String)data.get("com_cd"));
					sql.setString(3, item_data.get("V_ORG_STORE_CD"));
					sql.setString(4, item_data.get("V_ORG_POS_NO"));
					sql.setString(5, item_data.get("V_ORG_TRAN_NO"));
					
					sql_debug1 = sql.debug(); // SQL debug
					executeUpdate(sql);
					
					//logger.info("[SQL DEBUG 1] " + sql_debug1);
				}
			} else {
				procErrLog("CM_TRANDIVIDE_2000", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_2000", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_2000", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public int CM_TRANDIVIDE_2001(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_2001", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_2001"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, item_data.get("V_ASGN_CANCEL_YN"));
				sql.setString(8, item_data.get("V_ITEM_CD"));
				sql.setString(9, item_data.get("V_PLU_CD"));
				sql.setString(10, item_data.get("V_PLU_FLAG"));
				sql.setString(11, item_data.get("V_CATE_ID"));
				sql.setString(12, item_data.get("V_GRP_ID"));
				sql.setString(13, item_data.get("V_SGRP_ID"));
				sql.setString(14, item_data.get("V_BRAND_ID"));
				sql.setString(15, item_data.get("V_ITEM_ID"));
				sql.setString(16, item_data.get("V_ITEM_NM"));
				sql.setString(17, item_data.get("V_SALE_QTY"));
				sql.setString(18, item_data.get("V_SALE_UPRC"));
				sql.setString(19, item_data.get("V_SALE_AMT"));
				sql.setString(20, item_data.get("V_PRICE_CHG_ID"));
				sql.setString(21, item_data.get("V_PRICE_CHG_UPRC"));
				sql.setString(22, item_data.get("V_ITEM_INPUT_ID"));
				sql.setString(23, item_data.get("V_SCAN_CD"));
				sql.setString(24, item_data.get("V_BTL_SUM_AMT"));
				sql.setString(25, item_data.get("V_BTL_PLU_CD"));
				sql.setString(26, item_data.get("V_ITEM_TAX_ID"));
				sql.setString(27, item_data.get("V_ITEM_TAX_VALUE"));
				sql.setString(28, item_data.get("V_RECT_AMT"));
				sql.setString(29, item_data.get("V_POS_DC_ID"));
				sql.setString(30, item_data.get("V_POS_DC_RATE"));
				sql.setString(31, item_data.get("V_POS_DC_AMT"));
				sql.setString(32, item_data.get("V_EVT_DC_QTY"));
				sql.setString(33, item_data.get("V_EVT_DC_AMT"));
				sql.setString(34, item_data.get("V_CO_DC_ID"));
				sql.setString(35, item_data.get("V_CO_DC_QTY"));
				sql.setString(36, item_data.get("V_CO_DC_AMT"));
				sql.setString(37, item_data.get("V_SALE_UNIT_QTY"));
				sql.setString(38, item_data.get("V_SCRAP_RES_ID"));
				sql.setString(39, item_data.get("V_SERVICE_FLAG"));
				sql.setString(40, item_data.get("V_PACK_FLAG"));
				sql.setString(41, (String)data.get("tran_ymd"));
				
				sql_debug1 = sql.debug(); // SQL debug
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_2001", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_2001", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_2001", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_2001", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}	
	public int CM_TRANDIVIDE_4001(SqlWrapper sql, int loop_num, Map<Object, Object> data, String item, String sys_ymd, COMMLog cLog) {
		int ret = 0;
		String sql_debug1 = "";
		try {
			Map<String, String> item_data = TranDivideUtil.getItemData("TRANDIVIDE_4001", item, cLog);
			if(item_data != null) {
				if(sql != null) {
					sql.close();
				}

				//logger.info("item_data.toString() [" + item_data.toString() +  "]");
				
				sql.put(findQuery("tran-divide", "CM_TRANDIVIDE_4001"));
				sql.setString(1, sys_ymd);
				sql.setString(2, (String)data.get("com_cd"));
				sql.setString(3, (String)data.get("store_cd"));
				sql.setString(4, (String)data.get("pos_no"));
				sql.setString(5, (String)data.get("tran_no"));
				
				sql.setString(6, item_data.get("TR_ITEM_SEQ"));		// ITEM_SEQ
				sql.setString(7, (String)data.get("tran_kind"));  // IN_TRAN_ID
				sql.setString(8, (String)item_data.get("V_ITEM_ID"));  // V_ITEM_ID
				sql.setString(9, (String)item_data.get("V_PLU_CD"));  // V_PLU_CD
				sql.setString(10, (String)item_data.get("V_ITEM_CD"));  // V_ITEM_CD
				
				sql.setString(11, (String)item_data.get("V_SALE_QTY"));  // V_SALE_QTY
				sql.setString(12, (String)item_data.get("V_SALE_UPRC"));  // V_SALE_UPRC
				sql.setString(13, item_data.get("V_SALE_AMT"));  // V_SALE_AMT
				sql.setString(14, (String)data.get("tran_ymd"));  // IN_TRAN_YMD
				sql.setString(15, item_data.get("V_ASGN_CANCEL_YN"));  // V_SALE_AMT
				
				sql_debug1 = sql.debug(); // SQL debug

				//logger.info("sql_debug1.toString() [" + sql_debug1.toString() +  "]");
				
				int sql_ret = executeUpdate(sql);
				if(sql_ret != 1) {
					ret = 9;
					procErrLog("CM_TRANDIVIDE_4001", "loop_num:"+loop_num, "trandivide_insert_error", data, cLog);
				}
//				executeUpdate(sql);
				
				//logger.info("[SQL DEBUG 1] " + sql_debug1);
				
			} else {
				procErrLog("CM_TRANDIVIDE_4001", "loop_num:"+loop_num, "item_data => null", data, cLog);
				ret = 9;
			}
		} catch(SQLException se) { 	
			//logger.info( "▶ [SQLException ErrorCode] : "+ se.getErrorCode());
			//logger.info( "▶ [SQLException ErrorMessage] : "+ se.getMessage());
			procErrLog("CM_TRANDIVIDE_4001", "loop_num:"+loop_num, se.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
			if(se.getErrorCode() == 1) { // ORA-00001: 무결성 제약 조건(SYSTEM.110DT_PK) 위배
				ret = 99;
			} else {
				ret = 9;
			}
		} catch(Exception e) {
			ret = 9;
			procErrLog("CM_TRANDIVIDE_4001", "loop_num:"+loop_num, e.getMessage(), data, cLog);
//			logger.info("[SQL DEBUG 1] " + sql_debug1);
		}
		
		return ret;
	}
	
	public void procErrLog(String level1, String level2, String eMsg, Map<Object, Object> data, COMMLog cLog) {
		logger.info("[ERROR on ] " + level1 + (level2==null||"".equals(level2)?"":" / "+level2));
		logger.info("[ERROR] tran_ymd : " + (String)data.get("tran_ymd"));
		logger.info("[ERROR] store_cd : " + (String)data.get("store_cd"));
		logger.info("[ERROR] pos_no : " + (String)data.get("pos_no"));
		logger.info("[ERROR] tran_no : " + (String)data.get("tran_no"));
		logger.info("[ERROR] Msg : " + eMsg);
	}
	
	public void updTranDivideFlag(String result, Map<Object, Object> data, COMMLog cLog) {
		String sql_debug = null;
		
		connect("CMGNS"); // DB Connection
		try {
			begin(); // TRANSACTION = true
			SqlWrapper sql = new SqlWrapper();
			sql.put(findQuery("tran-divide", "UPD_TRANDIVIDE_FLAG"));
			sql.setString(1,   "PK".equals(result)?"3":result);
			sql.setString(2,   (String)data.get("tran_ymd"));
			sql.setString(3,   (String)data.get("com_cd"));
			sql.setString(4,   (String)data.get("store_cd"));
			sql.setString(5,   (String)data.get("pos_no"));
			sql.setString(6,   (String)data.get("tran_no"));
			sql.setString(7,   (String)data.get("tran_type"));
			sql.setString(8,   (String)data.get("tran_kind"));
			sql_debug = sql.debug(); // SQL debug
			executeUpdate(sql);
			
		} catch(Exception e) {
			logger.info("[ERROR] " + e);
//			logger.info("[SQL DEBUG] " + sql_debug);
			rollback();
		} finally {
			end();
		}
	}
	
	public void updTranDivide00Flag(String result, Map<Object, Object> data, COMMLog cLog) {
		String sql_debug = null;
		
		connect("CMGNS"); // DB Connection
		try {
			begin(); // TRANSACTION = true
			SqlWrapper sql = new SqlWrapper();
			sql.put(findQuery("tran-divide", "UPD_PROC_ID_STTRP110DT"));
			sql.setString(1,   (String)data.get("tran_ymd"));
			sql.setString(2,   (String)data.get("com_cd"));
			sql.setString(3,   (String)data.get("store_cd"));
			sql.setString(4,   (String)data.get("pos_no"));
			sql.setString(5,   (String)data.get("tran_no"));
			sql_debug = sql.debug(); // SQL debug
			executeUpdate(sql);
			
		} catch(Exception e) {
			logger.info("[ERROR] " + e);
//			logger.info("[SQL DEBUG] " + sql_debug);
			rollback();
		} finally {
			end();
		}
	}

}
