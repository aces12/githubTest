package biz.cms_TranDivide;

import java.util.HashMap;
import java.util.Map;

import biz.comm.COMMLog;

public class TranDivideUtil {
	
	static Map<String, String> getItemData(String defName, String item, COMMLog cLog) throws Exception {
		Map<String, String> item_data;
		Object[][] Rules = TranDivide_Define.get(defName);
		if(Rules != null) {
			item_data = new HashMap<String, String>();
			byte[] b = item.getBytes("MS949");
			int offset = 0;
			String key = "";
			String val = "";
			for(Object[] def : Rules){
				key = (String)def[0];
				val = new String(b, offset, (Integer)def[1], "MS949");
				item_data.put(key, val);
				offset += (Integer)def[1];
			}
			// 길이 오류 체크
			if(b.length == Integer.parseInt(item_data.get("ITEM_LEN"))) {
				return item_data;
			} else {
				cLog.CommLogger("[TranDivideUtil / getItemData] : Wrong Item length");
				return null;
			}
		} else {
			cLog.CommLogger("[TranDivideUtil / getItemData] : Not Define Rules");
			return null;
		}
	}

}
