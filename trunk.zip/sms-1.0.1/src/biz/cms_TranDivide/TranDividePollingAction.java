package biz.cms_TranDivide;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

public class TranDividePollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(TranDividePollingAction.class);
	private COMMLog cLog = new COMMLog();

	@Override
	public void execute(String actionMode) {
		try {
			cLog.setbizLogger(logger);
			//cLog.execute("LogForTranDivide");
			
			// DAO
			TranDivideDAO dao = new TranDivideDAO();
			
			List<Map<Object, Object>> divide_list = dao.selDivideList(cLog);
			
			for(Map<Object, Object> data : divide_list){
				dao.updTranDivideFlag("8", data, cLog);
			}

			if (divide_list.size() > 0) {
				for(Map<Object, Object> data : divide_list) {
					SP_TRANDIVIDE(data, dao);
				}
			}
			
		} catch (Exception e) {
			logger.info("[ERROR] Exception : " + e);
		}
		
	}
	
	private void SP_TRANDIVIDE(Map<Object, Object> data, TranDivideDAO dao) {
		logger.error("tran_ymd[" + (String)data.get("tran_ymd")+"] "
		           +"store_cd["+(String)data.get("store_cd")+"] "
		           +"pos_no["+(String)data.get("pos_no")+"] "
		           +"tran_no["+(String)data.get("tran_no")+"] "
		           );
		if("00".equals((String)data.get("tran_kind")) || // 판매
		   "21".equals((String)data.get("tran_kind")) || // 공용기 회수
		   "31".equals((String)data.get("tran_kind")) || // 택배 서비스
		   "32".equals((String)data.get("tran_kind")) || // 선불 상품권(편의점 캐시)
		   "33".equals((String)data.get("tran_kind")) || // 교통 카드
		   "34".equals((String)data.get("tran_kind")) || // 휴대폰 충전
		   "35".equals((String)data.get("tran_kind")) || // 택배 집계 완료
		   "36".equals((String)data.get("tran_kind")) || // 스포츠토토
		   "37".equals((String)data.get("tran_kind")) || // SSG MONEY충전
		   "38".equals((String)data.get("tran_kind")) || // POSA카드
		   "39".equals((String)data.get("tran_kind")) || // 즉시환급 
		   "42".equals((String)data.get("tran_kind")) || // 청호이지캐쉬백 
		   "64".equals((String)data.get("tran_kind")) || // 외상 입금
		   "85".equals((String)data.get("tran_kind"))) { // 무인 택배 서비스(SCO, 20180220)
			// 연습모드 데이터 또는 거래중지 데이터 체크
			if("1".equals((String)data.get("pmod_yn"))){
				dao.updTranDivideFlag("1", data, cLog);
				close_cLog("pmod_yn / stop_yn", data);
			} else {
				dao.tranDivideModule("00", data, cLog);
			}
			
		} else if("10".equals((String)data.get("tran_kind"))) { // 점내 용도
			// 연습모드 데이터 또는 거래중지 데이터 체크
			if("1".equals((String)data.get("pmod_yn")) || "1".equals((String)data.get("stop_yn"))){
				dao.updTranDivideFlag("1", data, cLog);
				close_cLog("pmod_yn / stop_yn", data);
			} else {
				dao.tranDivideModule("10", data, cLog);
			}

			   
		} else if("20".equals((String)data.get("tran_kind"))) { // 폐기
			// 연습모드 데이터 또는 거래중지 데이터 체크
			if("1".equals((String)data.get("pmod_yn")) || "1".equals((String)data.get("stop_yn"))){
				dao.updTranDivideFlag("1", data, cLog);
				close_cLog("pmod_yn / stop_yn", data);
			} else {
				dao.tranDivideModule("20", data, cLog);
			}
			
		} else if("40".equals((String)data.get("tran_kind"))) { // 공병 회입/반출 2016.08.10 oht
			// 연습모드 데이터 또는 거래중지 데이터 체크
			if("1".equals((String)data.get("pmod_yn")) || "1".equals((String)data.get("stop_yn"))){
				dao.updTranDivideFlag("1", data, cLog);
				close_cLog("pmod_yn / stop_yn", data);
			} else {
				dao.tranDivideModule("40", data, cLog);
			}
			
		} else if("60".equals((String)data.get("tran_kind")) || // 준비금
				  "61".equals((String)data.get("tran_kind")) || // 입금
				  "62".equals((String)data.get("tran_kind")) || // 중간 입금
				  "63".equals((String)data.get("tran_kind"))) { // 출금
			// 연습모드 데이터 또는 거래중지 데이터 체크
			if("1".equals((String)data.get("pmod_yn")) || "1".equals((String)data.get("stop_yn"))){
				dao.updTranDivideFlag("1", data, cLog);
				close_cLog("pmod_yn / stop_yn", data);
			} else {
				dao.tranDivideModule("60", data, cLog);
			}
			
		} else if("70".equals((String)data.get("tran_kind")) || // 영업 개시
				  "71".equals((String)data.get("tran_kind")) || // 영업 종료
				  "72".equals((String)data.get("tran_kind")) || // 로그온
				  "73".equals((String)data.get("tran_kind")) || // 로그아웃
				  "74".equals((String)data.get("tran_kind")) || // 시재 입금
				  "75".equals((String)data.get("tran_kind")) || // 정산 내역
				  "76".equals((String)data.get("tran_kind")) || // 마감 입금 정산
				  "77".equals((String)data.get("tran_kind")) || // 인수 인계
				  "78".equals((String)data.get("tran_kind")) || // 마감 입금 정산(영업 종료)
				  "81".equals((String)data.get("tran_kind")) || // 마감 입금 정산(영업 종료)FC  //neo0531 
				  "79".equals((String)data.get("tran_kind"))) { // 시재 확인
			// 연습모드 데이터 또는 거래중지 데이터 체크
			if("1".equals((String)data.get("pmod_yn")) || "1".equals((String)data.get("stop_yn"))){
				dao.updTranDivideFlag("1", data, cLog);
				close_cLog("pmod_yn / stop_yn", data);
			} else {
				dao.tranDivideModule("70", data, cLog);
			}
			
		} else if("80".equals((String)data.get("tran_kind"))) { // 출퇴근
			// 연습모드 데이터 또는 거래중지 데이터 체크
			if("1".equals((String)data.get("pmod_yn")) || "1".equals((String)data.get("stop_yn"))){
				dao.updTranDivideFlag("1", data, cLog);
				close_cLog("pmod_yn / stop_yn", data);
			} else {
				dao.tranDivideModule("80", data, cLog);
			}
			
		} else if("91".equals((String)data.get("tran_kind")) || // 전자 서명
				  "99".equals((String)data.get("tran_kind"))) { // 저널 인쇄
			// 연습모드 데이터 또는 거래중지 데이터 체크
			if("1".equals((String)data.get("pmod_yn")) || "1".equals((String)data.get("stop_yn"))){
				dao.updTranDivideFlag("1", data, cLog);
				close_cLog("pmod_yn / stop_yn", data);
			} else {
				dao.tranDivideModule("90", data, cLog);
			}
			
		} else { // 처리 할 수 없는 전문
			// tran_kind ERROR 
			close_cLog("tran_kind ERROR", data);
		}
	}
	
	// 연습모드 데이터 또는 거래중지 데이터 체크
	private void checkPmodYnStopYn(String procNO, Map<Object, Object> data, TranDivideDAO dao) {
		if("1".equals((String)data.get("pmod_yn")) || "1".equals((String)data.get("stop_yn"))) {
			dao.updTranDivideFlag("1", data, cLog);
			close_cLog("pmod_yn / stop_yn", data);
		} else {
			dao.tranDivideModule(procNO, data, cLog);
		}
	}
	
	private void close_cLog(String confNM, Map<Object, Object> data) {
		/*
		cLog.CommLogger("---------- [END] SP_TRANDIVIDE ----------");
		if("SUCCESS".equals(confNM)) {
			cLog.close("END [SP_TRANDIVIDE Log]", "[SUCCESS]");
		} else {
			cLog.close("END [SP_TRANDIVIDE Log]", "..by [" + confNM + "] ..CHECK INFO : "+(String)data.get("tran_ymd")+"/"+(String)data.get("store_cd")+"/"+(String)data.get("pos_no")+"/"+(String)data.get("tran_no"));
		}
		*/
	}

}
