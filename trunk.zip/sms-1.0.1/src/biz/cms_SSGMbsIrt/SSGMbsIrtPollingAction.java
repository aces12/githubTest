package biz.cms_SSGMbsIrt;

import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;

import org.apache.log4j.Logger;

import sun.misc.BASE64Decoder;

import com.cyberpass.seed.Seed;

public class SSGMbsIrtPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(SSGMbsIrtPollingAction.class);
	
	public ActionSocket actSock = null;
	
	public static void main(String args[]) throws Exception {
		SSGMbsIrtPollingAction action = new SSGMbsIrtPollingAction();
		try {
			if (args == null || args.length < 1) {
				logger.info("------ args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			action.execute("1");
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(String actionMode) {
		String com_cd = "";
		String fcstr_id = "";
//		String smsPath = "";
//		String retMsg = "";
		String sendMsg = "";
		String recvBuf = "";
		String ip = "";
		StringBuffer sb = null;
		int port = 0;
		List<Object> list = null;
		try {
			com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			fcstr_id = PropertyUtil.findProperty("service-property", "SSGPOINT_FCSTR_ID");
//			smsPath = PropertyUtil.findProperty("stsys-property", "SMS_ROOT");
			
			ip = PropertyUtil.findProperty("communication-property", "SSGPOINT_SERVER_IP");
			port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGPOINT_SERVER_PORT"));
			
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode.equals("1") ) {
				actSock = new ActionSocket(new Socket(ip, port), (Filter)(new COMMConveyerFilter(COMMBiz.SSGPOINT_FILTER)));
				
				SSGMbsIrtDAO dao = new SSGMbsIrtDAO();
				SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
				
				Calendar calendar = new GregorianCalendar(Locale.KOREA);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String todayDate = sdf.format(calendar.getTime());
				
				// 오늘 일자 추후적립 batch가 돌았는지 확인
				list = dao.selSVCFILEDAILY(todayDate, "SSG", "02", com_cd);
				if( list.size() > 0 ) return;
				
				HashMap<String, String> h = new HashMap<String, String>();
				h.put("COM_CD", com_cd);
				h.put("STD_YMD", todayDate);
				h.put("SVC_ID", "SSG");
				h.put("CMD_TY", "02");
				
				dao.insSVCFILEINFO(h);
				
				list = null;
				list = dao.selSSGMbsAbnormalSaveTRAN(com_cd);
				
				Seed seed = Seed.getInstance("CBC/PKCS5Padding");
				String keyData = PropertyUtil.findProperty("service-property", "KEY_DATA");
				String ivData = PropertyUtil.findProperty("service-property", "IV_DATA");
				seed.setKey(keyData.getBytes());
				seed.setIV(ivData.getBytes());
				BASE64Decoder decoder = new BASE64Decoder();
				
				logger.info("[DEBUG] Abnormal SAVE TRAN Count : " + Integer.toString(list.size()));
				// 신세계포인트 적립트란 테이블 조회
				if( list.size() > 0 ) {
					for( int i = 0;i < list.size();i++ ) {
						HashMap<String, String> hm = new HashMap<String, String>();
						Map<String, String> map = (Map<String, String>)list.get(i);
						
						hm.put("MSG_LEN", "0535");														// 전문 총길이
						if( ((String)map.get("SAVE_CNCL_TP")).equals("1") ) {		// 적립
							hm.put("MSG_TEXT", "CONTRN0121");												// 전문구분
							hm.put("TRADE_GB_CD", "200020");												// 거래구분코드
						}else if( ((String)map.get("SAVE_CNCL_TP")).equals("2") ) {	// 취소
							hm.put("MSG_TEXT", "CONTRN0141");												// 전문구분
							hm.put("TRADE_GB_CD", "400080");												// 거래구분코드
						}else {
							continue;
						}
						hm.put("BUSI_DT", (String)map.get("TRAN_YMD"));									// 영업일자
						hm.put("TRADE_GENTD_DT", (String)map.get("REG_YMDHMS").substring(4, 8));		// 거래발생일자
						hm.put("TRADE_GENTD_TM", (String)map.get("REG_YMDHMS").substring(8, 14));		// 거래발생시간
						hm.put("TRADE_GENTD_STCD", (String)map.get("STORE_CD"));						// 거래발생점번호
						hm.put("POS_NO", (String)map.get("POS_NO"));									// POS번호
						hm.put("TRADE_NO", (String)map.get("TRAN_NO"));									// 거래번호
						hm.put("APPR_NO", " ");															// 승인번호
						hm.put("CARD_NO", new String(seed.decrypt(decoder.decodeBuffer((String)map.get("CARD_NO_ENCODED")))));	// 카드번호
						hm.put("BRCH_ID", fcstr_id);													// 가맹점ID
						hm.put("PASSWD", " ");															// 비밀번호
						hm.put("CORP_CARD_AMT", "0000000000");											// 수단별결제-제휴카드
						hm.put("CASH_AMT", (String)map.get("PAY_AMT"));									// 수단별결제-현금
						hm.put("OTHER_ETC_AMT", "0000000000");											// 수단별결제-타사카드/기타
						hm.put("NOADD_AMT", "0000000000");												// 수단별결제-미적립결제액
						hm.put("SPOINT_AMT", "0000000000");												// 수단별결제-S Point
						hm.put("TOT_TRADE_AMT", (String)map.get("PAY_AMT"));							// 총거래금액
						hm.put("TPOINT", "00000000");													// 누적포인트
						hm.put("UBPOINT", "00000000");													// 가용포인트
						hm.put("GPOINT", "00000000");													// 금회포인트
						if( ((String)map.get("SAVE_CNCL_TP")).equals("1") ) {		// 적립
							hm.put("REJCT_GB", "0");													// 적립사용구분
							hm.put("OTRADE_BUSI_DT", "00000000");										// 원거래영업일자
							hm.put("OTRADE_APPR_NO", "00000000000000000000");							// 원거래승인번호
							hm.put("OTRADE_AMT", "0000000000");											// 원거래금액
						}else if( ((String)map.get("SAVE_CNCL_TP")).equals("2") ) {	// 취소
							hm.put("REJCT_GB", "1");													// 적립사용구분
							hm.put("OTRADE_BUSI_DT", (String)map.get("ORGTRAN_APPR_DT"));				// 원거래영업일자
							hm.put("OTRADE_APPR_NO", (String)map.get("ORGTRAN_APPR_NO"));				// 원거래승인번호
							hm.put("OTRADE_AMT", (String)map.get("PAY_AMT"));							// 원거래금액
						}else {
							hm.put("REJCT_GB", "0");													// 적립사용구분
							hm.put("OTRADE_BUSI_DT", "00000000");										
							hm.put("OTRADE_APPR_NO", "00000000000000000000");							
							hm.put("OTRADE_AMT", "0000000000");											
						}
						hm.put("REPLY_CD", "0000");														// 응답코드
						hm.put("APPR_CRE_DT", "00000000");												// 시스템일자
						hm.put("APPR_CRE_TM", "000000");												// 시스템시간
						hm.put("REPLY_MESG", " ");														// 영수증출력메시지
						hm.put("CUST_ID", " ");															// 고객ID
						hm.put("RESERVE", " ");															// 여분
						
						sendMsg = makeSendDataSSGPoint(hm);
						sb = new StringBuffer(sendMsg);
						sb.replace(71, 81, "********************");
						logger.info("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("MSG_TEXT") + "]:[" + sb.toString() + "]");
						if(actSock.send(sendMsg)) {
							logger.info("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] OK");
						}else {
							logger.info("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] ERROR");
							throw new Exception("SSG Server is no response");
						}
						
						recvBuf = (String)actSock.receive();
						sb = null;
						sb = new StringBuffer(recvBuf);
						sb.replace(71, 91, "********************");
						logger.info("[sms<ssgpoint] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
						
						HashMap<String, String> hmRecv = new HashMap<String, String>();
						hmRecv = protocol.getParseSSGPointRsp(recvBuf);
						hmRecv.put("COM_CD", com_cd);
						
						int ret = dao.updSSGMbsSaveTRAN(hmRecv);
						if( ret > 0 ) {
							logger.info("TRAN[" + (String)map.get("TRAN_ID") + "] is successfuly updated.");
						}
					}
				}
				
				// 신세계포인트 사용 트란테이블 조회
				list = dao.selSSGMbsAbnormalUseTRAN(com_cd);
				logger.info("[DEBUG] Abnormal USE TRAN Count : " + Integer.toString(list.size()));
				if( list.size() > 0 ) {
					for(int i = 0;i < list.size();i++ ) {
						HashMap<String, String> hm = new HashMap<String, String>();
						Map<String, String> map = (Map<String, String>)list.get(i);
						
						hm.put("MSG_LEN", "0535");														// 전문 총길이
						if( ((String)map.get("USE_CNCL_TP")).equals("2") ) {	// 취소
							hm.put("MSG_TEXT", "CONTRN0141");												// 전문구분
							hm.put("TRADE_GB_CD", "400080");												// 거래구분코드
						}else {
							continue;
						}
						hm.put("BUSI_DT", (String)map.get("TRAN_YMD"));									// 영업일자
						hm.put("TRADE_GENTD_DT", (String)map.get("REG_YMDHMS").substring(4, 8));		// 거래발생일자
						hm.put("TRADE_GENTD_TM", (String)map.get("REG_YMDHMS").substring(8, 14));		// 거래발생시간
						hm.put("TRADE_GENTD_STCD", (String)map.get("STORE_CD"));						// 거래발생점번호
						hm.put("POS_NO", (String)map.get("POS_NO"));									// POS번호
						hm.put("TRADE_NO", (String)map.get("TRAN_NO"));									// 거래번호
						hm.put("APPR_NO", " ");															// 승인번호
						hm.put("CARD_NO", new String(seed.decrypt(decoder.decodeBuffer((String)map.get("CARD_NO_ENCODED")))));	// 카드번호
						hm.put("BRCH_ID", fcstr_id);													// 가맹점ID
						hm.put("PASSWD", " ");															// 비밀번호
						hm.put("CORP_CARD_AMT", "0000000000");											// 수단별결제-제휴카드
						hm.put("CASH_AMT", (String)map.get("PAY_AMT"));									// 수단별결제-현금
						hm.put("OTHER_ETC_AMT", "0000000000");											// 수단별결제-타사카드/기타
						hm.put("NOADD_AMT", "0000000000");												// 수단별결제-미적립결제액
						hm.put("SPOINT_AMT", (String)map.get("USE_POINT"));								// 수단별결제-S Point
						hm.put("TOT_TRADE_AMT", Integer.toString(Integer.parseInt((String)map.get("PAY_AMT")) 
								+ Integer.parseInt((String)map.get("USE_POINT"))));						// 총거래금액
						hm.put("TPOINT", "00000000");													// 누적포인트
						hm.put("UBPOINT", "00000000");													// 가용포인트
						hm.put("GPOINT", "00000000");													// 금회포인트
						hm.put("REJCT_GB", "2");														// 적립사용구분
						hm.put("OTRADE_BUSI_DT", (String)map.get("ORGTRAN_APPR_DT"));					// 원거래영업일자
						hm.put("OTRADE_APPR_NO", (String)map.get("ORGTRAN_APPR_NO"));					// 원거래승인번호
						hm.put("OTRADE_AMT", (String)map.get("USE_POINT"));								// 원거래금액
						hm.put("REPLY_CD", "0000");														// 응답코드
						hm.put("APPR_CRE_DT", "00000000");												// 시스템일자
						hm.put("APPR_CRE_TM", "000000");												// 시스템시간
						hm.put("REPLY_MESG", " ");														// 영수증출력메시지
						hm.put("CUST_ID", " ");															// 고객ID
						hm.put("RESERVE", " ");															// 여분
						
						sendMsg = makeSendDataSSGPoint(hm);
						sb = null;
						sb = new StringBuffer(sendMsg);
						sb.replace(71, 91, "********************");
						logger.info("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("MSG_TEXT") + "]:[" + sb.toString() + "]");
						if(actSock.send(sendMsg)) {
							logger.info("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] OK");
						}else {
							logger.info("[sms>ssgpoint] SEND[" + sendMsg.getBytes().length + "] ERROR");
							throw new Exception("SSG Server is no response");
						}
						
						recvBuf = (String)actSock.receive();
						sb = null;
						sb = new StringBuffer(recvBuf);
						sb.replace(71, 91, "********************");
						logger.info("[sms<ssgpoint] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
						
						HashMap<String, String> hmRecv = new HashMap<String, String>();
						hmRecv = protocol.getParseSSGPointRsp(recvBuf);
						hmRecv.put("COM_CD", com_cd);
						
						int ret = dao.updSSGMbsUseTRAN(hmRecv);
						if( ret > 0 ) {
							logger.info("TRAN[" + (String)map.get("TRAN_ID") + "] is successfuly updated.");
						}
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	private String makeSendDataSSGPoint(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,10,6,8,4
					  ,6,5,4,4,20
					  ,20,10,4,10,10
					  ,10,10,10,10,8
					  ,8,8,1,8,20
					  ,10,4,8,6,80
					  ,9,200};
				
		String strHeaders[] = { 
				"MSG_LEN"			, // 전문 총길이
				"MSG_TEXT"			, // 전문 구분
				"TRADE_GB_CD"		, // 거래구분코드
				"BUSI_DT"			, // 영업일자
				"TRADE_GENTD_DT"	, // 거래발생일자
				
				"TRADE_GENTD_TM"	, // 거래발생시간
				"TRADE_GENTD_STCD"	, // 거래발생점번호
				"POS_NO"			, // POS번호
				"TRADE_NO"			, // 거래번호
				"APPR_NO"			, // 승인번호
				
				"CARD_NO"			, // 카드번호
				"BRCH_ID"			, // 가맹점ID
				"PASSWD"			, // 비밀번호
				"CORP_CARD_AMT"		, // 수단별결제금액 - 제휴카드
				"CASH_AMT"			, // 수단별결제금액 - 현금
				
				"OTHER_ETC_AMT"		, // 수단별결제금액 - 타사카드/기타
				"NOADD_AMT"			, // 수단별결제금액 - 미적립결제액
				"SPOINT_AMT"		, // 수단별결제금액 - S POINT
				"TOT_TRADE_AMT"		, // 총거래금액
				"TPOINT"			, // 누적포인트
				
				"UBPOINT"			, // 가용포인트
				"GPOINT"			, // 금회포인트
				"REJCT_GB"			, // 취소구분(적립취소/사용취소)
				"OTRADE_BUSI_DT"	, // 원거래영업일자
				"OTRADE_APPR_NO"	, // 원거래승인번호
				
				"OTRADE_AMT"		, // 원거래금액
				"REPLY_CD"			, // 응답코드
				"APPR_CRE_DT"		, // 시스템일자
				"APPR_CRE_TM"		, // 시스템시간
				"REPLY_MESG"		, // 영수증출력메시지
				
				"CUST_ID"			, // 고객ID
				"RESERVE"			  // FILLER
			};
		
		for (int i = 0; i < nlens.length; i++) {
			logger.info(strHeaders[i] + "=" + (String)hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
}