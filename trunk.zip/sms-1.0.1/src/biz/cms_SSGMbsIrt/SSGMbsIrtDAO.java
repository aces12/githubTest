package biz.cms_SSGMbsIrt;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class SSGMbsIrtDAO extends GenericDAO {

	private static Logger logger = Logger.getLogger(SSGMbsIrtAction.class);

	public List<Object> selSSGMbsAbnormalUseTRAN(String com_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;

		try {
			// DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("service-sql", "SEL_SSGMBSABNMLUSETRAN"));
			sql.setString(++i, com_cd);

			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		}

		return list;
	}

	public int updSSGMbsUseTRAN(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;

		try {
			begin();

			// DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("service-sql", "UPD_SSGMBSABNMLUSETRAN"));
			sql.setString(++i, (String) hm.get("APPR_NO"));
			sql.setString(++i, (String) hm.get("APPR_CRE_DT"));
			if (((String) hm.get("REPLY_CD")).equals("0000") || ((String) hm.get("REPLY_CD")).equals("4051")
					|| ((String) hm.get("REPLY_CD")).equals("4081")) { // 정상 or 중복거래전문전송 or 기취소된 거래
				sql.setString(++i, "2");
			} else { // 오류
				sql.setString(++i, "1");
			}
			sql.setString(++i, (String) hm.get("BUSI_DT"));
			sql.setString(++i, (String) hm.get("TRADE_GENTD_STCD"));
			sql.setString(++i, (String) hm.get("POS_NO"));
			sql.setString(++i, (String) hm.get("TRADE_NO"));
			sql.setString(++i, (String) hm.get("COM_CD"));

			rows = executeUpdate(sql);
		} catch (Exception e) {
			rollback();
			throw e;
		} finally {
			end();
		}

		return rows;
	}

	public List<Object> selSVCFILEDAILY(String stdYmd, String svcID, String cmdTp, String comCD) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;

		try {
			// DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("service-sql", "SEL_SVCCRTDAILY"));
			sql.setString(++i, stdYmd);
			sql.setString(++i, svcID);
			sql.setString(++i, cmdTp);
			sql.setString(++i, comCD);

			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		}

		return list;
	}

	public int insSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;

		try {
			begin();

			// DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("service-sql", "INS_SVCFILEINFO"));
			sql.setString(++i, (String) hm.get("COM_CD"));
			sql.setString(++i, (String) hm.get("STD_YMD"));
			sql.setString(++i, (String) hm.get("SVC_ID"));
			sql.setString(++i, (String) hm.get("CMD_TY"));

			rows = executeUpdate(sql);

		} catch (Exception e) {
			rollback();
			throw e;
		} finally {
			end();
		}

		return rows;
	}

	public List<Object> selSSGMbsAbnormalSaveTRAN(String com_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;

		try {
			// DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("service-sql", "SEL_SSGMBSABNMLSAVETRAN"));
			sql.setString(++i, com_cd);

			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		}

		return list;
	}

	public int updSSGMbsSaveTRAN(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;

		try {
			begin();

			// DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("service-sql", "UPD_SSGMBSABNMLSAVETRAN"));
			sql.setString(++i, (String) hm.get("APPR_CRE_DT"));
			sql.setString(++i, (String) hm.get("APPR_NO"));
			sql.setString(++i, ((String) hm.get("GPOINT")).replaceFirst("^0+", ""));
			if (((String) hm.get("REPLY_CD")).equals("0000") || ((String) hm.get("REPLY_CD")).equals("4051")
					|| ((String) hm.get("REPLY_CD")).equals("4081")) { // 정상 or 중복거래전문전송 or 기취소된 거래
				sql.setString(++i, "2");
			} else { // 오류
				sql.setString(++i, "1");
			}
			sql.setString(++i, (String) hm.get("BUSI_DT"));
			sql.setString(++i, (String) hm.get("TRADE_GENTD_STCD"));
			sql.setString(++i, (String) hm.get("POS_NO"));
			sql.setString(++i, (String) hm.get("TRADE_NO"));
			sql.setString(++i, (String) hm.get("COM_CD"));

//			logger.info(">>>sql:" + sql.debug());
			rows = executeUpdate(sql);
		} catch (Exception e) {
			rollback();
			throw e;
		} finally {
			end();
		}

		return rows;
	}

	// 20170828 알리페이결제수단추가 _ LYH
	public String selAlipayMchSendSeq(String yyyymmdd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		String strSequence = null;

		if (yyyymmdd == null || yyyymmdd.trim().length() != 8) {
			SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd", Locale.KOREA); // 20041102
			yyyymmdd = df.format(Calendar.getInstance().getTime());
		}
		try {
			// DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("service-sql", "SEL_ALIPAY_MCH_SEND_SEQ"));
			list = executeQuery(sql);
			sql.close();
			if (list.size() > 0) {
				int sequence = Integer.parseInt((String) ((Map<String, String>) list.get(0)).get("SEQ"));
				strSequence = String.format("%s%06d", yyyymmdd.substring(2), sequence);
			}
		} catch (Exception e) {
			throw e;
		}
		return strSequence;
	}

	// PT 직원 전화번호 조회 추가
	public List<Object> getPTPhoneNumber(String hp_num, String sale_date, String store_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		String ret = "00";
		String dataMsg = "";

		try {
			// DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("service-sql", "SEL_PTHPNUMBER"));
			sql.setString(++i, hp_num);
			sql.setString(++i, store_cd);
			sql.setString(++i, sale_date);

			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		}

		return list;
	}

}