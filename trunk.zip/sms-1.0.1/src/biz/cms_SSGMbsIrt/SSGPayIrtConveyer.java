package biz.cms_SSGMbsIrt;

import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;

import org.apache.log4j.Logger;

import com.mysql.jdbc.StringUtils;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

public class SSGPayIrtConveyer {
	private static Logger logger = Logger.getLogger(SSGMbsIrtAction.class);
	private Socket svrSock = null;
	private ActionSocket actSock = null;

	COMMLog df = null;

	private final String SSGPAY_COM_CD = "5700";
	private String SSGPAY_GNRFCSTR_ID = "";
	private String SSGPAY_GIFTFCSTR_ID = "";
	private String SSGCON_GNRFCSTR_ID = "";

	public SSGPayIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
		try {
			SSGPAY_GNRFCSTR_ID = PropertyUtil.findProperty("service-property", "SSGPAY_GNRFCSTR_ID");
			SSGPAY_GIFTFCSTR_ID = PropertyUtil.findProperty("service-property", "SSGPAY_GIFTFCSTR_ID");
			SSGCON_GNRFCSTR_ID = "FM00010770";
		} catch (Exception e) {
		}
	}

	public String getSSGPayMGiftApproval(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();

		String sendMsg = ""; // 신세계로 보낼 송신 전문
		String recvBuf = ""; // 신세계에서 받을 응답 전문
		String dataMsg = ""; // POS로 보낼 응답 전문
		String ret = "00";

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String todayDT = sdf.format(calendar.getTime());

		try {
			actSock = new ActionSocket(this.svrSock, (Filter) (new COMMConveyerFilter(COMMBiz.SSGPAY_FILTER)));

			/*
			 * 통합결제플랫폼 모바일상품권 회수요청전문 HEADER 구성
			 */
			hm.put("MSG_LEN", "0900"); // 01. 전문길이(4)
			hm.put("MSG_ID", "PGIU0200"); // 02. 전문ID(8)
			hm.put("MCH_SEND_DATE", todayDT.substring(0, 8)); // 03. 전문전송일자(8)
			hm.put("MCHH_SEND_UNIQ_NO", hmComm.get("TRAN_YMD") + hmComm.get("POS_NO") + "0000" + hmComm.get("TRAN_NO")); // 04.
																															// 전송거래고유번호(20)
			hm.put("GIFT_MCH_NO", SSGPAY_GIFTFCSTR_ID); // 05. 가맹점번호(15)
			hm.put("MSG_GUBUN", "SEND"); // 06. 요청구분(4)
			hm.put("SER_COM_CD", SSGPAY_COM_CD); // 07. 회사코드(4)
			hm.put("SALE_DATE", hmComm.get("TRAN_YMD")); // 08. 영업일자(8)
			hm.put("SALE_TIME", hmComm.get("SYS_HMS")); // 09. 영업시간(6)
			hm.put("ST_CODE", hmComm.get("STORE_CD")); // 10. 점코드(10)
			hm.put("TM_NO", hmComm.get("POS_NO")); // 11. 포스번호(4)
			hm.put("CD_NO", "0000"); // 12. CD번호(4)
			hm.put("TRAN_NO", hmComm.get("TRAN_NO")); // 13. TRAN_NO(4)
														// 14. Casher번호(10)
			hm.put("POS_DATE", hmComm.get("SYS_YMD")); // 15. POS시스템일자(8)
			hm.put("POS_TIME", hmComm.get("SYS_HMS")); // 16. POS시스템시간(6)
			hm.put("SER_COM_UNIQ_NO", " "); // 17. 회사별요청자정보(20)
			hm.put("JUMPO_SYS_DATE", todayDT.substring(0, 8)); // 18. 점포서버 전문전송일자(8)
			hm.put("JUMPO_SYS_TIME", todayDT.substring(8, 14)); // 19. 점포서버 전문전송시간(6)
			hm.put("HEAD_ETC_FIELD", " "); // 20. 헤더예비필드(53)
			/*
			 * 통합결제플랫폼 모바일상품권 회수요청전문 DATA 구성
			 */
			hm.put("TRAN_TYPE", hm.get("INQ_TYPE").equals("64") ? "00" : "02"); // 21. 거래TYPE(2)
			hm.put("TRADE_TYPE", hm.get("INQ_TYPE").equals("64") ? "25" : "65");// 22. 요청TYPE(2)
			hm.put("EVENT_GUBUN", " "); // 23. 행사구분(2)
			hm.put("EVENT_TYPE", " "); // 24. 행사타입(2)
			hm.put("EVENT_NO", " "); // 25. 행사번호(20)
			hm.put("TRACK_TYPE", "3"); // 26. TRACK2 유무(1)
			hm.put("START_BARCODE", " "); // 27. 시작바코드(50)
			hm.put("END_BARCODE", " "); // 28. 종료바코드(50)
			hm.put("BARCODE_CNT", "001"); // 29. 판매수량(3)
											// 30. GIFT카드번호(100)
											// 31. GIFT인증번호(50)
											// 32. KEY_IN 유무(2)
											// 33. 요청금액(12)
			hm.put("SPECIAL_GUBUN", "1"); // 34. 미수수료구분(1)
											// 35. 사용구분(1)
			hm.put("GIFT_GUBUN", "3"); // 36. 상품종류구분(1)
			hm.put("PART_GUBUN", "60"); // 37. 제휴사구분코드(2)
										// 38. 권종코드(4)
			hm.put("GIFT_MOMILE_NO", " "); // 39. 선물하기번호(20)
											// 40. 원거래 회사코드(4)
											// 41. 원거래 영업일자(8)
											// 42. 원거래 점코드(10)
											// 43. 원거래 포스번호(4)
											// 44. 원거래 거래번호(4)
											// 45. 원거래 CD번호(4)
											// 46. 원거래 전문전송일자(8)
											// 47. 원거래전송거래고유번호(20)
			hm.put("ORG_GIFT_MCH_NO", " "); // 48. 원거래가맹점번호(15)
											// 49. 원거래 승인일자(8)
											// 50. 원거래 승인번호(8)
			hm.put("AUTH_DATE", " "); // 51. 승인일자(8)
			hm.put("AUTH_TIME", " "); // 52. 승인시간(6)
			hm.put("AUTH_NO", " "); // 53. 승인번호(8)
			hm.put("REMAIN_AMT", " "); // 54. 상품권잔액금액(12)
			hm.put("MD_CODE", " "); // 55. 회사별물품코드(30)
			hm.put("RESP_CODE", " "); // 56. 응답코드(4)
			hm.put("RESP_MSG", " "); // 57. 응답메시지(60)
			hm.put("REFUND_ABLE_AMT", " "); // 58. 환불가능금액(12)
											// 59. 통합플랫폼바코드(48)
			hm.put("NORM_REF_AMT", " "); // 60. 일반상품권금액(12)
			hm.put("NORM_REF_FEE", " "); // 61. 일반상품권환불수수료(12)
			hm.put("SWAP_REF_AMT", " "); // 62. 전환상품권금액(12)
			hm.put("SWAP_REF_FEE", " "); // 63. 전환상품권환불수수료(12)
			hm.put("FREE_REF_AMT", " "); // 64. 무상금액(12)
			hm.put("DATA_ETC_FIELD", " "); // 65. DATA예비필드(23)
			hm.put("MSG_END", " "); // 66. 전문종료내역(1)

			sendMsg = makeSendDataSSGPayMGiftApproval(hm, df);

			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();

			// 전문종료내역 설정
			sendBytes[899] = (byte) 0x0d;

			df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");

			if (actSock.send(sendBytes, sendBytes.length)) {
				df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "] OK");
			} else {
				df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSGPay Server is no response");
			}

			recvBuf = ((String) actSock.receive());
			df.CommLogger("[sms<ssgpay] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");

			hmRecv = protocol.getParseSSGPayMGiftRspApproval(recvBuf);

			hmRecv.put("INQ_TYPE", (String) hm.get("INQ_TYPE"));
		} catch (Exception e) {
			ret = "29";
			throw e;
		} finally {
			actSock.close();
			dataMsg = ret + makeSendDataSSGPayMGiftApprovalRsp(hmRecv, df);
		}

		return dataMsg;
	}

	public String getSSGPayAccountApproval(HashMap<String, String> hmComm, HashMap<String, String> hm)
			throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();

		String sendMsg = ""; // 신세계로 보낼 송신 전문
		String recvBuf = ""; // 신세계에서 받을 응답 전문
		String dataMsg = ""; // POS로 보낼 응답 전문
		String ret = "00";

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String todayDT = sdf.format(calendar.getTime());
		SSGPAY_GIFTFCSTR_ID = PropertyUtil.findProperty("service-property", "SSGPAY_GIFTFCSTR_ID");

		try {
			actSock = new ActionSocket(this.svrSock, (Filter) (new COMMConveyerFilter(COMMBiz.SSGPAY_FILTER)));

			String tmpUniqNo = (String) hm.get("SALE_DATE") + hmComm.get("POS_NO") + "0000" + "0000"
					+ hmComm.get("TRAN_NO");

			String tmpNormalGubun = hm.get("TRAN_TYPE").equals("03") ? "EXCEPT" : "NORMAL";
			/*
			 * 통합결제플랫폼 모바일상품권 회수요청전문 HEADER 구성
			 */

			hm.put("MSG_LEN", "1600"); // 01. 전문길이(4)
			hm.put("MSG_ID", hm.get("MSG_ID")); // 02. 전문ID(8)
			hm.put("MCH_SEND_DATE", todayDT.substring(0, 8)); // 03. 전문전송일자(8)
			hm.put("MCH_SEND_UNIQ_NO", tmpUniqNo); // 04. 전송거래고유번호(24)
			hm.put("MSG_GUBUN", "SEND"); // 05. 요청구분(4)
			hm.put("TRAN_TYPE", hm.get("TRAN_TYPE")); // 06. 거래TYPE(2)
			hm.put("SER_COM_CD", SSGPAY_COM_CD); // 07. 회사코드(4)
			hm.put("TERM_ID", SSGPAY_GNRFCSTR_ID); // 08. 터미널아이디(15)
			hm.put("SALE_DATE", (String) hm.get("SALE_DATE").trim()); // 09. 영업일자(8)
			hm.put("SALE_TIME", (String) hm.get("SALE_TIME").trim()); // 10. 영업시간(6)
			hm.put("ST_CODE", hmComm.get("STORE_CD")); // 11. 점코드(10)
			hm.put("TM_NO", hmComm.get("POS_NO")); // 12. 포스번호(4)
			hm.put("SHOP_NO", "0000"); // 13. 매장번호(4)
			hm.put("CD_NO", "0000"); // 14. CD번호(4)
			hm.put("TRAN_NO", hmComm.get("TRAN_NO")); // 15. TRAN_NO(4)
			hm.put("CASHER_NO", (String) hm.get("CASHER_NO").trim());// 16. Casher번호(10)
			hm.put("POS_DATE", hmComm.get("SYS_YMD")); // 17. POS시스템일자(8)
			hm.put("POS_TIME", hmComm.get("SYS_HMS")); // 18. POS시스템시간(6)
			hm.put("NORMAL_GUBUN", tmpNormalGubun); // 19. 정상 예외 구분(6)
			hm.put("BUY_FIRM_CODE", "    "); // 20. 매입사코드(4)
			hm.put("BUY_FIRM_NM", "                              "); // 21. 매입사명(30)
			hm.put("ISSUE_FIRM_CODE", "    "); // 22. 발행사코드(4)
			hm.put("ISSUE_FIRM_NM", "                              "); // 23. 발행사명(30)
			hm.put("CARD_SYS_DATE", "        "); // 24. 카드사요청일자(8)
			hm.put("CARD_SYS_TIME", "      "); // 25. 카드사요청시간(6)
			hm.put("CARD_UNIQ_NO", "                    "); // 26. 카드사요청고유번호(20)
			hm.put("CARD_MCH_NO", "                    "); // 27. 카드사가맹점번호(20)
			hm.put("SER_COM_UNIQ_NO", SSGPAY_COM_CD); // 28. 회사별요청자정보(20)
			hm.put("JUMPO_SYS_DATE", todayDT.substring(0, 8)); // 29. 점포서버전문전송일자(8)
			hm.put("JUMPO_SYS_TIME", todayDT.substring(8, 14)); // 30. 점포서버전문전송시간(6)
			hm.put("RESP_CODE", "    "); // 31. 응답메시지 코드(4)
			hm.put("RESP_MSG", "                                                            "); // 32. 응답메시지 설명(60)
			hm.put("BANK_CODE", (String) hm.get("BANK_CODE").trim());// 33. 은행코드(3)
			hm.put("BANK_NM", (String) hm.get("BANK_NM").trim()); // 34. 은행사명(30)
			hm.put("BANK_VAN_FLAG", (String) hm.get("BANK_VAN_FLAG").trim()); // 35. 금융VAN구분(4)
			hm.put("PLATFORM_M_ID", SSGPAY_GIFTFCSTR_ID); // 36. 플랫폼연동가맹점ID(20)
			hm.put("HEAD_ETC_FIELD",
					"                                                                                    "); // 37.
																												// Header예비필더(84)

			/*
			 * 통합결제플랫폼조회전문 DATA 구성
			 */
			hm.put("DELEGATE_BARCODE_NO", (String) hm.get("DELEGATE_BARCODE_NO").trim()); // 38. 통합바코드번호(64)
			hm.put("KEY_IN_TYPE", (String) hm.get("KEY_IN_TYPE").trim()); // 39. KEY_IN유무(2)
			hm.put("BANK_ACCOUNT_NO", (String) hm.get("BANK_ACCOUNT_NO").trim()); // 40. 가상은행계좌번호(96)
			hm.put("BANK_TOT_TRADE_AMT", (String) hm.get("BANK_TOT_TRADE_AMT").trim()); // 41. 전체거래금액(12)
			hm.put("BANK_DIS_TRADE_AMT", (String) hm.get("BANK_DIS_TRADE_AMT").trim()); // 42. 에누리금액(12)
			hm.put("BANK_NET_TRADE_AMT", (String) hm.get("BANK_NET_TRADE_AMT").trim()); // 43. 실승인요청금액(12)
			hm.put("BANK_AUTH_DATE", (String) hm.get("BANK_AUTH_DATE").trim()); // 44. 가상은행계좌 승인일자(8)
			hm.put("BANK_AUTH_TIME", (String) hm.get("BANK_AUTH_TIME").trim()); // 45. 가상은행계좌 승인시간(6)
			hm.put("BANK_AUTH_NO", (String) hm.get("BANK_AUTH_NO").trim()); // 46. 가상은행계좌 승인번호(15)
			// hm.put("MD_CNT", (String)hm.get("MD_CNT").trim()); // 47. 상품 수량(4)
			hm.put("MD_CNT", "0001"); // 47. 상품 수량(4)
			// hm.put("MD_CODE", (String)hm.get("MD_CODE").trim()); // 48. 회사별 상품 코드 (50)
			hm.put("MD_CODE", "                                                  "); // 48. 회사별 상품 코드 (50)
			// hm.put("MD_NAME", (String)hm.get("MD_NAME").trim()); // 49. 상품명(100)
			hm.put("MD_NAME",
					"                                                                                                    "); // 49.
																																// 상품명(100)
			hm.put("ORG_SEND_DATE", (String) hm.get("ORG_SEND_DATE").trim()); // 50. 원거래 전문전송일자(8)
			hm.put("ORG_SEND_UNIQ_NO", (String) hm.get("ORG_SEND_UNIQ_NO").trim()); // 51. 원거래 전송 거래고유번호(24)
			hm.put("ORG_SER_COM_CD", (String) hm.get("ORG_SER_COM_CD").trim()); // 52. 원거래 회사코드(4)
			hm.put("ORG_SALE_DATE", (String) hm.get("ORG_SALE_DATE").trim()); // 53. 원거래 영업일자(8)
			hm.put("ORG_ST_CODE", (String) hm.get("ORG_ST_CODE").trim()); // 54. 원거래 점코드(10)
			hm.put("ORG_TM_NO", (String) hm.get("ORG_TM_NO").trim()); // 55. 원거래 포스 번호(4)
			hm.put("ORG_SHOP_NO", (String) hm.get("ORG_SHOP_NO").trim()); // 56. 원거래 매장번호(4)
			hm.put("ORG_CD_NO", (String) hm.get("ORG_CD_NO").trim()); // 57. 원거래 CD 번호(4)
			hm.put("ORG_TRAN_NO", (String) hm.get("ORG_TRAN_NO").trim()); // 58. 원거래 거래 번호(4)
			hm.put("ORG_CASHER_NO", (String) hm.get("ORG_CASHER_NO").trim()); // 59. 원거래 Casher 번호(10)
			hm.put("ORG_BANK_AUTH_DATE", (String) hm.get("ORG_BANK_AUTH_DATE").trim()); // 60. 원거래 가상은행계좌 승인일자 (8)
			hm.put("ORG_BANK_AUTH_NO", (String) hm.get("ORG_BANK_AUTH_NO").trim()); // 61. 원거래 가상은행계좌 승인번호(15)
			// hm.put("CNCL_GUBUN", (String)hm.get("CNCL_GUBUN").trim()); // 62. 취소 구분(2)
			// hm.put("CNCL_USE_YN", (String)hm.get("CNCL_USE_YN").trim()); // 63. 부분취소 가능
			// 여부(1)
			hm.put("CNCL_GUBUN", "  "); // 62. 취소 구분(2)
			hm.put("CNCL_USE_YN", " "); // 63. 부분취소 가능 여부(1)
			hm.put("ORG_DELEGATE_BARCODE_NO", (String) hm.get("ORG_DELEGATE_BARCODE_NO").trim()); // 64. 원거래 통합바코드번호(64)
			// hm.put("ORG_BANK_AUTH_AMT", (String)hm.get("ORG_BANK_SUTH_AMT").trim()); //
			// 65. 원거래 실승인요청금액(12)
			hm.put("ORG_BANK_AUTH_AMT", "            "); // 65. 원거래 실승인요청금액(12)
			hm.put("DATA_ETC_FIELD", " "); // 66. DATA예비필드(536)
			hm.put("MSG_END", " "); // 67. 전문 종료 내역(1)

			sendMsg = makeSendDataSSGPayAccountApproval(hm, df);

			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();

			// 전문종료내역 설정
			sendBytes[1599] = (byte) 0x0d;

			df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");

			if (actSock.send(sendBytes, sendBytes.length)) {
				df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "] OK");
			} else {
				df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSGPay Server is no response");
			}

			recvBuf = ((String) actSock.receive());
			df.CommLogger("[sms<ssgpay] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");

			hmRecv = protocol.getParseSSGPayAccountRspApproval(recvBuf);

			hmRecv.put("INQ_TYPE", (String) hm.get("INQ_TYPE"));
		} catch (Exception e) {
			ret = "29";
			df.CommLogger("===send receive exception occur===============" + e.getMessage());
			throw e;
		} finally {
			actSock.close();
			dataMsg = ret + makeSendDataSSGPayAccountApprovalRsp(hmRecv, df);
		}

		return dataMsg;
	}

	public String getSSGPayApproval(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();

		String msgHeader = ""; // 송신전문 헤더
		String msgData = ""; // 송신전문 데이터
		String sendMsg = ""; // 신세계로 보낼 송신 전문
		String recvBuf = ""; // 신세계에서 받을 응답 전문
		String dataMsg = ""; // POS로 보낼 응답 전문
		String ret = "00";

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String todayDT = sdf.format(calendar.getTime());

		try {
			actSock = new ActionSocket(this.svrSock, (Filter) (new COMMConveyerFilter(COMMBiz.SSGPAY_FILTER)));

			/*
			 * 통합결제플랫폼조회전문 HEADER 구성
			 */
			hm.put("MSG_LEN", "1600"); // 01. 전문길이(4)
			hm.put("MSG_ID", "POIA0200"); // 02. 전문ID(8)
			hm.put("MCH_SEND_DATE", todayDT.substring(0, 8)); // 03. 전문전송일자(8)
			hm.put("MCH_SEND_UNIQ_NO",
					hmComm.get("TRAN_YMD") + hmComm.get("POS_NO") + "0000" + "0000" + hmComm.get("TRAN_NO")); // 04.
																												// 전송거래고유번호(24)
			hm.put("MSG_GUBUN", "SEND"); // 05. 요청구분(4)
			hm.put("TRAN_TYPE", "00"); // 06. 거래TYPE(2)
			hm.put("SER_COM_CD", "1100"); // 07. 회사코드(4)
			hm.put("TERM_ID", SSGPAY_GNRFCSTR_ID); // 08. 터미널아이디(15)
			hm.put("SALE_DATE", hmComm.get("TRAN_YMD")); // 09. 영업일자(8)
			hm.put("SALE_TIME", hmComm.get("SYS_HMS")); // 10. 영업시간(6)
			hm.put("ST_CODE", hmComm.get("STORE_CD")); // 11. 점포코드(10)
			hm.put("TM_NO", hmComm.get("POS_NO")); // 12. 포스번호(4)
			hm.put("SHOP_NO", " "); // 13. 매장번호(4)
			hm.put("CD_NO", "0000"); // 14. CD번호(4)
			hm.put("TRAN_NO", hmComm.get("TRAN_NO")); // 15. 거래번호(4)
														// 16. Casher번호(4)
			hm.put("POS_DATE", hmComm.get("SYS_YMD")); // 17. POS시스템일자(8)
			hm.put("POS_TIME", hmComm.get("SYS_HMS")); // 18. POS시스템시간(6)
			hm.put("NORMAL_GUBUN", "NORMAL"); // 19. 정상 예외 구분(6)
												// 20. 매입사코드(4)
												// 21. 발행사코드(4)
			hm.put("CARD_SYS_DATE", " "); // 22. 카드사요청일자(8)
			hm.put("CARD_SYS_TIME", " "); // 23. 카드사요청시간(6)
			hm.put("CARD_UNIQ_NO", " "); // 24. 카드사요청고유번호(20)
			hm.put("CARD_MCH_NO", " "); // 25. 카드사가맹점번호(20)
			hm.put("SER_COM_UNIQ_NO", " "); // 26. 회사별요청자정보(20)
			hm.put("JUMPO_SYS_DATE", todayDT.substring(0, 8)); // 27. 점포서버전문전송일자(8)
			hm.put("JUMPO_SYS_TIME", todayDT.substring(8, 6)); // 28. 점포서버전문전송시간(6)
			hm.put("RESP_CODE", " "); // 29. 응답메시지 코드(4)
			hm.put("RESP_MSG", " "); // 30. 응답메시지 설명(60)
			hm.put("HEAD_ETC_FIELD", " "); // 31. Header예약필더(201)

			/*
			 * 통합결제플랫폼조회전문 DATA 구성
			 */
			// 32. 통합바코드번호(32)
			// 33. KEY_IN유무(2)
			// 34. 신용카드인증구분(2)
			// 35. 신용카드번호(32)
			// 36. 간편결제인증번호(48)
			// 37. 간편결제인증번호(32)
			// 38. 할부개월(2)
			// 39. 전체거래금액(12)
			// 40. 할인금액(12)
			// 41. 실승인요청금액(12)
			hm.put("CARD_AUTH_DATE", " "); // 42. 승인일자(8)
			hm.put("CARD_AUTH_TIME", " "); // 43. 승인시간(6)
			hm.put("CARD_AUTH_NO", " "); // 44. 승인번호(20)
											// 45. 상품수량(4)
											// 46. 상품코드(50)
											// 47. 상품명(100)
			hm.put("ORG_SER_COM_CD", " "); // 48. 원거래회사코드(4)
											// 49. 원거래영업일자(8)
			hm.put("ORG_SER_COM_CD", hmComm.get("STORE_CD")); // 50. 원거래점코드(10)
																// 51. 원거래포스번호(4)
			hm.put("ORG_SHOP_NO", " "); // 52. 원거래매장번호(4)
										// 53. 원거래거래번호(4)
			hm.put("ORG_CD_NO", " "); // 54. 원거래CD번호(4)
										// 55. 원거래전문전송일자(8)
										// 56. 원거래전송거래고유번호(24)
										// 57. 원거래카드승인일자(8)
										// 58. 원거래카드승인번호(20)
			hm.put("DATA_ETC_FIELD", " "); // 59. DATA예비필드(627)
			byte byMSG_END[] = new byte[1];
			byMSG_END[0] = (byte) 0x0D;
			hm.put("MSG_END", new String(byMSG_END)); // 60. 전문종료내역(1)

			msgHeader = makeSendDataSSGPayHeader(hm, df);
			msgData = makeSendDataSSGPayApprovalData(hm, df);

			sendMsg = msgHeader + msgData;

			df.CommLogger("[sms>ssgpay] SEND[" + sendMsg.getBytes().length + "]:[" + sendMsg + "]");

			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>ssgpay] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>ssgpay] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("SSGPay Server is no response");
			}

			recvBuf = ((String) actSock.receive());
			df.CommLogger("[sms<ssgpay] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");

			hmRecv = protocol.getParseSSGPayRspApproval(recvBuf);

			hmRecv.put("INQ_TYPE", (String) hm.get("INQ_TYPE"));
		} catch (Exception e) {
			ret = "29";
			throw e;
		} finally {
			actSock.close();
			dataMsg = ret + makeSendDataSSGPayApprovalRsp(hmRecv, df);
		}

		return dataMsg;
	}

	public String getSSGPayInq(HashMap<String, String> hmComm, HashMap<String, String> hm, boolean bIsExtended)
			throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();

		String msgHeader = ""; // 송신전문 헤더
		String msgData = ""; // 송신전문 데이터
		String sendMsg = ""; // 신세계로 보낼 송신 전문
		String recvBuf = ""; // 신세계에서 받을 응답 전문
		String dataMsg = ""; // POS로 보낼 응답 전문
		String ret = "00";

		df.CommLogger("[sms>ssgpay] hm[" + hm + "]");
		int hmSize = hm.size(); // 20170614 SSGPAY 상시할인/PLCC 추가 KSN //POS로 받아온 전문size(구분위해)
		df.CommLogger("[sms>ssgpay] hmSize CHECK[" + hmSize + "]");

		SSGPAY_GIFTFCSTR_ID = PropertyUtil.findProperty("service-property", "SSGPAY_GIFTFCSTR_ID");

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String todayDT = sdf.format(calendar.getTime());
		String ssgpayCpYn = (String) hm.get("SSGPAY_CP_YN");

		df.CommLogger("[sms>ssgpay] ssgpayCpYn CHECK[" + ssgpayCpYn + "]");
		if ("".equals(ssgpayCpYn) || ssgpayCpYn == null) {
			ssgpayCpYn = "";
		}

		try {
			actSock = new ActionSocket(this.svrSock, (Filter) (new COMMConveyerFilter(COMMBiz.SSGPAY_FILTER)));

			/*
			 * 통합결제플랫폼조회전문 HEADER 구성
			 */
			hm.put("MSG_LEN", "1600"); // 01. 전문길이(4)
//			hm.put("MSG_ID", "POIF0100");							// 02. 전문ID(8)
			hm.put("MCH_SEND_DATE", todayDT.substring(0, 8)); // 03. 전문전송일자(8)
			hm.put("MCH_SEND_UNIQ_NO",
					hmComm.get("TRAN_YMD") + hmComm.get("POS_NO") + "0000" + "0000" + hmComm.get("TRAN_NO")); // 04.
																												// 전송거래고유번호(24)
			hm.put("MSG_GUBUN", "SEND"); // 05. 요청구분(4)
			hm.put("TRAN_TYPE", "05"); // 06. 거래TYPE(2)
			hm.put("SER_COM_CD", "5700"); // 07. 회사코드(4)
			hm.put("TERM_ID", SSGPAY_GNRFCSTR_ID); // 08. 터미널아이디(15)
			hm.put("SALE_DATE", hmComm.get("TRAN_YMD")); // 09. 영업일자(8)
			hm.put("SALE_TIME", hmComm.get("SYS_HMS")); // 10. 영업시간(6)
			hm.put("ST_CODE", hmComm.get("STORE_CD")); // 11. 점포코드(10)
			hm.put("TM_NO", hmComm.get("POS_NO")); // 12. 포스번호(4)
			hm.put("SHOP_NO", "0000"); // 13. 매장번호(4)
			hm.put("CD_NO", "0000"); // 14. CD번호(4)
			hm.put("TRAN_NO", hmComm.get("TRAN_NO")); // 15. 거래번호(4)
			hm.put("CASHER_NO", (String) hm.get("CASHER_NO").trim());// 16. Casher번호(10)
			hm.put("POS_DATE", hmComm.get("SYS_YMD")); // 17. POS시스템일자(8)
			hm.put("POS_TIME", hmComm.get("SYS_HMS")); // 18. POS시스템시간(6)
			hm.put("NORMAL_GUBUN", "NORMAL"); // 19. 정상 예외 구분(6)
			hm.put("BUY_FIRM_CODE", " "); // 20. 매입사코드(4)
			hm.put("BUY_FIRM_NM", " "); // 21. 매입사명(30)
			hm.put("ISSUE_FIRM_CODE", " "); // 22. 발행사코드(4)
			hm.put("ISSUE_FIRM_NM", " "); // 23. 발행사명(30)
			hm.put("CARD_SYS_DATE", " "); // 24. 카드사요청일자(8)
			hm.put("CARD_SYS_TIME", " "); // 25. 카드사요청시간(6)
			hm.put("CARD_UNIQ_NO", " "); // 26. 카드사요청고유번호(20)
			hm.put("CARD_MCH_NO", " "); // 27. 카드사가맹점번호(20)
			hm.put("SER_COM_UNIQ_NO", " "); // 28. 회사별요청자정보(20)
			hm.put("JUMPO_SYS_DATE", todayDT.substring(0, 8)); // 29. 점포서버전문전송일자(8)
			hm.put("JUMPO_SYS_TIME", todayDT.substring(8, 14)); // 30. 점포서버전문전송시간(6)
			hm.put("RESP_CODE", " "); // 31. 응답메시지 코드(4)
			hm.put("RESP_MSG", " "); // 32. 응답메시지 설명(60)
			hm.put("BANK_CODE", " "); // 33. 은행코드(3) -- 계좌 결제 수단 추가 2016.05.27 by OHT
			hm.put("BANK_NM", " "); // 34. 은행사명(30) -- 계좌 결제 수단 추가 2016.05.27 by OHT
			hm.put("BANK_VAN_FLAG", " "); // 35. 금융VAN구분(4) -- 계좌 결제 수단 추가 2016.05.27 by OHT
			hm.put("PLATFORM_M_ID", SSGPAY_GIFTFCSTR_ID); // 36. 플랫폼연동가맹점ID(20) -- 계좌 결제 수단 추가 2016.05.27 by OHT
			hm.put("HEAD_ETC_FIELD", " "); // 37. Header예비필더(84)

			/*
			 * 통합결제플랫폼조회전문 DATA 구성
			 */
			hm.put("DELEGATE_BARCODE_NO", (String) hm.get("DELEGATE_BARCODE_NO").trim()); // 38. 통합바코드번호(64)
			hm.put("KEY_IN_TYPE", (String) hm.get("KEY_IN_TYPE").trim()); // 39. KEY_IN유무(2)
			hm.put("EMP_ID_YN", " "); // 40. 사원증유무(1)
			hm.put("EMP_ID_NO", " "); // 41. 사원증번호(32)
			hm.put("S_POINT_YN", " "); // 42. 신세계포인트여부(1)
			hm.put("S_POINT_CARD_NO", " "); // 43. 신세계포인트카드번호(64)
			hm.put("M_GIFT_CARD_YN", " "); // 44. 모바일상품권여부(1)
			hm.put("M_GIFT_CARD_NO", " "); // 45. 모바일상품권번호(64)
			hm.put("M_GIFT_CONFIRM_NO", " "); // 46. 모바일상품권인증번호(32)
			hm.put("M_GIFT_CARD_AMT", " "); // 47. 모바일상품권잔액(12)
			hm.put("CARD_YN", " "); // 48. 신용카드여부(1)
			hm.put("CARD_CNT", " "); // 49. 응답카드수량(1)
			hm.put("CARD_CERT_FLAG_1", " "); // 50. 신용카드인증구분(2)
			hm.put("CARD_NO_1", " "); // 51. 신용카드번호(64)
			hm.put("CARD_DATE_NO_1", " "); // 52. 신용카드유효기간(32)
			hm.put("CARD_CERTIFY_NO_1", " "); // 53. 인증번호(96)
			hm.put("CARD_TRACK2DATA_1", " "); // 54. 가상 TRACK2 DATA(96)
			hm.put("CARD_ETC_DATA_1", " "); // 55. 카드사 예비필드(128)
			hm.put("CARD_RECEIPT_A_1", " "); // 56. 영수증 출력 A(32)
			hm.put("CARD_RECEIPT_D_1", " "); // 57. 영수증 출력 D(32)
			hm.put("CASH_RECEIPT_YN", " "); // 58. 현금영수증식별여부(1)
			hm.put("CASH_RECEIPT_INFO", " "); // 59. 현금영수증식별정보(32)
			hm.put("DIRECT_AUTH_FLAG", " "); // 60. 가맹점직라인여부(미적용)
			if (hmSize >= 10) {
				if (!"".equals((String) hm.get("DC_MD_IN_YN")) && (String) hm.get("DC_MD_IN_YN") != null) {
					hm.put("EVENT_MD_IN_YN", (String) hm.get("DC_MD_IN_YN")); // 61. 이벤트상품포함여부
				} else {
					hm.put("EVENT_MD_IN_YN", " "); // 61. 이벤트상품포함여부
				}
			} else {
				if (bIsExtended) {
					hm.put("EVENT_MD_IN_YN", (String) hm.get("EVENT_MD_IN_YN")); // 61. 이벤트상품포함여부
				} else {
					hm.put("EVENT_MD_IN_YN", " "); // 61. 이벤트상품포함여부
				}
			}
			df.CommLogger("[sms>ssgpay] SEND[" + hm.get("EVENT_MD_IN_YN") + "]");

			hm.put("EVENT_YN", " "); // 62. 이벤트참여식별여부
			hm.put("BANK_YN", " "); // 63. 가상은행계좌 여부(1) -- 계좌 결제 수단 추가 2016.05.27 by OHT
			hm.put("BANK_ACCOUNT_NO", " "); // 64. 가상은행계좌번호(96) -- 계좌 결제 수단 추가 2016.05.27 by OHT
			hm.put("BANK_RECEIPT", " "); // 65. 은행계좌 영수증 출력(15) -- 계좌 결제 수단 추가 2016.05.27 by OHT
			hm.put("CARD_BIN", " "); // 66. 실 카드빈(6) --SSGPAY 상시할인/PLCC 추가 20170613 KSN

			hm.put("SSGPAY_CP_YN", ssgpayCpYn); // 67. SSGPAY 쿠폰 존재 여부(1) --SSGPAY 상시할인/PLCC 추가 20170613 KSN
			hm.put("SSGPAY_CP_FLAG", " "); // 68. SSGPAY 쿠폰 구분자(1) --SSGPAY 상시할인/PLCC 추가 20170613 KSN
			hm.put("SSGPAY_CP_APPLY", " "); // 69. SSGPAY 쿠폰 적용 액(8) --SSGPAY 상시할인/PLCC 추가 20170613 KSN
			hm.put("SSGPAY_CP_MAX_AMT", " "); // 70. SSGPAY 쿠폰 최대 금액(8) --SSGPAY 상시할인/PLCC 추가 20170613 KSN

			df.CommLogger("[sms>ssgpay] SSGPAY_CP_YN::[" + ssgpayCpYn + "]");
			df.CommLogger("[sms>ssgpay] SEND[CARD_BIN:" + hm.get("CARD_BIN") + " ,SSGPAY_CP_YN:"
					+ hm.get("SSGPAY_CP_YN") + " ,SSGPAY_CP_FLAG:" + hm.get("SSGPAY_CP_FLAG") + ", SSGPAY_CP_APPLY:"
					+ hm.get("SSGPAY_CP_APPLY") + ", SSGPAY_CP_MAX_AMT:" + hm.get("SSGPAY_CP_MAX_AMT") + "]");

			hm.put("DATA_ETC_FIELD", " "); // 71. DATA예비필드(170)
			hm.put("MSG_END", " "); // 72. 전문종료내역(1)

			msgHeader = makeSendDataSSGPayHeader(hm, df);
			msgData = makeSendDataSSGPayInqData(hm, df);
			sendMsg = msgHeader + msgData;
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			// 전문종료내역 설정
			sendBytes[1599] = (byte) 0x0d;

			df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "]:[" + (new String(sendBytes)) + "]");

			if (actSock.send(sendBytes, sendBytes.length)) {
				df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "] OK");
			} else {
				df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSGPay Server is no response");
			}

			recvBuf = ((String) actSock.receive());
			df.CommLogger("[sms<ssgpay] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");

			hmRecv = protocol.getParseSSGPayRspInq(recvBuf);
			df.CommLogger("hmRecv[" + hmRecv + "]");

			hmRecv.put("INQ_TYPE", (String) hm.get("INQ_TYPE"));

			// 20170614 SSGPAY 상시할인/PLCC 추가 KSN
			/*
			 * if(hmSize == 10){//상시10%할인, PLCC 가능한 경우 SSGPAY_CP_YN만 put 시켜주면 됨
			 * df.CommLogger("EVENT_YN[" + (String)hmRecv.get("EVENT_YN") + "]");
			 * 
			 * hmRecv.put("SSGPAY_DC_YN", (String)hmRecv.get("EVENT_YN"));
			 * 
			 * }
			 */

			hmRecv.put("CARD_BIN", stringNullReplace((String) hmRecv.get("CARD_BIN")));
			hmRecv.put("SSGPAY_DC_YN", stringNullReplace((String) hmRecv.get("EVENT_YN")));
			hmRecv.put("SSGPAY_CP_YN", stringNullReplace((String) hmRecv.get("SSGPAY_CP_YN")));
			hmRecv.put("SSGPAY_CP_FLAG", stringNullReplace((String) hmRecv.get("SSGPAY_CP_FLAG")));
			hmRecv.put("SSGPAY_CP_APPLY", stringNullReplace((String) hmRecv.get("SSGPAY_CP_APPLY")));
			hmRecv.put("SSGPAY_CP_MAX_AMT", stringNullReplace((String) hmRecv.get("SSGPAY_CP_MAX_AMT")));

			df.CommLogger("CARD_BIN[" + (String) hmRecv.get("CARD_BIN") + "]");
			df.CommLogger("SSGPAY_DC_YN[" + (String) hmRecv.get("SSGPAY_DC_YN") + "]");
			df.CommLogger("SSGPAY_CP_YN[" + (String) hmRecv.get("SSGPAY_CP_YN") + "]");
			df.CommLogger("SSGPAY_CP_FLAG[" + (String) hmRecv.get("SSGPAY_CP_FLAG") + "]");
			df.CommLogger("SSGPAY_CP_APPLY[" + (String) hmRecv.get("SSGPAY_CP_APPLY") + "]");
			df.CommLogger("SSGPAY_CP_MAX_AMT[" + (String) hmRecv.get("SSGPAY_CP_MAX_AMT") + "]");
			// 20170614 SSGPAY 상시할인/PLCC 추가 KSN

		} catch (Exception e) {
			ret = "29";
			throw e;
		} finally {
			actSock.close();
			dataMsg = ret + makeSendDataSSGPayInqRsp(hmRecv, df);
		}
		df.CommLogger("dataMsg[" + dataMsg + "]");
		System.out.println("dataMsg[" + dataMsg + "]");

		return dataMsg;
	}

	private String stringNullReplace(String data) throws Exception {
		String str = data;

		if (str == null) {
			str = "";
		}

		df.CommLogger("str[" + str + "]");
		return str;
	}

	public String getSSGPayCoupon(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();

		String msgHeader = ""; // 송신전문 헤더
		String msgData = ""; // 송신전문 데이터
		String sendMsg = ""; // 신세계로 보낼 송신 전문
		String recvBuf = ""; // 신세계에서 받을 응답 전문
		String dataMsg = ""; // POS로 보낼 응답 전문
		String ret = "00";

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String todayDT = sdf.format(calendar.getTime());

		try {
			df.CommLogger("getSSGPayCoupon hmComm[" + hmComm + "]");
			df.CommLogger("getSSGPayCoupon hm[" + hm + "]");
			actSock = new ActionSocket(this.svrSock, (Filter) (new COMMConveyerFilter(COMMBiz.SSGPAY_FILTER)));

			/* SPACE는 오른쪽부터 체움 */
			/* 통합결제플랫폼조회전문 HEADER 구성 */
			hm.put("MSG_LEN", "0900"); // 01.전문길이(4) : 0900
			hm.put("MSG_ID", (String) hm.get("MSG_ID").trim()); // 02.전문 ID(8) : 승인/취소-CPAU0200, 망취소-CPIM0300
			hm.put("MCH_SEND_DATE", (String) hm.get("MCH_SEND_DATE").trim()); // 03.전문전송일자(8)
			hm.put("MCH_SEND_UNIQ_NO", (String) hm.get("MCH_SEND_UNIQ_NO").trim()); // 04.전송 거래고유번호(20) :
																					// 영업일자(8)+포스번호(4)+CD번호(4)+거래번호(4)
			hm.put("MCH_NO", (String) hm.get("MCH_NO").trim()); // 05.가맹점번호(15) : IC00000000

			hm.put("MSG_GUBUN", (String) hm.get("MSG_GUBUN").trim()); // 06.요청구분(4) : SEND
			hm.put("SER_COM_CD", (String) hm.get("SER_COM_CD").trim()); // 07.회사코드(4) : 5700
			hm.put("SALE_DATE", (String) hm.get("SALE_DATE").trim()); // 08.영업일자(8)
			hm.put("SALE_TIME", (String) hm.get("SALE_TIME").trim()); // 09.영업시간(6)
			hm.put("ST_CODE", (String) hm.get("ST_CODE").trim()); // 10.점코드(10)

			hm.put("TM_NO", (String) hm.get("TM_NO").trim()); // 11.포스번호(4)
			hm.put("CD_NO", (String) hm.get("CD_NO").trim()); // 12.CD번호(4)
			hm.put("TRAN_NO", (String) hm.get("TRAN_NO").trim()); // 13.거래번호(4)
			hm.put("CASHER_NO", (String) hm.get("CASHER_NO").trim()); // 14.Casher번호(10)
			hm.put("POS_DATE", (String) hm.get("POS_DATE").trim()); // 15.POS시스템일자(8)

			hm.put("POS_TIME", (String) hm.get("POS_TIME").trim()); // 16.POS시스템시간(6)
			hm.put("SER_COM_UNIQ_NO", " "); // 17.회사별 요청자 정보(20) : SPACE로 체움
			hm.put("JUMPO_SYS_DATE", todayDT.substring(0, 8)); // 18.점포서버 전문전송일자(8)
			hm.put("JUMPO_SYS_TIME", todayDT.substring(8, 14)); // 19.점포서버 전문전송시간(6)
			hm.put("HEAD_ETC_FIELD", " "); // 20.헤더예비필드(53) : SPACE로 체움

			/* 통합결제플랫폼조회전문 DETAIL 구성 */
			hm.put("TRAN_TYPE", (String) hm.get("TRAN_TYPE").trim()); // 21.거래 TYPE(2) : 승인-00, 취소-01, 망취소-03
			hm.put("TRADE_TYPE", (String) hm.get("TRADE_TYPE").trim()); // 22.요청 TYPE(2) : 회수-25, 취소-65
			hm.put("TRACK_TYPE", (String) hm.get("TRACK_TYPE").trim()); // 23.Track2 유무(1) : 개별-3
			hm.put("END_BARCODE", " "); // 24.종료바코드(100) : SPACE로 체움
			hm.put("GIFT_CARD_NO", (String) hm.get("GIFT_CARD_NO").trim()); // 25.쿠폰 번호(100)

			hm.put("CONFIRM_NO", (String) hm.get("CONFIRM_NO").trim()); // 26.PIN 번호(50) : SPACE로 체움
			hm.put("KEY_IN_TYPE", (String) hm.get("KEY_IN_TYPE").trim()); // 27.KEY IN 유무(2) : 바코드-05, WEB-06, SWIP-00,
																			// KEYIN-01, RF-02, IR-03
			hm.put("TRADE_AMT", (String) hm.get("TRADE_AMT").trim()); // 28.요청금액(12)
			hm.put("SPECIAL_GUBUN", (String) hm.get("SPECIAL_GUBUN").trim()); // 29.거래별 구분 코드(1) : 일반-1
			hm.put("USE_GUBUN", (String) hm.get("USE_GUBUN").trim()); // 30.사용구분(1) : 승인-1, 그외-NULL

			hm.put("GOODS_GUBUN", (String) hm.get("GOODS_GUBUN").trim()); // 31.상품종류구분(1) : 쿠폰-5
			hm.put("PART_GUBUN", (String) hm.get("PART_GUBUN").trim()); // 32.제휴사구분코드(2) : 자사상품-60
			hm.put("MOBILE_NO", (String) hm.get("MOBILE_NO").trim()); // 33.선물하기 번호(20) : SPACE로 체움
			hm.put("ORG_SER_COM_CD", (String) hm.get("ORG_SER_COM_CD").trim()); // 34.원거래 회사코드(4) : 취소-승인정보, 승인-SPACE
			hm.put("ORG_SALE_DATE", (String) hm.get("ORG_SALE_DATE").trim()); // 35.원거래 영업일자(8) : 취소-승인정보, 승인-SPACE

			hm.put("ORG_ST_CODE", (String) hm.get("ORG_ST_CODE").trim()); // 36.원거래 점코드(10) : 취소-승인정보, 승인-SPACE
			hm.put("ORG_TM_NO", (String) hm.get("ORG_TM_NO").trim()); // 37.원거래 포스번호(4) : 취소-승인정보, 승인-SPACE
			hm.put("ORG_TRAN_NO", (String) hm.get("ORG_TRAN_NO").trim()); // 38.원거래 거래 번호(4) : 취소-승인정보, 승인-SPACE
			hm.put("ORG_CD_NO", (String) hm.get("ORG_CD_NO").trim()); // 39.원거래 CD 번호(4) : 취소-승인정보, 승인-SPACE
			hm.put("ORG_SEND_DATE", (String) hm.get("ORG_SEND_DATE").trim()); // 40.원거래 전문전송일자(8) : 취소-승인정보, 승인-SPACE

			hm.put("ORG_SEND_UNIQ_NO", (String) hm.get("ORG_SEND_UNIQ_NO").trim()); // 41.원거래 전송 거래고유번호(20) : 취소-승인정보,
																					// 승인-SPACE
			hm.put("ORG_MCH_NO", (String) hm.get("ORG_MCH_NO").trim()); // 42.원거래 가맹점번호(15) : 취소-승인정보, 승인-SPACE
			hm.put("ORG_AUTH_DATE", (String) hm.get("ORG_AUTH_DATE").trim()); // 43.원거래 승인일자(8) : 취소-승인정보, 승인-SPACE
			hm.put("ORG_AUTH_NO", (String) hm.get("ORG_AUTH_NO").trim()); // 44.원거래 승인번호(8) : 취소-승인정보, 승인-SPACE
			hm.put("AUTH_DATE", " "); // 45.승인일자(8) : SPACE로 체움

			hm.put("AUTH_TIME", " "); // 46.승인시간(6) : SPACE로 체움
			hm.put("AUTH_NO", " "); // 47.승인번호(8) : SPACE로 체움
			hm.put("REMAIN_AMT", " "); // 48.잔액(12) : SPACE로 체움
			hm.put("MD_CODE", " "); // 49.상품 코드(30) : SPACE로 체움
			hm.put("RESP_CODE", " "); // 50.응답 코드(4) : SPACE로 체움

			hm.put("RESP_MSG", " "); // 51.응답메시지(60) : SPACE로 체움
			hm.put("DATA_ETC_FIELD", " "); // 52.DATA예비필드(174) : SPACE로 체움
			hm.put("MSG_END", " "); // 53.전문 종료 내역(1) : SPACE로 체움

			sendMsg = makeSendDataSSGPayCoupon(hm, df);
//			sendMsg = msgHeader + msgData;
//			// 전송할 메시지를  byte 배열로 변환
//			byte sendBytes[] = sendMsg.getBytes();
//			// 전문종료내역 설정
//			sendBytes[1599] = (byte)0x0d;
//
//			df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "]:[" + (new String(sendBytes)) + "]");
//			
//			if (actSock.send(sendBytes, sendBytes.length)) {
			// 전송할 메시지를 byte 배열로 변환
			df.CommLogger("getSSGPayCoupon sendMsg[" + sendMsg + "]");
			byte sendBytes[] = sendMsg.getBytes();
			df.CommLogger("getSSGPayCoupon sendBytes 1[" + sendBytes + "]");
			// 전문종료내역 설정
			sendBytes[899] = (byte) 0x0d;

			df.CommLogger("getSSGPayCoupon sendBytes 2[" + sendBytes + "]");

			df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "]:[" + (new String(sendBytes)) + "]");

			if (actSock.send(sendBytes, sendBytes.length)) {
				df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "] OK");
			} else {
				df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSGPay Server is no response");
			}

			recvBuf = ((String) actSock.receive());
			df.CommLogger("[sms<ssgpay] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");

			hmRecv = protocol.getParseSSGPayCouponRsp(recvBuf);
			df.CommLogger("hmRecv[" + hmRecv + "]");

			hmRecv.put("INQ_TYPE", (String) hm.get("INQ_TYPE"));
		} catch (Exception e) {
			ret = "29";
			throw e;
		} finally {
			actSock.close();
			dataMsg = ret + makeSendDataSSGPayCouponRsp(hmRecv, df);
		}
		df.CommLogger("dataMsg[" + dataMsg + "]");

		return dataMsg;
	}

	private String makeSendDataSSGPayHeader(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 4, 8, 8, 24, 4, 2, 4, 15, 8, 6, 10, 4, 4, 4, 4, 10, 8, 6, 6, 4, 30, 4, 30, 8, 6, 20, 20, 20, 8,
				6, 4, 60, 3, 30, 4, 20, 84 };
		String strHeaders[] = { 
				"MSG_LEN", // 01. 전문길이(4)
				"MSG_ID", // 02. 전문ID(8)
				"MCH_SEND_DATE", // 03. 전문전송일자(8)
				"MCH_SEND_UNIQ_NO", // 04. 전송거래고유번호(24)
				"MSG_GUBUN", // 05. 요청구분(4)

				"TRAN_TYPE", // 06. 거래TYPE(2)
				"SER_COM_CD", // 07. 회사코드(4)
				"TERM_ID", // 08. 터미널아이디(15)
				"SALE_DATE", // 09. 영업일자(8)
				"SALE_TIME", // 10. 영업시간(6)

				"ST_CODE", // 11. 점포코드(10)
				"TM_NO", // 12. 포스번호(4)
				"SHOP_NO", // 13. 매장번호(4)
				"CD_NO", // 14. CD번호(4)
				"TRAN_NO", // 15. 거래번호(4)

				"CASHER_NO", // 16. Casher번호(10)
				"POS_DATE", // 17. POS시스템일자(8)
				"POS_TIME", // 18. POS시스템시간(6)
				"NORMAL_GUBUN", // 19. 정상 예외 구분(6)
				"BUY_FIRM_CODE", // 20. 매입사코드(4)

				"BUY_FIRM_NM", // 21. 매입사명(30)
				"ISSUE_FIRM_CODE", // 22. 발행사코드(4)
				"ISSUE_FIRM_NM", // 23. 발행사명(30)
				"CARD_SYS_DATE", // 24. 카드사요청일자(8)
				"CARD_SYS_TIME", // 25. 카드사요청시간(6)

				"CARD_UNIQ_NO", // 26. 카드사요청고유번호(20)
				"CARD_MCH_NO", // 27. 카드사가맹점번호(20)
				"SER_COM_UNIQ_NO", // 28. 회사별요청자정보(20)
				"JUMPO_SYS_DATE", // 29. 점포서버전문전송일자(8)
				"JUMPO_SYS_TIME", // 30. 점포서버전문전송시간(6)

				"RESP_CODE", // 31. 응답메시지 코드(4)
				"RESP_MSG", // 32. 응답메시지 설명(60)
				"BANK_CODE", // 33. 은행코드(3) -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"BANK_NM", // 34. 은행사명(30) -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"BANK_VAN_FLAG", // 35. 금융VAN구분(4) -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"PLATFORM_M_ID", // 36. 플랫폼연동가맹점ID(20) -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"HEAD_ETC_FIELD" // 37. Header예비필더(84)
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGPayMGiftApproval(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 4, 8, 8, 20, 15, 4, 4, 8, 6, 10, 4, 4, 4, 10, 8, 6, 20, 8, 6, 53, 2, 2, 2, 2, 20, 1, 50, 50, 3,
				100, 50, 2, 12, 1, 1, 1, 2, 4, 20, 4, 8, 10, 4, 4, 4, 8, 20, 15, 8, 8, 8, 6, 8, 12, 30, 4, 60, 12, 48,
				12, 12, 12, 12, 12, 23, 1 };
		String strHeaders[] = { "MSG_LEN", "MSG_ID", "MCH_SEND_DATE", "MCHH_SEND_UNIQ_NO", "GIFT_MCH_NO",

				"MSG_GUBUN", "SER_COM_CD", "SALE_DATE", "SALE_TIME", "ST_CODE",

				"TM_NO", "CD_NO", "TRAN_NO", "CASHER_NO", "POS_DATE",

				"POS_TIME", "SER_COM_UNIQ_NO", "JUMPO_SYS_DATE", "JUMPO_SYS_TIME", "HEAD_ETC_FIELD",

				"TRAN_TYPE", "TRADE_TYPE", "EVENT_GUBUN", "EVENT_TYPE", "EVENT_NO",

				"TRACK_TYPE", "START_BARCODE", "END_BARCODE", "BARCODE_CNT", "GIFT_CARD_NO",

				"GIFT_CONFIRM_NO", "KEY_IN_TYPE", "TRADE_AMT", "SPECIAL_GUBUN", "USE_GUBUN",

				"GIFT_GUBUN", "PART_GUBUN", "GIFT_CODE", "GIFT_MOMILE_NO", "ORG_SER_COM_CD",

				"ORG_SALE_DATE", "ORG_ST_CODE", "ORG_TM_NO", "ORG_TRAN_NO", "ORG_CD_NO",

				"ORG_SEND_DATE", "ORG_SEND_UNIQ_NO", "ORG_GIFT_MCH_NO", "ORG_AUTH_DATE", "ORG_AUTH_NO",

				"AUTH_DATE", "AUTH_TIME", "AUTH_NO", "REMAIN_AMT", "MD_CODE",

				"RESP_CODE", "RESP_MSG", "REFUND_ABLE_AMT", "PLATFORM_BARCODE", "NORM_REF_AMT",

				"NORM_REF_FEE", "SWAP_REF_AMT", "SWAP_REF_FEE", "FREE_REF_AMT", "DATA_ETC_FIELD",

				"MSG_END" };

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGPayAccountApproval(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 4, 8, 8, 24, 4, 2, 4, 15, 8, 6, 10, 4, 4, 4, 4, 10, 8, 6, 6, 4, 30, 4, 30, 8, 6, 20, 20, 20, 8,
				6, 4, 60, 3, 30, 4, 20, 84, 64, 2, 96, 12, 12, 12, 8, 6, 15, 4, 50, 100, 8, 24, 4, 8, 10, 4, 4, 4, 4,
				10, 8, 15, 2, 1, 64, 12, 536, 1 };
		String strHeaders[] = { "MSG_LEN", // 01. 전문길이(4)
				"MSG_ID", // 02. 전문ID(8)
				"MCH_SEND_DATE", // 03. 전문전송일자(8)
				"MCH_SEND_UNIQ_NO", // 04. 전송거래고유번호(24)
				"MSG_GUBUN", // 05. 요청구분(4)

				"TRAN_TYPE", // 06. 거래TYPE(2)
				"SER_COM_CD", // 07. 회사코드(4)
				"TERM_ID", // 08. 터미널아이디(15)
				"SALE_DATE", // 09. 영업일자(8)
				"SALE_TIME", // 10. 영업시간(6)

				"ST_CODE", // 11. 점코드(10)
				"TM_NO", // 12. 포스번호(4)
				"SHOP_NO", // 13. 매장번호(4)
				"CD_NO", // 14. CD번호(4)
				"TRAN_NO", // 15. TRAN_NO(4)

				"CASHER_NO", // 16. Casher번호(10)
				"POS_DATE", // 17. POS시스템일자(8)
				"POS_TIME", // 18. POS시스템시간(6)
				"NORMAL_GUBUN", // 19. 정상 예외 구분(6)
				"BUY_FIRM_CODE", // 20. 매입사코드(4)

				"BUY_FIRM_NM", // 21. 매입사명(30)
				"ISSUE_FIRM_CODE", // 22. 발행사코드(4)
				"ISSUE_FIRM_NM", // 23. 발행사명(30)
				"CARD_SYS_DATE", // 24. 카드사요청일자(8)
				"CARD_SYS_TIME", // 25. 카드사요청시간(6)

				"CARD_UNIQ_NO", // 26. 카드사요청고유번호(20)
				"CARD_MCH_NO", // 27. 카드사가맹점번호(20)
				"SER_COM_UNIQ_NO", // 28. 회사별요청자정보(20)
				"JUMPO_SYS_DATE", // 29. 점포서버전문전송일자(8)
				"JUMPO_SYS_TIME", // 30. 점포서버전문전송시간(6)

				"RESP_CODE", // 31. 응답메시지 코드(4)
				"RESP_MSG", // 32. 응답메시지 설명(60)
				"BANK_CODE", // 33. 은행코드(3)
				"BANK_NM", // 34. 은행사명(30)
				"BANK_VAN_FLAG", // 35. 금융VAN구분(4)

				"PLATFORM_M_ID", // 36. 플랫폼연동가맹점ID(20)
				"HEAD_ETC_FIELD", // 37. Header예비필더(84)
				"DELEGATE_BARCODE_NO", // 38. 통합바코드번호(64)
				"KEY_IN_TYPE", // 39. KEY_IN유무(2)
				"BANK_ACCOUNT_NO", // 40. 가상은행계좌번호(96)

				"BANK_TOT_TRADE_AMT", // 41. 전체거래금액(12)
				"BANK_DIS_TRADE_AMT", // 42. 에누리금액(12)
				"BANK_NET_TRADE_AMT", // 43. 실승인요청금액(12)
				"BANK_AUTH_DATE", // 44. 가상은행계좌 승인일자(8)
				"BANK_AUTH_TIME", // 45. 가상은행계좌 승인시간(6)

				"BANK_AUTH_NO", // 46. 가상은행계좌 승인번호(15)
				"MD_CNT", // 47. 상품 수량(4)
				"MD_CODE", // 48. 회사별 상품 코드 (50)
				"MD_NAME", // 49. 상품명(100)
				"ORG_SEND_DATE", // 50. 원거래 전문전송일자(8)

				"ORG_SEND_UNIQ_NO", // 51. 원거래 전송 거래고유번호(24)
				"ORG_SER_COM_CD", // 52. 원거래 회사코드(4)
				"ORG_SALE_DATE", // 53. 원거래 영업일자(8)
				"ORG_ST_CODE", // 54. 원거래 점코드(10)
				"ORG_TM_NO", // 55. 원거래 포스 번호(4)

				"ORG_SHOP_NO", // 56. 원거래 매장번호(4)
				"ORG_CD_NO", // 57. 원거래 CD 번호(4)
				"ORG_TRAN_NO", // 58. 원거래 거래 번호(4)
				"ORG_CASHER_NO", // 59. 원거래 Casher 번호(10)
				"ORG_BANK_AUTH_DATE", // 60. 원거래 가상은행계좌 승인일자 (8)

				"ORG_BANK_AUTH_NO", // 61. 원거래 가상은행계좌 승인번호(15)
				"CNCL_GUBUN", // 62. 취소 구분(2)
				"CNCL_USE_YN", // 63. 부분취소 가능 여부(1)
				"ORG_DELEGATE_BARCODE_NO", // 64. 원거래 통합바코드번호(64)
				"ORG_BANK_AUTH_AMT", // 65. 원거래 실승인요청금액(12)

				"DATA_ETC_FIELD", // 66. DATA예비필드(536)
				"MSG_END" // 67. 전문 종료 내역(1)
		};

		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger(
					"★ make send strHeaders : [" + strHeaders[i] + "]" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGPayMGiftCharge(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 4, 8, 8, 20, 15, 4, 4, 8, 6, 10, 4, 4, 4, 10, 8, 6, 20, 8, 6, 53, 2, 2, 24, 1, 100, 3, 100, 50,
				2, 12, 1, 1, 1, 2, 4, 20, 4, 8, 10, 4, 4, 4, 8, 20, 15, 8, 8, 8, 6, 8, 12, 30, 4, 60, 12, 48, 60, 2, 21,
				1 };
		String strHeaders[] = { "MSG_LEN", "MSG_ID", "MCH_SEND_DATE", "MCHH_SEND_UNIQ_NO", "GIFT_MCH_NO",

				"MSG_GUBUN", "SER_COM_CD", "SALE_DATE", "SALE_TIME", "ST_CODE",

				"TM_NO", "CD_NO", "TRAN_NO", "CASHER_NO", "POS_DATE",

				"POS_TIME", "SER_COM_UNIQ_NO", "JUMPO_SYS_DATE", "JUMPO_SYS_TIME", "HEAD_ETC_FIELD",

				"TRAN_TYPE", "TRADE_TYPE", "EVENT_ETC_FIELD", "TRACK_TYPE", "BARCODE_ETC_FIELD",

				"BARCODE_CNT", "GIFT_CARD_NO", "GIFT_CONFIRM_NO", "KEY_IN_TYPE", "TRADE_AMT",

				"SPECIAL_GUBUN", "USE_GUBUN", "GIFT_GUBUN", "PART_GUBUN", "GIFT_CODE",

				"GIFT_MOMILE_NO", "ORG_SER_COM_CD", "ORG_SALE_DATE", "ORG_ST_CODE", "ORG_TM_NO",

				"ORG_TRAN_NO", "ORG_CD_NO", "ORG_SEND_DATE", "ORG_SEND_UNIQ_NO", "ORG_GIFT_MCH_NO",

				"ORG_AUTH_DATE", "ORG_AUTH_NO", "AUTH_DATE", "AUTH_TIME", "AUTH_NO",

				"REMAIN_AMT", "MD_CODE", "RESP_CODE", "RESP_MSG", "REFUND_ABLE_AMT",

				"PLATFORM_BARCODE", "AMT_ETC_FIELD", "PAY_TYPE", "DATA_ETC_FIELD", "MSG_END" };

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGPayMGiftApprovalRsp(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 60, 12, 12, 8, 8, 6, 8 };
		String strHeaders[] = { "INQ_TYPE", "RESP_CODE", "RESP_MSG", "REFUND_ABLE_AMT", "REMAIN_AMT",

				"MCH_SEND_DATE", "AUTH_DATE", "AUTH_TIME", "AUTH_NO" };

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGPayAccountApprovalRsp(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 60, 12, 8, 8, 6, 15, 20 };
		String strHeaders[] = { "INQ_TYPE", "RESP_CODE", "RESP_MSG", "BANK_NET_TRADE_AMT", "MCH_SEND_DATE",

				"AUTH_DATE", "AUTH_TIME", "AUTH_NO", "CARD_UNIQ_NO" };

		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger(
					"★ make send strHeaders : [" + strHeaders[i] + "]" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGPayApprovalData(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 32, 2, 2, 32, 48, 32, 2, 12, 12, 12, 8, 6, 20, 4, 50, 100, 4, 8, 10, 4, 4, 4, 4, 8, 24, 8, 20,
				627, 1 };
		String strHeaders[] = { "DELEGATE_BARCODE_NO", // 32. 통합바코드번호(32)
				"KEY_IN_TYPE", // 33. KEY_IN유무(2)
				"CARD_CERT_FLAG", // 34. 신용카드인증구분(2)
				"CARD_NO", // 35. 신용카드번호(32)
				"CARD_LOCAL_CERTIFY_NO", // 36. 간편결제인증번호(48)

				"CARD_OTC_CERTIFY_NO", // 37. 간편결제인증번호(32)
				"INS_MON", // 38. 할부개월(2)
				"CARD_TOT_TRADE_AMT", // 39. 전체거래금액(12)
				"CARD_DIS_TRADE_AMT", // 40. 할인금액(12)
				"CARD_NET_TRADE_AMT", // 41. 실승인요청금액(12)

				"CARD_AUTH_DATE", // 42. 승인일자(8)
				"CARD_AUTH_TIME", // 43. 승인시간(6)
				"CARD_AUTH_NO", // 44. 승인번호(20)
				"MD_CNT", // 45. 상품수량(4)
				"MD_CODE", // 46. 상품코드(50)

				"MD_NAME", // 47. 상품명(100)
				"ORG_SER_COM_CD", // 48. 원거래회사코드(4)
				"ORG_SALE_DATE", // 49. 원거래영업일자(8)
				"ORG_ST_CODE", // 50. 원거래점코드(10)
				"ORG_TM_NO", // 51. 원거래포스번호(4)

				"ORG_SHOP_NO", // 52. 원거래매장번호(4)
				"ORG_TRAN_NO", // 53. 원거래거래번호(4)
				"ORG_CD_NO", // 54. 원거래CD번호(4)
				"ORG_SEND_DATE", // 55. 원거래전문전송일자(8)
				"ORG_SEND_UNIQ_NO", // 56. 원거래전송거래고유번호(24)

				"ORG_CARD_AUTH_DATE", // 57. 원거래카드승인일자(8)
				"ORG_CARD_AUTH_NO", // 58. 원거래카드승인번호(20)
				"DATA_ETC_FIELD", // 59. DATA예비필드(627)
				"MSG_END" // 60. 전문종료내역(1)
		};

		for (int i = 0; i < nlens.length; i++) {
			// df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String)
			// hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGPayInqData(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 64, 2, 1, 32, 1, 64, 1, 64, 32, 12, 1, 1, 2, 64, 32, 96, 96, 128, 32, 32, 1, 32, 1, 1, 1, 1, 96,
				15, 6, 1, 1, 8, 8, 170, 1 };
		String strHeaders[] = { "DELEGATE_BARCODE_NO", // 38. 통합바코드번호(64)
				"KEY_IN_TYPE", // 39. KEY_IN유무(2)
				"EMP_ID_YN", // 40. 사원증유무(1)
				"EMP_ID_NO", // 41. 사원증번호(32)
				"S_POINT_YN", // 42. 신세계포인트여부(1)

				"S_POINT_CARD_NO", // 43. 신세계포인트카드번호(64)
				"M_GIFT_CARD_YN", // 44. 모바일상품권여부(1)
				"M_GIFT_CARD_NO", // 45. 모바일상품권번호(64)
				"M_GIFT_CONFIRM_NO", // 46. 모바일상품권인증번호(32)
				"M_GIFT_CARD_AMT", // 47. 모바일상품권잔액(12)

				"CARD_YN", // 48. 신용카드여부(1)
				"CARD_CNT", // 49. 응답카드수량(1)
				"CARD_CERT_FLAG_1", // 50. 신용카드인증구분(2)
				"CARD_NO_1", // 51. 신용카드번호(64)
				"CARD_DATE_NO_1", // 52. 신용카드유효기간(32)

				"CARD_CERTIFY_NO_1", // 53. 인증번호(96)
				"CARD_TRACK2DATA_1", // 54. 가상 TRACK2 DATA(96)
				"CARD_ETC_DATA_1", // 55. 카드사 예비필드(128)
				"CARD_RECEIPT_A_1", // 56. 영수증출력A(32)
				"CARD_RECEIPT_D_1", // 57. 영수증출력D(32)

				"CASH_RECEIPT_YN", // 58. 현금영수증식별여부(1)
				"CASH_RECEIPT_INFO", // 59. 현금영수증식별정보(32)
				"DIRECT_AUTH_FLAG", // 60. 가맹점직라인여부(1)
				"EVENT_MD_IN_YN", // 61. 이벤트상품포함여부(1)
				"EVENT_YN", // 62. 이벤트참여식별여부(1)

				"BANK_YN", // 63. 가상은행계좌 여부(1) -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"BANK_ACCOUNT_NO", // 64. 가상은행계좌번호(96) -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"BANK_RECEIPT", // 65. 은행계좌 영수증 출력(15) -- 계좌 결제 수단 추가 2016.05.27 by OHT
				"CARD_BIN", // 66. 실 카드빈(6) -- SSGPAY 상시할인/PLCC 추가 20170613 KSN
				"SSGPAY_CP_YN", // 67. SSGPAY 쿠폰 존재 여부(1) -- SSGPAY 상시할인/PLCC 추가 20170613 KSN

				"SSGPAY_CP_FLAG", // 68. SSGPAY 쿠폰 구분자(1) -- SSGPAY 상시할인/PLCC 추가 20170613 KSN
				"SSGPAY_CP_APPLY", // 69. SSGPAY 쿠폰 적용 액(8) -- SSGPAY 상시할인/PLCC 추가 20170613 KSN
				"SSGPAY_CP_MAX_AMT", // 70. SSGPAY 쿠폰 최대 금액(8) -- SSGPAY 상시할인/PLCC 추가 20170613 KSN
				"DATA_ETC_FIELD", // 71. DATA예비필드(170)
				"MSG_END" // 72. 전문종료내역(1)
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGPayInqRsp(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 60, 8, 2, 8, 6, 4, 30, 4, 30, 1, 32, 1, 64, 1, 64, 32, 12, 1, 1, 2, 64, 32, 96, 96, 128,
				32, 32, 1, 32, 1, 3, 30, 4, 20, 1, 96, 15, 6, 1, 1, 1, 8, 8 };

		String strHeaders[] = { "INQ_TYPE", // 1. INQ종별(2)
				"RESP_CODE", // 2. 응답코드(4)
				"RESP_MSG", // 3. 응답메시지(60)
				"MSG_ID", // 4. 전문ID(8)
				"TRAN_TYPE", // 5. 거래TYPE(2)

				"SALE_DATE", // 6. 영업일자(8)
				"SALE_TIME", // 7. 영업시간(6)
				"BUY_FIRM_CODE", // 8. 매입사코드(4)
				"BUY_FIRM_NM", // 9. 매입사명(30)
				"ISSUE_FIRM_CODE", // 10. 발행사코드(4)

				"ISSUE_FIRM_NM", // 11. 발행사명(30)
				"EMP_ID_YN", // 12. 사원증유무(1)
				"EMP_ID_NO", // 13. 사원증번호(32)
				"S_POINT_YN", // 14. 신세계포인트여부(1)
				"S_POINT_CARD_NO", // 15. 신세계포인트카드번호(64)

				"M_GIFT_CARD_YN", // 16. 모바일상품권여부(1)
				"M_GIFT_CARD_NO", // 17. 모바일상품권번호(64)
				"M_GIFT_CONFIRM_NO", // 18. 모바일상품권인증번호(32)
				"M_GIFT_CARD_AMT", // 19. 모바일상품권잔액(12)
				"CARD_YN", // 20. 신용카드여부(1)

				"CARD_CNT", // 21. 응답카드수량(1)
				"CARD_CERT_FLAG_1", // 22. 신용카드인증구분(2)
				"CARD_NO_1", // 23. 신용카드번호(64)
				"CARD_DATE_NO_1", // 24. 신용카드유효기간(32)
				"CARD_CERTIFY_NO_1", // 25. 인증번호(96)

				"CARD_TRACK2DATA_1", // 26. 가상TRACK2DATA(96)
				"CARD_ETC_DATA_1", // 27. 카드사 예비필드(128)
				"CARD_RECEIPT_A_1", // 28. 영수증 출력 A(32)
				"CARD_RECEIPT_D_1", // 29. 영수증 출력 D(32)
				"CASH_RECEIPT_YN", // 30. 현금영수증식별여부(1)

				"CASH_RECEIPT_INFO", // 31. 현금영수증식별정보(32)
				"EVENT_YN", // 32. 이벤트참여식별여부(1)
				"BANK_CODE", // 33. 은행코드(3) -- 계좌 결제 수단 추가 2016.07.14 by OHT
				"BANK_NM", // 34. 은행사명(30) -- 계좌 결제 수단 추가 2016.07.14 by OHT
				"BANK_VAN_FLAG", // 35. 금융VAN구분(4) -- 계좌 결제 수단 추가 2016.07.14 by OHT

				"PLATFORM_M_ID", // 36. 플랫폼연동가맹점ID(20) -- 계좌 결제 수단 추가 2016.07.14 by OHT
				"BANK_YN", // 37. 가상은행계좌 여부(1) -- 계좌 결제 수단 추가 2016.07.14 by OHT
				"BANK_ACCOUNT_NO", // 38. 가상은행계좌번호(96) -- 계좌 결제 수단 추가 2016.07.14 by OHT
				"BANK_RECEIPT", // 39. 은행계좌 영수증 출력(15) -- 계좌 결제 수단 추가 2016.07.14 by OHT
				"CARD_BIN", // 40. 실 카드빈(6) -- SSGPAY 상시할인/PLCC 추가 20170613 KSN

				"SSGPAY_DC_YN", // 41. SSGPAY 상시 할인 여부(1) -- SSGPAY 상시할인/PLCC 추가 20170613 KSN
				"SSGPAY_CP_YN", // 42. SSGPAY 쿠폰 존재 여부(1) -- SSGPAY 상시할인/PLCC 추가 20170613 KSN
				"SSGPAY_CP_FLAG", // 43. SSGPAY 쿠폰 구분자(1) -- SSGPAY 상시할인/PLCC 추가 20170613 KSN
				"SSGPAY_CP_APPLY", // 44. SSGPAY 쿠폰 적용 액(8) -- SSGPAY 상시할인/PLCC 추가 20170613 KSN
				"SSGPAY_CP_MAX_AMT" // 45. SSGPAY 쿠폰 최대 금액(8) -- SSGPAY 상시할인/PLCC 추가 20170613 KSN
		};

		for (int i = 0; i < nlens.length; i++) {
			// df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String)
			// hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGPayApprovalRsp(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 8, 6, 20 };
		String strHeaders[] = { "INQ_TYPE", // 1. INQ종별(2)
				"CARD_AUTH_DATE", // 2. 승인일자(8)
				"CARD_AUTH_TIME", // 3. 승인시간(6)
				"CARD_AUTH_NO" // 4. 승인번호(20)
		};

		for (int i = 0; i < nlens.length; i++) {
			// df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String)
			// hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	public String getSSGPayMGiftCharge(HashMap<String, String> hmComm, HashMap<String, String> hm, int inq_type)
			throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();

		String sendMsg = ""; // 신세계로 보낼 송신 전문
		String recvBuf = ""; // 신세계에서 받을 응답 전문
		String dataMsg = ""; // POS로 보낼 응답 전문
		String ret = "00";

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String todayDT = sdf.format(calendar.getTime());

		String msg_Id = "";
		String tran_Type = "";
		String trade_Type = "";
		String trade_Amt = "";
		switch (inq_type) {
		case 75:
			msg_Id = "CGIS0200";
			tran_Type = "00";
			trade_Type = "27";
			trade_Amt = hm.get("TRADE_AMT");
			break;
		case 76:
			msg_Id = "CGIS0200";
			tran_Type = "02";
			trade_Type = "67";
			trade_Amt = hm.get("TRADE_AMT");
			break;
		case 77:
			msg_Id = "CGIF0100";
			tran_Type = "05";
			trade_Type = "47";
			trade_Amt = " ";
			break;
		case 78:
			msg_Id = "CGIM0200";
			tran_Type = "00";
			trade_Type = "27";
			trade_Amt = hm.get("TRADE_AMT");
			break;
		}

		try {
			actSock = new ActionSocket(this.svrSock, (Filter) (new COMMConveyerFilter(COMMBiz.SSGPAY_FILTER)));

			/*
			 * 통합결제플랫폼 모바일상품권 충전전문 HEADER 구성
			 */
			hm.put("MSG_LEN", "0900"); // 01. 전문길이(4)
			hm.put("MSG_ID", msg_Id); // 02. 전문ID(8)
			hm.put("MCH_SEND_DATE", todayDT.substring(0, 8)); // 03. 전문전송일자(8)
			hm.put("MCHH_SEND_UNIQ_NO", hmComm.get("TRAN_YMD") + hmComm.get("POS_NO") + "0000" + hmComm.get("TRAN_NO")); // 04.
																															// 전송거래고유번호(20)
			hm.put("GIFT_MCH_NO", SSGPAY_GIFTFCSTR_ID); // 05. 가맹점번호(15)
			hm.put("MSG_GUBUN", "SEND"); // 06. 요청구분(4)
			hm.put("SER_COM_CD", SSGPAY_COM_CD); // 07. 회사코드(4)
			hm.put("SALE_DATE", hmComm.get("TRAN_YMD")); // 08. 영업일자(8)
			hm.put("SALE_TIME", hmComm.get("SYS_HMS")); // 09. 영업시간(6)
			hm.put("ST_CODE", hmComm.get("STORE_CD")); // 10. 점코드(10)
			hm.put("TM_NO", hmComm.get("POS_NO")); // 11. 포스번호(4)
			hm.put("CD_NO", "0000"); // 12. CD번호(4)
			hm.put("TRAN_NO", hmComm.get("TRAN_NO")); // 13. TRAN_NO(4)
														// 14. Casher번호(10)
			hm.put("POS_DATE", hmComm.get("SYS_YMD")); // 15. POS시스템일자(8)
			hm.put("POS_TIME", hmComm.get("SYS_HMS")); // 16. POS시스템시간(6)
			hm.put("SER_COM_UNIQ_NO", " "); // 17. 회사별요청자정보(20)
			hm.put("JUMPO_SYS_DATE", todayDT.substring(0, 8)); // 18. 점포서버 전문전송일자(8)
			hm.put("JUMPO_SYS_TIME", todayDT.substring(8, 14)); // 19. 점포서버 전문전송시간(6)
			hm.put("HEAD_ETC_FIELD", " "); // 20. 헤더예비필드(53)
			/*
			 * 통합결제플랫폼 모바일상품권 회수요청전문 DATA 구성
			 */
			hm.put("TRAN_TYPE", tran_Type); // 21. 거래TYPE(2) //00:승인(75,78), 01:오타, 02:반품(76), 05:조회(77)
			hm.put("TRADE_TYPE", trade_Type); // 22. 요청TYPE(2) //27:충전(75,78), 67:충전취소(76), 47:잔액조회(77)
			hm.put("EVENT_ETC_FIELD", " "); // 23. 행사 예비필드(24)
			hm.put("TRACK_TYPE", "3"); // 24. TRACK2 유무(1)
			hm.put("BARCODE_ETC_FIELD", " "); // 25. 바코드 예비필드(100)
			hm.put("BARCODE_CNT", "001"); // 26. 판매수량(3)
											// 27. CINO(100)
											// 28. OTP번호(50)
											// 29. KEY_IN 유무(2)
			hm.put("TRADE_AMT", trade_Amt); // 30. 요청금액(12)
											// 31. 거래별 구분코드(1)
											// 32. 사용구분(1)
			hm.put("GIFT_GUBUN", "3"); // 33. 상품종류구분(1)
			hm.put("PART_GUBUN", "60"); // 34. 제휴사구분코드(2)
										// 35. 권종코드(4)
			hm.put("GIFT_MOMILE_NO", " "); // 36. 선물하기번호(20)
											// 37. 원거래 회사코드(4)
											// 38. 원거래 영업일자(8)
											// 39. 원거래 점코드(10)
											// 40. 원거래 포스번호(4)
											// 41. 원거래 거래번호(4)
											// 42. 원거래 CD번호(4)
											// 43. 원거래 전문전송일자(8)
											// 44. 원거래전송거래고유번호(20)
			hm.put("ORG_GIFT_MCH_NO", hm.get("INQ_TYPE").equals("76") ? SSGPAY_GIFTFCSTR_ID : " "); // 45. 원거래가맹점번호(15)
			// 46. 원거래 승인일자(8)
			// 47. 원거래 승인번호(8)
			hm.put("AUTH_DATE", " "); // 48. 승인일자(8)
			hm.put("AUTH_TIME", " "); // 49. 승인시간(6)
			hm.put("AUTH_NO", " "); // 50. 승인번호(8)
			hm.put("REMAIN_AMT", " "); // 51. 상품권잔액금액(12)
			hm.put("MD_CODE", " "); // 52. 회사별물품코드(30)
			hm.put("RESP_CODE", " "); // 53. 응답코드(4)
			hm.put("RESP_MSG", " "); // 54. 응답메시지(60)
			hm.put("REFUND_ABLE_AMT", " "); // 55. 환불가능금액(12)
											// 56. MY바코드 번호(48)
			hm.put("AMT_ETC_FIELD", " "); // 57. 금액관련 예비필드(60)
											// 58. 결제수단(2)
			hm.put("DATA_ETC_FIELD", " "); // 59. DATA예비필드(21)
			hm.put("MSG_END", " "); // 60. 전문종료내역(1)

			sendMsg = makeSendDataSSGPayMGiftCharge(hm, df);

			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();

			// 전문종료내역 설정
			sendBytes[899] = (byte) 0x0d;

			df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");

			if (actSock.send(sendBytes, sendBytes.length)) {
				df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "] OK");
			} else {
				df.CommLogger("[sms>ssgpay] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSGPay Server is no response");
			}

			recvBuf = ((String) actSock.receive());
			df.CommLogger("[sms<ssgpay] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");

			hmRecv = protocol.getParseSSGPayMGiftRspCharge(recvBuf);

			hmRecv.put("INQ_TYPE", (String) hm.get("INQ_TYPE"));
		} catch (Exception e) {
			ret = "29";
			throw e;
		} finally {
			actSock.close();
			dataMsg = ret + makeSendDataSSGPayMGiftChargeRsp(hmRecv, df);
		}

		return dataMsg;
	}

	private String makeSendDataSSGPayMGiftChargeRsp(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 60, 50, 12, 12, 8, 8, 6, 8 };
		String strHeaders[] = { "INQ_TYPE", "RESP_CODE", "RESP_MSG", "GIFT_CONFIRM_NO", "REFUND_ABLE_AMT",

				"REMAIN_AMT", "MCH_SEND_DATE", "AUTH_DATE", "AUTH_TIME", "AUTH_NO" };

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGPayCoupon(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 4, 8, 8, 20, 15, 4, 4, 8, 6, 10, 4, 4, 4, 10, 8, 6, 20, 8, 6, 53, 2, 2, 1, 100, 100, 50, 2, 12,
				1, 1, 1, 2, 20, 4, 8, 10, 4, 4, 4, 8, 20, 15, 8, 8, 8, 6, 8, 12, 30, 4, 60, 174, 1 };
		String strHeaders[] = {
				/* 통합결제플랫폼조회전문 HEADER 구성 */
				"MSG_LEN", // 01.전문길이(4) : 0900
				"MSG_ID", // 02.전문 ID(8) : 승인/취소-CPAU0200, 망취소-CPIM0300
				"MCH_SEND_DATE", // 03.전문전송일자(8)
				"MCH_SEND_UNIQ_NO", // 04.전송 거래고유번호(20) : 영업일자(8)+포스번호(4)+CD번호(4)+거래번호(4)
				"MCH_NO", // 05.가맹점번호(15) : IC00000000

				"MSG_GUBUN", // 06.요청구분(4) : SEND
				"SER_COM_CD", // 07.회사코드(4) : 5700
				"SALE_DATE", // 08.영업일자(8)
				"SALE_TIME", // 09.영업시간(6)
				"ST_CODE", // 10.점코드(10)

				"TM_NO", // 11.포스번호(4)
				"CD_NO", // 12.CD번호(4)
				"TRAN_NO", // 13.거래번호(4)
				"CASHER_NO", // 14.Casher번호(10)
				"POS_DATE", // 15.POS시스템일자(8)

				"POS_TIME", // 16.POS시스템시간(6)
				"SER_COM_UNIQ_NO", // 17.회사별 요청자 정보(20) : SPACE로 체움
				"JUMPO_SYS_DATE", // 18.점포서버 전문전송일자(8)
				"JUMPO_SYS_TIME", // 19.점포서버 전문전송시간(6)
				"HEAD_ETC_FIELD", // 20.헤더예비필드(53) : SPACE로 체움

				/* 통합결제플랫폼조회전문 DETAIL 구성 */
				"TRAN_TYPE", // 21.거래 TYPE(2) : 승인-00, 취소-01, 망취소-03
				"TRADE_TYPE", // 22.요청 TYPE(2) : 회수-25, 취소-65
				"TRACK_TYPE", // 23.Track2 유무(1) : 개별-3
				"END_BARCODE", // 24.종료바코드(100) : SPACE로 체움
				"GIFT_CARD_NO", // 25.쿠폰 번호(100)

				"CONFIRM_NO", // 26.PIN 번호(50) : SPACE로 체움
				"KEY_IN_TYPE", // 27.KEY IN 유무(2) : 바코드-05, WEB-06, SWIP-00, KEYIN-01, RF-02, IR-03
				"TRADE_AMT", // 28.요청금액(12)
				"SPECIAL_GUBUN", // 29.거래별 구분 코드(1) : 일반-1
				"USE_GUBUN", // 30.사용구분(1) : 승인-1, 그외-NULL

				"GOODS_GUBUN", // 31.상품종류구분(1) : 쿠폰-5
				"PART_GUBUN", // 32.제휴사구분코드(2) : 자사상품-60
				"MOBILE_NO", // 33.선물하기 번호(20) : SPACE로 체움
				"ORG_SER_COM_CD", // 34.원거래 회사코드(4) : 취소-승인정보, 승인-SPACE
				"ORG_SALE_DATE", // 35.원거래 영업일자(8) : 취소-승인정보, 승인-SPACE

				"ORG_ST_CODE", // 36.원거래 점코드(10) : 취소-승인정보, 승인-SPACE
				"ORG_TM_NO", // 37.원거래 포스번호(4) : 취소-승인정보, 승인-SPACE
				"ORG_TRAN_NO", // 38.원거래 거래 번호(4) : 취소-승인정보, 승인-SPACE
				"ORG_CD_NO", // 39.원거래 CD 번호(4) : 취소-승인정보, 승인-SPACE
				"ORG_SEND_DATE", // 40.원거래 전문전송일자(8) : 취소-승인정보, 승인-SPACE

				"ORG_SEND_UNIQ_NO", // 41.원거래 전송 거래고유번호(20) : 취소-승인정보, 승인-SPACE
				"ORG_MCH_NO", // 42.원거래 가맹점번호(15) : 취소-승인정보, 승인-SPACE
				"ORG_AUTH_DATE", // 43.원거래 승인일자(8) : 취소-승인정보, 승인-SPACE
				"ORG_AUTH_NO", // 44.원거래 승인번호(8) : 취소-승인정보, 승인-SPACE
				"AUTH_DATE", // 45.승인일자(8) : SPACE로 체움

				"AUTH_TIME", // 46.승인시간(6) : SPACE로 체움
				"AUTH_NO", // 47.승인번호(8) : SPACE로 체움
				"REMAIN_AMT", // 48.잔액(12) : SPACE로 체움
				"MD_CODE", // 49.상품 코드(30) : SPACE로 체움
				"RESP_CODE", // 50.응답 코드(4) : SPACE로 체움

				"RESP_MSG", // 51.응답메시지(60) : SPACE로 체움
				"DATA_ETC_FIELD", // 52.DATA예비필드(174) : SPACE로 체움
				"MSG_END" // 53.전문 종료 내역(1) : SPACE로 체움
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGPayCouponRsp(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 8, 6, 8, 12, 30, 60 };

		String strHeaders[] = { "INQ_TYPE", // 01.ING종별(2)
				"RESP_CODE", // 02.응답 코드(4)
				"AUTH_DATE", // 03.승인일자(8)
				"AUTH_TIME", // 04.승인시간(6)
				"AUTH_NO", // 05.승인번호(8)

				"REMAIN_AMT", // 06.잔액(12)
				"MD_CODE", // 07.상품 코드(30)
				"RESP_MSG" // 08.응답메시지(60)
		};

		for (int i = 0; i < nlens.length; i++) {
			// df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String)
			// hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	public String getSSGConInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmInq = new HashMap<String, String>();
		HashMap<String, String> hmRecvHD = new HashMap<String, String>();
		HashMap<String, String> hmRecvDTL = new HashMap<String, String>();
		HashMap<String, String> hmRecvTL = new HashMap<String, String>();
		HashMap<String, String> hmRsp = new HashMap<String, String>();

		String sendMsg = ""; // SSG CON으로 보낼 송신 전문
		String recvBuf = ""; // SSG CON에서 받을 응답 전문
		String dataField = ""; // SSG dataField
		String dataMsg = ""; // POS로 보낼 응답 전문
		String ret = "00";

		int grpBytes = 400;

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");

		String msgSendDt = sdf.format(calendar.getTime()).substring(0, 8);
		String msgSendTm = sdf.format(calendar.getTime()).substring(8, 14);
		String traceTmStamp = sdf.format(calendar.getTime()).substring(8, 17);

		String tranNo = String.format("%05d", Integer.parseInt(hmComm.get("TRAN_NO")));
		String msgTraceNo = (String) hmComm.get("TRAN_YMD") + (String) hmComm.get("POS_NO") + traceTmStamp + tranNo;

		logger.info("SSGCON::msgSendDt[" + msgSendDt + "]::msgSendTm::[" + msgSendTm + "]::msgTraceNo::[" + msgTraceNo
				+ "]");
		System.out.println("SSGCON::msgSendDt[" + msgSendDt + "]::msgSendTm::[" + msgSendTm + "]::msgTraceNo::["
				+ msgTraceNo + "]");
		try {
			actSock = new ActionSocket(this.svrSock, (Filter) (new COMMConveyerFilter(COMMBiz.SSGCON_FILTER)));

			hmInq.put("MSG_LEN", "00500"); // (5)전문 총길이
			hmInq.put("MSG_ID", "PCIF0100"); // (8)전문구분
			hmInq.put("MSG_SEND_DT", msgSendDt); // (8)전문전송일자
			hmInq.put("MSG_SEND_TM", msgSendTm); // (6)전문전송시간
			hmInq.put("MSG_TRACE_NO", msgTraceNo); // (26)전문전송거래추적번호 : 영업일자(8)+포스번호(4자리)+매장번호(5)+CD번호(4자리)+거래번호(5자리)

			hmInq.put("MSG_DATA_LEN", "00200"); // (5)전문본문길이
			hmInq.put("PTR_ID", SSGCON_GNRFCSTR_ID); // (15)제휴사아이디
			hmInq.put("PTR_MCH_ID", ""); // (15)가맹점아이디
			hmInq.put("SER_COM_CD", "5700"); // (4)회사코드
			hmInq.put("ST_CODE", (String) hmComm.get("STORE_CD")); // (10)점코드

			hmInq.put("TM_NO", (String) hmComm.get("POS_NO")); // (4)포스번호
			hmInq.put("SHOP_NO", "00000"); // (5)매장번호
			hmInq.put("CD_NO", "0000"); // (4)CD번호
			hmInq.put("TRAN_NO", tranNo); // (5)거래번호
			hmInq.put("CASHER_NO", (String) hm.get("USER_ID")); // (10)캐셔번호

			hmInq.put("TRAN_TYPE", "05"); // (2)거래구분
			hmInq.put("SALE_DATE", (String) hm.get("SALE_DATE")); // (8)거래일자
			hmInq.put("SALE_TIME", (String) hm.get("SALE_TIME")); // (6)거래시간
			hmInq.put("SER_COM_REQ_NO", ""); // (40)회사별부가요청정보
			hmInq.put("CRYPTO_GUBUN", "0"); // (1)보안설정구분

			hmInq.put("RESP_CODE", ""); // (4)응답코드
			hmInq.put("RESP_MSG", ""); // (64)응답메시지
			hmInq.put("HEADER_FILLER", ""); // (45)헤더필러
			hmInq.put("KEY_IN_TYPE", (String) hm.get("KEY_IN_TYPE")); // (2)수 입력타입
			hmInq.put("TRADE_TYPE", "47"); // (2)거래 요청타입

			hmInq.put("USE_FUNC_GUBUN", "1"); // (1)사용가능구분
			hmInq.put("USE_GUBUN", "1"); // (1)사용구분
			hmInq.put("DELEGATE_BARCODE_NO", (String) hm.get("BARCODE_NO")); // (64)통합바코드번호(암호화)
			hmInq.put("CPN_NO", (String) hm.get("COUPON_NO")); // (64)쿠폰번호
			hmInq.put("DATA_FILLER", ""); // (65)데이터필러

			hmInq.put("MSG_END", ""); // (1)전문종료내역

			logger.info("hmInq[" + hmInq + "]");

			sendMsg = makeSendDataSSGConCheck(hmInq, df);
			logger.info("SSGCON::sendMsg::[" + sendMsg + "]");
			System.out.println("SSGCON::sendMsg::[" + sendMsg + "]");

			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();

			// 전문종료내역 설정
			sendBytes[499] = (byte) 0x0d;

			logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");

			if (actSock.send(sendBytes, sendBytes.length)) {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] OK");
			} else {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSGPay Server is no response");
			}

			recvBuf = ((String) actSock.receive());
			logger.info("[sms<ssgcon] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");
			// 헤더, 데이터 구분

			hmRecvHD = protocol.getParseSSGConRspHDR(recvBuf); // 300byte + 94byte = 394
			logger.info("[INFO] hmRecvHD::[" + hmRecvHD + "]");

			int grpCnt = Integer.parseInt((String) hmRecvHD.get("GRP_ARRAY_CNT"));

			char type1 = '+';
			String cpnGrpData = COMMBiz.subStringMultibyte(recvBuf, 394, (recvBuf.getBytes().length - 106), type1);
			logger.info("[INFO] cpnGrpData::[" + cpnGrpData.getBytes().length + "]::cpnGrpData::[" + cpnGrpData + "]");

			if (grpCnt > 0) {
				dataField = "";
				for (int i = 0; i < grpCnt; i++) {
					// grpBytes
					String grpData = COMMBiz.subStringMultibyte(cpnGrpData, i * grpBytes, (i + 1) * grpBytes, type1);
					logger.info("[INFO] grpDataSize::[" + grpData.getBytes().length + "]::grpData::[" + grpData + "]");

					hmRecvDTL = protocol.getParseSSGConCheckRspGRP(grpData);
					logger.info("[INFO] hmRecvDTL::[" + hmRecvDTL + "]");

					hmRsp.put("INQ_TYPE", "D1"); // (2)INQ종별 (D1)
					hmRsp.put("RESP_CODE", (String) hmRecvHD.get("RESP_CODE")); // (4)응답코드
					hmRsp.put("RESP_MSG", (String) hmRecvHD.get("RESP_MSG")); // (64)응답메시지
					hmRsp.put("SEL_AUTH_NO", (String) hmRecvHD.get("SEL_AUTH_NO")); // (20)조회인증번호
					hmRsp.put("COUPON_NO", (String) hmRecvDTL.get("CPN_NO")); // (64)쿠폰번호(암호화)

					hmRsp.put("REMAIN_AMT", (String) hmRecvDTL.get("REMAIN_AMT")); // (12)남은금액
					hmRsp.put("EXPIRY_ST", (String) hmRecvDTL.get("EXPIRY_STARTDATE")); // (8)유효기간 시작일
					hmRsp.put("EXPIRY_ET", (String) hmRecvDTL.get("EXPIRY_ENDDATE")); // (8)유효기간 종료일
					hmRsp.put("CLASS_GUBUN", (String) hmRecvDTL.get("CLASS_GUBUN")); // (3)분류구분 //GEN:일반, SEL:선택1,
																						// ALL:상품제한없음, ADD:추가할인
					hmRsp.put("PRD_TYPE", (String) hmRecvDTL.get("PRD_TYPE")); // (4)상품타입 //13:금액차감, 14:금액소멸

					hmRsp.put("PRD_ID", (String) hmRecvDTL.get("PRD_ID")); // (20)상품아이디
					hmRsp.put("PRD_NM", (String) hmRecvDTL.get("PRD_NM")); // (64)상품명
					hmRsp.put("PRD_AMT", (String) hmRecvDTL.get("PRD_AMT")); // (12)상품액면가

					logger.info("hmRsp" + hmRsp + "]");

					dataField = dataField + makeSendDataSSGConInqRsp(hmRsp, df);
				}
			} else {
				dataField = "";
				logger.info("[INFO] usable coupon is not exists.");

				hmRsp.put("INQ_TYPE", "D1"); // (2)INQ종별 (D1)
				hmRsp.put("RESP_CODE", (String) hmRecvHD.get("RESP_CODE")); // (4)응답코드
				hmRsp.put("RESP_MSG", (String) hmRecvHD.get("RESP_MSG")); // (64)응답메시지
				hmRsp.put("SEL_AUTH_NO", (String) hmRecvHD.get("SEL_AUTH_NO")); // (20)조회인증번호
				hmRsp.put("COUPON_NO", ""); // (64)쿠폰번호(암호화)

				hmRsp.put("REMAIN_AMT", ""); // (12)남은금액
				hmRsp.put("EXPIRY_ST", ""); // (8)유효기간 시작일
				hmRsp.put("EXPIRY_ET", ""); // (8)유효기간 종료일
				hmRsp.put("CLASS_GUBUN", ""); // (3)분류구분 //GEN:일반, SEL:선택1, ALL:상품제한없음, ADD:추가할인
				hmRsp.put("PRD_TYPE", ""); // (4)상품타입 //13:금액차감, 14:금액소멸

				hmRsp.put("PRD_ID", ""); // (20)상품아이디
				hmRsp.put("PRD_NM", ""); // (64)상품명
				hmRsp.put("PRD_AMT", ""); // (12)상품액면가

				logger.info("hmRsp" + hmRsp + "]");

				dataField = makeSendDataSSGConInqRsp(hmRsp, df);
			}

		} catch (Exception e) {
//			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		} finally {
			actSock.close();
			dataMsg = ret + dataField;
			logger.info("dataMsg" + dataMsg + "]");
//			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		return dataMsg;
	}

	private String makeSendDataSSGConCheck(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 5, 8, 8, 6, 26, 5, 15, 15, 4, 10, 4, 5, 4, 5, 10, 2, 8, 6, 40, 1, 4, 64, 45, 2, 2, 1, 1, 64, 64,
				65, 1 };
		String strHeaders[] = { "MSG_LEN", // (5)전문 총길이
				"MSG_ID", // (8)전문 번호
				"MSG_SEND_DT", // (8)전문 전송일자
				"MSG_SEND_TM", // (6)전문 전송시간
				"MSG_TRACE_NO", // (26)전문 전송거래추적번호

				"MSG_DATA_LEN", // (5)전문본문길이
				"PTR_ID", // (15)제휴사아이디
				"PTR_MCH_ID", // (15)가맹점아이디
				"SER_COM_CD", // (4)회사코드
				"ST_CODE", // (10)점코드

				"TM_NO", // (4)포스번호
				"SHOP_NO", // (5)매장번호
				"CD_NO", // (4)CD번호
				"TRAN_NO", // (5)거래번호
				"CASHER_NO", // (10)캐셔번호

				"TRAN_TYPE", // (2)거래구분
				"SALE_DATE", // (8)거래일자
				"SALE_TIME", // (6)거래시간
				"SER_COM_REQ_NO", // (40)회사별부가요청정보
				"CRYPTO_GUBUN", // (1)보안설정구분

				"RESP_CODE", // (4)응답코드
				"RESP_MSG", // (64)응답메시지
				"HEADER_FILLER", // (45)헤더필러
				"KEY_IN_TYPE", // (2)수 입력타입
				"TRADE_TYPE", // (2)거래 요청타입

				"USE_FUNC_GUBUN", // (1)사용가능구분
				"USE_GUBUN", // (1)사용구분
				"DELEGATE_BARCODE_NO", // (64)통합바코드번호(암호화)
				"CPN_NO", // (64)쿠폰번호
				"DATA_FILLER", // (65)데이터필러

				"MSG_END" // (1)전문종료내역
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			logger.info("★ make send strHeaders : [" + strHeaders[i] + "]" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGConInqRsp(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 64, 20, 64, 12, 8, 8, 3, 4, 20, 64, 12 };
		String strHeaders[] = { "INQ_TYPE", // (2)INQ 종별
				"RESP_CODE", // (4)응답코드
				"RESP_MSG", // (64)응답메시지
				"SEL_AUTH_NO", // (20)조회 인증번호
				"COUPON_NO", // (64)쿠폰번호 암호화

				"REMAIN_AMT", // (12)잔액
				"EXPIRY_ST", // (8)유효기간 시작일
				"EXPIRY_ET", // (8)유효기간 종료일
				"CLASS_GUBUN", // (3)분류 구분
				"PRD_TYPE", // (2)상품타입

				"PRD_ID", // (20)상품아이디
				"PRD_NM", // (64)상품명
				"PRD_AMT" // (12)상품액면가
		};

		for (int i = 0; i < nlens.length; i++) {
			logger.info("★ make send strHeaders : [" + strHeaders[i] + "]" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	// 20171205 KSN SSG CON 금액형(잔액관리형/소멸형)쿠폰 승인/취소요청
	public String getSSGConMNAppr(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmInq = new HashMap<String, String>();
		HashMap<String, String> hmRecvHD = new HashMap<String, String>();
		HashMap<String, String> hmRecvDTL = new HashMap<String, String>();
		HashMap<String, String> hmRecvTL = new HashMap<String, String>();
		HashMap<String, String> hmRsp = new HashMap<String, String>();

		String sendMsg = ""; // SSG CON으로 보낼 송신 전문
		String recvBuf = ""; // SSG CON에서 받을 응답 전문
		String dataField = ""; // SSG dataField
		String dataMsg = ""; // POS로 보낼 응답 전문
		String ret = "00";

		String tranType = "00";
		String useFuncGb = "1";
		String keyInType = "05";
		String selAuthNo = "";
		String tradeType = "25";

		int grpBytes = 396;

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");

		String msgSendDt = sdf.format(calendar.getTime()).substring(0, 8);
		String msgSendTm = sdf.format(calendar.getTime()).substring(8, 14);
		String traceTmStamp = sdf.format(calendar.getTime()).substring(8, 17);

		String tranNo = String.format("%05d", Integer.parseInt(hmComm.get("TRAN_NO")));
		String msgTraceNo = (String) hmComm.get("TRAN_YMD") + (String) hmComm.get("POS_NO") + traceTmStamp + tranNo;

		if ("0".equals((String) hm.get("TYPE"))) {
			tranType = "00";
			selAuthNo = (String) hm.get("SEL_AUTH_NO");
		} else if ("1".equals((String) hm.get("TYPE"))) {
			tranType = "02";
			useFuncGb = "1";
			selAuthNo = "";
			tradeType = "65";
		} else {
			tranType = "";
		}

		if (!"".equals((String) hm.get("KEY_IN_TYPE").trim()) && (String) hm.get("KEY_IN_TYPE").trim() != null) {
			keyInType = (String) hm.get("KEY_IN_TYPE");
		}

		logger.info("SSGCON::keyInType::[" + keyInType + "]::msgSendDt[" + msgSendDt + "]::msgSendTm::[" + msgSendTm
				+ "]::msgTraceNo::[" + msgTraceNo + "]");
		System.out.println("SSGCON::msgSendDt[" + msgSendDt + "]::msgSendTm::[" + msgSendTm + "]::msgTraceNo::["
				+ msgTraceNo + "]");
		try {
			actSock = new ActionSocket(this.svrSock, (Filter) (new COMMConveyerFilter(COMMBiz.SSGCON_FILTER)));

			hmInq.put("MSG_LEN", "01000"); // (5)전문 총길이
			hmInq.put("MSG_ID", "PCIU0200"); // (8)전문구분
			hmInq.put("MSG_SEND_DT", msgSendDt); // (8)전문전송일자
			hmInq.put("MSG_SEND_TM", msgSendTm); // (6)전문전송시간
			hmInq.put("MSG_TRACE_NO", msgTraceNo); // (26)전문전송거래추적번호 : 영업일자(8)+포스번호(4자리)+매장번호(5)+CD번호(4자리)+거래번호(5자리)

			hmInq.put("MSG_DATA_LEN", "00700"); // (5)전문본문길이
			hmInq.put("PTR_ID", SSGCON_GNRFCSTR_ID); // (15)제휴사아이디
			hmInq.put("PTR_MCH_ID", ""); // (15)가맹점아이디
			hmInq.put("SER_COM_CD", "5700"); // (4)회사코드
			hmInq.put("ST_CODE", (String) hmComm.get("STORE_CD")); // (10)점코드

			hmInq.put("TM_NO", (String) hmComm.get("POS_NO")); // (4)포스번호
			hmInq.put("SHOP_NO", "00000"); // (5)매장번호
			hmInq.put("CD_NO", "0000"); // (4)CD번호
			hmInq.put("TRAN_NO", tranNo); // (5)거래번호
			hmInq.put("CASHER_NO", (String) hm.get("USER_ID")); // (10)캐셔번호

			hmInq.put("TRAN_TYPE", tranType); // (2)거래구분
			hmInq.put("SALE_DATE", (String) hm.get("SALE_DATE")); // (8)거래일자
			hmInq.put("SALE_TIME", (String) hm.get("SALE_TIME")); // (6)거래시간
			hmInq.put("SER_COM_REQ_NO", ""); // (40)회사별부가요청정보
			hmInq.put("CRYPTO_GUBUN", "0"); // (1)보안설정구분

			hmInq.put("RESP_CODE", ""); // (4)응답코드
			hmInq.put("RESP_MSG", ""); // (64)응답메시지
			hmInq.put("HEADER_FILLER", ""); // (45)헤더필러
			hmInq.put("KEY_IN_TYPE", keyInType); // (2)수 입력타입
			hmInq.put("TRADE_TYPE", tradeType); // (2)거래 요청타입

			hmInq.put("USE_FUNC_GUBUN", useFuncGb); // (1)사용가능구분
			hmInq.put("USE_GUBUN", "1"); // (1)사용구분
			hmInq.put("DELEGATE_BARCODE_NO", (String) hm.get("BARCODE_NO")); // (64)통합바코드번호(암호화)
			hmInq.put("SEL_AUTH_NO", selAuthNo); // (20)조회 인증번호
			hmInq.put("GRP_ARRAY_CNT", "0001"); // (4)그룹 정보 개수

			hmInq.put("GRP_STA", "GSTA"); // (4)그룹 시작문자
			hmInq.put("GRP_TYPE", "10"); // (2)그룹 타입
			hmInq.put("ADD_DC_CODE", ""); // (20)추가할인코드
			hmInq.put("INFO_INDEX", "001"); // (3)상품 정보 순서
			hmInq.put("CLASS_GUBUN", (String) hm.get("CLASS_GUBUN")); // (3)분류구분

			hmInq.put("CPN_NO", (String) hm.get("COUPON_NO")); // (64)쿠폰 번호(암호화)
			hmInq.put("PRD_ID", (String) hm.get("PRD_ID")); // (20)상품 아이디
			hmInq.put("PRD_NM", (String) hm.get("PRD_NM")); // (64)상품 명
			hmInq.put("PRD_SKU_CODE", ""); // (20)상품 바코드
			hmInq.put("PRD_CNT", "0001"); // (4)상품 갯수

			hmInq.put("PRD_AMT", (String) hm.get("PRD_AMT")); // (12)상품원가
			hmInq.put("BRD_CODE", ""); // (10)브랜드코드
			hmInq.put("PRD_TYPE", (String) hm.get("PRD_TYPE")); // (4)상품타입
			hmInq.put("AMT_RATE_GUBUN", ""); // (1)정액/정률 구분
			hmInq.put("TOT_TRADE_AMT", ""); // (12)전체거래금액

			hmInq.put("TRADE_AMT", String.format("%012d", Integer.parseInt(hm.get("USED_AMT").trim()))); // (12)사용금액
			hmInq.put("REMAIN_AMT", String.format("%012d", 0)); // (12)남은금액
			hmInq.put("ARRAY_ETC_FIELD", ""); // (125)ARRAY DATA 예비필드
			hmInq.put("GRP_END", "GFIN"); // (4)그룹 종료
			hmInq.put("AUTH_DATE", ""); // (8)승인일자

			hmInq.put("AUTH_TIME", ""); // (6)승인시간
			hmInq.put("AUTH_NO", ""); // (8)승인번호
			hmInq.put("ORG_MSG_SEND_DT", (String) hm.get("ORG_MSG_SEND_DT")); // (8)원거래 전문 전송일자
			hmInq.put("ORG_MSG_TRACE_NO", (String) hm.get("ORG_TRACE_NO")); // (26)원거래 전문 전송거래추적번호
			hmInq.put("ORG_SALE_DATE", (String) hm.get("ORG_SALE_DATE")); // (8)원거래 거래일자

			hmInq.put("ORG_AUTH_DATE", (String) hm.get("ORG_AUTH_DATE")); // (8)원거래 승인일자
			hmInq.put("ORG_AUTH_NO", (String) hm.get("ORG_AUTH_NO")); // (8)원거래 승인번호
			hmInq.put("DATA_FILLER", ""); // (129)데이터 필러
			hmInq.put("MSG_END", ""); // (1)전문 종료 내역

			logger.info("hmInq[" + hmInq + "]");

			sendMsg = makeSendDataSSGConMNAppr(hmInq, df);
			logger.info("SSGCON::sendMsg::[" + sendMsg + "]");

			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();

			// 전문종료내역 설정
			sendBytes[999] = (byte) 0x0d;
			logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");

			if (actSock.send(sendBytes, sendBytes.length)) {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] OK");
			} else {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSGPay Server is no response");
			}

			try {
				recvBuf = ((String) actSock.receive());
				logger.info("[sms<ssgcon] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");

				// 헤더, 데이터, 테일 구분
				hmRecvHD = protocol.getParseSSGConRspHDR(recvBuf); // 300byte + 94byte = 394
				logger.info("[INFO] hmRecvHD::[" + hmRecvHD + "]");

				int grpCnt = Integer.parseInt((String) hmRecvHD.get("GRP_ARRAY_CNT"));

				char type1 = '+';
				String cpnGrpData = COMMBiz.subStringMultibyte(recvBuf, 394, (recvBuf.getBytes().length - 210), type1); // DATA
																														// 그룹부분
																														// str
				String cpnGrpTail = COMMBiz.subStringMultibyte(recvBuf, (recvBuf.getBytes().length - 210),
						recvBuf.getBytes().length, type1); // TAIL 부분 str

				hmRecvTL = protocol.getParseSSGConApprRspTL(cpnGrpTail);
				logger.info("[INFO] hmRecvTL::[" + hmRecvTL + "]");

				logger.info(
						"[INFO] DataSIZE::[" + cpnGrpData.getBytes().length + "]::cpnGrpData::[" + cpnGrpData + "]");
				logger.info(
						"[INFO] DataSIZE::[" + cpnGrpTail.getBytes().length + "]::cpnGrpTail::[" + cpnGrpTail + "]");
				logger.info("[INFO] grpCnt::[" + grpCnt + "]");

				if (grpCnt > 0) {
					dataField = "";
					for (int i = 0; i < grpCnt; i++) {
						String grpData = COMMBiz.subStringMultibyte(cpnGrpData, i * grpBytes, (i + 1) * grpBytes,
								type1);
						logger.info(
								"[INFO] grpDataSize::[" + grpData.getBytes().length + "]::grpData::[" + grpData + "]");

						hmRecvDTL = protocol.getParseSSGConApprRspGRP(grpData);
						logger.info("[INFO] hmRecvDTL::[" + hmRecvDTL + "]");

						hmRsp.put("INQ_TYPE", "D3"); // (2)INQ종별 (D3)
						hmRsp.put("RESP_CODE", (String) hmRecvHD.get("RESP_CODE")); // (4)응답코드
						hmRsp.put("RESP_MSG", (String) hmRecvHD.get("RESP_MSG")); // (64)응답메시지
						hmRsp.put("TRACE_NO", (String) hmRecvHD.get("MSG_TRACE_NO")); // (26)거래추적번호
						hmRsp.put("TRADE_TYPE", (String) hmRecvHD.get("TRADE_TYPE")); // (2)거래요청타입

						hmRsp.put("SEL_AUTH_NO", (String) hmRecvHD.get("SEL_AUTH_NO")); // (20)조회인증번호
						hmRsp.put("COUPON_NO", (String) hmRecvDTL.get("CPN_NO")); // (64)쿠폰번호
						hmRsp.put("BARCODE_NO", (String) hmRecvHD.get("DELEGATE_BARCODE_NO")); // (64)통합바코드번호
						hmRsp.put("USED_AMT", (String) hmRecvDTL.get("TRADE_AMT")); // (12)사용금액
						hmRsp.put("REMAIN_AMT", (String) hmRecvDTL.get("REMAIN_AMT")); // (12)남은금액

						hmRsp.put("AUTH_DATE", (String) hmRecvTL.get("AUTH_DATE")); // (8)승인일자
						hmRsp.put("AUTH_TIME", (String) hmRecvTL.get("AUTH_TIME")); // (6)승인시간
						hmRsp.put("AUTH_NO", (String) hmRecvTL.get("AUTH_NO")); // (8)승인번호
						hmRsp.put("MSG_SEND_DT", (String) hmRecvHD.get("MSG_SEND_DT")); // (8)전문전송일자
						hmRsp.put("MSG_SEND_TM", (String) hmRecvHD.get("MSG_SEND_TM")); // (6)전문전송시간

						hmRsp.put("PTR_MCH_ID", (String) hmRecvHD.get("PTR_MCH_ID")); // (15)가맹점ID
						hmRsp.put("CASHER_NO", (String) hmRecvHD.get("CASHER_NO")); // (10)사원번호
						hmRsp.put("TRAN_TYPE", (String) hmRecvHD.get("TRAN_TYPE")); // (2)거래구분
						hmRsp.put("KEY_IN_TYPE", (String) hmRecvHD.get("KEY_IN_TYPE")); // (2)수 입력타입
						hmRsp.put("USE_FUNC_GUBUN", (String) hmRecvHD.get("USE_FUNC_GUBUN")); // (1)사용기능구분

						hmRsp.put("USE_GUBUN", (String) hmRecvHD.get("USE_GUBUN")); // (1)사용구분
						hmRsp.put("GRP_TYPE", (String) hmRecvDTL.get("GRP_TYPE")); // (2)그룹타입
						hmRsp.put("TOT_TRADE_AMT", (String) hmRecvDTL.get("TOT_TRADE_AMT")); // (12)전체거래금액
						hmRsp.put("ORG_MSG_SEND_DT", (String) hmRecvTL.get("ORG_MSG_SEND_DT")); // (8)원거래전문전송일자

						logger.info("hmRsp" + hmRsp + "]");

						dataField = dataField + makeSendDataSSGConMNApprRsp(hmRsp, df);
					}
				} else {
					dataField = "";
					logger.info("[INFO] usable coupon is not exists.");

					hmRsp.put("INQ_TYPE", "D3"); // (2)INQ종별 (D3)
					hmRsp.put("RESP_CODE", (String) hmRecvHD.get("RESP_CODE")); // (4)응답코드
					hmRsp.put("RESP_MSG", (String) hmRecvHD.get("RESP_MSG")); // (64)응답메시지
					hmRsp.put("TRACE_NO", (String) hmRecvHD.get("MSG_TRACE_NO")); // (26)거래추적번호
					hmRsp.put("TRADE_TYPE", (String) hmRecvHD.get("TRADE_TYPE")); // (2)거래요청타입

					hmRsp.put("SEL_AUTH_NO", (String) hmRecvHD.get("SEL_AUTH_NO")); // (20)조회인증번호
					hmRsp.put("COUPON_NO", ""); // (64)쿠폰번호
					hmRsp.put("BARCODE_NO", (String) hmRecvHD.get("DELEGATE_BARCODE_NO")); // (64)통합바코드번호
					hmRsp.put("USED_AMT", "000000000000"); // (12)사용금액
					hmRsp.put("REMAIN_AMT", "000000000000"); // (12)남은금액

					hmRsp.put("AUTH_DATE", (String) hmRecvTL.get("AUTH_DATE")); // (8)승인일자
					hmRsp.put("AUTH_TIME", (String) hmRecvTL.get("AUTH_TIME")); // (6)승인시간
					hmRsp.put("AUTH_NO", (String) hmRecvTL.get("AUTH_NO")); // (8)승인번호
					hmRsp.put("MSG_SEND_DT", (String) hmRecvHD.get("MSG_SEND_DT")); // (8)전문전송일자
					hmRsp.put("MSG_SEND_TM", (String) hmRecvHD.get("MSG_SEND_TM")); // (6)전문전송시간

					hmRsp.put("PTR_MCH_ID", (String) hmRecvHD.get("PTR_MCH_ID")); // (15)가맹점ID
					hmRsp.put("CASHER_NO", (String) hmRecvHD.get("CASHER_NO")); // (10)사원번호
					hmRsp.put("TRAN_TYPE", (String) hmRecvHD.get("TRAN_TYPE")); // (2)거래구분
					hmRsp.put("KEY_IN_TYPE", (String) hmRecvHD.get("KEY_IN_TYPE")); // (2)수 입력타입
					hmRsp.put("USE_FUNC_GUBUN", (String) hmRecvHD.get("USE_FUNC_GUBUN")); // (1)사용기능구분

					hmRsp.put("USE_GUBUN", (String) hmRecvHD.get("USE_GUBUN")); // (1)사용구분
					hmRsp.put("GRP_TYPE", ""); // (2)그룹타입
					hmRsp.put("TOT_TRADE_AMT", "000000000000"); // (12)전체거래금액
					hmRsp.put("ORG_MSG_SEND_DT", (String) hmRecvTL.get("ORG_MSG_SEND_DT")); // (8)원거래전문전송일자

					logger.info("hmRsp" + hmRsp + "]");

					dataField = makeSendDataSSGConMNApprRsp(hmRsp, df);
				}
			} catch (Exception e) {
				// 20180110 KSN 응답전문 수신 및 수신 중 오류 발생시 망취소 전문 송신
				getSSGConMNAbnormalCncl(hmComm, hm);
				logger.info("[ERROR] RECV ERR OCCUR::[" + e.getMessage() + "]");
			}
		} catch (Exception e) {
//			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";

			throw e;
		} finally {
			actSock.close();
			dataMsg = ret + dataField;
			logger.info("dataMsg" + dataMsg + "]");
//			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		return dataMsg;
	}

	// 20180109 KSN SSG CON 물품형쿠폰 승인/취소요청
	public String getSSGConPrdAppr(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmInq = new HashMap<String, String>();
		HashMap<String, String> hmRecvHD = new HashMap<String, String>();
		HashMap<String, String> hmRecvDTL = new HashMap<String, String>();
		HashMap<String, String> hmRecvTL = new HashMap<String, String>();
		HashMap<String, String> hmRsp = new HashMap<String, String>();

		String sendMsg = ""; // SSG CON으로 보낼 송신 전문
		String recvBuf = ""; // SSG CON에서 받을 응답 전문
		String dataField = ""; // SSG dataField
		String dataMsg = ""; // POS로 보낼 응답 전문
		String ret = "00";

		String tranType = "00";
		String useFuncGb = "1";
		String keyInType = "05";
		String selAuthNo = "";
		String tradeType = "25";

		int grpBytes = 396;

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");

		String msgSendDt = sdf.format(calendar.getTime()).substring(0, 8);
		String msgSendTm = sdf.format(calendar.getTime()).substring(8, 14);
		String traceTmStamp = sdf.format(calendar.getTime()).substring(8, 17);

		String tranNo = String.format("%05d", Integer.parseInt(hmComm.get("TRAN_NO")));
		String msgTraceNo = (String) hmComm.get("TRAN_YMD") + (String) hmComm.get("POS_NO") + traceTmStamp + tranNo;

		if ("0".equals((String) hm.get("TYPE"))) {
			tranType = "00";
			selAuthNo = (String) hm.get("SEL_AUTH_NO");
		} else if ("1".equals((String) hm.get("TYPE"))) {
			tranType = "02";
			useFuncGb = "1";
			selAuthNo = "";
			tradeType = "65";
		} else {
			tranType = "";
		}

		if (!"".equals((String) hm.get("KEY_IN_TYPE").trim()) && (String) hm.get("KEY_IN_TYPE").trim() != null) {
			keyInType = (String) hm.get("KEY_IN_TYPE");
		}

		logger.info("SSGCON::keyInType::[" + keyInType + "]::msgSendDt[" + msgSendDt + "]::msgSendTm::[" + msgSendTm
				+ "]::msgTraceNo::[" + msgTraceNo + "]");
		System.out.println("SSGCON::msgSendDt[" + msgSendDt + "]::msgSendTm::[" + msgSendTm + "]::msgTraceNo::["
				+ msgTraceNo + "]");
		try {
			actSock = new ActionSocket(this.svrSock, (Filter) (new COMMConveyerFilter(COMMBiz.SSGCON_FILTER)));

			hmInq.put("MSG_LEN", "01000"); // (5)전문 총길이
			hmInq.put("MSG_ID", "PCIU0200"); // (8)전문구분
			hmInq.put("MSG_SEND_DT", msgSendDt); // (8)전문전송일자
			hmInq.put("MSG_SEND_TM", msgSendTm); // (6)전문전송시간
			hmInq.put("MSG_TRACE_NO", msgTraceNo); // (26)전문전송거래추적번호 : 영업일자(8)+포스번호(4자리)+매장번호(5)+CD번호(4자리)+거래번호(5자리)

			hmInq.put("MSG_DATA_LEN", "00700"); // (5)전문본문길이
			hmInq.put("PTR_ID", SSGCON_GNRFCSTR_ID); // (15)제휴사아이디
			hmInq.put("PTR_MCH_ID", ""); // (15)가맹점아이디
			hmInq.put("SER_COM_CD", "5700"); // (4)회사코드
			hmInq.put("ST_CODE", (String) hmComm.get("STORE_CD")); // (10)점코드

			hmInq.put("TM_NO", (String) hmComm.get("POS_NO")); // (4)포스번호
			hmInq.put("SHOP_NO", "00000"); // (5)매장번호
			hmInq.put("CD_NO", "0000"); // (4)CD번호
			hmInq.put("TRAN_NO", tranNo); // (5)거래번호
			hmInq.put("CASHER_NO", (String) hm.get("USER_ID")); // (10)캐셔번호

			hmInq.put("TRAN_TYPE", tranType); // (2)거래구분
			hmInq.put("SALE_DATE", (String) hm.get("SALE_DATE")); // (8)거래일자
			hmInq.put("SALE_TIME", (String) hm.get("SALE_TIME")); // (6)거래시간
			hmInq.put("SER_COM_REQ_NO", ""); // (40)회사별부가요청정보
			hmInq.put("CRYPTO_GUBUN", "0"); // (1)보안설정구분

			hmInq.put("RESP_CODE", ""); // (4)응답코드
			hmInq.put("RESP_MSG", ""); // (64)응답메시지
			hmInq.put("HEADER_FILLER", ""); // (45)헤더필러
			hmInq.put("KEY_IN_TYPE", keyInType); // (2)수 입력타입
			hmInq.put("TRADE_TYPE", tradeType); // (2)거래 요청타입

			hmInq.put("USE_FUNC_GUBUN", useFuncGb); // (1)사용가능구분
			hmInq.put("USE_GUBUN", "1"); // (1)사용구분
			hmInq.put("DELEGATE_BARCODE_NO", (String) hm.get("BARCODE_NO")); // (64)통합바코드번호(암호화)
			hmInq.put("SEL_AUTH_NO", selAuthNo); // (20)조회 인증번호
			hmInq.put("GRP_ARRAY_CNT", "0001"); // (4)그룹 정보 개수

			hmInq.put("GRP_STA", "GSTA"); // (4)그룹 시작문자
			hmInq.put("GRP_TYPE", "10"); // (2)그룹 타입
			hmInq.put("ADD_DC_CODE", ""); // (20)추가할인코드
			hmInq.put("INFO_INDEX", "001"); // (3)상품 정보 순서
			hmInq.put("CLASS_GUBUN", (String) hm.get("CLASS_GUBUN")); // (3)분류구분

			hmInq.put("CPN_NO", (String) hm.get("COUPON_NO")); // (64)쿠폰 번호(암호화)
			hmInq.put("PRD_ID", (String) hm.get("PRD_ID")); // (20)상품 아이디
			hmInq.put("PRD_NM", ""); // (64)상품 명
			hmInq.put("PRD_SKU_CODE", (String) hm.get("PRD_SKU_CODE")); // (20)상품 바코드
			hmInq.put("PRD_CNT", "0001"); // (4)상품 갯수

			hmInq.put("PRD_AMT", String.format("%012d", 0)); // (12)상품원가
			hmInq.put("BRD_CODE", ""); // (10)브랜드코드
			hmInq.put("PRD_TYPE", (String) hm.get("PRD_TYPE")); // (4)상품타입
			hmInq.put("AMT_RATE_GUBUN", ""); // (1)정액/정률 구분
			hmInq.put("TOT_TRADE_AMT", ""); // (12)전체거래금액

			hmInq.put("TRADE_AMT", String.format("%012d", Integer.parseInt(hm.get("USED_AMT").trim()))); // (12)사용금액
			hmInq.put("REMAIN_AMT", String.format("%012d", 0)); // (12)남은금액
			hmInq.put("ARRAY_ETC_FIELD", ""); // (125)ARRAY DATA 예비필드
			hmInq.put("GRP_END", "GFIN"); // (4)그룹 종료
			hmInq.put("AUTH_DATE", ""); // (8)승인일자

			hmInq.put("AUTH_TIME", ""); // (6)승인시간
			hmInq.put("AUTH_NO", ""); // (8)승인번호
			hmInq.put("ORG_MSG_SEND_DT", (String) hm.get("ORG_MSG_SEND_DT")); // (8)원거래 전문 전송일자
			hmInq.put("ORG_MSG_TRACE_NO", (String) hm.get("ORG_TRACE_NO")); // (26)원거래 전문 전송거래추적번호
			hmInq.put("ORG_SALE_DATE", (String) hm.get("ORG_SALE_DATE")); // (8)원거래 거래일자

			hmInq.put("ORG_AUTH_DATE", (String) hm.get("ORG_AUTH_DATE")); // (8)원거래 승인일자
			hmInq.put("ORG_AUTH_NO", (String) hm.get("ORG_AUTH_NO")); // (8)원거래 승인번호
			hmInq.put("DATA_FILLER", ""); // (129)데이터 필러
			hmInq.put("MSG_END", ""); // (1)전문 종료 내역

			logger.info("hmInq[" + hmInq + "]");

			sendMsg = makeSendDataSSGConMNAppr(hmInq, df);
			logger.info("SSGCON::sendMsg::[" + sendMsg + "]");

			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();

			// 전문종료내역 설정
			sendBytes[999] = (byte) 0x0d;
			logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");

			if (actSock.send(sendBytes, sendBytes.length)) {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] OK");
			} else {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSGPay Server is no response");
			}

			try {
				recvBuf = ((String) actSock.receive());
				logger.info("[sms<ssgcon] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");

				// 헤더, 데이터, 테일 구분
				hmRecvHD = protocol.getParseSSGConRspHDR(recvBuf); // 300byte + 94byte = 394
				logger.info("[INFO] hmRecvHD::[" + hmRecvHD + "]");

				int grpCnt = Integer.parseInt((String) hmRecvHD.get("GRP_ARRAY_CNT"));

				char type1 = '+';
				String cpnGrpData = COMMBiz.subStringMultibyte(recvBuf, 394, (recvBuf.getBytes().length - 210), type1); // DATA
																														// 그룹부분
																														// str
				String cpnGrpTail = COMMBiz.subStringMultibyte(recvBuf, (recvBuf.getBytes().length - 210),
						recvBuf.getBytes().length, type1); // TAIL 부분 str

				hmRecvTL = protocol.getParseSSGConApprRspTL(cpnGrpTail);
				logger.info("[INFO] hmRecvTL::[" + hmRecvTL + "]");

				logger.info(
						"[INFO] DataSIZE::[" + cpnGrpData.getBytes().length + "]::cpnGrpData::[" + cpnGrpData + "]");
				logger.info(
						"[INFO] DataSIZE::[" + cpnGrpTail.getBytes().length + "]::cpnGrpTail::[" + cpnGrpTail + "]");
				logger.info("[INFO] grpCnt::[" + grpCnt + "]");

				if (grpCnt > 0) {
					dataField = "";
					for (int i = 0; i < grpCnt; i++) {
						String grpData = COMMBiz.subStringMultibyte(cpnGrpData, i * grpBytes, (i + 1) * grpBytes,
								type1);
						logger.info(
								"[INFO] grpDataSize::[" + grpData.getBytes().length + "]::grpData::[" + grpData + "]");

						hmRecvDTL = protocol.getParseSSGConApprRspGRP(grpData);
						logger.info("[INFO] hmRecvDTL::[" + hmRecvDTL + "]");

						hmRsp.put("INQ_TYPE", "D7"); // (2)INQ종별 (D3)
						hmRsp.put("RESP_CODE", (String) hmRecvHD.get("RESP_CODE")); // (4)응답코드
						hmRsp.put("RESP_MSG", (String) hmRecvHD.get("RESP_MSG")); // (64)응답메시지
						hmRsp.put("TRACE_NO", (String) hmRecvHD.get("MSG_TRACE_NO")); // (26)거래추적번호
						hmRsp.put("TRADE_TYPE", (String) hmRecvHD.get("TRADE_TYPE")); // (2)거래요청타입

						hmRsp.put("SEL_AUTH_NO", (String) hmRecvHD.get("SEL_AUTH_NO")); // (20)조회인증번호
						hmRsp.put("COUPON_NO", (String) hmRecvDTL.get("CPN_NO")); // (64)쿠폰번호
						hmRsp.put("BARCODE_NO", (String) hmRecvHD.get("DELEGATE_BARCODE_NO")); // (64)통합바코드번호
						hmRsp.put("USED_AMT", (String) hmRecvDTL.get("TRADE_AMT")); // (12)사용금액
						hmRsp.put("REMAIN_AMT", (String) hmRecvDTL.get("REMAIN_AMT")); // (12)남은금액

						hmRsp.put("AUTH_DATE", (String) hmRecvTL.get("AUTH_DATE")); // (8)승인일자
						hmRsp.put("AUTH_TIME", (String) hmRecvTL.get("AUTH_TIME")); // (6)승인시간
						hmRsp.put("AUTH_NO", (String) hmRecvTL.get("AUTH_NO")); // (8)승인번호
						hmRsp.put("MSG_SEND_DT", (String) hmRecvHD.get("MSG_SEND_DT")); // (8)전문전송일자
						hmRsp.put("MSG_SEND_TM", (String) hmRecvHD.get("MSG_SEND_TM")); // (6)전문전송시간

						hmRsp.put("PTR_MCH_ID", (String) hmRecvHD.get("PTR_MCH_ID")); // (15)가맹점ID
						hmRsp.put("CASHER_NO", (String) hmRecvHD.get("CASHER_NO")); // (10)사원번호
						hmRsp.put("TRAN_TYPE", (String) hmRecvHD.get("TRAN_TYPE")); // (2)거래구분
						hmRsp.put("KEY_IN_TYPE", (String) hmRecvHD.get("KEY_IN_TYPE")); // (2)수 입력타입
						hmRsp.put("USE_FUNC_GUBUN", (String) hmRecvHD.get("USE_FUNC_GUBUN")); // (1)사용기능구분

						hmRsp.put("USE_GUBUN", (String) hmRecvHD.get("USE_GUBUN")); // (1)사용구분
						hmRsp.put("GRP_TYPE", (String) hmRecvDTL.get("GRP_TYPE")); // (2)그룹타입
						hmRsp.put("TOT_TRADE_AMT", (String) hmRecvDTL.get("TOT_TRADE_AMT")); // (12)전체거래금액
						hmRsp.put("ORG_MSG_SEND_DT", (String) hmRecvTL.get("ORG_MSG_SEND_DT")); // (8)원거래전문전송일자

						logger.info("hmRsp" + hmRsp + "]");

						dataField = dataField + makeSendDataSSGConPrdApprRsp(hmRsp, df);
					}
				} else {
					dataField = "";
					logger.info("[INFO] usable coupon is not exists.");

					hmRsp.put("INQ_TYPE", "D3"); // (2)INQ종별 (D3)
					hmRsp.put("RESP_CODE", (String) hmRecvHD.get("RESP_CODE")); // (4)응답코드
					hmRsp.put("RESP_MSG", (String) hmRecvHD.get("RESP_MSG")); // (64)응답메시지
					hmRsp.put("TRACE_NO", (String) hmRecvHD.get("MSG_TRACE_NO")); // (26)거래추적번호
					hmRsp.put("TRADE_TYPE", (String) hmRecvHD.get("TRADE_TYPE")); // (2)거래요청타입

					hmRsp.put("SEL_AUTH_NO", (String) hmRecvHD.get("SEL_AUTH_NO")); // (20)조회인증번호
					hmRsp.put("COUPON_NO", ""); // (64)쿠폰번호
					hmRsp.put("BARCODE_NO", (String) hmRecvHD.get("DELEGATE_BARCODE_NO")); // (64)통합바코드번호
					hmRsp.put("USED_AMT", "000000000000"); // (12)사용금액
					hmRsp.put("REMAIN_AMT", "000000000000"); // (12)남은금액

					hmRsp.put("AUTH_DATE", (String) hmRecvTL.get("AUTH_DATE")); // (8)승인일자
					hmRsp.put("AUTH_TIME", (String) hmRecvTL.get("AUTH_TIME")); // (6)승인시간
					hmRsp.put("AUTH_NO", (String) hmRecvTL.get("AUTH_NO")); // (8)승인번호
					hmRsp.put("MSG_SEND_DT", (String) hmRecvHD.get("MSG_SEND_DT")); // (8)전문전송일자
					hmRsp.put("MSG_SEND_TM", (String) hmRecvHD.get("MSG_SEND_TM")); // (6)전문전송시간

					hmRsp.put("PTR_MCH_ID", (String) hmRecvHD.get("PTR_MCH_ID")); // (15)가맹점ID
					hmRsp.put("CASHER_NO", (String) hmRecvHD.get("CASHER_NO")); // (10)사원번호
					hmRsp.put("TRAN_TYPE", (String) hmRecvHD.get("TRAN_TYPE")); // (2)거래구분
					hmRsp.put("KEY_IN_TYPE", (String) hmRecvHD.get("KEY_IN_TYPE")); // (2)수 입력타입
					hmRsp.put("USE_FUNC_GUBUN", (String) hmRecvHD.get("USE_FUNC_GUBUN")); // (1)사용기능구분

					hmRsp.put("USE_GUBUN", (String) hmRecvHD.get("USE_GUBUN")); // (1)사용구분
					hmRsp.put("GRP_TYPE", ""); // (2)그룹타입
					hmRsp.put("TOT_TRADE_AMT", "000000000000"); // (12)전체거래금액
					hmRsp.put("ORG_MSG_SEND_DT", (String) hmRecvTL.get("ORG_MSG_SEND_DT")); // (8)원거래전문전송일자

					logger.info("hmRsp" + hmRsp + "]");

					dataField = makeSendDataSSGConPrdApprRsp(hmRsp, df);
				}
			} catch (Exception e) {
				// 20180110 KSN 응답전문 수신 및 수신 중 오류 발생시 망취소 전문 송신
				getSSGConMNAbnormalCncl(hmComm, hm);
				logger.info("[ERROR] RECV ERR OCCUR::[" + e.getMessage() + "]");
			}
		} catch (Exception e) {
//			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";

			throw e;
		} finally {
			actSock.close();
			dataMsg = ret + dataField;
			logger.info("dataMsg" + dataMsg + "]");
//			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		return dataMsg;
	}

	private String makeSendDataSSGConMNAppr(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 5, 8, 8, 6, 26, 5, 15, 15, 4, 10, 4, 5, 4, 5, 10, 2, 8, 6, 40, 1, 4, 64, 45, 2, 2, 1, 1, 64, 20,
				4, 4, 2, 20, 3, 3, 64, 20, 64, 20, 4, 12, 10, 4, 1, 12, 12, 12, 125, 4, 8, 6, 8, 8, 26, 8, 8, 8, 129,
				1 };
		String strHeaders[] = { "MSG_LEN", // (5)전문 총길이
				"MSG_ID", // (8)전문 번호
				"MSG_SEND_DT", // (8)전문 전송일자
				"MSG_SEND_TM", // (6)전문 전송시간
				"MSG_TRACE_NO", // (26)전문 전송거래추적번호

				"MSG_DATA_LEN", // (5)전문본문길이
				"PTR_ID", // (15)제휴사아이디
				"PTR_MCH_ID", // (15)가맹점아이디
				"SER_COM_CD", // (4)회사코드
				"ST_CODE", // (10)점코드

				"TM_NO", // (4)포스번호
				"SHOP_NO", // (5)매장번호
				"CD_NO", // (4)CD번호
				"TRAN_NO", // (5)거래번호
				"CASHER_NO", // (10)캐셔번호

				"TRAN_TYPE", // (2)거래구분
				"SALE_DATE", // (8)거래일자
				"SALE_TIME", // (6)거래시간
				"SER_COM_REQ_NO", // (40)회사별부가요청정보
				"CRYPTO_GUBUN", // (1)보안설정구분

				"RESP_CODE", // (4)응답코드
				"RESP_MSG", // (64)응답메시지
				"HEADER_FILLER", // (45)헤더필러
				"KEY_IN_TYPE", // (2)수 입력타입
				"TRADE_TYPE", // (2)거래 요청타입

				"USE_FUNC_GUBUN", // (1)사용가능구분
				"USE_GUBUN", // (1)사용구분
				"DELEGATE_BARCODE_NO", // (64)통합바코드번호(암호화)
				"SEL_AUTH_NO", // (20)조회 인증번호
				"GRP_ARRAY_CNT", // (4)그룹 정보 개수

				"GRP_STA", // (4)그룹시작문자
				"GRP_TYPE", // (2)그룹타입
				"ADD_DC_CODE", // (20)추가할인코드
				"INFO_INDEX", // (3)상품정보순서
				"CLASS_GUBUN", // (3)분류구분

				"CPN_NO", // (64)쿠폰번호
				"PRD_ID", // (20)상품아이디
				"PRD_NM", // (64)상품명
				"PRD_SKU_CODE", // (20)상품바코드
				"PRD_CNT", // (4)상품갯수

				"PRD_AMT", // (12)상품원가
				"BRD_CODE", // (10)브랜드코드
				"PRD_TYPE", // (4)상품타입
				"AMT_RATE_GUBUN", // (1)정액/정률구분
				"TOT_TRADE_AMT", // (12)전체거래금액

				"TRADE_AMT", // (12)사용금액
				"REMAIN_AMT", // (12)남은금액
				"ARRAY_ETC_FIELD", // (125)ARRAY DATA 예비필드
				"GRP_END", // (4)그룹종료
				"AUTH_DATE", // (8)승인일자

				"AUTH_TIME", // (6)승인시간
				"AUTH_NO", // (8)승인번호
				"ORG_MSG_SEND_DT", // (8)원거래전문전송일자
				"ORG_MSG_TRACE_NO", // (26)원거래전문전송거래추적번호
				"ORG_SALE_DATE", // (8)원거래거래일자

				"ORG_AUTH_DATE", // (8)원거래승인일자
				"ORG_AUTH_NO", // (8)원거래승인번호
				"DATA_FILLER", // (129)데이터필러
				"MSG_END" // (1)전문종료내역
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			logger.info("★ make send strHeaders : [" + strHeaders[i] + "]" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	private String makeSendDataSSGConMNApprRsp(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 64, 26, 2, 20, 64, 64, 12, 12, 8, 6, 8, 8, 6, 15, 10, 2, 2, 1, 1, 2, 12, 8 };
		String strHeaders[] = { "INQ_TYPE", // (2)INQ 종별
				"RESP_CODE", // (4)응답코드
				"RESP_MSG", // (64)응답메시지
				"TRACE_NO", // (26)전문 추적번호
				"TRADE_TYPE", // (2)거래요청타입

				"SEL_AUTH_NO", // (20)조회 인증번호
				"COUPON_NO", // (64)쿠폰번호 암호화
				"BARCODE_NO", // (64)통합결제바코드번호
				"USED_AMT", // (12)사용금액
				"REMAIN_AMT", // (12)잔액

				"AUTH_DATE", // (8)승인일자
				"AUTH_TIME", // (6)승인시간
				"AUTH_NO", // (8)승인번호
				"MSG_SEND_DT", // (8)전문전송일자
				"MSG_SEND_TM", // (6)전문전송시간

				"PTR_MCH_ID", // (15)가맹점ID
				"CASHER_NO", // (10)사원번호
				"TRAN_TYPE", // (2)거래구분
				"KEY_IN_TYPE", // (2)수 입력타입
				"USE_FUNC_GUBUN", // (1)사용기능구분

				"USE_GUBUN", // (1)사용구분
				"GRP_TYPE", // (2)그룹타입
				"TOT_TRADE_AMT", // (12)전체거래금액
				"ORG_MSG_SEND_DT" // (8)원거래전문전송일자
		};

		for (int i = 0; i < nlens.length; i++) {
			logger.info("★ make send strHeaders : [" + strHeaders[i] + "]" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		return sb.toString();
	}

	// 20180110 KSN SSG CON 물품형 승인응답
	private String makeSendDataSSGConPrdApprRsp(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 64, 26, 2, 20, 64, 12, 12, 8, 6, 8, 8, 6, 15, 10, 2, 1, 1, 2, 12 };
		String strHeaders[] = { "INQ_TYPE", // (2)INQ 종별
				"RESP_CODE", // (4)응답코드
				"RESP_MSG", // (64)응답메시지
				"TRACE_NO", // (26)전문 추적번호
				"TRADE_TYPE", // (2)거래요청타입

				"SEL_AUTH_NO", // (20)조회 인증번호
				"COUPON_NO", // (64)쿠폰번호 암호화
				"USED_AMT", // (12)사용금액
				"REMAIN_AMT", // (12)잔액
				"AUTH_DATE", // (8)승인일자

				"AUTH_TIME", // (6)승인시간
				"AUTH_NO", // (8)승인번호
				"MSG_SEND_DT", // (8)전문전송일자
				"MSG_SEND_TM", // (6)전문전송시간
				"PTR_MCH_ID", // (15)가맹점ID

				"CASHER_NO", // (10)사원번호
				"TRAN_TYPE", // (2)거래구분
				"USE_FUNC_GUBUN", // (1)사용기능구분
				"USE_GUBUN", // (1)사용구분
				"GRP_TYPE", // (2)그룹타입

				"TOT_TRADE_AMT" // (12)전체거래금액
		};

		for (int i = 0; i < nlens.length; i++) {
			logger.info("★ make send strHeaders : [" + strHeaders[i] + "]" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		return sb.toString();
	}

	// 20180110 KSN SSG CON 물품형 조회요청
	public String getSSGConPrdInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmInq = new HashMap<String, String>();
		HashMap<String, String> hmRecvHD = new HashMap<String, String>();
		HashMap<String, String> hmRecvDTL = new HashMap<String, String>();
		HashMap<String, String> hmRecvTL = new HashMap<String, String>();
		HashMap<String, String> hmRsp = new HashMap<String, String>();

		String sendMsg = ""; // SSG CON으로 보낼 송신 전문
		String recvBuf = ""; // SSG CON에서 받을 응답 전문
		String dataField = ""; // SSG dataField
		String dataMsg = ""; // POS로 보낼 응답 전문
		String ret = "00";

		int grpBytes = 400;

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");

		String msgSendDt = sdf.format(calendar.getTime()).substring(0, 8);
		String msgSendTm = sdf.format(calendar.getTime()).substring(8, 14);
		String traceTmStamp = sdf.format(calendar.getTime()).substring(8, 17);

		String tranNo = String.format("%05d", Integer.parseInt(hmComm.get("TRAN_NO")));
		String msgTraceNo = (String) hmComm.get("TRAN_YMD") + (String) hmComm.get("POS_NO") + traceTmStamp + tranNo;

		logger.info("SSGCON::msgSendDt[" + msgSendDt + "]::msgSendTm::[" + msgSendTm + "]::msgTraceNo::[" + msgTraceNo
				+ "]");
		System.out.println("SSGCON::msgSendDt[" + msgSendDt + "]::msgSendTm::[" + msgSendTm + "]::msgTraceNo::["
				+ msgTraceNo + "]");
		try {
			actSock = new ActionSocket(this.svrSock, (Filter) (new COMMConveyerFilter(COMMBiz.SSGCON_FILTER)));

			hmInq.put("MSG_LEN", "00500"); // (5)전문 총길이
			hmInq.put("MSG_ID", "PCIF0100"); // (8)전문구분
			hmInq.put("MSG_SEND_DT", msgSendDt); // (8)전문전송일자
			hmInq.put("MSG_SEND_TM", msgSendTm); // (6)전문전송시간
			hmInq.put("MSG_TRACE_NO", msgTraceNo); // (26)전문전송거래추적번호 : 영업일자(8)+포스번호(4자리)+매장번호(5)+CD번호(4자리)+거래번호(5자리)

			hmInq.put("MSG_DATA_LEN", "00200"); // (5)전문본문길이
			hmInq.put("PTR_ID", SSGCON_GNRFCSTR_ID); // (15)제휴사아이디
			hmInq.put("PTR_MCH_ID", ""); // (15)가맹점아이디
			hmInq.put("SER_COM_CD", "5700"); // (4)회사코드
			hmInq.put("ST_CODE", (String) hmComm.get("STORE_CD")); // (10)점코드

			hmInq.put("TM_NO", (String) hmComm.get("POS_NO")); // (4)포스번호
			hmInq.put("SHOP_NO", "00000"); // (5)매장번호
			hmInq.put("CD_NO", "0000"); // (4)CD번호
			hmInq.put("TRAN_NO", tranNo); // (5)거래번호
			hmInq.put("CASHER_NO", (String) hm.get("USER_ID")); // (10)캐셔번호

			hmInq.put("TRAN_TYPE", "05"); // (2)거래구분
			hmInq.put("SALE_DATE", (String) hm.get("SALE_DATE")); // (8)거래일자
			hmInq.put("SALE_TIME", (String) hm.get("SALE_TIME")); // (6)거래시간
			hmInq.put("SER_COM_REQ_NO", ""); // (40)회사별부가요청정보
			hmInq.put("CRYPTO_GUBUN", "0"); // (1)보안설정구분

			hmInq.put("RESP_CODE", ""); // (4)응답코드
			hmInq.put("RESP_MSG", ""); // (64)응답메시지
			hmInq.put("HEADER_FILLER", ""); // (45)헤더필러
			hmInq.put("KEY_IN_TYPE", (String) hm.get("KEY_IN_TYPE")); // (2)수 입력타입
			hmInq.put("TRADE_TYPE", "47"); // (2)거래 요청타입

			hmInq.put("USE_FUNC_GUBUN", "1"); // (1)사용가능구분
			hmInq.put("USE_GUBUN", "1"); // (1)사용구분
			hmInq.put("DELEGATE_BARCODE_NO", (String) hm.get("BARCODE_NO")); // (64)통합바코드번호(암호화)
			hmInq.put("CPN_NO", (String) hm.get("COUPON_NO")); // (64)쿠폰번호
			hmInq.put("DATA_FILLER", ""); // (65)데이터필러

			hmInq.put("MSG_END", ""); // (1)전문종료내역

			logger.info("hmInq[" + hmInq + "]");

			sendMsg = makeSendDataSSGConCheck(hmInq, df);
			logger.info("SSGCON::sendMsg::[" + sendMsg + "]");
			System.out.println("SSGCON::sendMsg::[" + sendMsg + "]");

			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();

			// 전문종료내역 설정
			sendBytes[499] = (byte) 0x0d;

			logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");

			if (actSock.send(sendBytes, sendBytes.length)) {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] OK");
			} else {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSGPay Server is no response");
			}

			recvBuf = ((String) actSock.receive());
			logger.info("[sms<ssgcon] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");

			// 헤더, 데이터 구분
			hmRecvHD = protocol.getParseSSGConRspHDR(recvBuf); // 300byte + 94byte = 394
			logger.info("[INFO] hmRecvHD::[" + hmRecvHD + "]");

			int grpCnt = Integer.parseInt((String) hmRecvHD.get("GRP_ARRAY_CNT"));
			char type1 = '+';
			String cpnGrpData = COMMBiz.subStringMultibyte(recvBuf, 394, (recvBuf.getBytes().length - 106), type1);
			logger.info("[INFO] cpnGrpData::[" + cpnGrpData.getBytes().length + "]::cpnGrpData::[" + cpnGrpData + "]");

			hmRsp.put("INQ_TYPE", "D5"); // (2)INQ종별 (D5)
			hmRsp.put("RESP_CODE", (String) hmRecvHD.get("RESP_CODE")); // (4)응답코드
			hmRsp.put("RESP_MSG", (String) hmRecvHD.get("RESP_MSG")); // (64)응답메시지
			hmRsp.put("SEL_AUTH_NO", (String) hmRecvHD.get("SEL_AUTH_NO")); // (20)조회인증번호

			if (grpCnt > 0) {
				String grpDataField = "";
				for (int i = 0; i < grpCnt; i++) {
					// grpBytes
					String grpData = COMMBiz.subStringMultibyte(cpnGrpData, i * grpBytes, (i + 1) * grpBytes, type1);
					logger.info("[INFO] grpDataSize::[" + grpData.getBytes().length + "]::grpData::[" + grpData + "]");

					hmRecvDTL = protocol.getParseSSGConCheckRspGRP(grpData);
					logger.info("[INFO] grpCnt::[" + grpCnt + "]::hmRecvDTL::[" + hmRecvDTL + "]");

					hmRsp.put("COUPON_NO", (String) hmRecvDTL.get("CPN_NO")); // (64)쿠폰번호(암호화)

					hmRsp.put("REMAIN_AMT", (String) hmRecvDTL.get("REMAIN_AMT")); // (12)남은금액
					hmRsp.put("EXPIRY_ST", (String) hmRecvDTL.get("EXPIRY_STARTDATE")); // (8)유효기간 시작일
					hmRsp.put("EXPIRY_ET", (String) hmRecvDTL.get("EXPIRY_ENDDATE")); // (8)유효기간 종료일
					hmRsp.put("CLASS_GUBUN", (String) hmRecvDTL.get("CLASS_GUBUN")); // (3)분류구분 //GEN:일반, SEL:선택1,
																						// ALL:상품제한없음, ADD:추가할인
					hmRsp.put("PRD_TYPE", (String) hmRecvDTL.get("PRD_TYPE")); // (4)상품타입 //11:물품교환형, 13:금액차감, 14:금액소멸
					hmRsp.put("PRD_ID", (String) hmRecvDTL.get("PRD_ID")); // (20)상품ID(쿠폰ID)

					grpDataField = grpDataField + (String) hmRecvDTL.get("PRD_SKU_CODE");
				}

				hmRsp.put("PRD_COUNT", String.format("%02d", grpCnt)); // (2)상품수량
				hmRsp.put("PRD_DATA", grpDataField); // (100)상품정보

			} else {
				dataField = "";
				logger.info("[INFO] usable coupon is not exists.");

				hmRsp.put("INQ_TYPE", "D5"); // (2)INQ종별 (D1)
				hmRsp.put("RESP_CODE", (String) hmRecvHD.get("RESP_CODE")); // (4)응답코드
				hmRsp.put("RESP_MSG", (String) hmRecvHD.get("RESP_MSG")); // (64)응답메시지
				hmRsp.put("SEL_AUTH_NO", (String) hmRecvHD.get("SEL_AUTH_NO")); // (20)조회인증번호
				hmRsp.put("COUPON_NO", ""); // (64)쿠폰번호(암호화)

				hmRsp.put("REMAIN_AMT", ""); // (12)남은금액
				hmRsp.put("EXPIRY_ST", ""); // (8)유효기간 시작일
				hmRsp.put("EXPIRY_ET", ""); // (8)유효기간 종료일
				hmRsp.put("CLASS_GUBUN", ""); // (3)분류구분 //GEN:일반, SEL:선택1, ALL:상품제한없음, ADD:추가할인
				hmRsp.put("PRD_TYPE", ""); // (4)상품타입 //13:금액차감, 14:금액소멸
				hmRsp.put("PRD_ID", ""); // (20)상품ID(쿠폰ID)

				hmRsp.put("PRD_COUNT", String.format("%02d", grpCnt)); // (2)상품수량
				hmRsp.put("PRD_DATA", ""); // (100)상품정보
			}

			logger.info("hmRsp" + hmRsp + "]");

			dataField = makeSendDataSSGConPrdInqRsp(hmRsp, df);
		} catch (Exception e) {
//			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		} finally {
			actSock.close();
			dataMsg = ret + dataField;
			logger.info("dataMsg" + dataMsg + "]");
//			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		return dataMsg;
	}

	// 20180110 KSN SSG CON 물품형 승인응답
	private String makeSendDataSSGConPrdInqRsp(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 64, 20, 64, 12, 8, 8, 3, 4, 2, 100, 20 };
		String strHeaders[] = { "INQ_TYPE", // (2)INQ 종별
				"RESP_CODE", // (4)응답코드
				"RESP_MSG", // (64)응답메시지
				"SEL_AUTH_NO", // (20)조회 인증번호
				"COUPON_NO", // (64)쿠폰번호 암호화

				"REMAIN_AMT", // (12)잔액
				"EXPIRY_ST", // (8)유효기간 시작일
				"EXPIRY_ET", // (8)유효기간 종료일
				"CLASS_GUBUN", // (3)분류 구분
				"PRD_TYPE", // (4)상품타입

				"PRD_COUNT", // (2)상품수량
				"PRD_DATA", // (100)상품정보
				"PRD_ID" // (20)상품ID
		};

		for (int i = 0; i < nlens.length; i++) {
			logger.info("★ make send strHeaders : [" + strHeaders[i] + "]" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	// 20171205 KSN SSG CON 망취소
	public String getSSGConMNAbnormalCncl(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
		HashMap<String, String> hmInq = new HashMap<String, String>();
		HashMap<String, String> hmRecvHD = new HashMap<String, String>();
		HashMap<String, String> hmRecvDTL = new HashMap<String, String>();
		HashMap<String, String> hmRecvTL = new HashMap<String, String>();
		HashMap<String, String> hmRsp = new HashMap<String, String>();

		String sendMsg = ""; // SSG CON으로 보낼 송신 전문
		String recvBuf = ""; // SSG CON에서 받을 응답 전문
		String dataField = ""; // SSG dataField
		String dataMsg = ""; // POS로 보낼 응답 전문
		String ret = "00";

		String tranType = "00";
		String useFuncGb = "1";
		String keyInType = "05";
		String selAuthNo = "";
		String tradeType = "25";

		int grpBytes = 396;

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");

		String msgSendDt = sdf.format(calendar.getTime()).substring(0, 8);
		String msgSendTm = sdf.format(calendar.getTime()).substring(8, 14);
		String traceTmStamp = sdf.format(calendar.getTime()).substring(8, 17);

		String tranNo = String.format("%05d", Integer.parseInt(hmComm.get("TRAN_NO")));
		String msgTraceNo = (String) hmComm.get("TRAN_YMD") + (String) hmComm.get("POS_NO") + traceTmStamp + tranNo;

		if ("0".equals((String) hm.get("TYPE"))) {
			tranType = "00";
			selAuthNo = (String) hm.get("SEL_AUTH_NO");
		} else if ("1".equals((String) hm.get("TYPE"))) {
			tranType = "02";
			useFuncGb = "1";
			selAuthNo = "";
			tradeType = "65";
		} else {
			tranType = "";
		}

		if (!"".equals((String) hm.get("KEY_IN_TYPE").trim()) && (String) hm.get("KEY_IN_TYPE").trim() != null) {
			keyInType = (String) hm.get("KEY_IN_TYPE");
		}

		logger.info("SSGCON::keyInType::[" + keyInType + "]::msgSendDt[" + msgSendDt + "]::msgSendTm::[" + msgSendTm
				+ "]::msgTraceNo::[" + msgTraceNo + "]");
		System.out.println("SSGCON::msgSendDt[" + msgSendDt + "]::msgSendTm::[" + msgSendTm + "]::msgTraceNo::["
				+ msgTraceNo + "]");
		try {
			actSock = new ActionSocket(this.svrSock, (Filter) (new COMMConveyerFilter(COMMBiz.SSGCON_FILTER)));

			hmInq.put("MSG_LEN", "01000"); // (5)전문 총길이
			hmInq.put("MSG_ID", "PCIM0300"); // (8)전문구분
			hmInq.put("MSG_SEND_DT", msgSendDt); // (8)전문전송일자
			hmInq.put("MSG_SEND_TM", msgSendTm); // (6)전문전송시간
			hmInq.put("MSG_TRACE_NO", msgTraceNo); // (26)전문전송거래추적번호 : 영업일자(8)+포스번호(4자리)+매장번호(5)+CD번호(4자리)+거래번호(5자리)

			hmInq.put("MSG_DATA_LEN", "00700"); // (5)전문본문길이
			hmInq.put("PTR_ID", SSGCON_GNRFCSTR_ID); // (15)제휴사아이디
			hmInq.put("PTR_MCH_ID", ""); // (15)가맹점아이디
			hmInq.put("SER_COM_CD", "5700"); // (4)회사코드
			hmInq.put("ST_CODE", (String) hmComm.get("STORE_CD")); // (10)점코드

			hmInq.put("TM_NO", (String) hmComm.get("POS_NO")); // (4)포스번호
			hmInq.put("SHOP_NO", "00000"); // (5)매장번호
			hmInq.put("CD_NO", "0000"); // (4)CD번호
			hmInq.put("TRAN_NO", tranNo); // (5)거래번호
			hmInq.put("CASHER_NO", (String) hm.get("USER_ID")); // (10)캐셔번호

			hmInq.put("TRAN_TYPE", tranType); // (2)거래구분
			hmInq.put("SALE_DATE", (String) hm.get("SALE_DATE")); // (8)거래일자
			hmInq.put("SALE_TIME", (String) hm.get("SALE_TIME")); // (6)거래시간
			hmInq.put("SER_COM_REQ_NO", ""); // (40)회사별부가요청정보
			hmInq.put("CRYPTO_GUBUN", "0"); // (1)보안설정구분

			hmInq.put("RESP_CODE", ""); // (4)응답코드
			hmInq.put("RESP_MSG", ""); // (64)응답메시지
			hmInq.put("HEADER_FILLER", ""); // (45)헤더필러
			hmInq.put("KEY_IN_TYPE", keyInType); // (2)수 입력타입
			hmInq.put("TRADE_TYPE", tradeType); // (2)거래 요청타입

			hmInq.put("USE_FUNC_GUBUN", useFuncGb); // (1)사용가능구분
			hmInq.put("USE_GUBUN", "1"); // (1)사용구분
			hmInq.put("DELEGATE_BARCODE_NO", ""); // (22)통합바코드번호(암호화)
			hmInq.put("SEL_AUTH_NO", selAuthNo); // (20)조회 인증번호
			hmInq.put("GRP_ARRAY_CNT", "0001"); // (4)그룹 정보 개수

			hmInq.put("GRP_STA", "GSTA"); // (4)그룹 시작문자
			hmInq.put("GRP_TYPE", "10"); // (2)그룹 타입
			hmInq.put("ADD_DC_CODE", ""); // (20)추가할인코드
			hmInq.put("INFO_INDEX", "001"); // (3)상품 정보 순서
			hmInq.put("CLASS_GUBUN", (String) hm.get("CLASS_GUBUN")); // (3)분류구분

			hmInq.put("CPN_NO", (String) hm.get("COUPON_NO")); // (64)쿠폰 번호(암호화)
			hmInq.put("PRD_ID", (String) hm.get("PRD_ID")); // (20)상품 아이디
			hmInq.put("PRD_NM", (String) hm.get("PRD_NM")); // (64)상품 명
			hmInq.put("PRD_SKU_CODE", ""); // (20)상품 바코드
			hmInq.put("PRD_CNT", "0001"); // (4)상품 갯수

			hmInq.put("PRD_AMT", (String) hm.get("PRD_AMT")); // (12)상품원가
			hmInq.put("BRD_CODE", ""); // (10)브랜드코드
			hmInq.put("PRD_TYPE", (String) hm.get("PRD_TYPE")); // (4)상품타입
			hmInq.put("AMT_RATE_GUBUN", ""); // (1)정액/정률 구분
			hmInq.put("TOT_TRADE_AMT", ""); // (12)전체거래금액

			hmInq.put("TRADE_AMT", String.format("%012d", Integer.parseInt(hm.get("USED_AMT").trim()))); // (12)사용금액
			hmInq.put("REMAIN_AMT", String.format("%012d", 0)); // (12)남은금액
			hmInq.put("ARRAY_ETC_FIELD", ""); // (125)ARRAY DATA 예비필드
			hmInq.put("GRP_END", "GFIN"); // (4)그룹 종료
			hmInq.put("AUTH_DATE", ""); // (8)승인일자

			hmInq.put("AUTH_TIME", ""); // (6)승인시간
			hmInq.put("AUTH_NO", ""); // (8)승인번호
			hmInq.put("ORG_MSG_SEND_DT", (String) hm.get("ORG_MSG_SEND_DT")); // (8)원거래 전문 전송일자
			hmInq.put("ORG_MSG_TRACE_NO", (String) hm.get("ORG_TRACE_NO")); // (26)원거래 전문 전송거래추적번호
			hmInq.put("ORG_SALE_DATE", (String) hm.get("ORG_SALE_DATE")); // (8)원거래 거래일자

			hmInq.put("ORG_AUTH_DATE", (String) hm.get("ORG_AUTH_DATE")); // (8)원거래 승인일자
			hmInq.put("ORG_AUTH_NO", (String) hm.get("ORG_AUTH_NO")); // (8)원거래 승인번호
			hmInq.put("DATA_FILLER", ""); // (129)데이터 필러
			hmInq.put("MSG_END", ""); // (1)전문 종료 내역

			logger.info("hmInq[" + hmInq + "]");

			sendMsg = makeSendDataSSGConMNAppr(hmInq, df);
			logger.info("SSGCON::sendMsg::[" + sendMsg + "]");

			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();

			// 전문종료내역 설정
			sendBytes[999] = (byte) 0x0d;
			logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "]:[" + new String(sendBytes) + "]");

			if (actSock.send(sendBytes, sendBytes.length)) {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] OK");
			} else {
				logger.info("[sms>ssgcon] SEND[" + sendBytes.length + "] ERROR");
				throw new Exception("SSGPay Server is no response");
			}

			recvBuf = ((String) actSock.receive());
			logger.info("[sms<ssgcon] RECV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");

			// 헤더, 데이터, 테일 구분
			hmRecvHD = protocol.getParseSSGConRspHDR(recvBuf); // 300byte + 94byte = 394
			logger.info("[INFO] hmRecvHD::[" + hmRecvHD + "]");
			logger.info("[INFO] RESP_CODE::[" + (String) hmRecvHD.get("") + "]::RESP_MSG::[" + (String) hmRecvHD.get("")
					+ "]");

		} catch (Exception e) {
//			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";

			throw e;
		} finally {
			actSock.close();
			dataMsg = ret + dataField;
			logger.info("dataMsg" + dataMsg + "]");
//			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		return dataMsg;
	}
}
