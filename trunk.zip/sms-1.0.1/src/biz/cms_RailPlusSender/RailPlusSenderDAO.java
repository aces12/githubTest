package biz.cms_RailPlusSender;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class RailPlusSenderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(RailPlusSenderPollingAction.class);

	public int spSMSSEND(String strMsg, String strSender) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("sysinq-sql", "PR_SMSSEND"));
			sql.setString(++i, strMsg);
			sql.setString(++i, strSender);
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
	public List<Object> selSVCFILEDAILY(String stdYmd, String svcID, String cmdTp, String comCD) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SVCCRTDAILY"));
			sql.setString(++i, stdYmd);
			sql.setString(++i, svcID);
			sql.setString(++i, cmdTp);
			sql.setString(++i, comCD);
			
			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		} 
		
		return list;
	}
	
	public int insSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int updSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			//df.CommLogger("▶ SEL Error : " + e);
			//df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			rollback();	
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public List<Object> getWITHMEBizCoNo(String co_cd) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_WITHMEBIZCONUM"));
			sql.setString(++i, "A110010");
			sql.setString(++i, co_cd);			
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return list;
	}
	
	// iMode : 0-지불, 1-환불
	public List<Object> selRAILPLUSPAYRETTRAN(String com_cd, int iMode, String card_key, String double_card_key) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		String strTranTP = "";
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_RAILPLUSPAYRETTRAN"));
			sql.setString(++i, card_key);
			sql.setString(++i, double_card_key);
			sql.setString(++i, com_cd);
			strTranTP = (iMode == 0 ? "01" : "88");
			sql.setString(++i, strTranTP);
			
			logger.info("sql=" + sql.debug());
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	
	// iMode : 0-지불, 1-환불
	public List<Object> sumRAILPLUSPAYRETAMT(String com_cd, int iMode) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		String strTranTP = "";
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SUM_RAILPLUSPAYRETAMT"));
			sql.setString(++i, com_cd);
			strTranTP = (iMode == 0 ? "01" : "88");
			sql.setString(++i, strTranTP);
			
			logger.info("sql=" + sql.debug());
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	
	public List<Object> selRAILPLUSCHGTRAN(String com_cd, String card_key, String double_card_key) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_RAILPLUSCHGTRAN"));
			sql.setString(++i, card_key);
			sql.setString(++i, double_card_key);
			sql.setString(++i, com_cd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	
	public List<Object> selRAILPLUSCHGCNT(String com_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_RAILPLUSCHGCNT"));
			sql.setString(++i, com_cd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	
	public int updRAILPLUSPAYTRAN(String proc_id, String com_cd, String tran_id) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_RAILPLUSPAYTRAN"));
			sql.setString(++i, proc_id);
			sql.setString(++i, tran_id);
			sql.setString(++i, com_cd);
			
//			logger.info(" sql : " + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int updRAILPLUSCHGTRAN(String proc_id, String com_cd, String tran_id) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_RAILPLUSCHGTRAN"));
			sql.setString(++i, proc_id);
			sql.setString(++i, com_cd);
			sql.setString(++i, tran_id);
			
//			logger.info(" sql : " + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
}
