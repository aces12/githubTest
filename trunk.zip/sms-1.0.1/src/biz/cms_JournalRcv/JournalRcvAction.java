/*
 * JournalAction.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */

package biz.cms_JournalRcv;

import java.util.HashMap;
import org.apache.log4j.Logger;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;


import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;

/** 
 * JournalAction
 * A class that has inherited ServerAction(ServerAction을 상속받은 클래스)
 *  
 * @created  on 1.0,  11/03/17
 * @created  by oki(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */ 
public class JournalRcvAction extends ServerAction {
	
	private static Logger logger = Logger.getLogger(JournalRcvAction.class);
	
	
    /**
     * Receive journal data fro SC through 9003 PORT(SC로부터 저널 데이타를 9003 PORT로 받음).
     * 
     * @param ActionSocket
     * @return 
     * @throws Exception
     */
	public void execute(ActionSocket actionSocket) throws Exception {
		// TODO Auto-generated method stub
		HashMap hmCommon = new HashMap();
		HashMap hmData = new HashMap();
		JournalRcvDAO dao= new JournalRcvDAO();
		COMMLog df = new COMMLog();
		
		int ret=0;
		String rcvBuf="";
		String sendMsg="";
		String retValue="OK!";

		try {
			// Journal Data received from SC(SC로부터 받은  저널 데이타) 
			rcvBuf = ((String)actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Set Work Start Time(업무시작시간설정 )
			df.setStartTime();		
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress().getHostAddress().toString() ,
			        String.valueOf(actionSocket.getSocket().getPort()), logger, "JOURNAL" );

//			df.CommLogger("[pos>sms] SEND[" + rcvBuf.length() + "]:[" + rcvBuf + "]");	
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			// Compare to see if message Type value MsgType is journal(MsgType 전문구분값이  저널인지 비교한다).
			if ( !(COMMBiz.getCommMsgType(hmCommon, COMMBiz.JOURNAL)) ) {
				df.CommLogger("[pos>sms] SEND[" + rcvBuf.length() + "]:[" + rcvBuf + "]");
				df.CommLogger("▶  Message Type(전문 구분)("+hmCommon.get("MSG_TYPE")+") It is Code Error(코드 오류 입니다).");
				retValue = "[ERROR]";
				ret = -99;
			} else {
				// Save REceive Data into hmData according to COMMBiz.JOURNAL_DATA(Receive데이타를 COMMBiz.JOURNAL_DATA에 맞춰서 hmData에 저장) 
				hmData = COMMBiz.getData(rcvBuf, COMMBiz.JOURNAL_DATA);
				// Save journal data(저널 데이타 저장)
				ret = dao.setData(hmCommon, hmData, rcvBuf, df);
			}
		} catch (Exception e) {
			//029=HOST APPL ERR
			ret = 29;
			retValue = "[ERROR]3:" + e.getMessage();
			df.CommLogger("[pos>sms] SEND[" + rcvBuf.length() + "]:[" + rcvBuf + "]");
			df.CommLogger("▶ "+ retValue);
		}
		
		try {			
//			df.CommLogger("--- makeSendData:"+ret);
			// Make response message data(응답 전문데이타 만들기) 
			sendMsg = COMMBiz.makeSendData(hmCommon,0, ret);	
			// Send response data(응답 데이타 전송) 
			actionSocket.send(sendMsg);
//			df.CommLogger("[sms>pos] SEND[" + sendMsg.length() + "]:[" + sendMsg + "]");
//			df.CommLogger("▶ 2.SEND MSG: "+sendMsg + " ==>LEN: " + sendMsg.length());		
		} catch (Exception e) {
			retValue = "[ERROR]4:" + e.getMessage();
			df.CommLogger("▶ "+ retValue);	
		} finally {
			// Journal work termination log(저널 업무 종료 로그) 
			df.close( "JOURNAL", retValue);
		}
	}
}
