package biz.cms_TMoneyIrt;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;

import biz.comm.COMMLog;

public class TMoneyIrtDAO extends GenericDAO {
	
	public String getSvcDepstInq(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		String dataMsg = "";
		String ret = "00";
		
		try {
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SVCDEPST"));
			sql.setString(++i, "A16" + (String)hm.get("STORE_CODE"));
			sql.setString(++i, (String)hm.get("SERVICE_TP"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
		
			list = executeQuery(sql);
			if( list.size() > 0 ) {
				Map<String, String> map = (Map<String, String>)list.get(0);
				hm.put("DEPST_RAMT", (String)map.get("DEPST_AMT_REM_AMT"));
			}else {
				hm.put("DEPST_RAMT", "0000000000000000000000");
			}
		}catch(SQLException e) {
			ret = "20";
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			dataMsg = ret + makeSendDataSvcDepstRsp(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
			end();
		}
		
		return dataMsg;
	}
	
	private String makeSendDataSvcDepstRsp(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,5,2,22};
		String strHeaders[] = {
			"INQ_TYPE",
			"STORE_CODE",
			"SERVICE_TP",
			"DEPST_RAMT"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getTMoneyClientInfo(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		try {
			begin();
			
			sql.put(findQuery("service-sql", "INS_TMONEYTMNALSAMIDMST"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("MEMBER_ID"));
			sql.setString(++i, (String)hm.get("TERMINAL_ID"));
			sql.setString(++i, (String)hm.get("SAM_ID"));
			
			//df.CommLogger("[SQL1][INS_TMONEYCLIENTINFO]" + sql.debug() );
			
			//DB Connection(DB 접속)
			connect("CMGNS");			
			executeUpdate(sql);
			
			
		}catch(SQLException e) { 
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();	
			throw e;
		}finally {
			dataMsg = ret + makeSendDataClientInfo(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
			end();
		}
		
		return dataMsg;
	}
	
	private String makeSendDataClientInfo(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,7,9,16};
		
		String strHeaders[] = {
			"INQ_TYPE",
			"MEMBER_ID",
			"TERMINAL_ID",
			"SAM_ID"
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
}