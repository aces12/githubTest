package biz.cms_TMoneyIrt;

import java.net.Socket;
import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

public class TMoneyIrtConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;
	
	COMMLog df = null;
	
	public TMoneyIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}
	
	public String getTMoneyCHRGInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		TMoneyIrtProtocol protocol = new TMoneyIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 티머니로 보낼 송신 전문
		String recvBuf = "";	// 티머니에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.TMONEY_FILTER)));

//			String tranYYMMDD = ((String)hmComm.get("TRAN_YMD")).substring(2);
	
			//hm.put("COMMAND_TY", (String)hm.get("COMMAND_TY"));					// 업무구분
			hm.put("RECORD_LEN", "  ");
			hm.put("MEMBER_USE_FIELD", " ");										// 제휴사 사용 영역
			//hm.put("TRANSACTION_ID", (String)hm.get("TRANSACTION_ID"));			// TRANSACTION ID
			//hm.put("CARD_NO", (String)hm.get("CARD_NO"));							// 선불카드 ID
			//hm.put("CARD_OWNER_ID", (String)hm.get("CARD_OWNER_ID"));				// 카드소지자구분
			//hm.put("CHRG_REQ_YMDHMS", (String)hm.get("CHRG_REQ_YMDHMS"));			// 충전/직전충전취소/환불 요청일시
			//hm.put("KEYSET_VER", (String)hm.get("KEYSET_VER"));					// 키셋버전
			//hm.put("ALGM_ID", (String)hm.get("ALGM_ID"));							// 알고리즘 ID
			//hm.put("CARD_DEAL_SNO", (String)hm.get("CARD_DEAL_SNO"));				// 카드거래 일련번호
			//hm.put("CHRG_BEF_RAMT", (String)hm.get("CHRG_BEF_RAMT"));				// 선불카드 충전/직전충전취소/환불 전 잔액
			//hm.put("CHRG_REQ_AMT", (String)hm.get("CHRG_REQ_AMT"));				// 선불카드 충전/직전충전취소/환불 요청 금액
			//hm.put("RAND_NUM", (String)hm.get("RAND_NUM"));						// 난수
			//hm.put("SIGN1_VAL", (String)hm.get("SIGN1_VAL"));						// SIGN1 값
			//hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID"));					// 단말기 ID
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));						// 가맹점 ID
			//hm.put("ORG_SAM_ID", (String)hm.get("ORG_SAM_ID"));					// 직전/원 거래 SAM ID
			//hm.put("ORG_SAM_DEAL_SNO", (String)hm.get("ORG_SAM_DEAL_SNO"));		// 원거래 SAM 거래일련번호 (for 지불취소)
			//hm.put("ORG_CARD_DEAL_SNO", (String)hm.get("ORG_CARD_DEAL_SNO"));		// 직전/원 거래 카드 거래 일련번호
			//hm.put("ORG_CHRG_AMT", (String)hm.get("ORG_CHRG_AMT"));				// 직전거래 충전금액, 원거래 지불금액
			//hm.put("ORG_SALEDATE", (String)hm.get("ORG_SALEDATE"));				// 원거래 일시 (for 지불취소)
			//hm.put("ORG_TRANSACTION_ID", (String)hm.get("ORG_TRANSACTION_ID"));	// 원거래 TRANSACTION ID
			//hm.put("ORG_POS_SALEDATE", (String)hm.get("ORG_POS_SALEDATE"));		// 원거래 POS 영업일자(for 지불취소)
			//hm.put("ORG_POS_BILL_NO", (String)hm.get("ORG_POS_BILL_NO"));			// 원거래 POS 영수증 번호(for 지불취소)
			
			hm.put("FILLER", " ");													// FILLER
			
			// C1:충전요청, H1:직전충전취소요청, R1:환불요청
			if( ((String)hm.get("COMMAND_TY")).equals("C1")
					|| ((String)hm.get("COMMAND_TY")).equals("H1")
					|| ((String)hm.get("COMMAND_TY")).equals("R1") ) {
				
				sendMsg = makeSendDataTMoneyCHRGInq(hm);
			}else if( ((String)hm.get("COMMAND_TY")).equals("P7") ) {	// P7:지불취소(반품충전)
				sendMsg = makeSendDataTMoneyRtnCHRGInq(hm);
			}else {
				throw new Exception("invalid COMMAND_TY value");
			}
			
			// 전송할 메시지를  byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문 길이 0x018C(396) 설정
			sendBytes[2] = (byte)0x01;
			sendBytes[3] = (byte)0x8c;
			
			df.CommLogger("[sms>tmoney] SEND[" + sendBytes.length + "]:[JOB_CODE:" + (String)hm.get("COMMAND_TY") + "]:[" + (new String(sendBytes)) + "]");
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>tmoney] SEND[" + sendBytes.length + "] OK");
			}else {
				df.CommLogger("[sms>tmoney] SEND[" + sendBytes.length + "] ERROR");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<tmoney] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			
			hmRecv = protocol.getParseTMoneyCHRGRsp(recvBuf, df);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));

			// 수신 확인 전문 전송(정상이든 오류발생이든 수신 확인 전문 전송)
			HashMap<String, String> hmSend = new HashMap<String, String>();
			hmSend = hmRecv;
			if( ((String)hm.get("COMMAND_TY")).equals("C1") ) {
				hmSend.put("COMMAND_TY", "C3");
			}else if( ((String)hm.get("COMMAND_TY")).equals("H1") ) {
				hmSend.put("COMMAND_TY", "H3");
			}else if( ((String)hm.get("COMMAND_TY")).equals("R1") ) {
				hmSend.put("COMMAND_TY", "R3");
			}else if( ((String)hm.get("COMMAND_TY")).equals("P7") ) {
				hmSend.put("COMMAND_TY", "P8");
			}
			hmSend.put("RECORD_LEN", "  ");
			sendMsg = "";
			sendMsg = makeSendDataTMoneyCHRGCheck(hmSend);
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes2[] = sendMsg.getBytes();
			
			// 전문 길이 0x018C(396) 설정
			sendBytes2[2] = (byte)0x01;
			sendBytes2[3] = (byte)0x8c;
			
			df.CommLogger("[sms>tmoney] SEND[" + sendBytes2.length + "]:[JOB_CODE:" + (String)hm.get("COMMAND_TY") + "]:[" + (new String(sendBytes2)) + "]");
			
			if( actSock.send(sendBytes2, sendBytes2.length) ) {
				df.CommLogger("[sms>tmoney] SEND[" + sendBytes2.length + "] OK");
			}else {
				df.CommLogger("[sms>tmoney] SEND[" + sendBytes2.length + "] ERROR");
			}
			
			if( ((String)hm.get("COMMAND_TY")).equals("C3") ) {
				hmRecv.put("COMMAND_TY", "C2");
			}else if( ((String)hm.get("COMMAND_TY")).equals("H3") ) {
				hmRecv.put("COMMAND_TY", "H2");
			}else if( ((String)hm.get("COMMAND_TY")).equals("R3") ) {
				hmRecv.put("COMMAND_TY", "R2");
			}else if( ((String)hm.get("COMMAND_TY")).equals("P8") ) {
				hmRecv.put("COMMAND_TY", "7P");
			}
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataTMoneyCHRGRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataTMoneyCHRGInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,50,20,16
				      ,2,14,2,2,10
				      ,10,10,16,8,9
				      ,7,16,10,10,184};
		String strHeaders[] = {
			"COMMAND_TY" ,				// 업무구분
			"RECORD_LEN" ,				// 레코드 길이
			"MEMBER_USE_FIELD" ,		// 제휴사 사용 영역
			"TRANSACTION_ID" ,			// TRANSACTION ID
			"CARD_NO" ,					// 선불카드  ID
			
			"CARD_OWNER_ID" ,			// 카드소지자구분
			"CHRG_REQ_YMDHMS",			// 충전/직전충전취소/환불 요청일시
			"KEYSET_VER" ,				// 키셋버전
			"ALGM_ID" ,					// 알고리즘 ID
			"CARD_DEAL_SNO" ,			// 카드거래 일련번호
			
			"CHRG_BEF_RAMT" ,			// 선불카드 충전/직전충전취소/환불 전 잔액
			"CHRG_REQ_AMT" ,			// 선불카드 충전/직전충전취소/환불 요청 금액
			"RAND_NUM" ,				// 난수
			"SIGN1_VAL" ,				// SIGN1 값
			"TERMINAL_ID" ,				// 단말기 ID
			
			"MEMBER_ID" ,				// 가맹점 ID
			"ORG_SAM_ID" ,				// 직전거래 SAM ID
			"ORG_CARD_DEAL_SNO" ,		// 직전거래 카드 거래 일련번호
			"ORG_CHRG_AMT" ,			// 직전거래 충전금액
			"FILLER"			
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			//df.CommLogger("★ make send TMoneyCHRGInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataTMoneyRtnCHRGInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,50,20,16
					  ,2,14,2,2,10
					  ,10,10,16,8,9
					  ,7,16,10,10,10
					  ,14,20,8,5,127};
		String strHeaders[] = {
			"COMMAND_TY" ,
			"RECORD_LEN" ,
			"MEMBER_USE_FIELD" ,
			"TRANSACTION_ID" ,
			"CARD_NO" ,
			
			"CARD_OWNER_ID" ,
			"CHRG_REQ_YMDHMS" ,
			"KEYSET_VER" ,
			"ALGM_ID" ,
			"CARD_DEAL_SNO" ,
			
			"CHRG_BEF_RAMT" ,
			"CHRG_REQ_AMT" ,
			"RAND_NUM" ,
			"SIGN1_VAL" ,
			"TERMINAL_ID" ,
			
			"MEMBER_ID" ,
			"ORG_SAM_ID" ,
			"ORG_SAM_DEAL_SNO" ,
			"ORG_CARD_DEAL_SNO" ,
			"ORG_CHRG_AMT" ,
			
			"ORG_SALEDATE" ,
			"ORG_TRANSACTION_ID" ,
			"ORG_POS_SALEDATE" ,
			"ORG_POS_BILL_NO" ,
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send TMoneyRtnCHRGInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataTMoneyCHRGRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,20,16,16
					  ,10,2,14,2,2
					  ,10,10,10,10,10
					  ,10,10,16,8,9
					  ,7,14,4,4,2
					  ,30,100};
		String strHeaders[] = {
			"INQ_TYPE" ,
			"COMMAND_TY" ,
			"TRANSACTION_ID" ,
			"CARD_NO" ,
			"SAM_ID" ,
			
			"SAM_DEAL_SNO" ,
			"CARD_OWNER_ID" ,
			"CHRG_REQ_YMDHMS" ,
			"KEYSET_VER" ,
			"ALGM_ID" ,
			
			"CARD_DEAL_SNO" ,
			"CHRG_BEF_RAMT" ,
			"CHRG_REQ_AMT" ,
			"CHRG_AFT_RAMT" ,
			"CHRG_FEE" ,
			
			"CARD_DEPOSIT" ,
			"PENALTY_AMT" ,
			"RAND_NUM" ,
			"SIGN2_VAL" ,
			"TERMINAL_ID" ,
			
			"MEMBER_ID" ,
			"CHRG_DEAL_YMDHMS" ,
			"CARD_STATUS_CD" ,
			"TERMINAL_STATUS_CD" ,
			"RES_CD" ,
			
			"ERR_MSG" ,
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send TMoneyCHRGRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataTMoneyCHRGCheck(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,50,20,16
					  ,16,10,2,14,2
					  ,2,10,10,10,10
					  ,10,10,10,16,8
					  ,9,7,14,4,4
					  ,2,30,100};
		String strHeaders[] = {
			"COMMAND_TY" ,
			"RECORD_LEN" ,
			"MEMBER_USE_FIELD" ,
			"TRANSACTION_ID" ,
			"CARD_NO" ,
			
			"SAM_ID" ,
			"SAM_DEAL_SNO" ,
			"CARD_OWNER_ID" ,
			"CHRG_REQ_YMDHMS" ,
			"KEYSET_VER" ,
			
			"ALGM_ID" ,
			"CARD_DEAL_SNO" ,
			"CHRG_BEF_RAMT" ,
			"CHRG_REQ_AMT" ,
			"CHRG_AFT_RAMT" ,
			
			"CHRG_FEE" ,
			"CARD_DEPOSIT" ,
			"PENALTY_AMT" ,
			"RAND_NUM" ,
			"SIGN2_VAL" ,
			
			"TERMINAL_ID" ,
			"MEMBER_ID" ,
			"CHRG_DEAL_YMDHMS" ,
			"CARD_STATUS_CD" ,
			"TERMINAL_STATUS_CD" ,
			
			"RES_CD" ,
			"ERR_MSG" ,
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send TMoneyCHRGCheck : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getTMoneyCHRGCompleteInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {		
		String sendMsg = "";	// 티머니로 보낼 송신 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.TMONEY_FILTER)));
			
//			String tranYYMMDD = ((String)hmComm.get("TRAN_YMD")).substring(2);
			
			//hm.put("COMMAND_TY", (String)hm.get("COMMAND_TY"));					// 업무구분
			hm.put("RECORD_LEN", "  ");
			hm.put("MEMBER_USE_FIELD", " ");										// 제휴사 사용 영역
			//hm.put("TRANSACTION_ID", (String)hm.get("TRANSACTION_ID"));			// TRANSACTION ID
			//hm.put("CARD_NO", (String)hm.get("CARD_NO"));							// 선불카드 ID
			//hm.put("SAM_ID", (String)hm.get("SAM_ID"));							// SAM ID
			//hm.put("SAM_DEAL_SNO", (String)hm.get("SAM_DEAL_SNO"));				// SAM 거래 일련번호
			//hm.put("CARD_OWNER_ID", (String)hm.get("CARD_OWNER_ID"));				// 카드소지자구분
			//hm.put("CHRG_REQ_YMDHMS", (String)hm.get("CHRG_REQ_YMDHMS"));			// 충전/직전충전취소/환불 요청일시
			//hm.put("KEYSET_VER", (String)hm.get("KEYSET_VER"));					// 키셋버전
			//hm.put("ALGM_ID", (String)hm.get("ALGM_ID"));							// 알고리즘 ID
			//hm.put("CARD_DEAL_SNO", (String)hm.get("CARD_DEAL_SNO"));				// 카드거래 일련번호
			//hm.put("CHRG_BEF_RAMT", (String)hm.get("CHRG_BEF_RAMT"));				// 선불카드 충전/직전충전취소/환불 전 잔액
			//hm.put("CHRG_REQ_AMT", (String)hm.get("CHRG_REQ_AMT"));				// 선불카드 충전/직전충전취소/환불 요청 금액
			//hm.put("CHRG_AFT_RAMT", (String)hm.get("CHRG_AFT_RAMT"));				// 선불카드 충전 후 잔액
			//hm.put("CHRG_FEE", (String)hm.get("CHRG_FEE"));						// 충전/직전충전취소/환불 수수료
			//hm.put("CARD_DEPOSIT", (String)hm.get("CARD_DEPOSIT"));				// 카드 보증금
			//hm.put("PENALTY_AMT", (String)hm.get("PENALTY_AMT"));					// PENALTY 금액
			//hm.put("RAND_NUM", (String)hm.get("RAND_NUM"));						// 난수
			//hm.put("SIGN2_VAL", (String)hm.get("SIGN2_VAL"));						// SIGN2 값
			//hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID"));					// 단말기 ID
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));						// 가맹점 ID
			//hm.put("CHRG_DEAL_YMDHMS", (String)hm.get("CHRG_DEAL_YMDHMS"));		// 충전/직전충전취소/환불 거래 일시
			//hm.put("CARD_STATUS_CD", (String)hm.get("CARD_STATUS_CD"));			// 카드 상태 코드
			//hm.put("CARD_STATUS_CD", (String)hm.get("CARD_STATUS_CD"));			// 단말기 상태 코드
			//hm.put("RES_CD", (String)hm.get("RES_CD"));							// 응답코드
			//hm.put("ERR_MSG", (String)hm.get("ERR_MSG"));							// 오류 메시지
			
			hm.put("FILLER", " ");													// FILLER
			
			sendMsg = makeSendDataTMoneyCHRGCompleteInq(hm);
			df.CommLogger("[sms>tmoney] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("COMMAND_TY") + "]:[" + sendMsg + "]");
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문 길이 0x018C(396) 설정
			sendBytes[2] = (byte)0x01;
			sendBytes[3] = (byte)0x8c;
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>tmoney] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>tmoney] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("TMoney server is no response");
			}
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret;
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
				  
	private String makeSendDataTMoneyCHRGCompleteInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,50,20,16
					  ,16,10,2,14,2
					  ,2,10,10,10,10
					  ,10,10,10,16,8
					  ,9,7,14,4,4
					  ,2,30,100};
		String strHeaders[] = {
			"COMMAND_TY" ,
			"RECORD_LEN" ,
			"MEMBER_USE_FIELD" ,
			"TRANSACTION_ID" ,
			"CARD_NO" ,
			
			"SAM_ID" ,
			"SAM_DEAL_SNO" ,
			"CARD_OWNER_ID" ,
			"CHRG_REQ_YMDHMS" ,
			"KEYSET_VER" ,
			
			"ALGM_ID" ,
			"CARD_DEAL_SNO" ,
			"CHRG_BEF_RAMT" ,
			"CHRG_REQ_AMT" ,
			"CHRG_AFT_RAMT" ,
			
			"CHRG_FEE" ,
			"CARD_DEPOSIT" ,
			"PENALTY_AMT" ,
			"RAND_NUM" ,
			"SIGN2_VAL" ,
			
			"TERMINAL_ID" ,
			"MEMBER_ID" ,
			"CHRG_DEAL_YMDHMS" ,
			"CARD_STATUS_CD" ,
			"TERMINAL_STATUS_CD" ,
			
			"RES_CD" ,
			"ERR_MSG" ,
			"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send TMoneyCHRGCompleteInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getTMoneyCardTPCHGInq(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		TMoneyIrtProtocol protocol = new TMoneyIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 티머니로 보낼 송신 전문
		String recvBuf = "";	// 티머니에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.TMONEY_FILTER)));
			
//			String tranYYMMDD = ((String)hmComm.get("TRAN_YMD")).substring(2);
			
			//hm.put("COMMAND_TY", (String)hm.get("COMMAND_TY"));					// 업무구분
			//hm.put("RECORD_LEN", String.format("%02x", 0xff&(int)246));			// 레코드 길이
			hm.put("RECORD_LEN", "  ");
			//hm.put("TRANSACTION_ID", (String)hm.get("TRANSACTION_ID"));				// TRANSACTION ID
			//hm.put("INSTITUTION_ID", (String)hm.get("INSTITUTION_ID"));			// 기관코드
			//hm.put("REQ_JOB_ID", (String)hm.get("REQ_JOB_ID"));					// 요청작업 구분
			//hm.put("SYSTEM_ID", (String)hm.get("SYSTEM_ID"));						// 시스템 구분
			//hm.put("ALGM_ID", (String)hm.get("ALGM_ID"));							// 알고리즘 ID
			//hm.put("KEY_VER", (String)hm.get("KEY_VER"));							// 키버전
			//hm.put("CARD_RAMT", (String)hm.get("CARD_RAMT"));						// 선불카드 잔액
			//hm.put("KEYSET_VER", (String)hm.get("KEYSET_VER"));					// 키셋버전
			//hm.put("CARD_NO", (String)hm.get("CARD_NO"));							// 교통카드 ID
			//hm.put("CARD_DEAL_SNO", (String)hm.get("CARD_DEAL_SNO"));				// 카드거래 일련번호
			//hm.put("RAND_NUM", (String)hm.get("RAND_NUM"));						// 난수
			//hm.put("SIGN1_VAL", (String)hm.get("SIGN1_VAL"));						// SIGN1 값
			//hm.put("INST_REQ_YMDHMS", (String)hm.get("INST_REQ_YMDHMS"));			// 제휴기관 요청일시
			//hm.put("BEF_PARAM_DATA", (String)hm.get("BEF_PARAM_DATA"));			// 변경 전 파라미터 정보
			//hm.put("WORK_INFO1", (String)hm.get("WORK_INFO1"));					// 작업정보1
			//hm.put("WORK_INFO2", (String)hm.get("WORK_INFO2"));					// 작업정보2
			//hm.put("WORK_INFO3", (String)hm.get("WORK_INFO3"));					// 작업정보3
			//hm.put("WORK_INFO4", (String)hm.get("WORK_INFO4"));					// 작업정보4
			//hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID"));					// 단말기 ID
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));						// 가맹점 ID
			//hm.put("CARD_PUB_ID", (String)hm.get("CARD_PUB_ID"));					// 카드발행사 ID
			hm.put("FILLER", " ");													// FILLER
			
			sendMsg = makeSendDataTMoneyCardTPCHGInq(hm);
			df.CommLogger("[sms>tmoney] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("COMMAND_TY") + "]:[" + sendMsg + "]");
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문 길이 0x00f6(246) 설정
			sendBytes[2] = (byte)0x00;
			sendBytes[3] = (byte)0xf6;
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>tmoney] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>tmoney] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("TMoney server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[sms<tmoney] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			
			hmRecv = protocol.getParseTMoneyCardTPCHGRsp(recvBuf);
			hmRecv.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataTMoneyCardTPCHGRsp(hmRecv);
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataTMoneyCardTPCHGRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,20,2,2
					  ,2,16,10,32,8
					  ,14,2,30,9,7
					  ,7};
		String strHeaders[] = {
			"INQ_TYPE",
			"COMMAND_TY",
			"TRANSACTION_ID",
			"INSTITUTION_ID",
			"REQ_JOB_ID",
			
			"SYSTEM_ID",
			"SAM_ID",
			"SAM_DEAL_SNO",
			"ENCODED_PARAM_VAL",
			"SIGN2_VAL",
			
			"KSCC_RSP_YMDHMS",
			"RES_CD",
			"ERR_MSG",
			"TERMINAL_ID",
			"MEMBER_ID",
			
			"CARD_PUB_ID"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			//df.CommLogger("★ make makeSendDataTMoneyCardTPCHGRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeSendDataTMoneyCardTPCHGInq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,20,2,2
					  ,2,2,2,10,2
					  ,16,10,16,8,14
					  ,8,20,20,20,2
					  ,9,7,7,47};
		String strHeaders[] = {
			"COMMAND_TY",
			"RECORD_LEN",
			"TRANSACTION_ID",
			"INSTITUTION_ID",
			"REQ_JOB_ID",
			
			"SYSTEM_ID",
			"ALGM_ID",
			"KEY_VER",
			"CARD_RAMT",
			"KEYSET_VER",
			
			"CARD_NO",
			"CARD_DEAL_SNO",
			"RAND_NUM",
			"SIGN1_VAL",
			"INST_REQ_YMDHMS",
			
			"BEF_PARAM_DATA",
			"WORK_INFO1",
			"WORK_INFO2",
			"WORK_INFO3",
			"WORK_INFO4",
			
			"TERMINAL_ID",
			"MEMBER_ID",
			"CARD_PUB_ID",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			//df.CommLogger("★ make sendTMoneyCardTPCHGInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String getTMoneyCardTPCHGComplete(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 티머니로 보낼 송신 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.TMONEY_FILTER)));
			
			String tranYYMMDD = ((String)hmComm.get("TRAN_YMD")).substring(2);
			
			//hm.put("COMMAND_TY", (String)hm.get("COMMAND_TY"));					// 업무구분
			//hm.put("RECORD_LEN", String.format("%02x", 0xff&(int)146));				// 레코드 길이
			hm.put("RECORD_LEN", "  ");
			//hm.put("TRANSACTION_ID", (String)hm.get("TRANSACTION_ID"));			// TRANSACTION ID
			//hm.put("INSTITUTION_ID", (String)hm.get("INSTITUTION_ID"));			// 기관코드
			//hm.put("REQ_JOB_ID", (String)hm.get("REQ_JOB_ID"));					// 요청작업 구분
			//hm.put("SYSTEM_ID", (String)hm.get("SYSTEM_ID"));						// 시스템 구분
			//hm.put("SIGN3_VAL", (String)hm.get("SIGN3_VAL"));						// SIGN3 값
			//hm.put("UPDATE_YMDHMS", (String)hm.get("UPDATE_YMDHMS"));				// 업데이트 일시
			//hm.put("FINAL_PARAM_VAL", (String)hm.get("FINAL_PARAM_VAL"));			// 변경 후 파라미터 정보
			//hm.put("CARD_STATUS_CD", (String)hm.get("CARD_STATUS_CD"));			// 카드상태코드
			//hm.put("RES_CD", (String)hm.get("RES_CD"));							// 응답코드
			//hm.put("ERR_MSG", (String)hm.get("ERR_MSG"));							// 오류 메시지
			//hm.put("TERMINAL_ID", (String)hm.get("TERMINAL_ID"));					// 단말기 ID
			//hm.put("MEMBER_ID", (String)hm.get("MEMBER_ID"));						// 가맹점 ID
			//hm.put("CARD_PUB_ID", (String)hm.get("CARD_PUB_ID"));					// 카드발행사 ID
			hm.put("FILLER", " ");
			sendMsg = makeSendDataTMoneyCardTPCHGComplete(hm);
			df.CommLogger("[sms>tmoney] SEND[" + sendMsg.getBytes().length + "]:[JOB_CODE:" + (String)hm.get("COMMAND_TY") + "]:[" + sendMsg + "]");
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			// 전문 길이 0x0092(146) 설정
			sendBytes[2] = (byte)0x00;
			sendBytes[3] = (byte)0x92;
			
			if( actSock.send(sendBytes, sendBytes.length) ) {
				df.CommLogger("[sms>tmoney] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>tmoney] SEND[" + sendMsg.getBytes().length + "] ERROR");

				throw new Exception("TMoney server is no response");
			}
		}catch(Exception e) {
			//df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret;
			//df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataTMoneyCardTPCHGComplete(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2,20,2,2,2,8,14,8,4,2,30,9,7,7,31};
		
		String strHeaders[] = {
			"COMMAND_TY",
			"RECORD_LEN",
			"TRANSACTION_ID",
			"INSTITUTION_ID",
			"REQ_JOB_ID",
			"SYSTEM_ID",
			"SIGN3_VAL",
			"UPDATE_YMDHMS",
			"FINAL_PARAM_VAL",
			"CARD_STATUS_CD",
			"RES_CD",
			"ERR_MSG",
			"TERMINAL_ID",
			"MEMBER_ID",
			"CARD_PUB_ID",
			"FILLER"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			//df.CommLogger("★ make send TMoneyCHRGInq : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
}