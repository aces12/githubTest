package biz.cms_CashBeeSender;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class CashBeeSenderProtocol {
	//private static Logger logger = Logger.getLogger(CashBeeSenderProtocol.class);
	
	public static int COMM_LEN = 20;
	public static int LENGTH_BY_SEQUENCE = 3729;
	
	public HashMap<String, String> getParsePUBCOINFODATA(String recvBuf, COMMLog df) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {7,20,2,16,4
					  ,4,15,1,6,6
					  ,2,1,1,1,1
					  ,1,2,7,1};
		String strHeaders[] = {
			"PUBCO_ID",
			"PUBCO_NM",
			"PUBCO_KEYVER",
			"PUBCO_KEY",
			"CHRG_RATE",
			
			"BUY_RATE",
			"RFU",
			"INFOCHG",
			"RFND_FEE_AMT",
			"PENALTY_AMT",
			
			"SAM_TP",
			"CHRG_ABLE_YN",
			"BUY_ABLE_YN",
			"RFND_ABLE_YN",
			"STOLEN_YN",
			
			"RFND_MAX_AMT",
			"ELEC_BILL_ID",
			"CHRG_MAX_AMT",
			"ONCE_CHRG_MAX_AMT"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);

		df.CommLogger("recvBuf[" + recvBuf + "]");
		df.CommLogger("PUBCO_ID = " + (String)hm.get("PUBCO_ID"));
		df.CommLogger("PUBCO_NM = " + (String)hm.get("PUBCO_NM"));
		df.CommLogger("PUBCO_KEYVER = " + (String)hm.get("PUBCO_KEYVER"));
		df.CommLogger("PUBCO_KEY = " + (String)hm.get("PUBCO_KEY"));
		df.CommLogger("CHRG_RATE = " + (String)hm.get("CHRG_RATE"));
		
		df.CommLogger("BUY_RATE = " + (String)hm.get("BUY_RATE"));
		df.CommLogger("RFU = " + (String)hm.get("RFU"));
		df.CommLogger("INFOCHG = " + (String)hm.get("INFOCHG"));
		df.CommLogger("RFND_FEE_AMT = " + (String)hm.get("RFND_FEE_AMT"));
		df.CommLogger("PENALTY_AMT = " + (String)hm.get("PENALTY_AMT"));
		
		df.CommLogger("SAM_TP = " + (String)hm.get("SAM_TP"));
		df.CommLogger("CHRG_ABLE_YN = " + (String)hm.get("CHRG_ABLE_YN"));
		df.CommLogger("BUY_ABLE_YN = " + (String)hm.get("BUY_ABLE_YN"));
		df.CommLogger("RFND_ABLE_YN = " + (String)hm.get("RFND_ABLE_YN"));
		df.CommLogger("STOLEN_YN = " + (String)hm.get("STOLEN_YN"));
		
		df.CommLogger("RFND_MAX_AMT = " + (String)hm.get("RFND_MAX_AMT"));
		df.CommLogger("ELEC_BILL_ID = " + (String)hm.get("ELEC_BILL_ID"));
		df.CommLogger("CHRG_MAX_AMT = " + (String)hm.get("CHRG_MAX_AMT"));
		df.CommLogger("ONCE_CHRG_MAX_AMT = " + (String)hm.get("ONCE_CHRG_MAX_AMT"));
		
		return hm;
	}
	
	public HashMap<String, String> getParsePUBCOINFODATATMP(String recvBuf, COMMLog df) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,10,2,2};
		String strHeaders[] = {
			"DATA_TYPE",
			"SEQ_NUM",
			"RECORD_LEN",
			"PUBCO_NUM"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);
		
//		df.CommLogger("DATA_TYPE = " + (String)hm.get("DATA_TYPE"));
//		df.CommLogger("SEQ_NUM = " + (String)hm.get("SEQ_NUM"));
//		df.CommLogger("RECORD_LEN = " + (String)hm.get("RECORD_LEN"));
//		df.CommLogger("PUBCO_NUM = " + (String)hm.get("PUBCO_NUM"));
		
		return hm;
	}
	
	public HashMap<String, String> getParsePUBCOINFOHDR(String recvBuf, COMMLog df) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {1,14,8,14,10,18};
		String strHeaders[] = {
			"DATA_TYPE",
			"CRETD_YMDHMS",
			"FILE_VER",
			"APPLY_YMDHMS",
			"TOTAL_CNT",
			"RFU"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);
		
//		df.CommLogger((String)hm.get("DATA_TYPE"));
//		df.CommLogger((String)hm.get("CRETD_YMDHMS"));
//		df.CommLogger((String)hm.get("FILE_VER"));
//		df.CommLogger((String)hm.get("APPLY_YMDHMS"));
//		df.CommLogger((String)hm.get("TOTAL_CNT"));
//		df.CommLogger((String)hm.get("RFU"));
		
		return hm;
	}
	
	public HashMap<String, String> getParseCashBeePUBCOINFORsp(String recvBuf, COMMLog df) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,2,16
					  ,2,16,14,2};
		int len = 66;// nlens의 합  + 1
		String strHeaders[] = {
			"COMMAND_TP",
			"LENGTH",
			"TMNAL_ID",
			"SAM_TP",
			"EB_INTG_SAMID",
			
			"RES_CD",
			"RES_MSG",
			"RES_YMDHMS",
			"FILE_TP"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);
//		hm.put("DATA", recvBuf.substring(66));
		hm.put("DATA", new String(recvBuf.getBytes(), len, recvBuf.getBytes().length-len));	
		
//		df.CommLogger((String)hm.get("COMMAND_TP"));
//		df.CommLogger((String)hm.get("LENGTH"));
//		df.CommLogger((String)hm.get("TMNAL_ID"));
//		df.CommLogger((String)hm.get("SAM_TP"));
//		df.CommLogger((String)hm.get("EB_INTG_SAMID"));
//		df.CommLogger((String)hm.get("RES_CD"));
//		df.CommLogger((String)hm.get("RES_MSG"));
//		df.CommLogger((String)hm.get("RES_YMDHMS"));
//		df.CommLogger((String)hm.get("FILE_TP"));
//		df.CommLogger((String)hm.get("DATA"));
		
		return hm;
	}
		
	public String getResCD(String recvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3,4,4,1
					  ,1,3};
		String strHeaders[] = {
			"TLGM_LEN",
			"WORK_CD",
			"COMPANY_CD",
			"TLGM_CD",
			"DEAL_TP",
			
			"SNDRCV_FG",
			"RES_CD"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);
		
		return (String)hm.get("RES_CD");
	}
	
	public String getRecvData0640(String recvBuf, String key) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3,4,4,1
				  	  ,1,3,24,12,4};
		
		String strHeaders[] = {
			"TLGM_LEN",
			"WORK_CD",
			"COMPANY_CD",
			"TLGM_CD",
			"DEAL_TP",
				
			"SNDRCV_FG",
			"RES_CD",	
			"FILE_NAME",
			"FILE_SIZE",
			"TLGM_BYTE_NUM"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);
		
		return (String)hm.get(key);
	}
	
	public List<Integer> getRecvData0300(String recvBuf) {
		int totErrNum = 0;
		String chkStr = "";
		List<Integer> array = new ArrayList<Integer>();
		
		int len = Integer.parseInt(recvBuf.substring(0,4));
		int lossChkLen = len - 50;
		
		totErrNum = Integer.parseInt((recvBuf.substring(51, 54)).trim());
		chkStr = recvBuf.substring(54, 54 + lossChkLen);
		for( int i = 0;i < lossChkLen;i++) {
			if( array.size() == totErrNum ) break;
			if( chkStr.charAt(i) == '0') {	// 결번 Sequence Number 확인
				array.add(i);
			}
		}
		
		return array;
	}
	
	public boolean get0610WhetherNormality(String recvBuf, String strMgrCd, COMMLog df) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,3,4,4,1
					  ,1,3,24,10,3
					  ,20,16};
		boolean bRet = false;
		String strHeaders[] = {
			"TLGM_LEN",
			"WORK_CD",
			"COMPANY_CD",
			"TLGM_CD",
			"DEAL_TP",
			
			"SNDRCV_FG",
			"RES_CD",
			"FILE_NM",
			"TRANS_TIME",
			"MANAGE_INFO",
			
			"SENDER_NM",
			"SENDER_PW"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, recvBuf);

//		df.CommLogger(" >>>>>>>>>>>>>>>>>>>>>> here");
		
		if( ((String)hm.get("TLGM_CD")).equals("0610") 
				&& ((String)hm.get("MANAGE_INFO")).equals(strMgrCd) ) {
//			df.CommLogger(" >>>>>>>>>>>>>>>>>>>>>> here111111111");
			if( ((String)hm.get("RES_CD")).equals("000") ) {
//				df.CommLogger(" >>>>>>>>>>>>>>>>>>>>>> here2222222222");
				bRet = true;
			}
		}
		
		return bRet;
	}
}