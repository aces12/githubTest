package biz.cms_CashBeeSender;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class CashBeeSenderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(CashBeeSenderPollingAction.class);
	
	public int spSMSSEND(String strMsg, String strSender) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("sysinq-sql", "PR_SMSSEND"));
			sql.setString(++i, strMsg);
			sql.setString(++i, strSender);
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
	public List<Object> selSVCFILEDAILY(String stdYmd, String svcID, String cmdTp, String comCD) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SVCCRTDAILY"));
			sql.setString(++i, stdYmd);
			sql.setString(++i, svcID);
			sql.setString(++i, cmdTp);
			sql.setString(++i, comCD);
			
			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		} 
		
		return list;
	}
	
	public int updSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			//df.CommLogger("▶ SEL Error : " + e);
			//df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			rollback();	
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int delPUBCOINFODTL(String com_cd, String ver) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = 0;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "DEL_CASHBEEPUBCOINFODTL"));
			sql.setString(++i, ver);
			sql.setString(++i, com_cd);
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public List<Object> selPUBCOINFO(String com_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_CASHBEEPUBCOINFO"));
			sql.setString(++i, com_cd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	
	public List<Object> selTMNALSAMIDMST() throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_CASHBEETMNALSAMIDMST"));
			logger.info("sql : " + sql.debug());
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	
	public int insPUBCOINFODATA(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_CASHBEEPUBCOINFODATA"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("FILE_VER"));
			sql.setString(++i, (String)hm.get("PUBCO_ID"));
			sql.setString(++i, (String)hm.get("PUBCO_NM"));
			sql.setString(++i, (String)hm.get("PUBCO_KEYVER"));
			
			sql.setString(++i, (String)hm.get("PUBCO_KEY"));
			sql.setString(++i, (String)hm.get("CHRG_RATE"));
			sql.setString(++i, (String)hm.get("BUY_RATE"));
			sql.setString(++i, (String)hm.get("RFU"));
			sql.setString(++i, (String)hm.get("INFOCHG"));
			
			sql.setString(++i, (String)hm.get("RFND_FEE_AMT"));
			sql.setString(++i, (String)hm.get("PENALTY_AMT"));
			sql.setString(++i, (String)hm.get("SAM_TP"));
			sql.setString(++i, (String)hm.get("CHRG_ABLE_YN"));
			sql.setString(++i, (String)hm.get("BUY_ABLE_YN"));
			
			sql.setString(++i, (String)hm.get("RFND_ABLE_YN"));
			sql.setString(++i, (String)hm.get("STOLEN_YN"));
			sql.setString(++i, (String)hm.get("RFND_MAX_AMT"));
			sql.setString(++i, (String)hm.get("ELEC_BILL_ID"));
			sql.setString(++i, (String)hm.get("CHRG_MAX_AMT"));
			
			sql.setString(++i, (String)hm.get("ONCE_CHRG_MAX_AMT"));
			logger.info("sql : " + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insPUBCOINFOHDR(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_CASHBEEPUBCOINFOHDR"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("FILE_VER"));
			sql.setString(++i, (String)hm.get("CRETD_YMDHMS"));
			sql.setString(++i, (String)hm.get("APPLY_YMDHMS"));
			sql.setString(++i, (String)hm.get("TOTAL_CNT"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int updDSTBMSTCHGHIS(String com_cd, String chg_dt, String bizloc_org_cd, String mst_grp_cd, String reg_emp_id, String mod_emp_id) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_DSTBMSTCHGHIS"));
			sql.setString(++i, com_cd);
			sql.setString(++i, chg_dt);
			sql.setString(++i, bizloc_org_cd);
			sql.setString(++i, mst_grp_cd);
			sql.setString(++i, reg_emp_id);
			sql.setString(++i, mod_emp_id);
			
//			logger.info("sql : " + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int updCASHBEETRAN(String proc_id, String com_cd, String tmnal_id, String tran_id) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_CASHBEETRAN"));
			sql.setString(++i, proc_id);
			sql.setString(++i, com_cd);
			sql.setString(++i, tmnal_id);
			sql.setString(++i, tran_id);
			
//			logger.info(" sql : " + sql.debug());
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public List<Object> selCASHBEETRAN(String com_cd, String card_key, String double_card_key) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_CASHBEETRAN"));
			sql.setString(++i, card_key);
			sql.setString(++i, double_card_key);
			sql.setString(++i, card_key);
			sql.setString(++i, double_card_key);
			sql.setString(++i, com_cd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
}