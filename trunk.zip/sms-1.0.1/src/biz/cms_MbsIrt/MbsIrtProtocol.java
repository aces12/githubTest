/*
 * SysInfoRcvProtocol.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_MbsIrt;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;

import biz.comm.COMMBiz;


/** 
 * SysInfoRcvProtocol
 *  
 * @created  on 1.0,  11/03/17
 * @created  by oki(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */ 
public class MbsIrtProtocol {

	private static Logger logger = Logger.getLogger(MbsIrtAction.class);
	
	/***
	 * getRcvMbsIrtDATA
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	
	public int getRcvMbsIrtDATA(String rcvBuf){		
		HashMap hm = new HashMap();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};   
	
		String strHeaders[] = {      				
				"INQ_TYPE"			  // INQ Type(INQ 종별)    
			};		
		
		//////logger.info("▶ Receive Data: " + rcvBuf );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if (Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE"))){
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		return ret;
	}


	/***
	 * getParseMbsNewCustNo: Tran Data request to hm hashmap according to message layout(멤버쉽IRT 전문레이아웃에 맞춰 hm hashmap에 저장한다).
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseMbsNewCustNo(String rcvBuf){		
		HashMap hm = new HashMap();
		int nlens[]= {2};   
		String strHeaders[] = {      				                                                                        
				"INQ_TYPE"			, // INQ Type(INQ 종별)    
			};
		
		logger.info("▶ getParseMbsNewCustNo-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders,rcvBuf);
		
		return hm;
	}


	/***
	 * getParseMbsRegCust: Tran Data request to hm hashmap according to message layout(멤버쉽IRT 전문레이아웃에 맞춰 hm hashmap에 저장한다).
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 * @throws Exception 
	 */
	public HashMap getParseMbsRegCust(String rcvBuf) throws Exception {		
		HashMap hm = new HashMap();
		int nlens[]= {2,20,60,20,20,8,8};   
		String strHeaders[] = {      				                                                                        
				"INQ_TYPE"		    , // INQ Type(INQ 종별)    
				"CUST_NO"			, // Cust No.(고객번호)
				"CUST_NM"			, // Cust Name(고객명)
				"CUST_CARD_NO"		, // Cust Card No.(고객카드번호)
				"TEL_NO"			, // Tel No.(전화번호)
				"BIRTH_DAY"			, // Birthday(생년월일)
				"MARRY_DAY"			  // Marry Day(결혼기념일)
			};
		
		logger.info("▶ getParseMbsRegCust-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders,rcvBuf);
		
		//POS에서 유니코드 UTF16전송 다국어를 UTF8로 변환후 처리
		//hm.put("CUST_NM", COMMBiz.getConvertUTF16LE2UTF8( (String)hm.get("CUST_NM") ) );	

		return hm;
	}


	/***
	 * getParseMbsDropCust: Tran Data request to hm hashmap according to message layout(멤버쉽IRT 전문레이아웃에 맞춰 hm hashmap에 저장한다).
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseMbsDropCust(String rcvBuf){		
		HashMap hm = new HashMap();
		int nlens[]= {2,20,8,2};   
		String strHeaders[] = {      				                                                                        
				"INQ_TYPE"			, // INQ Type(INQ 종별)    
				"CUST_CARD_NO"		, // Cust Card No.(고객카드번호)
				"SECEDE_DT"			, // Secede Date(탈퇴일자)
				"SECEDE_REASON"		  // Secede Reason(탈퇴사유)
			};
		
		logger.info("▶ getParseMbsDropCust-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders,rcvBuf);
		
		return hm;
	}


	/***
	 * getParseMbsRegCard: Tran Data request to hm hashmap according to message layout(멤버쉽IRT 전문레이아웃에 맞춰 hm hashmap에 저장한다).
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseMbsRegCard(String rcvBuf){		
		HashMap hm = new HashMap();
		int nlens[]= {2,20,20,20,1};   
		String strHeaders[] = {      				                                                                        
				"INQ_TYPE"			, // INQ Type(INQ 종별)    
				"CUST_NO"			, // Cust No.(고객번호)
				"CUST_CARD_NO"		, // Cust Card No.(고객카드번호)
				"NEW_CUST_CARD_NO"	, // New Cust Card No.(신규카드번호)
				"PROC_FLAG"			  // Proc Flag(처리구분)
			};
		
		logger.info("▶ getParseMbsRegCard-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders,rcvBuf);
		
		return hm;
	}


	/***
	 * getParseMbsInqCust: Tran Data request to hm hashmap according to message layout(멤버쉽IRT 전문레이아웃에 맞춰 hm hashmap에 저장한다).
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 * @throws Exception 
	 */
	public HashMap getParseMbsInqCust(String rcvBuf) throws Exception{		
		HashMap hm = new HashMap();
		int nlens[]= {2,1,60,1};   
		String strHeaders[] = {      				                                                                        
				"INQ_TYPE"			, // INQ Type(INQ 종별)    
				"INQ_FLAG"			, // Inq Flag(조회구분) (0:고객번호, 1:고객카드번호, 2:고객명, 3:전화번호, 4:생일)
				"INQ_VALUE"			, // Inq Value(조회값)
				"CUST_CARD_INQ_FALG"  // Cust Card Inq Flag(고객카드조회구분) (0:1개, 1:전체)
			};
		
		logger.info("▶ getParseMbsInqCust-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders,rcvBuf);
		
		//POS에서 유니코드 UTF16전송 다국어를 UTF8로 변환후 처리
		//hm.put("INQ_VALUE", COMMBiz.getConvertUTF16LE2UTF8( (String)hm.get("INQ_VALUE") ) );	

		return hm;
	}


	/***
	 * getParseMbsInqCustInfo: Tran Data request to hm hashmap according to message layout(멤버쉽IRT 전문레이아웃에 맞춰 hm hashmap에 저장한다).
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseMbsInqCustInfo(String rcvBuf){		
		HashMap hm = new HashMap();
		int nlens[]= {2,20};   
		String strHeaders[] = {      				                                                                        
				"INQ_TYPE"			, // INQ Type(INQ 종별)    
				"CUST_CARD_NO"		  // Cust Card No.(고객카드번호)
			};
		
		logger.info("▶ getParseMbsInqCustInfo-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders,rcvBuf);
		
		return hm;
	}


	/***
	 * getParseMbsInqPoint: Tran Data request to hm hashmap according to message layout(멤버쉽IRT 전문레이아웃에 맞춰 hm hashmap에 저장한다).
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseMbsInqPoint(String rcvBuf){		
		HashMap hm = new HashMap();
		int nlens[]= {2,20};   
		String strHeaders[] = {      				                                                                        
				"INQ_TYPE"			, // INQ Type(INQ 종별)    
				"CUST_CARD_NO"		  // Cust Card No.(고객카드번호)
			};
		
		logger.info("▶ getParseMbsInqPoint-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders,rcvBuf);
		
		return hm;
	}


	/***
	 * getParseMbsInqPointUsed: Tran Data request to hm hashmap according to message layout(멤버쉽IRT 전문레이아웃에 맞춰 hm hashmap에 저장한다).
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseMbsInqPointUsed(String rcvBuf){		
		HashMap hm = new HashMap();
		int nlens[]= {2,4,20,1,10};   
		String strHeaders[] = {      				                                                                        
				"INQ_TYPE"			, // INQ Type(INQ 종별)    
				"TRAN_NO"			, // Tran No.(거래번호)
				"CUST_CARD_NO"		, // Cust Card No.(고객카드번호)
				"USE_FLAG"			, // Use Flag(사용구분)
				"USE_POINT"			  // Use Point(사용포인트)
			};
		
		logger.info("▶ getParseMbsInqPointUsed-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders,rcvBuf);
		
		return hm;
	}


};



