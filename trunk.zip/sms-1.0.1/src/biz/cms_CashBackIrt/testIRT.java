package biz.cms_CashBackIrt;

import java.net.Socket;
import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

public class testIRT {
	
	public static String getCashBackRsp95(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback으에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
//			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.GTF_FILTER)));	
//			/*neo0531====>*/df.CommLogger("getCashBack95 actSock create is success");
			//SMS->CashBack SEND 에필요한 데이터 가공 
			String tmpInq = hm.get("INQ_TYPE");
			hm.remove("INQ_TYPE");
			
			sendMsg = makeSendDataCashBack(hm, CashBackData.POSREQ95 ); //파싱한거 보낼거 만듦 칼럼추가시키는거
			
			sb = new StringBuffer(sendMsg);			
//			df.CommLogger("[sms>CashBack95] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
//			if (actSock.send(sendMsg)) {
//				df.CommLogger("[sms>CashBack95] SEND[" + sendMsg.getBytes().length + "] OK");
//			} else {
//				df.CommLogger("[sms>CashBack95] SEND[" + sendMsg.getBytes().length + "] ERROR");
//				throw new Exception("CashBack Server is no response");
//			}
			
//			recvBuf = ((String) actSock.receive());
//			/*neo0531====>*/df.CommLogger("CashBack95 actSock.receive");
			
			
			//recvBuf = "NPG01641 44444444188888888666666101010101014141414141414666666224040404040404040404040404040404040404040                                                                                                                                                                                                                                                                                                               33310101010104040404040404040404040404040404040404040                                                                                                                                                                               55555"; 
//			recvBuf = "NPG0100452444444441888888886666661010101010141414141414146666662240404040404040404040404040404040404040403331001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100133310101010104040404040404040404040404040404040404040303030303030303030303030303030888888881212121212128888888830303030303030303030303030303015151515151515112121212121260606060606060606060606060606060606060606060606060606060606000010";
			recvBuf = "NPG010173802104310220160913212535testpay01mACHV1609003100100822PL201609130099900030822                   80N4                                                                                                                                                                                                        088000004000040,000                                  testpay01m090116091321253831182016091300000000000000000000                                                                                                                     01196JQVrNeSt7Y45CTcOQBoEcWqEGiVHx/cUbevj0UGmH5MdtNwPIyYSewB1himHXNDsVOhzrOEdVs5+38+HW828WacblPeHCv6vd+T2ShCTo/wpBFZeey8TZO5xSMDr7uwu1QMO3g9Li8IP6rX7pUVh0txAeXAy5TXnkbSECoeBsAHusu0fuOX0PcxrW5wstttHLw2Nl4mzktrcDt1PdtCyMVWWk80GNZlyiSBzOT8Gobv3stHOgM3DDtTz2ZhSJvdWR58GC8DqMTekSigc6kf6pTUj/W6AoYQliFhc1GLqZcgYY5pyqXRz965Bs1r4KhjklU9GmWiQW+6J4RYaSqUq1aGC2w/KQGSeB51LM/2dLdjqRnh+QxHNnWkxt5mOr3gTcXZCwPzvd3CcO4NfClNnKAwvPFT0iydCUn3AUmEiX+X2J78GKDxtyEzDPa1NDCWxn8yPWIryMWrTYbZQ4lMNB7SNBkiiEAnw0SvlkbQTWgOWNl3BbqHiD9Vx1zxNNygj/tvNaBbPA3rh4vLS1DXuRerTMUYMxs55yJ1ole3K+sEf+wmExn40cY5uCjLvQgkZYJJiWe3cKRawwRtMLnvaxW5glFFOIHKtqzxwn6fH2A+tSqeQJgrFRSwUvy1tq9t/XuViwV7n659pw8Ujheg3u731trbUI90kEKQtXaLlvtMA/SdmvPfxgC1kLfCvYgAe+kOrNjJgYrgYlQw2cfc9NYfRXA8rXitWnVofyW7m1CpyHNTREhDMyJyjJwbJcWyV5VmI/fH4HGSEozMQZ0UCy5OGyK6kkVRsCDzENMkwdWylg9mNML9EIeAA1wCrAIog6U2qIypIfuE6oQqSZdvhDmrHwIWXmk6u1XDATJgF7k1GBbMChJkxu12+PqMyd0VJHFdezLATTYkNrFKeEL+lb9S/64MMZagl3eGyyZnNs6U+bvB0aekMLdCnXT2IyyVbYDkQKGg/dNh4Sby8AeyxkSyyxSpX8onBqIrCDGUiOWe8Aoxh48Mw1WpHvuwAPonKeJr1JQ/i32NXzYvEo2JU8eBZFWaak2ddNckpl8lBfGkZ7YDJ/YQfCACFAtupEdQgoaYJltZLm81T97Pv9StJ0+muBfgHrdVVe2qXj2lVqG54xWBbLed6VV4JJHZmaBFhsiJlhpka4lMGDCNIovPpdnkn7RflT2FnSZS/hsazFqk=                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ";
			String testENC = "1234567890"; recvBuf = recvBuf + rPadSpace(testENC, 5000);
			
			//테스트 리시브버퍼
			sb = null;
			sb = new StringBuffer(recvBuf);			
//			df.CommLogger("[CashBack95>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , CashBackData.POSREQ95);				//hmRecv = protocol.getParseGTFRsp(recvBuf , GTFData.RSP100);				//hmRecv = protocol.getParseSSGPointRsp(recvBuf);	
			//			/*neo0531====>*/df.CommLogger("GTF 100 hmRecv  getParseGTFRsp parse is success");
		}catch(Exception e) {
//			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
//			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, CashBackData.POSRSP95);			
//			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public static String getCashBackRsp96(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback으에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			String tmpInq = hm.get("INQ_TYPE");
			hm.remove("INQ_TYPE");			
			sendMsg = makeSendDataCashBack(hm, CashBackData.POSREQ96 );		
			sb = new StringBuffer(sendMsg);			
			recvBuf = "NPG010045244444444188888888666666101010101014141414141414666666224040404040404040404040404040404040404040333100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100110010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010013336666664040404040404040404040404040404040404040101010101088888888101010101000010";
			String testENC = "1234567890"; recvBuf = recvBuf + rPadSpace(testENC, 5000);
			sb = null;
			sb = new StringBuffer(recvBuf);					
			hmRecv = protocol.getParseCashBackRsp(recvBuf , CashBackData.POSREQ96);				//hmRecv = protocol.getParseGTFRsp(recvBuf , GTFData.RSP100);				//hmRecv = protocol.getParseSSGPointRsp(recvBuf);	
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, CashBackData.POSRSP96);			
		}
		return dataMsg;
	}
	
	public static String getCashBackRsp97(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback으에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			String tmpInq = hm.get("INQ_TYPE");
			hm.remove("INQ_TYPE");
			
			sendMsg = makeSendDataCashBack(hm, CashBackData.POSREQ97 );
			
			sb = new StringBuffer(sendMsg);			
			
			recvBuf = "NPG01004524444444418888888866666610101010101414141414141466666622404040404040404040404040404040404040404033310010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010012002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002002033310101010108888888800010";
			String testENC = "1234567890"; recvBuf = recvBuf + rPadSpace(testENC, 5000);

			sb = null;
			sb = new StringBuffer(recvBuf);			
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , CashBackData.POSREQ97);				//hmRecv = protocol.getParseGTFRsp(recvBuf , GTFData.RSP100);				//hmRecv = protocol.getParseSSGPointRsp(recvBuf);	
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, CashBackData.POSRSP97);			
		}
		
		return dataMsg;
	}
	
	public static String getCashBackRsp98(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback으에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			String tmpInq = hm.get("INQ_TYPE");
			hm.remove("INQ_TYPE");
			
			sendMsg = makeSendDataCashBack(hm, CashBackData.POSREQ98 );
			
			sb = new StringBuffer(sendMsg);			

			recvBuf = "NPG0100452444444441888888886666661010101010141414141414146666662240404040404040404040404040404040404040403331001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100133300010";
			String testENC = "1234567890"; recvBuf = recvBuf + rPadSpace(testENC, 5000);
			
			sb = null;
			sb = new StringBuffer(recvBuf);			
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , CashBackData.POSREQ98);				//hmRecv = protocol.getParseGTFRsp(recvBuf , GTFData.RSP100);				//hmRecv = protocol.getParseSSGPointRsp(recvBuf);	
		}catch(Exception e) {
			ret = "29";
			throw e;
		}finally {
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, CashBackData.POSRSP98);			
		}
		
		return dataMsg;
	}
	
	
	
	
	
	
	public static String rPadSpace(String str, int num) {
		return String.format("%1$-" + num + "s", str).replace(' ', '0');
	}
	private static String makeSendDataCashBack(HashMap<String, String> hm, int jobType) {
		StringBuffer sb = new StringBuffer();				
		
		//Append field 
		switch(jobType){
			case CashBackData.POSREQ95:{//계좌출금 
				hm.put("VERSION", "NPG01");//NPG01고정
				hm.put("LENGTH",  "5641" ); //Integer.toString(641+ Integer.parseInt(hm.get("ENC_DATA_LENGTH"))) 
				hm.put("RESP_CODE", "333");
				hm.put("RESP_MSG", "1001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001");
				hm.put("FILLER", "1001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001");
				hm.put("TRANS_ID", "303030303030303030303030303030"); //수정 TRAN_ID -> TRANS_ID
				hm.put("ADMIT_DATE", "88888888"); //수정
				hm.put("ADMIT_NO", "121212121212");
				hm.put("COM_AMT", "88888888");//수정
				hm.put("CUS_NM", "303030303030303030303030303030");
				hm.put("CUS_AUTH_NO", "151515151515151");
				hm.put("CUS_TEL", "121212121212");
				hm.put("CUS_EMAIL", "603030303030303030303030303030303030303030303030303030303060");
				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));
				for (int i = 0; i < CashBackData.nlensSms95().length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersSms95[i].toString()), CashBackData.nlensSms95()[i]);
				}	
				break;
			}
			case CashBackData.POSREQ96:{//계좌 출금 취소 
				hm.put("VERSION", "NPG01");//NPG01고정
				hm.put("LENGTH",  "5490" ); //Integer.toString(641+ Integer.parseInt(hm.get("ENC_DATA_LENGTH"))) 
				hm.put("RESP_CODE", "   ");
				hm.put("RESP_MSG", "                                                                                                    ");
				hm.put("FILLER", "                                                                                                                                                                                                        ");
				hm.put("CANCLE_DATE", "                              "); //"CANCLE_DATE로 수정"
				hm.put("CANCLE_AMT", "        ");				
				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));
				
				for (int i = 0; i < CashBackData.nlensSms96().length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersSms96[i].toString()), CashBackData.nlensSms96()[i]);
				}	
				break;
			}			
			case CashBackData.POSREQ97:{
				hm.put("VERSION", "NPG01");//NPG01고정
				hm.put("LENGTH",  "5434" ); //Integer.toString(641+ Integer.parseInt(hm.get("ENC_DATA_LENGTH"))) 
				hm.put("RESP_CODE", "   ");
				hm.put("RESP_MSG", "                                                                                                    ");
				hm.put("FILLER", "                                                                                                                                                                                                        ");								
				hm.put("COM_AMT", "        ");//수정확인
				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));
				
				for (int i = 0; i < CashBackData.nlensSms97().length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersSms97[i].toString()), CashBackData.nlensSms97()[i]);
				}	
				break;
			}
			case CashBackData.POSREQ98:{
				hm.put("VERSION", "NPG01");//NPG01고정
				hm.put("LENGTH",  "5416" ); //Integer.toString(641+ Integer.parseInt(hm.get("ENC_DATA_LENGTH"))) 
				hm.put("RESP_CODE", "   ");
				hm.put("RESP_MSG", "                                                                                                    ");
				hm.put("FILLER", "                                                                                                                                                                                                        ");				
				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));
				
				for (int i = 0; i < CashBackData.nlensSms98().length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersSms98[i].toString()), CashBackData.nlensSms98()[i]);
				}	
				break;
			}			
		}		
		return sb.toString();
}

	private static String makeSendDataToPosRsp(HashMap<String, String> hm, int rspType) {
		StringBuffer sb = new StringBuffer();								
		switch(rspType){
		case CashBackData.POSRSP95:{
			for (int i = 0; i < CashBackData.nlensPosRsp95.length; i++) {
				StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersPosRsp95[i].toString()), CashBackData.nlensPosRsp95[i]);
			}	
			break;
			}
		case CashBackData.POSRSP96:{			
			for (int i = 0; i < CashBackData.nlensPosRsp96.length; i++) {
				StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersPosRsp96[i].toString()), CashBackData.nlensPosRsp96[i]);
			}				
			break;
			}
		case CashBackData.POSRSP97:{				
			for (int i = 0; i < CashBackData.nlensPosRsp97.length; i++) {
				StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersPosRsp97[i].toString()), CashBackData.nlensPosRsp97[i]);
			}							
			break;
		}
		case CashBackData.POSRSP98:{				
			for (int i = 0; i < CashBackData.nlensPosRsp98.length; i++) {
				StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersPosRsp98[i].toString()), CashBackData.nlensPosRsp98[i]);
			}							
			break;
		}
		
		default :{
				//do nothing
			}
		}			
		return sb.toString();
	}
	
	/////////////////////////////////////////////////메인시작/////////////////////////////////////////////////////////////////////////////
	public static void main(String[] args) throws Exception{
		
		String sendMsg = "";
		String dataMsg = "";
		
		int inq_type = 0;	
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		String totalRcvBuf = "";
		String rcvDataBuf = "";
		
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		StringBuffer sb = null;
		
		CashBackIrtConveyer CashBackConveyer = null;
		CashBackIrtDAO dao = new CashBackIrtDAO();

		//테스트용
		String header = "00031506555554444444488888888888888886666663334444";
//		totalRcvBuf = "00031506555554444444488888888888888886666663334444954444444418888888866666610101010101414141414141466666622404040404040404040404040404040404040404010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010033310101010104040404040404040404040404040404040404040000101234567890";
//		rcvDataBuf = "9544444444188888888666666101010101014141414141414666666224040404040404040404040404040404040404040100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100133310101010104040404040404040404040404040404040404040000101234567890";
		//95
//		rcvDataBuf = "9654004320188888888666666101010101014141414141414006666224040404040404040404040404040404040404040100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100100133366666640404040404040404040404040404040404040401010101010000101234567890";
		//96
//		rcvDataBuf = "970200721018888888866666610101010101414141414141466666622404040404040404040404040404040404040404010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010010013331010101010000101234567890";
		//97
//		rcvDataBuf = "98020021901888888886666661010101010141414141414140066662240404040404040404040404040404040404040401001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001333000101234567890";
		//98
//		rcvDataBuf = "990099925"; totalRcvBuf = "00000906009990005361320161017201610170857140001002";
		//99
		rcvDataBuf = "A11313131313131201610120099900031923"; totalRcvBuf = "00003606009990005361320161017201610170857140001002"; //00000006009990003204620161018201610181532590001002
		//91 헤더제외 163
//		rcvDataBuf = "9502004310120160913185325testpay01mACHV1609003100100800PL201609130099900030800                                                                                                                       088000003000030,000원                                01088JQVrNeSt7Y45CTcOQBoEcbRqLy8m87qnulyR3SC85JYQKq08afOBGavFokkhg6+cGKMHgztkFXpDKEtAHUYplfSvKT/PdMaM00p1FFP0sMOPhEn6MymP1+zmSmzIPVWbcx7qAvQ7Ju9tldzKq5kBfod9imFq9gWvchWc8jfo/QvFuY1QSJQEZrLRVx6O9izins+ysykTyykcGhzbslx5gfW6FUSLXe8xB4unzfQVnvL8foB2dVP9s2pdrmCDQaFTuBjNiCEil/fJyeULbpMim0/gmbHxKz4WbIKevFrul3j/isIhT1o7PYNlFeWDn3+ADW/1YwAlfclhh3FeoHRjfI3Gfzdzj6o8BTA8/hkguJm075HTjJtM++/XiDsGb49TcsTXe43aUqaGWUxU3ulkr3F3B/TWU1XLf/g7ryn/eIS6VhQZKHSs5Xm2qKt6iPC5plAGgbXWp//1/qf7lButp32NO1+mb2WndGu29smkOsAkiTr0+Ca3J6TFzDw3QH31fwq6FF3oqBdxogzE1dluFKZSdVqidkrzXmtudbDSyrLvSonAcaxXi8YKUITY6nz4U3+89PsSRK58SS7PpGnDN2ehGMTUHFFJrLOLy5jdQ8Oh23qlDwmCesB1CBKdHscfI4+8b8cC52COMSaFUMxxaUNBQk1ZupdKwG/OKP3AemhyMJOyiIZCVeHt9zAg0Vt5Qr/92QVc4jOBWCcNi7Tu7sCEvWsclAX4eF4I9ybiku1WjatiQYPGJ80J0rAtGH5hoaN2+2uG5Bt6ZKlGQWS+9/dV33f43KyLMaVnjSXvDpihhEnXUDnhWDAnQZwmWdeyy+CgXuzWzZEJx4NB10SC7maRyH8Htc9zJ6LbuuHXEmsjgkFp9E8wFIThZu6WeUkXBaxRmM0btPH8eCRQ99suSmUqk48oTqCvPUM7u1yozpaTLE/hCbvZcy09ZVKFqS/EpSzYXCdPsCPKi85WY7LWfuIB8Rs42lbCt74VxqTUJ0kFVCg77SqIb8GxivjWUMJfz7oqM4+1Jfr0r78UVf38GDr/aETn0nHlxdDc4k+K9rXcou5sgJV3RcjBR7b+k6n4                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ";
//		byte[] b = rcvDataBuf.getBytes("euc-kr");
//		rcvDataBuf = new String(b);
//		totalRcvBuf = "005255060099900030800201609132016091318532500010029502004310120160913185325testpay01mACHV1609003100100800PL201609130099900030800                                                                                                                       088000003000030,000원                                01088JQVrNeSt7Y45CTcOQBoEcbRqLy8m87qnulyR3SC85JYQKq08afOBGavFokkhg6+cGKMHgztkFXpDKEtAHUYplfSvKT/PdMaM00p1FFP0sMOPhEn6MymP1+zmSmzIPVWbcx7qAvQ7Ju9tldzKq5kBfod9imFq9gWvchWc8jfo/QvFuY1QSJQEZrLRVx6O9izins+ysykTyykcGhzbslx5gfW6FUSLXe8xB4unzfQVnvL8foB2dVP9s2pdrmCDQaFTuBjNiCEil/fJyeULbpMim0/gmbHxKz4WbIKevFrul3j/isIhT1o7PYNlFeWDn3+ADW/1YwAlfclhh3FeoHRjfI3Gfzdzj6o8BTA8/hkguJm075HTjJtM++/XiDsGb49TcsTXe43aUqaGWUxU3ulkr3F3B/TWU1XLf/g7ryn/eIS6VhQZKHSs5Xm2qKt6iPC5plAGgbXWp//1/qf7lButp32NO1+mb2WndGu29smkOsAkiTr0+Ca3J6TFzDw3QH31fwq6FF3oqBdxogzE1dluFKZSdVqidkrzXmtudbDSyrLvSonAcaxXi8YKUITY6nz4U3+89PsSRK58SS7PpGnDN2ehGMTUHFFJrLOLy5jdQ8Oh23qlDwmCesB1CBKdHscfI4+8b8cC52COMSaFUMxxaUNBQk1ZupdKwG/OKP3AemhyMJOyiIZCVeHt9zAg0Vt5Qr/92QVc4jOBWCcNi7Tu7sCEvWsclAX4eF4I9ybiku1WjatiQYPGJ80J0rAtGH5hoaN2+2uG5Bt6ZKlGQWS+9/dV33f43KyLMaVnjSXvDpihhEnXUDnhWDAnQZwmWdeyy+CgXuzWzZEJx4NB10SC7maRyH8Htc9zJ6LbuuHXEmsjgkFp9E8wFIThZu6WeUkXBaxRmM0btPH8eCRQ99suSmUqk48oTqCvPUM7u1yozpaTLE/hCbvZcy09ZVKFqS/EpSzYXCdPsCPKi85WY7LWfuIB8Rs42lbCt74VxqTUJ0kFVCg77SqIb8GxivjWUMJfz7oqM4+1Jfr0r78UVf38GDr/aETn0nHlxdDc4k+K9rXcou5sgJV3RcjBR7b+k6n4                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ";
		
		//테스트용코드============================================================
//		String testStr = "123우567890    ";
//		byte[] testB = testStr.getBytes("euc-kr");
//		String testRe = new String(testB, 6, 1);
//		String testRe2 = new String(testB);
//		System.out.println(testRe);
//		testRe = testStr.substring(6, 7);
//		System.out.println(testRe);
//		testRe = testRe2.substring(6, 7);
//		System.out.println(testRe);
//		System.out.println(testStr.trim());
		
		String path          = "C:\\CMBO\\workspace\\sms-1.0.1\\xml\\daemon-config.xml";
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml", path);
		
		try {
			
//		hmCommon = COMMBiz.getData(totalRcvBuf, COMMBiz.CM_HEADER);
//			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
//				return;
//			}	
			//임의 MSG_LEN(315)=헤더(50)+출금요청 기본(255)+가변(임의10)
			//가변길이 구할때 MSG_LEN사용 95: 255, 96: 261, 97: 215, 98: 205
			//한도조회 가변 없음 99: 9
			//각각 315, 321, 275, 265, 059
//			hmCommon.put("MSG_LEN", "005255"); //case 마다 수정중
			hmCommon.put("MSG_LEN", "000009"); //case 마다 수정중
			hmCommon.put("MSG_TYPE", "06");
			hmCommon.put("STORE_CD", "00999");
			hmCommon.put("POS_NO", "4444");
			hmCommon.put("TRAN_NO", "4444");
			hmCommon.put("TRAN_YMD", "666666");
			hmCommon.put("SYS_YMD", "666666");
			hmCommon.put("SYS_HMS", "666666");
			hmCommon.put("ERR_CD", "333");
			hmCommon.put("COM_CD", "1002");
		
		inq_type = protocol.getCashBackIrtInq(rcvDataBuf);
		
		switch(inq_type) {//95: 캐시백출금요청 ,96 캐시백출금취소, 97 캐시백 수수료조회, 98 캐시백 키교환  
			case CashBackData.POSREQ95:{//95: 캐시백출금요청
//				df.execute("cashback withdraw request");	
				
//				b = totalRcvBuf.getBytes("euc-kr");
//				CashBackData.VariousEncryptedData = COMMBiz.toInteger(new String(b, 300, 305).trim(), 99);
//				CashBackData.VariousEncryptedData = Integer.parseInt(totalRcvBuf.substring(300, 305).trim());
//				CashBackData.VariousEncryptedData = 10;
				
				hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ95);	//IRT에서 받은거 파싱	
				System.out.println("hmData PLU_NM :" + hmData.get("PLU_NM"));
				System.out.println("hmData ENC_DATA_LENGTH :" + hmData.get("ENC_DATA_LENGTH"));
				
				sb = null;
				sb = new StringBuffer(totalRcvBuf);					
//				df.CommLogger("POSREQ95[pos>sms] RECV[" + totalRcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");
				
//				extClntSock = new Socket(smartcon_server_ip, smartcon_server_port);
//				CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
				
				dataMsg = getCashBackRsp95(hmCommon, hmData );  //********칼럼+전송, 소켓으로 응답받
									
//				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;				
			}
			case CashBackData.POSREQ96:{//96: 계좌출금조회
////				df.execute("cashback withdraw search");	
//				
				CashBackData.VariousEncryptedData = 
						protocol.getCashBackIrtVariousEncryptedDataLength(hmCommon,CashBackData.POSREQ96);
//				
				hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ96);					
				sb = null;
				sb = new StringBuffer(totalRcvBuf);					
////				df.CommLogger("POSREQ96[pos>sms] RECV[" + totalRcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");
				
////				extClntSock = new Socket(smartcon_server_ip, smartcon_server_port);
////				CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
				
				dataMsg = getCashBackRsp96(hmCommon, hmData );//
									
////				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;				
			}
			case CashBackData.POSREQ97:{//97: 수수료 조회
////				df.execute("cashback FEE search");	
//				
				CashBackData.VariousEncryptedData = 
						protocol.getCashBackIrtVariousEncryptedDataLength(hmCommon,CashBackData.POSREQ97);
				
				hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ97);					
				sb = null;
				sb = new StringBuffer(totalRcvBuf);					
////				df.CommLogger("POSREQ97[pos>sms] RECV[" + totalRcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");
//				
////				extClntSock = new Socket(smartcon_server_ip, smartcon_server_port);
////				CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
//				
				dataMsg = getCashBackRsp97(hmCommon, hmData ); //CashBackConveyer.
									
////				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;				
			}	
			case CashBackData.POSREQ98:{//98:키교환
////				df.execute("cashback key transfer");	
				
				CashBackData.VariousEncryptedData = 
						protocol.getCashBackIrtVariousEncryptedDataLength(hmCommon,CashBackData.POSREQ98);
				
				hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ98);					
				sb = null;
				sb = new StringBuffer(totalRcvBuf);					
////				df.CommLogger("POSREQ98[pos>sms] RECV[" + totalRcvBuf.getBytes().length + "]:[INQ_TYPE:" + inq_type + "]:[" + sb.toString() + "]");
				
////				extClntSock = new Socket(smartcon_server_ip, smartcon_server_port);
////				CashBackConveyer = new CashBackIrtConveyer(extClntSock, df);										
				
				dataMsg = getCashBackRsp98(hmCommon, hmData );
									
////				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;				
			}
			case CashBackData.POSREQ99:{//99: 점포별 한도 금액 조회 
//				df.execute("store limit Amt search");	
									
				hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ99);
				COMMLog df = new COMMLog();
				dataMsg = dao.getLimitBalance(hmCommon, hmData, df);//점포별 한도조회
									
//				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;				
			}
			case CashBackData.POSREQ91:{// "A1" > 91: 사후출금 조회
												
				hmData = protocol.getParseCashbackPosReq(rcvDataBuf,CashBackData.POSREQ91);					
				COMMLog df = new COMMLog();
				dataMsg = dao.getAfterFlag(hmCommon, hmData, df);//점포별 한도조회 
//				dataMsg = dataMsg.substring(2);
																		
				break;				
			}
			
			default:
//				df.CommLogger("▶ INQ Code(INQ 종별 코드):   [" + inq_type + "]" + totalRcvBuf.length());
//				ret = 99;
				break;
			}
		}
		catch(Exception e) 
		{
//		ret = 29; // 029=HOST APPL ERR
//		retValue = "[ERROR]2:" + e.getMessage();
//		logger.error("=====▶ " + retValue);
//		df.CommLogger("▶ " + retValue);
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			int ret = 0;
			hmCommon.put("COM_CD", "0000"); //밑 행 makeSendData메서드 요구하는 com_cd 헤더에 없음, 임의 추가  
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			
			System.out.println("sendMsg : " + sendMsg);
			System.out.println("dataMsg : " + dataMsg);
			System.out.println("totalMsg : " + totalMsg);
					
//			df.CommLogger("================ 4-2) POS<-SMS 응답전문 ===================");
//			df.CommLogger("전문길이=[" + totalMsg.getBytes().length + "]");
//			df.CommLogger("INQ_TYPE=[" + dataMsg.substring(0, 2) + "]");
//			df.CommLogger("전문내용=[" + totalMsg + "]");
			
			// Send Response Data (응답 데이타 전송)
//			if (actionSocket.send(totalMsg)) 
//			{
//				df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] OK");
//			} 
//			else 
//			{
//				df.CommLogger("[pos<sms] SEND[" + totalMsg.getBytes().length + "] ERROR");
//			}
		}
		catch (Exception e) 
		{
//			retValue = "[ERROR]4" + e.getMessage();
//			df.CommLogger("▶ " + retValue);
		}
		finally 
		{
			// IRT Work Finish Log(IRT 업무 종료 로그)
//			df.close("GTFIRT", retValue);
//			
//			if (!extClntSock.isClosed()) 
//			{
//				extClntSock.close();
//			}
		}
	}
	

}
