package biz.cms_CashBackIrt;

import java.util.HashMap;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class CashBackIrtProtocol {
	
	private static Logger logger = Logger.getLogger(CashBackIrtAction.class);
	

	public static int toInteger(String value, int errRet){
		int ret=0;
		
		try {			
			ret = Integer.parseInt(value);
		} catch (NumberFormatException e ){
			ret = errRet;
		}
		
		return ret;		
	}
	
	public int getCashBackIrtVariousEncryptedDataLength(HashMap hm, int type){		
		int ret = toInteger((String)hm.get("MSG_LEN"), 99);	
		
		if (ret != 99) {
			switch (type){
				case CashBackData.POSREQ95:{//출금요청
					ret = ret  - CashBackData.POSREQ95FIX; //-255// irt 고정부길이  
					return ret;
				}
				case CashBackData.POSRSP95:{//출금응답
					ret = ret  - CashBackData.COMHEADER - CashBackData.POSRSP95FIX; //-50-369//통신 헤더,  irt 고정부길이  
					return ret;
				}
				
				case CashBackData.POSREQ96:{//출금 취소 요청 POSREQ96FIX
					ret = ret  - CashBackData.POSREQ96FIX; //-261; //irt 고정부길이  
					return ret;
				}
				case CashBackData.POSRSP96:{//출금 취소 응답
					ret = ret - CashBackData.COMHEADER - CashBackData.POSRSP96FIX; //-50 -251; //통신 헤더,  irt 고정부길이  
					return ret;
				}
				
				case CashBackData.POSREQ97:{//수수료 조회 요청
					ret = ret  - CashBackData.POSREQ97FIX; //-215; //irt 고정부길이  
					return ret;
				}
				case CashBackData.POSRSP97:{//수수료 조회 응답
					ret = ret - CashBackData.COMHEADER - CashBackData.POSRSP97FIX; //-50 -249; //통신 헤더,  irt 고정부길이  
					return ret;
				}
				
				case CashBackData.POSREQ98:{//키교환 요청
					ret = ret  - CashBackData.POSREQ98FIX; //-205; //irt 고정부길이  
					return ret; 
				}
				case CashBackData.POSRSP98:{//키교환 응답 
					ret = ret - CashBackData.COMHEADER - CashBackData.POSRSP98FIX; //-50 -233; //통신 헤더,  irt 고정부길이  
					return ret;
				}
			}
		}				
		return ret;
	}
	
	/***
	 * getGTFIrtInq
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	
	public int getCashBackIrtInq(String rcvBuf){		
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};
	
		String strHeaders[] = {"INQ_TYPE"  };			  // INQ Type(INQ 종별)    //95: 캐시백출금요청 ,96 캐시백출금취소, 97 캐시백 수수료조회, 98 캐시백 키교환 
							
		//////logger.info("▶ Receive Data: " + rcvBuf );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		if(hm.get("INQ_TYPE").equals("A1")){hm.put("INQ_TYPE", "91");} //사후출금 조회 A1

		if (Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE"))){
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}else{ // hashCode of "C3" is 2128
			logger.info("neo0531 (String)hm.get(INQ_TYPE)=>"+(String)hm.get("INQ_TYPE"));
			ret  = COMMBiz.getInqTypeCHG((String)hm.get("INQ_TYPE"));
			logger.info("neo0531 COMMBiz.getInqTypeCHG =>"+ret);
		}
		
		
		return ret;
	}
		
	public int getCashBackIrtJobCd(String rcvBuf){		
		int ret=0;	
		ret = Integer.parseInt(rcvBuf.substring(20, 24));
	
		logger.info("neo0531 getCashBackIrtJobCd=>"+ret);
		return ret;
	}
	
	
	public int getCashBackIrtLen(String rcvBuf){		
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};
	
		String strHeaders[] = {"INQ_TYPE"  };			  // INQ Type(INQ 종별)    
							
		//////logger.info("▶ Receive Data: " + rcvBuf );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if (Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE"))){
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		return ret;
	}
	 
	 
	/***
	 * getRcvGTAIrtDATA
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	
	public int getRcvGTAIrtDATA(String rcvBuf){		
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {5 , 2, 10, 3};
	
		String strHeaders[] = {      				
				"LENGTH", // 전문 길이
				"EDI", // 업무 구분
				"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))
				"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)  
			};		
		
		//////logger.info("▶ Receive Data: " + rcvBuf );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if (Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE"))){
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		return ret;
	}

	

	
//	@SuppressWarnings("unchecked")
//	public HashMap<String, String> getParseGTFRsp(String rcvBuf ){ 
//		HashMap<String, String> hm = new HashMap<String, String>();
//
//		hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensGTF, CashBackData.strHeadersGTF, rcvBuf );//hm = GTFData.getParseDataGTFMultibyte(GTFData.nlens100, GTFData.strHeaders100, rcvBuf , GTFData.nlensG100, GTFData.strHeadersG100);
//		
//		return hm;
//	}	
	
	public static String rPadSpace(String str, int num) {
		return String.format("%1$-" + num + "s", str).replace(' ', ' ');
	}
	
	@SuppressWarnings("unchecked")
	public HashMap<String, String> getParseCashBackRsp(String rcvBuf , int jobType){ 
		HashMap<String, String> hm = new HashMap<String, String>();			
//		String len = rcvBuf.substring(5, 10);
//		int length = Integer.parseInt(len);
		
//		CashBackData.VariousEncryptedData = 
//			Integer.parseInt(hm.get("ENC_DATA_LENGTH"));	
		System.out.println(rcvBuf);
		
//		hm.put("ATM_CHARGE_AMT", " ");
//		hm.put("AMT", " ");
//		hm.put("CASHBAG_TRAN_YN", " ");
//		hm.put("CASHBAG_TRAN_AMT", " ");
		switch(jobType){				
			//neo0531 cash back 공동망 
			case 3100:{//환불수취조회 				
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensSms3100(), CashBackData.strHeadersSms3100, rcvBuf );
				logger.info("neo0531 3100 getParseDataMultibyte is over ");
				hm.put("ATM_CHARGE_AMT", "");
				hm.put("AMT", "");
				hm.put("INQ_TYPE", "C3");
				hm.put("ADMIT_DATE", (String)hm.get("POS_TRAN_YMD"));				
			    hm.put("ADMIT_TIME", (String)hm.get("POS_TRAN_TIME"));
			    
				/* 확인차 주석 처리함
				hm.put("EVT_AMT", "        ");				hm.remove("VERSION");				hm.remove("DATA_SIZE");				hm.remove("MID");				
				hm.remove("TERMINAL_ID");				hm.remove("TERMINAL_SEQ");				hm.remove("ENC_YN");				hm.remove("MCH_ORDER_NO");				
				hm.remove("ISS_BANK_CD");				hm.remove("BUY_BANK_CD");				hm.remove("VAN_TYPE_CD");				hm.remove("PAY_AMT");
				hm.remove("ENC_INFO");				hm.remove("TRACK_INFO");				hm.remove("IC_CARD_SEQ");				hm.remove("MEMB_NO");
				hm.remove("TEL_NO");				hm.remove("MEMB_NM");				hm.remove("REPR_NM");				hm.remove("BIZCO_NO");
				hm.remove("MEMB_ADDR");				hm.remove("ORG_TRAN_YMD");				hm.remove("ORG_MCH_SEND_UNIQ_NO");				hm.remove("BUY_MCH_SEND_UNIQ_NO");
				hm.remove("CARD_INFO_YN");				hm.remove("FILLER");	
				*/			
				return hm;
			}	
			
			case 4000:{//구매 
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensSms4000(), CashBackData.strHeadersSms4000, rcvBuf );
				logger.info("neo0531 4000 getParseDataMultibyte is over ");
				hm.put("ATM_CHARGE_AMT", "");
				hm.put("AMT", "");
				
				hm.put("INQ_TYPE", "C3");
				
				logger.info("neo0531 POS_TRAN_YMD=>"+ (String)hm.get("POS_TRAN_YMD"));
			    hm.put("ADMIT_DATE", (String)hm.get("POS_TRAN_YMD"));			
			    logger.info("neo0531 POS_TRAN_YMD=>"+ (String)hm.get("POS_TRAN_TIME"));
			    hm.put("ADMIT_TIME", (String)hm.get("POS_TRAN_TIME"));			
				return hm;
				
			}	
			case 4100:{//구매 환불 
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensSms4100(), CashBackData.strHeadersSms4100, rcvBuf );
				logger.info("neo0531 4100 getParseDataMultibyte is over ");
				hm.put("ATM_CHARGE_AMT", "");
				hm.put("AMT", "");

				hm.put("INQ_TYPE", "C3");
				hm.put("ADMIT_DATE", (String)hm.get("POS_TRAN_YMD"));		
			    hm.put("ADMIT_TIME", (String)hm.get("POS_TRAN_TIME"));
				return hm;
				
			}	
			case 4200:{//인출 
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensSms4200(), CashBackData.strHeadersSms4200, rcvBuf );
				logger.info("neo0531 4200 getParseDataMultibyte is over ");
				hm.put("AMT", "");
				
				hm.put("SERVICE_AMT", "");
				hm.put("VAT_AMT", "");
//				hm.put("MCH_CHARGE_AMT", "");
//				hm.put("ISSINS_CHARGE_AMT", "");
//				hm.put("BUYINS_CHARGE_AMT", "");
//				hm.put("VAN_CHARGE_AMT", "");
				
				hm.put("CASHBAG_TRAN_YN", " ");
				hm.put("CASHBAG_TRAN_AMT", " ");
				hm.put("INQ_TYPE", "C3");
				hm.put("ADMIT_DATE", (String)hm.get("POS_TRAN_YMD"));
			    hm.put("ADMIT_TIME", (String)hm.get("POS_TRAN_TIME"));
				return hm;
				
			}	
			case 6100:{//인출 			
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensSms6100(), CashBackData.strHeadersSms6100, rcvBuf );
				logger.info("neo0531 6100 getParseDataMultibyte is over ");
				hm.put("ATM_CHARGE_AMT", "");
				hm.put("AMT", "");
				hm.put("INQ_TYPE", "C3");	
				hm.put("ADMIT_DATE", (String)hm.get("POS_TRAN_YMD"));
			    hm.put("ADMIT_TIME", (String)hm.get("POS_TRAN_TIME"));
				return hm;
				
			}
			case CashBackData.POSREQ95:{//출금 응답
				//CashBackData.VariousEncryptedData =  Integer.parseInt(rcvBuf.substring((CashBackData.COMMONHFIX + CashBackData.PGREQ95FIX - 5), (CashBackData.COMMONHFIX + CashBackData.PGREQ95FIX)));
				CashBackData.VariousEncryptedData = CashBackData.getEncLen(); 
				logger.info("VariousEncryptedData"+CashBackData.VariousEncryptedData);
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensSms95(), CashBackData.strHeadersSms95, rcvBuf );
				hm.put("INQ_TYPE", Integer.toString(CashBackData.POSREQ95));
				hm.put("EVT_AMT", "        ");
				hm.remove("VERSION");
				hm.remove("LENGTH");
				hm.remove("SECURITY_YN");
				hm.remove("BANK_CD");
				hm.remove("PLU_NM");
				hm.remove("CUS_NM");
				hm.remove("CUS_AUTH_NO");
				hm.remove("CUS_TEL");
				hm.remove("CUS_EMAIL");
//				String tmp = hm.get("MCH_SEND_UNIQ_NO");				
//				String ttmp = tmp.substring(0, 21);	
							
				hm.put("ENCRYPTED_DATA" , hm.get("ENCRYPTED_DATA").substring(0, Integer.parseInt(hm.get("ENC_DATA_LENGTH"))));
				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));	
				CashBackData.VariousEncryptedData = Integer.parseInt(hm.get("ENC_DATA_LENGTH"));
				return hm;
			}		
			
			case CashBackData.POSREQ96:{//취소 응답
				CashBackData.VariousEncryptedData = CashBackData.getEncLen(); 
				logger.info("VariousEncryptedData"+CashBackData.VariousEncryptedData);
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensSms96(), CashBackData.strHeadersSms96, rcvBuf );
				hm.put("INQ_TYPE", Integer.toString(CashBackData.POSREQ96));
				hm.remove("VERSION");
				hm.remove("LENGTH");
				hm.remove("MID");
				hm.remove("TERMINAL_ID");
				hm.remove("INQ_UNIQ_NO");
				hm.remove("SECURITY_YN");
				hm.remove("MCH_SEND_UNIQ_NO");
				hm.remove("BANK_CD");
				hm.remove("ORG_INQ_UNIQ_NO");
				hm.remove("ORG_MCH_SEND_UNIQ_NO");
				hm.remove("ORG_TRADE_AMT");

				hm.put("ENCRYPTED_DATA" , hm.get("ENCRYPTED_DATA").substring(0, Integer.parseInt(hm.get("ENC_DATA_LENGTH"))));
				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));	
				
				CashBackData.VariousEncryptedData = Integer.parseInt(hm.get("ENC_DATA_LENGTH"));
				return hm;
			}

			case CashBackData.POSREQ97:{//수수료 응답
				CashBackData.VariousEncryptedData = CashBackData.getEncLen(); 
				logger.info("VariousEncryptedData"+CashBackData.VariousEncryptedData);
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensSms97(), CashBackData.strHeadersSms97, rcvBuf );
				hm.put("INQ_TYPE", Integer.toString(CashBackData.POSREQ97));
				hm.remove("VERSION");
				hm.remove("LENGTH");
				hm.remove("MID");
				hm.remove("TERMINAL_ID");
				hm.remove("INQ_UNIQ_NO");
				hm.remove("SECURITY_YN");
				hm.remove("MCH_SEND_UNIQ_NO");
				hm.remove("BANK_CD");
				hm.remove("TRAN_AMT");
				hm.remove("PLU_NM");
				hm.remove("CUS_NM");
				hm.remove("CUS_AUTH_NO");
				hm.remove("CUS_TEL");
				hm.remove("CUS_EMAIL");
//				String tmp = hm.get("MCH_SEND_UNIQ_NO");				
//				String ttmp = tmp.substring(0, 21);	
				hm.put("ENCRYPTED_DATA" , hm.get("ENCRYPTED_DATA").substring(0, Integer.parseInt(hm.get("ENC_DATA_LENGTH"))));
				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));	
				CashBackData.VariousEncryptedData = Integer.parseInt(hm.get("ENC_DATA_LENGTH"));
				return hm;
			}
			case CashBackData.POSREQ98:{//키교환 응답
				CashBackData.VariousEncryptedData = CashBackData.getEncLen(); 
				logger.info("VariousEncryptedData"+CashBackData.VariousEncryptedData);
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensSms98(), CashBackData.strHeadersSms98, rcvBuf );
				hm.put("INQ_TYPE", Integer.toString(CashBackData.POSREQ98));
				hm.remove("VERSION");
				hm.remove("LENGTH");
				hm.remove("MID");
				hm.remove("TERMINAL_ID");
				hm.remove("INQ_UNIQ_NO");
				hm.remove("SECURITY_YN");
				hm.remove("MCH_SEND_UNIQ_NO");
				hm.remove("BANK_CD");
//				String tmp = hm.get("MCH_SEND_UNIQ_NO");				
//				String ttmp = tmp.substring(0, 21);	
				hm.put("ENCRYPTED_DATA" , hm.get("ENCRYPTED_DATA").substring(0, Integer.parseInt(hm.get("ENC_DATA_LENGTH"))));
				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));	
				CashBackData.VariousEncryptedData = Integer.parseInt(hm.get("ENC_DATA_LENGTH"));
				return hm;				
			}								
		}						
		return hm;
	}



	public HashMap<String, String> getParseCommH(String rcvBuf ){
		HashMap<String, String> hm = new HashMap<String, String>();	
		final int nlens[] = { 6,2,5,4,4,
				8,8,6,3,4				};
		

		final String strHeaders[] = { 
				"MSG_LEN",
				"MSG_TYPE",
				"STORE_CD",
				"POS_NO",
				"TRAN_NO",
				
				"TRAN_YMD",
				"SYS_YMD",
				"SYS_HMS",
				"ERR_CD",
				"COM_CD"				
				};
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);

		
		return hm;
	}	
	
	
	
	
	public HashMap<String, String> getParseCashbackPosReq(String rcvBuf , int reqType){
		HashMap<String, String> hm = new HashMap<String, String>();	
		switch(reqType){
			case CashBackData.POSREQ95:{//승인
				
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq95, CashBackData.strHeadersPosReq95, rcvBuf);
				//hm = COMMBiz.getParseData(CashBackData.nlensPosReq95, CashBackData.strHeadersPosReq95, rcvBuf);	
				break;
			}
			case CashBackData.POSREQ96:{//취소	
				
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq96, CashBackData.strHeadersPosReq96, rcvBuf);
				break;
			}
			case CashBackData.POSREQ97:{//조회
				
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq97, CashBackData.strHeadersPosReq97, rcvBuf);
				break;
			}
			case CashBackData.POSREQ98:{//키교환
				
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq98, CashBackData.strHeadersPosReq98, rcvBuf);
				break;
			}
			case CashBackData.POSREQ99:{//점포별 한도조회
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq99, CashBackData.strHeadersPosReq99, rcvBuf);	
				break;
			}
			case CashBackData.POSREQ91:{//사후출금 조회
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq91, CashBackData.strHeadersPosReq91, rcvBuf);	
				break;
			}
		}
		return hm;
	}

	public HashMap<String, String> getParseCashbackPosReq_New(String rcvBuf , int reqType){
		HashMap<String, String> hm = new HashMap<String, String>();	
		switch(reqType){
			case CashBackData.POSREQ95:{//승인
				
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq95_New, CashBackData.strHeadersPosReq95_New, rcvBuf);
				//hm = COMMBiz.getParseData(CashBackData.nlensPosReq95, CashBackData.strHeadersPosReq95, rcvBuf);	
				break;
			}
			case CashBackData.POSREQ96:{//취소	
				
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq96_New, CashBackData.strHeadersPosReq96_New, rcvBuf);
				break;
			}
			case CashBackData.POSREQ97:{//조회
				
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq97_New, CashBackData.strHeadersPosReq97_New, rcvBuf);
				break;
			}
			case CashBackData.POSREQ98:{//키교환
				
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq98_New, CashBackData.strHeadersPosReq98_New, rcvBuf);
				break;
			}
			case CashBackData.POSREQ99:{//점포별 한도조회
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq99, CashBackData.strHeadersPosReq99, rcvBuf);	
				break;
			}
			case CashBackData.POSREQ91:{//사후출금 조회
				hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReq91, CashBackData.strHeadersPosReq91, rcvBuf);	
				break;
			}
		}
		return hm;
	}
	
	public HashMap<String, String> getParseCashbackPosReq_Common(String rcvBuf ){
		HashMap<String, String> hm = new HashMap<String, String>();	

		hm = COMMBiz.getParseDataMultibyte(CashBackData.nlensPosReqComm, CashBackData.strHeadersPosReqComm, rcvBuf);
		
		return hm;
	}
	
	
	//캐쉬백 VAN 추가	lys	
	/***
	 * getGTFIrtInq
	 * @param rcvBuf
	 * @return VAN_CD
	 */	
	public int getCahBackVanCdIng(String rcvBuf) {
		// TODO Auto-generated method stub
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};
	
		String strHeaders[] = {"VAN_CD"  };			  // 21:청호	22:한네트 
							
		logger.info("=======rcvBuf : " + rcvBuf);
		logger.info("=======rcvBuf.length() : " + rcvBuf.length());
		logger.info("=======nlens.length : " + nlens.length);
		//////logger.info("▶ Receive Data: " + rcvBuf );
		hm.put(strHeaders[0].toString(), rcvBuf.substring(rcvBuf.length() - 2, rcvBuf.length()));	//데이터 전문 마지막 2 바이트가 van구분코드
		//logger.info( strHeaders[0].toString() + "==>(" + rcvBuf.length() - nlens.length +","+ rcvBuf.length() + ")" + rcvBuf.substring(bInx, eInx));	
		
		if (Pattern.matches("[0-9]+", (String)hm.get("VAN_CD"))){
			ret = Integer.parseInt((String)hm.get("VAN_CD"));
		}
		
		return ret;
	}
	
}


















	
































