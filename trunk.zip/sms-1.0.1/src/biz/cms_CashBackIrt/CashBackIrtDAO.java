package biz.cms_CashBackIrt;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;

import biz.comm.COMMLog;

public class CashBackIrtDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(CashBackIrtAction.class);
	
	public String getLimitBalance(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sqlEpt = new SqlWrapper();
		List<Object> list = null;
		List<Object> listEpt = null;
		int i = 0;
		
		String dataMsg = "";
		String ret = "00";
		String setLmtYn = "Y";
		int defLmt = 500000;
		int curLmt = 0;
		
		try {
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SEARCH_LMT_AMT_BAL"));
			sql.setString(++i, (String)hm.get("SERVICE_TP"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("STORE_CODE"));
			sql.setString(++i, (String)hm.get("SERVICE_TP"));
			
			list = executeQuery(sql);
			if( list.size() > 0 ) {
				Map<String, String> map = (Map<String, String>)list.get(0);
				String stLimAmt = (String)map.get("LMT_AMT_BAL");
				
				logger.info("[INFO] stLimAmt ["+stLimAmt+"]");
				if( "".equals(stLimAmt) || stLimAmt == null ){
					setLmtYn = "N";
				}
				
				hm.put("LMT_RAMT", (String)map.get("LMT_AMT_BAL"));
				logger.info("(String)map.get(\"LMT_AMT_BAL\")"+ (String)map.get("LMT_AMT_BAL"));
			}else {		
				setLmtYn = "N";
				//logger.info("LMT_RAMT0000");
				//hm.put("LMT_RAMT", "0000000000000000000000");
			}
			
			logger.info("[INFO] setLmtYn ["+setLmtYn+"]");
			if("N".equals(setLmtYn)){
				sql.close();
				sql.clearParameter();
				sql.put(findQuery("service-sql", "SEL_USED_AMT_BAL"));				
				sql.setString(1, (String)hmComm.get("COM_CD"));
				sql.setString(2, (String)hm.get("STORE_CODE"));				
				
				listEpt = executeQuery(sql);
				if (listEpt.size()>0){
					Map<String, String> map = (Map<String, String>)listEpt.get(0);
					curLmt = defLmt - Integer.parseInt((String)map.get("SUM_TRADE_AMT"));
					hm.put("LMT_RAMT", String.valueOf(curLmt));
				}else{
					hm.put("LMT_RAMT", String.valueOf(defLmt));
				}
			}
		}catch(SQLException e) {
			ret = "20"; df.CommLogger(sql.debug());
		}catch(Exception e) {
			ret = "29"; df.CommLogger(sql.debug());
			throw e;
		}finally {
			logger.info("1");
			dataMsg = ret + makeSendDataLimitBalanceRsp(hm, df);
			df.CommLogger("★ make: " + dataMsg);
			end();
		}
		
		return dataMsg;
	}
	
	private String makeSendDataLimitBalanceRsp(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,5,2,22};
		String strHeaders[] = {
			"INQ_TYPE",
			"STORE_CODE",
			"SERVICE_TP",
			"LMT_RAMT"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	public String getAfterFlag(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		String dataMsg = "";
		String ret = "00";
		
		try {	
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SEARCH_AFTER_FLAG_BAL"));
//			sql.setString(++i, (String)hm.get("OP_NO"));
			sql.setString(++i, (String)hm.get("TRAN_YMD"));
			sql.setString(++i, (String)hm.get("STORE_CD"));
			sql.setString(++i, (String)hm.get("POS_NO"));
			sql.setString(++i, (String)hm.get("TRAN_NO"));
			sql.setString(++i, (String)hmComm.get("STORE_CD"));
			
			list = executeQuery(sql);
			if( list.size() > 0 ) {
				Map<String, String> map = (Map<String, String>)list.get(0);
				hm.put("DRAW_AMT", (String)map.get("TRADE_AMT"));
				hm.put("ERR_CD", (String)map.get("RESP_CODE"));
				hm.put("ERR_MSG", (String)map.get("RESP_MSG"));
				hm.put("AFTER_FLAG", (String)map.get("AFTER_FLAG"));
				hm.put("INQ_UNIQ_NO", (String)map.get("INQ_UNIQ_NO"));
				
				logger.info("map.get(trade_amt) "+(String)map.get("TRADE_AMT")
							+" map.get(resp_code) "+(String)map.get("RESP_CODE")
							+" map.get(resp_msg) "+(String)map.get("RESP_MSG")
							+" map.get(after_flag) "+(String)map.get("AFTER_FLAG")
							+" map.get(INQ_UNIQ_NO) "+(String)map.get("INQ_UNIQ_NO"));
			}else {
				hm.put("DRAW_AMT", "0000000000000000000000");
				hm.put("ERR_CD", "FFFF");
				hm.put("ERR_MSG", "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
				hm.put("AFTER_FLAG", "0");
				hm.put("AFTER_FLAG", "000000");
				logger.info("SELECT LIST FAIL, ERR_CD=" + (String)hm.get("ERR_CD"));
			}
			
		}catch(SQLException e) {
			ret = "20"; df.CommLogger(sql.debug());
		}catch(Exception e) {
			ret = "29"; df.CommLogger(sql.debug());
			throw e;
		}finally {
			dataMsg = ret + makeSendDataAfterFlagRsp(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
			end();
		}
		
		return dataMsg;
	}
	
	private String makeSendDataAfterFlagRsp(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2, 13, 8, 5, 4
					 , 4, 22, 4, 100, 1
					 , 6};
		String strHeaders[] = {
			"INQ_TYPE"
			, "OP_NO"
			, "TRAN_YMD"
			, "STORE_CD"
			, "POS_NO"
			
			, "TRAN_NO"
			, "DRAW_AMT"
			, "ERR_CD"
			, "ERR_MSG"
			, "AFTER_FLAG"
			
			, "INQ_UNIQ_NO"
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String)hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
/*
 	public String getTMoneyClientInfo(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		try {
			begin();
			
			sql.put(findQuery("service-sql", "INS_TMONEYTMNALSAMIDMST"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("MEMBER_ID"));
			sql.setString(++i, (String)hm.get("TERMINAL_ID"));
			sql.setString(++i, (String)hm.get("SAM_ID"));
			
			//df.CommLogger("[SQL1][INS_TMONEYCLIENTINFO]" + sql.debug() );
			
			//DB Connection(DB 접속)
			connect("CMGNS");			
			executeUpdate(sql);
			
			
		}catch(SQLException e) { 
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();	
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();	
			throw e;
		}finally {
			dataMsg = ret + makeSendDataClientInfo(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
			end();
		}
		
		return dataMsg;
	}
	
	private String makeSendDataClientInfo(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,7,9,16};
		
		String strHeaders[] = {
			"INQ_TYPE",
			"MEMBER_ID",
			"TERMINAL_ID",
			"SAM_ID"
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	*/
}