package biz.cms_CashBackIrt;

import java.net.Socket;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;

import org.apache.log4j.Logger;

import biz.comm.AES;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;



public class CashBackIrtConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;
	private static Logger logger = Logger.getLogger(CashBackIrtAction.class);
	COMMLog df = null;
	
	public CashBackIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}
	
	
	public static String rPadSpace(String str, int num) {
		return String.format("%1$-" + num + "s", str).replace(' ', ' ');
	}
			
	
	private String makeSendDataCashBack(HashMap<String, String> hm, COMMLog df ,int jobType) throws Exception {
		StringBuffer sb = new StringBuffer();				
//		logger.info("jobType1"+ jobType);
//		int encDataLength =  Integer.parseInt(hm.get("ENC_DATA_LENGTH")); 
		AES aes = new AES();
		String tmpCardSeq = "";
		//Append field 
		switch(jobType){
			case 3100:{//구매환불 수취조회 				
				logger.info("jobType"+ jobType);
				hm.remove("INQ_TYPE");
				hm.put("DATA_SIZE", "00900");			 
				hm.put("RSP_CD", "");
				hm.put("RSP_MSG", "");
				//여기까지 공통부  이후로는 우선 일단 하드 코딩 추후 확인 필요함  
				//hm.put("MEMB_NO"  , "1234567890123");	//가맹점관리번호 13
				hm.put("TEL_NO"   , "02-6916-1500");	//가맹점 전화번호14
				hm.put("MEMB_NM"  , "emart24             ");	//가맹점명20
				//hm.put("REPR_NM"  , "김성영              ");	//대표자명20
				//hm.put("BIZCO_NO" , "1058692454");	//사업자등록번호10
				//hm.put("MEMB_ADDR", "서울특별시 성동구 성수동 2가 281-4 푸조비즈타워                                                     ");	//가맹점주소100
				//hm.put("MEMB_JOB_CD"  	, "");	//4
				hm.put("BUY_MCH_SEND_UNIQ_NO"  	, "");	//13
				
				tmpCardSeq = aes.decrypt((String)hm.get("IC_CARD_SEQ").trim());				
				hm.put("IC_CARD_SEQ",   tmpCardSeq    );    // 신용카드  일련번호
				 
				hm.put("MCH_SEND_UNIQ_NO"  	, "");	//13
				String tmpAmt = hm.get("PAY_AMT").substring(4);
				hm.put("PAY_AMT",tmpAmt);
				
				tmpAmt = hm.get("SERVICE_AMT").substring(4);
				hm.put("SERVICE_AMT"  		, tmpAmt);	//12
				
				tmpAmt = hm.get("VAT_AMT").substring(4);
				hm.put("VAT_AMT"  			, tmpAmt);	//12
				
				
				
				//int tmpInt = Integer.parseInt((String)hm.get("PAY_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//				hm.put("PAY_AMT",String.valueOf(tmpInt));
//				hm.put("SERVICE_AMT"  		, "");	//12
//				hm.put("VAT_AMT"  			, "");	//12
				hm.put("MCH_CHARGE_AMT"  	, "");	//12
				hm.put("ISSINS_CHARGE_AMT"  , "");	//12
				hm.put("BUYINS_CHARGE_AMT"  , "");	//12
				hm.put("VAN_CHARGE_AMT"  	, "");	//12
				
				hm.put("PRT_ACCOUNT_NO"  	, "");	//20
				hm.put("CASHBAG_TRAN_YN"  	, "");	//1
				hm.put("CASHBAG_TRAN_AMT"  	, "");	//12
				//hm.put("CARD_INFO_YN"  	, "");		//1
				hm.put("FILLER"  			, "");	//60
				 
	//			hm.put("MCH_SEND_UNIQ_NO"  	, "             ");	//13
	//			hm.put("SERVICE_AMT"  		, "            ");	//12
	//			hm.put("VAT_AMT"  			, "            ");	//12
	//			hm.put("MCH_CHARGE_AMT"  	, "            ");	//12
	//			hm.put("ISSINS_CHARGE_AMT"  , "            ");	//12
	//			hm.put("BUYINS_CHARGE_AMT"  , "            ");	//12
	//			hm.put("VAN_CHARGE_AMT"  	, "            ");	//12
	//			
	//			hm.put("PRT_ACCOUNT_NO"  	, "                    ");	//20
	//			hm.put("CASHBAG_TRAN_YN"  	, " ");	//1
	//			hm.put("CASHBAG_TRAN_AMT"  	, "            ");	//12
	//			hm.put("FILLER"  			, "                                                            ");	//60
				logger.info("CashBackData.nlensSms3100().length ==>"+ CashBackData.nlensSms3100().length );
				for (int i = 0; i < CashBackData.nlensSms3100().length; i++) {
					StringUtil.appendSpace(sb , (String) hm.get(CashBackData.strHeadersSms3100[i].toString()), CashBackData.nlensSms3100()[i]);					
					//logger.info("Sms3100_appendSpace["+ i + "]["+CashBackData.nlensSms3100()[i] +"]  "+ sb.toString() );
				}

				logger.info("strHeadersSms3100_appendSpace[sb]  "+ sb.toString() );
				break;
			}	
			case 4000:{//구매 				
				logger.info("jobType"+ jobType);
				hm.remove("INQ_TYPE");
				hm.put("DATA_SIZE", "00900");			 
				hm.put("RSP_CD", "");
				hm.put("RSP_MSG", "");

				//hm.put("MEMB_NO"  , "1234567890123");	//가맹점관리번호 13
				hm.put("TEL_NO"   , "02-6916-1500");	//가맹점 전화번호14
				
			
				String tmpStr = "emart24             "; 
				byte[] tmpByte = tmpStr.getBytes("KSC5601");
				String ConvertStr = new String(tmpByte);
													
				
				hm.put("MEMB_NM"  ,ConvertStr );	//가맹점명20
				//hm.put("REPR_NM"  , "김성영              ");	//대표자명20
				//hm.put("BIZCO_NO" , "1058692454");	//사업자등록번호10
				//hm.put("MEMB_ADDR", "서울특별시 성동구 성수동 2가 281-4 푸조비즈타워                                                     ");	//가맹점주소100
				//hm.put("MEMB_JOB_CD"  	, "");	//4														
				//hm.put("BUY_MCH_SEND_UNIQ_NO"  	, "             ");	//13
				
				tmpCardSeq = aes.decrypt((String)hm.get("IC_CARD_SEQ").trim());				
				hm.put("IC_CARD_SEQ",   tmpCardSeq    );    // 신용카드  일련번호

				hm.put("MCH_SEND_UNIQ_NO"  	, "");	//13
				String tmpAmt = hm.get("PAY_AMT").substring(4);
				hm.put("PAY_AMT",tmpAmt);
				
				tmpAmt = hm.get("SERVICE_AMT").substring(4);
				hm.put("SERVICE_AMT"  		, tmpAmt);	//12
				
				tmpAmt = hm.get("VAT_AMT").substring(4);
				hm.put("VAT_AMT"  			, tmpAmt);	//12
				
				
				
				//int tmpInt = Integer.parseInt((String)hm.get("PAY_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//				hm.put("PAY_AMT",String.valueOf(tmpInt));
//				hm.put("SERVICE_AMT"  		, "");	//12
//				hm.put("VAT_AMT"  			, "");	//12
				hm.put("MCH_CHARGE_AMT"  	, "");	//12
				hm.put("ISSINS_CHARGE_AMT"  , "");	//12
				hm.put("BUYINS_CHARGE_AMT"  , "");	//12
				hm.put("VAN_CHARGE_AMT"  	, "");	//12
				
				hm.put("PRT_ACCOUNT_NO"  	, "");	//20
				hm.put("CASHBAG_TRAN_YN"  	, "");	//1
				hm.put("CASHBAG_TRAN_AMT"  	, "");	//12
				//hm.put("CARD_INFO_YN"  	, "");		//1
				hm.put("FILLER"  			, "");	//95
				
				
				logger.info("CashBackData.nlensSms4000().length ==>"+ CashBackData.nlensSms4000().length );
				for (int i = 0; i < CashBackData.nlensSms4000().length; i++) {
					
//					if (CashBackData.strHeadersSms4000[i].toString() == "MEMB_NM"){
//						String tmpStr = (String) hm.get(CashBackData.strHeadersSms4000[i].toString()); 
//						byte[] tmpByte = tmpStr.getBytes("KSC5601");
//						String ConvertStr = new String(tmpByte);
//											
//						StringUtil.appendSpace(sb
//								, ConvertStr , CashBackData.nlensSms4000()[i]);
//						
//					}
//					else {
					StringUtil.appendSpace(sb
							, (String) hm.get(CashBackData.strHeadersSms4000[i].toString()), CashBackData.nlensSms4000()[i]);
//					}
					//logger.info("Sms4000_appendSpace["+ i + "]["+CashBackData.nlensSms4000()[i] +"]  "+ sb.toString() );
				}	
				logger.info("strHeadersSms4000_appendSpace[sb]  "+ sb.toString() );
				break;
			}
			
			case 4100:{//구매 환불		
				
				logger.info("jobType"+ jobType);
				hm.remove("INQ_TYPE");
				hm.put("DATA_SIZE", "00900");			 
				hm.put("RSP_CD", "");
				hm.put("RSP_MSG", "");
				
				
				//hm.put("MEMB_NO"  , "1234567890123");	//가맹점관리번호 13
				hm.put("TEL_NO"   , "02-6916-1500");	//가맹점 전화번호14
				hm.put("MEMB_NM"  , "emart24             ");	//가맹점명20
				//hm.put("REPR_NM"  , "김성영              ");	//대표자명20
				//hm.put("BIZCO_NO" , "1058692454");	//사업자등록번호10
				//hm.put("MEMB_ADDR", "서울특별시 성동구 성수동 2가 281-4 푸조비즈타워                                                     ");	//가맹점주소100
				//hm.put("MCH_JOB_CD"  	, "");	//4				
				//hm.put("BUY_MCH_SEND_UNIQ_NO"  	, "             ");	//13
				 
				tmpCardSeq = aes.decrypt((String)hm.get("IC_CARD_SEQ").trim());				
				hm.put("IC_CARD_SEQ",   tmpCardSeq    );    // 신용카드  일련번호

				hm.put("MCH_SEND_UNIQ_NO"  	, "");	//13
				String tmpAmt = hm.get("PAY_AMT").substring(4);
				hm.put("PAY_AMT",tmpAmt);
				
				tmpAmt = hm.get("SERVICE_AMT").substring(4);
				hm.put("SERVICE_AMT"  		, tmpAmt);	//12
				
				tmpAmt = hm.get("VAT_AMT").substring(4);
				hm.put("VAT_AMT"  			, tmpAmt);	//12
				
				
				
				//int tmpInt = Integer.parseInt((String)hm.get("PAY_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//				hm.put("PAY_AMT",String.valueOf(tmpInt));
//				hm.put("SERVICE_AMT"  		, "");	//12
//				hm.put("VAT_AMT"  			, "");	//12
				hm.put("MCH_CHARGE_AMT"  	, "");	//12
				hm.put("ISSINS_CHARGE_AMT"  , "");	//12
				hm.put("BUYINS_CHARGE_AMT"  , "");	//12
				hm.put("VAN_CHARGE_AMT"  	, "");	//12
				
				hm.put("PRT_ACCOUNT_NO"  	, "");	//20
				hm.put("CASHBAG_TRAN_YN"  	, "");	//1
				hm.put("CASHBAG_TRAN_AMT"  	, "");	//12
				//hm.put("CARD_INFO_YN"  	, "");		//1
				hm.put("FILLER"  			, "");	//60
				
				logger.info("CashBackData.nlensSms4100().length ==>"+ CashBackData.nlensSms4100().length );
				for (int i = 0; i < CashBackData.nlensSms4100().length; i++) {
					StringUtil.appendSpace(sb
							, (String) hm.get(CashBackData.strHeadersSms4100[i].toString()), CashBackData.nlensSms4100()[i]);
					//logger.info("Sms4100_appendSpace["+ i + "]["+CashBackData.nlensSms4100()[i] +"]  "+ sb.toString() );
				}	
				logger.info("strHeadersSms4100_appendSpace[sb]  "+ sb.toString() );
				break;
			}
			case 4200:{//인출 				
				//logger.info("jobType"+ jobType);
				hm.remove("INQ_TYPE");
				hm.put("DATA_SIZE", "00900");			 
				hm.put("RSP_CD", "");
				hm.put("RSP_MSG", "");
				//여기까지 공통부  이후로는 우선 일단 하드 코딩 추후 확인 필요함  
				//hm.put("MEMB_NO"  , "1234567890123");	//가맹점관리번호 13
				hm.put("TEL_NO"   , "02-6916-1500");	//가맹점 전화번호14
				hm.put("MEMB_NM"  , "emart24             ");	//가맹점명20
				//hm.put("REPR_NM"  , "김성영              ");	//대표자명20
				//hm.put("BIZCO_NO" , "1058692454");	//사업자등록번호10
				//hm.put("MEMB_ADDR", "서울특별시 성동구 성수동 2가 281-4 푸조비즈타워                                                     ");	//가맹점주소100
				//hm.put("MCH_JOB_CD"  	, "");	//4								
				//hm.put("BUY_MCH_SEND_UNIQ_NO"  	, "             ");	//13
				
				tmpCardSeq = aes.decrypt((String)hm.get("IC_CARD_SEQ").trim());				
				hm.put("IC_CARD_SEQ",   tmpCardSeq    );    // 신용카드  일련번호

				hm.put("MCH_SEND_UNIQ_NO"  	, "");	//13
				String tmpAmt = hm.get("PAY_AMT").substring(4);
				hm.put("PAY_AMT",tmpAmt);
				

				hm.put("ATM_CHARGE_AMT"		, "");	//12							
				hm.put("PRT_ACCOUNT_NO"  	, "");	//20			
				hm.put("FILLER"  			, "");	//60
				
				hm.put("MCH_CHARGE_AMT"      ,"");//new
				hm.put("ISSINS_CHARGE_AMT"   ,"");//new
				hm.put("BUYINS_CHARGE_AMT"   ,"");//new
				hm.put("VAN_CHARGE_AMT"      ,"");//new
				
				logger.info("CashBackData.nlensSms4200().length ==>"+ CashBackData.nlensSms4200().length );
				for (int i = 0; i < CashBackData.nlensSms4200().length; i++) {
					StringUtil.appendSpace(sb
							, (String) hm.get(CashBackData.strHeadersSms4200[i].toString()), CashBackData.nlensSms4200()[i]);
					
					//logger.info("Sms4200_appendSpace["+ i + "]["+CashBackData.nlensSms4200()[i] +"]  "+ sb.toString() );
				}	
				logger.info("strHeadersSms4200_appendSpace[sb]  "+ sb.toString() );
				break;
			}
			case 6100:{//구매환불 결과조회 				
				logger.info("jobType"+ jobType);
				hm.remove("INQ_TYPE");
				hm.put("DATA_SIZE", "00900");			 
				hm.put("RSP_CD", "");
				hm.put("RSP_MSG", "");
				//여기까지 공통부  이후로는 우선 일단 하드 코딩 추후 확인 필요함  
				//hm.put("MEMB_NO"  , "1234567890123");	//가맹점관리번호 13
				hm.put("TEL_NO"   , "02-6916-1500");	//가맹점 전화번호14
				hm.put("MEMB_NM"  , "emart24             ");	//가맹점명20
				//hm.put("REPR_NM"  , "김성영              ");	//대표자명20
				//hm.put("BIZCO_NO" , "1058692454");	//사업자등록번호10
				//hm.put("MEMB_ADDR", "서울특별시 성동구 성수동 2가 281-4 푸조비즈타워                                                     ");	//가맹점주소100
				//hm.put("MCH_JOB_CD"  	, "");	//4							
				hm.put("BUY_MCH_SEND_UNIQ_NO"  	, "             ");	//13
				
				tmpCardSeq = aes.decrypt((String)hm.get("IC_CARD_SEQ").trim());				
				hm.put("IC_CARD_SEQ",   tmpCardSeq    );    // 신용카드  일련번호
				 
				hm.put("MCH_SEND_UNIQ_NO"  	, "");	//13
				String tmpAmt = hm.get("PAY_AMT").substring(4);
				hm.put("PAY_AMT",tmpAmt);
				
				tmpAmt = hm.get("SERVICE_AMT").substring(4);
				hm.put("SERVICE_AMT"  		, tmpAmt);	//12
				
				tmpAmt = hm.get("VAT_AMT").substring(4);
				hm.put("VAT_AMT"  			, tmpAmt);	//12
				
				
				
				//int tmpInt = Integer.parseInt((String)hm.get("PAY_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//				hm.put("PAY_AMT",String.valueOf(tmpInt));
//				hm.put("SERVICE_AMT"  		, "");	//12
//				hm.put("VAT_AMT"  			, "");	//12
				hm.put("MCH_CHARGE_AMT"  	, "");	//12
				hm.put("ISSINS_CHARGE_AMT"  , "");	//12
				hm.put("BUYINS_CHARGE_AMT"  , "");	//12
				hm.put("VAN_CHARGE_AMT"  	, "");	//12
				
				hm.put("PRT_ACCOUNT_NO"  	, "");	//20
				hm.put("CASHBAG_TRAN_YN"  	, "");	//1
				hm.put("CASHBAG_TRAN_AMT"  	, "");	//1
				hm.put("FILLER"  			, "");	//
				 

				logger.info("CashBackData.nlensSms6100().length ==>"+ CashBackData.nlensSms6100().length );
				for (int i = 0; i < CashBackData.nlensSms6100().length; i++) {
					StringUtil.appendSpace(sb
							, (String) hm.get(CashBackData.strHeadersSms6100[i].toString()), CashBackData.nlensSms6100()[i]);
					//logger.info("Sms6100_appendSpace["+ i + "]["+CashBackData.nlensSms6100()[i] +"]  "+ sb.toString() );
				}
				logger.info("strHeadersSms6100_appendSpace[sb]  "+ sb.toString() );
				break;
			}	
			case CashBackData.POSREQ95:{//계좌출금 
				int encDataLength =  Integer.parseInt(hm.get("ENC_DATA_LENGTH")); 
				logger.info("jobType"+ jobType);
				hm.put("VERSION", "NPG01");//NPG01고정
				hm.put("LENGTH",  StringUtil.lPad(String.valueOf(CashBackData.COMMONHFIX + encDataLength + CashBackData.PGREQ95FIX), 5, "0") ); //Integer.toString(641+ Integer.parseInt(hm.get("ENC_DATA_LENGTH"))) 
				hm.put("RESP_CODE", "    ");
				hm.put("RESP_MSG", "                                                                                                    ");
				hm.put("FILLER", "                                                                                                    ");
				hm.put("TRANS_ID", "                              ");
				hm.put("ADMIT_DATE", "        ");
				hm.put("ADMIT_NO", "            ");
				hm.put("COM_AMT", "        ");
				hm.put("CUS_NM", "                              ");
				hm.put("CUS_AUTH_NO", "               ");
				hm.put("CUS_TEL", "            ");
				hm.put("CUS_EMAIL", "                                                            ");
				logger.info("encDataLength "+ encDataLength );
				logger.info("PRE_ENCRYPTED_DATA "+ hm.get("ENCRYPTED_DATA") );
				hm.put("ENCRYPTED_DATA", hm.get("ENCRYPTED_DATA").substring(0,encDataLength) );
				CashBackData.VariousEncryptedData = encDataLength;
				logger.info("POST_ENCRYPTED_DATA "+ hm.get("ENCRYPTED_DATA") );
//				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));
				logger.info("CashBackData.nlensSms95().length ==>"+ CashBackData.nlensSms95().length );
				for (int i = 0; i < CashBackData.nlensSms95().length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersSms95[i].toString()), CashBackData.nlensSms95()[i]);
//					logger.info("strHeadersSms95[i]  "+ (String) hm.get(CashBackData.strHeadersSms95[i].toString())  + "CashBackData.nlensSms95[i]  "+ CashBackData.nlensSms95[i]  );
				}	
				break;
			}
			case CashBackData.POSREQ96:{//계좌 출금 취소 
				int encDataLength =  Integer.parseInt(hm.get("ENC_DATA_LENGTH")); 
				logger.info("jobType"+ jobType);
				hm.put("VERSION", "NPG01");//NPG01고정
				hm.put("LENGTH",  
						StringUtil.lPad(String.valueOf(CashBackData.COMMONHFIX + encDataLength + CashBackData.PGREQ96FIX), 5, "0") ); //Integer.toString(641+ Integer.parseInt(hm.get("ENC_DATA_LENGTH"))) 
				hm.put("RESP_CODE", "    ");
				hm.put("RESP_MSG", "                                                                                                    ");
				hm.put("FILLER", "                                                                                                    ");
				hm.put("CANCLE_DATE", "        ");
				hm.put("CANCLE_AMT", "        ");
				logger.info("encDataLength "+ encDataLength );
				logger.info("PRE_ENCRYPTED_DATA "+ hm.get("ENCRYPTED_DATA") );
				hm.put("ENCRYPTED_DATA", hm.get("ENCRYPTED_DATA").substring(0,encDataLength) );
				CashBackData.VariousEncryptedData = encDataLength;
				logger.info("POST_ENCRYPTED_DATA "+ hm.get("ENCRYPTED_DATA") );
//				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));
				
				for (int i = 0; i < CashBackData.nlensSms96().length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersSms96[i].toString()), CashBackData.nlensSms96()[i]);
//					logger.info("strHeadersSms96[i]  "+ (String) hm.get(CashBackData.strHeadersSms96[i].toString())  + "CashBackData.nlensSms96[i]  "+ CashBackData.nlensSms96()[i]  );
				}	
				break;
			}			
			case CashBackData.POSREQ97:{
				int encDataLength =  Integer.parseInt(hm.get("ENC_DATA_LENGTH")); 
				logger.info("jobType"+ jobType);
				hm.put("VERSION", "NPG01");//NPG01고정
				
				hm.put("LENGTH",  
						StringUtil.lPad(String.valueOf(CashBackData.COMMONHFIX + encDataLength + CashBackData.PGREQ97FIX), 5, "0") );  
				hm.put("RESP_CODE", "   ");
				hm.put("RESP_MSG", "                                                                                                    ");
				hm.put("FILLER", "                                                                                                    ");								
				hm.put("COM_AMT", "00000000");	
				logger.info("encDataLength "+ encDataLength );
				logger.info("PRE_ENCRYPTED_DATA "+ hm.get("ENCRYPTED_DATA") );
				hm.put("ENCRYPTED_DATA", hm.get("ENCRYPTED_DATA").substring(0,encDataLength) );
				CashBackData.VariousEncryptedData = encDataLength;
//				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));
				logger.info("POST_ENCRYPTED_DATA "+ hm.get("ENCRYPTED_DATA") );
				for (int i = 0; i < CashBackData.nlensSms97().length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersSms97[i].toString()), CashBackData.nlensSms97()[i]);
					logger.info("strHeadersSms97[i]  "+ (String) hm.get(CashBackData.strHeadersSms97[i].toString())  + "CashBackData.nlensSms97[i]  "+ CashBackData.nlensSms97()[i]  );
				}	
				break;
			}
			case CashBackData.POSREQ98:{
				int encDataLength =  Integer.parseInt(hm.get("ENC_DATA_LENGTH")); 
				logger.info("jobType"+ jobType);
				hm.put("VERSION", "NPG01");//NPG01고정
				hm.put("LENGTH",  
						StringUtil.lPad(String.valueOf(CashBackData.COMMONHFIX + encDataLength + CashBackData.PGREQ98FIX), 5, "0")); //Integer.toString(641+ Integer.parseInt(hm.get("ENC_DATA_LENGTH"))) 
				hm.put("RESP_CODE", "   ");
				hm.put("RESP_MSG", "                                                                                                    ");
				hm.put("FILLER", "                                                                                                    ");
				logger.info("encDataLength "+ encDataLength );
				logger.info("PRE_ENCRYPTED_DATA "+ hm.get("ENCRYPTED_DATA") );
				hm.put("ENCRYPTED_DATA", hm.get("ENCRYPTED_DATA").substring(0,encDataLength) );
				CashBackData.VariousEncryptedData = encDataLength;
				logger.info("POST_ENCRYPTED_DATA "+ hm.get("ENCRYPTED_DATA") );
//				hm.put("ENCRYPTED_DATA", rPadSpace(hm.get("ENCRYPTED_DATA"), 5000));
				
				for (int i = 0; i < CashBackData.nlensSms98().length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersSms98[i].toString()), CashBackData.nlensSms98()[i]);
//					logger.info("strHeadersSms98[i]  "+ (String) hm.get(CashBackData.strHeadersSms98[i].toString())  + "CashBackData.nlensSms98[i]  "+ CashBackData.nlensSms98()[i]  );					
				}	
				break;
			}	

		}		
		logger.info("sb.toString() "+sb.toString()  );	
		return sb.toString();
}		

	
	public String getCashBackRsp95(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback으에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBACK_FILTER)));	
			/*neo0531====>*/df.CommLogger("getCashBack95 actSock create is success");
			logger.info("11neo0531");
			//SMS->CashBack SEND 에필요한 데이터 가공 
			String tmpInq = hm.get("INQ_TYPE");
			logger.info("tmpInq"+ tmpInq);
			hm.remove("INQ_TYPE");
			
			//캐쉬백 VAN 추가 lys
			String tmpVanCd = hm.get("VAN_CD");
			logger.info("tmpVanCd"+ tmpVanCd);
			hm.remove("VAN_CD");
			//캐쉬백 VAN end
			
			sendMsg = makeSendDataCashBack(hm, df , CashBackData.POSREQ95 );
			
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>CashBack95] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>CashBack95] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>CashBack95] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("CashBack Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			/*neo0531====>*/df.CommLogger("CashBack95 actSock.receive");

			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[CashBack95>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , CashBackData.POSREQ95);				//hmRecv = protocol.getParseGTFRsp(recvBuf , GTFData.RSP100);				//hmRecv = protocol.getParseSSGPointRsp(recvBuf);	
			/*neo0531====>*/df.CommLogger("CASHBACK 95 hmRecv parse is success");
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, CashBackData.POSRSP95,df);			
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String getCashBackRsp96(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback으에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBACK_FILTER)));	
			/*neo0531====>*/df.CommLogger("getCashBack96 actSock create is success");
			//SMS->CashBack SEND 에필요한 데이터 가공 
			String tmpInq = hm.get("INQ_TYPE");
			hm.remove("INQ_TYPE");
			
			//캐쉬백 VAN 추가 lys
			String tmpVanCd = hm.get("VAN_CD");
			logger.info("tmpVanCd"+ tmpVanCd);
			hm.remove("VAN_CD");
			//캐쉬백 VAN end
			
			sendMsg = makeSendDataCashBack(hm, df , CashBackData.POSREQ96 );
			
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>CashBack96] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>CashBack96] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>CashBack96] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("CashBack Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			/*neo0531====>*/df.CommLogger("CashBack96 actSock.receive");

			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[CashBack96>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , CashBackData.POSREQ96);				//hmRecv = protocol.getParseGTFRsp(recvBuf , GTFData.RSP100);				//hmRecv = protocol.getParseSSGPointRsp(recvBuf);	
			/*neo0531====>*/df.CommLogger("CASHBACKRsp96 parse is success");
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, CashBackData.POSRSP96,df);			
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String getCashBackRsp97(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback으에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBACK_FILTER)));	
			/*neo0531====>*/df.CommLogger("getCashBack97 actSock create is success");
			//SMS->CashBack SEND 에필요한 데이터 가공 
			String tmpInq = hm.get("INQ_TYPE");
			hm.remove("INQ_TYPE");
			
			//캐쉬백 VAN 추가 lys
			String tmpVanCd = hm.get("VAN_CD");
			logger.info("tmpVanCd"+ tmpVanCd);
			hm.remove("VAN_CD");
			//캐쉬백 VAN end
			
			sendMsg = makeSendDataCashBack(hm, df , CashBackData.POSREQ97 );

			df.CommLogger("sendMsg[" + sendMsg + "]");
			df.CommLogger("sendMsg.toString()[" + sendMsg.toString() + "]");
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>CashBack97] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>CashBack97] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>CashBack97] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("CashBack Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			/*neo0531====>*/df.CommLogger("CashBack97 actSock.receive");

			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[CashBack97>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , CashBackData.POSREQ97);				//hmRecv = protocol.getParseGTFRsp(recvBuf , GTFData.RSP100);				//hmRecv = protocol.getParseSSGPointRsp(recvBuf);	
			/*neo0531====>*/df.CommLogger("CASHBACKRsp97 parse is success");
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, CashBackData.POSRSP97,df);			
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String getCashBackRsp98(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback으에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBACK_FILTER)));	
			/*neo0531====>*/df.CommLogger("getCashBack98 actSock create is success");
			//SMS->CashBack SEND 에필요한 데이터 가공 
			String tmpInq = hm.get("INQ_TYPE");
			hm.remove("INQ_TYPE");
			
			//캐쉬백 VAN 추가 lys
			String tmpVanCd = hm.get("VAN_CD");
			logger.info("tmpVanCd"+ tmpVanCd);
			hm.remove("VAN_CD");
			//캐쉬백 VAN end
			
			sendMsg = makeSendDataCashBack(hm, df , CashBackData.POSREQ98 );
			
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>CashBack98] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>CashBack98] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>CashBack98] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("CashBack Server is no response");
			}
			
			recvBuf = ((String) actSock.receive());
			/*neo0531====>*/df.CommLogger("CashBack98 actSock.receive");

			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[CashBack98>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , CashBackData.POSREQ98);				//hmRecv = protocol.getParseGTFRsp(recvBuf , GTFData.RSP100);				//hmRecv = protocol.getParseSSGPointRsp(recvBuf);	
			/*neo0531====>*/df.CommLogger("CASHBACKRsp98 parse is success");
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, CashBackData.POSRSP98,df);			
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}	
	
	// 공동망
	public String getCashBackRsp3100(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback에서 받은 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBACK_FILTER_COMMON)));	
			df.CommLogger("getCashBack3100 actSock create is success");			
			//SMS->CashBack SEND 에필요한 데이터 가공 //String tmpInq = hm.get("INQ_TYPE");						logger.info("tmpInq"+ tmpInq); 
			sendMsg = makeSendDataCashBack(hm, df , 3100 );
			
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>CashBack3100] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>CashBack3100] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>CashBack3100] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("CashBack Server is no response");
			}
			actSock.getSocket().setSoTimeout(50*1000);//10초
			recvBuf = ((String) actSock.receive());
			df.CommLogger("CashBack3100 actSock.receive");

			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[CashBack3100>sms] RECV[" + recvBuf.getBytes().length + "]:[DATA:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , 3100);				
			df.CommLogger("CASHBACK 3100 hmRecv parse is success");
		}catch(SocketTimeoutException ste) {			
			df.CommLogger("▶▶▶ [ERROR]39: " + ste.getMessage());
			ret = "39";
			throw ste;
		}catch(Exception e) {
		
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, 3100,df);			
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String getCashBackRsp4000(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback에서 받은 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;

		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBACK_FILTER_COMMON)));	
			
			df.CommLogger("getCashBack4000 actSock create is success");			
			//SMS->CashBack SEND 에필요한 데이터 가공 //String tmpInq = hm.get("INQ_TYPE");						logger.info("tmpInq"+ tmpInq); 
			sendMsg = makeSendDataCashBack(hm, df , 4000 );
			logger.info("neo0531 "+sendMsg);
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>CashBack4000] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");

			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();					
			
			String tmpStr = "emart24             "; 
			byte[] tmpByte = tmpStr.getBytes("KSC5601");
			
			System.out.println(new String(tmpByte));
			String tmp = "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ";
			byte[] convByte = tmp.getBytes();
			int idt = 0;
			
			for (int id = 0 ; id< sendBytes.length; id++){				
				convByte[id] = sendBytes[id];
				if( id >= 684   && id <= 704 -1 ){
					convByte[id] = tmpByte[idt];
					idt++;
				}										
			}
			
			if( actSock.send(convByte, convByte.length) ) {			
				df.CommLogger("[sms>CashBack4000] SEND[" + sendMsg.getBytes().length + "] OK");
				} else {
					df.CommLogger("[sms>CashBack4000] SEND[" + sendMsg.getBytes().length + "] ERROR");
					throw new Exception("CashBack Server is no response");
				}

//			if (actSock.send(sendMsg)) {
//				df.CommLogger("[sms>CashBack4000] SEND[" + sendMsg.getBytes().length + "] OK");
//			} else {
//				df.CommLogger("[sms>CashBack4000] SEND[" + sendMsg.getBytes().length + "] ERROR");
//				throw new Exception("CashBack Server is no response");
//			}
			logger.info("neo0531 -1 ");			
			actSock.getSocket().setSoTimeout(50*1000);//10초
			logger.info("neo0531 -2 ");	
			recvBuf = ((String) actSock.receive());
			logger.info("neo0531 recvBuf=>"+ recvBuf);
			df.CommLogger("CashBack4000 actSock.receive");

			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[CashBack4000>sms] RECV[" + recvBuf.getBytes().length + "]:[DATA:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , 4000);				
			df.CommLogger("CASHBACK 4000 hmRecv parse is success");
		}catch(SocketTimeoutException ste) {			
			df.CommLogger("▶▶▶ [ERROR]39: " + ste.getMessage());
			ret = "39";
			throw ste;
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR4000]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {			
			actSock.close();
			//neo0531
			if (ret !="39" && ret !="29")
				dataMsg = ret + makeSendDataToPosRsp(hmRecv, 4000,df);
			else 
				dataMsg = ret ;
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	
	public String getCashBackRsp4100(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback에서 받은 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBACK_FILTER_COMMON)));	
			df.CommLogger("getCashBack4100 actSock create is success");			
			//SMS->CashBack SEND 에필요한 데이터 가공 //String tmpInq = hm.get("INQ_TYPE");						logger.info("tmpInq"+ tmpInq); 
			sendMsg = makeSendDataCashBack(hm, df , 4100 );
			
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>CashBack4100] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>CashBack4100] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>CashBack4100] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("CashBack Server is no response");
			}
			actSock.getSocket().setSoTimeout(50*1000);//10초
			recvBuf = ((String) actSock.receive());
			df.CommLogger("CashBack4100 actSock.receive");

			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[CashBack4100>sms] RECV[" + recvBuf.getBytes().length + "]:[DATA:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , 4100);				
			df.CommLogger("CASHBACK 4100 hmRecv parse is success");
		}catch(SocketTimeoutException ste) {			
			df.CommLogger("▶▶▶ [ERROR]39: " + ste.getMessage());
			ret = "39";
			throw ste;
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, 4100,df);			
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	
	public String getCashBackRsp4200(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback에서 받은 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBACK_FILTER_COMMON)));	
			df.CommLogger("getCashBack4200 actSock create is success");			
			//SMS->CashBack SEND 에필요한 데이터 가공 //String tmpInq = hm.get("INQ_TYPE");						logger.info("tmpInq"+ tmpInq); 
			sendMsg = makeSendDataCashBack(hm, df , 4200 );
			
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>CashBack4200] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>CashBack4200] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>CashBack4200] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("CashBack Server is no response");
			}
			actSock.getSocket().setSoTimeout(50*1000);//10초
			recvBuf = ((String) actSock.receive());
			df.CommLogger("CashBack4200 actSock.receive");

			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[CashBack4200>sms] RECV[" + recvBuf.getBytes().length + "]:[DATA:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , 4200);				
			df.CommLogger("CASHBACK 4200 hmRecv parse is success");
		}catch(SocketTimeoutException ste) {			
			df.CommLogger("▶▶▶ [ERROR]39: " + ste.getMessage());
			ret = "39";
			throw ste;
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, 4200,df);			
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	
	public String getCashBackRsp6100(HashMap<String, String> hmComm, HashMap<String, String> hm ) throws Exception {
		CashBackIrtProtocol protocol = new CashBackIrtProtocol();
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// cashback으로 보낼 송신 전문
		String recvBuf = "";		// cashback에서 받은 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHBACK_FILTER_COMMON)));	
			df.CommLogger("getCashBack6100 actSock create is success");			
			//SMS->CashBack SEND 에필요한 데이터 가공 //String tmpInq = hm.get("INQ_TYPE");						logger.info("tmpInq"+ tmpInq); 
			sendMsg = makeSendDataCashBack(hm, df , 6100 );
			
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>CashBack6100] SEND[" + sendMsg.getBytes ().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>CashBack6100] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>CashBack6100] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("CashBack Server is no response");
			}
			actSock.getSocket().setSoTimeout(50*1000);//10초
			recvBuf = ((String) actSock.receive());
			df.CommLogger("CashBack6100 actSock.receive");

			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[CashBack6100>sms] RECV[" + recvBuf.getBytes().length + "]:[DATA:]:[" + sb.toString() + "]");
			
			hmRecv = protocol.getParseCashBackRsp(recvBuf , 6100);				
			df.CommLogger("CASHBACK 6100 hmRecv parse is success");
		}catch(SocketTimeoutException ste) {			
			df.CommLogger("▶▶▶ [ERROR]39: " + ste.getMessage());
			ret = "39";
			throw ste;
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, 6100,df);			
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
		
	
	private String makeSendDataToPosRsp(HashMap<String, String> hm, int rspType, COMMLog df) {
		StringBuffer sb = new StringBuffer();								
		switch(rspType){
			case 3100:
			case 4000:
			case 4100:
			case 4200:
			case 6100:{
//				// 포스에서 못받는 문제 생길시 주석 해제 할것 
				if (rspType != 4200){
//					
//					int tmpInt = Integer.parseInt((String)hm.get("PAY_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//					hm.put("PAY_AMT",String.valueOf(tmpInt));
//					tmpInt = Integer.parseInt((String)hm.get("SERVICE_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//					hm.put("SERVICE_AMT",String.valueOf(tmpInt));
//					tmpInt = Integer.parseInt((String)hm.get("VAT_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//					hm.put("VAT_AMT",String.valueOf(tmpInt));
//					tmpInt = Integer.parseInt((String)hm.get("MCH_CHARGE_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//					hm.put("MCH_CHARGE_AMT",String.valueOf(tmpInt));
//					tmpInt = Integer.parseInt((String)hm.get("ISSINS_CHARGE_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//					hm.put("ISSINS_CHARGE_AMT",String.valueOf(tmpInt));
//					tmpInt = Integer.parseInt((String)hm.get("BUYINS_CHARGE_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//					hm.put("BUYINS_CHARGE_AMT",String.valueOf(tmpInt));
//					tmpInt = Integer.parseInt((String)hm.get("VAN_CHARGE_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//					hm.put("VAN_CHARGE_AMT",String.valueOf(tmpInt));
								
				 //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
				hm.put("PAY_AMT",StringUtil.lPad((String)hm.get("PAY_AMT").trim(),16,"0"));				
				hm.put("SERVICE_AMT",StringUtil.lPad((String)hm.get("SERVICE_AMT").trim(),16,"0"));				
				hm.put("VAT_AMT",StringUtil.lPad((String)hm.get("VAT_AMT").trim(),16,"0"));				
				hm.put("MCH_CHARGE_AMT",StringUtil.lPad((String)hm.get("MCH_CHARGE_AMT").trim(),16,"0"));				
				hm.put("ISSINS_CHARGE_AMT",StringUtil.lPad((String)hm.get("ISSINS_CHARGE_AMT").trim(),16,"0"));				
				hm.put("BUYINS_CHARGE_AMT",StringUtil.lPad((String)hm.get("BUYINS_CHARGE_AMT").trim(),16,"0"));				
				hm.put("VAN_CHARGE_AMT",StringUtil.lPad((String)hm.get("VAN_CHARGE_AMT").trim(),16,"0"));				
				hm.put("CASHBAG_TRAN_AMT",StringUtil.lPad((String)hm.get("CASHBAG_TRAN_AMT").trim(),16,"0"));
				
				
				}else{ //4200
//					int tmpInt = Integer.parseInt((String)hm.get("PAY_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//					hm.put("PAY_AMT",String.valueOf(tmpInt));
//					tmpInt = Integer.parseInt((String)hm.get("ATM_CHARGE_AMT").trim()); //포스(16)와 자리수(12) 차이로 인한 잡업 ㅡ;
//					hm.put("ATM_CHARGE_AMT",String.valueOf(tmpInt));
				
				hm.put("PAY_AMT",StringUtil.lPad((String)hm.get("PAY_AMT").trim(),16,"0"));
				hm.put("ATM_CHARGE_AMT",StringUtil.lPad((String)hm.get("ATM_CHARGE_AMT").trim(),16,"0"));
				} 
					
 
				for (int i = 0; i < CashBackData.nlensPosRspComm.length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersPosRspComm[i].toString()), CashBackData.nlensPosRspComm[i]);
					
					logger.info("PosRspComm_appendSpace["+ i + "]["+CashBackData.strHeadersPosRspComm[i].toString()+"]  "+ (String) hm.get(CashBackData.strHeadersPosRspComm[i].toString()) );
					
				}	
				break;
				
			}
			case CashBackData.POSRSP95:{
				for (int i = 0; i < CashBackData.nlensPosRsp95.length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersPosRsp95[i].toString()), CashBackData.nlensPosRsp95[i]);
				}	
				break;
				}
			case CashBackData.POSRSP96:{			
				for (int i = 0; i < CashBackData.nlensPosRsp96.length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersPosRsp96[i].toString()), CashBackData.nlensPosRsp96[i]);
				}				
				break;
				}
			case CashBackData.POSRSP97:{				
				for (int i = 0; i < CashBackData.nlensPosRsp97.length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersPosRsp97[i].toString()), CashBackData.nlensPosRsp97[i]);
				}							
				break;
			}
			case CashBackData.POSRSP98:{				
				for (int i = 0; i < CashBackData.nlensPosRsp98.length; i++) {
					StringUtil.appendSpace(sb, (String) hm.get(CashBackData.strHeadersPosRsp98[i].toString()), CashBackData.nlensPosRsp98[i]);
				}							
				break;
			}
			
			default :{
					//do nothing
				}
		}			
		return sb.toString();
	}

	
}
