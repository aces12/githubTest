package biz.cms_SvArrivalSync;

import java.util.List;

import org.apache.log4j.Logger;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class SvArrivalSyncDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(SvArrivalSyncPollingAction.class);
	/**
	 * 사원증 인증(사원증 SV 점착 인증) 동기화
	 * @return : 사원증 인증(사원증 SV 점착 인증) 동기화 대상
	 */
	public List<Object> selSvArrivalSync(String val) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery("svarrival-sql", "SEL_SVARRIVALSYNC"));
			list = executeQuery(sql);

		}catch(Exception e) {
			logger.info("[ERROR]SEL_SVARRIVALSYNC::" + e);
		} 
		
		return list;
	}
	
	public int upSvArrivalSync(String dt, String elec_staff, String employee_id) {
		SqlWrapper sql = new SqlWrapper();
		int updateYn = 0;
		int i = 0;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");

			sql.clearParameter();
			sql.put(findQuery("svarrival-sql", "UP_SVARRIVALSYNC"));
			sql.setString(++i, employee_id);
			sql.setString(++i, dt);
			sql.setString(++i, elec_staff);

			updateYn = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]UP_SVARRIVALSYNC::" + e);
		}finally {
			end();
		}
		
		return updateYn;
	}
}
