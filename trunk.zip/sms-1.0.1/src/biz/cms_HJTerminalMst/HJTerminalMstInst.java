package biz.cms_HJTerminalMst;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

/**
 * 한진 택배 터미널ID 정보 취득 처리 스레드
 * 배치프로그램 (SFTP를 이용하여 파일 다운로드 후 해당 내용을 파싱하여 DB에 저장) 
 * @author FCV00040
 */
public class HJTerminalMstInst extends Thread {
	private final String HANJIN_TERMINAL_MST_FILENAME_PREFIX = "EMARTZIP_";
	private final int LENGTH_BY_HD_RECORD = 71;			// 70 + (cr + lf)
	private final int LENGTH_BY_BODY_RECORD = 243;		// 241 + (cr + lf)

	private static Logger logger = Logger.getLogger(HJTerminalMstPollingAction.class);

	String path = "";			// 파일경로
	String stdDate = "";		// 처리 기준일(yyyyMMdd)

	/**
	 * 생성자
	 * @param path
	 * @param stdDate
	 */
	public HJTerminalMstInst(String path, String stdDate) {
		this.path = path;
		this.stdDate = stdDate;
	}

	/**
	 * 스레드 매소드
	 */
	public void run() {
		String fileNM = "";

		try {
			logger.info("[INFO] filePath::["+this.path+"]");

			List<File> file = getDirFileList(this.path);
			long fileSize = 0;
			int totLen = 0;
			int len = 0;

			logger.info("[INFO] fileCnt::["+Integer.toString(file.size())+"]");

			for (int i = 0; i < file.size(); i++) {
				fileNM = file.get(i).getName();

				logger.info("[INFO] fileName::["+fileNM+"]");
 
				if (!fileNM.startsWith("EMARTZIP_")) {
					logger.info("[INFO] this file is not HAJIN Terminal Addr Info. (SKIP) : " + fileNM); // 파일이름이 지정된 명칭으로 시작하지 않는다면 스킵
					moveFile(this.path, fileNM, this.path + File.separator + "backup"); // 파일 옮기기...
					continue;
				}

				// 변수 초기화 및 리셋
				fileSize = (file.get(i)).length();
				totLen = 0;
				len = 0;

				byte buf[] = new byte[(int)fileSize];
				InputStream is = new FileInputStream(file.get(i));
				StringBuffer sb = new StringBuffer();

				while ((len = is.read(buf, 0, (int) fileSize)) > 0) {
					sb.append(new String(buf, "UTF-8"));
					totLen += len;

					logger.info("[INFO] fileSize::["+fileSize+"]");
					if (totLen == fileSize) {		// 전체 읽어들인 경우 루프 강제 종료
						break;
					}
				}

				is.close();

				// 한진택배 터미널 정보 파일이 맞는 경우에만 아래 작업을 수행
				if ("EMARTZIP_".equals(fileNM.substring(0, 9))) {
					logger.info("[INFO] insert start.");

					this.insertDB(sb.toString());
				}

				// 파일 옮기기...
				moveFile(this.path, fileNM, this.path + File.separator + "backup");

				logger.info("[INFO] File::["+fileNM+"] processed successfuly.");
			}
		} catch (Exception e) {
			logger.info("[ERROR] " + e.getMessage());
			logger.info("[ERROR] #### YOU NEED INVESTIGATION on cms_HJTerminalMst ####");
		}
	}

	/**
	 * 데이터베이스에 정보 반입
	 * @param readData
	 * @throws Exception 
	 */
	private void insertDB(String readData) throws Exception {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			HJTerminalMstDAO dao = new HJTerminalMstDAO();

			
			String lines[] = readData.split("\n");
			logger.info("[INFO] insert taget count::["+lines.length+"]");
			
			for(int j = 1; j < lines.length; j++){
				String lineData = lines[j].toString();
				logger.info("[INFO] lineData::["+lineData+"]");
				
				String column[] = lineData.split("\\|");
				
				/*for(int h = 0; h < column.length; h++){
					System.out.println("[column::" + column[h].toString());
				}*/
				
				hm = this.getHJTerminalMstParsed(column);
				logger.info("[INFO] hm::["+hm+"]");
				
				try {
					dao.insHJTerminalMst(hm);
				} catch (Exception e) {
					logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					throw e;
				}
				
			}

		} catch(Exception e) {
			System.out.println("[ERROR] " + e.getMessage());

			throw e;
		}
	}

	/**
	 * 하나의 레코드 정보를 파싱 
	 * @param rcvBuf
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@SuppressWarnings("unchecked")
	private HashMap<String, String> getHJTerminalMstParsed(String columData[]) throws UnsupportedEncodingException {
		HashMap<String, String> hm = new HashMap<String, String>();
		String strHeaders[] = {
			"POST_NO",			// 우편번호
			"CITY_ADDR",		// 시
			"GU_ADDR",			// 구
			"DONG_ADDR",		// 동
			"SUB_ADDR",			// 서브
			
			"TERMINAL_CD",		// 터미널코드
			"TERMINAL_NM",		// 터미널명
			"SALE_CD",			// 영업소코드
			"SALE_NM",			// 영업소명
			"DELI_HOUR",		// 배송소요시간
			
			"DIVISION_TP",		// 권역구분
			"HUB_CD",			// 허브코드
			"MID_CD",			// 중분류코드
			"SUB_CD",			// 소분류코드
			"COL_AREA_NM",		// 집배구역명
			
			"ES_NM",			// ES명
			"QUICK_AREA"		// 퀵지역
		};
		
		hm = this.getParseDataMultibyte(strHeaders, columData);
		
		return hm;
	}

	/***
	 * 정보 파싱
	 * @param nlens
	 * @param strHeaders
	 * @param rcvBuf
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private HashMap getParseDataMultibyte(String strHeaders[], String columData[]) throws UnsupportedEncodingException {		
		HashMap hm = new HashMap();
		for (int i = 0; i < strHeaders.length; i++) {
			hm.put(strHeaders[i].toString(), columData[i].toString().trim());		// 문자 TRIM 처리
		}
		return hm;
	}
	

	/**
	 * 지정 경로의 파일을 다른 경로로 이동
	 * @param orgPath
	 * @param fileNM
	 * @param destPath
	 */
	public void moveFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);

		if (!destDir.exists()) {
			destDir.mkdir();
		}

		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);

		logger.info("orgFile = " + orgPath + File.separator + fileNM);
		logger.info("destFile = " + destPath + File.separator + fileNM);

		if (destFile.exists()) {
			if (orgFile.delete()) {
				logger.info("[DEBUG] File(" + orgFile.getPath() + " / " + orgFile.getName() + ") Deleted");
			} else {
				logger.info("[DEBUG] Fail to remove file(" + orgFile.getPath() + " / " + orgFile.getName() + ")");
			}
		} else {
			for (int i = 0; i < 20; i++) {
				if (orgFile.renameTo(destFile)) {
					logger.info(">> MOVE OK : " + destFile.getName());
					break;
				}

				System.gc();

				try {
					Thread.sleep(50);
				} catch (InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}

	/**
	 * 지정 디렉토리 내의 파일 핸들 객체를 목록으로 반환 
	 * @param dirPath
	 * @return
	 */
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		File dir = new File(dirPath);

		if (dir.exists()) {
			File[] files = dir.listFiles();

			tmpList = Arrays.asList(files);

			for (int i = 0; i < tmpList.size(); i++) {
				if (tmpList.get(i).isFile()) {
					dirFileList.add(tmpList.get(i));
				}
			}
		}
		
		return dirFileList;
	}
}