package biz.cms_HJTerminalMst;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.apache.log4j.Logger;

import biz.comm.SFTPManager;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

/**
 * 한진 택배 터미널ID 정보 취득
 * 배치프로그램 (SFTP를 이용하여 파일 다운로드 후 해당 내용을 파싱하여 DB에 저장) 
 * @author FCV00040
 */
public class HJTerminalMstPollingAction_TEST extends PollingAction {
	private static Logger logger = Logger.getLogger(HJTerminalMstPollingAction.class);

	/**
	 * 테스트/수동실행 목적 main 매소드
	 * @param args
	 * @throws Exception
	 */
	public static void main(String args[]) throws Exception {
		HJTerminalMstPollingAction_TEST action = new HJTerminalMstPollingAction_TEST();

		try {
			if (args == null || args.length < 1) {
				System.out.println("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0]);
			System.out.println("[DEBUG] [args[1]]=" + args[1]);

			String path = nvl(args[0].replaceFirst("-path:", ""));
			String fileDt = nvl(args[1].replaceFirst("-fileDt:", ""));
			
			/*String path = "C:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
			String fileDt = "20180418";*/
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml", path);
			
			action.execute("1", fileDt);
		} catch (Exception e) {
			System.out.println("[Received Data]=" + e.getMessage());
		}
	}

	private static String nvl(String param) {
		return param != null ? param: "";
	}

	/**
	 * 한진 택배 터미널ID 정보 취득 작업 실행
	 * @param actionMode : 0=POLLING_PERIOD에 주기적으로 무조건 수행(처리하지 않음), 1=ACTION_TIME에 한번 수행
	 */
	public void execute(String actionMode, String fileDt) {
		SFTPManager sFtpMgr = null;
		BufferedOutputStream bos = null;

		String hanjinFtpIp   = "";		// 한진(HANJIN) FTP 접속정보
		int    hanjinFtpPort = 0;
		String hanjinFtpId   = "";
		String hanjinFtpPwd  = "";

		String basePath = "";
		String destPath = "";
		String FileNm   = "";	
		String stdDate  = "";

		int iRetry = 0;
		
		boolean isDownOK = false;

		try{
			if (actionMode != "1") {	// actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
				return;
			}

			// 프로퍼티로부터 SFTP 접속 정보 취득
			hanjinFtpIp   = PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_IP");
			hanjinFtpPort = Integer.parseInt(PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_PORT"));
			hanjinFtpId   = PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_ID");
			hanjinFtpPwd  = PropertyUtil.findProperty("communication-property", "HANJIN_FTP_SERVER_PWD");

			logger.info("[INFO] Trying HANJIN SFTP Connection...");

			// SFTP 연결 초기화
			try {				
				sFtpMgr = new SFTPManager(hanjinFtpIp, hanjinFtpPort, hanjinFtpId, hanjinFtpPwd);
				logger.info("[INFO] TRY Connected to " + hanjinFtpIp + ":" + hanjinFtpPort);
			} catch (Exception e) {
				logger.info("[INFO] exception occur" + e.getMessage());
				logger.info("[INFO] SFTP Connect fail exception occur ");
				return;
			}

			logger.info("[INFO] SFTP Connection is Success ");

			// 프로퍼티로부터 파일 생성 경로 확보
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "hanjin_tm";

			File destDir = new File(destPath);

			if( !destDir.exists() ) {
				destDir.mkdir();
				logger.info("[DEBUG] Try to make dir" );
			}
			
			if(fileDt != null && !"".equals(fileDt)){
				stdDate = fileDt;
			}else{	// 당일날짜 타임스탬프 취득 및 사용 파일명 특정
				Calendar calendar = new GregorianCalendar(Locale.KOREA);	
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				calendar.setTime(new Date());
				stdDate = sdf.format(calendar.getTime());		// 기준일
			}

			String downTargetFileNM = "EMARTZIP_" + stdDate;
			FileNm = downTargetFileNM;

			logger.info("[INFO] Hanjin Terminal Down File Name::["+downTargetFileNM+"]");

			bos = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + downTargetFileNM));	// 파일 작성용 스트림 생성
	        sFtpMgr.cd(".." + File.separator + "out"); // SFTP 디렉토리 이동

		    logger.info("[INFO] change directory success.");
		    
			while (iRetry < 2) {	// SFTP 파일 다운로드
				logger.info("[INFO] iRetry::["+iRetry+"]");

				if ((isDownOK = sFtpMgr.get(downTargetFileNM, bos))) {		// 파일다운로드
					logger.info("[INFO] File download is success.");
					break;
				}

				iRetry++;
			}

		    logger.info("[INFO] SFTP::isDownOK::["+isDownOK+"]");

		    bos.flush();
	        bos.close();
		    bos = null;

		    System.gc();

		    // SFTP 서버 파일 정리(제거) 및 다운로드 완료 된 파일의 정리(파일명에 .ok 추가)
			if (isDownOK == true) {
				logger.info("[INFO] >>>>>>>>>>>>> successfully downloaded file [" + downTargetFileNM + "]");
				
				if (sFtpMgr.rm(downTargetFileNM)) { // 다운 받은 파일은 삭제한다.
					System.out.println("[DEBUG] Succeeded remove file.");

					File file = new File(destPath + "/" + downTargetFileNM);
					File fileOK = new File(destPath + "/" + downTargetFileNM.concat(".ok"));
					file.renameTo(fileOK);				// 다운로드 완료시 파일명에 .ok 추가
				} else {
					System.out.println("[DEBUG] Failed to remove.");
				}
			} else {	// 다운로드 중 완료되지 않은 파일로 간주하여 제거
				File file = new File(destPath + File.separator + downTargetFileNM);	

				logger.info("[ERROR] Can't get file on FTP server. Start delete zero file.");
				if (file.delete() != true) {
					logger.info("[ERROR] Failed to delete empty file [" + downTargetFileNM + "]");
				}
			}
		    logger.info("[INFO] FILE PARSE AND DB INSERT START");

		    HJTerminalMstInst insert = new HJTerminalMstInst(destPath, stdDate);
		    insert.start();
		    
		} catch (Exception e) {
			if (isDownOK != true) {
				// 예외 발생시 !isDownOK삭제(ACTION_TIME 다중 발생시 생성되는 0byte파일 삭제)
				File file = new File(destPath + "/" + FileNm);

				if (file.delete() != true) {
					System.out.println("[ERROR] Failed to delete empty file [" + FileNm + "]");
				}

				System.out.println("[ERROR] Exception, delete file: " + FileNm);
			}
			
			System.out.println("[ERROR1] " + e.getMessage());
		} finally {
			if (bos != null) {
				try {
					bos.close();
					bos = null;
				} catch (Exception e) {
					// do pass
				}
			}

			try {
				if (sFtpMgr.isClosed() != true) {
					sFtpMgr.logout();
				}
			} catch (Exception e) {
				// do pass
			}
		}

		System.out.println("# HAJIN TERMINAL MST INFO DOWNLOAD THREAD :: execute() END");
	}

	@Override
	public void execute(String arg0) {
		// TODO Auto-generated method stub
		
	}
}
