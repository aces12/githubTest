package biz.cms_ETCTransCardIrt;

import java.util.HashMap;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class ETCTransCardIrtProtocol {
	private static Logger logger = Logger.getLogger(ETCTransCardIrtAction.class);
	
	public int getRcvETCTransCardIrtDATA(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret = 0;
		int nlens[] = {2};
		
		String strHeaders[] = {
			"INQ_TYPE"		// INQ Type(INQ 종별)
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if( Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE")) ) {
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		
		return ret;
	}
	
	public HashMap<String, String> getParseHanPayCARDBLCHKRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,8,2,8,6,8
					  ,15,14,16,2,13};
		String strHeaders[] = {
			"COL_CENTER_CD",
			"AGENT_CD",
			"MSG_CD",
			"RESP_CD",
			"TRANS_YMD",
			"TRANS_HMS",
			"DATA_LEN",
				
			"FCSTR_NO",
			"REQ_YMDHMS",
			"CCARD_NO",
			"USE_YN",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseHanPayCPNPINCHKRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,8,2,8,6,8
					  ,15,10,20,2,6
					  ,10,8,8,4,17};
		String strHeaders[] = {
			"COL_CENTER_CD",
			"AGENT_CD",
			"MSG_CD",
			"RESP_CD",
			"TRANS_YMD",
			"TRANS_HMS",
			"DATA_LEN",
			
			"FCSTR_NO",
			"TERMINAL_ID",
			"COUPON_PIN",
			"PIN_USEABLE",
			"COUP_ISSU_CORP_CD",
			
			"COUPON_AMT",
			"VAL_START_DT",
			"VAL_END_DT",
			"ERR_CD",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseHanPayCHRGCHRGCNCLRSLTRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,8,2,8,6,8
					  ,18,16,8,18};
		String strHeaders[] = {
			"COL_CENTER_CD",
			"AGENT_CD",
			"MSG_CD",
			"RESP_CD",
			"TRANS_YMD",
			"TRANS_HMS",
			"DATA_LEN",
			
			"DEAL_UNIQ_NO",
			"IDEP",
			"BALEP",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseHanPayCHRGCHRGCNCLRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,8,2,8,6,8
					  ,18,16,8,8,2,8};
		String strHeaders[] = {
			"COL_CENTER_CD",
			"AGENT_CD",
			"MSG_CD",
			"RESP_CD",
			"TRANS_YMD",
			"TRANS_HMS",
			"DATA_LEN",
			
			"DEAL_UNIQ_NO",
			"RHSM",
			"NTLSAM",
			"SIND2",
			"CHRG_RESP_CD",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseHanPayTMNLOPENRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,8,2,8,6,8
					  ,1,1,10,16,16,40,40,20,6,150,10,10,10,15,5};
		String strHeaders[] = {
			"COL_CENTER_CD",
			"AGENT_CD",
			"MSG_CD",
			"RESP_CD",
			"TRANS_YMD",
			"TRANS_HMS",
			"DATA_LEN",
				
			"DEAL_TYPE_CD",
			"JOB_TP",
			"TERMINAL_ID",
			"SAM_ID",
			"BEFORE_SAM_ID",
			"FCSTR_NM",
			"FCSTR_OWNER_NM",
			"TEL_NO",
			"POST_CD",
			"FCSTR_ADDR",
			"HQ_CORP_REG_NO",
			"FCSTR_CORP_REG_NO",
			"BEF_FCSTR_CORP_REG_NO",
			"FCSTR_NO",
			"FILLER"
		};
		
		//logger.info("▶ getParseCashBeeTMNLINSTALLRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseHanPayTMNLOPENInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,1,1,10,16
					  ,16,40,40,20,6
					  ,150,10,10,10};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE_CD",
			"JOB_TP",
			"TERMINAL_ID",
			"SAM_ID",
			
			"BEFORE_SAM_ID",
			"FCSTR_NM",
			"FCSTR_OWNER_NM",
			"TEL_NO",
			"POST_CD",
			
			"FCSTR_ADDR",
			"HQ_CORP_REG_NO",
			"FCSTR_CORP_REG_NO",
			"BEF_FCSTR_CORP_REG_NO"
		};
		
		//logger.info( "▶ getParseCashBeeTMNLINSTALLInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);		
		
		return hm;
	}
	
	public HashMap<String, String> getParseHanPayCHRGCHRGCNCLInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,18,15,6,14
					  ,8,4,10,2,2
					  ,2,20,6,2,2
					  ,16,2,2,8,8
					  ,2,16,8,8,8
					  ,16,16,8,2,20};
		String strHeaders[] = { "INQ_TYPE", "DEAL_UNIQ_NO", "FCSTR_NO", "ISSU_CORP_CD", "DEAL_YMDHMS"
							  , "ADJT_YMD", "CARD_TP", "TERMINAL_ID", "PROC_CD", "CARD_CORP_TP"
							  , "PAYMENT_TP", "PAYMENT_TP_PIN_CD", "COUPON_ISSU_CORP_CD", "TRT", "IDCENTER"
							  , "IDEP", "ALGEP", "VKDL_KEY", "BALEP", "NTEP"
							  , "IDLSAM_CENTER", "IDLSAM", "NTLSAM", "MLDA", "SIND1"
							  , "REP", "CCARD_NO", "CCARD_AUTH_NO", "CCARD_TP", "ORG_DEAL_UNIQ_NO" };
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseHanPayCHRGCHRGCNCLRSLTInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,18,15,2,2
					  ,16,8,8,16,8
					  ,16,8,16,2};
		String strHeaders[] = { "INQ_TYPE", "DEAL_UNIQ_NO", "FCSTR_NO", "TRT", "IDCENTER"
							  , "IDEP", "BALEP", "NTEP", "IDLSAM", "NTLSAM"
							  , "RHSM", "SIND3", "REP", "DEAL_STS_TP" };
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseHanPayCPNPINCHKInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,15,10,20,14};
		String strHeaders[] = { "INQ_TYPE", "FCSTR_NO", "TERMINAL_ID", "COUPON_PIN", "REQ_YMDHMS" };
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseHanPayCARDBLCHKInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,15,14,16};
		String strHeaders[] = { "INQ_TYPE", "FCSTR_NO", "REQ_YMDHMS", "CCARD_NO" };
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}

	// 레일플러스 충전/충전직전거래취소/반품충전 요청
	public HashMap<String, String> getParseRailPlusCHRGCHRGCNCLInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,20,16,2
					  ,14,2,2,10,10
					  ,10,16,8,10,7
					  ,16,10,10,16,14
					  ,10,10,2,16,10
					  ,40};
		String strHeaders[] = { "INQ_TYPE", "TASK_TP", "TRANSACTION_ID", "CARD_NO", "CARD_OWNER_TP"
							  , "OCCU_YMDHMS", "KEYSET_VER", "ALGO_ID", "CARD_DEAL_SEQ_NO", "PPCARD_REM_AMT"
							  , "PPCARD_REQ_AMT", "RAND_VAL", "SIGN1_VAL", "TERMINAL_ID", "FCSTR_DIS_CD"							  
							  , "BEFDEAL_SAM_ID", "BEFDEAL_CARD_TRAN_SEQ_NO", "BEFDEAL_CHRG_AMT", "ORG_CARD_NO", "ORG_DEAL_YMDHMS"							  
							  , "ORG_CARD_DEAL_SEQ_NO", "ORG_TERMINAL_ID", "PAY_TP", "MEMBER_ID", "DEAL_BRANCH_NO"
							  , "DEAL_BRANCH_NM"};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	// 레일플러스 충전/충전직전거래취소/반품충전 결과
	public HashMap<String, String> getParseRailPlusCHRGCHRGCNCLRSLTInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,20,16,16
					  ,10,2,14,2,2
					  ,10,10,10,10,10
					  ,10,10,16,8,10
					  ,7,14,4,4,2
					  ,20,16,10,4};
		String strHeaders[] = { "INQ_TYPE", "TASK_TP", "TRANSACTION_ID", "CARD_NO", "SAM_ID"				
							  , "SAM_DEAL_SEQ_NO", "CARD_OWNER_TP", "OCCU_YMDHMS", "KEYSET_VER", "ALGO_ID"							  
							  , "CARD_TRAN_SEQ_NO", "CHRG_BEF_RAMT", "CHRG_REQ_RAMT", "CHRG_AFT_RAMT", "FEE"
							  , "CARD_DEPOSIT", "PENALTY_AMT", "RAND_VAL", "SIGN3_VAL", "TERMINAL_ID"
							  , "FCSTR_DIS_CD", "DEAL_YMDHMS", "CARD_STS_CD", "TERMINAL_STS_CD", "RESP_CD"
							  , "ERR_MSG", "PREDEAL_ID_HOST", "DEAL_BRANCH_NO", "CHRG_FEE_RATE" };
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	// 레일플러스 카드 PL 상태 요청
	public HashMap<String, String> getParseRailPlusCARDPLCHKInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,20,16,10
				      ,14};
		String strHeaders[] = { "INQ_TYPE", "TASK_TP", "TRANSACTION_ID", "CARD_NO", "ALIAS_NO"
				              , "REQ_YMDHMS"};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	// 레일플러스 충전/충전직전거래취소/반품충전 응답
	public HashMap<String, String> getParseRailPlusCHRGCHRGCNCLRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,50,20,16
					  ,16,10,2,14,2
					  ,2,10,10,10,10
					  ,10,10,10,16,8
					  ,10,7,14,4,4
					  ,2,20,8,4,97};
		String strHeaders[] = { "TASK_TP"                   // 업무구분
				              , "RECORD_LEN" 				// 레코드 길이
				              , "MEMBER_USE_FIELD"  		// 제휴사 사용 영역
				              , "TRANSACTION_ID"            // TRANSACTION ID
				              , "CARD_NO"                   // 선불카드 ID
				              
				              , "SAM_ID"                    // SAM ID				              
				  			  , "SAM_DEAL_SEQ_NO"           // SAM 거래 일련번호
				              , "CARD_OWNER_TP"		        // 카드소지자 구분		              
							  , "OCCU_YMDHMS"               // 충전일시/직전거래 충전취소 일시/반환일시
							  , "KEYSET_VER"                // 키셋버전
							  
							  , "ALGO_ID"                   // 알고리즘 ID
							  , "CARD_TRAN_SEQ_NO"          // 카드거래 일련번호
							  , "CHRG_BEF_RAMT"             // 선불카드잔액/직전거래 충전취소 잔액/반환전잔액
							  , "CHRG_REQ_RAMT"             // 선불카드충전요청금액/직전거래 충전취소요청금액/반환요청금액
							  , "CHRG_AFT_RAMT"             // 선불카드 충전후 잔액
							  
							  , "FEE"                       // 충전수수료/직전거래 충전취소 수수료/반환수수료
							  , "CARD_DEPOSIT"              // 카드보증금
							  , "PENALTY_AMT"               // PENALTY 금액
							  , "RAND_VAL"                  // 난수							  
							  , "SIGN2_VAL"                 // SIGN2
							  
							  , "TERMINAL_ID"               // 단말기ID
							  , "FCSTR_DIS_CD"	            // 가맹점구분코드
							  , "DEAL_YMDHMS"               // 충전거래 일시/직전거래 충전취소 거래일시/반환거래 일시
							  , "CARD_STS_CD"               // 카드상태코드
							  , "TERMINAL_STS_CD"           // 단말기상태코드
							  
							  , "RESP_CD"                   // 응답코드
							  , "ERR_MSG"                   // 오류메시지
							  , "FRANCHISE_ID"              // 가맹점ID
							  , "CHRG_FEE_RATE"             // 충전수수료율/반환수수료율
							  , "FILLER"};                  // FILLER
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	// 레일플러스 카드 PL 상태 응답
	public HashMap<String, String> getParseRailPlusCARDBLCHKRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,50,20,8
					  ,14,16,10,1,1
				      ,276};
		String strHeaders[] = { "TASK_TP"                   // 업무구분
							  , "RECORD_LEN" 				// 레코드 길이
							  , "MEMBER_USE_FIELD"  		// 제휴사 사용 영역
							  , "TRANSACTION_ID"            // TRANSACTION ID
							  , "FRANCHISE_ID"              // 가맹점ID
				              
							  , "REQ_YMDHMS"                // 요청일시
				              , "CARD_NO"                   // 선불카드 ID
							  , "ALIAS_NO"                  // Alias 번호
							  , "REGDEL_INFO"               // 등록/해제 정보
							  , "STUD_REQ_TP"               // 학생등록 구분
							  
							  , "FILLER"                    // FILLER
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}

	public HashMap<String, String> getParseSTOTOTRANCHKInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,3,5,5,1
					  ,1,1,3};
		String strHeaders[] = { "INQ_TYPE", "DATE_DDD", "TIME_SSSSS", "FCSTR_ID", "PAY_TP"
							  , "ITEM_GRP_CD", "ITEM_CD", "GAME_NTH"};
		
//		logger.info( "▶ getParseSTOTOTRANCHKInq-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
}
