package biz.cms_PURCARDSender;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

public class PURCARDSenderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(PURCARDSenderPollingAction.class);
	
	public static void main(String args[]) throws Exception {
		PURCARDSenderPollingAction action = new PURCARDSenderPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[0]]=" + args[1] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			if( cmd.length() != 2 ) return;
			
			if( cmd.charAt(0) == '1' ) {
				logger.info("start create file");
				System.out.println("creating PURCARD Payment tran file.");
				action.createPURCARDPAYTranFile();
			}
			
//			if( cmd.charAt(1) == '1' ) {
//				System.out.println("creating PURCARD Charge tran file.");
//				action.createPURCARDCHGTranFile();
//			}
			
			if( cmd.charAt(1) == '1' ) {
				System.out.println("transfering PURCARD tran files.");
				(new PURCARDSenderFileTransfer()).transferMST();
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		PURCARDSenderDAO dao = new PURCARDSenderDAO();
		List<Object> list = null;
		int totalCnt = 0;
		
		try {
			int ret = -1;
			
			// actionMode : 0-POLLING_PERIOD에 주기적으로 무조건 수행, 1-ACTION_TIME에 한 번 수행
			logger.info("actionMode[" + actionMode + "]");
//			System.out.println("actionMode[" + actionMode + "]" );	
			String stTime = (new SimpleDateFormat("HH")).format( new Date() );
			logger.info("stTime[" + stTime + "]");
			int iTime = COMMBiz.toInteger(stTime, 1);
			if (iTime < 11) return;
//			if( actionMode != "1" ) return;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String stdYmd = sdf.format(new Date());
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			//(금일 대사파일 생성 유무 조회)
			list = dao.selSVCFILEDAILY(stdYmd, "PCD", "01", com_cd);
			totalCnt = list.size();
			
//				System.out.println("totalCnt[" + totalCnt + "]" );	
			
			//금일 대사파일 생성 row가 없으면 생성
			if( totalCnt <= 0 ) {
				HashMap<String, String> hm = new HashMap<String, String>();
				hm.put("COM_CD", com_cd);
				hm.put("STD_YMD", stdYmd);
				hm.put("SVC_ID", "PCD");
				hm.put("CMD_TY", "00");
				
				ret = dao.insSVCFILEINFO(hm);
				
				System.out.println("ret[" + ret + "]" );	
					
				if( ret > 0 ) {
					createPURCARDPAYTranFile();
					Thread.sleep(50);
					
					try {
						(new PURCARDSenderFileTransfer()).transferMST();
					}catch(Exception e) {
						System.out.println("[ERROR]" + e.getMessage() );	
						logger.info("[ERROR]" + e.getMessage());
					}
					hm.put("CMD_TY", "01");
					ret = dao.updSVCFILEINFO(hm);
				}
			}

		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
			System.out.println("[ERROR]" + e.getMessage() );	
		}
	}
	
	public boolean createPURCARDPAYTranFile() {
		boolean bIsCreatedFile = false;
		
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			PURCARDSenderDAO dao = new PURCARDSenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			//String toDay = sdf.format(calendar.getTime());
			//calendar.setTime(sdf.parse(toDay));
			calendar.setTime(new Date());
			String curDate = sdf.format(calendar.getTime());
//			calendar.add(Calendar.DATE, -1);
//			String adjDate = sdf.format(calendar.getTime());
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
//			String withme_PURCARD_id = PropertyUtil.findProperty("service-property", "WITHME_PURCARD_ID"); //가맹점ID
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "PURCARD";
//			String card_key = PropertyUtil.findProperty("decode-key-property", "CARD_KEY");
//			String double_card_key = PropertyUtil.findProperty("double-decode-key-property", "CARD_KEY");
			
			String withme_corp_no = PropertyUtil.findProperty("service-property", "WITHME_CORP_NO");
			
			String JOB_TP = "WMPT";
			String strTRANFileNM = JOB_TP + curDate.substring(0,8) + ".txt"; //#### 확인
			
			list = null;
			list = dao.selPURCARDPAYTRAN(com_cd);
			int iPayCnt = list.size();
//			for(int i=0; i<=iPayCnt; i++){logger.info(list.get(i));
			logger.info("list[" + list + "]");

			for(int i = 0;i < iPayCnt;i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				if (i == 0){
					hmData.put("CRT_YMD", map.get("CRT_YMD"));
					hmData.put("CRT_CNT", StringUtil.lPad(String.valueOf(Integer.toString(iPayCnt)),5,"0"));
					hmData.put("FILLER1", "");
					logger.info("hmData " + i + " [" + hmData + "]");
					sbFile.append(makeDataOfPURCARDPAYCountFile(hmData));
					sbFile.append("\r\n");					
				}

				hmData.put("OFF_ID", "164893322");
				hmData.put("CARD_STR_ID", map.get("CARD_STR_ID"));
				hmData.put("MON_CNT", "0");
				hmData.put("CONF_AMT", StringUtil.lPad(String.valueOf(map.get("CONF_AMT")),18,"0"));
				hmData.put("YMD1", map.get("CARD_CONF_YMD"));
				hmData.put("YMD2", "");
				hmData.put("YMD3", "");
				hmData.put("CONT_ID", "000582");
				hmData.put("CODE", "");
				hmData.put("AMT", StringUtil.lPad(String.valueOf("0"),18,"0"));
				hmData.put("AMT2", StringUtil.lPad(String.valueOf("0"),18,"0"));

				
				System.out.println("hmData " + i + " [" + hmData + "]" );	


				logger.info("hmData " + i + " [" + hmData + "]");
				sbFile.append(makeDataOfPURCARDPAYFile(hmData));
				sbFile.append("\r\n");
			}

			// 거래내역 파일 생성                                                         
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRANFileNM);
			
		}catch(Exception e) {
			System.out.println("[ERROR]" + e);	
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
/*	
	public boolean createPURCARDCHGTranFile() {
		boolean bIsCreatedFile = false;
		
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			PURCARDSenderDAO dao = new PURCARDSenderDAO();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			//String toDay = sdf.format(calendar.getTime());
			//calendar.setTime(sdf.parse(toDay));
			calendar.setTime(new Date());
			String curDate = sdf.format(calendar.getTime());
			calendar.add(Calendar.DATE, -1);
			String adjDate = sdf.format(calendar.getTime());
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "PURCARD";
			
//			list = dao.getWITHMEBizCoNo(com_cd);
//			String strWithMeBizCoNo = (String)((Map<String, String>)list.get(0)).get("BIZCO_NO");
			
			//승인요청전문 		:L3TR####	WMLT
			
			String JOB_TP = "WMLT";
			String strTRANFileNM = JOB_TP + curDate; //######## 확인
			
			list = null;
			list = dao.selPURCARDCHGTRAN(com_cd);
			int iChgCnt = list.size();
			
			for(int i = 0;i < iChgCnt;i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				hmData.put("CRT_YMD", map.get("CRT_YMD"));
				hmData.put("CARD_STR_ID", map.get("CARD_STR_ID"));
				hmData.put("CONF_YMD", map.get("CONF_YMD"));
				
				hmData.put("CONF_AMT", map.get("CONF_AMT"));
				hmData.put("CODE", map.get("CODE")); 
				hmData.put("AMT", map.get("AMT")); 
				hmData.put("AMT2", map.get("AMT2")); 
				
				sbFile.append(makeDataOfPURCARDTRANFile(hmData));
			}
			
			// 거래내역 파일 생성
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRANFileNM);
			
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRANFileNM);
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					if("03".equals((String)map.get("PURCARD_TRAN_TP"))){
						dao.updPURCARDCHGTRAN_2("1", (String)map.get("COM_CD"), (String)map.get("TRAN_ID"));
					}else{
						dao.updPURCARDCHGTRAN("1", (String)map.get("COM_CD"), (String)map.get("TRAN_ID"));
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
*/	
	private String makeDataOfPURCARDPAYCountFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {8,5,103};
		String strHeaders[] = {
				"CRT_YMD",
				"CRT_CNT",
				"FILLER1"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info(i+":"+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		System.out.println(sb.toString());
		logger.info(sb.toString());
		return sb.toString();
	}
	
	private String makeDataOfPURCARDPAYFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {12,11,5
				      ,18,8,8,8,6
				      ,4,18,18};
		String strHeaders[] = {
				"OFF_ID",
				"CARD_STR_ID",
				"MON_CNT",
				"CONF_AMT",
				"YMD1",
				"YMD2",
				"YMD3",
				"CONT_ID",
				"CODE", 
				
				"AMT", 
				"AMT2"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info(i+":"+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		System.out.println(sb.toString());
		logger.info(sb.toString());
		return sb.toString();
	}
/*	
	private String makeDataOfPURCARDTRANFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {8,11,8,18,2
					  ,18,18};
		String strHeaders[] = {
				"CRT_YMD",      
				"CARD_STR_ID",      
				"CONF_YMD",       
				"CONF_AMT",   
				"CODE",    
				
				"AMT",    
				"AMT2"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {		
//			logger.info(i+":"+(String) hm.get(strHeaders[i].toString()));
//			System.out.println(strHeaders[i].toString()+"="+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
*/	
	/*
	private String makeTailerOfPURCARDTranFile(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,8,8,7,425,	1};
		String strHeaders[] = {
			"RECORD_TP",       
			"FILE_NM",         
			"FILE_DT",         
			"SEND_CNT",        
			"FILLER",
			
			"MARK"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {			
//			System.out.println(strHeaders[i].toString()+"="+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	*/
}
