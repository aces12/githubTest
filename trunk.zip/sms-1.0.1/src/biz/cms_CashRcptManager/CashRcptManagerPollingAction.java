package biz.cms_CashRcptManager;

import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import sun.misc.BASE64Decoder;

import com.cyberpass.seed.Seed;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;

public class CashRcptManagerPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(CashRcptManagerPollingAction.class);
	
	public enum MessageID {
		MID_CASH0200("CASH0200"), MID_CASH0400("CASH0400"), MID_CASH0500("CASH0500"), MID_CASH0600("CASH0600");
		
		public String msgID;
		MessageID(String msgID) {
			this.msgID = msgID;
		}
		String getID() {
			return this.msgID;
		}
	}

	public static void main(String args[]) throws Exception {

//		logger.info("main" );
//		String path          = "D:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
//		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);		
//		String cmd			 = "00010"; //nvl(args[1].replaceFirst("-cmd:" , ""));
//		String store_cd		 = "%"; //nvl(args[2].replaceFirst("-store:", ""));
//		String beforedays	 = "150"; //nvl(args[3].replaceFirst("-day:", ""));
//		CashRcptManagerPollingAction action = new CashRcptManagerPollingAction();
//		logger.info("main" );
		
		CashRcptManagerPollingAction action = new CashRcptManagerPollingAction();
		if( args == null || args.length < 1 ) {
			logger.info("------ master main args null");
		}
		logger.info("[DEBUG] [args[0]]=" + args[0] );
		
		String path          = nvl(args[0].replaceFirst("-path:"  ,""));
		String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));
		String store_cd		 = nvl(args[2].replaceFirst("-store:", ""));
		String beforedays	 = nvl(args[3].replaceFirst("-day:", ""));
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		
		if( cmd.length() != 5 ) return;
		
		if( cmd.charAt(0) == '1' ) {
			logger.info("Get approval NO bands" );
			action.getBands();
		}
		if( cmd.charAt(1) == '1' ) {
			logger.info("Transfer acting approval list" );
			logger.info("This daemon  cant polling action" );
			//action.transferActingApprovalTran();
		}
		if( cmd.charAt(2) == '1' ) {
			logger.info("Transfer adjustment report" );
			action.transferAdjReport(store_cd);
		}
		if( cmd.charAt(3) == '1' ) {
			logger.info("called Execute() this daemon cant polling action");
			//action.execute("0");
		}
		if( cmd.charAt(4) == '1' ) {
			logger.info("standard is day to transfer");
			action.transferSpecAdjReport(store_cd, Integer.parseInt(beforedays));
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}  
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		CashRcptManagerDAO dao = new CashRcptManagerDAO();
		List<Object> list = null;
		int totalCnt = 0;
		
		try {
			int ret = -1;
			
			// actionMode : 0-POLLING_PERIOD에 주기적으로 무조건 수행, 1-ACTION_TIME에 한 번 수행
			if( actionMode == "1" ) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String stdYmd = sdf.format(new Date());
				String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
				
				//(금일 승인번호관리/정산내역 유무 조회)
				list = dao.selSVCFILEDAILY(stdYmd, "SCR", "00", com_cd);
				totalCnt = list.size();
				
				if( totalCnt <= 0 ) {
					HashMap<String, String> hm = new HashMap<String, String>();
					hm.put("COM_CD", com_cd);
					hm.put("STD_YMD", stdYmd);
					hm.put("SVC_ID", "SCR");
					hm.put("CMD_TY", "00");
					
					ret = dao.insSVCFILEINFO(hm);
					
					if( ret > 0 ) {					
						this.getBands();
						Thread.sleep(50);
						
						this.transferAdjReport("%");
					}
				}
			}else if( actionMode == "0") {
				//this.transferActingApprovalTran();
			}
		}catch(Exception e) {
			logger.info("[ERROR]:execute:" + e.getMessage());
		}
	}
	
	private ActionSocket connectServer(MessageID MsgID) {
		String server_ip = "";
		int server_port = 0;
		
		ActionSocket actSock = null;
		Socket extClntSock = null;
		
		try {
			server_ip = PropertyUtil.findProperty("communication-property", "CASHRCPT_SERVER_IP");
			server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CASHRCPT_SERVER_PORT"));
			
			extClntSock = new Socket(server_ip, server_port);
			
			if( MsgID == MessageID.MID_CASH0600) {
				actSock = new ActionSocket(extClntSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHRCPT_EXT_FILTER)));
			}else {
				actSock = new ActionSocket(extClntSock, (Filter)(new COMMConveyerFilter(COMMBiz.CASHRCPT_FILTER)));
			}
		}catch(Exception e) {
			actSock.close();
			actSock = null;
			logger.info("[DEBUG] " + e.getMessage());
		}
		
		return actSock;
	}
	
	private String makeGWHeader(MessageID MsgID) {
		StringBuffer sb = new StringBuffer();
		
		String CASH_MSG_LEN = "";
		String CASH_MSG_ID = "";
		
		if( MsgID == MessageID.MID_CASH0200 ) {			// 대행승인내역전송
			CASH_MSG_LEN = "00316";
			CASH_MSG_ID = "SCCSAGENT";
		}else if( MsgID == MessageID.MID_CASH0400 ) {	// 재전송
			CASH_MSG_LEN = "00316";
			CASH_MSG_ID = "SCCSRETRY";
		}else if( MsgID == MessageID.MID_CASH0500 ) {	// 정산
			CASH_MSG_LEN = "00256";
			CASH_MSG_ID = "SCCSCALC";
		}else if( MsgID == MessageID.MID_CASH0600 ) {	// 승인번호관리
			CASH_MSG_LEN = "00288";
			CASH_MSG_ID = "SCCSAUTHNO";
		}
		
		sb.append(CASH_MSG_LEN);
		sb.append(String.format("%-15s", CASH_MSG_ID));
		
		return sb.toString();
	}
	
	private String makeCommonHeader(MessageID MsgID) {
		return (this.makeCommonHeader(MsgID, null));
	}
	
	private String makeCommonHeader(MessageID MsgID, Map<String, String> map) {
		HashMap<String, String> hm = new HashMap<String, String>();
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 8, 6, 2, 8, 8
					  , 6, 3, 10, 4, 4
					  , 8, 9, 2, 4, 32
					  , 8, 6, 18, 6, 4
					  , 4};
		String strHeaders[] = { "MSG_ID", "MSG_LEN", "MSG_PATH", "SALE_DATE", "SYS_DATE"
							  , "SYS_TIME", "CMP_TYPE", "CMP_NO", "JUMPO_NO", "JUMPO_SER_NO"
							  , "SEQ_NO", "APPROVAL_NO", "APPROVAL_FLAG", "ERROR_CODE", "ERROR_MSG"
							  , "SCCS_DATE", "SCCS_TIME", "JUMPO_INFO", "ORI_SALE_DATE", "ORI_POS_NO"
							  , "ORI_TRAN_NO"};
		
		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		calendar.setTime(new Date());
		String sys_ymdhms = sdf.format(calendar.getTime());
		
		if( MsgID == MessageID.MID_CASH0200 ) {			// 대행승인내역전송
			hm.put(strHeaders[0], MsgID.getID());											//전문ID(CASH0200)
			hm.put(strHeaders[1], "000316");												//전문Length
			hm.put(strHeaders[2], "SC");													//전문경로
			hm.put(strHeaders[3], (String)map.get("TRAN_YMD"));								//영업일자
			hm.put(strHeaders[4], (String)map.get("SYS_DATE"));								//승인시스템일자
			hm.put(strHeaders[5], (String)map.get("SYS_TIME"));								//승인시스템시각
			hm.put(strHeaders[6], "110");													//회사구분
			hm.put(strHeaders[7], " ");														//사업자등록번호
			hm.put(strHeaders[8], (String)map.get("JUMPO_NO"));								//점포번호
			hm.put(strHeaders[9], (String)map.get("JUMPO_SER_NO"));							//점포서버번호(POS번호)
			hm.put(strHeaders[10], String.format("%08d", Integer.parseInt((String)map.get("SEQ_NO"))));		//전문순번
			hm.put(strHeaders[11], (String)map.get("APPROVAL_NO"));							//현금영수증승인번호
			hm.put(strHeaders[12], "00");													//직승인 지시 flag
			hm.put(strHeaders[13], " ");													//에러코드
			hm.put(strHeaders[14], " ");													//에러메시지
			hm.put(strHeaders[15], " ");													//현금영수증서버 시스템일자
			hm.put(strHeaders[16], " ");													//현금영수증서버 시스템시간
			hm.put(strHeaders[17], " ");													//요청자 정보
			hm.put(strHeaders[18], (String)map.get("ORI_SALE_DATE").substring(2, 8));		//원영업일자
			hm.put(strHeaders[19], (String)map.get("ORI_POS_NO"));							//원포스번호
			hm.put(strHeaders[20], (String)map.get("ORI_TRAN_NO"));							//원거래번호
		}else if( MsgID == MessageID.MID_CASH0400 ) {	// 재전송
			hm.put(strHeaders[0], MsgID.getID());											//전문ID(CASH0200)
			hm.put(strHeaders[1], "000316");												//전문Length
			hm.put(strHeaders[2], "SC");													//전문경로
			hm.put(strHeaders[3], (String)map.get("TRAN_YMD"));								//영업일자
			hm.put(strHeaders[4], (String)map.get("SYS_DATE"));								//승인시스템일자
			hm.put(strHeaders[5], (String)map.get("SYS_TIME"));								//승인시스템시각
			hm.put(strHeaders[6], "110");													//회사구분
			hm.put(strHeaders[7], " ");														//사업자등록번호
			hm.put(strHeaders[8], (String)map.get("JUMPO_NO"));								//점포번호
			hm.put(strHeaders[9], (String)map.get("JUMPO_SER_NO"));							//점포서버번호(POS번호)
			hm.put(strHeaders[10], String.format("%08d", Integer.parseInt((String)map.get("SEQ_NO"))));		//전문순번
			hm.put(strHeaders[11], (String)map.get("APPROVAL_NO"));							//현금영수증승인번호
			hm.put(strHeaders[12], "00");													//직승인 지시 flag
			hm.put(strHeaders[13], " ");													//에러코드
			hm.put(strHeaders[14], " ");													//에러메시지
			hm.put(strHeaders[15], " ");													//현금영수증서버 시스템일자
			hm.put(strHeaders[16], " ");													//현금영수증서버 시스템시간
			hm.put(strHeaders[17], " ");													//요청자 정보
			hm.put(strHeaders[18], (String)map.get("ORI_SALE_DATE").substring(2, 8));		//원영업일자
			hm.put(strHeaders[19], (String)map.get("ORI_POS_NO"));							//원포스번호
			hm.put(strHeaders[20], (String)map.get("ORI_TRAN_NO"));							//원거래번호
		}else if( MsgID == MessageID.MID_CASH0500 ) {	// 정산
			hm.put(strHeaders[0], MsgID.getID());											//전문ID(CASH0500)
			hm.put(strHeaders[1], "000256");												//전문Length
			hm.put(strHeaders[2], "SC");													//전문경로
			hm.put(strHeaders[3], (String)map.get("TRAN_YMD"));								//영업일자
			hm.put(strHeaders[4], (String)map.get("TRAN_YMD"));								//승인시스템일자
			hm.put(strHeaders[5], sys_ymdhms.substring(8, 14));								//승인시스템시각
			hm.put(strHeaders[6], "110");													//회사구분
			hm.put(strHeaders[7], " ");														//사업자등록번호
			hm.put(strHeaders[8], ((String)map.get("CASHIER_NO")).substring(1, 5));			//점포번호
			hm.put(strHeaders[9], ((String)map.get("CASHIER_NO")).substring(0, 1) + "001");	//점포서버번호(POS번호)
			hm.put(strHeaders[10], String.format("%08d", Integer.parseInt((String)map.get("SEQ_NO"))));		//전문순번
			hm.put(strHeaders[11], " ");													//현금영수증승인번호
			hm.put(strHeaders[12], "00");													//직승인 지시 flag
			hm.put(strHeaders[13], " ");													//에러코드
			hm.put(strHeaders[14], " ");													//에러메시지
			hm.put(strHeaders[15], " ");													//현금영수증서버 시스템일자
			hm.put(strHeaders[16], " ");													//현금영수증서버 시스템시간
			hm.put(strHeaders[17], " ");													//요청자 정보
			hm.put(strHeaders[18], " ");													//원영업일자
			hm.put(strHeaders[19], " ");													//원포스번호
			hm.put(strHeaders[20], " ");													//원거래번호
		}else if( MsgID == MessageID.MID_CASH0600 ) {	// 승인번호관리
			hm.put(strHeaders[0], MsgID.getID());											//전문ID(CASH0600)
			hm.put(strHeaders[1], "000288");												//전문Length
			hm.put(strHeaders[2], "SC");													//전문경로
			hm.put(strHeaders[3], sys_ymdhms.substring(0, 8));								//영업일자
			hm.put(strHeaders[4], sys_ymdhms.substring(0, 8));								//승인시스템일자
			hm.put(strHeaders[5], sys_ymdhms.substring(8, 14));								//승인시스템시각
			hm.put(strHeaders[6], "110");													//회사구분
			hm.put(strHeaders[7], " ");														//사업자등록번호
			hm.put(strHeaders[8], "0001");													//점포번호
			hm.put(strHeaders[9], "0001");													//점포서버번호(POS번호)
			hm.put(strHeaders[10], " ");													//전문순번
			hm.put(strHeaders[11], " ");													//현금영수증승인번호
			hm.put(strHeaders[12], " ");													//직승인 지시 flag
			hm.put(strHeaders[13], " ");													//에러코드
			hm.put(strHeaders[14], " ");													//에러메시지
			hm.put(strHeaders[15], " ");													//현금영수증서버 시스템일자
			hm.put(strHeaders[16], " ");													//현금영수증서버 시스템시간
			hm.put(strHeaders[17], " ");													//요청자 정보
			hm.put(strHeaders[18], " ");													//원영업일자
			hm.put(strHeaders[19], " ");													//원포스번호
			hm.put(strHeaders[20], " ");													//원거래번호
		}
		
		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info(" >>>>> " + strHeaders[i].toString() + "=" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeAdjReport(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 6, 7, 10
					  , 7, 10, 50 };
		String strHeaders[] = { "TRAN_TYPE", "POS_NO", "CASHIER_NO", "VALID_SALE_CNT", "VALID_SALE_AMT"
					 		  , "RETURN_SALE_CNT", "RETURN_SALE_AMT", "FILLER" };
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeActingApprovalTran(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 4, 6, 9
					  , 9, 9, 9, 1, 20
					  , 1, 6, 9, 1, 1
					  , 5, 3, 50, 7};
		String strHeaders[] = { "TRAN_TYPE", "POS_NO", "TRAN_NO", "CASHIER_NO", "AMOUNT"
							  , "TAX_CHARGE", "SERVICE_CHARGE", "GRAND_TOTAL", "TRAN_KIND", "PERSONAL_INFO"
							  , "MANUAL_YN", "ORG_SYS_DATE", "ORG_APPROVAL_NO", "CANCEL_TYPE", "MASKING_FLAG" 
							  , "FILLER" , "ITEM_KIND", "PERSONAL_INFO_ENC", "FILLER"};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info(" >>>>> " + strHeaders[i].toString() + "=" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeActingApprovalTran_NEW(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 4, 4, 6, 9
					  , 9, 9, 9, 1, 20
					  , 1, 6, 9, 1, 1
					  , 1, 4, 3, 50, 7};
		String strHeaders[] = { "TRAN_TYPE", "POS_NO", "TRAN_NO", "CASHIER_NO", "AMOUNT"
							  , "TAX_CHARGE", "SERVICE_CHARGE", "GRAND_TOTAL", "TRAN_KIND", "PERSONAL_INFO"
							  , "MANUAL_YN", "ORG_SYS_DATE", "ORG_APPROVAL_NO", "CANCEL_TYPE", "MASKING_FLAG" 
							  , "MUNWHA_FLAG", "FILLER" , "ITEM_KIND", "PERSONAL_INFO_ENC", "FILLER"};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info(" >>>>> " + strHeaders[i].toString() + "=" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	private String makeApprovalNoManagementData(HashMap<String, String> hm, String tranType) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 9, 9, 8, 40
					  , 40, 20 };
		String strHeaders[] = { "TRAN_TYPE", "APPROVAL_START_NO", "APPROVAL_END_NO", "APPLY_DATE", "NTA_STATEMENT1"
						  	  , "NTA_STATEMENT2", "FILLER" };
		
		hm.put(strHeaders[0], tranType);													//거래구분
		hm.put(strHeaders[1], hm.get(strHeaders[1]));										//대행승인 시작번호
		hm.put(strHeaders[2], hm.get(strHeaders[2]));										//대행승인 종료번호
		hm.put(strHeaders[3], hm.get(strHeaders[3]));										//대행승인 적용시작일
		hm.put(strHeaders[4], hm.get(strHeaders[4]));										//안내문구1
		hm.put(strHeaders[5], hm.get(strHeaders[5]));										//안내문구2
		hm.put(strHeaders[6], hm.get(strHeaders[6]));										//filler
		
		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info(" >>>>> " + strHeaders[i].toString() + "=" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public void transferSpecAdjReport(String store_cd, int day) {
		CashRcptManagerDAO dao = new CashRcptManagerDAO();
		List<Object> list = null;
		int ret = -1;
		
		try {
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			list = dao.selCASHRCPTSPECADJTRPT(com_cd, store_cd, day);
			
			for(int i = 0;i < list.size();i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				try {
					this.sendSpecAdjReport(com_cd, map, day);
				}catch(Exception e) {
					logger.info("[ERROR]:" + e.getMessage());
				}
				Thread.sleep(50);
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
		}
	}
	
	public void transferAdjReport(String store_cd) {
		CashRcptManagerDAO dao = new CashRcptManagerDAO();
		List<Object> list = null;
		int ret = -1;
		
		try {
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			list = dao.selCASHRCPTADJTRPT(com_cd, store_cd);
//			logger.info("list[" + list + "]");
			
			for(int i = 0;i < list.size();i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				try {
//					logger.info("map[" + map + "]");
					this.sendAdjReport(com_cd, map);
				}catch(Exception e) {
					logger.info("[ERROR]:" + e.getMessage());
				}
				Thread.sleep(50);
			}
		}catch(Exception e) {
			logger.info("[ERROR]:transferAdjReport:" + e.getMessage());
		}
	}
	
	/*public void transferActingApprovalTran() {
		CashRcptManagerDAO dao = new CashRcptManagerDAO();
		List<Object> list = null;
		int ret = -1;
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("MMddHHmmss");
			String proc_ymdhms = sdf.format(new Date()) + (Double.toString(Math.random())).substring(2, 6);
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String local_no_crct = PropertyUtil.findProperty("communication-property", "LOCAL_SERVER_NO");
			// 현금영수증 TRAN에 대상 정보 기록 및 기록된 TRAN 조회			
			ret = dao.updCASHRCPTTRAN(com_cd, proc_ymdhms,local_no_crct);
			 
			//logger.info("updated rows=" + Integer.toString(ret));
			
			if( ret > 0 ) {
				// 대상 정보 기록된 TRAN 조회						
				list = dao.selCASHRCPTTRAN(com_cd, proc_ymdhms , local_no_crct);							
//				logger.info("selCASHRCPTTRAN rows=" + Integer.toString(list.size()));
				
				for(int i = 0;i < list.size();i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					try {
						this.sendActingApprovalTran(com_cd, map, MessageID.MID_CASH0200);
					}catch(Exception e) {
						logger.info("[ERROR]:" + e.getMessage());
						dao.updSSGMONEYTRAN_RESET("9", map);
					}
					Thread.sleep(50);
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]:transferActingApprovalTran:" + e.getMessage());
		}
	}*/
	
	public void sendSpecAdjReport(String com_cd, Map<String, String> map, int day) throws Exception {
		CashRcptManagerDAO dao = new CashRcptManagerDAO();
		ActionSocket actSock = null;
		
		HashMap<String, String> hm = new HashMap<String, String>();
		
		String sendMsg = "";
		String recvBuf = "";
		
		String strDataID[] = { "TRAN_TYPE", "POS_NO", "CASHIER_NO", "VALID_SALE_CNT", "VALID_SALE_AMT"
							 , "RETURN_SALE_CNT", "RETURN_SALE_AMT", "FILLER" };
		
		try {
			actSock = connectServer(MessageID.MID_CASH0500);
			
			hm.put(strDataID[0], "01");
			hm.put(strDataID[1], "0001");
			hm.put(strDataID[2], (String)map.get("CASHIER_NO"));
			hm.put(strDataID[3], String.format("%07d", Integer.parseInt((String)map.get("NORMAL_CNT"))));
			hm.put(strDataID[4], String.format("%010d", Integer.parseInt((String)map.get("NORMAL_TOT_AMT"))));
			hm.put(strDataID[5], String.format("%07d", Integer.parseInt((String)map.get("REFUND_CNT"))));
			hm.put(strDataID[6], String.format("%010d", Integer.parseInt((String)map.get("REFUND_TOT_AMT"))));
			hm.put(strDataID[7], " ");
			
			sendMsg = makeGWHeader(MessageID.MID_CASH0500)
					+ makeCommonHeader(MessageID.MID_CASH0500, map)
					+ makeAdjReport(hm);
			
			logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "][" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "] ERROR");
			}
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<ssg] RECV[" + recvBuf.getBytes().length + "][" + recvBuf + "]");
			
			// 0000:정상, 1010:정산횟수 오류
			if( !(recvBuf.substring(78, 82)).equals("0000") && !(recvBuf.substring(78, 82)).equals("1010") ) {
				actSock.close();
				actSock = null;
				
				List<Object> list = null;
				List<Object> listMsgID = null;
				list = dao.selCASHRCPTTRAN_RETRANS_SPEC(com_cd, ((String)map.get("CASHIER_NO")).substring(0, 5), day);
				
				for(int i = 0;i < list.size();i++) {
					listMsgID = dao.selCASHRCPTMSGID();
					Map<String, String> mSeq = (Map<String, String>)listMsgID.get(0);
					Map<String, String> m = (Map<String, String>)list.get(i);
					m.put("SEQ_NO", (String)mSeq.get("SEQ_NO"));
					try {
						this.sendActingApprovalTran(com_cd, m, MessageID.MID_CASH0400);
					}catch(Exception e) {
						logger.info("[ERROR]:" + e.getMessage());
					}
					Thread.sleep(50);
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]:sendSpecAdjReport:"+e.getMessage());
			throw e;
		}finally {
			actSock.close();
			actSock = null;
		}
	}
	
	public void sendAdjReport(String com_cd, Map<String, String> map) throws Exception {
		CashRcptManagerDAO dao = new CashRcptManagerDAO();
		ActionSocket actSock = null;
		
		HashMap<String, String> hm = new HashMap<String, String>();
		
		String sendMsg = "";
		String recvBuf = "";
//		logger.info("sendAdjReport map[" + map + "]");
		
		String strDataID[] = { "TRAN_TYPE", "POS_NO", "CASHIER_NO", "VALID_SALE_CNT", "VALID_SALE_AMT"
							 , "RETURN_SALE_CNT", "RETURN_SALE_AMT", "FILLER" };
		
		try {
			actSock = connectServer(MessageID.MID_CASH0500);
			
			hm.put(strDataID[0], "01");
			hm.put(strDataID[1], "0001");
			hm.put(strDataID[2], (String)map.get("CASHIER_NO"));
			hm.put(strDataID[3], String.format("%07d", Integer.parseInt((String)map.get("NORMAL_CNT"))));
			hm.put(strDataID[4], String.format("%010d", Integer.parseInt((String)map.get("NORMAL_TOT_AMT"))));
			hm.put(strDataID[5], String.format("%07d", Integer.parseInt((String)map.get("REFUND_CNT"))));
			hm.put(strDataID[6], String.format("%010d", Integer.parseInt((String)map.get("REFUND_TOT_AMT"))));
			hm.put(strDataID[7], " ");
			logger.info("sendAdjReport hm[" + hm + "]");
			
			sendMsg = makeGWHeader(MessageID.MID_CASH0500)
					+ makeCommonHeader(MessageID.MID_CASH0500, map)
					+ makeAdjReport(hm);
			
			logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "][" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "] ERROR");
			}
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<ssg] RECV[" + recvBuf.getBytes().length + "][" + recvBuf + "]");
			
			// 0000:정상, 1010:정산횟수 오류
			if( !(recvBuf.substring(78, 82)).equals("0000") && !(recvBuf.substring(78, 82)).equals("1010") ) {
				actSock.close();
				actSock = null;
				
				List<Object> list = null;
				List<Object> listMsgID = null;
				list = dao.selCASHRCPTTRAN_RETRANS(com_cd, ((String)map.get("CASHIER_NO")).substring(0, 5));
				
				for(int i = 0;i < list.size();i++) {
					listMsgID = dao.selCASHRCPTMSGID();
					Map<String, String> mSeq = (Map<String, String>)listMsgID.get(0);
					Map<String, String> m = (Map<String, String>)list.get(i);
					m.put("SEQ_NO", (String)mSeq.get("SEQ_NO"));
					try {
						this.sendActingApprovalTran(com_cd, m, MessageID.MID_CASH0400);
					}catch(Exception e) {
						logger.info("[ERROR]:" + e.getMessage());
					}
					Thread.sleep(50);
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]:sendAdjReport:"+e.getMessage());
			throw e;
		}finally {
			actSock.close();
			actSock = null;
		}
	}
	
	public void sendActingApprovalTran(String com_cd, Map<String, String> map, MessageID msgID) throws Exception {
		CashRcptManagerDAO dao = new CashRcptManagerDAO();
		ActionSocket actSock = null;
		
		HashMap<String, String> hm = new HashMap<String, String>();
		
		String sendMsg = "";
		String recvBuf = "";
		String personal_info = null;
        String decrypt_key = null;
//        logger.info("sendActingApprovalTran map[" + map + "]");
		
		String strDataID[] = { "TRAN_TYPE", "POS_NO", "TRAN_NO", "CASHIER_NO", "AMOUNT"
							 , "TAX_CHARGE", "SERVICE_CHARGE", "GRAND_TOTAL", "TRAN_KIND", "PERSONAL_INFO"
							 , "MANUAL_YN", "ORG_SYS_DATE", "ORG_APPROVAL_NO", "CANCEL_TYPE", "MASKING_FLAG" 
							  , "FILLER" , "ITEM_KIND", "PERSONAL_INFO_ENC", "FILLER" };
		
		String strDataID_NEW[] = { "TRAN_TYPE", "POS_NO", "TRAN_NO", "CASHIER_NO", "AMOUNT"
				 				 , "TAX_CHARGE", "SERVICE_CHARGE", "GRAND_TOTAL", "TRAN_KIND", "PERSONAL_INFO"
				 				 , "MANUAL_YN", "ORG_SYS_DATE", "ORG_APPROVAL_NO", "CANCEL_TYPE", "MASKING_FLAG" 
				 				 , "FILLER" , "ITEM_KIND", "PERSONAL_INFO_ENC", "FILLER", "MUNWHA_FLAG" };
		try {
			Seed seed = Seed.getInstance("CBC/PKCS5Padding");
			String keyData = PropertyUtil.findProperty("service-property", "KEY_DATA");
//			logger.info("keyData[" + keyData + "]");
			String ivData = PropertyUtil.findProperty("service-property", "IV_DATA");
//			logger.info("ivData[" + ivData + "]");
			
	        String sDoubleKey = PropertyUtil.findProperty("double-decode-key-property", "CASH_IF_KEY");
//			logger.info("sDoubleKey[" + sDoubleKey + "]");
	        String sKey = PropertyUtil.findProperty("decode-key-property", "CASH_IF_KEY");
//			logger.info("sKey[" + sKey + "]");
	        String sInitVector = PropertyUtil.findProperty("decode-key-property", "INITVECTOR");
//			logger.info("sInitVector[" + sInitVector + "]");
	        
			seed.setKey(keyData.getBytes());
			seed.setIV(ivData.getBytes());
			BASE64Decoder decoder = new BASE64Decoder();
			
			if(!"".equals((String)map.get("PERSONAL_INFO")) && (String)map.get("PERSONAL_INFO") != null){
				personal_info = new String(seed.decrypt(decoder.decodeBuffer((String)map.get("PERSONAL_INFO"))));
			}else{
				personal_info = "0100001234";
			}
			
//            logger.info("personal_info[" + personal_info + "]");
            decrypt_key = COMMBiz.aesDecryptCbc(sDoubleKey, sKey, sInitVector);
//            logger.info("decrypt_key[" + decrypt_key + "]");
            String encrypt_personal_info = COMMBiz.aesEncryptCbc(decrypt_key, personal_info, sInitVector);
//            logger.info("encrypt_personal_info[" + encrypt_personal_info + "]");
			
//			actSock = connectServer(MessageID.MID_CASH0200);
			actSock = connectServer(msgID);
			
			//20180607 KSN 도서/문화비 대응
			String sysDate = (String)map.get("SYS_DATE");
			if("20180701".compareTo(sysDate) <= 0){
				hm.put(strDataID_NEW[0], (String)map.get("TRAN_TYPE"));
				hm.put(strDataID_NEW[1], (String)map.get("POS_NO"));
				hm.put(strDataID_NEW[2], (String)map.get("TRAN_NO"));
				hm.put(strDataID_NEW[3], (String)map.get("CASHIER_NO"));
				hm.put(strDataID_NEW[4], String.format("%09d", Integer.parseInt((String)map.get("AMOUNT"))));
				hm.put(strDataID_NEW[5], String.format("%09d", Integer.parseInt((String)map.get("TAX_CHARGE"))));
				hm.put(strDataID_NEW[6], String.format("%09d", Integer.parseInt((String)map.get("SERVICE_CHARGE"))));
				hm.put(strDataID_NEW[7], String.format("%09d", Integer.parseInt((String)map.get("GRAND_TOTAL"))));
				hm.put(strDataID_NEW[8], (String)map.get("TRAN_KIND"));
				hm.put(strDataID_NEW[9], " ");
				hm.put(strDataID_NEW[10],(String)map.get("MANUAL_YN"));
				hm.put(strDataID_NEW[11], ((String)map.get("ORG_SYS_DATE")).length() == 8 ? (String)map.get("ORG_SYS_DATE").substring(2, 8) : "");
				hm.put(strDataID_NEW[12], (String)map.get("ORG_APPROVAL_NO"));
				hm.put(strDataID_NEW[13], (String)map.get("CANCEL_TYPE"));
				hm.put(strDataID_NEW[14], " ");
				hm.put(strDataID_NEW[15], " ");
				hm.put(strDataID_NEW[16], "ENC");
				hm.put(strDataID_NEW[17], encrypt_personal_info.trim());
				hm.put(strDataID_NEW[18], " ");
				hm.put(strDataID_NEW[19], (String)map.get("MUNWHA_FLAG"));
//				logger.info("hm[" + hm + "]");
				
				sendMsg = makeGWHeader(msgID)
						+ makeCommonHeader(msgID, map) 
						+ makeActingApprovalTran_NEW(hm);
			}else{
				hm.put(strDataID[0], (String)map.get("TRAN_TYPE"));
				hm.put(strDataID[1], (String)map.get("POS_NO"));
				hm.put(strDataID[2], (String)map.get("TRAN_NO"));
				hm.put(strDataID[3], (String)map.get("CASHIER_NO"));
				hm.put(strDataID[4], String.format("%09d", Integer.parseInt((String)map.get("AMOUNT"))));
				hm.put(strDataID[5], String.format("%09d", Integer.parseInt((String)map.get("TAX_CHARGE"))));
				hm.put(strDataID[6], String.format("%09d", Integer.parseInt((String)map.get("SERVICE_CHARGE"))));
				hm.put(strDataID[7], String.format("%09d", Integer.parseInt((String)map.get("GRAND_TOTAL"))));
				hm.put(strDataID[8], (String)map.get("TRAN_KIND"));
				hm.put(strDataID[9], " ");
				hm.put(strDataID[10],(String)map.get("MANUAL_YN"));
				hm.put(strDataID[11], ((String)map.get("ORG_SYS_DATE")).length() == 8 ? (String)map.get("ORG_SYS_DATE").substring(2, 8) : "");
				hm.put(strDataID[12], (String)map.get("ORG_APPROVAL_NO"));
				hm.put(strDataID[13], (String)map.get("CANCEL_TYPE"));
				hm.put(strDataID[14], " ");
				hm.put(strDataID[15], " ");
				hm.put(strDataID[16], "ENC");
				hm.put(strDataID[17], encrypt_personal_info.trim());
				hm.put(strDataID[18], " ");
//				logger.info("hm[" + hm + "]");
				
				sendMsg = makeGWHeader(msgID)
						+ makeCommonHeader(msgID, map) 
						+ makeActingApprovalTran(hm);
			}
			
			logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "][" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "] ERROR");
			}
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<ssg] RECV[" + recvBuf.getBytes().length + "][" + recvBuf + "]");
			
			if( msgID == MessageID.MID_CASH0200 ) {
				if( !(recvBuf.substring(78, 82)).equals("0000") ) {
					dao.updSSGMONEYTRAN_RESET("9", map);
				}else {
					dao.updSSGMONEYTRAN_RESET("1", map);
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]:"+e.getMessage());
			throw e;
		}finally {
			actSock.close();
			actSock = null;
		}
	}
	
	public void getBands() {
		CashRcptManagerDAO dao = new CashRcptManagerDAO();
		ActionSocket actSock = null;
		
		HashMap<String, String> hm = new HashMap<String, String>();
		
		String sendMsg = "";
		String recvBuf = "";
		String com_cd = "1002";
		
		String strDataID[] = { "TRAN_TYPE", "APPROVAL_START_NO", "APPROVAL_END_NO", "APPLY_DATE", "NTA_STATEMENT1"
			  	  			 , "NTA_STATEMENT2", "FILLER" };
		try {
			com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			actSock = connectServer(MessageID.MID_CASH0600);
			
			hm.put(strDataID[1], " ");		//대행승인 시작번호
			hm.put(strDataID[2], " ");		//대행승인 종료번호
			hm.put(strDataID[3], " ");		//대행승인 적용시작일
			hm.put(strDataID[4], " ");		//안내문구1
			hm.put(strDataID[5], " ");		//안내문구2
			hm.put(strDataID[6], " ");		//filler
			
			sendMsg = makeGWHeader(MessageID.MID_CASH0600)
					+ makeCommonHeader(MessageID.MID_CASH0600)
					+ makeApprovalNoManagementData(hm, "00");	// 00:승인번호요청
			logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "][" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "] ERROR");
			}
			recvBuf = ((String)actSock.receive());
			logger.info("[sms<ssg] RECV[" + recvBuf.getBytes().length + "][" + recvBuf + "]");
			
			if( !(recvBuf.substring(78, 82)).equals("0000") ) {
				throw new Exception("[CASH0600] Error code=[" + recvBuf.substring(78, 82) + "] for 1st message");
			}
			hm.put(strDataID[1], recvBuf.substring(162, 171));		//대행승인 시작번호
			hm.put(strDataID[2], recvBuf.substring(171, 180));		//대행승인 종료번호
			hm.put(strDataID[3], recvBuf.substring(180, 188));		//대행승인 적용시작일
			hm.put(strDataID[4], recvBuf.substring(188, 228));		//안내문구1
			hm.put(strDataID[5], recvBuf.substring(228, 268));		//안내문구2
			hm.put(strDataID[6], recvBuf.substring(268, 288));		//filler

			sendMsg = "";
			sendMsg = makeGWHeader(MessageID.MID_CASH0600)
					+ makeCommonHeader(MessageID.MID_CASH0600)
					+ makeApprovalNoManagementData(hm, "01");	// 01:승인번호 적용 확인
			logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "][" + sendMsg + "]");
			
			if( actSock.send(sendMsg) ) {
				logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				logger.info("[sms>ssg] SEND[" + sendMsg.getBytes().length + "] ERROR");
			}
			recvBuf = "";
			recvBuf = ((String)actSock.receive());
			
			if( !(recvBuf.substring(78, 82)).equals("0000") ) {
				throw new Exception("[CASH0600] Error code=[" + recvBuf.substring(78, 82) + "] for 2nd message");
			}

			dao.procCASHRCPT_APPRNO_INS(com_cd, hm);
		}catch(Exception e) {
			logger.info("[Error]:getBands:" + e.getMessage());
			
			hm.put(strDataID[1], "NULL");	//대행승인 시작번호
			hm.put(strDataID[2], "");		//대행승인 종료번호
			hm.put(strDataID[3], "");		//대행승인 적용시작일
			hm.put(strDataID[4], "");		//안내문구1
			hm.put(strDataID[5], "");		//안내문구2
			hm.put(strDataID[6], "");		//filler
			try {
				dao.procCASHRCPT_APPRNO_INS(com_cd, hm);
			}catch(Exception ex) {}
			
		}finally {
			actSock.close();
			actSock = null;
		}
	}
}
