package biz.cms_CashRcptManager;

import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import sun.misc.BASE64Decoder;

import com.cyberpass.seed.Seed;

import biz.comm.AES;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;


class TestIrtStart {

	private static Logger logger = Logger.getLogger(TestIrtStart.class);
	static COMMLog cLog = new COMMLog();

	public static void main(String[] args)  throws Exception {
		try {
			cLog.setStartTime(); 
			cLog.setbizLogger(logger);

			String path          = "D:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			execute();
			
		} catch (Exception e) {
			System.out.println("[ERROR] Exception : " + e.getMessage());
		}
		
	}
	
	public static void execute() throws Exception {

//        String sText = "동글이팜";
//        String encrypt_text = null;
//        String decrypt_text = null;
//        String decrypt_key = null;
//        String sDoubleKey = PropertyUtil.findProperty("double-decode-key-property", "CASH_IF_KEY");
//        String sKey = PropertyUtil.findProperty("decode-key-property", "CASH_IF_KEY");
//        String sInitVector = PropertyUtil.findProperty("decode-key-property", "INITVECTOR");
//        try {
//
//            System.out.println("sDoubleKey[" + sDoubleKey + "]");
//            System.out.println("sKey[" + sKey + "]");
//            System.out.println("sInitVector[" + sInitVector + "]");
//            System.out.println("");
//            System.out.println("");
// 
//            decrypt_key = COMMBiz.aesDecryptCbc(sDoubleKey, sKey, sInitVector);
//            System.out.println("decrypt_key[" + decrypt_key + "]");
//            System.out.println("");
//            System.out.println("");
//
//            encrypt_text = COMMBiz.aesEncryptCbc(decrypt_key, sText, sInitVector);
//            System.out.println("decrypted[" + encrypt_text + "]");
//            System.out.println("");
//            System.out.println("");
// 
//            decrypt_text = COMMBiz.aesDecryptCbc(decrypt_key, encrypt_text, sInitVector);
//            System.out.println("decrypt_text[" + decrypt_text + "]");
		
//        String sText = "ENC8ZfHtVNNlh0Qe+2UA6C7eQ==";
//        String encrypt_text = null;
//        String decrypt_text = null;
//        String decrypt_key = null;
//        String sDoubleKey = PropertyUtil.findProperty("double-decode-key-property", "CASH_IF_KEY");
//        String sKey = PropertyUtil.findProperty("decode-key-property", "CASH_IF_KEY");
//        String sInitVector = PropertyUtil.findProperty("decode-key-property", "INITVECTOR");
        try {

//            System.out.println("sDoubleKey[" + sDoubleKey + "]");
//            System.out.println("sKey[" + sKey + "]");
//            System.out.println("sInitVector[" + sInitVector + "]");
////            System.out.println("");
////            System.out.println("");
// 
//            decrypt_key = COMMBiz.aesDecryptCbc(sDoubleKey, sKey, sInitVector);
//            System.out.println("decrypt_key[" + decrypt_key + "]");
////            System.out.println("");
////            System.out.println("");
// 
//            decrypt_text = COMMBiz.aesDecryptCbc(decrypt_key, sText, sInitVector);
//            System.out.println("decrypt_text[" + decrypt_text + "]");
////        String[] text = {
////        		"7ulc/ksuu9hw/DLjGXn4wA=="
////        		,"7ulc/ksuu9hw/DLjGXn4wA=="
////        		,"7ulc/ksuu9hw/DLjGXn4wA=="
////        		,"7ulc/ksuu9hw/DLjGXn4wA=="
////        		,"7ulc/ksuu9hw/DLjGXn4wA=="
////        };
////        
////
////		System.out.println("text.length()[" + text.length + "]");
////		System.out.println(" text[0][" + text[0] + "]");
//		String sText2 = "f32642cf9a347e0e1a173e57080fab41                                                                                                ";
//		String info = null;
////		try {
//			
//			Seed seed = Seed.getInstance("CBC/PKCS5Padding");
//			String keyData = PropertyUtil.findProperty("service-property", "KEY_DATA");
//			String ivData = PropertyUtil.findProperty("service-property", "IV_DATA");
//			seed.setKey(keyData.getBytes());
//			seed.setIV(ivData.getBytes());
//			BASE64Decoder decoder = new BASE64Decoder();
//				
//			for(int i = 0; text.length > i; i++){				
//				info = new String(seed.decrypt(decoder.decodeBuffer(text[i])));
//				System.out.println("decrypt_text[" + info + "]");
//			}
			
//        	
//        	
//        	
//        	
//        	
//        	
//        	
//        	
//        	
//        	
//        	

        	
			System.out.println("decrypt_text[" + new AES().decrypt("75378cb1989cc9c2294eb69d006cbbee".trim()) + "]");
            
        } catch (Exception e) {
            e.printStackTrace();
        }

	}
}