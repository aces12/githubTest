package biz.cms_SSGConReceiver;

import java.util.HashMap;
import java.util.List;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

import org.apache.log4j.Logger;

public class SSGConReceiverDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(SSGConReceiverPollingAction.class);
	
	public List<Object> selSVCFILEDAILY(String stdYmd, String svcID, String cmdTp, String comCD) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SVCCRTDAILY"));
			sql.setString(++i, stdYmd);
			sql.setString(++i, svcID);
			sql.setString(++i, cmdTp);
			sql.setString(++i, comCD);
			
			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		} 
		
		return list;
	}
	
	
	public int insSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	
	//20171221 KSN::SSGCON 수신 대사파일 데이터 등록 (TO HQM.HQ_SSGCONADJT_TRN)
	public int insSSGConPLFTranDATA(HashMap<String, String> hmDTL, HashMap<String, String> hmHD) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			connect("CMGNS"); //DB Connection(DB 접속)
			
			logger.info("[INFO] hmDTL::["+hmDTL+"]");
			
			sql.put(findQuery("service-sql", "INS_SSGCON_PLFTRAN_DATA"));
			sql.setString(++i, (String)hmDTL.get("MSG_SEND_DT"));			//TRAN_YMD
			sql.setString(++i, (String)hmDTL.get("ST_CODE").substring(0, 5));//STORE_CD
			sql.setString(++i, (String)hmDTL.get("TM_NO"));					//POS_NO
			sql.setString(++i, (String)hmDTL.get("TRAN_NO").substring(1, 5));//TRAN_NO
			sql.setString(++i, (String)hmDTL.get("MSG_TRACE_NO"));			//TRACE_NO
			
			sql.setString(++i, (String)hmHD.get("SEND_DATE"));				//ADJT_DT
			sql.setString(++i, (String)hmDTL.get("TRAN_TYPE"));				//TRAN_TYPE
			sql.setString(++i, (String)hmDTL.get("CASHER_NO"));				//CASHER_NO
			sql.setString(++i, (String)hmDTL.get("SALE_DT"));				//SALE_DT
			sql.setString(++i, (String)hmDTL.get("KEY_IN_TYPE"));			//KEY_IN_TYPE
			
			sql.setString(++i, (String)hmDTL.get("TRADE_TYPE"));			//TRADE_TYPE
			sql.setString(++i, (String)hmDTL.get("USE_FUNC_GUBUN"));		//USE_FUNC_GUBUN
			sql.setString(++i, (String)hmDTL.get("USE_GUBUN"));				//USE_GUBUN
			sql.setString(++i, (String)hmDTL.get("DELEGATE_BARCODE_NO"));	//DELEGATE_BARCODE_NO
			sql.setString(++i, (String)hmDTL.get("CPN_NO"));				//CPN_NO
			
			sql.setString(++i, (String)hmDTL.get("TOT_TRADE_AMT"));			//TOT_TRADE_AMT
			sql.setString(++i, (String)hmDTL.get("TRADE_AMT"));				//TRADE_AMT
			sql.setString(++i, (String)hmDTL.get("REMAIN_AMT"));			//REMAIN_AMT
			sql.setString(++i, (String)hmDTL.get("AUTH_DATE"));				//AUTH_DATE
			sql.setString(++i, (String)hmDTL.get("AUTH_TIME"));				//AUTH_TIME
			
			sql.setString(++i, (String)hmDTL.get("AUTH_NO"));				//AUTH_NO
			sql.setString(++i, (String)hmDTL.get("PRD_TYPE"));				//PRD_TYPE
			sql.setString(++i, (String)hmDTL.get("PRD_ID"));				//PRD_ID
			sql.setString(++i, (String)hmDTL.get("PTR_ID"));				//PTR_ID	
			sql.setString(++i, (String)hmDTL.get("PTR_MCH_ID"));			//PTR_MCH_ID
			
			sql.setString(++i, (String)hmDTL.get("SER_COM_CD"));			//SER_COM_CD
			sql.setString(++i, (String)hmDTL.get("SHOP_NO"));				//SHOP_NO
			sql.setString(++i, (String)hmDTL.get("CD_NO"));					//CD_NO
			
			rows = executeUpdate(sql);
			
			logger.info("[INFO] sql.debug::["+sql.debug()+"]");
			
		}catch(Exception e) {
			logger.info("[ERROR] SSGCON PLF DATA INSERT ERR OCCUR.");
			logger.info("[ERROR] err_msg::["+e.getMessage()+"]");
			logger.info("[ERROR] sql.debug::["+sql.debug()+"]");
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
}
