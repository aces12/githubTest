package biz.cms_SSGConReceiver;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

import org.apache.log4j.Logger;

import com.sshtools.j2ssh.sftp.SftpFile;

import biz.cms_HJParcelTran.HJParcelTranDAO;
import biz.comm.COMMBiz;
import biz.comm.SFTPManager;

public class SSGConReceiverPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(SSGConReceiverPollingAction.class);
	private final int LENGTH_BY_HD_RECORD = 85;
	private final int LENGTH_BY_DTL_RECORD = 333;
	private final int LENGTH_BY_TL_RECORD = 3;
	
	public static void main(String args[]) throws Exception {
		SSGConReceiverPollingAction action = new SSGConReceiverPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[1]]=" + args[1] );
			System.out.println("[DEBUG] [args[2]]=" + args[2] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd           = nvl(args[1].replaceFirst("-cmd:"  ,""));
			String fileDt        = nvl(args[2].replaceFirst("-fileDt:"  ,""));
			
			/*
			String path          = "C:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
			String cmd 	         = "1";
			String fileDt        = "20171211";
			*/
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			String retMsg = "";
			if("0".equals(cmd)){		//전일자 파일다운 및 데이터등록처리
				action.execute("1");
			}else if("1".equals(cmd)){	//특정일자 파일다운 및 데이터등록처리
				action.transferSSGConDownFile(fileDt);
			}
			
			System.out.println("[Send Data]=" + retMsg);
		}catch(Exception e) {
			System.out.println("[Send Data]=" + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	//20171211 KSN SSGCON 전송파일 생성
	@Override
	public void execute(String actionMode) {
		logger.info(":::SEND SSGCON TRAN DATA START:::");
		SSGConReceiverDAO dao = new SSGConReceiverDAO();
		List<Object> list = null;
		int totalCnt = 0;
		
		try{
			int ret =  -1;
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode != "1" ) return;
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String stdYmd = sdf.format(new Date());
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			//(금일 대사파일 생성 유무 조회)
			list = dao.selSVCFILEDAILY(stdYmd, "SCO", "01", com_cd);
			totalCnt = list.size();
			
			//금일 대사파일 생성 row가 없으면 생성
			if(totalCnt <= 0){
				HashMap<String, String> hm = new HashMap<String, String>();
				hm.put("COM_CD", com_cd);
				hm.put("STD_YMD", stdYmd);
				hm.put("SVC_ID", "SCO");
				hm.put("CMD_TY", "01");
				
				ret = dao.insSVCFILEINFO(hm);
				System.out.println("[INFO] ret::["+ret+"]");
				logger.info("[INFO] ret::["+ret+"]");
				if( ret > 0 ) {
					transferSSGConDownFile(stdYmd);
				}
			}
		}catch(Exception e){
			System.out.println("[ERROR] error occur::["+e.getMessage()+"]");
			logger.info("[ERROR] error occur::["+e.getMessage()+"]");
		}
			
	}
	
	
	public void transferSSGConDownFile(String fileDt) {
		logger.info("[INFO] START DOWN SSGCON TRAN FILE." );
		//서버정보
		String ssgcon_ftp_ip = "";
		int ssgcon_ftp_port = 0;
		String ssgcon_ftp_id = "";
		String ssgcon_ftp_pwd = ""; 
		
		SFTPManager sFtpMgr = null;
		BufferedOutputStream bos = null;
		
		String basePath = "";
		String destPath = "";
		
		int iRetry = 0;
		boolean isDownOK = false;
		String stdDate = "";
		String targetFileNm = "";
		
		try {			
			ssgcon_ftp_ip = PropertyUtil.findProperty("communication-property", "SSGCON_FTP_IP");
			ssgcon_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGCON_FTP_PORT"));
			ssgcon_ftp_id = PropertyUtil.findProperty("communication-property", "SSGCON_FTP_ID");
			ssgcon_ftp_pwd = PropertyUtil.findProperty("communication-property", "SSGCON_FTP_PW");	
			
			try{				
				sFtpMgr = new SFTPManager(ssgcon_ftp_ip, ssgcon_ftp_port, ssgcon_ftp_id, ssgcon_ftp_pwd);	
				logger.info("[INFO] TRY Connected to " + ssgcon_ftp_ip + ":" + ssgcon_ftp_port);
			}catch(Exception e){
				logger.info("[ERROR] exception occur. "+e.getMessage());
				logger.info("[ERROR] SFTP Connect fail exception occur.");
				return;
			}					
			logger.info("[INFO] SFTP Connection is Success.");	
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "ssgcon";		
			
			if("".equals(fileDt) || fileDt == null){
				Calendar calendar = new GregorianCalendar(Locale.KOREA);
				SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
				calendar.setTime(new Date());
				calendar.add(Calendar.DATE, 1);
				stdDate = sdf.format(calendar.getTime());
			}else{
				stdDate = fileDt.substring(2,8);
			}
							
			isDownOK = false;
			iRetry = 0;
			
			File destDir = new File(destPath);
			if( !destDir.exists() ) {
				destDir.mkdir();
				logger.info("[DEBUG] Try to make dir" );
			}
			
			targetFileNm = "SSG_EMART24." + stdDate;
			logger.info("[INFO] targetFileNm::["+targetFileNm+"]");
			bos = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + targetFileNm));
			
			sFtpMgr.cd("down"); // 경로변경
			
			while (iRetry < 2) {
		    	logger.info("[INFO] SSGCon Receiver::iRetry::["+iRetry+"]");
		    	if ((isDownOK = sFtpMgr.get(targetFileNm, bos))) {
		    		logger.info("[INFO] SSGCon tran file down succ.");
		          break;
		        }
		        iRetry++;
	        }
		    logger.info("[INFO] isDownOK::["+isDownOK+"]");
		      
		    bos.flush();
	        bos.close();
		    bos = null;
		    System.gc(); 
			
		    if( isDownOK ) {
				logger.info("[INFO] successfully downloaded file::["+targetFileNm+"]"); // 다운 받은 파일은 파일명변경한다.
				
				
				if( sFtpMgr.rename(targetFileNm, targetFileNm.concat(".ok")) ) {
					logger.info("[INFO] Succeeded rename.");
					
					File file = new File(destPath + File.separator + targetFileNm);
					File fileOK = new File(destPath + File.separator + targetFileNm.concat(".ok"));
					file.renameTo(fileOK);//다운로드 완료시 파일명에 .ok 추가
				}else {
					logger.info("[ERROR] Failed to remove.");
				}
			}else {
				logger.info("[ERROR] Can't get " + targetFileNm + " from FTP server");
									
				File file = new File(destPath + File.separator + targetFileNm);
				if( !file.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm + "]");
				}				
				logger.info("[ERROR2] Can't get file on FTP server");
			}
		    
		    if( !sFtpMgr.isClosed() ){ //ftp 연결종료
		    	sFtpMgr.logout();
		    }
		    
		    //파일 읽기
		    logger.info("[INFO] SSGCON PLATFORM TRAN DATA READ START.");
		    
		    String fileNM = "";
		    try{
		    	List<File> file = getDirFileList(destPath);
				logger.info("[INFO] file cnt::["+Integer.toString(file.size())+"]");
				
				for(int i = 0;i < file.size();i++) {
					fileNM = file.get(i).getName();
					
					logger.info("[INFO] file name::["+fileNM+"]");
					
					int len = 0;
					int totLen = 0;
					String readLine = "";
					
					long fileSize = (file.get(i)).length();
					logger.info("[INFO] fileSize::["+fileSize+"]");
					
					byte buf[] = new byte[(int)fileSize];
					InputStream is = new FileInputStream(file.get(i));
					
					StringBuffer sb = new StringBuffer();
					
					while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
						sb.append(new String(buf));
						totLen += len;
						logger.info("[INFO] fileSize::["+fileSize+"]");
						if( totLen == fileSize ) {
							break;
						}
					}
					
					is.close();
					
					logger.info("[INFO] fileNM::["+fileNM.substring(0, 11)+"]");
					
					if( fileNM.substring(0, 11).equals("SSG_EMART24") ) { // SSG CON 플랫폼 대사파일
						logger.info("[INFO] insert start");
						logger.info("[INFO] fileCon::["+sb.toString()+"]");
						this.insertDB(sb.toString());
					}
					
					// 파일 옮기기...
					moveFile(destPath, fileNM, destPath + File.separator + "backup");
					logger.info("[INFO] File::["+fileNM+"] processed successfuly.");
				}
		    }catch(Exception e){
		    	logger.info("[ERROR] SSG CON RCV FAIL. AFTER INSERT START. ERR_MSG::["+e.getMessage()+"]");
		    }
		    
		}catch(Exception e) {
			logger.info("[ERROR] SSG CON RCV FAIL. TOTAL ERR. ERR_MSG::["+e.getMessage()+"]");
		}
	}
	
	
	private void insertDB(String readData){
		try {
			SSGConReceiverDAO dao = new SSGConReceiverDAO();
			
			HashMap<String, String> hmHd = new HashMap<String, String>();
			HashMap<String, String> hmDTL = new HashMap<String, String>();
			HashMap<String, String> hmTl = new HashMap<String, String>();
			
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String trans_date = "";
			
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			int ret = 0;
			
			logger.info("[INFO] insertDB ::: bytes.length ::: "+ bytes.length);
			
			for(int i = 0; totLen<bytes.length; i++) {
				String strRecord = "";
				
				if(i == 0){
					strRecord = new String(bytes, i*LENGTH_BY_HD_RECORD, LENGTH_BY_HD_RECORD);
					totLen += LENGTH_BY_HD_RECORD;
					logger.info("[INFO] PARSE_DATA::HD_DATA::["+strRecord+"]::totLen::["+totLen+"]");
					
					hmHd = getSSGConTran_HD(strRecord);
					logger.info("[INFO] hmHd::["+hmHd+"]");
				}else{
					if(bytes.length-totLen > 3){
						strRecord = new String(bytes, totLen, LENGTH_BY_DTL_RECORD);
						totLen += LENGTH_BY_DTL_RECORD;
						logger.info("[INFO] PARSE_DATA::DTL_DATA::["+strRecord+"]::totLen::["+totLen+"]");
						
						hmDTL = getSSGConTran_DTL(strRecord);
						logger.info("[INFO] hmDTL::["+hmDTL+"]");
						
						try {
							ret = dao.insSSGConPLFTranDATA(hmDTL, hmHd);
						}catch(Exception e) {
							logger.info("[ERROR] Error for inserting data : " + e.getMessage());
						}
					}else{
						strRecord = new String(bytes, totLen, LENGTH_BY_TL_RECORD);
						totLen += LENGTH_BY_TL_RECORD;
						logger.info("[INFO] PARSE_DATA::TL_DATA::["+strRecord+"]::totLen::["+totLen+"]");
						
						hmTl = getSSGConTran_TL(strRecord);
						logger.info("[INFO] hmTl::["+hmTl+"]");
						
						logger.info("[INFO] READ SSGCON PLATFORM DATA END.");
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
			System.out.println("[ERROR] " + e.getMessage());
		}
	}
	
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();

			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
		}
		
		return dirFileList;
	}
	
	
	public void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}else {
					if( sendingFile.renameTo(sendedFile) ) {
						break;
					}
				}
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("[ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	
	private HashMap<String, String> getSSGConTran_HD(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {
			2, 8, 64, 1, 9,
			1
		};
		String strHeaders[] = {
			"HEADER",
			"SEND_DATE",
			"REQ_CO_NM",
			"WORK_CNT",
			"TOT_CNT",
			
			"LF"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	private HashMap<String, String> getSSGConTran_DTL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {
			8, 26, 15, 15, 4,
			10, 4, 5, 4, 5,
			10, 2, 8, 2, 2,
			1, 1, 64, 64, 12,
			12, 12, 8, 6, 8,
			20, 4, 1
		};
		String strHeaders[] = {
			"MSG_SEND_DT",
			"MSG_TRACE_NO",
			"PTR_ID",
			"PTR_MCH_ID",
			"SER_COM_CD",
			
			"ST_CODE",
			"TM_NO",
			"SHOP_NO",
			"CD_NO",
			"TRAN_NO",
			
			"CASHER_NO",
			"TRAN_TYPE",
			"SALE_DATE",
			"KEY_IN_TYPE",
			"TRADE_TYPE",
			
			"USE_FUNC_GUBUN",
			"USE_GUBUN",
			"DELEGATE_BARCODE_NO",
			"CPN_NO",
			"TOT_TRADE_AMT",
			
			"TRADE_AMT",
			"REMAIN_AMT",
			"AUTH_DATE",
			"AUTH_TIME",
			"AUTH_NO",
			
			"PRD_ID",
			"PRD_TYPE",
			"LF"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	private HashMap<String, String> getSSGConTran_TL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {
			2, 1
		};
		String strHeaders[] = {
			"TRAILER",
			"LF"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
}
