package biz.cms_DGBIrt;

import java.net.Socket;
import java.util.HashMap;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;

public class DGBIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(DGBIrtAction.class);
	
	private String server_ip = "";
	private int server_port = 0;
	
	/**
	 * Receive data from SC through 9015 PORT(SC로부터 데이타를 9015 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(ActionSocket actionSocket) throws Exception {		
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		DGBIrtProtocol protocol = new DGBIrtProtocol();
		COMMLog df = new COMMLog();
		
		Socket extClntSock = null;
		DGBIrtConveyer conveyer = null;
		this.server_ip = PropertyUtil.findProperty("communication-property", "DGB_COMM_IP");
		this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "DGB_COMM_PORT"));
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress()
					.getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,
					"DGBIRT");
			
			df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			

			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지
			// 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}

			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			inq_type = protocol.getRcvDGBIrtDATA(rcvDataBuf);//B3:2097 B4:2098 B5:2099 B6:2100
			switch( inq_type ) { //DGB [단말기개통/변경 B3] [충전/충전취소 B4] [충전/충전취소 결과 B5] [권종변경 요청/승인 B6] [권종변경 결과 B7]
			
				// DGB UPAY 단말기 개통/변경 요청 전문
				case 2097:
					df.execute("DGBIrt-TMNLINSTALL");
					hmData = protocol.getParseDGBTMNLINSTALLInq(rcvDataBuf);

					df.CommLogger("server_ip[" + server_ip + "]");
					df.CommLogger("server_port[" + server_port + "]");
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new DGBIrtConveyer(extClntSock, df);

					dataMsg = conveyer.getDGBTMNLINSTALLInq(hmCommon, hmData);
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
					// DGB UPAY 충전/충전 취소 요청 전문
				case 2098:
					df.execute("DGBIrt-CHRGInq");
					hmData = protocol.getParseDGBCHRGInq(rcvDataBuf);

					extClntSock = new Socket(server_ip, server_port);
					conveyer = new DGBIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getDGBCHRGInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// DGB UPAY 충전/충전취소 [결과] 요청 전문
				case 2099:
					df.execute("DGBIrt-CHRGCompletedInq");
					hmData = protocol.getParseDGBCHRGCompletedInq(rcvDataBuf);

					extClntSock = new Socket(server_ip, server_port);
					conveyer = new DGBIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getDGBCHRGCompletedInq(hmCommon, hmData);

					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
//				// DGB UPAY 권종변경 요청
				case 2100:
					df.execute("DGBIrt-ChangeInq");
					hmData = protocol.getParseDGBChangeSnd(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new DGBIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getDGBChangeSnd(hmCommon, hmData);
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// DGB UPAY 권종변경결과 요청
				case 2101:
					df.execute("DGBIrt-ChangeCompletedInq");
					hmData = protocol.getParseDGBChangeCompletedInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new DGBIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getDGBChangeCompletedInq(hmCommon, hmData);
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
			}
		}catch(Exception e) {
			ret = 29;
			retValue = "[ERROR]2:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			if( extClntSock != null ) {
				extClntSock.close();
			}
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + totalMsg + "]");
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(totalMsg)) {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		}catch(Exception e) {
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("DGBIRT", retValue);
		}
	}
}