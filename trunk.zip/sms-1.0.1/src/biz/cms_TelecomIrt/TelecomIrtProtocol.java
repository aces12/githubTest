package biz.cms_TelecomIrt;

import java.util.HashMap;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class TelecomIrtProtocol {
	private static Logger logger = Logger.getLogger(TelecomIrtAction.class);
	
	public int getRcvTelecomIrtDATA(String rcvBuf) {
		HashMap hm = new HashMap();
		int ret = 0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};
		
		String strHeaders[] = {
			"INQ_TYPE"	// INQ Type(INQ 종별)
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if( Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE")) ) {
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		return ret;
	}	
	
	public HashMap<String, String> getTelecomKtApprsvr(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 1, 2, 2, 1, 128, 14, 6, 16, 15, 4, 21, 5};
		String strHeaders[] = {
			"INQ_TYPE",       // INQ종별
			"MSG_TYPE",       // 전문종류
			"PAY_GB",         // 적립구분
			"MSG_GB",    	  // 전문구분
			"INPUT_TY",       // 입력구분
			"CARD_DATA",      // 카드데이터
			"TRAN_DATE",      // 거래일시
			"PRODUCT_CD",     // PRODUCT코드
			"SALE_AMT",       // 거래금액
			"ORG_AUTH_NO",    // 원거래승인번호
			"ORG_AUTH_DATE",  // 원거래승인일자
			"SALE_TRAN_NO",   // 거래번호
			"STORE_CD"        // 점포코드
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
}