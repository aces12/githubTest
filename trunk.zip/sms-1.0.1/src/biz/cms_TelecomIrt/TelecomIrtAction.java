package biz.cms_TelecomIrt;

import java.net.Socket;
import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;

import org.apache.log4j.Logger;

import biz.comm.AES;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class TelecomIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(TelecomIrtAction.class);
	
	private String server_ip = "";
	private int server_port = 0;
	
	/**
	 * Receive data from SC through 9001 PORT(SC로부터 데이타를 9001 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(ActionSocket actionSocket) throws Exception {
		// TODO Auto-generated method stub
		int ret = 0;
		int inq_type = 0;
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		String sendMsg = "";
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		TelecomIrtProtocol protocol = new TelecomIrtProtocol();
		
		Socket extClntSock = null;
		TelecomIrtConveyer conveyer = null;
		COMMLog df = new COMMLog();
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());
//			df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress()
					.getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,
					"POSIRT");
			
			// Check MsgType(MsgType 확인)
			logger.error("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지
			// 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}
			// TRAN Date(TRAN일자)
			String tranYmd = COMMBiz.getCommTranYMD(hmCommon);
			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			logger.error("▶ 01: Receive Data: [" + rcvBuf + "]");
			inq_type = protocol.getRcvTelecomIrtDATA(rcvDataBuf);
			df.CommLogger("inq_type [" + inq_type + "]");
			switch( inq_type ) {
				// 94: 바닐라VAN(KT할인) 승인요청
				case 94:
					hmData = protocol.getTelecomKtApprsvr(rcvDataBuf);
					
					this.server_ip = PropertyUtil.findProperty("communication-property", "TelecomKt_apprsvr_IP");
					df.CommLogger("server_ip [" + server_ip + "]");
					this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "TelecomKt_apprsvr_PORT"));			
					df.CommLogger("server_port [" + server_port + "]");
					
					extClntSock = new Socket(server_ip, server_port);	
					conveyer = new TelecomIrtConveyer(extClntSock, df);	
					dataMsg = conveyer.getTelecomKtApprsvr(hmCommon, hmData);

					df.CommLogger("dataMsg[" +dataMsg + "]");
					df.CommLogger("dataMsg.substring(0, 5)[" +dataMsg.substring(0, 5) + "]");
					df.CommLogger("dataMsg.substring(5, 20)[" +dataMsg.substring(5, 20) + "]");
					df.CommLogger("dataMsg.substring(20, 24)[" +dataMsg.substring(20, 24) + "]");
//					if("false".equals(dataMsg.substring(0, 5))){
//						df.CommLogger("1111111111111111"); 
//						for(int i=0;i<5;i++){
//							df.CommLogger("망취소 요청 [" + i + "]"); 
//							extClntSock = new Socket(server_ip, server_port);	
//							conveyer = new TelecomIrtConveyer(extClntSock, df);	
//							String cancle = conveyer.getTelecomKtApprsvrCancle(hmData, dataMsg.substring(5, 20), dataMsg.substring(20, 24));
//							df.CommLogger("cancle[" + cancle + "]");
//							if("0000".equals(cancle)){
//								df.CommLogger("망취소 성공");
//								break;
//							}
//						}
//						//df.CommLogger("2222222222222222"); 
//					}
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					
					dataMsg = dataMsg.substring(2);
					
					break;
					
				default:
					df.CommLogger("▶ INQ Type Code(INQ 종별 코드):   [" + inq_type + "]" + rcvBuf.length());
					ret = 99;
					break;
					
			}
		}catch(Exception e) {
			// 029=HOST APPL ERR
			ret = 29;
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기) 
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			df.CommLogger("[sms>pos] SEND[" + (sendMsg+dataMsg).getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + (sendMsg+dataMsg) + "]");
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(sendMsg + dataMsg)) {
				df.CommLogger("[sms>pos] SEND[" + (sendMsg+dataMsg).getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>pos] SEND[" + (sendMsg+dataMsg).getBytes().length + "] ERROR");
			}
		}catch(Exception e) {
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("POSIRT", retValue);
		}
	}
}