package biz.cms_TelecomIrt;

import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_SSGMbsIrt.SSGMbsIrtConveyer;
import biz.cms_SSGMbsIrt.SSGMbsIrtProtocol;
import biz.cms_SSGMbsIrt.SSGPayIrtConveyer;
import biz.cms_TranDivide.TranDivideDAO;
import biz.comm.AES;
import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.util.StringUtil;
import kt.ktds.aes256cipher.AES256Cipher;

class TestIrtStart {

	private static Logger logger = Logger.getLogger(TestIrtStart.class);
	static COMMLog cLog = new COMMLog();
	private static String server_ip = "";
	private static int server_port = 0;

	public static void main(String[] args)  throws Exception {
		try {
			cLog.setStartTime(); 
			cLog.setbizLogger(logger);

			String path          = "D:/withme_com/workspace/sms-1.0.1/xml/daemon-config.xml";
			System.out.println("1");
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			// DAO
			System.out.println("2");
			
			execute();
			
		} catch (Exception e) {
			System.out.println("[ERROR] Exception : " + e.getMessage());
		}
		
	}
	
	public static void execute() throws Exception {
		// TODO Auto-generated method stub
		int ret = 0;
		int inq_type = 0;
		String aa1 = "7578335075351767                                                                                                                ";
		String aa = aa1 + "";
		String bb = null;
		String cc = null;

		System.out.println("aa[" + aa +"]");
		
		bb = (new AES()).decrypt(aa.trim());
		System.out.println("bb[" + bb +"]");
		
		cc = (new AES()).encrypt(bb.trim());
		System.out.println("cc[" + cc +"]");
		

        AES256Cipher a256 = new AES256Cipher();//신규
        System.out.println("인코딩 TEST");
        System.out.println(a256.AES_Encode(bb));
        System.out.println("디코딩 TEST");
        System.out.println("CARD_DATE 복호화 [" + a256.AES_Decode(a256.AES_Encode(bb)) + "]");
        System.out.println("TEST 종료");
        String DD ="RJOXrOHRaLCxRKMZ2rbHRhewUjij0aUfiSlnovP0DJ8=                                                                                    ";
        System.out.println("CARD_DATE 복호화 [" + a256.AES_Decode(DD) + "]");
//		COMMLog df = new COMMLog();
//		df.setStartTime();
//
//		System.out.println("Checking SSGPoint");
//		//df.execute("Checking SSGPoint");
//		boolean bIsExtended = false;
//		System.out.println("bIsExtended[" + bIsExtended + "]");
//
//		bIsExtended = true;
//		SSGMbsIrtProtocol protocol = new SSGMbsIrtProtocol();
//		HashMap<String, String> hmData = new HashMap<String, String>();
//		HashMap<String, String> hmCommon = new HashMap<String, String>();
//		System.out.println("bIsExtended[" + bIsExtended + "]");
//		String point_server_ip = "174.100.67.174"; //PropertyUtil.findProperty("communication-property", "SSGPOINT_SERVER_IP");
//		System.out.println("point_server_ip[" + point_server_ip + "]");
//		int point_server_port = 64000; //Integer.parseInt(PropertyUtil.findProperty("communication-property", "SSGPOINT_SERVER_PORT"));
//		System.out.println("point_server_port[" + point_server_port + "]");
//
//		String rcvBuf = "00009906009990005307620160923201609231412450001002232016092300999000530760923141245d14384fad4a96a67b36041f8b8b9f333        B2000033713076636730766367";
//		String rcvDataBuf = "";
//		Socket extClntSock = null;
//		SSGMbsIrtConveyer SSGMbsConveyer = null;
//		SSGPayIrtConveyer SSGPayConveyer = null;
//
//		System.out.println("rcvBuf[" + rcvBuf + "]");
//		
//		rcvDataBuf = rcvBuf.substring(50);
//		String dataMsg = "";
//		int ret = 0;
//
//		System.out.println("rcvDataBuf[" + rcvDataBuf + "]");
//		hmData = protocol.getParseSSGPointPhoneInq(rcvDataBuf);
//		System.out.println("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
//		
//		System.out.println("SSG CARD SEARCH_1");
//		extClntSock = new Socket(point_server_ip, point_server_port);
//		System.out.println("1");
//		SSGMbsConveyer = new SSGMbsIrtConveyer(extClntSock, df);
//		System.out.println("2");
//		
//		dataMsg = SSGMbsConveyer.getSSGPointPhoneInq(hmCommon, hmData, bIsExtended);
//		ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
//		dataMsg = dataMsg.substring(2);
//		System.out.println("끝");
		
	}
}
