#!/bin/bash

echo "--start GTFPollingAction"

cd $SMS_HOME/bin

java biz.cms_SmartconSender.SmartconSenderPollingAction -path:$CONFIG_FILE -cmd:100

cd $APP_HOME/batch

