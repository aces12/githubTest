package biz.cms_SmartconSender;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import org.apache.log4j.Logger;

import biz.comm.SFTPManager;

public class SmartconSenderMakeTransferMST extends Thread {
	private static Logger logger = Logger.getLogger(SmartconSenderPollingAction.class);
	
	//boolean bMakeNTrans = false;
	boolean bMakeMST = false;
	boolean bTransMST = false;
	
		

	public void run() {
		logger.info("SmartconSenderMakeTransferMST run()" );
		
		if(bMakeMST){
			logger.info(" MST File MAKE") ;
			makeMST();				
		}
		if(bTransMST){			
			logger.info(" MST File Transfer") ;
			transferMST();			
		}			
		bMakeMST = false;
		bTransMST = false;		
	}
	
	
	
	public void makeMST(){
		logger.info("makeMST() " );
		BufferedWriter bwt = null ;

		try {						
			SmartconSenderDAO dao = new SmartconSenderDAO();
			List<Object> list = null;
			String basePath;
			String destPath;
			
			list = dao.selSmartconMST();
						
			List<Object> listMST = new ArrayList<Object>();
			
			for (int id= 0 ; id< list.size(); id++){		
				listMST.add((Map<String, String>)list.get(id));
			}											
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
		
			//neo0531 for test 
			//basePath = "C:\\CMBO";	// 파일 생성 루트 for test neo0531
			
			destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "smartcon";
			
			File destDir = new File(destPath);
			
			if( !destDir.exists() ) {
				destDir.mkdir();
				logger.info("[DEBUG] Try to make dir" );
			}			

			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

			calendar.setTime(new Date());
			calendar.add(Calendar.DATE, 1);
			String stdDate = sdf.format(calendar.getTime());
			
			String targetFileNm = "SMARTCON_WITHME_MST_" + stdDate + ".dat";
												
			bwt = new BufferedWriter(new FileWriter(destDir + File.separator + targetFileNm));
			
			for (int id= 0 ; id< listMST.size(); id++){		
				bwt.write(((Map<String, String>)listMST.get(id)).get("plu_cd")); 	bwt.write("\t");
				bwt.write(((Map<String, String>)listMST.get(id)).get("ptn_cd")); 	bwt.write("\t");
				bwt.write(((Map<String, String>)listMST.get(id)).get("cate_cd_l")); bwt.write("\t");
				bwt.write(((Map<String, String>)listMST.get(id)).get("cate_cd_m")); bwt.write("\t");
				bwt.write(((Map<String, String>)listMST.get(id)).get("cate_cd_s")); bwt.write("\t");
				bwt.write(((Map<String, String>)listMST.get(id)).get("hq_prc")); bwt.write("\t");//neo0531 master
				bwt.newLine();			
			}				
												
		}catch(Exception e) {
			logger.error("[ERROR1] " + e.getMessage());
		}finally {
			try {
				bwt.flush();
				bwt.close();
				bwt = null;
				System.gc();
								
				logger.info("Creation MST File is end");		
			}catch(Exception e) {}
		}
		
	}
	
	
	
	public void transferMST() {
		logger.info("transferMST() " );
		String smartcon_ftp_ip = "";
		int smartcon_ftp_port = 0;
		String smartcon_ftp_id = "";
		String smartcon_ftp_pwd = ""; 
		SFTPManager sFtpMgr = null;
		
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isSendOK = false;
		String targetPathNm = ""; 
		String stdDate = "";
		
		String targetFileNm = "";
		
		try {			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			//neo0531 for test
			//basePath = "C:\\CMBO";			
			destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "smartcon";		
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

			calendar.setTime(new Date());
			calendar.add(Calendar.DATE, 1);
			stdDate = sdf.format(calendar.getTime());
			
			targetFileNm = "SMARTCON_WITHME_MST_" + stdDate + ".dat";

			smartcon_ftp_ip = PropertyUtil.findProperty("communication-property", "SMARTCON_FTP_SERVER_IP");
			smartcon_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "SMARTCON_FTP_SERVER_PORT"));
			smartcon_ftp_id = PropertyUtil.findProperty("communication-property", "SMARTCON_FTP_SERVER_ID");
			smartcon_ftp_pwd = PropertyUtil.findProperty("communication-property", "SMARTCON_FTP_SERVER_PWD");	

			
			try{				
				sFtpMgr = new SFTPManager(smartcon_ftp_ip, smartcon_ftp_port, smartcon_ftp_id, smartcon_ftp_pwd);	
				logger.info("TRY Connected to " + smartcon_ftp_ip + ":" + smartcon_ftp_port);
			}catch(Exception e){
				logger.info("exception occur"+e.getMessage());
				logger.info(" SFTP Connect fail exception occur ");
				return;
			}					
			logger.info(" SFTP Connection is Success ");	
							
			targetPathNm = destPath + File.separator + targetFileNm;
			isSendOK = false;
			
			iRetry = 0;	
			sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "master"); // 경로변경(현재경로+master폴더)
			
			while( iRetry < 2 ) {				
				if( isSendOK = sFtpMgr.put(targetPathNm)) {		
				//if( isSendOK = sFtpMgr.put(destPath)) {
					break;
				}
				iRetry++;
			}			
		}catch(Exception e) {
			logger.info("[ERROR1] " + e.getMessage());
		}finally {
			try {					
				File oldFileNm = new File(targetPathNm);			
				if(isSendOK ) {
					logger.info(" >>>>>>>>>>>>> successfully upload file [" + targetFileNm + "]");
					// 송신완료한 파일은 rename을 통해 송신완료한 파일인지 구분한다.					
					File newFileNm = new File(targetPathNm +".ok");
					targetFileNm = targetPathNm +".ok";
				
					if(oldFileNm.renameTo(newFileNm))
						logger.info("rename work well done");	
					else
						logger.info("[DEBUG] Failed to rename.");
					
					moveFile(destPath, newFileNm.getName(), destPath + File.separator + "backup");
					logger.info("FTP work well done");
				

										
				}else {
					logger.info("[ERROR2] Can't put " + targetFileNm + " to FTP server");
					File newFileNm = new File(targetPathNm +".sendfail");
					targetFileNm = targetPathNm +".sendfail";
					if(oldFileNm.renameTo(newFileNm)){					
						logger.info("[DEBUG] Succeeded to rename.");
					}else {
						logger.info("[DEBUG] Failed to rename.");				
					logger.info("[ERROR2] Can't put file on FTP server");
				}			
			}
			}catch(Exception e) {}
		}		
	}	
	
	public  void moveFile(String orgPath, String fileNM, String destPath) {
		File sendingFile = new File(orgPath + File.separator + fileNM);
		
		if( sendingFile.exists() ) {
			File sendedPath = new File(destPath);
			if( !sendedPath.exists() ) {
				sendedPath.mkdirs();
			}
			File sendedFile = new File(destPath + File.separator + fileNM);
			
			for(int i = 0;i < 20;i++) {
				if( sendedFile.exists() ) {
					sendedFile.delete();
				}
				if( sendingFile.renameTo(sendedFile) ) {
					break;
				}
//					logger.info(" >>>>>>>> file rename fail!!");
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}	
	
}