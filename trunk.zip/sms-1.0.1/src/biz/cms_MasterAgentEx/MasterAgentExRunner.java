package biz.cms_MasterAgentEx;

import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;

public class MasterAgentExRunner extends Thread {
	private static Logger logger = Logger.getLogger(MasterAgentExPollingAction.class);
	
	private final int POS_PORT = 7002;
	
	private MasterAgentExPOSOperator operator = null;
	private Map<String, String> map = null;
	
	public MasterAgentExRunner(MasterAgentExPOSOperator operator) {
		this.operator = operator;
	}
	
	public void setMap(Map<String, String> map) {
		this.map = map;
	}
	
	public void run() {
		try {
			operator.msControl.useThread();
			
//			logger.info("The number of running threads : " + Integer.toString(operator.getMaxThread() - operator.getJobThread()) + ", " + (String)map.get("POS_IP"));
			sendOrderToPOS(map);
			
			operator.msControl.returnThread();
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
	}
	
	private void sendOrderToPOS(Map<String, String> map) {
		MasterAgentExDAO dao = new MasterAgentExDAO();
		Socket sock = null;
		ActionSocket actSock = null;
		String sendData = "";
		String recvData = "";
		boolean bIsOK = false;
		
		try {
			sock = new Socket((String)map.get("POS_IP"), POS_PORT);
			actSock = new ActionSocket(sock, (Filter)(new COMMConveyerFilter(COMMBiz.MASTER_EXT_FILTER)));
			
			actSock.getSocket().setSoTimeout(5000);
						
			sendData = makeMasterOrderMessage(map);
			logger.info("[sms>pos] SEND[" + sendData.length() + "]::[" + sendData + "]");
			
			if( actSock.send(sendData) ) {
				logger.info("[sms>pos] SEND[" + sendData.length() + "] OK");
			}
			
			recvData = (String)actSock.receive();
			logger.info("[sms<pos] RECV[" + recvData.length() + "]:[JOB_CODE:]:[" + recvData + "]");
			
			if( recvData.trim().equals("OK") ) {
				bIsOK = true;
				dao.updTARGETMASTERLIST(map, "3");
			}else {
				dao.updTARGETMASTERLIST(map, "2");
			}
		}catch(SocketTimeoutException ste) {
			// flag를 오류로 변경..나중에 오류인 것들만 다시 한 번 돌린다.
			dao.updTARGETMASTERLIST(map, "2");
			logger.info("[ERROR:TimeOut]" + "[" + (String)map.get("POS_IP") + "]" + ste.getMessage());
		}catch(Exception e) {
			// flag를  완료로 변경
			dao.updTARGETMASTERLIST(map, "3");
			logger.info("[ERROR]" + "[" + (String)map.get("POS_IP") + "]" + e.getMessage());
		}finally {
			if(actSock != null) actSock.close();
		}
	}
	
	public String getLocalIP() {
		InetAddress iAddress;
		String currentIp = "";
		try {
			iAddress= InetAddress.getLocalHost();
			currentIp = iAddress.getHostAddress();
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return currentIp;
	}
	
	public String makeMasterOrderMessage(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		
		try {
			String transId = (String)map.get("TRANS_ID");
			String fileDir = (String)map.get("TRANS_FILE_DIR");
			
			
			
			StringUtil.appendSpace(sb, "04", 2);							// 01.INQ_종별("04":파일전송의뢰)
					
			if( transId.equals("PGM") ) {
				transId = "01";
			}else if( transId.equals("MST") ) {
				transId = "02";
			}else if( transId.equals("CUSTDSP") ) {
				transId = "03";
			}else if( transId.equals("FFIMG") ) {
				transId = "04";
			}else if( transId.equals("POSDLL") ) {
				transId = "05";
			}else if( transId.equals("MSG") ) {
				transId = "06";
			}else {
				transId = "%";
			}
			
			// 긴급 메세지의 경우 전문 형태가 다르다. 
			if( transId.equals("06") ) {
				MasterAgentExDAO dao = new MasterAgentExDAO();
				List<Object> list = dao.selURGENTMSGLIST(map);
				if( list.size() > 0 ) {
					Map<String, String> m = (Map<String, String>)list.get(0);
					
					StringUtil.appendSpace(sb, transId, 2);						// 01.상세종별(01:프로그램,02:마스터,03:객면컨텐츠,04:상품이미지,05:POSDLL,06:긴급메세지)
					StringUtil.appendSpace(sb, (String)m.get("TRANS_VER"), 10);	// 02.메시지번호
					StringUtil.appendSpace(sb, (String)m.get("URGENT_YN"), 1);	// 03.메시지구분
					StringUtil.appendSpace(sb, (String)m.get("POS_SYMDHMS"),12);// 04.게시시작일시
					StringUtil.appendSpace(sb, (String)m.get("POS_EYMDHMS"),12);// 05.게시종료일시
					StringUtil.appendSpace(sb, (String)m.get("MSG_TITLE"), 100);// 06.메시지(타이틀)
					StringUtil.appendSpace(sb, (String)m.get("MSG_CONT"), 1000);// 07.메시지
				}
				
			}else {
				StringUtil.appendSpace(sb, transId, 2);							// 01.상세종별(01:프로그램,02:마스터,03:객면컨텐츠,04:상품이미지,05:POSDLL,06:긴급메세지)
				StringUtil.appendSpace(sb, (String)map.get("URGENT_YN"), 1);	// 02.적용구분(0:일반배신,1:즉시적용,2:긴급적용)
				StringUtil.appendSpace(sb, (String)map.get("TRANS_YMD"), 14);	// 03.적용일시
				StringUtil.appendSpace(sb, getLocalIP(), 15);					// 04.서버IP
				int dot = fileDir.lastIndexOf("/");
				StringUtil.appendSpace(sb, fileDir.substring(0, dot), 100);		// 05.파일경로
				StringUtil.appendSpace(sb, fileDir.substring(dot+1), 20);		// 06.파일명
				StringUtil.appendSpace(sb, (String)map.get("TRANS_VER"), 30);	// 07.파일버전
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return sb.toString();
	}
}
