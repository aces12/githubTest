package biz.cms_MFCIrt;

import java.util.HashMap;
import biz.comm.COMMBiz;

@SuppressWarnings("unchecked")
public class MFCIrtProtocol {
	int ret = 0;
	
	public int getMFCIrtInq(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};
	
		String strHeaders[] = {"INQ_TYPE"  };// INQ Type(INQ 종별) 
							
		//////logger.info("▶ Receive Data: " + rcvBuf );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		ret = COMMBiz.getInqTypeCHG((String)hm.get("INQ_TYPE"));

		return ret;
	}
	
	public HashMap<String, String> getParse(String rcvBuf , int reqType){
		HashMap<String, String> hm = new HashMap<String, String>();	
		switch(reqType){
			case MFCIrtData.POSREQ_A4:{
				hm = COMMBiz.getParseDataMultibyte(MFCIrtData.nlensPosReqA4, MFCIrtData.strHeadersPosReqA4, rcvBuf);
				break;
			}
			case MFCIrtData.POSREQ_A5:{
				hm = COMMBiz.getParseDataMultibyte(MFCIrtData.nlensPosReqA5, MFCIrtData.strHeadersPosReqA5, rcvBuf);
				break;
			}		
		}
		return hm;
	}
	
	public HashMap<String, String> getParseMFCRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {4, 9, 12, 4, 16
				, 16, 14, 6, 12, 2
				, 3
				};
		String strHeaders[] = {				
				"INQ_LENGTH",
				"USER_AREA",
				"ISO_MSG_HEADER",
				"MSG_TYPE",
				"PRI_BITMAP",
		
				"SEC_BITMAP",
				"VAN_DATE",
				"VAN_NO",
				"TRADE_UNIQ_NO",
				"RESP_CD",
		
				"NET_CD",
				};
		
		//logger.info( "▶ getParseCashBeeRTPaymentRcvRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseMFCAdmitRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {4, 9, 12, 4, 16
					, 16, 21, 6, 12, 14
					, 6, 6, 8, 4, 4
					, 3, 4, 3, 2, 4
					, 39, 12, 8, 2, 12
					, 15, 3, 16, 16, 12
					, 114};
		
		
		String strHeaders[] = {				
				"INQ_LENGTH"
				, "USER_AREA"
				, "ISO_MSG_HEADER"
				, "MSG_TYPE"
				, "PRI_BITMAP"
		
				, "SEC_BITMAP"
				, "CARD_NO"
				, "TRADE_CD"
				, "TRADE_AMT"
				, "VAN_DATE"
				
				, "VAN_NO"
				, "TERMINAL_TIME"
				, "TERMINAL_DATE"
				, "LIMIT_DATE"
				, "MCC_KIND"
				
				, "VAN_STATE_CD"
				, "REG_CD"
				, "CARD_UNIQ_NO"
				, "REG_KIND_CD"
				, "VAN_CD"
				
				, "TRACK2"
				, "TRADE_UNIQ_NO"
				, "ADMIT_NO"
				, "RESP_CD"
				, "TERMINAL_NO"
				
				, "FCSTR_NO"
				, "CURR_CD"
				, "PASSWORD"
				, "PASSWORD_DATA"
				, "POS_DATA"
				
				, "DMST_DATA"
				};
		
		//logger.info( "▶ getParseCashBeeRTPaymentRcvRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseMFCCancleRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {
				4, 9, 12, 4, 16
				, 16, 21, 6, 12, 14
				, 6, 6, 8, 4, 4
				, 3, 4, 3, 2, 4
				, 39, 12, 8, 2, 12
				, 15, 3, 12, 24, 114
				};
		
		
		String strHeaders[] = {				
				"INQ_LENGTH"
				, "USER_AREA"
				, "ISO_MSG_HEADER"
				, "MSG_TYPE"
				, "PRI_BITMAP"
		
				, "SEC_BITMAP"
				, "CARD_NO"
				, "TRADE_CD"
				, "TRADE_AMT"
				, "VAN_DATE"
				
				, "VAN_NO"
				, "TERMINAL_TIME"
				, "TERMINAL_DATE"
				, "LIMIT_DATE"
				, "MCC_KIND"
				
				, "VAN_STATE_CD"
				, "REG_CD"
				, "CARD_UNIQ_NO"
				, "REG_KIND_CD"
				, "VAN_CD"
				
				, "TRACK2"
				, "TRADE_UNIQ_NO"
				, "ADMIT_NO"
				, "RESP_CD"
				, "TERMINAL_NO"
				
				, "FCSTR_NO"
				, "CURR_CD"
				, "POS_DATA"
				, "ORG_DATA"
				, "DMST_DATA"
				};
		
		//logger.info( "▶ getParseCashBeeRTPaymentRcvRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);		
		
		return hm;
	}
}