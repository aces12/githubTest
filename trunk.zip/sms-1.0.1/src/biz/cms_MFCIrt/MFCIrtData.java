package biz.cms_MFCIrt;

public class MFCIrtData {
	
	static final int POSREQ_A4 = 2067; //inq_type A4, HashCode
	static final int POSREQ_A5 = 2068; //inq_type A5, HashCode
	// 푸르미 통신 (거래처 추가 생성시 등록 필요)
	static final String CUSTCODE_PURMEE[] = {
		"S00001"   // 춘천
		, "S00002" // 속초
		, "S00003" // 원주
		, "S00004" // 당진
		, "S00005" // 울산
		, "S00006" // 인천
		, "S00013" // 광주 남구 20170719 신규지역추가 ksn
		, "S00017" // 광주
		, "S00022" // 충주
		, "S00023" // 전주
		, "S00026" // 광주 동구 20170719 신규지역추가
//		, "S00027" // 광주 광산구20180620 신규지역추가
//		, "S00028" // 논산 20180620 신규지역추가
	};
	// 웹캐시 통신 (거래처 추가 생성시 등록 필요) 
	static final String CUSTCODE_WEBCASH[] = {
		"S00007"   // 경기도
		, "S00008" // 경상북도
		, "S00009" // 경상남도
		, "S00010" // 충청북도
		, "S00029" // 부산광역시 20180620 신규지역추가 ksn
	};
	
	//A4 pos -> withme parsing
	static final int nlensPosReqA4[] = {
		2,	4,	128,12,	14,
		6,	6,	8,	4,	1,
		12,	25,	5,	10
		};

	static final String strHeadersPosReqA4[] = {
		"INQ_TYPE"
		, "MSG_TYPE"
		, "CARD_NO"
		, "PAY_AMT"
		, "IRT_SEND_DATE_TIME"
		
		, "TRACE_NO"
		, "TERMINAL_TIME"
		, "TERMINAL_DATE"	
		, "VALIDATE_YYMM"
		, "INPUT_TYPE"
		
//		, "CARD_TRACK2"
		, "TRAN_UNIQ_NO"
		, "DMST_DATA"
		, "STORE_CD"
		, "CUST_CD"
		};
	
	//A4 WEBCASH make sendData MFC Card -> withme parsing
	static int nlensSmsA4_webcash[] = {
		4, 9, 12, 4, 16
		, 16, 21, 6, 12, 14
		, 6, 6, 8, 4, 4
		, 3, 4, 3, 2, 4
		, 39, 12, 8, 2, 12
		, 15, 3, 16, 16, 12
		, 114
		};
	
	static final String strHeadersSmsA4_webcash[] = {				
		"INQ_LENGTH"
		, "USER_AREA"
		, "ISO_MSG_HEADER"
		, "MSG_TYPE"
		, "PRI_BITMAP"

		, "SEC_BITMAP"
		, "CARD_NO"
		, "STATUS_CD"
		, "PAY_AMT"
		, "IRT_SEND_DATE_TIME"
		
		, "TRACE_NO"
		, "TERMINAL_TIME"
		, "TERMINAL_DATE"
		, "VALIDATE_YYMM"
		, "MCC_KIND"
		
		, "VAN_STATE_CD"
		, "INPUT_TYPE"
		, "CARD_UNIQ_NO"
		, "REG_KIND_CD"
		, "VAN_CD"
		
		, "CARD_TRACK2"
		, "TRAN_UNIQ_NO"
		, "APPROVAL_NO"
		, "RESP_CD"
		, "TERMINAL_NO"
		
		, "FCSTR_NO"
		, "CURRENCY_CD"
		, "PASSWORD"
		, "PASSWORD_DATA"
		, "POS_DATA"
		
		, "DMST_DATA"
		};
	
	//A4 PURMEE make sendData MFC Card -> withme parsing
	static int nlensSmsA4_purmee[] = {
		4,	4,	4,	8,	6,
		12,	2,	15,	8,	6,
		2,	1,	37,	16,	10,
		12,	8,	12,	9,	9,
		9,	1,	20,	50
		};
	
	static final String strHeadersSmsA4_purmee[] = {				
		"INQ_LENGTH"
		, "MSG_TYPE"
		, "SEND_COM_CD"
		, "SEND_DATE"	//IRT_SEND_DATE_TIME	PROCESSING
		, "SEND_TIME"	//IRT_SEND_DATE_TIME	PROCESSING

		, "TRAN_UNIQ_NO"
		, "RESP_CD"
		, "FCSTR_NO"	//CORP_CD(10)+STORE_CD(5)	PROCESSING
		, "TERMINAL_DATE"
		, "TERMINAL_TIME"
		
		, "USE_TYPE"
		, "INPUT_TYPE"//WCC
		, "CARD_TRACK2" //(39)->(37)	PROCESSING
		, "PASSWORD"	
		, "PAY_AMT" //(12)->(10)	PROCESSING	��ҿ�û�϶� �ŷ��ݾ� ��� ���point �ʵ�	//point��ȸ�϶� filler
		
		, "APPROVAL_NO"						//point��ȸ�϶� filler
		, "FILLER1"	//��ҿ�û�϶� ��ŷ���������	//point��ȸ�϶� filler
		, "FILLER2"	//��ҿ�û�϶� ��ŷ����ι�ȣ	//point��ȸ�϶� filler
		, "POINT_START"
		, "POINT_ABLE"
		
		, "POINT_REMAIN"
		, "CANCLE"							//point��ȸ�϶� filler
		, "BYPASS"
		, "RESP_MSG"
		
		};
	
	//A4 make dataMsg, withme -> pos
	static final int nlensPosRspA4[] = {
		2, 4, 6, 12, 12
		, 2, 10, 100
		};
	
	static final String strHeadersPosRspA4[] = {
		"INQ_TYPE"
		, "MSG_TYPE"
		, "TRACE_NO"
		, "TRAN_UNIQ_NO"
		, "APPROVAL_NO"
		
		, "RESP_CD"
		, "CUST_CD"
		, "RESP_MSG"
		};

//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	//	
	
	//A5 pos -> withme parsing
	static final int nlensPosReqA5[] = {
		2,	4,	128,12,	14,
		6,	6,	8,	4,	1,
		12,	12,	24,	25,	5,
		10,	8
		};

	static final String strHeadersPosReqA5[] = {
		"INQ_TYPE"
		, "MSG_TYPE"
		, "CARD_NO"
		, "PAY_AMT"
		, "IRT_SEND_DATE_TIME"
		
		, "TRACE_NO"
		, "TERMINAL_TIME"
		, "TERMINAL_DATE"
		, "VALIDATE_YYMM"
		, "INPUT_TYPE"
		
//		, "CARD_TRACK2"
		, "TRAN_UNIQ_NO"
		, "ORG_APPROVAL_NO"
		, "ORG_DATA"
		, "DMST_DATA"
		
		, "STORE_CD"
		, "CUST_CD"
		, "ORG_APPROVAL_DATE"
	};
	
	//A5 make sendData MFC Card -> withme parsing
	static int nlensSmsA5_webcash[] = {
		4, 9, 12, 4, 16
		, 16, 21, 6, 12, 14
		, 6, 6, 8, 4, 4
		, 3, 4, 3, 2, 4
		, 39, 12, 8, 2, 12
		, 15, 3, 12, 24, 114
		};
	
	static final String strHeadersSmsA5_webcash[] = {				
		"INQ_LENGTH"
		, "USER_AREA"
		, "ISO_MSG_HEADER"
		, "MSG_TYPE"
		, "PRI_BITMAP"

		, "SEC_BITMAP"
		, "CARD_NO"
		, "STATUS_CD"
		, "PAY_AMT"
		, "IRT_SEND_DATE_TIME"
		
		, "TRACE_NO"
		, "TERMINAL_TIME"
		, "TERMINAL_DATE"
		, "VALIDATE_YYMM"
		, "MCC_KIND"
		
		, "VAN_STATE_CD"
		, "INPUT_TYPE"
		, "CARD_UNIQ_NO"
		, "REG_KIND_CD"
		, "VAN_CD"
		
		, "CARD_TRACK2"	//TRACK2
		, "TRAN_UNIQ_NO"
		, "ORG_APPROVAL_NO"
		, "RESP_CD"
		, "TERMINAL_NO"
		
		, "FCSTR_NO"
		, "CURRENCY_CD"
		, "POS_DATA"
		, "ORG_DATA"
		, "DMST_DATA"
		};
	
	static int nlensSmsA5_purmee[] = {
		4,	4,	4,	8,	6,
		12,	2,	15,	8,	6,
		2,	1,	37,	16,	10,
		12,	8,	12,	9,	9,
		9,	1,	20,	50
		};
	
	static final String strHeadersSmsA5_purmee[] = {				
		"INQ_LENGTH"
		, "MSG_TYPE"
		, "SEND_COM_CD"
		, "SEND_DATE"	//IRT_SEND_DATE_TIME	PROCESSING
		, "SEND_TIME"	//IRT_SEND_DATE_TIME	PROCESSING

		, "TRAN_UNIQ_NO"
		, "RESP_CD"
		, "FCSTR_NO"	//CORP_CD(10)+STORE_CD(5)	PROCESSING
		, "TERMINAL_DATE"
		, "TERMINAL_TIME"
		
		, "USE_TYPE"
		, "INPUT_TYPE"//WCC
		, "CARD_TRACK2" //(39)->(37)	PROCESSING
		, "PASSWORD"	
		, "PAY_AMT" //(12)->(10)	PROCESSING	��ҿ�û�϶� �ŷ��ݾ� ��� ���point �ʵ�	//point��ȸ�϶� filler
		
		, "APPROVAL_NO"						//point��ȸ�϶� filler
		, "ORG_ADMIT_DATE"	//��ҿ�û�϶� ��ŷ���������	//point��ȸ�϶� filler
		, "ORG_APPROVAL_NO"	//��ҿ�û�϶� ��ŷ����ι�ȣ	//point��ȸ�϶� filler
		, "POINT_START"
		, "POINT_ABLE"
		
		, "POINT_REMAIN"
		, "CANCLE"							//point��ȸ�϶� filler
		, "BYPASS"
		, "RESP_MSG"
		
		};
	
	//A5 make dataMsg, withme -> pos
	static final int nlensPosRspA5[] = {
		2, 4, 2, 10, 12,
		100
		};
	
	static final String strHeadersPosRspA5[] = {
		"INQ_TYPE"
		, "MSG_TYPE"
		, "RESP_CD"
		, "CUST_CD"
		, "ORG_APPROVAL_NO"//ORG_APPROVAL_NO
		
		, "RESP_MSG"
		};
}