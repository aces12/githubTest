package biz.cms_MFCIrt;

import java.net.Socket;
import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;
import biz.comm.AES;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

@SuppressWarnings("unchecked")
public class MFCIrtConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;
	private String withme_fcstr_no = "";
	private String withme_corp_no = "";
	COMMLog df = null;

	
	public MFCIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}
	
	public String getMFCRspA4_webcash(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		df.CommLogger("in getMFCRspA4");
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// webcash로 보낼 송신 전문
		String recvBuf = "";		// webcash에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		withme_fcstr_no = PropertyUtil.findProperty("service-property", "WITHME_FCSTR_NO");
		withme_corp_no = PropertyUtil.findProperty("service-property", "WITHME_CORP_NO");
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.MFC_WEBCASH_FILTER)));
			df.CommLogger("actSock success");
			
			hm.put("ORG_CARD_NO", decryptCardNo(hm.get("CARD_NO").trim(), ret)); // 암호화 전달된 필드에서 순수 카드번호 16자리(org_card_no) 도출
			df.CommLogger("decryptCardNo["+hm.get("ORG_CARD_NO")+"]");
			
			sendMsg = makeSendDataMFCInq_webcash(hm, df, MFCIrtData.POSREQ_A4); // 업체 send 데이터 생성
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("MFC Server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("MFC actSock.receive");
			
			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[MFC_A4>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
//			//Receive 데이터 가공
			hmRecv = COMMBiz.getParseDataMultibyte(MFCIrtData.nlensSmsA4_webcash, MFCIrtData.strHeadersSmsA4_webcash, recvBuf);
			hmRecv.put("INQ_TYPE", "A4");
			hmRecv.put("CUST_CD", hm.get("CUST_CD"));//MFCIrtData.CUSTCODE_WEBCASH
			hmRecv.put("RESP_MSG", rspMsgParsing(hmRecv.get("RESP_CD")));//webcash 응답메세지

			
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, MFCIrtData.POSREQ_A4, df);
		}
		
		return dataMsg;
	}
	
	public String getMFCRspA5_webcash(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// webcash로 보낼 송신 전문
		String recvBuf = "";		// webcash에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		withme_fcstr_no = PropertyUtil.findProperty("service-property", "WITHME_FCSTR_NO");
		withme_corp_no = PropertyUtil.findProperty("service-property", "WITHME_CORP_NO");
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.MFC_WEBCASH_FILTER)));
			
			hm.put("ORG_CARD_NO", decryptCardNo(hm.get("CARD_NO").trim(), ret)); // 암호화 전달된 필드에서 순수 카드번호 16자리(org_card_no) 도출
			
			sendMsg = makeSendDataMFCInq_webcash(hm, df, MFCIrtData.POSREQ_A5);	// 업체 send 데이터 생성
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("MFC Server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("MFC actSock.receive");
			
			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[MFC_A5>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
//			//Receive 데이터 가공
			hmRecv = COMMBiz.getParseDataMultibyte(MFCIrtData.nlensSmsA5_webcash, MFCIrtData.strHeadersSmsA5_webcash, recvBuf);
			hmRecv.put("INQ_TYPE", "A5");
			hmRecv.put("CUST_CD", hm.get("CUST_CD"));//MFCIrtData.CUSTCODE_WEBCASH
			hmRecv.put("RESP_MSG", rspMsgParsing(hmRecv.get("RESP_CD")));
			hmRecv.put("MSG_TYPE", "1100");

		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, MFCIrtData.POSREQ_A5, df);
		}
		
		return dataMsg;
	}
	
	public String getMFCRspA4_purmee(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		df.CommLogger("in getMFCRspA4");
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// purmee로 보낼 송신 전문
		String recvBuf = "";		// purmee에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		withme_fcstr_no = PropertyUtil.findProperty("service-property", "WITHME_FCSTR_NO");
		withme_corp_no = PropertyUtil.findProperty("service-property", "WITHME_CORP_NO");
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.MFC_PURMEE_FILTER)));
			df.CommLogger("actSock success");
			
			hm.put("ORG_CARD_NO", decryptCardNo(hm.get("CARD_NO").trim(), ret));	// 암호화 전달된 필드에서 순수 카드번호 16자리(org_card_no) 도출
			
			sendMsg = makeSendDataMFCInq_purmee(hm, df, MFCIrtData.POSREQ_A4);	// 업체 send 데이터 생성
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("MFC Server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("MFC actSock.receive");
			
			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[MFC_A4>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
//			//Receive 데이터 가공
			hmRecv = COMMBiz.getParseDataMultibyte(MFCIrtData.nlensSmsA4_purmee, MFCIrtData.strHeadersSmsA4_purmee, recvBuf);
			hmRecv.put("INQ_TYPE", "A4");
			hmRecv.put("TRACE_NO", hm.get("TRACE_NO"));
			hmRecv.put("CUST_CD", hm.get("CUST_CD"));
			hmRecv.put("MSG_TYPE", "1100");

			
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, MFCIrtData.POSREQ_A4, df);
		}
		
		return dataMsg;
	}
	
	public String getMFCRspA5_purmee(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		HashMap<String,String> hmRecv = new HashMap<String,String>();
		
		String sendMsg = "";		// purmee로 보낼 송신 전문
		String recvBuf = "";		// purmee에서 받을 응답 전문
		String dataMsg = "";		// POS로 보낼 응답 전문
		String ret = "00";
		StringBuffer sb = null;
		
		withme_fcstr_no = PropertyUtil.findProperty("service-property", "WITHME_FCSTR_NO");
		withme_corp_no = PropertyUtil.findProperty("service-property", "WITHME_CORP_NO");
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.MFC_PURMEE_FILTER)));
			
			hm.put("ORG_CARD_NO", decryptCardNo(hm.get("CARD_NO").trim(), ret));	// 암호화 전달된 필드에서 순수 카드번호 16자리(org_card_no) 도출
			
			sendMsg = makeSendDataMFCInq_purmee(hm, df, MFCIrtData.POSREQ_A5);	// 업체 send 데이터 생성
			sb = new StringBuffer(sendMsg);			
			df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "]" + ":[" + sb.toString() + "]");
			
			if (actSock.send(sendMsg)) {
				df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>MFC] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("MFC Server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("MFC actSock.receive : "+recvBuf);
			
			sb = null;
			sb = new StringBuffer(recvBuf);			
			df.CommLogger("[MFC_A5>sms] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + sb.toString() + "]");
			
//			//Receive 데이터 가공
			hmRecv = COMMBiz.getParseDataMultibyte(MFCIrtData.nlensSmsA5_purmee, MFCIrtData.strHeadersSmsA5_purmee, recvBuf);
			hmRecv.put("INQ_TYPE", "A5");
			hmRecv.put("TRACE_NO", hm.get("TRACE_NO"));
			hmRecv.put("CUST_CD", hm.get("CUST_CD"));
			hmRecv.put("MSG_TYPE", "1100");

		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			dataMsg = ret + makeSendDataToPosRsp(hmRecv, MFCIrtData.POSREQ_A5, df);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataMFCInq_webcash(HashMap<String, String> hm, COMMLog df, int jobType) {
		df.CommLogger("in makeSendDataMFCInq");
		StringBuffer sb = new StringBuffer();
		
		switch(jobType){
		case MFCIrtData.POSREQ_A4:{
			hm.put("INQ_LENGTH", "0407");
			hm.put("USER_AREA", "CSCARD   "); //고정값
			hm.put("ISO_MSG_HEADER", "ISO000000000"); //고정값
			hm.put("MSG_TYPE", "0100"); //고정값 0100승인요청
			hm.put("PRI_BITMAP", "F23C66812EC09810"); //고정값
			
			hm.put("SEC_BITMAP", "0000000000000400"); //고정값
			hm.put("CARD_NO", hm.get("ORG_CARD_NO").length()+hm.get("ORG_CARD_NO")+"   ");//카드번호길이(2)+카드번호(16)+Space(3)
			hm.put("STATUS_CD", "031000");
//			hm.put("PAY_AMT", "000000001300");
//			hm.put("IRT_SEND_DATE_TIME", "20161124130210");	
			
//			hm.put("IRT_TRACE_NO", "675911");
//			hm.put("TERMINAL_TIME", "130210");
//			hm.put("TERMINAL_DATE", "20161124");
//			hm.put("VALIDATE_YYMM", "2108");
			hm.put("MCC_KIND", "0000"); //고정값
			
			hm.put("VAN_STATE_CD", "410"); //고정값
			hm.put("INPUT_TYPE", "9100");//입력형태코드
			hm.put("CARD_UNIQ_NO", "   ");
			hm.put("REG_KIND_CD", "00");//입력상황코드 현재사용안함
			hm.put("VAN_CD", "47  ");
			
			hm.put("CARD_TRACK2", "37"+hm.get("ORG_CARD_NO")+"="+hm.get("VALIDATE_YYMM"));//TRACK2길이(2)+카드번호(16)+"="(1)+유효기간(4)
//			hm.put("TRAN_UNIQ_NO", "161124130210"); //Space(12)
			hm.put("APPROVAL_NO", "        "); //Space(8)
			hm.put("RESP_CD", "  "); //Space(2)
			hm.put("TERMINAL_NO", "            ");//[8759686472  ](12)
			
			hm.put("FCSTR_NO", this.withme_fcstr_no);
			hm.put("CURRENCY_CD", "410"); //원화
			hm.put("PASSWORD", "                "); //Space(16)
			hm.put("PASSWORD_DATA", "                "); //Space(16)
			hm.put("POS_DATA", "100000000000");
			
			hm.put("DMST_DATA", "11100" + this.withme_corp_no + hm.get("DMST_DATA"));//길이(3)+할부개월수일시불(2)+사업자번호(10)+pos전달값세금,봉사료,승인여부(25)
			
			for( int i = 0;i < MFCIrtData.nlensSmsA4_webcash.length;i++ ) {
				StringUtil.appendSpace(sb, (String) hm.get(MFCIrtData.strHeadersSmsA4_webcash[i].toString()), MFCIrtData.nlensSmsA4_webcash[i]);
//				df.CommLogger("makeSendData "+MFCIrtData.strHeadersSmsA4_webcash[i].toString()+" "+MFCIrtData.nlensSmsA4_webcash[i]);
				}
			break;
			}
		case MFCIrtData.POSREQ_A5:{
			hm.put("INQ_LENGTH", "0399");
			hm.put("USER_AREA", "CSCARD   "); //고정값
			hm.put("ISO_MSG_HEADER", "ISO000000000"); //고정값
//			hm.put("MSG_TYPE", "0400"); //고정값, 아래 망취소 구분과 함께 값 할당
			hm.put("PRI_BITMAP", "F23C66812EC08010"); //고정값
			hm.put("SEC_BITMAP", "0000004000000400"); //고정값
			hm.put("CARD_NO", hm.get("ORG_CARD_NO").length()+hm.get("ORG_CARD_NO")+"   ");//카드번호길이(2)+카드번호(16)+Space(3)
			hm.put("STATUS_CD", "031000");
//			hm.put("PAY_AMT", "000000001300");
//			hm.put("IRT_SEND_DATE_TIME", "20161124130210");
//			hm.put("TRACE_NO", "675911");
//			hm.put("TERMINAL_TIME", "130210");
//			hm.put("TERMINAL_DATE", "20161124");
//			hm.put("VALIDATE_YYMM", "2108");
			hm.put("MCC_KIND", "0000"); //고정값
			hm.put("VAN_STATE_CD", "410"); //고정값
			hm.put("INPUT_TYPE", "9100");
			hm.put("CARD_UNIQ_NO", "   ");
			hm.put("REG_KIND_CD", "00");//현재사용안함
			hm.put("VAN_CD", "47  ");
			hm.put("CARD_TRACK2", "37"+hm.get("ORG_CARD_NO")+"="+hm.get("VALIDATE_YYMM"));//TRACK2길이(2)+카드번호(16)+"="(1)+유효기간(4)
//			hm.put("IRT_UNIQ_NO", "            ");//tran_uniq_no
			hm.put("ORG_APPROVAL_NO", hm.get("ORG_APPROVAL_NO").substring(0, 8)); //Space(8)  ORG_APPROVAL_NO
			hm.put("RESP_CD", "17"); //Space(2)
			hm.put("TERMINAL_NO", "            ");//(12)
			hm.put("FCSTR_NO", this.withme_fcstr_no);
			hm.put("CURRENCY_CD", "410"); //원화 
			hm.put("POS_DATA", "100000000000");
//			hm.put("ORG_DATA", "0100310000              ");		
			hm.put("DMST_DATA", "11100" + this.withme_corp_no + hm.get("DMST_DATA"));//길이(3)+할부개월수일시불(2)+사업자번호(10)+pos전달값세금,봉사료,승인여부(25)
			
			if(hm.get("MSG_TYPE").equals("3000")){//MSG_TYPE=3000 망취소
				hm.put("MSG_TYPE", "0400");//고정값(승인취소) 
				hm.put("RESP_CD", "68");
				hm.put("ORG_DATA", "0100"+hm.get("STATUS_CD")+hm.get("IRT_SEND_DATE_TIME"));//원거래전문번호"0100"(4)+거래구분코드(6)+전문전송일시(14)
				df.CommLogger("ORG_DATA ["+hm.get("ORG_DATA")+"]");
				}else{
					hm.put("MSG_TYPE", "0400");
					}
			
			for( int i = 0;i < MFCIrtData.nlensSmsA5_webcash.length;i++ ) {
				StringUtil.appendSpace(sb, (String) hm.get(MFCIrtData.strHeadersSmsA5_webcash[i].toString()), MFCIrtData.nlensSmsA5_webcash[i]);
				}
			break;
			}
		}
		return sb.toString();
	}
	
	private String makeSendDataMFCInq_purmee(HashMap<String, String> hm, COMMLog df, int jobType) {
		df.CommLogger("in makeSendDataMFCInq");
		StringBuffer sb = new StringBuffer();
		
		switch(jobType){
		case MFCIrtData.POSREQ_A4:{
			hm.put("INQ_LENGTH", "0261"); 
			hm.put("MSG_TYPE", "0500");	//승인 0500, 0510 | 취소요청 0600, 0610 | 포인트조회 0700, 0710
			hm.put("SEND_COM_CD", "WDME");
			hm.put("SEND_DATE", hm.get("IRT_SEND_DATE_TIME").substring(0, 8));
			hm.put("SEND_TIME", hm.get("IRT_SEND_DATE_TIME").substring(8, 14));
			
//			hm.put("TRACE_NO", "121212121212");
			hm.put("RESP_CD", "  ");
			hm.put("FCSTR_NO", this.withme_corp_no+hm.get("STORE_CD")); //corp_no(10)+점포코드(5)
//			hm.put("TRADE_DATE", "88888888");TERMINAL_DATE
//			hm.put("TRADE_TIME", "666666");TERMINAL_TIME
			
			hm.put("USE_TYPE", "11");
//			hm.put("WCC", hm.get("INPUT_TYPE"));
			hm.put("CARD_TRACK2", hm.get("ORG_CARD_NO")+"="+hm.get("VALIDATE_YYMM"));//카드번호(16)+"="(1)+유효기간(4)+appendSpace
			hm.put("PASSWORD", "                ");
			hm.put("PAY_AMT", hm.get("PAY_AMT").substring(2));
			
			hm.put("APPROVAL_NO", "            ");
			hm.put("FILLER1", "        ");
			hm.put("FILLER2", "            "); 
			hm.put("POINT_START", "         ");
			hm.put("POINT_ABLE", "         "); 
			
			hm.put("POINT_REMAIN", "         ");
			hm.put("CANCLE", "0");//승인요청:0 | 500번TimeOut:5 | 단말기취소:7 | R거래(원승인번호 없는 취소거래):9
			hm.put("BYPASS", "                    ");
			hm.put("RESP_MSG", "                                                  ");
			
			for( int i = 0;i < MFCIrtData.nlensSmsA4_purmee.length;i++ ) {
				StringUtil.appendSpace(sb, (String) hm.get(MFCIrtData.strHeadersSmsA4_purmee[i].toString()), MFCIrtData.nlensSmsA4_purmee[i]);
				}
			break;
			}
		case MFCIrtData.POSREQ_A5:{
			hm.put("INQ_LENGTH", "0261"); 
//			hm.put("MSG_TYPE", "0600");	//승인 0500, 0510 | 취소요청 0600, 0610 | 포인트조회 0700, 0710
			hm.put("SEND_COM_CD", "WDME");
			hm.put("SEND_DATE", hm.get("IRT_SEND_DATE_TIME").substring(0, 8));
			hm.put("SEND_TIME", hm.get("IRT_SEND_DATE_TIME").substring(8, 14));
			
//			hm.put("TRACE_NO", "121212121212");
			hm.put("RESP_CD", "  ");
			hm.put("FCSTR_NO", this.withme_corp_no+hm.get("STORE_CD")); //corp_no(10)+점포코드(5)
//			hm.put("TRADE_DATE", "88888888");TERMINAL_DATE
//			hm.put("TRADE_TIME", "666666");TERMINAL_TIME
			
			hm.put("USE_TYPE", "11");
//			hm.put("WCC", hm.get("INPUT_TYPE"));
			hm.put("CARD_TRACK2", hm.get("ORG_CARD_NO")+"="+hm.get("VALIDATE_YYMM"));//카드번호(16)+"="(1)+유효기간(4)+appendSpace
			hm.put("PASSWORD", "                ");
			hm.put("PAY_AMT", hm.get("PAY_AMT").substring(2));
			
			hm.put("APPROVAL_NO", "            ");
			hm.put("ORG_ADMIT_DATE", "        ");
			hm.put("ORG_ADMIT_NO", "            "); 
			hm.put("POINT_START", "         ");
			hm.put("POINT_ABLE", "         "); 
			
			hm.put("POINT_REMAIN", "         ");
			hm.put("CANCLE", "7");//승인요청:0 | 500번TimeOut:5 | 단말기취소:7 | R거래(원승인번호 없는 취소거래):9
			hm.put("BYPASS", "                    ");
			hm.put("RESP_MSG", "                                                  ");
						
			if(hm.get("MSG_TYPE").equals("3000")){//MSG_TYPE=3000 망취소
				hm.put("CANCLE", "9");
				hm.put("MSG_TYPE", "0600");
				}else{
					hm.put("MSG_TYPE", "0600");
					}
			
			for( int i = 0;i < MFCIrtData.nlensSmsA4_purmee.length;i++ ) {
				StringUtil.appendSpace(sb, (String) hm.get(MFCIrtData.strHeadersSmsA5_purmee[i].toString()), MFCIrtData.nlensSmsA5_purmee[i]);
				}
			break;
			}
		
		}
		return sb.toString();
	}
	
	private String makeSendDataToPosRsp(HashMap<String, String> hm, int rspType, COMMLog df) {
		StringBuffer sb = new StringBuffer();								
		switch(rspType){
		case MFCIrtData.POSREQ_A4:{
			for (int i = 0; i < MFCIrtData.nlensPosRspA4.length; i++) {
				StringUtil.appendSpace(sb, (String) hm.get(MFCIrtData.strHeadersPosRspA4[i].toString()), MFCIrtData.nlensPosRspA4[i]);
			}
			break;
			}
		case MFCIrtData.POSREQ_A5:{
			for (int i = 0; i < MFCIrtData.nlensPosRspA5.length; i++) {
				StringUtil.appendSpace(sb, (String) hm.get(MFCIrtData.strHeadersPosRspA5[i].toString()), MFCIrtData.nlensPosRspA5[i]);
			}
			break;
			}
		default :{
				//do nothing
			}
		}	
		return sb.toString();
	}
	/**
	 * 필드 암호화 string type->encrypt(string)
	 * @param cardno
	 * @param ret
	 * @return encrypt(crypt)
	 * @throws Exception
	 */
	public String encryptCardNo(String crypt, String ret) throws Exception{
		try{
			AES aes = new AES();
			return aes.encrypt(crypt);
		}catch(Exception e){
			df.CommLogger("▶ [ERROR] : encrypt error/"+ e.getMessage());
			ret = "29";
			throw e;
		}
	}
	/**
	 * 암호화된 필드 해독 encrypt(string)->string type
	 * @param cardno
	 * @param ret
	 * @return decrypt(crypt)
	 * @throws Exception
	 */
	public String decryptCardNo(String crypt, String ret) throws Exception{
		try{
			AES aes = new AES();
			return aes.decrypt(crypt);
		}catch(Exception e){
			df.CommLogger("▶ [ERROR] : decrypt error/"+ e.getMessage());
			ret = "29";
			throw e;
		}
	}

	/**
	 * 응답 코드에 따른 응답 메시지 파싱
	 * @param rspCode
	 * @param ret
	 * @return rspMessage(rspCode)
	 * @throws Exception
	 */
	public String rspMsgParsing(String rspCode)throws Exception{
		String rspMsg = "";
		if (rspCode.equals("00")){rspMsg = "정상";		
		}else if (rspCode.equals("20")){	rspMsg = "ISP인증절차가 생략되거나 ISP 미등록회원인 경우 거래 불가";
		}else if (rspCode.equals("21")){	rspMsg = "KEY-IN 승인불가 가맹점";
		}else if (rspCode.equals("22")){	rspMsg = "당월중 KEY IN 승인 한도 초과";
		}else if (rspCode.equals("23")){	rspMsg = "가맹점 매출한도초과";
		}else if (rspCode.equals("24")){	rspMsg = "가맹점 자기매출 발생";
		}else if (rspCode.equals("25")){	rspMsg = "1일한도초과";
		}else if (rspCode.equals("26")){	rspMsg = "월간한도초과";
		}else if (rspCode.equals("27")){	rspMsg = "사고등록계좌";
		}else if (rspCode.equals("30")){	rspMsg = "전문 FORMAT ERROR";
		}else if (rspCode.equals("31")){	rspMsg = "당회회원아님";
		}else if (rspCode.equals("32")){	rspMsg = "가맹점번호 미존재";
		}else if (rspCode.equals("33")){	rspMsg = "할부기간 재입력";
		}else if (rspCode.equals("34")){	rspMsg = "승인금액 재입력";
		}else if (rspCode.equals("36")){	rspMsg = "원거래없음";
		}else if (rspCode.equals("37")){	rspMsg = "고유번호중복";
		}else if (rspCode.equals("38")){	rspMsg = "통장잔액부족";
		}else if (rspCode.equals("39")){	rspMsg = "1회한도초과";
		}else if (rspCode.equals("41")){	rspMsg = "유효기한 경과";
		}else if (rspCode.equals("42")){	rspMsg = "전카드 사용기한 경과";
		}else if (rspCode.equals("43")){	rspMsg = "기업카드로 할부거래불가";
		}else if (rspCode.equals("44")){	rspMsg = "취소불가 승인번호";
		}else if (rspCode.equals("50")){	rspMsg = "해지가맹점";
		}else if (rspCode.equals("51")){	rspMsg = "할부판매대상 가맹점이 아님";
		}else if (rspCode.equals("52")){	rspMsg = "잔액증명발급계좌";
		}else if (rspCode.equals("53")){	rspMsg = "거래정지된 가맹점";
		}else if (rspCode.equals("56")){	rspMsg = "유효기한 입력 오류";
		}else if (rspCode.equals("58")){	rspMsg = "승인기관과 취소기관상이";
		}else if (rspCode.equals("60")){	rspMsg = "거래중지중인카드";
		}else if (rspCode.equals("62")){	rspMsg = "상품권한도 초과";
		}else if (rspCode.equals("63")){	rspMsg = "분실도난카드";
		}else if (rspCode.equals("64")){	rspMsg = "할부구매제한자";
		}else if (rspCode.equals("65")){	rspMsg = "결제대금이 연체되어 있는 회원";
		}else if (rspCode.equals("66")){	rspMsg = "타카드 연체";
		}else if (rspCode.equals("67")){	rspMsg = "전카드승인시 최종카드 사고 회원";
		}else if (rspCode.equals("68")){	rspMsg = "CVC등 검증값 오류";
		}else if (rspCode.equals("69")){	rspMsg = "비밀번호 오류입니다";
		}else if (rspCode.equals("70")){	rspMsg = "한도초과회원";
		}else if (rspCode.equals("80")){	rspMsg = "허가된 거래가 아님";
		}else if (rspCode.equals("81")){	rspMsg = "회원등록당일 거래승인불가";
		}else if (rspCode.equals("83")){	rspMsg = "비밀번호 연속오류입력횟수 초과";
		}else if (rspCode.equals("88")){	rspMsg = "시스템장애로 인해 거절처리";
		}else if (rspCode.equals("90")){	rspMsg = "전자상거래 PG서브몰 사업자 번호 검증불가";	
		}else if (rspCode.equals("92")){	rspMsg = "클린카드에 의한 업종 사용제한";
		}else if (rspCode.equals("93")){	rspMsg = "클린카드에 의한 시간 사용제한";
		}else if (rspCode.equals("95")){	rspMsg = "포인트사용불가 가맹점";
		}else if (rspCode.equals("96")){	rspMsg = "포인트금액부족";
		}else if (rspCode.equals("A1")){	rspMsg = "5만원미만 할부거래 불가";
		}else if (rspCode.equals("A3")){	rspMsg = "IC 카드 승인 불가 ";
		}else if (rspCode.equals("A6")){	rspMsg = "구매 카드 가맹점 아님";
		}else if (rspCode.equals("B1")){	rspMsg = "승인요청방식 오류";
		}else if (rspCode.equals("B4")){	rspMsg = "복지카드 가맹점 아님";
		}else if (rspCode.equals("B5")){	rspMsg = "무료입장 서비스 불가";
		}else if (rspCode.equals("B6")){	rspMsg = "할인서비스 이용 불가";
		}else if (rspCode.equals("B7")){	rspMsg = "비밀번호 미입력";
		}else if (rspCode.equals("C3")){	rspMsg = "탈회카드";
		}else if (rspCode.equals("C4")){	rspMsg = "미교부카드";
		}else if (rspCode.equals("C5")){	rspMsg = "비밀번호 미등록 회원";
		}else if (rspCode.equals("D1")){	rspMsg = "체크카드 할부 불가";
		}else if (rspCode.equals("G3")){	rspMsg = "체크카드 시스템 점검 시간";   
		}else if (rspCode.equals("G4")){	rspMsg = "체크카드 시스템 정기 점검 시간";        
		}else if (rspCode.equals("I1")){	rspMsg = "ARQC검증오류";                 
		}else if (rspCode.equals("CC")){	rspMsg = "카드사 전화 요망 비밀번호 3회 초과오류";   
		}else if (rspCode.equals("ZZ")){	rspMsg = "VAN사건별 대행처리 요청";          
		}else if (rspCode.equals("45")){	rspMsg = "매출표매입으로 취소불가";
		}else if (rspCode.equals("U0")){	rspMsg = "요청매수 미존재 혹은 0매";
		}else if (rspCode.equals("V0")){	rspMsg = "해당서비스대상 제휴카드아님";
		}else if (rspCode.equals("V1")){	rspMsg = "해당 거래가 허가된 가맹점 아님";
		}else if (rspCode.equals("V2")){	rspMsg = "기준월 이용 실적 부족";
		}else if (rspCode.equals("V3")){	rspMsg = "기준 내 이용횟수 초과";
		}else if (rspCode.equals("V4")){	rspMsg = "일 이용 횟수 초과";
		}else if (rspCode.equals("V5")){	rspMsg = "이용매수 초과";		
		}else{	rspMsg = "알수 없는 응답코드 ";
		}
			
		return rspMsg;
		
	} 	
}
