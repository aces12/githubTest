package biz.cms_PDACommIf2;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import biz.comm.COMMBiz_PDA;
import biz.comm.COMMLog;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;
 
public class PDACommIFBackDAO2 extends GenericDAO {

	private static String STORE_FIRST_CODE 		= "A16";
	private static int ROWS_COUNT_SIZE = 10;
	
	/***************************************************************************
	 * selScanPluInfo
	 * : [점포 발주] 스캔(저장) - FF발주 선마감 반영 2016.10.21 I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setScanPluUpdateNew(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		int nAMT = 0;
		int i = 0;
		connect("STRORD");
		try {
			begin();
				
			String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
			String INPUT_DT = ""; // 발주일자
			
			int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			// 발주 처리
			//
			for(idx = 0;idx < total_cnt;idx++ ) {
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.TB_NEW_ORDER_UPDATE));

				int INPUT_COUNT = Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
				String ITEM_CD = (String)hm.get("ITEM_CD" + Integer.toString(idx)).toString().trim();
				INPUT_DT = (String)hm.get("INPUT_DT" + Integer.toString(idx)).toString().trim();

				i=0;
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, INPUT_DT);
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, ITEM_CD );
				if( hm.get("INQ_TYPE") == "27") {
					sql.setString( ++i, "202");		// 스캔발주
				}else if(hm.get("INQ_TYPE") == "48"){
					sql.setString( ++i, "201");		// 발주수정
				}else {
					sql.setString( ++i, "203");		// 긴급발주
				}
				sql.setInt   ( ++i, INPUT_COUNT );
				sql.setInt   ( ++i, INPUT_COUNT );
				sql.setInt   ( ++i, INPUT_COUNT );
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, ITEM_CD );
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, INPUT_DT);
				sql.setString( ++i, ORG_CD);
				
				sql.setString( ++i, INPUT_DT);
				sql.setString( ++i, INPUT_DT);
				
//				nAMT += nCount * GDS_COST;
				
				df.CommLogger("▶ SQL 1: " + sql.debug() );
				int rows = executeUpdate(sql);
				df.CommLogger("▶ ***************************************** rows : " + rows );
				if (rows > 0)
				{
					nAMT += Integer.parseInt((String)hm.get("ADD_TO_LOANAMT" + Integer.toString(idx)).toString().trim());
				}
				sql.close();
			}

		}catch(SQLException e) {
			//rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			//rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			//end();			
			dataMsg = ret;
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
}
