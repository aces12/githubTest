package biz.cms_PDACommIf2;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz_PDA;
import biz.comm.COMMLog;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;
 
public class PDACommIFDAO2 extends GenericDAO {
	private static Logger logger = Logger.getLogger(PDACommIFAction2.class);
	private static String STORE_FIRST_CODE 		= "A16";
	private static int ROWS_COUNT_SIZE = 10;
	
	/***************************************************************************
	 * selUserInfoStore 사용자 조회 STORE
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selUserInfoStore(String comCD, String storeCD, String userID, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap(); 
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		//
		connect("CMGNS");
		try {
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_USER_INFO));
			sql.setString(++i, userID.trim());
			sql.setString(++i, STORE_FIRST_CODE + storeCD.trim());
			sql.setString(++i, comCD.trim());

//			df.CommLogger("SQL:" + sql.debug());
			list = executeQuery(sql);
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				String userPW = (String)map.get("USER_PW");
				if( userPW.length() > 0 ) {
					map.put("USER_PWD", userPW);
				}else{
					map.put("USER_PWD", "");
				}
				String userNM = (String)map.get("USER_NM");
				if( userNM.length() > 0 ) {
					map.put("USER_NM", userNM);
				}else{
					map.put("USER_NM", "");
				}
				String userTY = (String)map.get("STR_STAFF_TP");
				if( userTY.length() > 0 ) {
					map.put("USER_LEVEL", userTY);
				}else{
					map.put("USER_LEVEL", "");
				}
				String WRKPLC_TP = (String)map.get("WRKPLC_TP");
				if( WRKPLC_TP.length() > 0 ) {
					map.put("USER_TYPE", WRKPLC_TP);
				}else{
					map.put("USER_TYPE", "");
				}
			}else {
				map.put("USER_PWD", " ");
				map.put("USER_NM", " ");
				map.put("USER_LEVEL", " ");
				map.put("USER_TYPE", " ");
				ret = "09";
			}
			
			hm.put("INQ_TYPE", "10");
			hm.put("USER_ID", userID);
			hm.put("USER_PWD", (String)map.get("USER_PWD"));
			hm.put("USER_NM", (String)map.get("USER_NM"));
			hm.put("USER_LEVEL", (String)map.get("USER_LEVEL"));
			hm.put("USER_TYPE", (String)map.get("USER_TYPE"));
			
//			sql.close();
//			sql.clearParameter();
//			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.WM_ORDERTIME_CHECK));
//			df.CommLogger("SQL:" + sql.debug());
//			List list2 = executeQuery(sql);
//			df.CommLogger("list2 size :" +  list2.size() );
		}catch(SQLException e) {
			df.CommLogger("SQL:" + sql.debug());
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("SQL:" + sql.debug());
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			dataMsg = ret + makeUserInfoSendData(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeUserInfoSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeUserInfoSendData(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 13, 60, 50, 2, 2 };
		String strHeaders[] = {
				"INQ_TYPE",   	// "10": Search User(사용자 조회)
				"USER_ID",		// User ID(사용자ID)
				"USER_PWD",    	// User Password(사용자 비밀번호)
				"USER_NM",		// User Name(사용자 이름)
				"USER_LEVEL",	// User Level(사용자 레벨)
				"USER_TYPE"	// User Level(사용자 레벨)
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger(strHeaders[i].toString() + (String)hm.get(strHeaders[i].toString()) );
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	public String DelPrintMst(String pSTORE_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int iRtn = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();

			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.DEL_IQ_PRINT_MST));
			sql.setString(++i, "A16" + pSTORE_CD);				// BIZLOC_ORG_CD
			
			
			df.CommLogger(sql.debug());
			iRtn = executeUpdate(sql);
//			df.CommLogger(String.valueOf(iRtn));
			if(iRtn == 1){
			hm.put("INQ_TYPE", "72");
			hm.put("RESULT_CD", "00");
			}
			else{
				hm.put("INQ_TYPE", "72");
				hm.put("RESULT_CD", "01");
			}
			
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e.getStackTrace());
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makePRINTMSTInfoSendData(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String insPrintMst(String pCOM_CD, String pSTORE_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int iRtn = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();

			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.INS_PRINT_MST));
			sql.setString(++i, pCOM_CD.toString().trim());							// CO_CD
			sql.setString(++i, "A16" + pSTORE_CD);									// BIZLOC_ORG_CD
			//날짜입력 해야함 현재일
			SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
			Calendar cDate = Calendar.getInstance();								/* 달력 */
			
			String ys = SDF.format(cDate.getTime());								/* 스캔일 */
			sql.setString(++i, ys);
			sql.setString(++i, "A16" + pSTORE_CD);									// BIZLOC_ORG_CD
			sql.setString(++i, "A16" + pSTORE_CD);									// BIZLOC_ORG_CD
			sql.setString(++i, (String)hm.get("IP"));								// IP 주소
			sql.setString(++i, "A16" + pSTORE_CD);									// BIZLOC_ORG_CD
			sql.setString(++i, (String)hm.get("PLU_CD").trim());					// PLU_CD
			sql.setString(++i, pCOM_CD.toString().trim());							// CO_CD
			
			//df.CommLogger(sql.debug());
			iRtn = executeUpdate(sql);
			//df.CommLogger(String.valueOf(iRtn));
			if(iRtn == 1){
			hm.put("INQ_TYPE", "76");
			hm.put("RESULT_CD", "00");
			}
			else{
				hm.put("INQ_TYPE", "76");
				hm.put("RESULT_CD", "01");
			}
			
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e.getStackTrace());
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makePRINTMSTInfoSendData(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String insExceptOrd(String pCOM_CD, String pSTORE_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int iRtn = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.INS_EXCEPT_ORD));
			sql.setString(++i, (String)hm.get("ORD_ENBL_TP").trim());   			// 발주가능여부
			sql.setString(++i, "A16" + pSTORE_CD);									// BIZLOC_ORG_CD
			sql.setString(++i, (String)hm.get("PLU_CD").trim());					// PLU_CD
			sql.setString(++i, pCOM_CD.toString().trim());							// CO_CD
			sql.setString(++i, (String)hm.get("ITEM_CD").trim());					// ITEM_CD
			//날짜입력 해야함 현재일 
			//SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
			//Calendar cDate = Calendar.getInstance();								/* 달력 */
			
			//String ys = SDF.format(cDate.getTime());								/* 스캔일 */
			//sql.setString(++i, ys);
			//df.CommLogger(sql.debug());
			iRtn = executeUpdate(sql);
			//df.CommLogger(String.valueOf(iRtn));
			if(iRtn == 1){
			hm.put("INQ_TYPE", "39");
			hm.put("RESULT_CD", "00");
			}
			else{
				hm.put("INQ_TYPE", "39");
				hm.put("RESULT_CD", "01");
			}
			
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e.getStackTrace());
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makePRINTMSTInfoSendData(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	

	/***************************************************************************
	 * makeSaleInfoChkSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makePRINTMSTInfoSendData(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 2 };
		String strHeaders[] = {
				"INQ_TYPE",   	// 버전체크
				"RESULT_CD"//결과
				
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger(strHeaders[i].toString() + (String)hm.get(strHeaders[i].toString()) );
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	public String insPDAVersion(String pCOM_CD, String pSTORE_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int iRtn = 0;
		String dataMsg = "";
		String ret = "00";
		List list = null;
		Map map = new HashMap(); 
		connect("CMGNS");
		try {
			begin();

			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.INS_PDAVERSION_MGR));
			sql.setString(++i, pCOM_CD.toString().trim());											// CO_CD
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD"));									// BIZLOC_ORG_CD
			sql.setString(++i, (String)hm.get("PDA_NO"));											// PDA_NO
			sql.setString(++i, (String)hm.get("IP_ADDR"));											// TRAN_NO
			sql.setString(++i, (String)hm.get("VERSION"));											// TOT_SALE_AMT
			
			iRtn = executeUpdate(sql);
//			df.CommLogger(String.valueOf(iRtn));
			if(iRtn == 1){
			//hm.put("INQ_TYPE", "76");
			//hm.put("RESULT_CD", "00");
			}
			else{
				hm.put("INQ_TYPE", "76");
				hm.put("RESULT_CD", "00");
			}
			sql.close();// sql 닫기
			sql.clearParameter();//파라미터 비우기
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PDAVERSION_MGR));
			//df.CommLogger(sql.debug());
			list = executeQuery(sql);
			//카운팅 값
			
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				String RESULT = (String)map.get("RESULT_CD");
				if( RESULT.length() > 0 ) {
					hm.put("INQ_TYPE", "76");
					hm.put("RESULT_CD", RESULT);
				}else{
					hm.put("RESULT_CD", "00");
				}
			}
			else
			{
				ret = "09";
			}
			sql.close();
			
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e.getStackTrace());
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeSaleInfoChkSendData(hm, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selNoxChk : 위해상품 여부 요청
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	public String selNoxChk(String Plu_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int iRtn = 0;
		String dataMsg = "";
		String ret = "00";
		List list = null;
		Map map = new HashMap(); 
		connect("CMGNS");
		try {
			begin();

			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_NOX_INFO));
			sql.setString(++i, Plu_CD.trim());									// 상품코드
			
			//df.CommLogger("▶ SQL : " + sql.debug() );
			list = executeQuery(sql);
			if(list.size() > 0){
				map = (Map)list.get(0);
				String Nox = (String)map.get("RESULT");
				if(Nox.length()>0){
					map.put("RESULT", Nox);
				}
				else{
					map.put("RESULT", "0");
				}
			}
			else{
				map.put("RESULT", "0");
				ret = "09";
			}
			
			hm.put("INQ_TYPE", "78");
			hm.put("RESULT", (String)map.get("RESULT"));
			sql.close();
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeSelNoxSendData(hm,df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selSaleChk : 상품판매 가능여부 요청
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	public String selSaleChk(String pSTORE_CD, String Plu_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int iRtn = 0;
		String dataMsg = "";
		String ret = "00";
		List list = null;
		Map map = new HashMap(); 
		connect("CMGNS");
		try {
			begin();

			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_SEL_ST_STRGDS_MST));
			sql.setString(++i, Plu_CD.trim());									// 상품코드
			sql.setString(++i, pSTORE_CD.trim());									// 점포코드
			//df.CommLogger("▶ SQL : " + sql.debug() );
			list = executeQuery(sql);
			if(list.size() > 0){
				map = (Map)list.get(0);
				String SaleChk = (String)map.get("SAL_ENBL_YN");
				if(SaleChk.length()>0){
					map.put("SALE_CHK", SaleChk);
				}
				else{
					map.put("SALE_CHK", "0");
				}
				String PLU_NM = (String)map.get("GDS_NM");
				if(PLU_NM.length()>0){
					map.put("PLU_NM", PLU_NM);
				}
				else
				{
					map.put("PLU_NM", "");
				}
				String AMT = (String)map.get("GDS_SAL_PRC");
				if(AMT.length()>0){
					map.put("AMT", AMT);
				}else{
					map.put("AMT", "");
				}
			}
			else{
				map.put("SALE_CHK", "0");
				map.put("PLU_NM", " ");
				map.put("AMT", " ");
				ret = "09";
			}
			
			hm.put("INQ_TYPE", "77");
			hm.put("SALE_CHK", (String)map.get("SAL_ENBL_YN"));
			hm.put("PLU_NM", (String)map.get("GDS_NM"));
			hm.put("AMT", (String)map.get("GDS_SAL_PRC"));
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeSalInfoSendData(hm,df);
			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selSaleChk2 : 상품판매 가능여부 요청  - PLU(바코드) 체크추가 I.G
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	public String selSaleChk2(String pSTORE_CD, String Plu_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		
		int i = 0;
		int j = 0;
		int iRtn = 0;
		String dataMsg = "";
		String ret = "00";
		List list = null;
		List list1 = null;
		Map map = new HashMap(); 
		Map map1 = new HashMap();
		connect("CMGNS");
		try {
			begin();
			
			String pLU_CD = (String)hm.get("PLU_CD").trim();
			String pCOM_CD = "1002";
			
			if (pLU_CD.length() < 13) {			
				sql1.put(findQuery(COMMBiz_PDA.PDA_SQL,	COMMBiz_PDA.SEL_PLU_INFO_CHK));				
				sql1.setString(++j, pLU_CD);                         /* PLU코드 */
				sql1.setString(++j, pLU_CD);                         /* PLU코드 */
				sql1.setString(++j, pCOM_CD);                        /* 회사코드 */
				sql1.setString(++j, STORE_FIRST_CODE + pSTORE_CD);   /* 점포코드 */
				sql1.setString(++j, pLU_CD);                         /* PLU코드 */
				
				df.CommLogger(sql1.debug());

				list1 = executeQuery(sql1);				
				map1 = (Map) list1.get(0);				
				pLU_CD = (String) map1.get("PLU_CD_N");
				//df.CommLogger("▶ pLU_CD ********** : "+pLU_CD);
				sql1.clearParameter();
				sql1.close();
			}
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_SEL_ST_STRGDS_MST));
			
			sql.setString(++i, pLU_CD);									            // 상품코드			
			sql.setString(++i, pSTORE_CD.trim());									// 점포코드			
			df.CommLogger("▶ SQL : " + sql.debug() );
			list = executeQuery(sql);
			
			if(list.size() > 0){
				map = (Map)list.get(0);
				String SaleChk = (String)map.get("SAL_ENBL_YN");
				if(SaleChk.length()>0){
					map.put("SALE_CHK", SaleChk);
				}
				else{
					map.put("SALE_CHK", "0");
				}
				String PLU_NM = (String)map.get("GDS_NM");
				if(PLU_NM.length()>0){
					map.put("PLU_CD", pLU_CD); /* 추가 I.G */
					map.put("PLU_NM", PLU_NM);					
				}
				else
				{
					map.put("PLU_CD", ""); /* 추가 I.G */
					map.put("PLU_NM", "");					
				}
				String AMT = (String)map.get("GDS_SAL_PRC");
				if(AMT.length()>0){
					map.put("AMT", AMT);
				}else{
					map.put("AMT", "");
				}
			}
			else{
				map.put("SALE_CHK", "0");
				map.put("PLU_CD", " "); /* 추가 I.G */
				map.put("PLU_NM", " ");
				map.put("AMT", " ");
				ret = "09";
			}
			
			hm.put("INQ_TYPE", "94");
			hm.put("SALE_CHK", (String)map.get("SAL_ENBL_YN"));
			hm.put("PLU_CD", pLU_CD); /* 추가 I.G */
			hm.put("PLU_NM", (String)map.get("GDS_NM"));
			hm.put("AMT", (String)map.get("GDS_SAL_PRC"));
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeSalInfoSendData2(hm,df);
			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeSalInfoSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeSalInfoSendData(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 2, 50,10 };
		String strHeaders[] = {
				"INQ_TYPE",   	// "77": 상품판매 가능여부
				"SALE_CHK",
				"PLU_NM",
				"AMT"
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger(strHeaders[i].toString() + (String)hm.get(strHeaders[i].toString()) );
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * makeSalInfoSendData2 : Make Data Part Sending Data(데이타부 전송데이타를 만듬)
	 *  - PLU_CD 추가 I.G
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeSalInfoSendData2(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 2, 50, 10, 30 };
		String strHeaders[] = {
				"INQ_TYPE",   	// "93": 상품판매 가능여부
				"SALE_CHK",				
				"PLU_NM",
				"AMT",
				"PLU_CD"
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger(strHeaders[i].toString() + (String)hm.get(strHeaders[i].toString()) );
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * makeSalInfoSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeSelNoxSendData(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 2 };
		String strHeaders[] = {
				"INQ_TYPE",   	// "77": 상품판매 가능여부
				"RESULT"
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger(strHeaders[i].toString() + (String)hm.get(strHeaders[i].toString()) );
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * makeSaleInfoChkSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeSaleInfoChkSendData(HashMap hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 5 };
		String strHeaders[] = {
				"INQ_TYPE",   	// 버전체크
				"RESULT_CD"		//결과
				
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger(strHeaders[i].toString() + (String)hm.get(strHeaders[i].toString()) );
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * selScanPluInfo
	 * : 점포발주-스캔방식 상품정보 요청
	 * IQ_SCAN_ORDER_REQ
	 * @param comCD
	 * @param storeCD
	 * @param pluCD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selScanPluInfo(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		//Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();
			
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_SCAN_PLUINFO));
//				df.CommLogger("▶ storeCD : "+ STORE_FIRST_CODE + pSTORE_CD);
//				df.CommLogger("▶ pCOM_CD : "+ pCOM_CD);
//				df.CommLogger("▶ PLU_CD : "+ (String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
//				df.CommLogger("▶ INPUT_DT : "+ (String)hm.get("INPUT_DT").toString().trim() );
//				df.CommLogger("▶ SQL : " + sql.get().toString() );
//				df.CommLogger("SQL2: " + sql.debug());
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// PLU_CD
				/// 회사
				///
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, pCOM_CD);
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());
				sql.setString(++i, pCOM_CD);
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);
				sql.setString(++i, pCOM_CD);
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* 이너박스바코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* 소박스 바코드 */
				sql.setString(++i, pCOM_CD);
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				
				//df.CommLogger("▶ SQL : " + sql.debug() );
				//df.CommLogger("M1: " + sql.get());
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
//				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 )
				{
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("PLU_TP", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", " ");
					hm.put("ORD_LOW", " ");
					hm.put("ORD_MAX", " ");
					hm.put("NSTCK_QTY", " ");
					hm.put("SALE_QTY", " ");
					hm.put("STR_SAL_PRC", " ");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", " ");
					hm.put("SORD_QTY", " ");
					hm.put("AMT", " ");
					hm.put("DEL_YN", " ");
					// SUP_PLAN_DT
					ret = "09";
				}
			} 
			else 
			{
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeScanPluInfo(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selScanPluInfo
	 * : 점포발주-스캔방식 상품정보 요청 [ 전일발주수량 ] - 상품대 제외배송처, 금액추가
	 * IQ_SCAN_ORDER_REQ
	 * @param comCD
	 * @param storeCD
	 * @param pluCD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selScanPluInfo3(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		//Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		Map map = new HashMap(); 
		connect("CMGNS");
		try {
			begin();
			
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_MSTCHK));
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());/* PLU코드 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);
				//df.CommLogger(sql.debug());
				list = executeQuery(sql);
				//df.CommLogger(String.valueOf(list.size()));
				if(list.size() > 0){
					map = (Map)list.get(0);
					String ICHK = (String)map.get("ITEM_CHK");
					//df.CommLogger(ICHK);
					if(ICHK.equals("0")){
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");
						
						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");
						
						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");
						
						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY"," ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret ="10";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						
						return dataMsg;
					}
					sql.clearParameter();
					sql.close();
					i = 0;
					list.clear();
				}
				sql.clearParameter();
				sql.close();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_AMT_DVY));
//				df.CommLogger("▶ storeCD : "+ STORE_FIRST_CODE + pSTORE_CD);
//				df.CommLogger("▶ pCOM_CD : "+ pCOM_CD);
//				df.CommLogger("▶ PLU_CD : "+ (String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
//				df.CommLogger("▶ INPUT_DT : "+ (String)hm.get("INPUT_DT").toString().trim() );
//				df.CommLogger("▶ SQL : " + sql.get().toString() );
//				df.CommLogger("SQL2: " + sql.debug());
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// PLU_CD
				/// 회사
				///
				//이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();								/* 달력 */
				cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);											/* 전일계산 */
				String ys = SDF.format(cDate.getTime());								/* 발주전일 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, pCOM_CD);									  /* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD);									  /* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				  /* 조직코드 */
				sql.setString(++i, pCOM_CD);									  /* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				
				sql.setString(++i, ys);											/* 전일발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				/* 조직코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
				sql.setString(++i, pCOM_CD); 								  	/* 회사코드 */
				 
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				/* 조직코드 */
				sql.setString(++i, pCOM_CD); 								  	/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				/* 조직코드 */
				
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* 이너박스바코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* 소박스 바코드 */
				sql.setString(++i, pCOM_CD);									/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				
				df.CommLogger("▶ SQL : " + sql.debug() );
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
//				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 )
				{
					hm.put("INQ_TYPE", " ");
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("NSTCK_QTY", " ");
					hm.put("SORD_QTY", " ");
					hm.put("SALE_QTY", " ");
					
					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", " ");
					hm.put("ORD_LOW", " ");
					hm.put("ORD_MAX", " ");
					
					hm.put("STR_SAL_PRC", " ");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", " ");
					
					hm.put("AMT", " ");
					hm.put("DEL_YN", " ");
					hm.put("YS_QTY"," ");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");
					// SUP_PLAN_DT
					ret = "09";
				}
			} 
			else 
			{
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeScanPluInfo3(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selScanPluInfo4
	 * : 점포발주-스캔방식 상품정보 요청 [ 전일발주수량 ] - 이익율,행사,반품구분 등 추가 I.G
	 * IQ_SCAN_ORDER_REQ
	 * @param comCD
	 * @param storeCD
	 * @param pluCD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selScanPluInfo4(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql2 = new SqlWrapper();
		List list = null;
		List list2 = null;
		int i = 0;
		String dataMsg = "";
		String dataMsg2 = "";
		String ret = "00";
		Map map = new HashMap(); 
		connect("CMGNS");
		try {
			begin();
			
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_MSTCHK2));
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());/* PLU코드 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);
				df.CommLogger(sql.debug());
				list = executeQuery(sql);
				//df.CommLogger(String.valueOf(list.size()));
				if(list.size() > 0){
					map = (Map)list.get(0);
					String ICHK = (String)map.get("ITEM_CHK");
					String SCHK = (String)map.get("SUP_CHK");
					df.CommLogger("************************ ICHK : " +ICHK);
					df.CommLogger("************************ SCHK : " +SCHK);
					if(ICHK.equals("0")){
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");
						
						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");
						
						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");
						
						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY"," ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret ="10";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						//df.CommLogger("************************ dataMsg : " +dataMsg);
						list.clear();
						return dataMsg;
					} else if(SCHK.equals("0")){  // ST_점포배송처납품일자관리에 없는
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");
						
						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");
						
						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");
						
						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY"," ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret ="09";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						//df.CommLogger("************************ dataMsg : " +dataMsg);
						list.clear();
						return dataMsg;
					}
					sql.clearParameter();
					sql.close();
					i = 0;
					list.clear();
				}
				sql.clearParameter();
				sql.close();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_AMT_DVY2));
//				df.CommLogger("▶ storeCD : "+ STORE_FIRST_CODE + pSTORE_CD);
//				df.CommLogger("▶ pCOM_CD : "+ pCOM_CD);
//				df.CommLogger("▶ PLU_CD : "+ (String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
//				df.CommLogger("▶ INPUT_DT : "+ (String)hm.get("INPUT_DT").toString().trim() );
//				df.CommLogger("▶ SQL : " + sql.get().toString() );
//				df.CommLogger("SQL2: " + sql.debug());
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// PLU_CD
				/// 회사
				///
				//이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();								/* 달력 */
				cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);											/* 전일계산 */
				String ys = SDF.format(cDate.getTime());								/* 발주전일 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, pCOM_CD);									  /* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD);									  /* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				  /* 조직코드 */
				sql.setString(++i, pCOM_CD);									  /* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				
				sql.setString(++i, ys);											/* 전일발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				/* 조직코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
				sql.setString(++i, pCOM_CD); 								  	/* 회사코드 */
				 
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				/* 조직코드 */
				sql.setString(++i, pCOM_CD); 								  	/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				
				// 추가된 부분(7줄) I.G
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				   /* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() ); /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() ); /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				   /* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() ); /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() ); /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() ); /* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				/* 조직코드 */
				
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* 이너박스바코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* 소박스 바코드 */
				sql.setString(++i, pCOM_CD);									/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				
				df.CommLogger("▶ SQL : " + sql.debug() );
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
//				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 )
				{
					hm.put("INQ_TYPE", " ");
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("NSTCK_QTY", " ");
					hm.put("SORD_QTY", " ");
					hm.put("SALE_QTY", " ");
					
					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", " ");
					hm.put("ORD_LOW", " ");
					hm.put("ORD_MAX", " ");
					
					hm.put("STR_SAL_PRC", " ");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", " ");
					
					hm.put("AMT", " ");
					hm.put("DEL_YN", " ");
					hm.put("YS_QTY"," ");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");
					// SUP_PLAN_DT
					
					// 추가된 부분(6줄) I.G
					hm.put("PROFIT_RT", " ");
					hm.put("ORD_SUG_NM", " ");
					hm.put("EVT_NM", " ");
					hm.put("EVT_NEXT_NM", " ");
					hm.put("RTN_TP", " ");
					hm.put("S_CATE_NM", " ");
					
					ret = "09";
				// else 부터 추가	
				} else {
					i = 0;
					sql2.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_RECORD));
					
					sql2.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
					sql2.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
					sql2.setString(++i, pCOM_CD);									   /* 회사코드 */
					sql2.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, pCOM_CD);									   /* 회사코드 */
					sql2.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); /* 발주일자 */					
					sql2.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */					
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				   /* 조직코드 */
					sql2.setString(++i, pCOM_CD);									   /* 회사코드 */
					sql2.setString(++i, (String)hm.get("PLU_CD").toString().trim() );  /* PLU코드 */
					sql2.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				   /* 조직코드 */
					sql2.setString(++i, pCOM_CD);									   /* 회사코드 */
					sql2.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				   /* 조직코드 */
					sql2.setString(++i, pCOM_CD);									   /* 회사코드 */
					sql2.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				   /* 조직코드 */
					sql2.setString(++i, pCOM_CD);									   /* 회사코드 */
					
					df.CommLogger("▶ SQL : " + sql2.debug() );		
					
					list2 = executeQuery(sql2);
					
					int total_cnt2 = list2.size();
					hm.put("ROWS_COUNT2", Integer.toString(total_cnt2));
				}
				//sql.clearParameter();
				sql.close();
				sql2.close();
			} 
			else 
			{
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			if( list.size() > 0 ){
				dataMsg2 = ret + makeScanPluInfo4(hm, list, df);
				if( list2.size() > 0 ){
					dataMsg = dataMsg2 + makeScanPluInfo5(hm, list2, df);
					//df.CommLogger("★ make: " + dataMsg2);
				} else {
					dataMsg = dataMsg2;
				}
			}
		}
		
		return dataMsg;
	}	
	
	/***************************************************************************
	 * selScanPluInfo5
	 * : 점포발주-스캔방식 상품정보 요청 [전일발주수량 ] - 이익율,행사,반품구분 등 추가 I.G - 발주 스캔 시 메시지처리 추가I.G 20151207
	 * IQ_SCAN_ORDER_REQ 
	 * @param comCD
	 * @param storeCD
	 * @param pluCD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selScanPluInfo5(String pCOM_CD, String pSTORE_CD, HashMap hm,	COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql2 = new SqlWrapper();
		List list = null;
		List list2 = null;
		int i = 0;
		String dataMsg = "";
		String dataMsg2 = "";
		String ret = "00";
		Map map = new HashMap();
		connect("CMGNS");
		try {
			begin();

			if (getCloseOrderTime(pCOM_CD, pSTORE_CD,(String) hm.get("INPUT_DT").toString().trim(), df) == true)
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_MSTCHK3));
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD); /* 회사코드 */
				sql.setString(++i, (String) hm.get("PLU_CD").toString().trim()); /* PLU코드 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD); /* 점포코드 */
				// df.CommLogger(sql.debug());
				list = executeQuery(sql);
				// df.CommLogger(String.valueOf(list.size()));
				if (list.size() > 0) {
					map = (Map) list.get(0);
					String ICHK = (String) map.get("ITEM_CHK");
					String SCHK = (String) map.get("SUP_CHK");
					String OCHK = (String) map.get("ORD_CHK");
					String OYN = (String) map.get("ORD_YN");
					// df.CommLogger("************************ ICHK : " +ICHK); /* 상품마스터 체크 */
					// df.CommLogger("************************ SCHK : " +SCHK); /* 발주가능 일자 체크 */
					// df.CommLogger("************************ OCHK : " +OCHK); /* 발주가능 시간 체크 */
					// df.CommLogger("************************ OYN : " +OYN);   /* 발주불가 상품 체크 */

					if (OCHK.equals("N")) {
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "11";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						list.clear();
						return dataMsg;
					} else if (ICHK.equals("0")) {
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "10";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						// df.CommLogger("************************ dataMsg : " +dataMsg);
						list.clear();
						return dataMsg;
					} else if (OYN.equals("N")) {
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "12";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						// df.CommLogger("************************ dataMsg : " +dataMsg);
						list.clear();
						return dataMsg;
					} else if (SCHK.equals("0")) { // ST_점포배송처납품일자관리에 없는
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "09";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						// df.CommLogger("************************ dataMsg : " +dataMsg);
						list.clear();
						return dataMsg;
					}
					sql.clearParameter();
					sql.close();
					i = 0;
					list.clear();
				}
				sql.clearParameter();
				sql.close();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_AMT_DVY2));
				// df.CommLogger("▶ storeCD : "+ STORE_FIRST_CODE + pSTORE_CD);
				// df.CommLogger("▶ pCOM_CD : "+ pCOM_CD);
				// df.CommLogger("▶ PLU_CD : "+(String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
				// df.CommLogger("▶ INPUT_DT : "+(String)hm.get("INPUT_DT").toString().trim() );
				// df.CommLogger("▶ SQL : " + sql.get().toString() );
				// df.CommLogger("SQL2: " + sql.debug());
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// PLU_CD
				/// 회사
				///
				// 이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");                 /* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();                                 /* 달력 */
				cDate.setTime(SDF.parse((String) hm.get("INPUT_DT").toString().trim())); /* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);                                            /* 전일계산 */
				String ys = SDF.format(cDate.getTime());                                 /* 발주전일 */

				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                             /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                             /* 회사코드 */
				
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                        /* 조직코드 */
				sql.setString(++i, pCOM_CD);                                             /* 회사코드 */
				
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
				
				sql.setString(++i, ys);                                                  /* 전일발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                        /* 조직코드 */
				sql.setString(++i, (String) hm.get("PLU_CD").toString().trim());         /* PLU코드 */
				sql.setString(++i, pCOM_CD);                                             /* 회사코드 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                        /* 조직코드 */
				sql.setString(++i, pCOM_CD);                                             /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */

				// 추가된 부분(7줄) I.G
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                        /* 조직코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                        /* 조직코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                        /* 조직코드 */

				sql.setString(++i, (String) hm.get("PLU_CD").toString().trim());         /* PLU코드 */
				sql.setString(++i, (String) hm.get("PLU_CD").toString().trim());         /* 이너박스바코드 */
				sql.setString(++i, (String) hm.get("PLU_CD").toString().trim());         /* 소박스 바코드 */
				sql.setString(++i, pCOM_CD);                                             /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */

				df.CommLogger("▶ SQL : " + sql.debug());

				list = executeQuery(sql);

				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));

				// df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));

				if (list.size() <= 0) {
					hm.put("INQ_TYPE", " ");
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("NSTCK_QTY", " ");
					hm.put("SORD_QTY", " ");
					hm.put("SALE_QTY", " ");

					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", " ");
					hm.put("ORD_LOW", " ");
					hm.put("ORD_MAX", " ");

					hm.put("STR_SAL_PRC", " ");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", " ");

					hm.put("AMT", " ");
					hm.put("DEL_YN", " ");
					hm.put("YS_QTY", " ");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");
					// SUP_PLAN_DT

					// 추가된 부분(6줄) I.G
					hm.put("PROFIT_RT", " ");
					hm.put("ORD_SUG_NM", " ");
					hm.put("EVT_NM", " ");
					hm.put("EVT_NEXT_NM", " ");
					hm.put("RTN_TP", " ");
					hm.put("S_CATE_NM", " ");

					ret = "09";
					// else 부터 추가
				} else {
					i = 0;
					sql2.put(findQuery(COMMBiz_PDA.PDA_SQL,
							COMMBiz_PDA.SEL_PLU_INFO_RECORD));

					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
					sql2.setString(++i, pCOM_CD);                                             /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
					sql2.setString(++i, pCOM_CD);                                             /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                        /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                             /* 회사코드 */
					sql2.setString(++i, (String) hm.get("PLU_CD").toString().trim());         /* PLU코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                        /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                             /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                        /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                             /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim());       /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                        /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                             /* 회사코드 */

					df.CommLogger("▶ SQL : " + sql2.debug());

					list2 = executeQuery(sql2);

					int total_cnt2 = list2.size();
					hm.put("ROWS_COUNT2", Integer.toString(total_cnt2));
				}
				// sql.clearParameter();
				sql.close();
				sql2.close();
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		} catch (SQLException e) {
			rollback();
			df.CommLogger("▶ SQLException  Rollback=====>" + e.getErrorCode());
			df.CommLogger("▶ SQLException  Message=====>" + e.getMessage());
			// Return 20 DB ERROR(20 DB ERROR 리턴)
			ret = "10";
		} catch (Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		} finally {
			end();
			if (list.size() > 0) {
				dataMsg2 = ret + makeScanPluInfo4(hm, list, df);
				if (list2.size() > 0) {
					dataMsg = dataMsg2 + makeScanPluInfo5(hm, list2, df);
					// df.CommLogger("★ make: " + dataMsg2);
				} else {
					dataMsg = dataMsg2;
				}
			}
		}

		return dataMsg;
	}
	
	/***************************************************************************
	 * selScanPluInfo6
	 * : 점포발주-스캔방식 상품정보 요청 [전일발주수량 ] - 이익율,행사,반품구분 등 추가 I.G - 발주 스캔 시 메시지처리 추가I.G 20151207
	 *  - PLU코드(바코드) 13자리 체크로직 추가I.G 20151223
	 * IQ_SCAN_ORDER_REQ
	 * @param comCD
	 * @param storeCD
	 * @param pluCD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selScanPluInfo6(String pCOM_CD, String pSTORE_CD, HashMap hm,	COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		SqlWrapper sql2 = new SqlWrapper();
		List list = null;
		List list1 = null;
		List list2 = null;
		int i = 0;
		int j = 0;
		String dataMsg = "";
		String dataMsg2 = "";
		String ret = "00";
		Map map = new HashMap();
		Map map1 = new HashMap();
		connect("CMGNS");
		try {
			begin();
			String pINPUT_DT = (String) hm.get("INPUT_DT").toString().trim();
			String pPLU_CD   = (String) hm.get("PLU_CD").toString().trim();
			
			if (getCloseOrderTimeOld(pCOM_CD, pSTORE_CD, pINPUT_DT, pPLU_CD, df) == true)
			{
				String pLU_CD = (String) hm.get("PLU_CD").toString().trim();
				
				if (pLU_CD.length() < 13) {
					sql1.put(findQuery(COMMBiz_PDA.PDA_SQL,	COMMBiz_PDA.SEL_PLU_INFO_CHK));
					sql1.setString(++j, pLU_CD);                         /* PLU코드 */
					sql1.setString(++j, pLU_CD);                         /* PLU코드 */
					sql1.setString(++j, pCOM_CD);                        /* 회사코드 */
					sql1.setString(++j, STORE_FIRST_CODE + pSTORE_CD);   /* 점포코드 */
					sql1.setString(++j, pLU_CD);                         /* PLU코드 */
					df.CommLogger(sql1.debug());

					list1 = executeQuery(sql1);
					map1 = (Map) list1.get(0);
					pLU_CD = (String) map1.get("PLU_CD_N");

					sql1.clearParameter();
					sql1.close();
				}

				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_MSTCHK3));
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());         /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                               /* 회사코드 */
				sql.setString(++i, pLU_CD);                                                /* PLU코드(수정) */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                          /* 점포코드 */
				df.CommLogger(sql.debug());
				list = executeQuery(sql);
				// df.CommLogger(String.valueOf(list.size()));
				
				if (list.size() > 0) {
					map = (Map) list.get(0);
					String ICHK = (String) map.get("ITEM_CHK");
					String SCHK = (String) map.get("SUP_CHK");
					String OCHK = (String) map.get("ORD_CHK");
					String OYN = (String) map.get("ORD_YN");

					if (OCHK.equals("N")) {
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "11";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						list.clear();
						return dataMsg;
					} else if (ICHK.equals("0")) {
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "10";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						// df.CommLogger("************************ dataMsg : " +dataMsg);
						list.clear();
						return dataMsg;
					} else if (OYN.equals("N")) {
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "12";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						// df.CommLogger("************************ dataMsg : " +dataMsg);
						list.clear();
						return dataMsg;
					} else if (SCHK.equals("0")) { // ST_점포배송처납품일자관리에 없는
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "09";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						// df.CommLogger("************************ dataMsg : " +dataMsg);
						list.clear();
						return dataMsg;
					}
					sql.clearParameter();
					sql.close();
					i = 0;
					list.clear();
				}
				sql.clearParameter();
				sql.close();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_AMT_DVY2));

				///
				// 이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd"); /* 날짜포멧 */
				Calendar cDate = Calendar.getInstance(); /* 달력 */
				cDate.setTime(SDF.parse((String) hm.get("INPUT_DT").toString().trim())); /* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1); /* 전일계산 */
				String ys = SDF.format(cDate.getTime());                           /* 발주전일 */

				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, ys);                                            /* 전일발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, (String) hm.get("PLU_CD").toString().trim());   /* PLU코드 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				// 추가된 부분(7줄) I.G
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */

				sql.setString(++i, (String) hm.get("PLU_CD").toString().trim());   /* PLU코드 */
				sql.setString(++i, (String) hm.get("PLU_CD").toString().trim());   /* 이너박스바코드 */
				sql.setString(++i, (String) hm.get("PLU_CD").toString().trim());   /* 소박스 바코드 */			
				
				sql.setString(++i, pCOM_CD); /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				df.CommLogger("▶ SQL : " + sql.debug());

				list = executeQuery(sql);

				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));

				// df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));

				if (list.size() <= 0) {
					hm.put("INQ_TYPE", " ");
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("NSTCK_QTY", " ");
					hm.put("SORD_QTY", " ");
					hm.put("SALE_QTY", " ");

					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", " ");
					hm.put("ORD_LOW", " ");
					hm.put("ORD_MAX", " ");

					hm.put("STR_SAL_PRC", " ");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", " ");

					hm.put("AMT", " ");
					hm.put("DEL_YN", " ");
					hm.put("YS_QTY", " ");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");
					// SUP_PLAN_DT

					// 추가된 부분(6줄) I.G
					hm.put("PROFIT_RT", " ");
					hm.put("ORD_SUG_NM", " ");
					hm.put("EVT_NM", " ");
					hm.put("EVT_NEXT_NM", " ");
					hm.put("RTN_TP", " ");
					hm.put("S_CATE_NM", " ");

					ret = "09";
					// else 부터 추가
				} else {
					i = 0;
					sql2.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_RECORD));

					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("PLU_CD").toString().trim());   /* PLU코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */

					df.CommLogger("▶ SQL : " + sql2.debug());

					list2 = executeQuery(sql2);

					int total_cnt2 = list2.size();
					hm.put("ROWS_COUNT2", Integer.toString(total_cnt2));
				}
				// sql.clearParameter();
				sql.close();
				sql2.close();
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		} catch (SQLException e) {
			rollback();
			df.CommLogger("▶ SQLException  Rollback=====>" + e.getErrorCode());
			df.CommLogger("▶ SQLException  Message=====>" + e.getMessage());
			// Return 20 DB ERROR(20 DB ERROR 리턴)
			ret = "10";
		} catch (Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		} finally {
			end();
			if (list.size() > 0) {
				dataMsg2 = ret + makeScanPluInfo4(hm, list, df);
				if (list2.size() > 0) {
					dataMsg = dataMsg2 + makeScanPluInfo5(hm, list2, df);
					// df.CommLogger("★ make: " + dataMsg2);
				} else {
					dataMsg = dataMsg2;
				}
			}
		}

		return dataMsg;
	}
	
	/***************************************************************************
	 * selScanPluInfo7
	 * : 점포 발주- 긴급발주 상품정보 요청 (selScanPluInfo6 -> selScanPluInfo7 : 2줄 출력 제거2016.07.19)
	 * IQ_SCAN_ORDER_REQ
	 * @param comCD
	 * @param storeCD
	 * @param pluCD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selScanPluInfo7(String pCOM_CD, String pSTORE_CD, HashMap hm,	COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		SqlWrapper sql2 = new SqlWrapper();
		List list = null;
		List list1 = null;
		List list2 = null;
		int i = 0;
		int j = 0;
		String dataMsg = "";
		String dataMsg2 = "";
		String ret = "00";
		Map map = new HashMap();
		Map map1 = new HashMap();
		connect("CMGNS");
		try {
			begin();			
			String pINPUT_DT = (String) hm.get("INPUT_DT").toString().trim();
			String pPLU_CD   = (String) hm.get("PLU_CD").toString().trim();

			if (getCloseOrderTimeOld(pCOM_CD, pSTORE_CD, pINPUT_DT, pPLU_CD, df) == true)
			{
				String pLU_CD = (String) hm.get("PLU_CD").toString().trim();
				
				if (pLU_CD.length() < 13) {
					sql1.put(findQuery(COMMBiz_PDA.PDA_SQL,	COMMBiz_PDA.SEL_PLU_INFO_CHK));
					sql1.setString(++j, pLU_CD);                         /* PLU코드 */
					sql1.setString(++j, pLU_CD);                         /* PLU코드 */
					sql1.setString(++j, pCOM_CD);                        /* 회사코드 */
					sql1.setString(++j, STORE_FIRST_CODE + pSTORE_CD);   /* 점포코드 */
					sql1.setString(++j, pLU_CD);                         /* PLU코드 */
					df.CommLogger(sql1.debug());

					list1 = executeQuery(sql1);
					map1 = (Map) list1.get(0);
					pLU_CD = (String) map1.get("PLU_CD_N");
					df.CommLogger("************************ PLU_CD : " + pLU_CD);

					sql1.clearParameter();
					sql1.close();
				}

				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_MSTCHK3));				
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());         /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                               /* 회사코드 */
				sql.setString(++i, pLU_CD);                                                /* PLU코드(수정) */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                          /* 점포코드 */
				df.CommLogger(sql.debug());
				list = executeQuery(sql);
				// df.CommLogger(String.valueOf(list.size()));
				
				if (list.size() > 0) {
					map = (Map) list.get(0);
					String ICHK = (String) map.get("ITEM_CHK");
					String SCHK = (String) map.get("SUP_CHK");
					String OCHK = (String) map.get("ORD_CHK");
					String OYN = (String) map.get("ORD_YN");

					df.CommLogger("************************ ICHK : " +ICHK);               /* 상품마스터 체크 */
					df.CommLogger("************************ SCHK : " +SCHK);               /* 발주가능 일자 체크 */
					df.CommLogger("************************ OCHK : " +OCHK);               /* 발주가능 시간 체크 */
					df.CommLogger("************************ OYN : " +OYN);                 /* 발주불가 상품 체크 */

					if (OCHK.equals("N")) {
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "11";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						list.clear();
						return dataMsg;
					} else if (ICHK.equals("0")) {
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "10";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						// df.CommLogger("************************ dataMsg : " +dataMsg);
						list.clear();
						return dataMsg;
					} else if (OYN.equals("N")) {
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "12";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						// df.CommLogger("************************ dataMsg : " +dataMsg);
						list.clear();
						return dataMsg;
					} else if (SCHK.equals("0")) { // ST_점포배송처납품일자관리에 없는
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret = "09";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						// df.CommLogger("************************ dataMsg : " +dataMsg);
						list.clear();
						return dataMsg;
					}
					sql.clearParameter();
					sql.close();
					i = 0;
					list.clear();
				}
				sql.clearParameter();
				sql.close();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_AMT_DVY3));
				// df.CommLogger("▶ storeCD : "+ STORE_FIRST_CODE + pSTORE_CD);
				// df.CommLogger("▶ pCOM_CD : "+ pCOM_CD);
				// df.CommLogger("▶ PLU_CD : "+(String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
				// df.CommLogger("▶ INPUT_DT : "+(String)hm.get("INPUT_DT").toString().trim() );
				// df.CommLogger("▶ SQL : " + sql.get().toString() );
				// df.CommLogger("SQL2: " + sql.debug());
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// PLU_CD
				/// 회사
				///
				// 이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd"); /* 날짜포멧 */
				Calendar cDate = Calendar.getInstance(); /* 달력 */
				cDate.setTime(SDF.parse((String) hm.get("INPUT_DT").toString().trim())); /* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1); /* 전일계산 */
				String ys = SDF.format(cDate.getTime());                           /* 발주전일 */
				
				sql.setString(++i, pLU_CD);                                        /* PLU코드               I.G 수정 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, ys);                                            /* 전일발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, pLU_CD);                                        /* PLU코드               I.G 수정 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				// 추가된 부분(7줄) I.G
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */

				sql.setString(++i, pLU_CD);                                        /* PLU코드               I.G 수정 */
				sql.setString(++i, pLU_CD);                                        /* 이너박스바코드     I.G 수정 */
				sql.setString(++i, pLU_CD);                                        /* 소박스 바코드       I.G 수정 */				
				
				sql.setString(++i, pCOM_CD); /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				df.CommLogger("▶ SQL : " + sql.debug());

				list = executeQuery(sql);

				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));

				// df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));

				if (list.size() <= 0) {
					hm.put("INQ_TYPE", " ");
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("NSTCK_QTY", " ");
					hm.put("SORD_QTY", " ");
					hm.put("SALE_QTY", " ");

					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", " ");
					hm.put("ORD_LOW", " ");
					hm.put("ORD_MAX", " ");

					hm.put("STR_SAL_PRC", " ");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", " ");

					hm.put("AMT", " ");
					hm.put("DEL_YN", " ");
					hm.put("YS_QTY", " ");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");
					// SUP_PLAN_DT

					// 추가된 부분(6줄) I.G
					hm.put("PROFIT_RT", " ");
					hm.put("ORD_SUG_NM", " ");
					hm.put("EVT_NM", " ");
					hm.put("EVT_NEXT_NM", " ");
					hm.put("RTN_TP", " ");
					hm.put("S_CATE_NM", " ");

					ret = "09";
					// else 부터 추가
				} else {
					i = 0;
					sql2.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_RECORD));

					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, pLU_CD);                                        /* PLU코드               I.G 수정 */					
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */

					df.CommLogger("▶ SQL : " + sql2.debug());

					list2 = executeQuery(sql2);

					int total_cnt2 = list2.size();
					hm.put("ROWS_COUNT2", Integer.toString(total_cnt2));
				}
				// sql.clearParameter();
				sql.close();
				sql2.close();
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		} catch (SQLException e) {
			rollback();
			df.CommLogger("▶ SQLException  Rollback=====>" + e.getErrorCode());
			df.CommLogger("▶ SQLException  Message=====>" + e.getMessage());
			// Return 20 DB ERROR(20 DB ERROR 리턴)
			ret = "10";
		} catch (Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		} finally {
			end();
			if (list.size() > 0) {
				dataMsg2 = ret + makeScanPluInfo4(hm, list, df);
				if (list2.size() > 0) {
					dataMsg = dataMsg2 + makeScanPluInfo5(hm, list2, df);
					// df.CommLogger("★ make: " + dataMsg2);
				} else {
					dataMsg = dataMsg2;
				}
			}
		}

		return dataMsg;
	}
	
	/***************************************************************************
	 * selScanPluInfo8
	 * : [점포 발주] 스캔(조회)
	 *   FF발주 선마감 반영 2016.10.21 I.G
	 * IQ_SCAN_ORDER_REQ
	 * @param comCD
	 * @param storeCD
	 * @param pluCD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selScanPluInfo8(String pCOM_CD, String pSTORE_CD, HashMap hm,	COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		SqlWrapper sql2 = new SqlWrapper();
		List list = null;
		List list1 = null;
		List list2 = null;
		int i = 0;
		int j = 0;
		String dataMsg = "";
		String dataMsg2 = "";
		String ret = "00";
		Map map = new HashMap();
		Map map1 = new HashMap();
		connect("CMGNS");
		try {
			begin();
			
			String PLU_CD = (String) hm.get("PLU_CD").toString().trim();
			
			if (PLU_CD.length() < 13) {
				sql1.put(findQuery(COMMBiz_PDA.PDA_SQL,	COMMBiz_PDA.SEL_PLU_INFO_CHK));
				sql1.setString(++j, PLU_CD);                         /* PLU코드 */
				sql1.setString(++j, PLU_CD);                         /* PLU코드 */
				sql1.setString(++j, pCOM_CD);                        /* 회사코드 */
				sql1.setString(++j, STORE_FIRST_CODE + pSTORE_CD);   /* 점포코드 */
				sql1.setString(++j, PLU_CD);                         /* PLU코드 */
				//df.CommLogger(sql1.debug());

				list1 = executeQuery(sql1);
				map1 = (Map) list1.get(0);
				PLU_CD = (String) map1.get("PLU_CD_N");
				df.CommLogger("************************ PLU_CD : " + PLU_CD);

				sql1.clearParameter();
				sql1.close();
			}
			String INPUT_DT = (String)hm.get("INPUT_DT").toString().trim();
			String RET_VAL  = getCloseOrderTime2(pCOM_CD,pSTORE_CD,PLU_CD,INPUT_DT, df);
			
			if(RET_VAL.equals("00"))
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_MSTCHK4));				
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());         /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                               /* 회사코드 */
				sql.setString(++i, PLU_CD);                                                /* PLU코드 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                          /* 점포코드 */
				df.CommLogger(sql.debug());
				list = executeQuery(sql);
				// df.CommLogger(String.valueOf(list.size()));
				
				if (list.size() > 0) {
					map = (Map) list.get(0);
					String ICHK = (String) map.get("ITEM_CHK");
					String SCHK = (String) map.get("SUP_CHK");					
					String OYN = (String) map.get("ORD_YN");

					df.CommLogger("************************ ICHK : " +ICHK);               /* 상품마스터 체크 */
					df.CommLogger("************************ SCHK : " +SCHK);               /* 발주가능 일자 체크 */					
					df.CommLogger("************************ OYN : " +OYN);                 /* 발주불가 상품 체크 */

					if(ICHK.equals("0")||OYN.equals("N")||SCHK.equals("0")) {
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						
						if (ICHK.equals("0")) {
							ret = "10";
						} else if (OYN.equals("N")) {
							ret = "12";
						} else if (SCHK.equals("0")) { // ST_점포배송처납품일자관리에 없는
							ret = "09";
						}
						
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						list.clear();
						return dataMsg;
					}	

					sql.clearParameter();
					sql.close();
					i = 0;
					list.clear();
				}
				sql.clearParameter();
				sql.close();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_AMT_DVY3));
				
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// PLU_CD
				/// 회사
				///
				// 이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd"); /* 날짜포멧 */
				Calendar cDate = Calendar.getInstance(); /* 달력 */
				cDate.setTime(SDF.parse((String) hm.get("INPUT_DT").toString().trim())); /* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1); /* 전일계산 */
				String ys = SDF.format(cDate.getTime());                           /* 발주전일 */
				
				sql.setString(++i, PLU_CD);                                        /* PLU코드               I.G 수정 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, ys);                                            /* 전일발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, PLU_CD);                                        /* PLU코드               I.G 수정 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				// 추가된 부분(7줄) I.G
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */

				sql.setString(++i, PLU_CD);                                        /* PLU코드               I.G 수정 */
				sql.setString(++i, PLU_CD);                                        /* 이너박스바코드     I.G 수정 */
				sql.setString(++i, PLU_CD);                                        /* 소박스 바코드       I.G 수정 */				
				
				sql.setString(++i, pCOM_CD); /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				df.CommLogger("▶ SQL : " + sql.debug());

				list = executeQuery(sql);

				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));

				// df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));

				if (list.size() <= 0) {
					hm.put("INQ_TYPE", " ");
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("NSTCK_QTY", " ");
					hm.put("SORD_QTY", " ");
					hm.put("SALE_QTY", " ");

					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", " ");
					hm.put("ORD_LOW", " ");
					hm.put("ORD_MAX", " ");

					hm.put("STR_SAL_PRC", " ");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", " ");

					hm.put("AMT", " ");
					hm.put("DEL_YN", " ");
					hm.put("YS_QTY", " ");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");
					// SUP_PLAN_DT

					// 추가된 부분(6줄) I.G
					hm.put("PROFIT_RT", " ");
					hm.put("ORD_SUG_NM", " ");
					hm.put("EVT_NM", " ");
					hm.put("EVT_NEXT_NM", " ");
					hm.put("RTN_TP", " ");
					hm.put("S_CATE_NM", " ");

					ret = "09";
					// else 부터 추가
				} else {
					i = 0;
					sql2.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_RECORD));

					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, PLU_CD);                                        /* PLU코드               I.G 수정 */					
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */

					df.CommLogger("▶ SQL : " + sql2.debug());

					list2 = executeQuery(sql2);

					int total_cnt2 = list2.size();
					hm.put("ROWS_COUNT2", Integer.toString(total_cnt2));
				}
				// sql.clearParameter();
				sql.close();
				sql2.close();
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				//ret = "09";
				ret = RET_VAL;
			}
		} catch (SQLException e) {
			rollback();
			df.CommLogger("▶ SQLException  Rollback=====>" + e.getErrorCode());
			df.CommLogger("▶ SQLException  Message=====>" + e.getMessage());
			// Return 20 DB ERROR(20 DB ERROR 리턴)
			ret = "10";
		} catch (Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		} finally {
			end();
			
			if(list == null) {
				dataMsg = ret + makeScanPluInfo4(hm, list, df);
			} else {
				if (list.size() > 0) {
					dataMsg2 = ret + makeScanPluInfo4(hm, list, df);
					if (list2.size() > 0) {
						dataMsg = dataMsg2 + makeScanPluInfo5(hm, list2, df);
						// df.CommLogger("★ make: " + dataMsg2);
					} else {
						dataMsg = dataMsg2;
					}
				}
			}
		}

		return dataMsg;
	}
	
	/***************************************************************************
	 * selScanPluInfo8
	 * : [점포 발주] 스캔(조회)
	 *   5대행사/발주불가 체크 추가 2016.11.21 I.G
	 * IQ_SCAN_ORDER_REQ
	 * @param comCD
	 * @param storeCD
	 * @param pluCD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selScanPluInfo9(String pCOM_CD, String pSTORE_CD, HashMap hm,	COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		SqlWrapper sql2 = new SqlWrapper();
		List list = null;
		List list1 = null;
		List list2 = null;
		int i = 0;
		int j = 0;
		String dataMsg = "";
		String dataMsg2 = "";
		String ret = "00";
		Map map = new HashMap();
		Map map1 = new HashMap();
		connect("CMGNS");
		try {
			begin();
			
			String PLU_CD = (String) hm.get("PLU_CD").toString().trim();
			
			if (PLU_CD.length() < 13) {
				sql1.put(findQuery(COMMBiz_PDA.PDA_SQL,	COMMBiz_PDA.SEL_PLU_INFO_CHK));
				sql1.setString(++j, PLU_CD);                         /* PLU코드 */
				sql1.setString(++j, PLU_CD);                         /* PLU코드 */
				sql1.setString(++j, pCOM_CD);                        /* 회사코드 */
				sql1.setString(++j, STORE_FIRST_CODE + pSTORE_CD);   /* 점포코드 */
				sql1.setString(++j, PLU_CD);                         /* PLU코드 */
				//df.CommLogger(sql1.debug());

				list1 = executeQuery(sql1);
				map1 = (Map) list1.get(0);
				PLU_CD = (String) map1.get("PLU_CD_N");
				df.CommLogger("************************ PLU_CD : " + PLU_CD);

				sql1.clearParameter();
				sql1.close();
			}
			String INPUT_DT = (String)hm.get("INPUT_DT").toString().trim();
			String RET_VAL  = getCloseOrderTime2(pCOM_CD,pSTORE_CD,PLU_CD,INPUT_DT, df);
			
			if(RET_VAL.equals("00"))
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_MSTCHK5));				
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());         /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());         /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                               /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());         /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim());         /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                               /* 회사코드 */
				sql.setString(++i, pCOM_CD);                                               /* 회사코드 */
				sql.setString(++i, PLU_CD);                                                /* PLU코드 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                          /* 점포코드 */
				df.CommLogger(sql.debug());
				list = executeQuery(sql);
				// df.CommLogger(String.valueOf(list.size()));
				
				if (list.size() > 0) {
					map = (Map) list.get(0);
					String ICHK = (String) map.get("ITEM_CHK");
					String SCHK = (String) map.get("SUP_CHK");					
					String OYN = (String) map.get("ORD_YN");
					String EYN = (String) map.get("EVT_YN");

					df.CommLogger("************************ ICHK : " +ICHK);               /* 상품마스터 체크 */
					df.CommLogger("************************ SCHK : " +SCHK);               /* 발주가능 일자 체크 */					
					df.CommLogger("************************ OYN : " +OYN);                 /* 발주불가 상품 체크 */
					df.CommLogger("************************ EYN : " +EYN);                 /* 행사상품 체크 */

					if(ICHK.equals("0")||OYN.equals("N")||SCHK.equals("0")||EYN.equals("N")) {
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");

						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");

						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");

						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY", " ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						
						if (ICHK.equals("0")) {
							ret = "10";
						} else if (OYN.equals("N")||EYN.equals("N")) {
							ret = "12";
						} else if (SCHK.equals("0")) { // ST_점포배송처납품일자관리에 없는
							ret = "09";
						}
						
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						list.clear();
						return dataMsg;
					}	

					sql.clearParameter();
					sql.close();
					i = 0;
					list.clear();
				}
				sql.clearParameter();
				sql.close();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_AMT_DVY4));
				
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// PLU_CD
				/// 회사
				///
				// 이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd"); /* 날짜포멧 */
				Calendar cDate = Calendar.getInstance(); /* 달력 */
				cDate.setTime(SDF.parse((String) hm.get("INPUT_DT").toString().trim())); /* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1); /* 전일계산 */
				String ys = SDF.format(cDate.getTime());                           /* 발주전일 */
				
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				
				sql.setString(++i, PLU_CD);                                        /* PLU코드               I.G 수정 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, ys);                                            /* 전일발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, PLU_CD);                                        /* PLU코드               I.G 수정 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, pCOM_CD);                                       /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				// 추가된 부분(7줄) I.G
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */

				sql.setString(++i, PLU_CD);                                        /* PLU코드               I.G 수정 */
				sql.setString(++i, PLU_CD);                                        /* 이너박스바코드     I.G 수정 */
				sql.setString(++i, PLU_CD);                                        /* 소박스 바코드       I.G 수정 */				
				
				sql.setString(++i, pCOM_CD); /* 회사코드 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */

				df.CommLogger("▶ SQL : " + sql.debug());

				list = executeQuery(sql);

				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));

				// df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));

				if (list.size() <= 0) {
					hm.put("INQ_TYPE", " ");
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("NSTCK_QTY", " ");
					hm.put("SORD_QTY", " ");
					hm.put("SALE_QTY", " ");

					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", " ");
					hm.put("ORD_LOW", " ");
					hm.put("ORD_MAX", " ");

					hm.put("STR_SAL_PRC", " ");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", " ");

					hm.put("AMT", " ");
					hm.put("DEL_YN", " ");
					hm.put("YS_QTY", " ");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");
					// SUP_PLAN_DT

					// 추가된 부분(6줄) I.G
					hm.put("PROFIT_RT", " ");
					hm.put("ORD_SUG_NM", " ");
					hm.put("EVT_NM", " ");
					hm.put("EVT_NEXT_NM", " ");
					hm.put("RTN_TP", " ");
					hm.put("S_CATE_NM", " ");

					ret = "09";
					// else 부터 추가
				} else {
					i = 0;
					sql2.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_RECORD));

					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, PLU_CD);                                        /* PLU코드               I.G 수정 */					
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, (String) hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
					sql2.setString(++i, STORE_FIRST_CODE + pSTORE_CD);                  /* 조직코드 */
					sql2.setString(++i, pCOM_CD);                                       /* 회사코드 */

					df.CommLogger("▶ SQL : " + sql2.debug());

					list2 = executeQuery(sql2);

					int total_cnt2 = list2.size();
					hm.put("ROWS_COUNT2", Integer.toString(total_cnt2));
				}
				// sql.clearParameter();
				sql.close();
				sql2.close();
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				//ret = "09";
				ret = RET_VAL;
			}
		} catch (SQLException e) {
			rollback();
			df.CommLogger("▶ SQLException  Rollback=====>" + e.getErrorCode());
			df.CommLogger("▶ SQLException  Message=====>" + e.getMessage());
			// Return 20 DB ERROR(20 DB ERROR 리턴)
			ret = "10";
		} catch (Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		} finally {
			end();
			
			if(list == null) {
				dataMsg = ret + makeScanPluInfo4(hm, list, df);
			} else {
				if (list.size() > 0) {
					dataMsg2 = ret + makeScanPluInfo4(hm, list, df);
					if (list2.size() > 0) {
						dataMsg = dataMsg2 + makeScanPluInfo5(hm, list2, df);
						// df.CommLogger("★ make: " + dataMsg2);
					} else {
						dataMsg = dataMsg2;
					}
				}
			}
		}

		return dataMsg;
	}
	
	/***************************************************************************
	 * selScanPluInfo
	 * : 점포발주-스캔방식 상품정보 요청 [ 전일발주수량 ]
	 * IQ_SCAN_ORDER_REQ
	 * @param comCD
	 * @param storeCD
	 * @param pluCD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selScanPluInfo2(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		//Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		Map map = new HashMap(); 
		connect("CMGNS");
		try {
			begin();
			
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS_MSTCHK));
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());/* PLU코드 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);
				//df.CommLogger(sql.debug());
				list = executeQuery(sql);
				//df.CommLogger(String.valueOf(list.size()));
				if(list.size() > 0){
					map = (Map)list.get(0);
					String ICHK = (String)map.get("ITEM_CHK");
					//df.CommLogger(ICHK);
					if(ICHK.equals("0")){
						hm.put("INQ_TYPE", " ");
						hm.put("PLU_CD", " ");
						hm.put("PLU_NM", " ");
						hm.put("NSTCK_QTY", " ");
						hm.put("SORD_QTY", " ");
						hm.put("SALE_QTY", " ");
						
						hm.put("ITEM_CD", " ");
						hm.put("STAND_CD", " ");
						hm.put("ORD_ENBL_TP", " ");
						hm.put("ORD_ACQ_QTY", " ");
						hm.put("ORD_LOW", " ");
						hm.put("ORD_MAX", " ");
						
						hm.put("STR_SAL_PRC", " ");
						hm.put("GDS_COST", " ");
						hm.put("INNER_BOX_BARCD", " ");
						hm.put("INNER_BOX_ACQ_QTY", " ");
						
						hm.put("AMT", " ");
						hm.put("DEL_YN", " ");
						hm.put("YS_QTY"," ");
						hm.put("ROWS_COUNT", Integer.toString(0));
						ret ="10";
						sql.clearParameter();
						sql.close();
						end();
						dataMsg = ret + makeScanPluInfo2(hm, list, df);
						
						return dataMsg;
					}
					sql.clearParameter();
					sql.close();
					i = 0;
					list.clear();
				}
				sql.clearParameter();
				sql.close();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_PLU_INFO_YS));
//				df.CommLogger("▶ storeCD : "+ STORE_FIRST_CODE + pSTORE_CD);
//				df.CommLogger("▶ pCOM_CD : "+ pCOM_CD);
//				df.CommLogger("▶ PLU_CD : "+ (String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
//				df.CommLogger("▶ INPUT_DT : "+ (String)hm.get("INPUT_DT").toString().trim() );
//				df.CommLogger("▶ SQL : " + sql.get().toString() );
//				df.CommLogger("SQL2: " + sql.debug());
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// PLU_CD
				/// 회사
				///
				//이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();								/* 달력 */
				cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);											/* 전일계산 */
				String ys = SDF.format(cDate.getTime());								/* 발주전일 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, pCOM_CD);									  /* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); /* 발주일자 */
				sql.setString(++i, pCOM_CD);									  /* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				  /* 조직코드 */
				sql.setString(++i, pCOM_CD);									  /* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				
				sql.setString(++i, ys);											/* 전일발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				/* 조직코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
				sql.setString(++i, pCOM_CD); 								  	/* 회사코드 */
				 
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				/* 조직코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* PLU코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* 이너박스바코드 */
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );/* 소박스 바코드 */
				sql.setString(++i, pCOM_CD);									/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );/* 발주일자 */
				
				//df.CommLogger("▶ SQL : " + sql.debug() );
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
//				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 )
				{
					hm.put("INQ_TYPE", " ");
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("NSTCK_QTY", " ");
					hm.put("SORD_QTY", " ");
					hm.put("SALE_QTY", " ");
					
					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", " ");
					hm.put("ORD_LOW", " ");
					hm.put("ORD_MAX", " ");
					
					hm.put("STR_SAL_PRC", " ");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", " ");
					
					hm.put("AMT", " ");
					hm.put("DEL_YN", " ");
					hm.put("YS_QTY"," ");
					// SUP_PLAN_DT
					ret = "09";
				}
			} 
			else 
			{
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeScanPluInfo2(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}

	/***************************************************************************
	 * makeScanPluInfo : Make Scan Plu Info (데이타부 전송데이타를 만듬).
	 * IQ_SCAN_ORDER_RSP, 발주가능금액, 제외배송처 여부 추가
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeScanPluInfo3(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2, 
                20,
                50,
                10,
                10,
                10,
                30,
                30,
                4,
                2,
                10,
                10,
                10,
                10,
                10,
                20,
                10,
                10,
                2,
                10,
                20,
                15,
                3
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// 
				"PLU_CD",   			//
				"PLU_NM",   			//
				"NSTCK_QTY",   			//
				"SORD_QTY",   			//
				"SALE_QTY",   			//
				
				"ITEM_CD",   			//
				"STAND_CD",   			//
				"PLU_TP",   			//
				"ORD_ENBL_TP",   		//
				"ORD_ACQ_QTY",   		//
				"ORD_LOW",   			//
				"ORD_MAX",   			//
				
				
				"STR_SAL_PRC",   		//
				"GDS_COST",   			//
				"INNER_BOX_BARCD",   	//
				"INNER_BOX_ACQ_QTY",   	//
				
				"AMT",   				//
				"DEL_YN", 				//
				"YS_QTY",
				"NDVY_CD",
				"AVB_LOAN_AMT",
				"CHECK_TP"
				
		};

		try {
			// ROWS_COUNT Length is 10.
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			//StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						//df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						//StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						
						// 2014.04.11  납품예정일자  추가 요청으로 발주하한에 상한값을 더하고 상한값에 납품예정일자를 넣는다.
						if(hdr_StrHeaders[nCol].toString()=="ORD_LOW")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("ORD_LOW")+"/"+(String)map.get("ORD_MAX"), hdr_lens[nCol]);
						} else if(hdr_StrHeaders[nCol].toString()=="ORD_MAX")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("SUP_PLAN_DT"), hdr_lens[nCol]);
						} else {
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						}
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeScanPluInfo : " + e.getMessage());
			throw e;
		}
		

		return sb.toString();
	}
	
	/***************************************************************************
	 * makeScanPluInfo : Make Scan Plu Info (데이타부 전송데이타를 만듬).
	 * IQ_SCAN_ORDER_RSP, 이익율,행사,반품구분 등 추가 I.G
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeScanPluInfo4(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2, 
                20,
                50,
                10,
                10,
                10,
                30,
                30,
                4,
                2,
                10,
                10,
                10,
                10,
                10,
                20,
                10,
                10,
                2,
                10,
                20,
                15,
                
                4, // 추가(6줄) I.G
                50,
                50,
                50,
                20,
                50,
                
                3                
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// 
				"PLU_CD",   			//
				"PLU_NM",   			//
				"NSTCK_QTY",   			//
				"SORD_QTY",   			//
				"SALE_QTY",   			//
				
				"ITEM_CD",   			//
				"STAND_CD",   			//
				"PLU_TP",   			//
				"ORD_ENBL_TP",   		//
				"ORD_ACQ_QTY",   		//
				"ORD_LOW",   			//
				"ORD_MAX",   			//
				
				
				"STR_SAL_PRC",   		//
				"GDS_COST",   			//
				"INNER_BOX_BARCD",   	//
				"INNER_BOX_ACQ_QTY",   	//
				
				"AMT",   				//
				"DEL_YN", 				//
				"YS_QTY",
				"NDVY_CD",
				"AVB_LOAN_AMT",
				
				"PROFIT_RT", // 추가(6줄) I.G
				"ORD_SUG_NM",
				"EVT_NM",
				"EVT_NEXT_NM",
				"RTN_TP",
				"S_CATE_NM",
				
				"CHECK_TP"				
		};

		try {
			// ROWS_COUNT Length is 10.
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			//StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						//df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						//StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						
						// 2014.04.11  납품예정일자  추가 요청으로 발주하한에 상한값을 더하고 상한값에 납품예정일자를 넣는다.
						if(hdr_StrHeaders[nCol].toString()=="ORD_LOW")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("ORD_LOW")+"/"+(String)map.get("ORD_MAX"), hdr_lens[nCol]);
						} else if(hdr_StrHeaders[nCol].toString()=="ORD_MAX")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("SUP_PLAN_DT"), hdr_lens[nCol]);
						} else {
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						}
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeScanPluInfo4 : " + e.getMessage());
			throw e;
		}
		

		return sb.toString();
	}
	
	/***************************************************************************
	 * makeScanPluInfo5 : Make Scan Plu Info (데이타부 전송데이타를 만듬).
	 * IQ_SCAN_ORDER_RSP, 매입,판매,폐기 I.G
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeScanPluInfo5(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();		
		int hdr_lens[] = { 2, 10, 10, 10, 10, 10, 10 };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",
				"DT_1",		// D-3
				"DT_2",	    // D-2
				"DT_3",	    // D-1
				"DT_4",	    // D
				"DT_5",	    // D+1
				"DT_6"	    // D+2
		};

		try {
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT2").toString().trim());
			//df.CommLogger("ROWS_COUNT2 :" + nRowCount);
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					//StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						//df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeScanPluInfo5 : " + e.getMessage());
			throw e;
		}
		
		return sb.toString();
	}
	
	/***************************************************************************
	 * makeScanPluInfo : Make Scan Plu Info (데이타부 전송데이타를 만듬).
	 * IQ_SCAN_ORDER_RSP
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeScanPluInfo2(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2, 
                20,
                50,
                10,
                10,
                10,
                30,
                30,
                4,
                2,
                10,
                10,
                10,
                10,
                10,
                20,
                10,
                10,
                2,
                10
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// 
				"PLU_CD",   			//
				"PLU_NM",   			//
				"NSTCK_QTY",   			//
				"SORD_QTY",   			//
				"SALE_QTY",   			//
				
				"ITEM_CD",   			//
				"STAND_CD",   			//
				"PLU_TP",   			//
				"ORD_ENBL_TP",   		//
				"ORD_ACQ_QTY",   		//
				"ORD_LOW",   			//
				"ORD_MAX",   			//
				
				
				"STR_SAL_PRC",   		//
				"GDS_COST",   			//
				"INNER_BOX_BARCD",   	//
				"INNER_BOX_ACQ_QTY",   	//
				
				"AMT",   				//
				"DEL_YN", 				//
				"YS_QTY"
		};

		try {
			// ROWS_COUNT Length is 10.
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			//StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						//df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						//StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						
						// 2014.04.11  납품예정일자  추가 요청으로 발주하한에 상한값을 더하고 상한값에 납품예정일자를 넣는다.
						if(hdr_StrHeaders[nCol].toString()=="ORD_LOW")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("ORD_LOW")+"/"+(String)map.get("ORD_MAX"), hdr_lens[nCol]);
						} else if(hdr_StrHeaders[nCol].toString()=="ORD_MAX")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("SUP_PLAN_DT"), hdr_lens[nCol]);
						} else {
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						}
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeScanPluInfo : " + e.getMessage());
			throw e;
		}
		

		return sb.toString();
	}
	/***************************************************************************
	 * makeScanPluInfo : Make Scan Plu Info (데이타부 전송데이타를 만듬).
	 * IQ_SCAN_ORDER_RSP
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeScanPluInfo(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2, 
                20,
                50,
                10,
                10,
                10,
                30,
                30,
                4,
                2,
                10,
                10,
                10,
                10,
                10,
                20,
                10,
                10,
                2
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "73": Search Stand Plu Info(진열대 상품 조회)
				"PLU_CD",   			//
				"PLU_NM",   			//
				"NSTCK_QTY",   			//
				"SORD_QTY",   			//
				"SALE_QTY",   			//
				
				"ITEM_CD",   			//
				"STAND_CD",   			//
				"PLU_TP",   			//
				"ORD_ENBL_TP",   		//
				"ORD_ACQ_QTY",   		//
				"ORD_LOW",   			//
				"ORD_MAX",   			//
				
				
				"STR_SAL_PRC",   		//
				"GDS_COST",   			//
				"INNER_BOX_BARCD",   	//
				"INNER_BOX_ACQ_QTY",   	//
				
				"AMT",   				//
				"DEL_YN", 				//
		};

		try {
			// ROWS_COUNT Length is 10.
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			//StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						//df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						//StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						
						// 2014.04.11  납품예정일자  추가 요청으로 발주하한에 상한값을 더하고 상한값에 납품예정일자를 넣는다.
						if(hdr_StrHeaders[nCol].toString()=="ORD_LOW")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("ORD_LOW")+"/"+(String)map.get("ORD_MAX"), hdr_lens[nCol]);
						} else if(hdr_StrHeaders[nCol].toString()=="ORD_MAX")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("SUP_PLAN_DT"), hdr_lens[nCol]);
						} else {
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						}
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeScanPluInfo : " + e.getMessage());
			throw e;
		}
		

		return sb.toString();
	}
	
	/***************************************************************************
	 * setOldScanPluUpdate
	 * : 점포발주-스캔방식 상품정보 수정 요청
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setOldScanPluUpdate(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		int nAMT = 0;
		int i = 0;
		connect("CMGNS");
		try {
			begin();
			
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT0").toString().trim(),df) ) {
				
				String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
				String INPUT_DT = ""; // 발주일자
				
				int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
				// 발주 처리
				//
				for(idx = 0;idx < total_cnt;idx++ ) {
					sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.TB_PRODUCT_UPDATE2)); // 수정 I.G
					///
					/// INPUT Params
					///
					/// COM_CD
					/// BIZLOC_ORG_CD
					/// ITEM_CD
					/// ORD_TP = 202  // 발주구분<B144> VARCHAR2(1) (201:진열대발주, 202:스캔발주) 
					/// ORD_QTY
					/// ORD_QTY
					/// ORD_QTY
					/// 등록자ID
					/// 수정자ID
					/// ITEM_CD
					/// COM_CD
					/// BIZLOC_ORG_CD
					///
	
					int SORD_QTY = Integer.parseInt((String)hm.get("SORD_QTY" + Integer.toString(idx)).toString().trim());
					int INPUT_COUNT = Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
					int GDS_COST = Integer.parseInt((String)hm.get("GDS_COST" + Integer.toString(idx)).toString().trim());
					int nCount = INPUT_COUNT - SORD_QTY;
					String ITEM_CD = (String)hm.get("ITEM_CD" + Integer.toString(idx)).toString().trim();
					INPUT_DT = (String)hm.get("INPUT_DT" + Integer.toString(idx)).toString().trim();
					
	//				df.CommLogger("▶ SORD_QTY : " + Integer.toString(SORD_QTY) );
	//				df.CommLogger("▶ INPUT_COUNT : " + Integer.toString(INPUT_COUNT) );
	//				df.CommLogger("▶ GDS_COST: " + Integer.toString(GDS_COST) );
	//				df.CommLogger("▶ ORG_CD: " + ORG_CD );
	//				df.CommLogger("▶ ITEM_CD: " + ITEM_CD );
	//				df.CommLogger("▶ pCOM_CD: " + pCOM_CD );
	//				df.CommLogger("▶ INPUT_DT: " + INPUT_DT );
					i=0;
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, "202");		
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, INPUT_DT); // 수정 I.G
					sql.setString( ++i, INPUT_DT); // 수정 I.G
					
					//nAMT += nCount * GDS_COST;
					
	//				df.CommLogger("▶ SQL 1: " + sql.debug() );
					int rows = executeUpdate(sql);
					
					if (rows > 0)
					{
						nAMT += nCount * GDS_COST;
					}
					sql.close();
					
					
				}
				i = 0;
	//			df.CommLogger("▶ AMT : " + nAMT );
				
				// 발주 후 여신 처리
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.CALL_PR_HQ_STRLOAN_INFO));
				/// 
				/// 회사코드
				/// 점포코드
				/// [발주수량] * [공급가]
				/// [사용자]
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				//sql.setString( ++i, INPUT_DT);
				sql.setInt(++i, nAMT );
				sql.setString( ++i, ORG_CD); 
				
	//			df.CommLogger("▶ SQL 2: " + sql.debug() );
				int nResult00 = executeUpdate(sql);
				sql.close();
				
				i = 0;
				// 발주 후 점포 칼렌더 발주 여부 업데이트 
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.UPD_ST_STRCALENDAR_MGR));
				///
				///
				/// 수정자ID
				/// 회사코드
				/// 점포코드
				///
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, INPUT_DT);
				
	//			df.CommLogger("▶ SQL 3: " + sql.debug() );
				int nResult01 = executeUpdate(sql);
				sql.close();
			}else {
				ret = "09";
			}

		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeScanPluUpdateSendData(hm,idx);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selScanPluInfo
	 * : 점포발주-스캔방식 상품정보 수정 요청
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setScanPluUpdate(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		int nAMT = 0;
		int i = 0;
		connect("CMGNS");
		try {
			begin();
			
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT0").toString().trim(),df) ) {
			
				String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
				String INPUT_DT = ""; // 발주일자
				
				int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
				// 발주 처리
				//
				for(idx = 0;idx < total_cnt;idx++ ) {
					sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.TB_PRODUCT_UPDATE2)); // 수정 I.G
					///
					/// INPUT Params
					///
					/// COM_CD
					/// BIZLOC_ORG_CD
					/// ITEM_CD
					/// ORD_TP = 202  // 발주구분<B144> VARCHAR2(1) (201:진열대발주, 202:스캔발주) 
					/// ORD_QTY
					/// ORD_QTY
					/// ORD_QTY
					/// 등록자ID
					/// 수정자ID
					/// ITEM_CD
					/// COM_CD
					/// BIZLOC_ORG_CD
					///
	
					int SORD_QTY = Integer.parseInt((String)hm.get("SORD_QTY" + Integer.toString(idx)).toString().trim());
					int INPUT_COUNT = Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
					int GDS_COST = Integer.parseInt((String)hm.get("GDS_COST" + Integer.toString(idx)).toString().trim());
					int nCount = INPUT_COUNT - SORD_QTY;
					String ITEM_CD = (String)hm.get("ITEM_CD" + Integer.toString(idx)).toString().trim();
					INPUT_DT = (String)hm.get("INPUT_DT" + Integer.toString(idx)).toString().trim();
					
	//				df.CommLogger("▶ SORD_QTY : " + Integer.toString(SORD_QTY) );
	//				df.CommLogger("▶ INPUT_COUNT : " + Integer.toString(INPUT_COUNT) );
	//				df.CommLogger("▶ GDS_COST: " + Integer.toString(GDS_COST) );
	//				df.CommLogger("▶ ORG_CD: " + ORG_CD );
	//				df.CommLogger("▶ ITEM_CD: " + ITEM_CD );
	//				df.CommLogger("▶ pCOM_CD: " + pCOM_CD );
	//				df.CommLogger("▶ INPUT_DT: " + INPUT_DT );
					i=0;
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					if( hm.get("INQ_TYPE") == "27") {
						sql.setString( ++i, "202");		// 스캔발주
					}else {
						sql.setString( ++i, "203");		// 긴급발주
					}
//					sql.setString( ++i, "202");		
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, INPUT_DT); // 수정 I.G
					sql.setString( ++i, INPUT_DT); // 수정 I.G
					
	//				nAMT += nCount * GDS_COST;
					
					df.CommLogger("▶ SQL 1: " + sql.debug() );
					int rows = executeUpdate(sql);
					
					if (rows > 0)
					{
						nAMT += Integer.parseInt((String)hm.get("ADD_TO_LOANAMT" + Integer.toString(idx)).toString().trim());
					}
					sql.close();
					
					
				}
				i = 0;
	//			df.CommLogger("▶ AMT : " + nAMT );
				
				// 발주 후 여신 처리
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.CALL_PR_HQ_STRLOAN_INFO));
				/// 
				/// 회사코드
				/// 점포코드
				/// [발주수량] * [공급가]
				/// [사용자]
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				//sql.setString( ++i, INPUT_DT);
				sql.setInt(++i, nAMT ); // FF발주 선마감으로 변경(저장된 데이터만 계산)
				//sql.setInt(++i, Integer.parseInt((String)hm.get("TOT_ADD_AMT")));
				sql.setString( ++i, ORG_CD); 
				
	//			df.CommLogger("▶ SQL 2: " + sql.debug() );
				int nResult00 = executeUpdate(sql);
				sql.close();
				
				i = 0;
				// 발주 후 점포 칼렌더 발주 여부 업데이트 
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.UPD_ST_STRCALENDAR_MGR));
				///
				///
				/// 수정자ID
				/// 회사코드
				/// 점포코드
				///
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, INPUT_DT);
				
	//			df.CommLogger("▶ SQL 3: " + sql.debug() );
				int nResult01 = executeUpdate(sql);
				sql.close();
			}else {
				ret = "09";
			}

		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeScanPluUpdateSendData(hm,idx);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selScanPluInfo
	 * : [점포 발주] 스캔(저장) - FF발주 선마감 반영 2016.10.21 I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setScanPluUpdate2(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		int nAMT = 0;
		int i = 0;
		connect("CMGNS");
		try {
			begin();
			
			String INPUT_DT0 = (String)hm.get("INPUT_DT0").toString().trim();			
			String PLU_CD0   = (String)hm.get("PLU_CD0").toString().trim();		
			int INPUT_COUNT0 = Integer.parseInt((String)hm.get("INPUT_COUNT0").toString().trim());
			String RET_VAL   = getCloseOrderTime4(pCOM_CD,pSTORE_CD,PLU_CD0,INPUT_DT0,INPUT_COUNT0,df);
			//df.CommLogger("*************************************RET_VAL : " + RET_VAL);
			if(RET_VAL.equals("00")) {
				
				String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
				String INPUT_DT = ""; // 발주일자
				
				int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
				// 발주 처리
				//
				for(idx = 0;idx < total_cnt;idx++ ) {
					sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.TB_PRODUCT_UPDATE2));
					
					int SORD_QTY = Integer.parseInt((String)hm.get("SORD_QTY" + Integer.toString(idx)).toString().trim());
					int INPUT_COUNT = Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
					int GDS_COST = Integer.parseInt((String)hm.get("GDS_COST" + Integer.toString(idx)).toString().trim());
					int nCount = INPUT_COUNT - SORD_QTY;
					String ITEM_CD = (String)hm.get("ITEM_CD" + Integer.toString(idx)).toString().trim();
					INPUT_DT = (String)hm.get("INPUT_DT" + Integer.toString(idx)).toString().trim();
					
	//				df.CommLogger("▶ SORD_QTY : " + Integer.toString(SORD_QTY) );
	//				df.CommLogger("▶ INPUT_COUNT : " + Integer.toString(INPUT_COUNT) );
	//				df.CommLogger("▶ GDS_COST: " + Integer.toString(GDS_COST) );
	//				df.CommLogger("▶ ORG_CD: " + ORG_CD );
	//				df.CommLogger("▶ ITEM_CD: " + ITEM_CD );
	//				df.CommLogger("▶ pCOM_CD: " + pCOM_CD );
	//				df.CommLogger("▶ INPUT_DT: " + INPUT_DT );
					i=0;
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					if( hm.get("INQ_TYPE") == "27") {
						sql.setString( ++i, "202");		// 스캔발주
					}else {
						sql.setString( ++i, "203");		// 긴급발주
					}
//					sql.setString( ++i, "202");		
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, INPUT_DT);
					
	//				nAMT += nCount * GDS_COST;
					
					df.CommLogger("▶ SQL 1: " + sql.debug() );
					int rows = executeUpdate(sql);
					df.CommLogger("▶ ***************************************** rows : " + rows );
					if (rows > 0)
					{
						nAMT += Integer.parseInt((String)hm.get("ADD_TO_LOANAMT" + Integer.toString(idx)).toString().trim());
					}
					sql.close();
					
					
				}
				i = 0;
				df.CommLogger("▶ *********************************************** AMT : " + nAMT );
				
				// 발주 후 여신 처리
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.CALL_PR_HQ_STRLOAN_INFO));
				/// 
				/// 회사코드
				/// 점포코드
				/// [발주수량] * [공급가]
				/// [사용자]
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				//sql.setString( ++i, INPUT_DT);
				sql.setInt(++i, nAMT ); // FF발주 선마감으로 변경(저장된 데이터만 계산)
				//sql.setInt(++i, Integer.parseInt((String)hm.get("TOT_ADD_AMT")));
				sql.setString( ++i, ORG_CD); 
				
	//			df.CommLogger("▶ SQL 2: " + sql.debug() );
				int nResult00 = executeUpdate(sql);
				sql.close();
				
				i = 0;
				// 발주 후 점포 칼렌더 발주 여부 업데이트 
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.UPD_ST_STRCALENDAR_MGR));
				///
				///
				/// 수정자ID
				/// 회사코드
				/// 점포코드
				///
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, INPUT_DT);
				
	//			df.CommLogger("▶ SQL 3: " + sql.debug() );
				int nResult01 = executeUpdate(sql);
				sql.close();
			}else {
				//ret = "09";
				ret = RET_VAL;
			}

		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeScanPluUpdateSendData(hm,idx);
			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * setScanPluUpdate3
	 * : [점포 발주] 스캔(저장) - 신발주 적용 I.G 180309
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setScanPluUpdate3(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		String dataMsg = "";
		String ret = "00";
		String ret1 = "00";
		String ret2 = "00";
		int idx = 0;
		int nAMT = 0;
		int i = 0;
		
		PDACommIFServiceDAO2 dao1 = new PDACommIFServiceDAO2();
		PDACommIFBackDAO2 dao2 = new PDACommIFBackDAO2();

		try {
			begin();
			String INPUT_DT0 = (String)hm.get("INPUT_DT0").toString().trim();			
			String PLU_CD0   = (String)hm.get("PLU_CD0").toString().trim();			
			int INPUT_COUNT0 = Integer.parseInt((String)hm.get("INPUT_COUNT0").toString().trim());			
			String RET_VAL   = getCloseOrderTime4(pCOM_CD,pSTORE_CD,PLU_CD0,INPUT_DT0,INPUT_COUNT0,df);
			
			if(RET_VAL.equals("00")) {
				
				String NEW_ORDER_YN = getNewOrderStore(pCOM_CD, pSTORE_CD, df);
		
				if(NEW_ORDER_YN.equals("N")){
					ret1 = dao1.setScanPluUpdateOld(pCOM_CD, pSTORE_CD, hm, df);
					df.CommLogger( "===========================> ret1 :::::"+ret1);
				} else {
					ret1 = dao1.setScanPluUpdateOld(pCOM_CD, pSTORE_CD, hm, df);
					df.CommLogger( "===========================> ret1 :::::"+ret1);
					
					if(ret1.equals("00")) {
						ret2 = dao2.setScanPluUpdateNew(pCOM_CD, pSTORE_CD, hm, df);
						df.CommLogger( "===========================> ret2 :::::"+ret2);
					}
				}			
			
			}else {
				//ret = "09";
				ret = RET_VAL;
		 	}

		}catch(SQLException e) {
			dao1.rollback();
			dao2.rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			dao1.rollback();
			dao2.rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			if (!ret1.equals("00")){
				dao1.rollback();				
				ret = ret1;
				df.CommLogger( "===========================> Rollback1");
			} else if (!ret2.equals("00")) {
				dao1.rollback();
				dao2.rollback();
				ret = ret2;
				df.CommLogger( "===========================> Rollback2");
			} else {
				df.CommLogger( "===========================> Commit");
			}
			
			end();
			dao1.end();
			dao2.end();
			//dataMsg = ret + makeScanPluUpdateSendData(hm,idx);
			dataMsg = ret + makeScanPluUpdateSendData(hm,1);
			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeScanPluUpdateSendData : 
	 * : 점포발주-스캔방식 상품정보 수정 응답
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeScanPluUpdateSendData(HashMap hm, int idx) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 30, 10, 10 };
		String strHeaders[] = {
				"INQ_TYPE",   	// "30": Search Product(상품 조회)
				"SLIP_NO",		// Product Barcode(상품코드)
				"ROW_COUNT",	// 자료처리건수
				"RESULT_CD "	// 결과코드
		};

		StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE" + Integer.toString(0)), nlens[0]);
		StringUtil.appendSpace(sb, "", nlens[1]);
		StringUtil.appendSpace(sb, Integer.toString(idx), nlens[2]);
		if( idx > 0 ) {
			StringUtil.appendSpace(sb, "00", nlens[3]);
		}else {
			StringUtil.appendSpace(sb, "09", nlens[3]);
		}
				
		return sb.toString();
	}
	
	/***************************************************************************
	 * selScanPluInfo
	 * : 점포발주-진열대 진열대 정보 요청
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selStandInfo(String pCOM_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_STAND_LIST));
			sql.setString(++i, pCOM_CD.trim());
//			df.CommLogger("▶ pCOM_CD : " + pCOM_CD.trim());
			
			list = executeQuery(sql);
			//df.CommLogger("▶ SQL : " + sql.get().toString());
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) {
				hm.put("STAND_CD", " ");
				hm.put("STAND_NM", " ");
				hm.put("MOD_DT", " ");
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandInfo(hm, list, df);
			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selScanPluInfo
	 * : 점포발주-분류별 : 대분류 정보 요청
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selStandInfo2(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{  
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try { 
			begin();
//			df.CommLogger("▶ pCOM_CD : " + pCOM_CD.trim());
//			df.CommLogger("▶ pSTORE_CD : " + pSTORE_CD.trim());
//			df.CommLogger("▶ INPUT_DT : "+ (String)hm.get("INPUT_DT").toString().trim() );
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_STAND_LIST2));
			sql.setString(++i, pCOM_CD.trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());
			
			list = executeQuery(sql);
			//df.CommLogger("▶ SQL : " + sql.get().toString());
			df.CommLogger("▶ SQL : " + sql.debug() );
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) {
				hm.put("STAND_CD", " ");
				hm.put("STAND_NM", " ");
				hm.put("MOD_DT", " ");
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandInfo(hm, list, df);
			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeStandInfo : 점포발주-진열대 진열대 정보 응답
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeStandInfo(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10, 30, 50, 20 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "72": Search Stand Info(진열대 조회)
				"ROW_SEQ",			// ROW Number
				"STAND_CD",				// 진열대 코드
				"STAND_NM",				// 진열대 이름
				"MOD_DT"				// 최종수정일자
		};
		
		try
		{
			// ROWS_COUNT Length is 10.
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), hdr_lens[1]);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					StringUtil.appendSpace(sb, Integer.toString(i), hdr_lens[1]);
					StringUtil.appendSpace(sb, (String)map.get("STAND_CD"), hdr_lens[2]);
					StringUtil.appendSpace(sb, (String)map.get("STAND_NM"), hdr_lens[3]);
					StringUtil.appendSpace(sb, (String)map.get("MOD_DTM"), hdr_lens[4]);
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				StringUtil.appendSpace(sb, Integer.toString(0), hdr_lens[1]);
				StringUtil.appendSpace(sb, "", hdr_lens[2]);
				StringUtil.appendSpace(sb, "", hdr_lens[3]);
				StringUtil.appendSpace(sb, "", hdr_lens[4]);
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeStandInfo Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	/***************************************************************************
	 * selStandPluInfo : IQ_STAND_ORDER_REQ
	 * : 점포발주-진열대 진열대 상품 정보 요청
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selStandPluInfo(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			// 발주 일자 체크
			
			
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_STAND_PRODUCT));
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// STAND_CD
				/// 회사
				///
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());
				sql.setString(++i, pCOM_CD.trim());
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());
				sql.setString(++i, pCOM_CD.trim());
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());
				sql.setString(++i, pCOM_CD.trim());
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());
				sql.setString(++i, (String)hm.get("STAND_CD").toString().trim());
				sql.setString(++i, pCOM_CD.trim());
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); 
				
				//df.CommLogger("EXE: " + sql.debug());
	//			df.CommLogger("▶ SQL:"+sql.get().toString());
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ STAND_CD:"+(String)hm.get("STAND_CD").toString().trim());
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
//				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 ) 
				{
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("PLU_TP", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", "0");
					hm.put("ORD_LOW", "0");
					hm.put("ORD_MAX", "0");
					hm.put("NSTCK_QTY", "0");
					hm.put("SALE_QTY", "0");
					hm.put("STR_SAL_PRC", "0");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", "0");
					hm.put("SORD_QTY", "0");
					hm.put("AMT", "0");
					
					ret = "09";
				}
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluInfo(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeStandPluInfo : 점포발주-진열대 진열대 상품 정보 응답
	 * IQ_STAND_ORDER_RSP
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeStandPluInfo(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2, 
                20,
                50,
                10,
                10,
                10,
                30,
                30,
                4,
                2,
                10,
                10,
                10,
                10,
                10,
                20,
                10,
                10 
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "73": Search Stand Plu Info(진열대 상품 조회)
				"PLU_CD",   			//
				"PLU_NM",   			//
				"NSTCK_QTY",   			//
				"SORD_QTY",   			//
				"SALE_QTY",   			//
				
				"ITEM_CD",   			//
				"STAND_CD",   			//
				"PLU_TP",   			//
				"ORD_ENBL_TP",   		//
				"ORD_ACQ_QTY",   		//
				"ORD_LOW",   			//
				"ORD_MAX",   			//
				
				
				"STR_SAL_PRC",   		//
				"GDS_COST",   			//
				"INNER_BOX_BARCD",   	//
				"INNER_BOX_ACQ_QTY",   	//
				
				"AMT"   				//
		};
		
		try
		{
			// ROWS_COUNT Length is 10.
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						//df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						//StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						
						// 2014.04.11  납품예정일자  추가 요청으로 발주하한에 상한값을 더하고 상한값에 납품예정일자를 넣는다.
						if(hdr_StrHeaders[nCol].toString()=="ORD_LOW")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("ORD_LOW")+"/"+(String)map.get("ORD_MAX"), hdr_lens[nCol]);
						} else if(hdr_StrHeaders[nCol].toString()=="ORD_MAX")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("SUP_PLAN_DT"), hdr_lens[nCol]);
						} else {
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						}
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeStandPluInfo Error : " + e);
			throw e;
		}
 
		return sb.toString();
	}
	
	/***************************************************************************
	 * selStandPluInfo : IQ_STAND_ORDER_REQ
	 * : 점포발주-진열대 진열대 상품 정보 요청 - 상품대제외 배송처, 발주가능금액 요청 추가
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selStandPluInfo3(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			// 발주 일자 체크
			
			
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_STAND_PLU_INFO_YS2));
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// STAND_CD
				/// 회사
				///
				
				//이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();								/* 달력 */
				cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);											/* 전일계산 */
				String ys = SDF.format(cDate.getTime());								/* 발주전일 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());//67									/* 회사코드 */
				
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, ys);													/* 발주전일 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, (String)hm.get("STAND_CD").toString().trim());		/* 진열대코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); 		/* 발주일자 */
				
	//			df.CommLogger("EXE: " + sql.debug());
	//			df.CommLogger("▶ SQL:"+sql.get().toString());
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ STAND_CD:"+(String)hm.get("STAND_CD").toString().trim());
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 ) 
				{
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("PLU_TP", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", "0");
					hm.put("ORD_LOW", "0");
					hm.put("ORD_MAX", "0");
					hm.put("NSTCK_QTY", "0");
					hm.put("SALE_QTY", "0");
					hm.put("STR_SAL_PRC", "0");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", "0");
					hm.put("SORD_QTY", "0");
					hm.put("AMT", "0");
					hm.put("YS_QTY", "0");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");
					ret = "09";
				}
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluInfo3(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selStandPluInfo : IQ_STAND_ORDER_REQ
	 * : 점포발주-진열대 진열대 상품 정보 요청 - 이익율,행사,반품구분 등 추가 I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selStandPluInfo4(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			//df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
			//df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
			//df.CommLogger("▶ STAND_CD:"+(String)hm.get("STAND_CD").toString().trim());
			
			// 발주 일자 체크
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_STAND_PLU_INFO_YS5));
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// STAND_CD
				/// 회사
				///				
				//이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();								/* 달력 */
				cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);											/* 전일계산 */
				String ys = SDF.format(cDate.getTime());								/* 발주전일 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());//67									/* 회사코드 */
				
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, ys);													/* 발주전일 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				
				// 추가된 부분(7 + 21줄) I.G
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, (String)hm.get("STAND_CD").toString().trim());		/* 진열대코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); 		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); 		/* 발주일자 */
				
				df.CommLogger("EXE: " + sql.debug());
	//			df.CommLogger("▶ SQL:"+sql.get().toString());
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ STAND_CD:"+(String)hm.get("STAND_CD").toString().trim());
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
				//df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 ) 
				{
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("PLU_TP", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", "0");
					hm.put("ORD_LOW", "0");
					hm.put("ORD_MAX", "0");
					hm.put("NSTCK_QTY", "0");
					hm.put("SALE_QTY", "0");
					hm.put("STR_SAL_PRC", "0");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", "0");
					hm.put("SORD_QTY", "0");
					hm.put("AMT", "0");
					hm.put("YS_QTY", "0");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");
					// 추가된 부분(6 + 18줄) I.G
					hm.put("PROFIT_RT", " ");
					hm.put("ORD_SUG_NM", " ");
					hm.put("EVT_NM", " ");
					hm.put("EVT_NEXT_NM", " ");
					hm.put("RTN_TP", " ");
					hm.put("S_CATE_NM", " ");
					
					hm.put("PDG_QTY1", " ");
					hm.put("PDG_QTY2", " ");
					hm.put("PDG_QTY3", " ");
					hm.put("PDG_QTY4", " ");
					hm.put("PDG_QTY5", " ");
					hm.put("PDG_QTY6", " ");
					hm.put("SDG_QTY1", " ");
					hm.put("SDG_QTY2", " ");
					hm.put("SDG_QTY3", " ");
					hm.put("SDG_QTY4", " ");
					hm.put("SDG_QTY5", " ");
					hm.put("SDG_QTY6", " ");
					hm.put("DIS_QTY1", " ");
					hm.put("DIS_QTY2", " ");
					hm.put("DIS_QTY3", " ");
					hm.put("DIS_QTY4", " ");
					hm.put("DIS_QTY5", " ");
					hm.put("DIS_QTY6", " ");
					ret = "09";
				}
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluInfo4(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selStandPluInfo : IQ_STAND_ORDER_REQ
	 * : 점포발주-신상품 상품 정보 요청 - I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selStandPluInfo5(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			// 발주 일자 체크
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_STAND_PLU_INFO_YS6)); // 수정 I.G
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// STAND_CD
				/// 회사
				///
				
				//이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();								/* 달력 */
				cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);											/* 전일계산 */
				String ys = SDF.format(cDate.getTime());								/* 발주전일 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());//67									/* 회사코드 */
				
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, ys);													/* 발주전일 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */				
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); 		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); 		/* 발주일자 */
				
				df.CommLogger("EXE: " + sql.debug());
	//			df.CommLogger("▶ SQL:"+sql.get().toString());
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ STAND_CD:"+(String)hm.get("STAND_CD").toString().trim());
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 ) 
				{
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("PLU_TP", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", "0");
					hm.put("ORD_LOW", "0");
					hm.put("ORD_MAX", "0");
					hm.put("NSTCK_QTY", "0");
					hm.put("SALE_QTY", "0");
					hm.put("STR_SAL_PRC", "0");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", "0");
					hm.put("SORD_QTY", "0");
					hm.put("AMT", "0");
					hm.put("YS_QTY", "0");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");

					hm.put("PROFIT_RT", " ");
					hm.put("ORD_SUG_NM", " ");
					hm.put("EVT_NM", " ");
					hm.put("EVT_NEXT_NM", " ");
					hm.put("RTN_TP", " ");
					hm.put("S_CATE_NM", " ");
					
					hm.put("PDG_QTY1", " ");
					hm.put("PDG_QTY2", " ");
					hm.put("PDG_QTY3", " ");
					hm.put("PDG_QTY4", " ");
					hm.put("PDG_QTY5", " ");
					hm.put("PDG_QTY6", " ");
					hm.put("SDG_QTY1", " ");
					hm.put("SDG_QTY2", " ");
					hm.put("SDG_QTY3", " ");
					hm.put("SDG_QTY4", " ");
					hm.put("SDG_QTY5", " ");
					hm.put("SDG_QTY6", " ");
					hm.put("DIS_QTY1", " ");
					hm.put("DIS_QTY2", " ");
					hm.put("DIS_QTY3", " ");
					hm.put("DIS_QTY4", " ");
					hm.put("DIS_QTY5", " ");
					hm.put("DIS_QTY6", " ");
					ret = "09";
				}
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluInfo4(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selStandPluInfo6 : IQ_STAND_ORDER_REQ
	 * : [점포 발주] 분류별(조회)
	 *   FF발주 선마감 반영 2016.10.21 I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selStandPluInfo6(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			//df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
			//df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
			//df.CommLogger("▶ STAND_CD:"+(String)hm.get("STAND_CD").toString().trim());
			
			// 발주 일자 체크
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_STAND_PLU_INFO_YS5));
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// STAND_CD
				/// 회사
				///				
				//이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();								/* 달력 */
				cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);											/* 전일계산 */
				String ys = SDF.format(cDate.getTime());								/* 발주전일 */
				
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());//67									/* 회사코드 */
				
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, ys);													/* 발주전일 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				
				// 추가된 부분(7 + 21줄) I.G
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, (String)hm.get("STAND_CD").toString().trim());		/* 진열대코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); 		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				
				df.CommLogger("EXE: " + sql.debug());
	//			df.CommLogger("▶ SQL:"+sql.get().toString());
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ STAND_CD:"+(String)hm.get("STAND_CD").toString().trim());
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
				//df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 ) 
				{
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("PLU_TP", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", "0");
					hm.put("ORD_LOW", "0");
					hm.put("ORD_MAX", "0");
					hm.put("NSTCK_QTY", "0");
					hm.put("SALE_QTY", "0");
					hm.put("STR_SAL_PRC", "0");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", "0");
					hm.put("SORD_QTY", "0");
					hm.put("AMT", "0");
					hm.put("YS_QTY", "0");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");
					// 추가된 부분(6 + 18줄) I.G
					hm.put("PROFIT_RT", " ");
					hm.put("ORD_SUG_NM", " ");
					hm.put("EVT_NM", " ");
					hm.put("EVT_NEXT_NM", " ");
					hm.put("RTN_TP", " ");
					hm.put("S_CATE_NM", " ");
					
					hm.put("PDG_QTY1", " ");
					hm.put("PDG_QTY2", " ");
					hm.put("PDG_QTY3", " ");
					hm.put("PDG_QTY4", " ");
					hm.put("PDG_QTY5", " ");
					hm.put("PDG_QTY6", " ");
					hm.put("SDG_QTY1", " ");
					hm.put("SDG_QTY2", " ");
					hm.put("SDG_QTY3", " ");
					hm.put("SDG_QTY4", " ");
					hm.put("SDG_QTY5", " ");
					hm.put("SDG_QTY6", " ");
					hm.put("DIS_QTY1", " ");
					hm.put("DIS_QTY2", " ");
					hm.put("DIS_QTY3", " ");
					hm.put("DIS_QTY4", " ");
					hm.put("DIS_QTY5", " ");
					hm.put("DIS_QTY6", " ");
					ret = "09";
				}
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluInfo4(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selStandPluInfo : IQ_STAND_ORDER_REQ
	 * : [점포 발주] 신상품(조회)
	 *   FF발주 선마감 반영 2016.10.21 I.G
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selStandPluInfo7(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			// 발주 일자 체크
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_STAND_PLU_INFO_YS6));
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// STAND_CD
				/// 회사
				///
				
				//이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();								/* 달력 */
				cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);											/* 전일계산 */
				String ys = SDF.format(cDate.getTime());								/* 발주전일 */
				
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());//67									/* 회사코드 */
				
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, ys);													/* 발주전일 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim() );      /* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD);				        /* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */				
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); 		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); 		/* 발주일자 */
				
				df.CommLogger("EXE: " + sql.debug());
	//			df.CommLogger("▶ SQL:"+sql.get().toString());
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ STAND_CD:"+(String)hm.get("STAND_CD").toString().trim());
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 ) 
				{
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("PLU_TP", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", "0");
					hm.put("ORD_LOW", "0");
					hm.put("ORD_MAX", "0");
					hm.put("NSTCK_QTY", "0");
					hm.put("SALE_QTY", "0");
					hm.put("STR_SAL_PRC", "0");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", "0");
					hm.put("SORD_QTY", "0");
					hm.put("AMT", "0");
					hm.put("YS_QTY", "0");
					hm.put("NDVY_CD", " ");
					hm.put("AVB_LOAN_AMT", " ");

					hm.put("PROFIT_RT", " ");
					hm.put("ORD_SUG_NM", " ");
					hm.put("EVT_NM", " ");
					hm.put("EVT_NEXT_NM", " ");
					hm.put("RTN_TP", " ");
					hm.put("S_CATE_NM", " ");
					
					hm.put("PDG_QTY1", " ");
					hm.put("PDG_QTY2", " ");
					hm.put("PDG_QTY3", " ");
					hm.put("PDG_QTY4", " ");
					hm.put("PDG_QTY5", " ");
					hm.put("PDG_QTY6", " ");
					hm.put("SDG_QTY1", " ");
					hm.put("SDG_QTY2", " ");
					hm.put("SDG_QTY3", " ");
					hm.put("SDG_QTY4", " ");
					hm.put("SDG_QTY5", " ");
					hm.put("SDG_QTY6", " ");
					hm.put("DIS_QTY1", " ");
					hm.put("DIS_QTY2", " ");
					hm.put("DIS_QTY3", " ");
					hm.put("DIS_QTY4", " ");
					hm.put("DIS_QTY5", " ");
					hm.put("DIS_QTY6", " ");
					ret = "09";
				}
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluInfo4(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selOrderPluInfo : IQ_STAND_ORDER_REQ
	 * : 점포발주-발주 상품 정보 요청 - I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selOrderPluInfo(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();

			// 발주 일자 체크
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_ORDER_PLU_INFO));
				///
				/// 조직코드
				/// 회사
				
				//이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();								/* 달력 */
				cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);											/* 전일계산 */
				String ys = SDF.format(cDate.getTime());								/* 발주전일 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */				
				
	//			df.CommLogger("EXE: " + sql.debug());
	//			df.CommLogger("▶ SQL:"+sql.get().toString());
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ STAND_CD:"+(String)hm.get("STAND_CD").toString().trim());
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 ) 
				{
					hm.put("GDS_CD", " ");
					hm.put("GDS_NM", " ");
					hm.put("ACQ", "0");
					hm.put("SORD_QTY", "0");
					hm.put("PLU_CD", " ");					
					hm.put("COST", "0");					
					hm.put("TOT_AMT", "0");
					hm.put("AVB_LOAN_AMT", "0");
					hm.put("CHECK_TP", " ");
					hm.put("ORD_ACQ_QTY", "0");										
					hm.put("ORD_LOW", "0");
					hm.put("ORD_MAX", "0");
					hm.put("SUP_PLAN_DT", "0");
					hm.put("ITEM_CNT", "0");
					hm.put("TOT_AMT", "0");
					hm.put("NDVY_CD", " ");
					hm.put("ITEM_CD", " ");
					
					ret = "09";
				}
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeOrderPluInfo(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selOrderPluInfo : IQ_STAND_ORDER_REQ
	 * : 점포발주-발주 상품 정보 요청 - I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selOrderPluInfo2(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			// 발주 일자 체크
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_ORDER_PLU_INFO));
				///
				/// 조직코드
				/// 회사
				
				//이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();								/* 달력 */
				cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);											/* 전일계산 */
				String ys = SDF.format(cDate.getTime());								/* 발주전일 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */				
				
				df.CommLogger("EXE: " + sql.debug());
	//			df.CommLogger("▶ SQL:"+sql.get().toString());
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ STAND_CD:"+(String)hm.get("STAND_CD").toString().trim());
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 ) 
				{
					hm.put("GDS_CD", " ");
					hm.put("GDS_NM", " ");
					hm.put("ACQ", "0");
					hm.put("SORD_QTY", "0");
					hm.put("PLU_CD", " ");					
					hm.put("COST", "0");					
					hm.put("TOT_AMT", "0");
					hm.put("AVB_LOAN_AMT", "0");
					hm.put("CHECK_TP", " ");
					hm.put("ORD_ACQ_QTY", "0");										
					hm.put("ORD_LOW", "0");
					hm.put("ORD_MAX", "0");
					hm.put("SUP_PLAN_DT", "0");
					hm.put("ITEM_CNT", "0");
					hm.put("TOT_AMT", "0");
					hm.put("NDVY_CD", " ");
					hm.put("ITEM_CD", " ");
					
					ret = "09";
				}
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "15";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeOrderPluInfo(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selStandPluInfo : IQ_STAND_ORDER_REQ
	 * : 점포발주-진열대 진열대 상품 정보 요청
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selStandPluInfo2(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			// 발주 일자 체크
			
			
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT").toString().trim(),df) == true )
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_STAND_PLU_INFO_YS));
				///
				/// 조직코드
				/// 회사
				/// 조직코드
				/// STAND_CD
				/// 회사
				///
				
				//이전일 구하기!
				SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
				Calendar cDate = Calendar.getInstance();								/* 달력 */
				cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
				cDate.add(Calendar.DATE, -1);											/* 전일계산 */
				String ys = SDF.format(cDate.getTime());								/* 발주전일 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, pCOM_CD.trim());//67									/* 회사코드 */
				
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, ys);													/* 발주전일 */
				sql.setString(++i, ys);													/* 발주전일 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, (String)hm.get("STAND_CD").toString().trim());		/* 진열대코드 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 발주일자 */
				sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim()); 		/* 발주일자 */
				
	//			df.CommLogger("EXE: " + sql.debug());
	//			df.CommLogger("▶ SQL:"+sql.get().toString());
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ STAND_CD:"+(String)hm.get("STAND_CD").toString().trim());
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
//				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 ) 
				{
					hm.put("PLU_CD", " ");
					hm.put("PLU_NM", " ");
					hm.put("ITEM_CD", " ");
					hm.put("STAND_CD", " ");
					hm.put("PLU_TP", " ");
					hm.put("ORD_ENBL_TP", " ");
					hm.put("ORD_ACQ_QTY", "0");
					hm.put("ORD_LOW", "0");
					hm.put("ORD_MAX", "0");
					hm.put("NSTCK_QTY", "0");
					hm.put("SALE_QTY", "0");
					hm.put("STR_SAL_PRC", "0");
					hm.put("GDS_COST", " ");
					hm.put("INNER_BOX_BARCD", " ");
					hm.put("INNER_BOX_ACQ_QTY", "0");
					hm.put("SORD_QTY", "0");
					hm.put("AMT", "0");
					hm.put("YS_QTY", "0");
					ret = "09";
				}
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluInfo2(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	
	/***************************************************************************
	 * makeStandPluInfo : 점포발주-진열대 진열대 상품 정보 응답
	 * IQ_STAND_ORDER_RSP
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeStandPluInfo3(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2, 
                20,
                50,
                10,
                10,
                10,
                30,
                30,
                4,
                2,
                10,
                10,
                10,
                10,
                10,
                20,
                10,
                10,
                10,						//ys_qty
                20,						//배송처
                15,						//금액
                3
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "73": Search Stand Plu Info(진열대 상품 조회)
				"PLU_CD",   			//
				"PLU_NM",   			//
				"NSTCK_QTY",   			//
				"SORD_QTY",   			//
				"SALE_QTY",   			//
				
				"ITEM_CD",   			//
				"STAND_CD",   			//
				"PLU_TP",   			//
				"ORD_ENBL_TP",   		//
				"ORD_ACQ_QTY",   		//
				"ORD_LOW",   			//
				"ORD_MAX",   			//
				
				
				"STR_SAL_PRC",   		//
				"GDS_COST",   			//
				"INNER_BOX_BARCD",   	//
				"INNER_BOX_ACQ_QTY",   	//
				
				"AMT",   				//
				"YS_QTY",
				"NDVY_CD",
				"AVB_LOAN_AMT",
				"CHECK_TP"
		};
		
		try
		{
			// ROWS_COUNT Length is 10.
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						//df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						//StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						
						// 2014.04.11  납품예정일자  추가 요청으로 발주하한에 상한값을 더하고 상한값에 납품예정일자를 넣는다.
						if(hdr_StrHeaders[nCol].toString()=="ORD_LOW")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("ORD_LOW")+"/"+(String)map.get("ORD_MAX"), hdr_lens[nCol]);
						} else if(hdr_StrHeaders[nCol].toString()=="ORD_MAX")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("SUP_PLAN_DT"), hdr_lens[nCol]);
						} else {
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						}
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeStandPluInfo Error : " + e);
			throw e;
		}
 
		return sb.toString();
	}
	
	/***************************************************************************
	 * makeStandPluInfo : 점포발주-진열대 진열대 상품 정보 응답
	 * IQ_STAND_ORDER_RSP 이익율,행사,반품구분 등 추가 I.G
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeStandPluInfo4(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2, 
                20,
                50,
                10,
                10,
                10,
                30,
                30,
                4,
                2,
                10,
                10,
                10,
                10,
                10,
                20,
                10,
                10,
                10,						//ys_qty
                20,						//배송처
                15,						//금액
                3,
                
                4, // 추가(6 + 18줄) I.G
                50,
                50,
                50,
                20,
                50,
                
                5,
                5,
                5,
                5,
                5,
                5,
                5,
                5,
                5,
                5,
                5,
                5,
                5,
                5,
                5,
                5,
                5,
                5
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "73": Search Stand Plu Info(진열대 상품 조회)
				"PLU_CD",   			//
				"PLU_NM",   			//
				"NSTCK_QTY",   			//
				"SORD_QTY",   			//
				"SALE_QTY",   			//
				
				"ITEM_CD",   			//
				"STAND_CD",   			//
				"PLU_TP",   			//
				"ORD_ENBL_TP",   		//
				"ORD_ACQ_QTY",   		//
				"ORD_LOW",   			//
				"ORD_MAX",   			//			
				
				"STR_SAL_PRC",   		//
				"GDS_COST",   			//
				"INNER_BOX_BARCD",   	//
				"INNER_BOX_ACQ_QTY",   	//
				
				"AMT",   				//
				"YS_QTY",
				"NDVY_CD",
				"AVB_LOAN_AMT",
				"CHECK_TP",
				
				"PROFIT_RT",            // 추가(6 + 18줄) I.G
				"ORD_SUG_NM",
				"EVT_NM",
				"EVT_NEXT_NM",
				"RTN_TP",
				"S_CATE_NM",
				
				"PDG_QTY1",
				"PDG_QTY2",
				"PDG_QTY3",
				"PDG_QTY4",
				"PDG_QTY5",
				"PDG_QTY6",
				"SDG_QTY1",
				"SDG_QTY2",
				"SDG_QTY3",
				"SDG_QTY4",
				"SDG_QTY5",
				"SDG_QTY6",
				"DIS_QTY1",
				"DIS_QTY2",
				"DIS_QTY3",
				"DIS_QTY4",
				"DIS_QTY5",
				"DIS_QTY6"
		};
		
		try
		{
			// ROWS_COUNT Length is 10.
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						//df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						//StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						
						// 2014.04.11  납품예정일자  추가 요청으로 발주하한에 상한값을 더하고 상한값에 납품예정일자를 넣는다.
						if(hdr_StrHeaders[nCol].toString()=="ORD_LOW")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("ORD_LOW")+"/"+(String)map.get("ORD_MAX"), hdr_lens[nCol]);
						} else if(hdr_StrHeaders[nCol].toString()=="ORD_MAX")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("SUP_PLAN_DT"), hdr_lens[nCol]);
						} else {
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						}
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeStandPluInfo Error : " + e);
			throw e;
		}
 
		return sb.toString();
	}
	
	/***************************************************************************
	 * makeStandPluInfo : 점포발주-발주 상품 정보 응답
	 * IQ_STAND_ORDER_RSP
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeOrderPluInfo(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2, 
                20,
                50,
                10,
                5,
                20,             
                15,
                15,
                15,
                3,                
                5,
                10,
                10,
                10,
                5,
                15,
                20,
                30
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "37": 발주상품정보
				"GDS_CD",   			//
				"GDS_NM",   			//
				"ACQ",   			    //
				"SORD_QTY",   			//
				"PLU_CD",   			//								
				"COST",   		     	//
				"AMT",       			//
				"AVB_LOAN_AMT",			//
				"CHECK_TP",      		//
				"ORD_ACQ_QTY",   	    //
				"ORD_LOW",              //
				"ORD_MAX",              //
				"SUP_PLAN_DT",          //
				"ITEM_CNT",      		//
				"TOT_AMT",   			//
				"NDVY_CD",              //
				"ITEM_CD"               //
		};
		
		try
		{
			// ROWS_COUNT Length is 10.
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						//StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);						

//						df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						
						// 2014.04.11  납품예정일자  추가 요청으로 발주하한에 상한값을 더하고 상한값에 납품예정일자를 넣는다.
						if(hdr_StrHeaders[nCol].toString()=="ORD_LOW")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("ORD_LOW")+"/"+(String)map.get("ORD_MAX"), hdr_lens[nCol]);
						} else if(hdr_StrHeaders[nCol].toString()=="ORD_MAX")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("SUP_PLAN_DT"), hdr_lens[nCol]);
						} else {
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						}
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeStandPluInfo Error : " + e);
			throw e;
		}
 
		return sb.toString();
	}
	
	
	/***************************************************************************
	 * makeStandPluInfo : 점포발주-진열대 진열대 상품 정보 응답
	 * IQ_STAND_ORDER_RSP
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeStandPluInfo2(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2, 
                20,
                50,
                10,
                10,
                10,
                30,
                30,
                4,
                2,
                10,
                10,
                10,
                10,
                10,
                20,
                10,
                10,
                10						//ys_qty
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "73": Search Stand Plu Info(진열대 상품 조회)
				"PLU_CD",   			//
				"PLU_NM",   			//
				"NSTCK_QTY",   			//
				"SORD_QTY",   			//
				"SALE_QTY",   			//
				
				"ITEM_CD",   			//
				"STAND_CD",   			//
				"PLU_TP",   			//
				"ORD_ENBL_TP",   		//
				"ORD_ACQ_QTY",   		//
				"ORD_LOW",   			//
				"ORD_MAX",   			//
				
				
				"STR_SAL_PRC",   		//
				"GDS_COST",   			//
				"INNER_BOX_BARCD",   	//
				"INNER_BOX_ACQ_QTY",   	//
				
				"AMT",   				//
				"YS_QTY"
		};
		
		try
		{
			// ROWS_COUNT Length is 10.
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						//df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						//StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						
						// 2014.04.11  납품예정일자  추가 요청으로 발주하한에 상한값을 더하고 상한값에 납품예정일자를 넣는다.
						if(hdr_StrHeaders[nCol].toString()=="ORD_LOW")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("ORD_LOW")+"/"+(String)map.get("ORD_MAX"), hdr_lens[nCol]);
						} else if(hdr_StrHeaders[nCol].toString()=="ORD_MAX")
						{
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get("SUP_PLAN_DT"), hdr_lens[nCol]);
						} else {
//							df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
							StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
						}
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeStandPluInfo Error : " + e);
			throw e;
		}
 
		return sb.toString();
	}
	
	/***************************************************************************
	 * setOldStandPluUpdate [점포발주]
	 * : 점포발주-진열대 진열대 상품 정보 수정 요청
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setOldStandPluUpdate(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		int nAMT = 0;
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		connect("CMGNS");
		try {
			begin();
			
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT0").toString().trim(),df) ) {
				String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
				String INPUT_DT = "";
	
				int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
	//			df.CommLogger("▶ ROWS_COUNT: " + Integer.toString(total_cnt) );
				// 발주 처리
				//
				for(idx = 0;idx < total_cnt;idx++ ) {
					sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.TB_PRODUCT_UPDATE2)); // 수정 I.G
					///
					/// INPUT Params
					///
					/// COM_CD
					/// BIZLOC_ORG_CD
					/// ITEM_CD
					/// ORD_TP = 202  // 발주구분<B144> VARCHAR2(1) (201:진열대발주, 202:스캔발주) 
					/// ORD_QTY
					/// ORD_QTY
					/// ORD_QTY
					/// 등록자ID
					/// 수정자ID
					/// ITEM_CD
					/// COM_CD
					/// BIZLOC_ORG_CD
					///
					int SORD_QTY = Integer.parseInt((String)hm.get("SORD_QTY" + Integer.toString(idx)).toString().trim());
					int INPUT_COUNT = Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
					int GDS_COST = Integer.parseInt((String)hm.get("GDS_COST" + Integer.toString(idx)).toString().trim());
					int nCount = INPUT_COUNT - SORD_QTY;
					String ITEM_CD = (String)hm.get("ITEM_CD" + Integer.toString(idx)).toString().trim();
					INPUT_DT = (String)hm.get("INPUT_DT" + Integer.toString(idx)).toString().trim();
					i=0;
	//				df.CommLogger("▶ SORD_QTY : " + Integer.toString(SORD_QTY) );
	//				df.CommLogger("▶ INPUT_COUNT : " + Integer.toString(INPUT_COUNT) );
	//				df.CommLogger("▶ GDS_COST: " + Integer.toString(GDS_COST) );
	//				df.CommLogger("▶ ORG_CD: " + ORG_CD );
	//				df.CommLogger("▶ ITEM_CD: " + ITEM_CD );
	//				df.CommLogger("▶ pCOM_CD: " + pCOM_CD );
	//				df.CommLogger("▶ INPUT_DT: " + INPUT_DT );
	
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, "201");		
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, INPUT_DT); // 수정 I.G
					sql.setString( ++i, INPUT_DT); // 수정 I.G
					
					//nAMT += nCount * GDS_COST;
					
	//				df.CommLogger("▶ SQL 1: " + sql.debug() );
					int rows = executeUpdate(sql);
					
					if (rows > 0)
					{
						nAMT += nCount * GDS_COST;
					}
					sql.close();
					
					
				}
				
				i=0;
	//			df.CommLogger("▶ AMT : " + nAMT );
				// 발주 후 여신 처리
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.CALL_PR_HQ_STRLOAN_INFO));
				/// 
				/// 회사코드
				/// 점포코드
				/// [발주수량] * [공급가]
				/// [사용자]
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				//sql.setString( ++i, INPUT_DT);
				sql.setInt(++i, nAMT );
				sql.setString( ++i, ORG_CD);
				
	//			df.CommLogger("▶ SQL 2: " + sql.debug() );
				int nResult00 = executeUpdate(sql);
				sql.close();
				
				
				i=0;
				// 발주 후 점포 칼렌더 발주 여부 업데이트 
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.UPD_ST_STRCALENDAR_MGR));
				///
				///
				/// 수정자ID
				/// 회사코드
				/// 점포코드
				///
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, INPUT_DT);
				
	//			df.CommLogger("▶ SQL 3: " + sql.debug() );
				int nResult01 = executeUpdate(sql);
				sql.close();
			}else {
//				df.CommLogger("222");
				ret = "09";
			}
	
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluUpdate(hm,idx);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * setStandPluUpdate [점포발주]
	 * : 점포발주-진열대 진열대 상품 정보 수정 요청
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setStandPluUpdate(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		int nAMT = 0;
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		connect("CMGNS");
		try {
			begin();
			
			if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT0").toString().trim(),df) ) {
			
				String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
				String INPUT_DT = "";
	
				int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
	//			df.CommLogger("▶ ROWS_COUNT: " + Integer.toString(total_cnt) );
				// 발주 처리
				//
				for(idx = 0;idx < total_cnt;idx++ ) {
					sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.TB_PRODUCT_UPDATE2)); // 수정 I.G
					///
					/// INPUT Params
					///
					/// COM_CD
					/// BIZLOC_ORG_CD
					/// ITEM_CD
					/// ORD_TP = 202  // 발주구분<B144> VARCHAR2(1) (201:진열대발주, 202:스캔발주) 
					/// ORD_QTY
					/// ORD_QTY
					/// ORD_QTY
					/// 등록자ID
					/// 수정자ID
					/// ITEM_CD
					/// COM_CD
					/// BIZLOC_ORG_CD
					///
					int SORD_QTY = Integer.parseInt((String)hm.get("SORD_QTY" + Integer.toString(idx)).toString().trim());
					int INPUT_COUNT = Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
					int GDS_COST = Integer.parseInt((String)hm.get("GDS_COST" + Integer.toString(idx)).toString().trim());
					int nCount = INPUT_COUNT - SORD_QTY;
					String ITEM_CD = (String)hm.get("ITEM_CD" + Integer.toString(idx)).toString().trim();
					INPUT_DT = (String)hm.get("INPUT_DT" + Integer.toString(idx)).toString().trim();
					i=0;
	//				df.CommLogger("▶ SORD_QTY : " + Integer.toString(SORD_QTY) );
	//				df.CommLogger("▶ INPUT_COUNT : " + Integer.toString(INPUT_COUNT) );
	//				df.CommLogger("▶ GDS_COST: " + Integer.toString(GDS_COST) );
	//				df.CommLogger("▶ ORG_CD: " + ORG_CD );
	//				df.CommLogger("▶ ITEM_CD: " + ITEM_CD );
	//				df.CommLogger("▶ pCOM_CD: " + pCOM_CD );
	//				df.CommLogger("▶ INPUT_DT: " + INPUT_DT );
	
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, "201");		
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, INPUT_DT); // 수정 I.G
					sql.setString( ++i, INPUT_DT); // 수정 I.G
					
	//				nAMT += nCount * GDS_COST;
					
					df.CommLogger("▶ SQL 1: " + sql.debug() );
					int rows = executeUpdate(sql);
					
					if (rows > 0)
					{
						nAMT += Integer.parseInt((String)hm.get("ADD_TO_LOANAMT" + Integer.toString(idx)).toString().trim());
					}
					sql.close();
				}
				
				i=0;
				//df.CommLogger("▶ AMT : " + nAMT );
				// 발주 후 여신 처리
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.CALL_PR_HQ_STRLOAN_INFO));
				/// 
				/// 회사코드
				/// 점포코드
				/// [발주수량] * [공급가]
				/// [사용자]
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				//sql.setString( ++i, INPUT_DT);
				sql.setInt(++i, nAMT ); // FF발주 선마감으로 변경(저장된 데이터만 계산)
				//sql.setInt(++i, Integer.parseInt((String)hm.get("TOT_ADD_AMT")));
				sql.setString( ++i, ORG_CD);
				
				df.CommLogger("▶ SQL 2: " + sql.debug() );
				int nResult00 = executeUpdate(sql);
				sql.close();
				
				
				i=0;
				// 발주 후 점포 칼렌더 발주 여부 업데이트 
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.UPD_ST_STRCALENDAR_MGR));
				///
				///
				/// 수정자ID
				/// 회사코드
				/// 점포코드
				///
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, INPUT_DT);
				
	//			df.CommLogger("▶ SQL 3: " + sql.debug() );
				int nResult01 = executeUpdate(sql);
				sql.close();
			}else {
				ret = "09";
			}
	
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluUpdate(hm,idx);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * setStandPluUpdate2
	 * : [점포 발주] 분류별/신상품(저장)
	 *   FF발주 선마감 반영 2016.10.21 I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setStandPluUpdate2(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		int nAMT = 0;
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		connect("CMGNS");
		try {
			begin();
			
			String INPUT_DT0 = (String)hm.get("INPUT_DT0").toString().trim();
			String PLU_CD0   = (String)hm.get("PLU_CD0").toString().trim();
			String RET_VAL   = getCloseOrderTime2(pCOM_CD,pSTORE_CD,PLU_CD0,INPUT_DT0, df);
			
			//if( getCloseOrderTime(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT0").toString().trim(),df) ) {
			//df.CommLogger("*************************************RET_VAL : " + RET_VAL);
			if(RET_VAL.equals("00")) {
			
				String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
				String INPUT_DT = "";
	
				int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
	//			df.CommLogger("▶ ROWS_COUNT: " + Integer.toString(total_cnt) );
				// 발주 처리
				//
				for(idx = 0;idx < total_cnt;idx++ ) {
					sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.TB_PRODUCT_UPDATE2)); // 수정 I.G
					///
					/// INPUT Params
					///
					/// COM_CD
					/// BIZLOC_ORG_CD
					/// ITEM_CD
					/// ORD_TP = 202  // 발주구분<B144> VARCHAR2(1) (201:진열대발주, 202:스캔발주) 
					/// ORD_QTY
					/// ORD_QTY
					/// ORD_QTY
					/// 등록자ID
					/// 수정자ID
					/// ITEM_CD
					/// COM_CD
					/// BIZLOC_ORG_CD
					///
					int SORD_QTY = Integer.parseInt((String)hm.get("SORD_QTY" + Integer.toString(idx)).toString().trim());
					int INPUT_COUNT = Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
					int GDS_COST = Integer.parseInt((String)hm.get("GDS_COST" + Integer.toString(idx)).toString().trim());
					int nCount = INPUT_COUNT - SORD_QTY;
					String ITEM_CD = (String)hm.get("ITEM_CD" + Integer.toString(idx)).toString().trim();
					INPUT_DT = (String)hm.get("INPUT_DT" + Integer.toString(idx)).toString().trim();
					i=0;
	//				df.CommLogger("▶ SORD_QTY : " + Integer.toString(SORD_QTY) );
	//				df.CommLogger("▶ INPUT_COUNT : " + Integer.toString(INPUT_COUNT) );
	//				df.CommLogger("▶ GDS_COST: " + Integer.toString(GDS_COST) );
	//				df.CommLogger("▶ ORG_CD: " + ORG_CD );
	//				df.CommLogger("▶ ITEM_CD: " + ITEM_CD );
	//				df.CommLogger("▶ pCOM_CD: " + pCOM_CD );
	//				df.CommLogger("▶ INPUT_DT: " + INPUT_DT );
	
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, "201");		
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, INPUT_DT); // 수정 I.G
					sql.setString( ++i, INPUT_DT); // 수정 I.G
					
	//				nAMT += nCount * GDS_COST;
					
					df.CommLogger("▶ SQL 1: " + sql.debug() );
					int rows = executeUpdate(sql);
					df.CommLogger("▶ ***************************************** rows : " + rows );
					
					if (rows > 0)
					{
						nAMT += Integer.parseInt((String)hm.get("ADD_TO_LOANAMT" + Integer.toString(idx)).toString().trim());
					}
					sql.close();
				}
				
				i=0;
				df.CommLogger("▶ AMT : " + nAMT );
				// 발주 후 여신 처리
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.CALL_PR_HQ_STRLOAN_INFO));
				/// 
				/// 회사코드
				/// 점포코드
				/// [발주수량] * [공급가]
				/// [사용자]
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				//sql.setString( ++i, INPUT_DT);
				sql.setInt(++i, nAMT ); // FF발주 선마감으로 변경(저장된 데이터만 계산)
				//sql.setInt(++i, Integer.parseInt((String)hm.get("TOT_ADD_AMT")));
				sql.setString( ++i, ORG_CD);
				
				df.CommLogger("▶ SQL 2: " + sql.debug() );
				int nResult00 = executeUpdate(sql);
				sql.close();
				
				
				i=0;
				// 발주 후 점포 칼렌더 발주 여부 업데이트 
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.UPD_ST_STRCALENDAR_MGR));
				///
				///
				/// 수정자ID
				/// 회사코드
				/// 점포코드
				///
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, INPUT_DT);
				
	//			df.CommLogger("▶ SQL 3: " + sql.debug() );
				int nResult01 = executeUpdate(sql);
				sql.close();
			}else {
				//ret = "09";
				ret = RET_VAL;
			}
	
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluUpdate(hm,idx);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * setStandPluUpdate3
	 * : [점포 발주] 발주수정(저장)
	 *   FF발주 선마감 반영 2016.10.21 I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setStandPluUpdate3(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		int nAMT = 0;
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		connect("CMGNS");
		try {
			begin();
			
			String RET_VAL = getCloseOrderTime3(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT0").toString().trim(),df);			
			//df.CommLogger("*************************************RET_VAL : " + RET_VAL);
			if(RET_VAL.equals("00") || RET_VAL.equals("01")) {
			
				String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
				String INPUT_DT = "";
	
				int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
	//			df.CommLogger("▶ ROWS_COUNT: " + Integer.toString(total_cnt) );
				// 발주 처리
				//
				for(idx = 0;idx < total_cnt;idx++ ) {
					sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.TB_PRODUCT_UPDATE2));
					///
					/// INPUT Params
					///
					/// COM_CD
					/// BIZLOC_ORG_CD
					/// ITEM_CD
					/// ORD_TP = 202  // 발주구분<B144> VARCHAR2(1) (201:진열대발주, 202:스캔발주) 
					/// ORD_QTY
					/// ORD_QTY
					/// ORD_QTY
					/// 등록자ID
					/// 수정자ID
					/// ITEM_CD
					/// COM_CD
					/// BIZLOC_ORG_CD
					///
					int SORD_QTY = Integer.parseInt((String)hm.get("SORD_QTY" + Integer.toString(idx)).toString().trim());
					int INPUT_COUNT = Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
					int GDS_COST = Integer.parseInt((String)hm.get("GDS_COST" + Integer.toString(idx)).toString().trim());
					int nCount = INPUT_COUNT - SORD_QTY;
					String ITEM_CD = (String)hm.get("ITEM_CD" + Integer.toString(idx)).toString().trim();
					INPUT_DT = (String)hm.get("INPUT_DT" + Integer.toString(idx)).toString().trim();
					i=0;
	//				df.CommLogger("▶ SORD_QTY : " + Integer.toString(SORD_QTY) );
	//				df.CommLogger("▶ INPUT_COUNT : " + Integer.toString(INPUT_COUNT) );
	//				df.CommLogger("▶ GDS_COST: " + Integer.toString(GDS_COST) );
	//				df.CommLogger("▶ ORG_CD: " + ORG_CD );
	//				df.CommLogger("▶ ITEM_CD: " + ITEM_CD );
	//				df.CommLogger("▶ pCOM_CD: " + pCOM_CD );
	//				df.CommLogger("▶ INPUT_DT: " + INPUT_DT );
	
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, "201");		
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setInt   ( ++i, INPUT_COUNT );
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, ITEM_CD );
					sql.setString( ++i, pCOM_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, ORG_CD);
					sql.setString( ++i, INPUT_DT);
					sql.setString( ++i, INPUT_DT);
					
	//				nAMT += nCount * GDS_COST;
					
					df.CommLogger("▶ SQL 1: " + sql.debug() );
					int rows = executeUpdate(sql);
					
					if (rows > 0)
					{
						nAMT += Integer.parseInt((String)hm.get("ADD_TO_LOANAMT" + Integer.toString(idx)).toString().trim());
					}
					sql.close();
				}
				
				i=0;
				df.CommLogger("▶ AMT : " + nAMT );
				// 발주 후 여신 처리
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.CALL_PR_HQ_STRLOAN_INFO));
				/// 
				/// 회사코드
				/// 점포코드
				/// [발주수량] * [공급가]
				/// [사용자]
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				//sql.setString( ++i, INPUT_DT);
				sql.setInt(++i, nAMT ); // FF발주 선마감으로 변경(저장된 데이터만 계산)
	//			sql.setInt(++i, Integer.parseInt((String)hm.get("TOT_ADD_AMT")));			
				sql.setString( ++i, ORG_CD);
				
				df.CommLogger("▶ SQL 2: " + sql.debug() );
				int nResult00 = executeUpdate(sql);
				sql.close();
				
				
				i=0;
				// 발주 후 점포 칼렌더 발주 여부 업데이트 
				//
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.UPD_ST_STRCALENDAR_MGR));
				///
				///
				/// 수정자ID
				/// 회사코드
				/// 점포코드
				///
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, INPUT_DT);
				
	//			df.CommLogger("▶ SQL 3: " + sql.debug() );
				int nResult01 = executeUpdate(sql);
				sql.close();
				
				ret = RET_VAL;
			}else {
				//ret = "09";
				ret = RET_VAL;
			}
	
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluUpdate(hm,idx);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * setStandPluUpdate4
	 * : [점포 발주] 발주수정(저장) - 신발주 적용 I.G 180309
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setStandPluUpdate4(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();

		String dataMsg = "";
		String ret = "00";
		String ret1 = "00";
		String ret2 = "00";
		
		int idx = 0;
		int nAMT = 0;
		int i = 0;
		
		PDACommIFServiceDAO2 dao1 = new PDACommIFServiceDAO2();
		PDACommIFBackDAO2 dao2 = new PDACommIFBackDAO2();
		df.CommLogger( "===========================> Update3 start");
		
		try {
			begin();
			
			String RET_VAL = getCloseOrderTime3(pCOM_CD,pSTORE_CD,(String)hm.get("INPUT_DT0").toString().trim(),df);
			//df.CommLogger("*************************************RET_VAL : " + RET_VAL);
			if(RET_VAL.equals("00") || RET_VAL.equals("01")) {
				
				String NEW_ORDER_YN = getNewOrderStore(pCOM_CD, pSTORE_CD, df);
				
				if(NEW_ORDER_YN.equals("N")){
					ret1 = dao1.setScanPluUpdateOld(pCOM_CD, pSTORE_CD, hm, df);
					df.CommLogger( "===========================> ret1 :::::"+ret1);
				} else {
					ret1 = dao1.setScanPluUpdateOld(pCOM_CD, pSTORE_CD, hm, df);
					df.CommLogger( "===========================> ret1 :::::"+ret1);
					
					if(ret1.equals("00")) {
						ret2 = dao2.setScanPluUpdateNew(pCOM_CD, pSTORE_CD, hm, df);
						df.CommLogger( "===========================> ret2 :::::"+ret2);
					}				
				}
            }else {
            	ret = RET_VAL;
            }
			
		}catch(SQLException e) {
			dao1.rollback();
			dao2.rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			dao1.rollback();
			dao2.rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			if (!ret1.equals("00")){
				dao1.rollback();				
				ret = ret1;
				df.CommLogger( "===========================> Rollback1");
			} else if (!ret2.equals("00")) {
				dao1.rollback();
				dao2.rollback();
				ret = ret2;
				df.CommLogger( "===========================> Rollback2");
			} else {
				df.CommLogger( "===========================> Commit");
			}
			end();
			dao1.end();
			dao2.end();
			
			//dataMsg = ret + makeStandPluUpdate(hm,idx);
			dataMsg = ret + makeScanPluUpdateSendData(hm,1);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeScanPluUpdateSendData : [점포발주]
	 * : 점포발주-진열대 진열대 상품 정보 수정 응답
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeStandPluUpdate(HashMap hm, int idx) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 30, 10, 10 };
		String strHeaders[] = {
				"INQ_TYPE",   	// "30": Search Product(상품 조회)
				"SLIP_NO",		// 발주번호
				"ROW_COUNT",	// 자료처리건수
				"RESULT_CD "	// 결과코드
		};

		StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE" + Integer.toString(0)), nlens[0]);
		StringUtil.appendSpace(sb, "SLIP_NO", nlens[1]);
		StringUtil.appendSpace(sb, Integer.toString(idx), nlens[2]);
		if( idx > 0 ) {
			StringUtil.appendSpace(sb, "00", nlens[3]);
		}else {
			StringUtil.appendSpace(sb, "09", nlens[3]);
		}
				
		return sb.toString();
	}
	
	/***************************************************************************
	 * selIncomInfo 입고상품 정보
	 * 
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selIncomInfo(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();
			
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_INCOM_CHK));
			sql.setString(++i, (String)hm.get("SLIP_NO").toString().trim());
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			
			list = executeQuery(sql);
			int incomchk = list.size();
			if(incomchk == 1)
			{
				//df.CommLogger("OK");
				hm.put("INQ_TYPE"," "); 
				hm.put("SLIP_SEQ"," ");
				hm.put("PLU_CD"," ");
				hm.put("PLU_NM"," ");
				hm.put("WARIN_QTY"," ");
				hm.put("PLU_INV"," ");
				hm.put("STR_SAL_PRC"," ");
				ret = "10";
				end();
				dataMsg = ret + makeIncomInfo(hm, list, df);
				return dataMsg;
			}
			else
			{
				i = 0;
				sql.clearParameter();
				sql.close();
				
			}
			
//			df.CommLogger("▶ SLIP_NO : " + (String)hm.get("SLIP_NO"));
//			df.CommLogger("▶ WARIN_DT : " + (String)hm.get("WARIN_DT"));
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_INCOM_PRODUCT));//SEL_INCOM_INFO
			sql.setString(++i, (String)hm.get("SLIP_NO").toString().trim());
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			//sql.setString(++i, (String)hm.get("WARIN_DT"));

//			df.CommLogger("▶ SLIP_NO : " + (String)hm.get("SLIP_NO"));
//			df.CommLogger("▶ COM_CD : " + pCOM_CD);
//			df.CommLogger("▶ STORE_CD : " + STORE_FIRST_CODE + pSTORE_CD);
//			
//			df.CommLogger("▶ SQL : " + sql.debug());
			
			list = executeQuery(sql);
			
//			df.CommLogger("▶ list size : " + Integer.toString(list.size()));
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) {
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeIncomInfo(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeIncomInfo : 점포입고-2 전표에 해당하는 상품정보 응답
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeIncomInfo(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int iq_info_header_lens[] = {2, 10, 30, 30, 30 };
		int hdr_lens[] = { 2, 10, 30, 50, 10, 10, 10 };
		String iq_info_headers[] = {
				"INQ_TYPE",
				"INQ_COUNT",
                "INQ_COLUME1",
                "INQ_COLUME2",
                "INQ_COLUME3"
		};
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// 
				"SLIP_SEQ",				// ROW Number
				"PLU_CD",				// 상품 코드
				"PLU_NM",				// 상품 이름
				"WARIN_QTY",			// 입고수량
				"PLU_INV",				// 상품 재고수량
				"STR_SAL_PRC"			// 점포매가
		};
		
		try
		{
			StringUtil.appendSpace(sb, (String)hm.get(iq_info_headers[0].toString()), iq_info_header_lens[0]);
			
//			df.CommLogger("▶ ROWS_COUNT : " + (String)hm.get("ROWS_COUNT").toString().trim());
			
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT"), iq_info_header_lens[1]);
			
			int i = 0;
			if( nRowCount > 0 ) {
				for(i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					
					if(i==0)
					{

						StringUtil.appendSpace(sb, (String)map.get("WM_CENT_NM"), iq_info_header_lens[2]);
						StringUtil.appendSpace(sb, (String)map.get("DVY_ROOT_TP_NM"), iq_info_header_lens[3]);
						StringUtil.appendSpace(sb, (String)map.get("WM_CONF_TP")+"|"+(String)map.get("WARIN_DT"), iq_info_header_lens[4]);
					}
					
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					StringUtil.appendSpace(sb, (String)map.get("SLIP_SEQ"), hdr_lens[1]);
					StringUtil.appendSpace(sb, (String)map.get("PLU_CD"), hdr_lens[2]);
					StringUtil.appendSpace(sb, (String)map.get("GDS_NM"), hdr_lens[3]);
					StringUtil.appendSpace(sb, (String)map.get("WARIN_QTY"), hdr_lens[4]);
					StringUtil.appendSpace(sb, (String)map.get("NSTCK_QTY"), hdr_lens[5]);
					StringUtil.appendSpace(sb, (String)map.get("STR_SAL_PRC"), hdr_lens[6]);
					
					
				}
			}else {
				//df.CommLogger("▶ hdr_StrHeaders[0] is : " + (String)hm.get(hdr_StrHeaders[0].toString()) );
				if(i==0)
				{

					StringUtil.appendSpace(sb, "", iq_info_header_lens[1]);
					StringUtil.appendSpace(sb, "", iq_info_header_lens[2]);
					StringUtil.appendSpace(sb, "", iq_info_header_lens[3]);
				}
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				StringUtil.appendSpace(sb, Integer.toString(0), hdr_lens[1]);
				StringUtil.appendSpace(sb, "", hdr_lens[2]);				
				StringUtil.appendSpace(sb, "", hdr_lens[3]);
				StringUtil.appendSpace(sb, "", hdr_lens[4]);
				StringUtil.appendSpace(sb, "", hdr_lens[5]);
				StringUtil.appendSpace(sb, "", hdr_lens[6]);
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeIncomInfo : " + e.getMessage());
			throw e;
		}

		return sb.toString();
	}
	/***************************************************************************
	 * setIncomUpdate 입고상품 정보 수정 요청
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setIncomUpdate(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		connect("CMGNS");
		try {
			begin();
			int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			begin();
//			df.CommLogger( "▶ ROWS:"+(String)hm.get("ROWS_COUNT").toString().trim());
			// 전표 상세 저장
			for(idx = 0;idx < total_cnt;idx++ ) {
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.TB_INCOM_DETAIL_UPDATE));
				
//				df.CommLogger( "▶ [1]:"+(String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
//				df.CommLogger( "▶ [2]:"+(String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
//				df.CommLogger( "▶ [3]:"+STORE_FIRST_CODE + pSTORE_CD);
//				df.CommLogger( "▶ [4]:"+pCOM_CD);
//				df.CommLogger( "▶ [5]:"+(String)hm.get("SLIP_NO" + Integer.toString(idx)).toString().trim());
//				df.CommLogger( "▶ [6]:"+(String)hm.get("SLIP_SEQ" + Integer.toString(idx)).toString().trim());
				
				i=0;
				sql.setInt   ( ++i, Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim()) );
				sql.setInt   ( ++i, Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim()) );
				sql.setString( ++i, STORE_FIRST_CODE + pSTORE_CD);
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, (String)hm.get("SLIP_NO" + Integer.toString(idx)).toString().trim() );
				sql.setString( ++i, (String)hm.get("SLIP_SEQ" + Integer.toString(idx)).toString().trim() );
				
//				df.CommLogger( "▶ [TB_INCOM_DETAIL_UPDATE] SQL:"+sql.debug());
				int rows = executeUpdate(sql);
				sql.close();
			}
			// 전표 헤더 저장
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.TB_INCOM_MASTER_UPDATE));
			i=0;
//			df.CommLogger( "▶ [1]:"+pCOM_CD);
//			df.CommLogger( "▶ [2]:"+(String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim());
			sql.setString( ++i, STORE_FIRST_CODE + pSTORE_CD);
			sql.setString( ++i, pCOM_CD);
			sql.setString( ++i, (String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim() );
//			df.CommLogger( "▶[TB_INCOM_MASTER_UPDATE] SQL:"+sql.debug());
			int rows2 = executeUpdate(sql);
			sql.close();
			// 헤더 저장 후 실행 ( 현재고 처리)
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.CALL_PR_ST_SLIP_CONF));
			i=0;
//			df.CommLogger( "▶ [1]:"+(String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim());
//			df.CommLogger( "▶ [2]:"+pCOM_CD);
//			df.CommLogger( "▶ [3]:"+(String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim());
//			df.CommLogger( "▶ [4]:"+STORE_FIRST_CODE + pSTORE_CD);
			sql.setString( ++i, (String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim() );
			sql.setString( ++i, pCOM_CD);
			sql.setString( ++i, (String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim() );
			sql.setString( ++i, STORE_FIRST_CODE + pSTORE_CD);
//			df.CommLogger( "▶ [CALL_PR_ST_SLIP_CONF] SQL:"+sql.debug());
			int rows3 = executeUpdate(sql);
			sql.close();
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeIncomUpdate(hm,idx);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeScanPluUpdateSendData [점포발주]
	 * : 입고상품 정보 수정 응답
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeIncomUpdate(HashMap hm, int idx) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 30, 10, 10 };
		String strHeaders[] = {
				"INQ_TYPE",   	// "30": Search Product(상품 조회)
				"SLIP_NO",		// 발주번호
				"ROW_COUNT",	// 자료처리건수
				"RESULT_CD "	// 결과코드
		};

		StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE" + Integer.toString(0)), nlens[0]);
		StringUtil.appendSpace(sb, (String)hm.get("SLIP_NO" + Integer.toString(0)), nlens[1]);
		StringUtil.appendSpace(sb, Integer.toString(idx), nlens[2]);
		StringUtil.appendSpace(sb, "00", nlens[3]);

		return sb.toString();
	}

	/***************************************************************************
	 * selInventoryAdjustment : 상품재고정보 
	 * 
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selInventoryAdjustment(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int state = 0;
		connect("CMGNS");
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_INVENTORY_PLUINFO));
			///
			/// 조직코드
			/// 회사
			/// 조직코드
			/// PLU_CD
			/// 회사
			///
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());
			sql.setString(++i, pCOM_CD.trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim() );
			sql.setString(++i, pCOM_CD.trim());
			
//			df.CommLogger("▶ SQL : "+sql.debug());
			
//			df.CommLogger(" 조직코드 : " + STORE_FIRST_CODE + pSTORE_CD.trim());
//			df.CommLogger(" 회사코드 : " + pCOM_CD.trim());
//			df.CommLogger(" PLU_CD : " + (String)hm.get("PLU_CD").toString().trim());
			
			list = executeQuery(sql);
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));

//			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			sql.clearParameter();
			sql.close();
			
			if(list.size() <= 0){
				i=0;
				state = 1;
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_IQ_INV_NSTCK_QTY));
				sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());
				sql.setString(++i, STORE_FIRST_CODE+ pSTORE_CD.trim());
				//df.CommLogger("sql: "+sql.debug());
				list = executeQuery(sql);
				
				hm.remove("ROWS_COUNT");
				total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			}
			if( list.size() <= 0 )
			{
				hm.put("PLU_CD", " ");
				hm.put("PLU_NM", " ");
				hm.put("ITEM_CD", " ");
				hm.put("STAND_CD", " ");
				hm.put("PLU_TP", " ");
				hm.put("ORD_ENBL_TP", " ");
				hm.put("ORD_ACQ_QTY", "0");
				hm.put("ORD_LOW", "0");
				hm.put("ORD_MAX", "0");
				hm.put("NSTCK_QTY", "0");
				hm.put("SALE_QTY", "0");
				hm.put("STR_SAL_PRC", "0");
				hm.put("GDS_COST", " ");
				hm.put("INNER_BOX_BARCD", " ");
				hm.put("INNER_BOX_ACQ_QTY", "0");
				hm.put("SORD_QTY", "0");
				hm.put("AMT", "0");
				
				ret = "09";
			}
			
			hm.put("PLU_NM", (String)map.get("PLU_NM"));
			hm.put("PLU_INV", (String)map.get("PLU_INV"));
			hm.put("PLU_SALE", (String)map.get("PLU_SALE"));
			hm.put("ITEM_CD", (String)map.get("ITEM_CD"));
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			sql.close();
			end();
			dataMsg = ret + makeInventoryAdjustment(hm, list, df);//makeScanPluInfo(hm, list, df);
			
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selInventoryAdjustment : 상품재고정보 - PLU(바코드) 체크추가 I.G
	 * 
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selInventoryAdjustment2(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		List list = null;
		List list1 = null;
		Map map = new HashMap();
		Map map1 = new HashMap();
		int i = 0;
		int j = 0;
		String dataMsg = "";
		String ret = "00";
		int state = 0;
		connect("CMGNS");
		
		try {
			begin();
			
			String pLU_CD = (String)hm.get("PLU_CD").toString().trim();			
			if (pLU_CD.length() < 13) {				
				sql1.put(findQuery(COMMBiz_PDA.PDA_SQL,	COMMBiz_PDA.SEL_PLU_INFO_CHK));				
				sql1.setString(++j, pLU_CD);                         /* PLU코드 */
				sql1.setString(++j, pLU_CD);                         /* PLU코드 */
				sql1.setString(++j, pCOM_CD);                        /* 회사코드 */
				sql1.setString(++j, STORE_FIRST_CODE + pSTORE_CD);   /* 점포코드 */
				sql1.setString(++j, pLU_CD);                         /* PLU코드 */
				
				//df.CommLogger(sql1.debug());
				list1 = executeQuery(sql1);				
				map1 = (Map) list1.get(0);				
				pLU_CD = (String) map1.get("PLU_CD_N");
				//df.CommLogger("▶ pLU_CD ********** : "+pLU_CD);
				sql1.clearParameter();
				sql1.close();
			}
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.TB_INVENTORY_PLUINFO));

			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());
			sql.setString(++i, pCOM_CD.trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());
			sql.setString(++i, pLU_CD.trim());  // 수정 I.G
			sql.setString(++i, pCOM_CD.trim());
			
//			df.CommLogger("▶ SQL : "+sql.debug());
			
//			df.CommLogger(" 조직코드 : " + STORE_FIRST_CODE + pSTORE_CD.trim());
//			df.CommLogger(" 회사코드 : " + pCOM_CD.trim());
//			df.CommLogger(" PLU_CD : " + (String)hm.get("PLU_CD").toString().trim());
			
			list = executeQuery(sql);
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));

//			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			sql.clearParameter();
			sql.close();
			
			if(list.size() <= 0){
				i=0;
				state = 1;
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_IQ_INV_NSTCK_QTY));
				sql.setString(++i, pLU_CD.trim());  // 수정 I.G
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());
				//df.CommLogger("sql: "+sql.debug());
				list = executeQuery(sql);
				
				hm.remove("ROWS_COUNT");
				total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			}
			if( list.size() <= 0 )
			{
				hm.put("PLU_CD", " ");
				hm.put("PLU_NM", " ");
				hm.put("ITEM_CD", " ");
				hm.put("STAND_CD", " ");
				hm.put("PLU_TP", " ");
				hm.put("ORD_ENBL_TP", " ");
				hm.put("ORD_ACQ_QTY", "0");
				hm.put("ORD_LOW", "0");
				hm.put("ORD_MAX", "0");
				hm.put("NSTCK_QTY", "0");
				hm.put("SALE_QTY", "0");
				hm.put("STR_SAL_PRC", "0");
				hm.put("GDS_COST", " ");
				hm.put("INNER_BOX_BARCD", " ");
				hm.put("INNER_BOX_ACQ_QTY", "0");
				hm.put("SORD_QTY", "0");
				hm.put("AMT", "0");
				
				ret = "09";
			}
			
			hm.put("PLU_CD", pLU_CD);
			hm.put("PLU_NM", (String)map.get("PLU_NM"));
			hm.put("PLU_INV", (String)map.get("PLU_INV"));
			hm.put("PLU_SALE", (String)map.get("PLU_SALE"));
			hm.put("ITEM_CD", (String)map.get("ITEM_CD"));
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			sql.close();
			end();
			dataMsg = ret + makeInventoryAdjustment(hm, list, df);//makeScanPluInfo(hm, list, df);
			
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeInventoryAdjustment : 상품재고정보 응답.
	 * IQ_INV_AD_RSP
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeInventoryAdjustment(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2, 
                20,
                50,
                10,
                10,
                10,
                30,
                30,
                4,
                2,
                10,
                10,
                10,
                10,
                10,
                20,
                10,
                10 
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "87": 재고조정 상품 조회
				"PLU_CD",   			//
				"PLU_NM",   			//
				"NSTCK_QTY",   			//
				"SORD_QTY",   			//
				"SALE_QTY",   			//
				
				"ITEM_CD",   			//
				"STAND_CD",   			//
				"PLU_TP",   			//
				"ORD_ENBL_TP",   		//
				"ORD_ACQ_QTY",   		//
				"ORD_LOW",   			//
				"ORD_MAX",   			//
				
				
				"STR_SAL_PRC",   		//
				"GDS_COST",   			//
				"INNER_BOX_BARCD",   	//
				"INNER_BOX_ACQ_QTY",   	//
				
				"AMT"   				//
		};

		try {
			// ROWS_COUNT Length is 10.
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			//StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			//df.CommLogger(Integer.toString(nRowCount));
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
//						df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, " ", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeScanPluInfo : " + e.getMessage());
			throw e;
		}
		

		return sb.toString();
	}

	/***************************************************************************
	 * setInventoryUpdate : 상품재고정보 수정
	 * 
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setInventoryUpdate(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();
			String STORE_CD = STORE_FIRST_CODE + pSTORE_CD.trim();
			String COM_CD = pCOM_CD.trim();
			String ITEM_CD = (String)hm.get("ITEM_CD").toString().trim();
			int INPUT_QTY = Integer.parseInt( (String)hm.get("INPUT_QTY").toString().trim() );
//			df.CommLogger( "▶ [1] STORE_CD :" + STORE_CD);
//			df.CommLogger( "▶ [2] COM_CD :" + COM_CD);
//			df.CommLogger( "▶ [3] ITEM_CD :" + ITEM_CD);
//			df.CommLogger( "▶ [3] INPUT_QTY :" + INPUT_QTY);
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.UPD_INVENTORY_QTY_LOG2));
			
			// [회사코드]
			// [조직코드]
			// [품목코드]
			// [조정수량]
			// [사용자]
			// [사용자]
			
			// [조직코드]
			// [품목코드]
			// [회사코드]
			sql.setString( ++i, COM_CD);
			sql.setString( ++i, STORE_CD);
			sql.setString( ++i, ITEM_CD);
			sql.setInt   ( ++i, INPUT_QTY);
			sql.setString( ++i, STORE_CD);
			sql.setString( ++i, STORE_CD);
			
			sql.setString( ++i, STORE_CD);
			sql.setString( ++i, ITEM_CD);
			sql.setString( ++i, COM_CD);
			
//			df.CommLogger( "▶ SQL 1 :" + sql.debug());
			int rows1 = executeUpdate(sql);
			sql.close();
			
			i = 0;
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.UPD_INVENTORY_QTY_MGR));

			// [회사코드]
			// [조직코드]
			// [품목코드]
			// [조정수량]
			// [사용자]
			// [사용자]
			sql.setString( ++i, COM_CD);
			sql.setString( ++i, STORE_CD);
			sql.setString( ++i, ITEM_CD);
			sql.setInt   ( ++i, INPUT_QTY);
			sql.setString( ++i, STORE_CD);
			sql.setString( ++i, STORE_CD);
			
//			df.CommLogger( "▶ SQL  2 :" + sql.debug());
			int rows2 = executeUpdate(sql);
			sql.close();
			
			hm.put("RESULT_CD", "00");
			
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeInventoryUpdate(hm);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * setInventoryUpdate : 상품재고정보 수정
	 *   - 프로시저 호출하는 로직으로 변경 160718 I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setInventoryUpdate2(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();
			String STORE_CD = STORE_FIRST_CODE + pSTORE_CD.trim();
			String COM_CD = pCOM_CD.trim();
			String ITEM_CD = (String)hm.get("ITEM_CD").toString().trim();
			int INPUT_QTY = Integer.parseInt( (String)hm.get("INPUT_QTY").toString().trim() );
			
			df.CommLogger( "▶ [1] COM_CD :" + COM_CD);
			df.CommLogger( "▶ [2] STORE_CD :" + STORE_CD);			
			df.CommLogger( "▶ [3] ITEM_CD :" + ITEM_CD);
			df.CommLogger( "▶ [4] INPUT_QTY :" + INPUT_QTY);
			df.CommLogger( "▶ [5] STORE_CD :" + STORE_CD);
			
			i = 0;
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.CALL_PR_ST_STRINVTRYBAL_HIS));
			//df.CommLogger( "▶ CALL_PR_ST_STRINVTRYBAL_HIS");
			
			sql.setString( ++i, COM_CD);
			sql.setString( ++i, STORE_CD);
			sql.setString( ++i, ITEM_CD);
			sql.setInt   ( ++i, INPUT_QTY);
			sql.setString( ++i, STORE_CD);
			
			//df.CommLogger( "▶ SQL 1 :" + sql.debug());
			int rows1 = executeUpdate(sql);
			sql.close();
			
			hm.put("RESULT_CD", "00");
			
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeInventoryUpdate(hm);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String setInventoryUpdate_old(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();
			String STORE_CD = STORE_FIRST_CODE + pSTORE_CD.trim();
			String COM_CD = pCOM_CD.trim();
			String ITEM_CD = (String)hm.get("ITEM_CD").toString().trim();
			int INPUT_QTY = Integer.parseInt( (String)hm.get("INPUT_QTY").toString().trim() );
//			df.CommLogger( "▶ [1] STORE_CD :" + STORE_CD);
//			df.CommLogger( "▶ [2] COM_CD :" + COM_CD);
//			df.CommLogger( "▶ [3] ITEM_CD :" + ITEM_CD);
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.UPD_INVENTORY_MST));
//			df.CommLogger( "▶ SQL 1 :" + sql.get().toString());
			// @params
			// 회사코드
			// 조직코드
			// 담당자ID
			// 등록자ID
			// 수정자ID
			sql.setString( ++i, COM_CD);
			sql.setString( ++i, STORE_CD);
			sql.setString( ++i, STORE_CD);
			sql.setString( ++i, STORE_CD);
			sql.setString( ++i, STORE_CD);
			int rows1 = executeUpdate(sql);
			sql.close();

			i = 0;
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.UPD_INVENTORY_DTL));
//			df.CommLogger( "▶ SQL  2 :" + sql.get().toString());
			// @params
			// 조정수량 int
			// 확정수량 int
			// 등록자ID
			// 수정자ID
			// 품목코드
			// 회사코드
			// 조직코드
			sql.setInt   ( ++i, INPUT_QTY);
			sql.setInt   ( ++i, INPUT_QTY);
			sql.setString( ++i, STORE_CD);
			sql.setString( ++i, STORE_CD);
			sql.setString( ++i, ITEM_CD);
			sql.setString( ++i, COM_CD);
			sql.setString( ++i, STORE_CD);
			int rows2 = executeUpdate(sql);
			sql.close();
			
			hm.put("RESULT_CD", "00");
			
		}catch(SQLException e) {
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			rollback();
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			rollback();
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeInventoryUpdate(hm);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	/***************************************************************************
	 * makeInventoryUpdate
	 * : 상품재고정보 수정
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeInventoryUpdate(HashMap hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 20 };
		String strHeaders[] = {
				"INQ_TYPE",   	// 
				"RESULT_CD "	// 결과코드
		};

		StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE"), nlens[0]);
		StringUtil.appendSpace(sb, (String)hm.get("RESULT_CD"), nlens[1]);

		return sb.toString();
	}

	/***************************************************************************
	 * getParseMasterStandReq
	 * : 진열대 마스터 정보 요청
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getParseMasterStandReq(String pCOM_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try { 
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.GET_PDA_MESSAGE));//.TB_MASTER_STAND_LIST));
			sql.setString(++i, pCOM_CD);
			sql.setString(++i, (String)hm.get("MOD_DT").toString().trim());
			
//			df.CommLogger("▶ SQL:"+sql.get().toString());
//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
//			df.CommLogger("▶ MOD_DT:"+(String)hm.get("MOD_DT").toString().trim());

			list = executeQuery(sql);
			
//			int total_cnt = list.size();
//			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
//			
//			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));

			if( list.size() <= 0 ) {
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeMasterStandReq(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeMasterStandReq : 진열대 마스터 정보 요청
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeMasterStandReq(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10, 50, 20, 20 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "72": Search Stand Info(진열대 조회)
				"STAND_CD",				// 진열대 코드
				"STAND_NM",				// 진열대 이름
				"MOD_DT",				// 최종 수정 일자.
				"STAND_SEQ"
		};
		
		try
		{
			// ROWS_COUNT Length is 10.
//			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
//			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), hdr_lens[1]);
			int total_cnt = list.size();
			StringUtil.appendSpace(sb, Integer.toString(total_cnt), hdr_lens[1]);
//			df.CommLogger("▶ total_cnt:"+Integer.toString(total_cnt));
			
			if( total_cnt > 0 ) {
				for(int i = 0;i < total_cnt;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
//					StringUtil.appendSpace(sb, (String)map.get("STAND_CD"), hdr_lens[1]);
//					StringUtil.appendSpace(sb, (String)map.get("STAND_NM"), hdr_lens[2]);
//					StringUtil.appendSpace(sb, (String)map.get("MOD_DTM"), hdr_lens[3]);
//					StringUtil.appendSpace(sb, (String)map.get("STAND_SEQ"), hdr_lens[4]);
					
					StringUtil.appendSpace(sb, (String)map.get("LNG_TP"), hdr_lens[1]);
					StringUtil.appendSpace(sb, (String)map.get("PDA_MSG_VAL"), hdr_lens[2]);
					StringUtil.appendSpace(sb, (String)map.get("PDA_MSG_CD"), hdr_lens[3]);
					StringUtil.appendSpace(sb, (String)map.get("PDA_MSG_GRP_TP"), hdr_lens[4]);
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				StringUtil.appendSpace(sb, "", hdr_lens[1]);
				StringUtil.appendSpace(sb, "", hdr_lens[2]);
				StringUtil.appendSpace(sb, "", hdr_lens[3]);
				StringUtil.appendSpace(sb, "", hdr_lens[4]);
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeMasterStandReq Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * getAppVersion
	 * : 버전 정보 요청
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getAppVersion(String pCOM_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try { 
			begin();
			
//			df.CommLogger("▶ PDA Version :"+(String)hm.get("VER").toString().trim());
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.GET_APP_VERSION));

			list = executeQuery(sql);
			
			if( list.size() < 0 ) {
				ret = "09";
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeAppVersion(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String getStoreEXCEPTINFOS(HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map<String, String> map = new HashMap();
		int i = 0;
		
		StringBuffer sb = new StringBuffer();
		
		int nlens[] = { 2, 20, 50, 10, 50,
				        50, 9, 50, 50, 10, 
				        10, 4, 10, 10, 10,
				        10, 50, 50, 2, 20,
				        30, 2};
		
		String strHeaders[] = {
			"INQ_TYPE",//2
			"PLU_CD",//20
			"PLU_NM",//50
			"VEN_CD",//10
			"VEN_NM",//50
			
			"ORD_SUG_NM",//50
			"CIRC_TMLMT",//9
			"EVT_NM",//50
			"EVT_NEXT_NM",//50
			"STR_SAL_PRC",//10
			
			"GDS_COST",//10
			"PROFIT_RT",//4
			"ORD_LOW",//10
			"ORD_MAX",//10
			"NSTCK_QTY",//10
			
			"ORD_ACQ_QTY",//10
			"ITEM_VOL",//50
			"ITEM_VOL_NM",//50
			"ORD_ENBL_TP",//2
			"RTN_TP",//20
			
			"ITEM_CD",//30
			"PRCCHG_ENBL_YN"//2
		};
		
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_EXCEPT_SEARCH));

			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, (String)hm.get("CO_CD").toString().trim());
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD").toString().trim());
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD").toString().trim());
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
						
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD").toString().trim());
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());
			sql.setString(++i, (String)hm.get("CO_CD").toString().trim());
			
			//df.CommLogger("SQL:" + sql.debug());
			list = executeQuery(sql);
			//df.CommLogger(String.valueOf(list.size()));
			if( list.size() <= 0 ) 
			{				
				hm.put("PLU_CD", " ");
				hm.put("PLU_NM", " ");
				hm.put("VEN_CD", " ");
				hm.put("VEN_NM", " ");
				hm.put("ORD_SUG_NM", " ");
				hm.put("CIRC_TMLMT", " ");
				hm.put("EVT_NM", " ");
				hm.put("EVT_NEXT_NM", " ");				
				hm.put("STR_SAL_PRC", " ");
				hm.put("GDS_COST", " ");				
				hm.put("PROFIT_RT", " ");
				hm.put("ORD_LOW", " ");
				hm.put("ORD_MAX", " ");
				hm.put("NSTCK_QTY", " ");
				hm.put("ORD_ACQ_QTY", " ");
				hm.put("ITEM_VOL", " ");
				hm.put("ITEM_VOL_NM", " ");
				hm.put("ORD_ENBL_TP", " ");
				hm.put("RTN_TP", " ");
				hm.put("ITEM_CD", " ");
				hm.put("PRCCHG_ENBL_YN", " ");
				ret = "09";
			}
			else
			{
				map = (Map)list.get(0);
				map.put("INQ_TYPE", "38");
				//df.CommLogger(map.get("PLU_NM"));
				for(int j = 1; j < strHeaders.length; j++){
					//df.CommLogger(strHeaders[j] + "=" + (String)map.get(strHeaders[j]));
					if(strHeaders[j].toString() == "ORD_LOW")
					{
						StringUtil.appendSpace(sb, (String)map.get("ORD_LOW")+"/"+(String)map.get("ORD_MAX"), nlens[i]);
					} else {
						StringUtil.appendSpace(sb, (String)map.get(strHeaders[j]), nlens[j]);
					}	
				}
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + "25" + sb.toString();//makeSTRITMSELRsp(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	
	/***************************************************************************
	 * getStoreEXCEPTINFOS2 : 상품조회(발주제외 조회)
	 * - PLU(바코드) 체크추가 I.G
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getStoreEXCEPTINFOS2(HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		List list = null;
		List list1 = null;
		Map<String, String> map = new HashMap();
		Map map1 = new HashMap();
		
		int i = 0;
		int k = 0;
		
		StringBuffer sb = new StringBuffer();
		
		int nlens[] = { 2, 20, 50, 10, 50,
				        50, 9, 50, 50, 10, 
				        10, 4, 10, 10, 10,
				        10, 50, 50, 2, 20,
				        30, 2};
		
		String strHeaders[] = {
			"INQ_TYPE",//2
			"PLU_CD",//20
			"PLU_NM",//50
			"VEN_CD",//10
			"VEN_NM",//50
			
			"ORD_SUG_NM",//50
			"CIRC_TMLMT",//9
			"EVT_NM",//50
			"EVT_NEXT_NM",//50
			"STR_SAL_PRC",//10
			
			"GDS_COST",//10
			"PROFIT_RT",//4
			"ORD_LOW",//10
			"ORD_MAX",//10
			"NSTCK_QTY",//10
			
			"ORD_ACQ_QTY",//10
			"ITEM_VOL",//50
			"ITEM_VOL_NM",//50
			"ORD_ENBL_TP",//2
			"RTN_TP",//20
			
			"ITEM_CD",//30
			"PRCCHG_ENBL_YN"//2
		};
		
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		
		try {
			begin();
			
			String pLU_CD = (String)hm.get("PLU_CD").trim();
			
			if (pLU_CD.length() < 13) {			
				sql1.put(findQuery(COMMBiz_PDA.PDA_SQL,	COMMBiz_PDA.SEL_PLU_INFO_CHK));				
				sql1.setString(++k, pLU_CD);                         /* PLU코드 */
				sql1.setString(++k, pLU_CD);                         /* PLU코드 */
				sql1.setString(++k, (String)hm.get("CO_CD").toString().trim());              /* 회사코드 */
				sql1.setString(++k, "A16" + (String)hm.get("STORE_CD").toString().trim());   /* 점포코드 */
				sql1.setString(++k, pLU_CD);                         /* PLU코드 */
				
				df.CommLogger(sql1.debug());

				list1 = executeQuery(sql1);				
				map1 = (Map) list1.get(0);				
				pLU_CD = (String) map1.get("PLU_CD_N");
				//df.CommLogger("▶ pLU_CD ********** : "+pLU_CD);
				sql1.clearParameter();
				sql1.close();
			}
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_EXCEPT_SEARCH));

			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, (String)hm.get("CO_CD").toString().trim());
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD").toString().trim());
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD").toString().trim());
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
						
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD").toString().trim());
			sql.setString(++i, pLU_CD); // 수정 I.G
			sql.setString(++i, (String)hm.get("CO_CD").toString().trim());
			
			df.CommLogger("SQL:" + sql.debug());
			list = executeQuery(sql);
			//df.CommLogger(String.valueOf(list.size()));
			if( list.size() <= 0 ) 
			{				
				hm.put("PLU_CD", " ");
				hm.put("PLU_NM", " ");
				hm.put("VEN_CD", " ");
				hm.put("VEN_NM", " ");
				hm.put("ORD_SUG_NM", " ");
				hm.put("CIRC_TMLMT", " ");
				hm.put("EVT_NM", " ");
				hm.put("EVT_NEXT_NM", " ");				
				hm.put("STR_SAL_PRC", " ");
				hm.put("GDS_COST", " ");				
				hm.put("PROFIT_RT", " ");
				hm.put("ORD_LOW", " ");
				hm.put("ORD_MAX", " ");
				hm.put("NSTCK_QTY", " ");
				hm.put("ORD_ACQ_QTY", " ");
				hm.put("ITEM_VOL", " ");
				hm.put("ITEM_VOL_NM", " ");
				hm.put("ORD_ENBL_TP", " ");
				hm.put("RTN_TP", " ");
				hm.put("ITEM_CD", " ");
				hm.put("PRCCHG_ENBL_YN", " ");
				ret = "09";
			}
			else
			{
				map = (Map)list.get(0);
				map.put("INQ_TYPE", "38");
				//df.CommLogger(map.get("PLU_NM"));
				for(int j = 1; j < strHeaders.length; j++){
					//df.CommLogger(strHeaders[j] + "=" + (String)map.get(strHeaders[j]));
					if(strHeaders[j].toString() == "ORD_LOW")
					{
						StringUtil.appendSpace(sb, (String)map.get("ORD_LOW")+"/"+(String)map.get("ORD_MAX"), nlens[i]);
					} else {
						StringUtil.appendSpace(sb, (String)map.get(strHeaders[j]), nlens[j]);
					}	
				}
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + "25" + sb.toString();//makeSTRITMSELRsp(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String getStoreStockChgList(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map<String, String> map = new HashMap();
		int i = 0;
		
		StringBuffer sb = new StringBuffer();
		
		int nlens[] = { 2, 10, 20, 8, 10, 10, 30, 20, 50, 3};
		
		String strHeaders[] = {
			"INQ_TYPE",//2
			"ROW_SEQ",//10
			"PLU_CD",//20			
			"BAL_DT",//8
			"NSTCK_BAL_QTY",//10
			"BAL_QTY",//10
			"ITEM_CD",//30			
			"GDS_CD",//20			
			"GDS_NM",//50
			"ORDER_BY_NUM"//3
		};
		
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		
		try {
			begin();			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_STOCK_CHG_LIST));			
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());			
			sql.setString(++i, pCOM_CD.trim());			
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());
			
			df.CommLogger("EXE: " + sql.debug());
			list = executeQuery(sql);
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			//df.CommLogger(String.valueOf(list.size()));
			if( total_cnt <= 0 ) 
			{				
				hm.put("PLU_CD", " ");
				hm.put("BAL_DT", " ");
				hm.put("NSTCK_BAL_QTY", " ");
				hm.put("BAL_QTY", " ");
				hm.put("ITEM_CD", " ");
				hm.put("GDS_CD", " ");
				hm.put("GDS_NM", " ");
				hm.put("ORDER_BY_NUM", " ");
				ret = "09";
			}
			else
			{
				//map = (Map)list.get(0);
				//df.CommLogger(map.get("PLU_CD"));
				
				int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
				StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), nlens[1]);
				//df.CommLogger("****************** ROWS_COUNT : " + nRowCount);
				
				if( nRowCount > 0 ) {
					for(i = 0;i < nRowCount;i++ ) {						
						map = (Map)list.get(i);
						map.put("INQ_TYPE", "90");
						StringUtil.appendSpace(sb, (String)hm.get(strHeaders[0].toString()), nlens[0]);						
						for(int j = 2; j < strHeaders.length; j++){
							//df.CommLogger(strHeaders[j] + "=" + (String)map.get(strHeaders[j]));
							StringUtil.appendSpace(sb, (String)map.get(strHeaders[j].toString()), nlens[j]);
						}
						
					}
				}
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + sb.toString();//makeSTRITMSELRsp(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * getStoreStockChgList2 : 재고조정 이력 조회
	 * - PLU(바코드) 체크추가 I.G
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getStoreStockChgList2(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		List list = null;
		List list1 = null;
		Map<String, String> map = new HashMap();
		Map map1 = new HashMap();
		int i = 0;
		int k = 0;
		
		StringBuffer sb = new StringBuffer();
		
		int nlens[] = { 2, 10, 20, 8, 10, 10, 30, 20, 50, 3};
		
		String strHeaders[] = {
			"INQ_TYPE",//2
			"ROW_SEQ",//10
			"PLU_CD",//20			
			"BAL_DT",//8
			"NSTCK_BAL_QTY",//10
			"BAL_QTY",//10
			"ITEM_CD",//30			
			"GDS_CD",//20			
			"GDS_NM",//50
			"ORDER_BY_NUM"//3
		};
		
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		
		try {
			begin();
			
			String pLU_CD = (String)hm.get("PLU_CD").toString().trim();
			
			if (pLU_CD.length() < 13) {			
				sql1.put(findQuery(COMMBiz_PDA.PDA_SQL,	COMMBiz_PDA.SEL_PLU_INFO_CHK));				
				sql1.setString(++k, pLU_CD);                         /* PLU코드 */
				sql1.setString(++k, pLU_CD);                         /* PLU코드 */
				sql1.setString(++k, pCOM_CD);                        /* 회사코드 */
				sql1.setString(++k, STORE_FIRST_CODE + pSTORE_CD);   /* 점포코드 */
				sql1.setString(++k, pLU_CD);                         /* PLU코드 */
				
				df.CommLogger(sql1.debug());

				list1 = executeQuery(sql1);				
				map1 = (Map) list1.get(0);				
				pLU_CD = (String) map1.get("PLU_CD_N");
				//df.CommLogger("▶ pLU_CD ********** : "+pLU_CD);
				sql1.clearParameter();
				sql1.close();
			}
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_STOCK_CHG_LIST));			
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());			
			sql.setString(++i, pCOM_CD.trim());			
			sql.setString(++i, pLU_CD.trim());  // 수정 I.G
			
			df.CommLogger("EXE: " + sql.debug());
			list = executeQuery(sql);
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			//df.CommLogger(String.valueOf(list.size()));
			if( total_cnt <= 0 ) 
			{				
				hm.put("PLU_CD", " ");
				hm.put("BAL_DT", " ");
				hm.put("NSTCK_BAL_QTY", " ");
				hm.put("BAL_QTY", " ");
				hm.put("ITEM_CD", " ");
				hm.put("GDS_CD", " ");
				hm.put("GDS_NM", " ");
				hm.put("ORDER_BY_NUM", " ");
				ret = "09";
			}
			else
			{
				//map = (Map)list.get(0);
				//df.CommLogger(map.get("PLU_CD"));
				
				int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
				StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), nlens[1]);
				//df.CommLogger("****************** ROWS_COUNT : " + nRowCount);
				
				if( nRowCount > 0 ) {
					for(i = 0;i < nRowCount;i++ ) {						
						map = (Map)list.get(i);
						map.put("INQ_TYPE", "90");
						StringUtil.appendSpace(sb, (String)hm.get(strHeaders[0].toString()), nlens[0]);						
						for(int j = 2; j < strHeaders.length; j++){
							//df.CommLogger(strHeaders[j] + "=" + (String)map.get(strHeaders[j]));
							StringUtil.appendSpace(sb, (String)map.get(strHeaders[j].toString()), nlens[j]);
						}
						
					}
				}
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + sb.toString();//makeSTRITMSELRsp(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String getStoreITEMINFOS(HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map<String, String> map = new HashMap();
		int i = 0;
		
		StringBuffer sb = new StringBuffer();
		
		int nlens[] = { 2, 50, 10, 10, 50,10,5,30 };
		
		String strHeaders[] = {
			"INQ_TYPE",//2
			"PLU_NM",//50
			"STR_SAL_PRC",//10
			"GDS_COST",//10
			"STAND_NM",//50
			"STAND_CD",//10
			"ORD_ENBL_TP",//5
			"SE_TTM"//30
		};
		
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_ITEM_SEARCH));
			/*
			 * "INQ_TYPE",//2
			"SEL_DT",//8
			"CO_CD",//4
			"STORE_CD",//5
			"PLU_CD"//30
			 * */
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, (String)hm.get("CO_CD").toString().trim());
			sql.setString(++i, (String)hm.get("SEL_DT").toString().trim());
			sql.setString(++i, (String)hm.get("CO_CD").toString().trim());
			
			sql.setString(++i, (String)hm.get("CO_CD").toString().trim());
			
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD").toString().trim());
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());
			sql.setString(++i, (String)hm.get("CO_CD").toString().trim());
			
			//df.CommLogger(sql.debug());
			list = executeQuery(sql);
			//df.CommLogger(String.valueOf(list.size()));
			if( list.size() <= 0 ) 
			{
				
				hm.put("PLU_NM", " ");
				hm.put("STR_SAL_PRC", " ");
				hm.put("GDS_COST", " ");
				hm.put("STAND_NM", " ");
				hm.put("STAND_CD", " ");
				hm.put("ORD_ENBL_TP", " ");
				hm.put("SE_TTM", " ");
				ret = "09";
			}
			else
			{
				map = (Map)list.get(0);
				map.put("INQ_TYPE", "25");
				//df.CommLogger(map.get("PLU_NM"));
				for(int j = 1; j < strHeaders.length; j++){
					//df.CommLogger(strHeaders[j] + "=" + (String)map.get(strHeaders[j]));
					StringUtil.appendSpace(sb, (String)map.get(strHeaders[j]), nlens[j]);	
				}
				
				
			}
		
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + "25" + sb.toString();//makeSTRITMSELRsp(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public String setStoreLoan(HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map<String, String> map = new HashMap();
		int i = 0;
		
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		
		try {
			begin();
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.GET_STORELOAN));
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			
//			df.CommLogger(sql.debug());
			list = executeQuery(sql);
			
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				if( ((String)map.get("LOAN_CHK_EXCEPT_YN")).compareTo("1") == 0 ) {
					hm.put("AVB_LOAN_AMT", "0");
				}else {
					hm.put("AVB_LOAN_AMT", (String)map.get("AVB_LOAN_AMT"));
				}
				hm.put("LOAN_CHK_EXCEPT_YN", (String)map.get("LOAN_CHK_EXCEPT_YN"));
			}else {
				ret = "09";
				hm.put("AVB_LOAN_AMT", "0");
				hm.put("LOAN_CHK_EXCEPT_YN", "0");
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStoreLoanRsp(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***
	 * 점상품 조회 응답
	 * @param hm
	 * @param list
	 * @param df
	 * @return
	 * @throws Exception
	 */
	private String makeSTRITMSELRsp(HashMap<String, String> hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		
		int nlens[] = { 2, 50, 10, 10, 50,10,5,30 };
		Map map = new HashMap();
		map = (Map)list.get(0);
		
		String strHeaders[] = {
			"INQ_TYPE",//2
			"PLU_NM",//50
			"STR_SAL_PRC",//10
			"GDS_COST",//10
			"STAND_NM",//50
			"STAND_CD",//10
			"ORD_ENBL_TP",//5
			"SE_TTM"//30
		};
		
		for(int i = 0;i < nlens.length;i++) {
			df.CommLogger(strHeaders[i] + "=" + (String)hm.get(strHeaders[i]));
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i]), nlens[i]);
		}
		
		return sb.toString();
		
	}
	
	private String makeStoreLoanRsp(HashMap<String, String> hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 10, 2 };
		String strHeaders[] = {
			"INQ_TYPE",
			"AVB_LOAN_AMT",
			"LOAN_CHK_EXCEPT_YN"
		};
		
		for(int i = 0;i < nlens.length;i++) {
//			df.CommLogger(strHeaders[i] + "=" + (String)hm.get(strHeaders[i]));
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i]), nlens[i]);
		}
		
		return sb.toString();
	}
	
	/***************************************************************************
	 * setPDAEmegrTranHDR
	 * : 정전시 PDA판매 거래정보 전송 요청
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setPDAEmergencyTran(String pCOM_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		Map<String, String> map = new HashMap();
		int iRtn = 0;
		int i = 0;
		int iRowsCnt = 0;
		int iItemCnt = 0;
		int iFailCnt = 0;
		String dataMsg = "";
		String ret = "00";
		String retMsg = "";
		StringBuffer sb = new StringBuffer();
		connect("CMGNS");
		try {
			begin();
			
			iRowsCnt = Integer.parseInt((String)hm.get("ROWS_COUNT"));
			for(int nRows = 0;nRows < iRowsCnt;nRows++) {
				i = 0;
				sql.clearParameter();
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.INS_PDAEMERGTRN_HDR));
				sql.setString(++i, pCOM_CD.toString().trim());											// CO_CD
				sql.setString(++i, (String)hm.get("SALE_DT"+Integer.toString(nRows)));					// TRAN_DT
				sql.setString(++i, "A16" + (String)hm.get("STORE_CD"+Integer.toString(nRows)));			// BIZLOC_ORG_CD
				sql.setString(++i, (String)hm.get("PDA_NO"+Integer.toString(nRows)));					// PDA_NO
				sql.setString(++i, (String)hm.get("TRAN_NO"+Integer.toString(nRows)));					// TRAN_NO
				sql.setString(++i, (String)hm.get("SUM"+Integer.toString(nRows)));						// TOT_SALE_AMT
				sql.setString(++i, (String)hm.get("TOT_ITEM"+Integer.toString(nRows)));					// TOT_ROW_CNT
				
//				df.CommLogger(sql.debug());
				iRtn = executeUpdate(sql);
				sql.close();
				
				if( iRtn < 0 ) {
					iFailCnt++;
					sb.append(String.format("%02d", nRows + 1));
					continue;
				}
				
				iItemCnt = Integer.parseInt((String)hm.get("TOT_ITEM"+Integer.toString(nRows)));
				
				for(int nItems = 0;nItems < iItemCnt;nItems++) {
					i = 0;
					sql.clearParameter();
					sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.INS_PDAEMERGTRN_DTL));
					sql.setString(++i, pCOM_CD.toString().trim());
					sql.setString(++i, (String)hm.get("SALE_DT"+Integer.toString(nRows)));
					sql.setString(++i, "A16" + (String)hm.get("STORE_CD"+Integer.toString(nRows)));
					sql.setString(++i, (String)hm.get("PDA_NO"+Integer.toString(nRows)));
					sql.setString(++i, (String)hm.get("TRAN_NO"+Integer.toString(nRows)));
					sql.setString(++i, (String)hm.get("ITEM_SEQ"+Integer.toString(nRows)+Integer.toString(nItems)));
					sql.setString(++i, (String)hm.get("PLU_CD"+Integer.toString(nRows)+Integer.toString(nItems)));
					sql.setString(++i, (String)hm.get("ITEM_QTY"+Integer.toString(nRows)+Integer.toString(nItems)));
					
//					df.CommLogger(sql.debug());
					iRtn = executeUpdate(sql);
					sql.close();
				}
			}
			
			retMsg = String.format("%02d%02d%s", iRowsCnt, iFailCnt, sb.toString());
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + (String)hm.get("INQ_TYPE0") + retMsg;
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeAppVersion : 버전 정보 요청 응답
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeAppVersion(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "22": 
				"RESULT_CD" 		    // 진열대 코드
		};
		
		try
		{
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				String VER = (String)map.get("VER");
				StringUtil.appendSpace(sb, VER, hdr_lens[1]);
			} else {
				StringUtil.appendSpace(sb, "", hdr_lens[1]);
			}
			
		}catch(Exception e) {
			df.CommLogger("▶ makeAppVersion Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	/***************************************************************************
	 * getCloseOrderTime
	 * : 발주가능 시간, 금액 조회
	 * @param pCOM_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String getCloseOrderTime(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try { 
			begin();
			
			String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
			String INPUT_DT = "";
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.CALL_CLOSE_TM));
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());

			list = executeQuery(sql);
	
			if( list.size() < 0 ) {
				ret = "09";
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeCloseOrderTime(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selLimitRtnDateInfo : IQ_LIMIT_RTN_DATE_REQ
	 * : [반품등록] 한도반품 일자/한도 조회 - I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selLimitRtnDateInfo(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_LIMIT_RTN_DATE));
			///
			/// 조직코드
			/// 회사
			
			//이전일 구하기!
			SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
			Calendar cDate = Calendar.getInstance();								/* 달력 */
			cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
			cDate.add(Calendar.DATE, -1);											/* 전일계산 */
			String ys = SDF.format(cDate.getTime());								/* 발주전일 */
			
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */							
			
			df.CommLogger("EXE: " + sql.debug());
//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
//			df.CommLogger("▶ SQL:"+sql.get().toString());
			
			list = executeQuery(sql);
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) 
			{
				hm.put("INQ_TYPE", " ");
				hm.put("RTN_ST_DD", " ");
				hm.put("RTN_ED_DD", " ");
				hm.put("RTN_ABL_AMT", "0");
				hm.put("RTN_ABL_YN", " ");
				hm.put("RTN_ORG_CD", " ");
				
				ret = "09";
			}
			else 
			{
				map = (Map) list.get(0);
				String RTN_ABL_YN = (String) map.get("RTN_ABL_YN");
				df.CommLogger("************************ RTN_ABL_YN : " +RTN_ABL_YN);
				
				if(RTN_ABL_YN.equals("0")) {
					hm.put("INQ_TYPE", " ");
					hm.put("RTN_ST_DD", " ");
					hm.put("RTN_ED_DD", " ");
					hm.put("RTN_ABL_AMT", "0");
					hm.put("RTN_ABL_YN", " ");
					hm.put("RTN_ORG_CD", " ");
					
					ret = "10";
				}
			}

		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeRtnDateInfo(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selLimitRtnInfo : IQ_LIMIT_RTN_REQ
	 * : [반품등록] 한도반품 정보 요청 - I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selLimitRtnInfo(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_LIMIT_RTN_INFO));
			///
			/// 조직코드
			/// 회사
			
			//이전일 구하기!
			SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
			Calendar cDate = Calendar.getInstance();								/* 달력 */
			cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
			cDate.add(Calendar.DATE, -1);											/* 전일계산 */
			String ys = SDF.format(cDate.getTime());								/* 발주전일 */
			
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */			
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
							
			
			df.CommLogger("EXE: " + sql.debug());
//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
//			df.CommLogger("▶ SQL:"+sql.get().toString());
			
			list = executeQuery(sql);
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) 
			{
				hm.put("INQ_TYPE", " ");
				hm.put("GDS_NM", " ");
				hm.put("RTN_ENBL_QTY", " ");
				hm.put("REQ_QTY", "0");
				hm.put("ORG_AMT", "0");
				hm.put("AMT", "0");
				hm.put("GDS_CD", " ");
				hm.put("ITEM_CD", " ");
				hm.put("SUP_PRC", "0");
				hm.put("VAT", "0");
				hm.put("CONF_QTY", "0");
				hm.put("CONF_YN", " ");
				hm.put("CONF_DT", " ");
				hm.put("NSTCK_QTY", "0");
				hm.put("RTN_TP", " ");
				hm.put("RTN_TP_NM", " ");
				hm.put("DVY_CD", " ");
				hm.put("PTN_CD", " ");
				hm.put("VEN_CD", " ");
				hm.put("TAX_TP", " ");
				hm.put("TAX_RT", "0");
				hm.put("HDQ_SAL_PRC", "0");
				hm.put("TOT_AMT", "0");
				hm.put("TOT_QTY", "0");
				
				ret = "09";
			}

		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLimitRtnInfo(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selLimitRtnGdsInfo : IQ_RTN_GDS_REQ
	 * : [반품등록] 한도반품 상품 정보 요청 - I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selLimitRtnGdsInfo(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		List list = null;
		List list1 = null;
		Map map = new HashMap();
		Map map1 = new HashMap();
		int i = 0;
		int j = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			String PLU_CD = (String) hm.get("PLU_CD").toString().trim();
			
			if (PLU_CD.length() < 13) {
				sql1.put(findQuery(COMMBiz_PDA.PDA_SQL,	COMMBiz_PDA.SEL_PLU_INFO_CHK));
				sql1.setString(++j, PLU_CD);                         /* PLU코드 */
				sql1.setString(++j, PLU_CD);                         /* PLU코드 */
				sql1.setString(++j, pCOM_CD);                        /* 회사코드 */
				sql1.setString(++j, STORE_FIRST_CODE + pSTORE_CD);   /* 점포코드 */
				sql1.setString(++j, PLU_CD);                         /* PLU코드 */

				list1 = executeQuery(sql1);
				map1 = (Map) list1.get(0);
				PLU_CD = (String) map1.get("PLU_CD_N");
				df.CommLogger("************************ PLU_CD : " + PLU_CD);

				sql1.clearParameter();
				sql1.close();
			}
			
			String INPUT_DT = (String)hm.get("INPUT_DT").toString().trim();			
			String RET_VAL = getCloseRtnDate(pCOM_CD, pSTORE_CD, INPUT_DT, df);
			
			if (!RET_VAL.equals("N"))
			{
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_RTN_GDS_INFO));
				///
				/// 조직코드
				/// 회사
				sql.setString(++i, RET_VAL.trim());                                     /* 한도금액 */ 
				sql.setString(++i, INPUT_DT.trim());                                    /* 요청일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, INPUT_DT.trim());                                    /* 요청일자 */
				sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
				sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
				sql.setString(++i, PLU_CD);                                             /* PLU코드 */
								
				
				df.CommLogger("EXE: " + sql.debug());
	//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
	//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
	//			df.CommLogger("▶ SQL:"+sql.get().toString());
				
				list = executeQuery(sql);
				
				int total_cnt = list.size();
				hm.put("ROWS_COUNT", Integer.toString(total_cnt));
				
				df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
				
				if( list.size() <= 0 ) 
				{
					hm.put("INQ_TYPE", " ");
					hm.put("GDS_NM", " ");
					hm.put("RTN_ENBL_QTY", " ");
					hm.put("REQ_QTY", "0");
					hm.put("ORG_AMT", "0");
					hm.put("AMT", "0");
					hm.put("GDS_CD", " ");
					hm.put("ITEM_CD", " ");
					hm.put("SUP_PRC", "0");
					hm.put("VAT", "0");
					hm.put("CONF_QTY", "0");
					hm.put("CONF_YN", " ");
					hm.put("CONF_DT", " ");
					hm.put("NSTCK_QTY", "0");
					hm.put("RTN_TP", " ");
					hm.put("RTN_TP_NM", " ");
					hm.put("DVY_CD", " ");
					hm.put("PTN_CD", " ");
					hm.put("VEN_CD", " ");
					hm.put("TAX_TP", " ");
					hm.put("TAX_RT", "0");
					hm.put("HDQ_SAL_PRC", "0");
					hm.put("TOT_AMT", "0");
					hm.put("TOT_QTY", "0");
					
					ret = "09";  // 반품불가 상품
				}
			} else {
				hm.put("ROWS_COUNT", Integer.toString(0));
				ret = "11";  // 발주가능기간 아님
			}

		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			df.CommLogger("★ ************************************ ret: " + ret);
			dataMsg = ret + makeLimitRtnInfo(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selFirstRtnDateInfo : IQ_FIRST_RTN_DATE_REQ
	 * : [반품등록] 초도반품 일자/한도 조회 - I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selFirstRtnDateInfo(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_FIRST_RTN_DATE));
			///
			/// 조직코드
			/// 회사
			
			//이전일 구하기!
			SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
			Calendar cDate = Calendar.getInstance();								/* 달력 */
			cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
			cDate.add(Calendar.DATE, -1);											/* 전일계산 */
			String ys = SDF.format(cDate.getTime());								/* 발주전일 */
			
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
			
			df.CommLogger("EXE: " + sql.debug());
//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
//			df.CommLogger("▶ SQL:"+sql.get().toString());
			
			list = executeQuery(sql);
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) 
			{
				hm.put("INQ_TYPE", " ");
				hm.put("RTN_ST_DD", " ");
				hm.put("RTN_ED_DD", " ");
				hm.put("RTN_ABL_AMT", "0");
				hm.put("RTN_ABL_YN", " ");
				hm.put("RTN_ORG_CD", " ");
				
				ret = "09";
			}
			else 
			{
				map = (Map) list.get(0);
				String RTN_ABL_YN = (String) map.get("RTN_ABL_YN");
				df.CommLogger("************************ RTN_ABL_YN : " +RTN_ABL_YN);
				
				if(RTN_ABL_YN.equals("0")) {
					hm.put("INQ_TYPE", " ");
					hm.put("RTN_ST_DD", " ");
					hm.put("RTN_ED_DD", " ");
					hm.put("RTN_ABL_AMT", "0");
					hm.put("RTN_ABL_YN", " ");
					hm.put("RTN_ORG_CD", " ");
					
					ret = "10";
				}
			}

		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeRtnDateInfo(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selFirstRtnInfo : IQ_FIRST_RTN_REQ
	 * : [반품등록] 초도반품 정보 요청 - I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selFirstRtnInfo(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_FIRST_RTN_INFO));
			///
			/// 조직코드
			/// 회사
			
			//이전일 구하기!
			SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
			Calendar cDate = Calendar.getInstance();								/* 달력 */
			cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
			cDate.add(Calendar.DATE, -1);											/* 전일계산 */
			String ys = SDF.format(cDate.getTime());								/* 발주전일 */
			
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */			
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */							
			
			df.CommLogger("EXE: " + sql.debug());
//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
//			df.CommLogger("▶ SQL:"+sql.get().toString());
			
			list = executeQuery(sql);
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) 
			{
				hm.put("INQ_TYPE", " ");
				hm.put("GDS_NM", " ");
				hm.put("RTN_ENBL_QTY", " ");
				hm.put("REQ_QTY", "0");
				hm.put("ORG_AMT", "0");
				hm.put("AMT", "0");
				hm.put("GDS_CD", " ");
				hm.put("ITEM_CD", " ");
				hm.put("SUP_PRC", "0");
				hm.put("VAT", "0");
				hm.put("CONF_QTY", "0");
				hm.put("CONF_YN", " ");
				hm.put("CONF_DT", " ");
				hm.put("NSTCK_QTY", "0");
				hm.put("RTN_TP", " ");
				hm.put("RTN_TP_NM", " ");
				hm.put("DVY_CD", " ");
				hm.put("PTN_CD", " ");
				hm.put("VEN_CD", " ");
				hm.put("TAX_TP", " ");
				hm.put("TAX_RT", "0");
				hm.put("HDQ_SAL_PRC", "0");
				hm.put("TOT_AMT", "0");
				hm.put("TOT_QTY", "0");
				
				ret = "09";
			}

		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLimitRtnInfo(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selRecallRtnDateInfo : IQ_RECALL_RTN_DATE_REQ
	 * : [반품등록] 리콜반품 일자/한도 조회 - I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selRecallRtnDateInfo(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_RECALL_RTN_DATE));
			///
			/// 조직코드
			/// 회사
			
			//이전일 구하기!
			SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
			Calendar cDate = Calendar.getInstance();								/* 달력 */
			cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
			cDate.add(Calendar.DATE, -1);											/* 전일계산 */
			String ys = SDF.format(cDate.getTime());								/* 발주전일 */
			
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */							
			
			df.CommLogger("EXE: " + sql.debug());
//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
//			df.CommLogger("▶ SQL:"+sql.get().toString());
			
			list = executeQuery(sql);
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) 
			{
				hm.put("INQ_TYPE", " ");
				hm.put("RTN_ST_DD", " ");
				hm.put("RTN_ED_DD", " ");
				hm.put("RTN_ABL_AMT", "0");
				hm.put("RTN_ABL_YN", " ");
				hm.put("RTN_ORG_CD", " ");
				
				ret = "09";
			}

		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeRtnDateInfo(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * selRecallRtnInfo : IQ_RECALL_RTN_REQ
	 * : [반품등록] 리콜반품 정보 요청 - I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selRecallRtnInfo(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try {
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_RECALL_RTN_INFO));
			///
			/// 조직코드
			/// 회사
			
			//이전일 구하기!
			SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");				/* 날짜포멧 */
			Calendar cDate = Calendar.getInstance();								/* 달력 */
			cDate.setTime(SDF.parse((String)hm.get("INPUT_DT").toString().trim()));	/* 날짜 셋팅 */
			cDate.add(Calendar.DATE, -1);											/* 전일계산 */
			String ys = SDF.format(cDate.getTime());								/* 발주전일 */
			
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */			
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());				/* 조직코드 */
			sql.setString(++i, pCOM_CD.trim());										/* 회사코드 */
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */			
			sql.setString(++i, (String)hm.get("INPUT_DT").toString().trim());		/* 등록일자 */							
			
			df.CommLogger("EXE: " + sql.debug());
//			df.CommLogger("▶ pCOM_CD:"+pCOM_CD);
//			df.CommLogger("▶ pSTORE_CD:"+STORE_FIRST_CODE + pSTORE_CD);
//			df.CommLogger("▶ SQL:"+sql.get().toString());
			
			list = executeQuery(sql);
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			df.CommLogger("▶ ROWS_COUNT:"+Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) 
			{
				hm.put("INQ_TYPE", " ");
				hm.put("GDS_NM", " ");
				hm.put("RTN_ENBL_QTY", " ");
				hm.put("REQ_QTY", "0");
				hm.put("ORG_AMT", "0");
				hm.put("AMT", "0");
				hm.put("GDS_CD", " ");
				hm.put("ITEM_CD", " ");
				hm.put("SUP_PRC", "0");
				hm.put("VAT", "0");
				hm.put("CONF_QTY", "0");
				hm.put("CONF_YN", " ");
				hm.put("CONF_DT", " ");
				hm.put("NSTCK_QTY", "0");
				hm.put("RTN_TP", " ");
				hm.put("RTN_TP_NM", " ");
				hm.put("DVY_CD", " ");
				hm.put("PTN_CD", " ");
				hm.put("VEN_CD", " ");
				hm.put("TAX_TP", " ");
				hm.put("TAX_RT", "0");
				hm.put("HDQ_SAL_PRC", "0");
				hm.put("TOT_AMT", "0");
				hm.put("TOT_QTY", "0");
				
				ret = "09";
			}

		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeLimitRtnInfo(hm, list, df);
			//df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * setRtnMgrUpdate
	 * : [반품등록] 반품등록 정보(저장) -  I.G
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setRtnMgrUpdate(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		int nAMT = 0;
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		
		connect("CMGNS");
		try {
			begin();
		
			String ORG_CD = STORE_FIRST_CODE + pSTORE_CD.trim();
			String COM_CD = pCOM_CD.trim();
			String INPUT_DT = "";			

			int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			df.CommLogger("▶ ROWS_COUNT: " + Integer.toString(total_cnt) );

			for(idx = 0;idx < total_cnt;idx++ ) {
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.UPD_RTN_MGR));
				
				INPUT_DT = (String)hm.get("INPUT_DT" + Integer.toString(idx)).toString().trim();
				String ITEM_CD = (String)hm.get("ITEM_CD" + Integer.toString(idx)).toString().trim();				
				String RTN_TP = (String)hm.get("RTN_TP" + Integer.toString(idx)).toString().trim();
				String DVY_CD = (String)hm.get("DVY_CD" + Integer.toString(idx)).toString().trim();				
				String PTN_CD = (String)hm.get("PTN_CD" + Integer.toString(idx)).toString().trim();
				String VEN_CD = (String)hm.get("VEN_CD" + Integer.toString(idx)).toString().trim();				
				String TAX_TP = (String)hm.get("TAX_TP" + Integer.toString(idx)).toString().trim();
				int TAX_RT = Integer.parseInt((String)hm.get("TAX_RT" + Integer.toString(idx)).toString().trim());
				int HDQ_SAL_PRC = Integer.parseInt((String)hm.get("HDQ_SAL_PRC" + Integer.toString(idx)).toString().trim());
				int SUP_PRC = Integer.parseInt((String)hm.get("SUP_PRC" + Integer.toString(idx)).toString().trim());
				int REQ_QTY = Integer.parseInt((String)hm.get("REQ_QTY" + Integer.toString(idx)).toString().trim());
				int AMT = Integer.parseInt((String)hm.get("AMT" + Integer.toString(idx)).toString().trim());
				int VAT = Integer.parseInt((String)hm.get("VAT" + Integer.toString(idx)).toString().trim());				
				
				i=0;
//				df.CommLogger("▶ ORG_CD: " + ORG_CD );
//				df.CommLogger("▶ ITEM_CD: " + ITEM_CD );
//				df.CommLogger("▶ pCOM_CD: " + pCOM_CD );
//				df.CommLogger("▶ INPUT_DT: " + INPUT_DT );

				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, INPUT_DT);					
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, ITEM_CD );
				sql.setString( ++i, INPUT_DT);				
				sql.setString( ++i, RTN_TP);		
				sql.setString( ++i, DVY_CD );
				sql.setString( ++i, PTN_CD );
				sql.setString( ++i, VEN_CD );
				sql.setString( ++i, TAX_TP);				
				sql.setInt( ++i, TAX_RT);
				sql.setInt( ++i, HDQ_SAL_PRC );
				sql.setInt( ++i, SUP_PRC);
				sql.setInt( ++i, REQ_QTY);
				sql.setInt( ++i, REQ_QTY);				
				sql.setInt( ++i, AMT);
				//sql.setInt( ++i, VAT);
				sql.setString( ++i, ORG_CD);
				sql.setString( ++i, ORG_CD);
				
//				nAMT += nCount * GDS_COST;
				
				df.CommLogger("▶ SQL 1: " + sql.debug() );
				int rows = executeUpdate(sql);
				
				sql.close();
			}
	
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeStandPluUpdate(hm,idx);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	public Boolean getCloseOrderTime(String pCOM_CD, String pSTORE_CD, String INPUT_DT, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		Boolean ret = true;

		connect("CMGNS");
		try { 
			begin();

			String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.CALL_CLOSE_TM));
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			
			list = executeQuery(sql);
			
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				int NOW_TTM = Integer.parseInt((String)map.get("NOW_TTM"));
				String TODAY = (String)map.get("TODAY");
				int CLOSE_TM = Integer.parseInt((String)map.get("CLOSE_TM"));
				String AVB_LOAN_AMT = (String)map.get("AVB_LOAN_AMT");
				
//				df.CommLogger( "▶   NOW_TTM=====>"+ NOW_TTM);
//				df.CommLogger( "▶   TODAY=====>"+ TODAY);
//				df.CommLogger( "▶   CLOSE_TM=====>"+ CLOSE_TM);
//				df.CommLogger( "▶   AVB_LOAN_AMT=====>"+ AVB_LOAN_AMT);
				
				int iCompare = TODAY.compareTo(INPUT_DT);
				
				if( iCompare == 0 ){
					if(NOW_TTM>=CLOSE_TM)
					{
						ret = false;
					}
				}else if( iCompare > 0 ) {
					ret = false;
				}
				
//				if( TODAY.equals(INPUT_DT))
//				{
//					if(NOW_TTM>CLOSE_TM)
//					{
//						ret = false;
//					}
//				}
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = false;
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = false;
			throw e;
		}
		
		return ret;
	}
	
	public Boolean getCloseOrderTimeOld(String pCOM_CD, String pSTORE_CD, String INPUT_DT, String pPLU_CD, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		Boolean ret = true;

		connect("CMGNS");
		try { 
			begin();

			String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.CALL_CLOSE_TM_OLD));
			sql.setString(++i, pPLU_CD.toString().trim());
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			
			list = executeQuery(sql);
			
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				int NOW_TTM = Integer.parseInt((String)map.get("NOW_TTM"));
				String TODAY = (String)map.get("TODAY");
				int CLOSE_TM = Integer.parseInt((String)map.get("CLOSE_TM"));
				String AVB_LOAN_AMT = (String)map.get("AVB_LOAN_AMT");
				
//				df.CommLogger( "▶   NOW_TTM=====>"+ NOW_TTM);
//				df.CommLogger( "▶   TODAY=====>"+ TODAY);
//				df.CommLogger( "▶   CLOSE_TM=====>"+ CLOSE_TM);
//				df.CommLogger( "▶   AVB_LOAN_AMT=====>"+ AVB_LOAN_AMT);
				
				int iCompare = TODAY.compareTo(INPUT_DT);
				
				if( iCompare == 0 ){
					if(NOW_TTM>=CLOSE_TM)
					{
						ret = false;
					}
				}else if( iCompare > 0 ) {
					ret = false;
				}
				
//				if( TODAY.equals(INPUT_DT))
//				{
//					if(NOW_TTM>CLOSE_TM)
//					{
//						ret = false;
//					}
//				}
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = false;
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = false;
			throw e;
		}
		
		return ret;
	}
	
	public String getCloseOrderTime2(String pCOM_CD, String pSTORE_CD, String pPLU_CD, String INPUT_DT, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;		
		String ret = "00";

		connect("CMGNS");
		try { 
			begin();
			
			String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.CALL_CLOSE_TM2));
			sql.setString(++i, pPLU_CD.toString().trim());
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());			
			
			list = executeQuery(sql);
			
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				int NOW_TTM = Integer.parseInt((String)map.get("NOW_TTM"));
				String NOW_HH = ((String)map.get("NOW_TTM")).substring(0,2).trim();
				String TODAY = (String)map.get("TODAY");
				int CLOSE_TM = Integer.parseInt((String)map.get("CLOSE_TM"));
				String AVB_LOAN_AMT = (String)map.get("AVB_LOAN_AMT");
				String FF_YN =  (String)map.get("FF_YN");
				
				//df.CommLogger( "▶   NOW_TTM=====>"+ NOW_TTM);
				//df.CommLogger( "▶   TODAY=====>"+ TODAY);
				//df.CommLogger( "▶   CLOSE_TM=====>"+ CLOSE_TM);
				//df.CommLogger( "▶   AVB_LOAN_AMT=====>"+ AVB_LOAN_AMT);				
				
				int iCompare = TODAY.compareTo(INPUT_DT);
				
				if (NOW_HH.equals("10")){  // 10~11시 발주 불가!! I.G					
					ret = "11";
				} else {
					if( iCompare == 0 ){
						if(NOW_TTM>=CLOSE_TM){
							if(FF_YN.equals("Y")){
								ret = "13";
							} else {
								ret = "14";
							}
						}
					}else if( iCompare > 0 ) {
						ret = "09";
					}				
				}
//				if( TODAY.equals(INPUT_DT))
//				{
//					if(NOW_TTM>CLOSE_TM)
//					{
//						ret = false;
//					}
//				}
			}
			//df.CommLogger( "********************* ret : "+ret);
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "09";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "09";
			throw e;
		}
		
		return ret;
	}
	
	public String getCloseOrderTime3(String pCOM_CD, String pSTORE_CD, String INPUT_DT, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String ret = "00";

		connect("CMGNS");
		try { 
			begin();

			String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.CALL_FF_CLOSE_TM));
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			
			list = executeQuery(sql);
			
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				int NOW_TTM = Integer.parseInt((String)map.get("NOW_TTM"));
				String TODAY = (String)map.get("TODAY");
				int FF_CLOSE_TM = Integer.parseInt((String)map.get("FF_CLOSE_TM"));
				int AL_CLOSE_TM = Integer.parseInt((String)map.get("AL_CLOSE_TM"));
				
//				df.CommLogger( "▶   NOW_TTM=====>"+ NOW_TTM);
//				df.CommLogger( "▶   TODAY=====>"+ TODAY);
//				df.CommLogger( "▶   CLOSE_TM=====>"+ CLOSE_TM);
				
				int iCompare = TODAY.compareTo(INPUT_DT);
				
				if( iCompare == 0 ){
					if (NOW_TTM>=FF_CLOSE_TM && NOW_TTM<AL_CLOSE_TM)
					{
						ret = "01";
					}
					else if (NOW_TTM>=AL_CLOSE_TM)
					{
						ret = "09";
					}
				}else if( iCompare > 0 ) {
					ret = "09";
				}
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "09";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "09";
			throw e;
		}
		end();
		return ret;
	}
	
	public String getCloseOrderTime4(String pCOM_CD, String pSTORE_CD, String pPLU_CD, String pINPUT_DT, Integer pINPUT_COUNT, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;		
		String ret = "00";

		connect("CMGNS");
		try { 
			begin();
			String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.CALL_CLOSE_TM3));

			sql.setString(++i, pPLU_CD.toString().trim());
			sql.setString(++i, pINPUT_DT.toString().trim());
			sql.setString(++i, pINPUT_COUNT.toString().trim());			
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());			

			list = executeQuery(sql);

			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				int NOW_TTM = Integer.parseInt((String)map.get("NOW_TTM"));
				String NOW_HH = ((String)map.get("NOW_TTM")).substring(0,2).trim();
				String TODAY = (String)map.get("TODAY");
				int CLOSE_TM = Integer.parseInt((String)map.get("CLOSE_TM"));
				String AVB_LOAN_AMT = (String)map.get("AVB_LOAN_AMT");
				String FF_YN =  (String)map.get("FF_YN");
				String ORD_CNT = (String)map.get("ORD_CNT");
				//df.CommLogger( "▶   NOW_TTM=====>"+ NOW_TTM);
				//df.CommLogger( "▶   TODAY=====>"+ TODAY);
				//df.CommLogger( "▶   CLOSE_TM=====>"+ CLOSE_TM);
				//df.CommLogger( "▶   AVB_LOAN_AMT=====>"+ AVB_LOAN_AMT);				
				df.CommLogger( "▶   ORD_CNT ========================================>"+ ORD_CNT);
				
				int iCompare = TODAY.compareTo(pINPUT_DT);

				if (NOW_HH.equals("10")){  // 10~11시 발주 불가!! I.G
					ret = "11";
				} else {
					if( iCompare == 0 ){
						if(NOW_TTM>=CLOSE_TM){
							if(FF_YN.equals("Y")){
								ret = "13";
							} else {
								ret = "14";
							}
						}
					}else if( iCompare > 0 ) {
						ret = "09";
					}
				}
				
				if(!ORD_CNT.equals("0")){
					ret = "09";
					df.CommLogger( "▶   ERROR  ========================================================================>");
					df.CommLogger( "▶   INPUT_DT  =============================================>"+ pINPUT_DT);
					df.CommLogger( "▶   STORE_CD =============================================>"+ pSTORE_CD);
					df.CommLogger( "▶   PLU_CD    =============================================>"+ pPLU_CD);
				}
//				if( TODAY.equals(INPUT_DT))
//				{
//					if(NOW_TTM>CLOSE_TM)
//					{
//						ret = false;
//					}
//				}
			}
			//df.CommLogger( "********************* ret : "+ret);
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "09";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "09";
			throw e;
		}
		end();
		return ret;
	}
	
	public String getNewOrderStore(String pCOM_CD, String pSTORE_CD, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;		
		String ret = "N";

		connect("CMGNS");
		try {
			begin();
			
			String ORG_CD = STORE_FIRST_CODE + pSTORE_CD;
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.CALL_NEW_ORDER_STORE));	
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			
			list = executeQuery(sql);
			
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				int STR_CNT = Integer.parseInt((String)map.get("STR_CNT"));

				if (STR_CNT == 0){
					ret = "N";
				} else {
					ret = "Y";
				}
				df.CommLogger( "▶   STORE_CD =============================================>"+ pSTORE_CD);
				df.CommLogger( "▶   NEW_ORDER_YN ========================================>"+ ret);
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "N";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "N";
			throw e;
		}
		end();
		return ret;
	}
	
	public String getCloseRtnDate(String pCOM_CD, String pSTORE_CD, String pINPUT_DT, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;		
		String ret = "0";

		connect("CMGNS");
		try { 
			begin();
			
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.SEL_LIMIT_RTN_DATE));
			sql.setString(++i, pINPUT_DT.toString().trim());                  /* 등록일자 */
			sql.setString(++i, pINPUT_DT.toString().trim());                  /* 등록일자 */
			sql.setString(++i, pCOM_CD.trim());                               /* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim().trim());   /* 조직코드 */
			sql.setString(++i, pCOM_CD.trim());                               /* 회사코드 */
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim().trim());   /* 조직코드 */
			
			list = executeQuery(sql);
			
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				//int RTN_ST_DD = Integer.parseInt((String)map.get("RTN_ST_DD"));
				//int RTN_ED_DD = Integer.parseInt((String)map.get("RTN_ED_DD"));
				String RTN_ABL_AMT = (String)map.get("RTN_ABL_AMT");
				String RTN_ABL_YN  = (String)map.get("RTN_ABL_YN");

				df.CommLogger( "▶   RTN_ABL_AMT=====>"+ RTN_ABL_AMT);
				df.CommLogger( "▶   RTN_ABL_YN=====>"+ RTN_ABL_YN);
				
				if (RTN_ABL_YN.equals("0")){  // 반품등록기간					
					ret = "N";         // 반품불가
				} else {
					ret = RTN_ABL_AMT; // 반품가능금액
				}
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "N";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "N";
			throw e;
		}
		
		return ret;
	}
	
	/***************************************************************************
	 * makeCloseOrderTime : 발주가능 시간, 금액 조회
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeCloseOrderTime(HashMap hm, List list, COMMLog df) throws Exception {
		Map map = new HashMap();
		StringBuffer sb = new StringBuffer();
		int hdr_lens[] = { 2, 10 };
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   	// 89 : IQ_CLOSE_ORDER_TIME_REQ
				"RESULT_CD",	// 발주가능 시간
		};
		
		try {
			
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);

			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				int NOW_TTM = Integer.parseInt((String)map.get("NOW_TTM"));
				String TODAY = (String)map.get("TODAY");
				int CLOSE_TM = Integer.parseInt((String)map.get("CLOSE_TM"));
				String AVB_LOAN_AMT = (String)map.get("AVB_LOAN_AMT");
				String INPUT_DT = (String)hm.get("INPUT_DT");
					
				if( TODAY.equals(INPUT_DT))
				{
					if(NOW_TTM>CLOSE_TM)
					{
						StringUtil.appendSpace(sb, "99", hdr_lens[1]);
					} 
					else
					{
						StringUtil.appendSpace(sb, "00", hdr_lens[1]);
					}
				} else {
					StringUtil.appendSpace(sb, "00", hdr_lens[1]);
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				StringUtil.appendSpace(sb, "88", hdr_lens[1]);
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeCloseOrderTime : " + e.getMessage());
			throw e;
		}
		

		return sb.toString();
	}
	
	/***************************************************************************
	 * makeRtnDateInfo : [반품등록] 점포 반품일자/한도 조회
	 * IQ_RTN_DATE_REQ
	 * @param hm
	 * @param list
	 * @return 전송메세지
    ***************************************************************************/
	private String makeRtnDateInfo(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2,
				2,
				2,
				10,
				2,
                10
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "51": 점포 반품일자/한도 조회
				"RTN_ST_DD", 		    //
				"RTN_ED_DD",            //
				"RTN_ABL_AMT",          //
				"RTN_ABL_YN",           //
				"RTN_ORG_CD"            //
		};
		
		try
		{
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						//StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);						

//						df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeRtnDateInfo Error : " + e);
			throw e;
		}
 
		return sb.toString();
	}
	
	/***************************************************************************
	 * makeLimitRtnInfo : [반품등록] 한도반품 정보 응답
	 * IQ_LIMIT_RTN_RSP
	 * @param hm
	 * @param list
	 * @return 전송메세지
	***************************************************************************/
	private String makeLimitRtnInfo(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 
				2,
				50,
				10,
				10,
				10,
				10,
                30,
                30,
                10,
                10,
                10,
                2,
                8,
                10,
                4,
                30,
                20,
                20,
                20,
                1,
                10,
                10,
                10,
                10
        };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "52": 한도반품 정보
				"GDS_NM", 			    //
				"RTN_ENBL_QTY",         //
				"REQ_QTY",              //
				"ORG_AMT",              //
				"AMT",                  //
				"PLU_CD",               //
				"ITEM_CD",              //
				"SUP_PRC",              //
				"VAT",                  //
				"CONF_QTY",             //				
				"CONF_YN",              //
				"CONF_DT",              //
				"NSTCK_QTY",            //
				"RTN_TP",               //
				"RTN_TP_NM",            //
				"DVY_CD",               //
				"PTN_CD",               //
				"VEN_CD",               //
				"TAX_TP",               //
				"TAX_RT",               //
				"HDQ_SAL_PRC",          //
				"TOT_AMT",              //
				"TOT_QTY"               //
		};
		
		try
		{
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT").toString().trim(), 10);
			
			if( nRowCount > 0 ) {
				for(int i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
						//StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);						

//						df.CommLogger("▶"+hdr_StrHeaders[nCol]+" : " + (String)map.get(hdr_StrHeaders[nCol].toString()));
						StringUtil.appendSpace(sb, (String)map.get(hdr_StrHeaders[nCol].toString()), hdr_lens[nCol]);
					}
				}
			}else {
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				for(int nCol = 1;nCol < hdr_StrHeaders.length;nCol++ ) {
					StringUtil.appendSpace(sb, "", hdr_lens[nCol]);
				}
			}
		}catch(Exception e) {
			df.CommLogger("▶ makeLimitRtnInfo Error : " + e);
			throw e;
		}
 
		return sb.toString();
	}
	
	/***************************************************************************
	 * setPLU_TEMP : 점포 상품 바코드 확인을 위한 임시 사용
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	String setPLU_TEMP(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		connect("CMGNS");
		try {
			begin();
			int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			begin();
//			df.CommLogger( "▶ ROWS:"+(String)hm.get("ROWS_COUNT").toString().trim());
			// 전표 상세 저장
			for(idx = 0;idx < total_cnt;idx++ ) {
				sql.put(findQuery(COMMBiz_PDA.PDA_SQL,  COMMBiz_PDA.TB_PLU_TEMP));

				i=0;

				sql.setString( ++i, (String)hm.get("PLU_CD" + Integer.toString(idx)).toString().trim() );
				sql.setInt   ( ++i, Integer.parseInt((String)hm.get("COUNT" + Integer.toString(idx)).toString().trim()) );
				
//				df.CommLogger( "▶ SQL:"+sql.debug());
				int rows = executeUpdate(sql);
				sql.close();
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			//dataMsg = ret + makePLU_TEMP(hm,idx);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * setSystemDate
	 * : 시스템시간 동기화(DB시간)
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setSystemDate(HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		connect("CMGNS");
		try { 
			begin();
			
//			df.CommLogger("▶ System Date :"+(String)hm.get("SYS_DATE").toString().trim());
			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.GET_SYSTEM_DATE));

			df.CommLogger( "▶ SQL:"+sql.debug());
			list = executeQuery(sql);
			
			if( list.size() < 0 ) {
				ret = "09";
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeSystemDate(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	/***************************************************************************
	 * makeSystemDate : 시스템시간 동기화 요청 응답
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeSystemDate(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 14 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "11": 
				"SYS_DATE" 		        // 시스템시간
		};
		
		try
		{
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				String SYS_DATE = (String)map.get("SYS_DATE");
				StringUtil.appendSpace(sb, SYS_DATE, hdr_lens[1]);
			} else {
				StringUtil.appendSpace(sb, "", hdr_lens[1]);
			}
			
		}catch(Exception e) {
			df.CommLogger("▶ makeSystemDate Error : " + e);
			throw e;
		}

		return sb.toString();
	}
	
	
	
	/***************************************************************************
	 * setMaxOrderAMT//leeseungho
	 * : 최대발주금액
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setMaxOrderAmt(HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
//		connect("CMGNS");
//		try { 
//			begin();
//			
////			df.CommLogger("▶ System Date :"+(String)hm.get("SYS_DATE").toString().trim());
//			sql.put(findQuery(COMMBiz_PDA.PDA_SQL, COMMBiz_PDA.GET_SYSTEM_DATE));
//
//			df.CommLogger( "▶ SQL:"+sql.debug());
//			list = executeQuery(sql);
//			
//			if( list.size() < 0 ) {
//				ret = "09";
//			}
//			
//		}catch(SQLException e) {
//			rollback();
//			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
//			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
//			ret = "10";
//		}catch(Exception e) {
//			rollback();
//			df.CommLogger("▶ SEL Error : " + e);
//			ret = "20";
//			throw e;
//		}finally {
//			end();
			dataMsg = ret + makeMaxOrderAmt(hm, list, df);
			df.CommLogger("neo0531[" + dataMsg +"]");
//		}
		
		return dataMsg;
	}
	

	
	/***************************************************************************
	 * makeSystemDate : 최대 발주 가능 금액 요청 응답
	 * 
	 * @param hm

	 * @return 전송메세지
	 */
	private String makeMaxOrderAmt(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int hdr_lens[] = { 2, 10 };
		
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// "97": 
				"MAX_ORDER_AMT" 		// 시스템시간
		};
		
		try
		{
			StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);				
				String MAX_ORDER_AMT = "-50000";
				StringUtil.appendSpace(sb, MAX_ORDER_AMT, hdr_lens[1]);
			
		}catch(Exception e) {
			df.CommLogger("▶ makeSystemDate Error : " + e);
			throw e;
		}

		return sb.toString();
	}
		

	
	
	/***************************************************************************
	 * selIncomInfo98 입고검수 정보 
	 * 
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selIncomInfo98(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();
			
			
			sql.put(findQuery("pda-sql", "SEL_INCOM_CHK98"));
			sql.setString(++i, (String)hm.get("SLIP_NO").toString().trim());
			sql.setString(++i, (String)hm.get("SLIP_NO").toString().trim());
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			
			list = executeQuery(sql);
			int incomchk = list.size();
			if(incomchk >= 1) //OLD 	if(incomchk == 1)
			{
				//df.CommLogger("OK");
				hm.put("INQ_TYPE"," "); 
				hm.put("SLIP_SEQ"," ");
				hm.put("PLU_CD"," ");
				hm.put("PLU_NM"," ");
				hm.put("WARIN_QTY"," ");
				hm.put("PLU_INV"," ");
				hm.put("STR_SAL_PRC"," ");
				ret = "10";
				end();
				dataMsg = ret + makeIncomInfo98(hm, list, df);
				return dataMsg;
			}
			else
			{
				i = 0;
				sql.clearParameter();
				sql.close();
				
			}
			
//			df.CommLogger("▶ SLIP_NO : " + (String)hm.get("SLIP_NO"));
//			df.CommLogger("▶ WARIN_DT : " + (String)hm.get("WARIN_DT"));
			sql.put(findQuery("pda-sql", "SEL_INCOM_INFO98"));//SEL_INCOM_INFO
			sql.setString(++i, (String)hm.get("SLIP_NO").toString().trim());
			sql.setString(++i, (String)hm.get("SLIP_NO").toString().trim());
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			//sql.setString(++i, (String)hm.get("WARIN_DT"));

//			df.CommLogger("▶ SLIP_NO : " + (String)hm.get("SLIP_NO"));
//			df.CommLogger("▶ COM_CD : " + pCOM_CD);
//			df.CommLogger("▶ STORE_CD : " + STORE_FIRST_CODE + pSTORE_CD);
//			
//			df.CommLogger("▶ SQL : " + sql.debug());
			
			list = executeQuery(sql);
			
//			df.CommLogger("▶ list size : " + Integer.toString(list.size()));
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) {
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeIncomInfo98(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	
	/***************************************************************************
	 * makeIncomInfo98 : 입고검수 전표에 해당하는 상품정보 응답
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeIncomInfo98(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int iq_info_header_lens[] = {2, 10, 30, 30, 30 };
		int hdr_lens[] = { 2, 10, 30, 50, 10, 10, 10, 30, 10 };		//int hdr_lens[] = { 2, 10, 30, 50, 10, 10, 10, 30, 10, 30, 12 };
		String iq_info_headers[] = {
				"INQ_TYPE",
				"INQ_COUNT",
                "INQ_COLUME1",
                "INQ_COLUME2",
                "INQ_COLUME3"
		};
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// 
				"SLIP_SEQ",				// ROW Number
				"PLU_CD",				// 상품 코드
				"PLU_NM",				// 상품 이름
				"WARIN_QTY",			// 입고수량
				"PLU_INV",				// 상품 재고수량
				"STR_SAL_PRC",			// 점포매가
				"SLIP_NO",				// 전표번호
				"OUT_QTY",				// 출고 수량
//				"PICE_PLU_CD",			// 낱개PLU
//				"BOX_STORD_ACQ"			// BOX점발주입수								
		};
		
		try
		{
			StringUtil.appendSpace(sb, (String)hm.get(iq_info_headers[0].toString()), iq_info_header_lens[0]);
			
//			df.CommLogger("▶ ROWS_COUNT : " + (String)hm.get("ROWS_COUNT").toString().trim());
			
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT"), iq_info_header_lens[1]);
			
			int i = 0;
			if( nRowCount > 0 ) {
				for(i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					
					if(i==0)
					{

						StringUtil.appendSpace(sb, (String)map.get("WM_CENT_NM"), iq_info_header_lens[2]);
						StringUtil.appendSpace(sb, (String)map.get("DVY_ROOT_TP_NM"), iq_info_header_lens[3]);
						StringUtil.appendSpace(sb, (String)map.get("WM_CONF_TP")+"|"+(String)map.get("WARIN_DT"), iq_info_header_lens[4]);
					}
					
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					StringUtil.appendSpace(sb, (String)map.get("SLIP_SEQ"), hdr_lens[1]);
					StringUtil.appendSpace(sb, (String)map.get("PLU_CD"), hdr_lens[2]);
					StringUtil.appendSpace(sb, (String)map.get("GDS_NM"), hdr_lens[3]);
					StringUtil.appendSpace(sb, (String)map.get("WARIN_QTY"), hdr_lens[4]);
					StringUtil.appendSpace(sb, (String)map.get("NSTCK_QTY"), hdr_lens[5]);
					StringUtil.appendSpace(sb, (String)map.get("STR_SAL_PRC"), hdr_lens[6]);
					StringUtil.appendSpace(sb, (String)map.get("SLIP_NO"), hdr_lens[7]);
					StringUtil.appendSpace(sb, (String)map.get("OUT_QTY"), hdr_lens[8]);
//					StringUtil.appendSpace(sb, (String)map.get("PICE_PLU_CD"), hdr_lens[9]);
//					StringUtil.appendSpace(sb, (String)map.get("BOX_STORD_ACQ"), hdr_lens[10]);
				}
			}else {
				//df.CommLogger("▶ hdr_StrHeaders[0] is : " + (String)hm.get(hdr_StrHeaders[0].toString()) );
				if(i==0)
				{
					StringUtil.appendSpace(sb, "", iq_info_header_lens[1]);
					StringUtil.appendSpace(sb, "", iq_info_header_lens[2]);
					StringUtil.appendSpace(sb, "", iq_info_header_lens[3]);
				}
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				StringUtil.appendSpace(sb, Integer.toString(0), hdr_lens[1]);
				StringUtil.appendSpace(sb, "", hdr_lens[2]);				
				StringUtil.appendSpace(sb, "", hdr_lens[3]);
				StringUtil.appendSpace(sb, "", hdr_lens[4]);
				StringUtil.appendSpace(sb, "", hdr_lens[5]);
				StringUtil.appendSpace(sb, "", hdr_lens[6]);
				StringUtil.appendSpace(sb, "", hdr_lens[7]);
				StringUtil.appendSpace(sb, "", hdr_lens[8]);
//				StringUtil.appendSpace(sb, "", hdr_lens[9]);
//				StringUtil.appendSpace(sb, "", hdr_lens[10]);
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeIncomInfo : " + e.getMessage());
			throw e;
		}

		return sb.toString();
	}

	/***************************************************************************
	 * setIncomUpdate 입고상품 정보 수정 요청
	 * 
	 * @param tranYmd
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String setIncomUpdate99(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		int idx = 0;
		connect("CMGNS");
		try {
			begin();
			int total_cnt = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			begin();
			df.CommLogger( "▶ ROWS:"+(String)hm.get("ROWS_COUNT").toString().trim());
			// 전표 상세 저장
			for(idx = 0;idx < total_cnt;idx++ ) {
				sql.put(findQuery("pda-sql",  "UPD_INCOM_DETAIL"));
				
//				df.CommLogger( "▶ [1]:"+(String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
//				df.CommLogger( "▶ [2]:"+(String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim());
//				df.CommLogger( "▶ [3]:"+STORE_FIRST_CODE + pSTORE_CD);
//				df.CommLogger( "▶ [4]:"+pCOM_CD);
//				df.CommLogger( "▶ [5]:"+(String)hm.get("SLIP_NO" + Integer.toString(idx)).toString().trim());
//				df.CommLogger( "▶ [6]:"+(String)hm.get("SLIP_SEQ" + Integer.toString(idx)).toString().trim());
				
				i=0;
				sql.setInt   ( ++i, Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim()) );
				sql.setInt   ( ++i, Integer.parseInt((String)hm.get("INPUT_COUNT" + Integer.toString(idx)).toString().trim()) );
				sql.setString( ++i, STORE_FIRST_CODE + pSTORE_CD);
				sql.setString( ++i, pCOM_CD);
				sql.setString( ++i, (String)hm.get("SLIP_NO" + Integer.toString(idx)).toString().trim() );
				sql.setString( ++i, (String)hm.get("SLIP_SEQ" + Integer.toString(idx)).toString().trim() );
				
				df.CommLogger( "▶ [TB_INCOM_DETAIL_UPDATE] SQL:"+sql.debug());
				int rows = executeUpdate(sql);
				sql.close();
			}
			// 전표 헤더 저장
			sql.put(findQuery("pda-sql",  "UPD_INCOM_MASTER99"));
			i=0;
//			df.CommLogger( "▶ [1]:"+pCOM_CD);
//			df.CommLogger( "▶ [2]:"+(String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim());
			sql.setString( ++i, STORE_FIRST_CODE + pSTORE_CD);
			sql.setString( ++i, pCOM_CD);
			sql.setString( ++i, (String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim() );
			df.CommLogger( "▶[TB_INCOM_MASTER_UPDATE] SQL:"+sql.debug());
			int rows2 = executeUpdate(sql);
			sql.close();
			// 헤더 저장 후 실행 ( 현재고 처리)
//			sql.put(findQuery("pda-sql",  "UPD_INCOM_INV99"));
			i=0;
//			df.CommLogger( "▶ [1]:"+(String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim());
//			df.CommLogger( "▶ [2]:"+pCOM_CD);
//			df.CommLogger( "▶ [3]:"+(String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim());
//			df.CommLogger( "▶ [4]:"+STORE_FIRST_CODE + pSTORE_CD);
//			sql.setString( ++i, (String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim() );
//			sql.setString( ++i, pCOM_CD);
//			sql.setString( ++i, (String)hm.get("SLIP_NO" + Integer.toString(0)).toString().trim() );
//			sql.setString( ++i, STORE_FIRST_CODE + pSTORE_CD);
//			df.CommLogger( "▶ [CALL_PR_ST_SLIP_CONF] SQL:"+sql.debug());
//			int rows3 = executeUpdate(sql);
//			sql.close();
			
		}catch(SQLException e) {
			df.CommLogger( "▶SQLException  SQL:"+sql.debug());
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeIncomUpdate99(hm,idx);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}	

	
	/***************************************************************************
	 * makeIncomInfoA0 : plu 에 해당하는 낱개 정보 
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeIncomInfoA0(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();

		int hdr_lens[] = { 2, 30, 12 };

		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// 
				"PICE_PLU_CD",			// 낱개PLU
				"BOX_STORD_ACQ"			// BOX점발주입수
		};
		
		try
		{
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());					
			int i = 0;
			if( nRowCount > 0 ) {
				map = (Map)list.get(i);								
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				StringUtil.appendSpace(sb, (String)map.get("PICE_PLU_CD"), hdr_lens[1]);
				StringUtil.appendSpace(sb, (String)map.get("BOX_STORD_ACQ"), hdr_lens[2]);
			}else {				
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);			
				StringUtil.appendSpace(sb, "", hdr_lens[1]);				
				StringUtil.appendSpace(sb, "", hdr_lens[2]);
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeIncomInfo : " + e.getMessage());
			throw e;
		}

		return sb.toString();
	}	
	
	/***************************************************************************
	 * makeScanPluUpdateSendData [점포발주]
	 * : 입고상품 정보 수정 응답
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeIncomUpdate99(HashMap hm, int idx) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 30, 10, 10 };
		String strHeaders[] = {
				"INQ_TYPE",   	// "30": Search Product(상품 조회)
				"SLIP_NO",		// 발주번호
				"ROW_COUNT",	// 자료처리건수
				"RESULT_CD "	// 결과코드
		};

		StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE" + Integer.toString(0)), nlens[0]);
		StringUtil.appendSpace(sb, (String)hm.get("SLIP_NO" + Integer.toString(0)), nlens[1]);
		StringUtil.appendSpace(sb, Integer.toString(idx), nlens[2]);
		StringUtil.appendSpace(sb, "00", nlens[3]);

		return sb.toString();
	}

	/***************************************************************************
	 * selIncomInfoA0  입고 검수 점포 코드와 PLU 로 낱개 PLU 와 입수 수량 리턴 //leeseungho 
	 * 
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selIncomInfoA0(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();
				
			sql.put(findQuery("pda-sql", "SEL_INCOM_INFOA0"));//SEL_INCOM_INFO
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());

			df.CommLogger("▶ SQL : " + sql.debug());
			
			list = executeQuery(sql);
			
//			df.CommLogger("▶ list size : " + Integer.toString(list.size()));
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) {
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeIncomInfoA0(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
		
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/***************************************************************************
	 * selExpiryDateInfoA1 유통기한 정보 
	 * 
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selExpiryDateInfoA1(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		List list2 = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();
						
			sql.put(findQuery("pda-sql", "SEL_GDS_INFOA1"));
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());
			df.CommLogger("neo0531_1"+sql.debug());
			list = executeQuery(sql);
			int incomchk = list.size();
			if(incomchk != 1) 
			{
				//df.CommLogger("OK");
				hm.put("GDS_NM"," "); 
				hm.put("STR_ORD_ENBL_YN"," ");
				hm.put("ORD_ACQ_QTY"," ");
				hm.put("NSTCK_QTY"," ");
				hm.put("RTN_TP"," ");
				hm.put("ITEM_CD"," ");	
				ret = "09";
				end();
				list.clear();
				hm.put("ROWS_COUNT", "0");
				dataMsg = ret + makeExpiryDateInfoA1(hm, list, df);
				return dataMsg;
			}
			else
			{
				map = (Map)list.get(0);
				hm.put("GDS_NM",(String)map.get("GDS_NM")); 
				hm.put("STR_ORD_ENBL_YN",(String)map.get("STR_ORD_ENBL_YN"));
				hm.put("ORD_ACQ_QTY",(String)map.get("ORD_ACQ_QTY"));
				hm.put("NSTCK_QTY",(String)map.get("NSTCK_QTY"));
				hm.put("RTN_TP",(String)map.get("RTN_TP"));
				hm.put("ITEM_CD",(String)map.get("ITEM_CD"));	
				i = 0;
				sql.clearParameter();
				sql.close();
				
			}

		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeExpiryDateInfoA1(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
/*
 		SqlWrapper sql = new SqlWrapper();
		List list = null;
		List list2 = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();
						
			sql.put(findQuery("pda-sql", "SEL_GDS_INFOA1"));
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());
			df.CommLogger("neo0531_1"+sql.debug());
			list = executeQuery(sql);
			int incomchk = list.size();
			if(incomchk != 1) 
			{
				//df.CommLogger("OK");
				hm.put("GDS_NM"," "); 
				hm.put("STR_ORD_ENBL_YN"," ");
				hm.put("ORD_ACQ_QTY"," ");
				hm.put("NSTCK_QTY"," ");
				hm.put("RTN_TP"," ");				
				ret = "10";
				end();
				list.clear();
				hm.put("ROWS_COUNT", "0");
				dataMsg = ret + makeExpiryDateInfoA1(hm, list, df);
				return dataMsg;
			}
			else
			{
				map = (Map)list.get(0);
				hm.put("GDS_NM",(String)map.get("GDS_NM")); 
				hm.put("STR_ORD_ENBL_YN",(String)map.get("STR_ORD_ENBL_YN"));
				hm.put("ORD_ACQ_QTY",(String)map.get("ORD_ACQ_QTY"));
				hm.put("NSTCK_QTY",(String)map.get("NSTCK_QTY"));
				hm.put("RTN_TP",(String)map.get("RTN_TP"));							
				i = 0;
				sql.clearParameter();
				sql.close();
				
			}
			sql.put(findQuery("pda-sql", "SEL_DUE_DATE_INFOA1"));
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			sql.setString(++i, (String)hm.get("PLU_CD").toString().trim());
			df.CommLogger("neo0531_2_"+sql.debug());
			list2 = executeQuery(sql);
						
			int total_cnt = list2.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			if( list2.size() <= 0 ) {
				df.CommLogger("neo0531_3_There is no due date");//ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeExpiryDateInfoA1(hm, list2, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
		*/		

	
	/***************************************************************************
	 * makeExpiryDateInfoA1 : 유통기한관리 상품정보 응답
	 * 	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeExpiryDateInfoA1(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int iq_info_header_lens[] = {2, 100, 10, 12, 19, 10, 30 };
	
		String iq_info_headers[] = {
				"INQ_TYPE",
				"GDS_NM",
                "STR_ORD_ENBL_YN",
                "ORD_ACQ_QTY",
                "NSTCK_QTY",
                "RTN_TP",
                "ITEM_CD"
		};
		
		try
		{
			logger.info("▶ INQ_TYPE " + (String)hm.get("INQ_TYPE"));
			logger.info("▶  GDS_NM" + (String)hm.get("GDS_NM"));
			logger.info("▶  STR_ORD_ENBL_YN" + (String)hm.get("STR_ORD_ENBL_YN"));
			logger.info("▶  ORD_ACQ_QTY" + (String)hm.get("ORD_ACQ_QTY"));
			logger.info("▶  NSTCK_QTY" + (String)hm.get("NSTCK_QTY"));
			logger.info("▶  RTN_TP" + (String)hm.get("RTN_TP"));
			logger.info("▶  ITEM_CD" + (String)hm.get("ITEM_CD"));
			
			StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE"), iq_info_header_lens[0]);			
			StringUtil.appendSpace(sb, (String)hm.get("GDS_NM"), iq_info_header_lens[1]);
			StringUtil.appendSpace(sb, (String)hm.get("STR_ORD_ENBL_YN"), iq_info_header_lens[2]);
			StringUtil.appendSpace(sb, (String)hm.get("ORD_ACQ_QTY"), iq_info_header_lens[3]);
			StringUtil.appendSpace(sb, (String)hm.get("NSTCK_QTY"), iq_info_header_lens[4]);
			StringUtil.appendSpace(sb, (String)hm.get("RTN_TP"), iq_info_header_lens[5]);			
			StringUtil.appendSpace(sb, (String)hm.get("ITEM_CD"), iq_info_header_lens[6]);
		}catch(Exception e) {
			logger.info("▶ [ERROR] makeIncomInfo : " + e.getMessage());
			throw e;
		}

		return sb.toString();
	}	
/*
 * 
 		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int iq_info_header_lens[] = {2, 100, 10, 12, 19, 10, 3 };
		int hdr_lens[] = { 3, 30, 8, 1  };		
		String iq_info_headers[] = {
				"INQ_TYPE",
				"GDS_NM",
                "STR_ORD_ENBL_YN",
                "ORD_ACQ_QTY",
                "NSTCK_QTY",
                "RTN_TP",
				"CNT",					//total count
		};
		String hdr_StrHeaders[] = {	
				"DATE_SEQ",				// ROW Number
				"PLU_CD",				// 상품 코드
				"DIS_LIM_DT",			// 유통기한
				"DEL_YN"				// 삭제여부								
		};		
		try
		{
			StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE"), iq_info_header_lens[0]);			
			StringUtil.appendSpace(sb, (String)hm.get("GDS_NM"), iq_info_header_lens[1]);
			StringUtil.appendSpace(sb, (String)hm.get("STR_ORD_ENBL_YN"), iq_info_header_lens[2]);
			StringUtil.appendSpace(sb, (String)hm.get("ORD_ACQ_QTY"), iq_info_header_lens[3]);
			StringUtil.appendSpace(sb, (String)hm.get("NSTCK_QTY"), iq_info_header_lens[4]);
			StringUtil.appendSpace(sb, (String)hm.get("RTN_TP"), iq_info_header_lens[5]);			
			//df.CommLogger("▶ ROWS_COUNT : " + (String)hm.get("ROWS_COUNT").toString().trim());			
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT"), iq_info_header_lens[6]);
			
			int i = 0;
			if( nRowCount > 0 ) {
				for(i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					
					StringUtil.appendSpace(sb, String.valueOf(i), hdr_lens[0]);
					StringUtil.appendSpace(sb, (String)map.get("PLU_CD"), hdr_lens[1]);
					StringUtil.appendSpace(sb, (String)map.get("DIS_LIM_DT"), hdr_lens[2]);
					StringUtil.appendSpace(sb, (String)map.get("DEL_YN"), hdr_lens[3]);
				}
			}else {
				//df.CommLogger("▶ hdr_StrHeaders[0] is : " + (String)hm.get(hdr_StrHeaders[0].toString()) );
				StringUtil.appendSpace(sb, "", hdr_lens[0]);
				StringUtil.appendSpace(sb, "", hdr_lens[1]);
				StringUtil.appendSpace(sb, "", hdr_lens[2]);				
				StringUtil.appendSpace(sb, "", hdr_lens[3]);
	
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeIncomInfo : " + e.getMessage());
			throw e;
		}

		return sb.toString();
*/

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/***************************************************************************
	 * selExpiryDateInfoA2 유통기한 정보 
	 * 
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selExpiryDateInfoA2(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		List list = null;
		List list1 = null;
		Map<String, String> map = new HashMap();
		Map map1 = new HashMap();
		int i = 0;
		int k = 0;
		
		StringBuffer sb = new StringBuffer();
		
		int nlens[] = { 2, 3, 8};
		
		String strHeaders[] = {
			"INQ_TYPE",//2
			"CNT",//3
			"DIS_LIM_DT"//8
		};
		
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		
		try {
			begin();
			
			String pLU_CD = (String)hm.get("PLU_CD").toString().trim();
//			
//			if (pLU_CD.length() < 13) {			
//				sql1.put(findQuery(COMMBiz_PDA.PDA_SQL,	COMMBiz_PDA.SEL_PLU_INFO_CHK));				
//				sql1.setString(++k, pLU_CD);                         /* PLU코드 */
//				sql1.setString(++k, pLU_CD);                         /* PLU코드 */
//				sql1.setString(++k, pCOM_CD);                        /* 회사코드 */
//				sql1.setString(++k, STORE_FIRST_CODE + pSTORE_CD);   /* 점포코드 */
//				sql1.setString(++k, pLU_CD);                         /* PLU코드 */
//				
//				df.CommLogger(sql1.debug());
//
//				list1 = executeQuery(sql1);				
//				map1 = (Map) list1.get(0);				
//				pLU_CD = (String) map1.get("PLU_CD_N");
//				//df.CommLogger("▶ pLU_CD ********** : "+pLU_CD);
//				sql1.clearParameter();
//				sql1.close();
//			}
//			
			sql.put(findQuery("pda-sql", "SEL_DUE_DATE_INFO_A2"));			
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());					
			sql.setString(++i, pLU_CD.trim());  
			
			df.CommLogger("EXE: " + sql.debug());
			list = executeQuery(sql);
			
			int total_cnt = list.size();
			hm.put("CNT", Integer.toString(total_cnt));
			logger.info("CNT:" + total_cnt);
			//df.CommLogger(String.valueOf(list.size()));
			if( total_cnt <= 0 ) 
			{				
				hm.put("DIS_LIM_DT", "        ");
				ret = "09";
			}
			else
			{									
				StringUtil.appendSpace(sb, (String)hm.get(strHeaders[0].toString()), nlens[0]);
				logger.info("(String)hm.get(strHeaders[0].toString())"+ (String)hm.get(strHeaders[0].toString()));
				int nRowCount = Integer.parseInt((String)hm.get("CNT").toString().trim());
				logger.info("111nRowCount"+ nRowCount);
				StringUtil.appendSpace(sb, (String)hm.get("CNT").toString().trim(), nlens[1]);
				logger.info("(String)hm.get(strHeaders[1].toString())"+ (String)hm.get(strHeaders[1].toString()));
				
				logger.info("nRowCount:" +nRowCount);
				logger.info("strHeaders.length" + strHeaders.length);
				if( nRowCount > 0 ) {
					for(i = 0;i < nRowCount;i++ ) {						
						map = (Map)list.get(i);
						//for(int j = 2; j < strHeaders.length; j++){
						
						
							StringUtil.appendSpace(sb, (String)map.get(strHeaders[2].toString()), nlens[2]);
							logger.info("sb="+sb);							
						//}						
					}
				}
			}
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + sb.toString();//makeSTRITMSELRsp(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}	
	
	
	
	
	public String updExpiryDateInfoA3(String pCOM_CD, String pSTORE_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int iRtn = 0;
		
		StringBuffer sb = new StringBuffer();
		
		int nlens[] = { 2, 3, 8};
		
		String strHeaders[] = {
			"INQ_TYPE",//2
			"CNT",//3
			"DIS_LIM_DT"//8
		};
		String dataMsg = "";
		String ret = "00";
		List list = null;
		Map map = new HashMap(); 
		connect("CMGNS");
		try {
			begin();
			sql.put(findQuery("pda-sql", "UPD_DUE_DATE_INFO_A3" ));
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			sql.setString(++i, (String)hm.get("PLU_CD"));
			sql.setString(++i, (String)hm.get("ITEM_CD"));
			sql.setString(++i, (String)hm.get("DIS_LIM_DT"));
			sql.setString(++i, (String)hm.get("DEL_YN"));
			
			iRtn = executeUpdate(sql);
			logger.info("update ok["+sql.debug()+"]");

			sql.close();// sql 닫기
			sql.clearParameter();//파라미터 비우기
			i=0;
			sql.put(findQuery("pda-sql", "SEL_DUE_DATE_INFO_A3"));
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.trim());
			sql.setString(++i, (String)hm.get("PLU_CD").trim());  
			df.CommLogger("EXE: " + sql.debug());
			list = executeQuery(sql);
			int total_cnt = list.size();//0일때 처리 할것 필요한가? 안쓸텐데
			hm.put("CNT", Integer.toString(total_cnt));
			logger.info("CNT:" + total_cnt);
			//df.CommLogger(String.valueOf(list.size()));
			if( total_cnt <= 0 ) 
			{				
				hm.put("DIS_LIM_DT", "        ");
				ret = "09";
			}
			else
			{									
				StringUtil.appendSpace(sb, (String)hm.get(strHeaders[0].toString()), nlens[0]);
				logger.info("(String)hm.get(strHeaders[0].toString())"+ (String)hm.get(strHeaders[0].toString()));
				int nRowCount = Integer.parseInt((String)hm.get("CNT").toString().trim());
				logger.info("111nRowCount"+ nRowCount);
				StringUtil.appendSpace(sb, (String)hm.get("CNT").toString().trim(), nlens[1]);
				logger.info("(String)hm.get(strHeaders[1].toString())"+ (String)hm.get(strHeaders[1].toString()));
				
				logger.info("nRowCount:" +nRowCount);
				logger.info("strHeaders.length" + strHeaders.length);
				if( nRowCount > 0 ) {
					for(i = 0;i < nRowCount;i++ ) {						
						map = (Map)list.get(i);
						logger.info(strHeaders[2]+"_strHeaders[2] =" + (String)map.get(strHeaders[2]));
							StringUtil.appendSpace(sb, (String)map.get(strHeaders[2].toString()), nlens[2]);
						logger.info("sb=["+sb+"]");
					}
				}
			}			
			
			
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e.getStackTrace());
			logger.info("▶ SEL Error : [" + e.getMessage()+"]");
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + sb.toString();			
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	
	
	/***************************************************************************
	 * selIncomInfoA4 입고검수 정보 
	 * 
	 * @param pCOM_CD
	 * @param pSTORE_CD
	 * @param hm
	 * @param df
	 * @return dataMsg
	 * @throws Exception
	 */
	public String selIncomInfoA4(String pCOM_CD, String pSTORE_CD, HashMap hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		
		connect("CMGNS");
		try {
			begin();
			
			
			sql.put(findQuery("pda-sql", "SEL_INCOM_CHKA4"));
			sql.setString(++i, (String)hm.get("SLIP_NO").toString().trim());
			sql.setString(++i, (String)hm.get("SLIP_NO").toString().trim());
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			
			list = executeQuery(sql);
			int incomchk = list.size();
			if(incomchk >= 1) //OLD 	if(incomchk == 1)
			{
				//df.CommLogger("OK");
				hm.put("INQ_TYPE"," "); 
				hm.put("SLIP_SEQ"," ");
				hm.put("PLU_CD"," ");
				hm.put("PLU_NM"," ");
				hm.put("WARIN_QTY"," ");
				hm.put("PLU_INV"," ");
				hm.put("STR_SAL_PRC"," ");
				ret = "10";
				end();
				dataMsg = ret + makeIncomInfoA4(hm, list, df);
				return dataMsg;
			}
			else
			{
				i = 0;
				sql.clearParameter();
				sql.close();
				
			}
			
//			df.CommLogger("▶ SLIP_NO : " + (String)hm.get("SLIP_NO"));
//			df.CommLogger("▶ WARIN_DT : " + (String)hm.get("WARIN_DT"));
			sql.put(findQuery("pda-sql", "SEL_INCOM_INFOA4"));//SEL_INCOM_INFO
			sql.setString(++i, (String)hm.get("SLIP_NO").toString().trim());
			sql.setString(++i, (String)hm.get("SLIP_NO").toString().trim());
			sql.setString(++i, pCOM_CD.toString().trim());
			sql.setString(++i, STORE_FIRST_CODE + pSTORE_CD.toString().trim());
			//sql.setString(++i, (String)hm.get("WARIN_DT"));

//			df.CommLogger("▶ SLIP_NO : " + (String)hm.get("SLIP_NO"));
//			df.CommLogger("▶ COM_CD : " + pCOM_CD);
//			df.CommLogger("▶ STORE_CD : " + STORE_FIRST_CODE + pSTORE_CD);
//			
//			df.CommLogger("▶ SQL : " + sql.debug());
			
			list = executeQuery(sql);
			
//			df.CommLogger("▶ list size : " + Integer.toString(list.size()));
			
			int total_cnt = list.size();
			hm.put("ROWS_COUNT", Integer.toString(total_cnt));
			
			if( list.size() <= 0 ) {
				ret = "09";
			}
		}catch(SQLException e) {
			rollback();
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			df.CommLogger( "▶ SQLException  Message=====>"+ e.getMessage());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "10";
		}catch(Exception e) {
			rollback();
			df.CommLogger("▶ SEL Error : " + e);
			ret = "20";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeIncomInfoA4(hm, list, df);
//			df.CommLogger("★ make: " + dataMsg);
		}
		
		return dataMsg;
	}
	
	
	/***************************************************************************
	 * makeIncomInfoA4 : 입고검수 전표에 해당하는 상품정보 응답
	 * 
	 * @param hm
	 * @param list
	 * @return 전송메세지
	 */
	private String makeIncomInfoA4(HashMap hm, List list, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		Map map = new HashMap();
		int iq_info_header_lens[] = {2, 10, 30, 30, 30 };
		int hdr_lens[] = { 2, 10, 30, 50, 10, 10, 10, 30, 10, 12, 19 };		//int hdr_lens[] = { 2, 10, 30, 50, 10, 10, 10, 30, 10, 30, 12 };
		String iq_info_headers[] = {
				"INQ_TYPE",
				"INQ_COUNT",
                "INQ_COLUME1",
                "INQ_COLUME2",
                "INQ_COLUME3"
		};
		String hdr_StrHeaders[] = {
				"INQ_TYPE",   			// 
				"SLIP_SEQ",				// ROW Number
				"PLU_CD",				// 상품 코드
				"PLU_NM",				// 상품 이름
				"WARIN_QTY",			// 입고수량
				"PLU_INV",				// 상품 재고수량
				"STR_SAL_PRC",			// 점포매가
				"SLIP_NO",				// 전표번호
				"OUT_QTY",				// 출고 수량
				"ACQ",					// 입수 (발주단위)
				"WARIN_MULT_QTY"		// 입고 배수
//				"PICE_PLU_CD",			// 낱개PLU
//				"BOX_STORD_ACQ"			// BOX점발주입수								
		};
		
		try
		{
			StringUtil.appendSpace(sb, (String)hm.get(iq_info_headers[0].toString()), iq_info_header_lens[0]);
			
//			df.CommLogger("▶ ROWS_COUNT : " + (String)hm.get("ROWS_COUNT").toString().trim());
			
			int nRowCount = Integer.parseInt((String)hm.get("ROWS_COUNT").toString().trim());
			StringUtil.appendSpace(sb, (String)hm.get("ROWS_COUNT"), iq_info_header_lens[1]);
			
			int i = 0;
			if( nRowCount > 0 ) {
				for(i = 0;i < nRowCount;i++ ) {
					map = (Map)list.get(i);
					
					if(i==0)
					{

						StringUtil.appendSpace(sb, (String)map.get("WM_CENT_NM"), iq_info_header_lens[2]);
						StringUtil.appendSpace(sb, (String)map.get("DVY_ROOT_TP_NM"), iq_info_header_lens[3]);
						StringUtil.appendSpace(sb, (String)map.get("WM_CONF_TP")+"|"+(String)map.get("WARIN_DT"), iq_info_header_lens[4]);
					}
					
					StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
					StringUtil.appendSpace(sb, (String)map.get("SLIP_SEQ"), hdr_lens[1]);
					StringUtil.appendSpace(sb, (String)map.get("PLU_CD"), hdr_lens[2]);
					StringUtil.appendSpace(sb, (String)map.get("GDS_NM"), hdr_lens[3]);
					StringUtil.appendSpace(sb, (String)map.get("WARIN_QTY"), hdr_lens[4]);
					StringUtil.appendSpace(sb, (String)map.get("NSTCK_QTY"), hdr_lens[5]);
					StringUtil.appendSpace(sb, (String)map.get("STR_SAL_PRC"), hdr_lens[6]);
					StringUtil.appendSpace(sb, (String)map.get("SLIP_NO"), hdr_lens[7]);
					StringUtil.appendSpace(sb, (String)map.get("OUT_QTY"), hdr_lens[8]);
					StringUtil.appendSpace(sb, (String)map.get("ACQ"), hdr_lens[9]);
					StringUtil.appendSpace(sb, (String)map.get("WARIN_MULT_QTY"), hdr_lens[10]);
				}
			}else {
				//df.CommLogger("▶ hdr_StrHeaders[0] is : " + (String)hm.get(hdr_StrHeaders[0].toString()) );
				if(i==0)
				{
					StringUtil.appendSpace(sb, "", iq_info_header_lens[1]);
					StringUtil.appendSpace(sb, "", iq_info_header_lens[2]);
					StringUtil.appendSpace(sb, "", iq_info_header_lens[3]);
				}
				StringUtil.appendSpace(sb, (String)hm.get(hdr_StrHeaders[0].toString()), hdr_lens[0]);
				StringUtil.appendSpace(sb, Integer.toString(0), hdr_lens[1]);
				StringUtil.appendSpace(sb, "", hdr_lens[2]);				
				StringUtil.appendSpace(sb, "", hdr_lens[3]);
				StringUtil.appendSpace(sb, "", hdr_lens[4]);
				StringUtil.appendSpace(sb, "", hdr_lens[5]);
				StringUtil.appendSpace(sb, "", hdr_lens[6]);
				StringUtil.appendSpace(sb, "", hdr_lens[7]);
				StringUtil.appendSpace(sb, "", hdr_lens[8]);
				StringUtil.appendSpace(sb, "", hdr_lens[9]);
				StringUtil.appendSpace(sb, "", hdr_lens[10]);
			}
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR] makeIncomInfo : " + e.getMessage());
			throw e;
		}

		return sb.toString();
	}

	
	
}
