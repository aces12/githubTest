package biz.cms_PDACommIf2;

import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMBiz_PDA;
import biz.comm.COMMLog;

public class PDACommIFProtocol2 {
 
	private static Logger logger = Logger.getLogger(PDACommIFAction2.class);
	
	/***
	 * getRcvPDAInqData
	 * @param rcvBuf Receive MSG
	 * @return INQ_TYPE
	 */
	public int getRcvPDAInqType(String rcvBuf)
	{
		int ret = 0;
		
		HashMap hm = new HashMap();
		
		hm.put("INQ_TYPE", rcvBuf.substring(0, 2));
		
		if( Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE")) )
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		
		return ret;
	}
	
	/***
	 * getRcvPDAInqDATA
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	//leesuengho
	public String getRcvPDAIrtDATA(String rcvBuf){		
		HashMap<String, String> hm = new HashMap<String, String>();
		String ret = "";
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};
	
		String strHeaders[] = {      				
				"INQ_TYPE"			  // INQ Type(INQ 종별)    
			};		

		logger.info("getRcvMbsIrtDATA rcvBuf[" + rcvBuf + "]" );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		logger.info("getRcvMbsIrtDATA hm[" + hm + "]" );
		return (String)hm.get("INQ_TYPE");
	}
	
	
	/***
	 * getParseInqUser
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseInqUser(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 13, 60}; 
		
		String strHeaders[] = {
				"INQ_TYPE",
				"USER_ID",
				"USER_PWD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);

		return hm;
	}
	
	/***
	 * getPDAVersion
	 * : 점포-PDA버전관리
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getPDAVersion(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 8, 8, 16, 12};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"STORE_CD",
				"PDA_NO",
				"IP_ADDR",
				"VERSION"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * setPrintMst
	 * : 점포-가격표출력
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> setPrintMst(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 2, 30, 30 };
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD",
				"IP"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * DelPrintMst
	 * : 점포-가격표 삭제 sysdate -1 일
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> DelPrintMst(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 2 };
		
		String strHeaders[] = {
				"INQ_TYPE"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * setExceptOrd
	 * : 점포발주-발주제외 수정
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> setExceptOrd(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 2, 30, 8, 2, 30, 2 };
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD",
				"STORE_CD",
				"ORD_ENBL_TP",
				"ITEM_CD",
				"PRCCHG_ENBL_YN"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * SALECHK
	 * : 점포 - 판매가능여부 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getSaleChk(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 8, 30};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"STORE_CD",
				"PLU_CD",
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * NOXCHK
	 * : 점포 - 위해상품 여부 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getNoxChk(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 30};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD",
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * getScanPluInfo
	 * : 점포발주-스캔방식 상품정보 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getScanPluInfo(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 30, 10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD",
				"INPUT_DT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * GetTotalSize
	 * : 프로토콜 전체 길이 구하기.
	 * @param nLens 프로토콜 길이
	 * @return int : 전체 길이
	 */
	private int GetTotalSize(int[] nLens)
	{
		int nResult = 0;
		try
		{
			for(int n=0; n<nLens.length; n++)
			{
				nResult += nLens[n];
			}
		}catch(Exception ex)
		{
			ex.toString();
		}
		
		return nResult;
	}
	/***
	 * getOldScanPluUpdate
	 * : 점포발주-스캔방식 상품정보 수정 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getOldScanPluUpdate(String rcvBuf, COMMLog df) throws Exception{
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 20, 20, 10, 10, 10, 20};
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD",
				"ITEM_CD",
				"SORD_QTY",
				"INPUT_COUNT",
				"GDS_COST",
				"INPUT_DT"
		};
		
		try {
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
			int nPos = 0;
			hm.put("ROWS_COUNT",Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos+=nlens[nCol];
//					df.CommLogger("["+strHeaders[nCol]+ Integer.toString(n)+"] = '" + rcvBuf.substring(nPos-nlens[nCol],nPos).trim() + "'" );
					hm.put(strHeaders[nCol]+ Integer.toString(n), rcvBuf.substring(nPos-nlens[nCol],nPos).trim());
				}
			}
		}catch(Exception e) {
			throw e;
		}
		return hm;
	}
	/***
	 * getScanPluUpdate
	 * : 점포발주-스캔방식 상품정보 수정 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getScanPluUpdate(String rcvBuf, COMMLog df) throws Exception{
		HashMap hm = new HashMap();
		int nlens[] = {2, 20, 20, 10, 10, 10, 20, 12};
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD",
				"ITEM_CD",
				"SORD_QTY",
				"INPUT_COUNT",
				"GDS_COST",
				"INPUT_DT",
				"ADD_TO_LOANAMT"
		};
		
		try {
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
			int nPos = 0;
			int nAddToLoanAmt = 0;
			hm.put("ROWS_COUNT",Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos+=nlens[nCol];
					//df.CommLogger("["+strHeaders[nCol]+ Integer.toString(n)+"] = '" + rcvBuf.substring(nPos-nlens[nCol],nPos).trim() + "'" );
					hm.put(strHeaders[nCol]+ Integer.toString(n), rcvBuf.substring(nPos-nlens[nCol],nPos).trim());
				}
				nAddToLoanAmt += Integer.parseInt((String)hm.get("ADD_TO_LOANAMT" + Integer.toString(n)));
			}
			hm.put("TOT_ADD_AMT", Integer.toString(nAddToLoanAmt));
		}catch(Exception e) {
			throw e;
		}
		return hm;
	}
	/***
	 * getStandInfo
	 * : 점포발주-진열대 진열대 정보 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getStandInfo(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 30};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"STORE_CD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * getStandInfo2
	 * : 점포발주-분류별 대분류 정보 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getStandInfo2(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 30, 10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"STORE_CD",
				"INPUT_DT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * getStandPluInfo
	 * : 점포발주-진열대 진열대 상품 정보 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getStandPluInfo(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 30, 10 };
		
		String strHeaders[] = {
				"INQ_TYPE",
				"STAND_CD",
				"INPUT_DT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getStandPluInfo
	 * : 점포발주-발주 상품 정보 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getOrderPluInfo(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 10 };
		
		String strHeaders[] = {
				"INQ_TYPE",
				"INPUT_DT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getOldStandPluInfo
	 * : 점포발주-진열대 진열대 상품 정보 수정 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getOldStandPluUpdate(String rcvBuf, COMMLog df) throws Exception{
		HashMap hm = new HashMap();
		int nlens[] = {2, 20, 20, 20, 10, 10, 10, 20};
		String strHeaders[] = {
				"INQ_TYPE",
				"STAND_CD",
				"PLU_CD",
				"ITEM_CD",
				"SORD_QTY",
				"INPUT_COUNT",
				"GDS_COST",
				"INPUT_DT"
		};
		
		try {
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
//			df.CommLogger("▶ nSize : " + Integer.toString(nSize) );
//			df.CommLogger("▶ GetTotalSize : " + Integer.toString(GetTotalSize(nlens)) );
//			df.CommLogger("▶ nRows : " + Integer.toString(nRows) );
			int nPos = 0;
			hm.put("ROWS_COUNT",Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos+=nlens[nCol];
//					df.CommLogger("["+strHeaders[nCol]+ Integer.toString(n)+"] = '" + rcvBuf.substring(nPos-nlens[nCol],nPos).trim() + "'" );
					hm.put(strHeaders[nCol]+ Integer.toString(n), rcvBuf.substring(nPos-nlens[nCol],nPos).trim() );
				}
			}
		}catch(Exception e) {
			throw e;
		}
		return hm;
	}
	
	/***
	 * getStandPluInfo
	 * : 점포발주-진열대 진열대 상품 정보 수정 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getStandPluUpdate(String rcvBuf, COMMLog df) throws Exception{
		HashMap hm = new HashMap();
		int nlens[] = {2, 20, 20, 20, 10, 10, 10, 20, 12};
		String strHeaders[] = {
				"INQ_TYPE",
				"STAND_CD",
				"PLU_CD",
				"ITEM_CD",
				"SORD_QTY",
				"INPUT_COUNT",
				"GDS_COST",
				"INPUT_DT",
				"ADD_TO_LOANAMT"
		};
		
		try {
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
//			df.CommLogger("▶ nSize : " + Integer.toString(nSize) );
//			df.CommLogger("▶ GetTotalSize : " + Integer.toString(GetTotalSize(nlens)) );
//			df.CommLogger("▶ nRows : " + Integer.toString(nRows) );
			int nPos = 0;
			int nAddToLoanAmt = 0;
			hm.put("ROWS_COUNT",Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos+=nlens[nCol];
//					df.CommLogger("["+strHeaders[nCol]+ Integer.toString(n)+"] = '" + rcvBuf.substring(nPos-nlens[nCol],nPos).trim() + "'" );
					hm.put(strHeaders[nCol]+ Integer.toString(n), rcvBuf.substring(nPos-nlens[nCol],nPos).trim() );
				}
				nAddToLoanAmt += Integer.parseInt((String)hm.get("ADD_TO_LOANAMT" + Integer.toString(n)));
			}
			hm.put("TOT_ADD_AMT", Integer.toString(nAddToLoanAmt));
		}catch(Exception e) {
			throw e;
		}
		return hm;
	}
	
	/***
	 * getLimitRtnInfo
	 * : 반품등록-한도반품 정보 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getLimitRtnInfo(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"INPUT_DT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getLimitRtnInfo
	 * : 반품등록-한도반품 상품 정보 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getRtnGdsInfo(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 30, 10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD",
				"INPUT_DT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}	
	
	/***
	 * getRtnMgrUpdate
	 * : 반품등록-반품등록 정보 수정 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getRtnMgrUpdate(String rcvBuf, COMMLog df) throws Exception{
		HashMap hm = new HashMap();
		int nlens[] = {2, 8, 30, 4, 20, 20, 20, 1, 10, 10, 10, 10, 10, 10};
		String strHeaders[] = {
				"INQ_TYPE",
				"INPUT_DT",
				"ITEM_CD",
				"RTN_TP",
				"DVY_CD",
				"PTN_CD",
				"VEN_CD",
				"TAX_TP",
				"TAX_RT",
				"HDQ_SAL_PRC",
				"SUP_PRC",
				"REQ_QTY",
				"AMT",
				"VAT"
		};
		
		try {
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
//			df.CommLogger("▶ nSize : " + Integer.toString(nSize) );
//			df.CommLogger("▶ GetTotalSize : " + Integer.toString(GetTotalSize(nlens)) );
//			df.CommLogger("▶ nRows : " + Integer.toString(nRows) );
			int nPos = 0;
			int nAddToLoanAmt = 0;
			hm.put("ROWS_COUNT",Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos+=nlens[nCol];
//					df.CommLogger("["+strHeaders[nCol]+ Integer.toString(n)+"] = '" + rcvBuf.substring(nPos-nlens[nCol],nPos).trim() + "'" );
					hm.put(strHeaders[nCol]+ Integer.toString(n), rcvBuf.substring(nPos-nlens[nCol],nPos).trim() );
				}
				//nAddToLoanAmt += Integer.parseInt((String)hm.get("ADD_TO_LOANAMT" + Integer.toString(n)));
			}
			//hm.put("TOT_ADD_AMT", Integer.toString(nAddToLoanAmt));
		}catch(Exception e) {
			throw e;
		}
		return hm;
	}
	
	/***
	 * getIncomInfo
	 * : 입고상품  정보
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getIncomInfo(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 30, 20};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"SLIP_NO",
				"WARIN_DT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * getIncomInfoUpdate
	 * : 입고상품  정보 수정
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getIncomInfoUpdate(String rcvBuf) throws Exception{
		HashMap hm = new HashMap();
		int nlens[] = {2, 30, 10, 30, 10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"SLIP_NO",
				"SLIP_SEQ",
				"PLU_CD",
				"INPUT_COUNT"
		};
		
		try {
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
			int nPos = 0;
			hm.put("ROWS_COUNT",Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos+=nlens[nCol];
					hm.put(strHeaders[nCol]+ Integer.toString(n), 
							rcvBuf.substring(nPos-nlens[nCol],nPos) );
				}
			}
		}catch(Exception e) {
			throw e;
		}
		return hm;
	}
	
	/***
	 * getInventoryAdjustment
	 * : 상품재고정보
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getInventoryAdjustment(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 30};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * getInventoryUpdate
	 * : 상품재고조정
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getInventoryUpdate(String rcvBuf, COMMLog df) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 20, 10, 10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"ITEM_CD",
				"NSTCK_QTY",
				"INPUT_QTY"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * getParseMasterStandReq
	 * : 진열대 마스터 정보 요청
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseMasterStandReq(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 20};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"MOD_DT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	/***
	 * getAppVersion
	 * : 버전 정보 요청  : IQ_MASTER_VER_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getAppVersion(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"VER"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getStoreLoan
	 * : 발주 여신금액 조회 요청  : IQ_PDAEMEGR_TRN_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getStoreLoan(String rcvBuf) throws Exception {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 4, 5};
		
		String strHeaders[] = {
			"INQ_TYPE",
			"COM_CD",
			"STORE_CD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
//		for(int i = 0;i < nlens.length;i++) {
//			logger.info("[" + strHeaders[i] + "]=" + hm.get(strHeaders[i]));
//		}
		
		return hm;
	}
	/***
	 * 점상품 조회 요청 : IQ_ITEM_SEARCH_INFO
	 * @param rcvBuf
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, String> getStoreITMINFO(String rcvBuf) throws Exception {
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {2, 8, 4, 5, 30};
		
		String strHeaders[] = {
			"INQ_TYPE",//2
			"SEL_DT",//8
			"CO_CD",//4
			"STORE_CD",//5
			"PLU_CD"//30
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
//		for(int i = 0;i < nlens.length;i++) {
//			logger.info("[" + strHeaders[i] + "]=" + hm.get(strHeaders[i]));
//		}
		
		return hm;
	}
	
	/***
	 * 재고조정 이력조회 요청 : IQ_STOCK_CHG_REQ
	 * @param rcvBuf
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, String> getStockChgReq(String rcvBuf) throws Exception {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 30};
		
		String strHeaders[] = {
			"INQ_TYPE",//2
			"PLU_CD"//30
		};		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getPDAEmegrTran
	 * : 정전시 PDA판매 거래정보 전송 요청  : IQ_PDAEMEGR_TRN_REQ
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getPDAEmegrTran(String rcvBuf) throws Exception {
		HashMap<String, String> hm = new HashMap();
		int nlens[] = {2, 5, 8, 4, 4, 8, 165};
		
		String strHeaders[] = {
			"INQ_TYPE",
			"STORE_CD",
			"SALE_DT",
			"PDA_NO",
			"TRAN_NO",
			"SUM",
			"INV_DATA"
		};
		
		try {
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
			int nPos = 0;
			hm.put("ROWS_COUNT", Integer.toString(nRows));
			for(int n = 0;n < nRows;n++)
			{
				for(int nCol = 0;nCol < nlens.length;nCol++)
				{
					nPos += nlens[nCol];
					hm.put(strHeaders[nCol] + Integer.toString(n), rcvBuf.substring(nPos - nlens[nCol], nPos).trim());
					
//					logger.info(strHeaders[nCol]+Integer.toString(n)+"="+rcvBuf.substring(nPos - nlens[nCol], nPos).trim());
				}
				String strINV_DATA = ((String)hm.get("INV_DATA"+Integer.toString(n))).trim();
				int iItemCnt = strINV_DATA.length() / 33;
				hm.put("TOT_ITEM"+Integer.toString(n), Integer.toString(iItemCnt));
				for(int nItem = 0;nItem < iItemCnt;nItem++)
				{
					hm.put("ITEM_SEQ" + Integer.toString(n) + Integer.toString(nItem), strINV_DATA.substring(nItem*33, nItem*33 + 1).trim());
					hm.put("PLU_CD" + Integer.toString(n) + Integer.toString(nItem), strINV_DATA.substring(nItem*33 + 1, nItem*33 + 1 + 30).trim());
					hm.put("ITEM_QTY" + Integer.toString(n) + Integer.toString(nItem), strINV_DATA.substring(nItem*33 + 31, nItem*33 + 31 + 2).trim());
					
//					logger.info("ITEM_SEQ" + Integer.toString(n) + Integer.toString(nItem) + "=" + (String)hm.get("ITEM_SEQ" + Integer.toString(n) + Integer.toString(nItem)));
//					logger.info("PLU_CD" + Integer.toString(n) + Integer.toString(nItem) + "=" + (String)hm.get("PLU_CD" + Integer.toString(n) + Integer.toString(nItem)));
//					logger.info("ITEM_QTY" + Integer.toString(n) + Integer.toString(nItem) + "=" + (String)hm.get("ITEM_QTY" + Integer.toString(n) + Integer.toString(nItem)));
				}
			}
		}catch(Exception e) {
			throw e;
		}
		
		return hm;
	}
	
	/***
	 * getCloseOrderTime
	 * : 발주가능 시간, 금액 조회
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getCloseOrderTime(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2,10};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"INPUT_DT"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	/***
	 * getPLU_TEMP
	 * : 점포 상품 바코드 확인을 위한 임시 사용
	 * @param rcvBuf Receive MSG
	 * @param df COMMLog
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getPLU_TEMP(String rcvBuf, COMMLog df) throws Exception{
		HashMap hm = new HashMap();
		int nlens[] = {2, 30, 10};
		
		String strHeaders[] = {
				"INQ_TYPE",   	// 30 : IQ_PLU_TEMP_REQ
				"PLU_CD",		// 상품코드
				"COUNT"  		// 수량
		};
		
		try {
			int nSize = rcvBuf.length();
			int nRows = nSize / GetTotalSize(nlens);
			int nPos = 0;
			hm.put("ROWS_COUNT",Integer.toString(nRows));
			for(int n=0; n<nRows; n++)
			{
				for(int nCol=0; nCol<nlens.length; nCol++)
				{
					nPos+=nlens[nCol];
					hm.put(strHeaders[nCol]+ Integer.toString(n), 
							rcvBuf.substring(nPos-nlens[nCol],nPos) );
				}
			}
		}catch(Exception e) {
			throw e;
		}
		return hm;
	}
	
	/***
	 * getSystemDate
	 * : 시스템시간 동기화(DB시간)
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getSystemDate(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 2 };
		
		String strHeaders[] = {
				"INQ_TYPE"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}

	//leeseungho 180719
	/***
	 * getSystemDate
	 * : 최대발주금액
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap<String, String> getMaxOrderAmt(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = { 2 };
		
		String strHeaders[] = {
				"INQ_TYPE"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	/***
	 * getIncomInfo
	 * : 입고상품  정보
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 *///leeseungho
	public HashMap getIncomInfoA0(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2,30};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}	
	
	
	////////////////////////////////////////////////
	/***
	 * getExpiryDateInfo
	 * : 유통기한 상품  정보
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getExpiryDateInfoA1(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 30};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	////////////////////////////////////////////////
	/***
	 * getExpiryDateInfo
	 * : 유통기한 상품  정보
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getExpiryDateInfoA2(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 30};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}	
	////////////////////////////////////////////////
	/***
	 * getExpiryDateMegA3
	 * : 유통기한 저장
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getExpiryDateMegA3(String rcvBuf) {
		HashMap hm = new HashMap();
		int nlens[] = {2, 30, 30, 8, 1};
		
		String strHeaders[] = {
				"INQ_TYPE",
				"PLU_CD",
				"ITEM_CD",
				"DIS_LIM_DT",
				"DEL_YN"
		};
		
		hm = COMMBiz_PDA.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
		
	
	
}
