package biz.cms_StaffDCIrt;

import java.util.HashMap;

import kr.fujitsu.com.ffw.util.StringUtil;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class StaffDCIrtProtocol {
	int ret = 0;
	
	public int getStaffDCIrtInq(String rcvBuf){
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};
	
		String strHeaders[] = {"INQ_TYPE"  };// INQ Type(INQ 종별) 
							
		//////logger.info("▶ Receive Data: " + rcvBuf );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		ret = COMMBiz.getInqTypeCHG((String)hm.get("INQ_TYPE"));

		return ret;
	}
	
	public HashMap<String, String> getStaffDCReq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		
		int nlens[] = {2, 5, 4, 1, 10
					, 80, 1, 1, 23, 8
					, 6};
		
		String strHeaders[] = {
			"INQ_TYPE",		// INQ종별
			"STORE_CODE",		// 점포코드 STORE_CODE
			"POS_NO",		// POS번호
			"CONF_GUBUN",	// 인증방법구분
			"ELEC_STAFF",	// 전자사원증
			
			"CARD_NO",		// 신용카드
			"KEY_IN",		// KEY IN 유무
			"REQ_TYPE",		// 요청구분
			"CTL_TRAN_NO",	// 내부 거래번호
			"REG_YMD",		// 등록일자
			
			"REG_HMS"		// 등록시간
		};
		
		//logger.info( "▶ getParseCashBeeRTPaymentRcvRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public String makeSendDataStrStockNow(HashMap<String, String> hm, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2, 2, 4, 2, 128
					, 10, 50, 50, 10, 50
					, 5, 16, 60};
		String strHeaders[] = {
				"INQ_TYPE",		//INQ종별
				"RETURN_CD",	//응답코드 to resp_code
				"RESP_CODE",	//결과코드 to return_cd
				"EMPLOYEE_YN",	//직원유무
				"EMPLOYEE_ID",	//사번
		
				"COMP_CD",		//소속사코드
				"COMP_NM",		//소속사명
				"EMPLOYEE_NM",	//이름
				"RANK_CD",		//직급코드
				"RANK_NM",		//직급명
		
				"USE_CNT",		//사용횟수
				"USE_AMT",		//가용금액
				"RSP_MESSAGE"	//응답메세지
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			df.CommLogger(nlens[i] + "[" + (String) hm.get(strHeaders[i].toString()) + "]");
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	

}
