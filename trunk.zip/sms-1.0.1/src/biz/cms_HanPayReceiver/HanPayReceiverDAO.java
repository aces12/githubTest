package biz.cms_HanPayReceiver;

import java.util.HashMap;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class HanPayReceiverDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(HanPayReceiverAction.class);
	
	public int insHanPayCHRGADJTRslt_HDR(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_HANPAYCHRGADJTRSLT_HDR"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
			sql.setString(++i, (String)hm.get("TOT_RECORD_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RECHRG_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RECHRG_AMT"));
			sql.setString(++i, (String)hm.get("TOT_RECHRG_FEE"));
			sql.setString(++i, (String)hm.get("TOT_RECHRGCNCL_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RECHRGCNCL_AMT"));
			sql.setString(++i, (String)hm.get("TOT_RECHRGCNCL_FEE"));
			sql.setString(++i, (String)hm.get("TOT_RETRECHRG_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RETRECHRG_AMT"));
			sql.setString(++i, (String)hm.get("TOT_RETRECHRG_FEE"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insHanPayCHRGADJTRslt_DAT(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_HANPAYCHRGADJTRSLT_DTL"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
			sql.setString(++i, (String)hm.get("TRAN_UNQ_NO"));
			sql.setString(++i, "A16" + ((String)hm.get("TRAN_UNQ_NO")).substring(6, 11));
			sql.setString(++i, (String)hm.get("FCSTR_ID"));
			sql.setString(++i, (String)hm.get("TMNAL_ID"));
			sql.setString(++i, (String)hm.get("CARD_NO"));
			sql.setString(++i, (String)hm.get("CARD_KEY"));
			sql.setString(++i, (String)hm.get("DOUBLE_CARD_KEY"));
			sql.setString(++i, (String)hm.get("CARD_TP"));
			sql.setString(++i, (String)hm.get("TRAN_REQ_DTM"));
			sql.setString(++i, (String)hm.get("TRAN_FNSH_DTM"));
			sql.setString(++i, (String)hm.get("CARD_TRAN_SEQ_NO"));
			sql.setString(++i, (String)hm.get("TASK_TP"));
			sql.setString(++i, (String)hm.get("TRAN_OCCU_DTM"));
			sql.setString(++i, (String)hm.get("TRANBE_REM_ATM"));
			sql.setString(++i, (String)hm.get("TRAN_REQ_AMT"));
			sql.setString(++i, (String)hm.get("TRANAF_REM_AMT"));
			sql.setString(++i, (String)hm.get("TRAN_FEE"));
			sql.setString(++i, (String)hm.get("RESP_CD"));
			sql.setString(++i, (String)hm.get("PAY_TP"));
			sql.setString(++i, (String)hm.get("CCARD_CO_TP"));
			
			//logger.info(sql.debug());
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insHanPayCHRGADJTRsltByFcstrID_1_DAT(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_HANPAYCHRGADJTRSLTBYFCSTRID_DTL_1"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
			sql.setString(++i, (String)hm.get("WM_STORE_CD").trim());
			sql.setString(++i, (String)hm.get("TOT_RECHG_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RECHRG_AMT"));
			sql.setString(++i, (String)hm.get("TOT_RECHRG_FEE"));
			sql.setString(++i, (String)hm.get("TOT_RECHRGCNCL_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RECHRGCNCL_AMT"));
			sql.setString(++i, (String)hm.get("TOT_RECHRGCNCL_FEE"));
			sql.setString(++i, (String)hm.get("TOT_RETRECHRG_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RETRECHRG_AMT"));
			sql.setString(++i, (String)hm.get("TOT_RETRECHRG_FEE"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insHanPayCHRGADJTRsltByFcstrID_2_DAT(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_HANPAYCHRGADJTRSLTBYFCSTRID_DTL_2"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("ADJT_DT"));
			sql.setString(++i, (String)hm.get("BIZLOC_ORG_CD").trim());
			sql.setString(++i, (String)hm.get("TOT_PMNT_CNT"));
			sql.setString(++i, (String)hm.get("TOT_PMNT_AMT"));
			sql.setString(++i, (String)hm.get("TOT_PMNT_FEE"));
			sql.setString(++i, (String)hm.get("TOT_RTN_CNT"));
			sql.setString(++i, (String)hm.get("TOT_RTN_AMT"));
			sql.setString(++i, (String)hm.get("TOT_RTN_FEE"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int updHanPayPAYMENT_DTL(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			if( ((String)hm.get("PROC_ID")).equals("3") ) {	// 반송
				sql.put(findQuery("service-sql", "UPD_HANPAYPAYMENT_DTL2"));
			}else {	// 정상
				sql.put(findQuery("service-sql", "UPD_HANPAYPAYMENT_DTL"));
			}
			sql.setString(++i, (String)hm.get("TRAN_FEE"));
			sql.setString(++i, (String)hm.get("RESP_CD"));
			sql.setString(++i, (String)hm.get("FILE_MK_DT"));
			sql.setString(++i, (String)hm.get("PROC_ID"));
			sql.setString(++i, ((String)hm.get("TRAN_UNQ_NO")).trim());
			sql.setString(++i, (String)hm.get("CO_CD"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int delHanPayPUBCOMST(String com_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "DEL_HANPAYPUBCO_MST"));
			sql.setString(++i, com_cd);
			
			rows = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insHanPayPUBCOMST(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_HANPAYPUBCO_MST"));
			sql.setString(++i, (String)hm.get("CO_CD"));
			sql.setString(++i, (String)hm.get("PUBCO_CD"));
			sql.setString(++i, ((String)hm.get("TMNAL_ID")));
			
//			logger.info(sql.debug());
			
			rows = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
//			logger.info("[ERROR]" + e);
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
}
