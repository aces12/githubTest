package biz.cms_SSGMbsTran;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class SSGMbsTranInst extends Thread {
	private static Logger logger = Logger.getLogger(SSGMbsTranPollingAction.class);
	
	private final int LENGTH_BY_RSLT_RECORD = 201;
	
	String path = "";
	
	public SSGMbsTranInst(String path) {
		this.path = path;
	}
	
	public void run() {
		String fileNM = "";
		
		try {
			List<File> file = getDirFileList(path);
			logger.info(" >>>>>>>>>>>>>>>>>>> file cnt : " + Integer.toString(file.size()));
			
			for(int i = 0;i < file.size();i++) {
				fileNM = file.get(i).getName();
				
				logger.info(" >>>>>>>>>>>>>>>>>>> file name : " + fileNM);
				
				int len = 0;
				int totLen = 0;
				String readLine = "";
				
				long fileSize = (file.get(i)).length();
				
				byte buf[] = new byte[(int)fileSize];
				InputStream is = new FileInputStream(file.get(i));
				
				StringBuffer sb = new StringBuffer();
				
				while( (len = is.read(buf, 0, (int)fileSize)) > 0 ) {
					sb.append(new String(buf));
					totLen += len;
					if( totLen == fileSize ) {
						break;
					}
				}
				
				is.close();
				
				if( fileNM.substring(0, 10).equals("2500CV0021") ) {		// 신세계포인트 사용 내역
					this.insertDB(1, sb.toString());
				}else if( fileNM.substring(0, 10).equals("2500CV0022") ) {	// 신세계포인트 적립 내역
					this.insertDB(2, sb.toString());
				}
				
				// 파일 옮기기...
				moveFile(path, fileNM, path + File.separator + "backup");
				logger.info("[DEBUG] File " + fileNM + " processed successfuly.");
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private void insertDB(int type, String readData) {
		try {
			HashMap<String, String> hm = new HashMap<String, String>();
			SSGMbsTranDAO dao = new SSGMbsTranDAO();
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			String trans_date = "";
			byte bytes[] = readData.getBytes();
			int totLen = 0;
			
			for(int i = 0;totLen < bytes.length;i++) {
				String strRecord = new String(bytes, i*LENGTH_BY_RSLT_RECORD, LENGTH_BY_RSLT_RECORD);
				totLen += LENGTH_BY_RSLT_RECORD;

				if( strRecord.substring(0, 2).equals("BH") ) {
					hm = getSSGPointRslt_HDR(strRecord);
					trans_date = (String)hm.get("TRANS_DATE");
				}else if( strRecord.substring(0, 2).equals("BD") ) {
					hm = getSSGPointRslt_DTL(strRecord);
					hm.put("CO_CD", com_cd);
					hm.put("TRANS_DATE", trans_date);
					hm.put("USE_SAVE_TP", Integer.toString(type));
					try {
						dao.insSSGPointRslt(hm);
					}catch(Exception e) {
						logger.info("[ERROR] Error for inserting data : " + e.getMessage());
					}
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private HashMap<String, String> getSSGPointRslt_HDR(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,8,190};
		String strHeaders[] = {
			"RECORD_TP",
			"TRANS_DATE",
			"FILLER"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
//		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info("[DEBUG] " + strHeaders[i] + "=" + (String)hm.get(strHeaders[i]));
//		}
		
		return hm;
	}
	
	private HashMap<String, String> getSSGPointRslt_DTL(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,8,20,21,1
					  ,10,20,8,8,20
					  ,20,62};
		String strHeaders[] = {
			"RECORD_TP",
			"APPROVAL_DT",
			"APPROVAL_NO",
			"TRAN_ID",
			"TYPE",
			
			"POINT",
			"CARD_NO",
			"TRAN_DT",
			"ORGTRAN_APPR_DT",
			"ORGTRAN_APPR_NO",
			
			"CARD_OWNER_NM",
			"FILLER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
//		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info("[DEBUG] " + strHeaders[i] + "=" + (String)hm.get(strHeaders[i]));
//		}
		
		return hm;
	}
	
	public void moveFile(String orgPath, String fileNM, String destPath) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdir();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		logger.info("orgFile = " + orgPath + File.separator + fileNM);
		logger.info("destFile = " + destPath + File.separator + fileNM);
		
		if( destFile.exists() ) {
			if( orgFile.delete() ) {
				logger.info("[DEBUG] File(" + orgFile.getPath() + " / "+ orgFile.getName() + ") Deleted");
			}else {
				logger.info("[DEBUG] Fail to remove file(" + orgFile.getPath() + " / "+ orgFile.getName() + ")");
			}
		}else {
			for(int i = 0;i < 20;i++) {
				if( orgFile.renameTo(destFile) ) {
					logger.info(">> MOVE OK : " + destFile.getName());
					break;
				}
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					logger.info("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();
			
			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
//			dirFileList = Arrays.asList(files);
		}
		
		return dirFileList;
	}
}