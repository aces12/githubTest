/*
 * MasterDAO.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */

package biz.cms_MasterAgent_New;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;


import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.DataTypes;
   
/** 
 * MasterAgentDAO
 * A class that has inherited GenericDAO(GenericDAO를 상속받은 클래스)
 * It is responsible for functions to access DB to retrieve respective information(DB에 접속하여 해당 정보를 조회해 오거나)
 * or update DB information(DB정보를 업데이트 하는 기능을 담당한다).
 * @created  on 1.0,  11/03/17
 * @created  khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok 
 * @caused   by  
 */ 
public class MasterAgentDAO extends GenericDAO{	
	private static Logger logger = Logger.getLogger(MasterAgentPollingAction_M.class);

	/**
	 * 마스터파일 생성 실행 30분 내 배신생성중(OPER_ID=1) ROW 조회
	 * @return list size
	 * @exception exception Description of Exception
	 */
	public int selCNTINPROGRESS(String transYMD_1, String transYMD_2, String localNo) {
		List<Object> result = null;
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = 0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_INPROGRESS"));
			sql.setString(++i, transYMD_1);
			sql.setString(++i, transYMD_2);
			sql.setString(++i, localNo);
			result = executeQuery(sql);
			
			rows = result.size();
		}catch(Exception e) {
			logger.info("[ERROR]selCNTINPROGRESS::" + e.getMessage());
		}
		
		return rows;
	}
	
	public int selCNTINPROGRESS_M(String transYMD_1, String transYMD_2, String localNo) {
		List<Object> result = null;
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = 0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_INPROGRESS_M"));
			sql.setString(++i, transYMD_1);
			sql.setString(++i, transYMD_2);
			sql.setString(++i, localNo);
			result = executeQuery(sql);
			
			rows = result.size();
		}catch(Exception e) {
			logger.info("[ERROR]selCNTINPROGRESS::" + e.getMessage());
		}
		
		return rows;
	}
	/**
     * 정기배신 마스터파일 생성여부 조회 
     * @return Master Info List(마스터정보목록)
     * @exception exception Description of Exception(예외사항설명)
     */
	public List selMASTERAGENTDAILY(String transYmd) {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_MASTERAGENTDAILY"));
			sql.setString(++i, transYmd);	// trans_ymd
			//logger.info("[DEBUG]selMASTERAGENTDAILY::" + sql.debug());
			list = executeQuery(sql);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			logger.info("[ERROR]selMASTERAGENTDAILY::" + e);
		} 
		
		return list;
	}
	
	/**
     * 수동배신 마스터파일 여부 조회 
     * @return Master Info List(마스터정보목록)
	 * @throws Exception 
     * @exception exception Description of Exception(예외사항설명)
     */
	public List selMASTERAGENTMANUAL(String transYmd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_MASTERAGENTMANUAL"));
			sql.setString(++i, transYmd);	// trans_ymd
			//logger.info("[DEBUG]selMASTERAGENTMANUAL::" + sql.debug());
			list = executeQuery(sql);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			logger.info( sql.debug());
			logger.info("[ERROR]selMASTERAGENTMANUAL::" + e);
		} 
		
		return list;
	} 
	
	/**
     * 수동배신 프로그램,긴급메시지 생성  여부 조회 
     * @return Master Info List(마스터정보목록)
	 * @throws Exception 
     * @exception exception Description of Exception(예외사항설명)
     */
	public List selPGMMANUAL(String transYmd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_PGMMANUAL"));
			sql.setString(++i, transYmd);	// trans_ymd
			list = executeQuery(sql);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			logger.info("[ERROR]debug::" + sql.debug());
			logger.info("[ERROR]SEL_PGMMANUAL::" + e);
		} finally{
			end();
		}
		
		return list;
	} 
	
	/**
     * 수동배신 프로그램,긴급메시지 생성  여부 조회 
     * @return Master Info List(마스터정보목록)
	 * @throws Exception 
     * @exception exception Description of Exception(예외사항설명)
     */
	public List selMSGMANUAL(String transYmd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_MSGMANUAL"));
			sql.setString(++i, transYmd);	// trans_ymd
			list = executeQuery(sql);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			logger.info("[ERROR]debug::" + sql.debug());
			logger.info("[ERROR]SEL_MSGMANUAL::" + e);
		}finally{
			end();
		} 
		
		return list;
	} 
	/**
     * 수동배신 FFIMG 생성  여부 조회 
     * @return Master Info List(마스터정보목록)
	 * @throws Exception 
     * @exception exception Description of Exception(예외사항설명)
     */
	public List selFFIMGMANUAL(String transYmd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_FFIMGMANUAL"));
			sql.setString(++i, transYmd);	// trans_ymd
			list = executeQuery(sql);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			logger.info("[ERROR]debug::" + sql.debug());
			logger.info("[ERROR]SEL_FFIMGMANUAL::" + e);
		} finally{
			end();
		}
		
		return list;
	} 
	
	
	/**
     * 정기마스터 배신정보 생성 프로시저 
     * @return Result code (결과코드)
     * @exception exception Description of Exception(예외사항설명)
     */
	public int procMSTINFOCRT(Map map) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		String tran_ymd = (String)map.get("tran_ymd");
		String com_cd = (String)map.get("com_cd");
		String store_cd = (String)map.get("store_cd");
		String create_ty = (String)map.get("create_ty");
		String server_no = (String)map.get("server_no");
		int i=0;
		int ret=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

			logger.info("tran_ymd:"   + tran_ymd);
			logger.info("com_cd:"     + com_cd);
			logger.info("store_cd:"   + store_cd);
			logger.info("create_ty:"   + create_ty);
			
			logger.info("[DEBUG] [procMSTINFOCRT] Begin");
			proc.put("SP_MSTINFO_CRT_SER", 7);
			proc.setString(++i, tran_ymd);	// tran_ymd
			proc.setString(++i, com_cd);	// com_cd
			proc.setString(++i, store_cd);	// store_cd
			proc.setString(++i, create_ty);	// create_ty
			proc.setString(++i, server_no);	// server_no
			proc.registerOutParameter(++i, DataTypes.INTEGER);
			proc.registerOutParameter(++i, DataTypes.VARCHAR);

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			ret = prs.getInt(6);
			String retMsg = prs.getString(7);
			logger.info("[DEBUG] [procMSTINFOCRT] ResultMsg:" + retMsg);
			logger.info("[DEBUG] [procMSTINFOCRT] End");
		} catch (Exception e) {
			rollback();
			System.out.println(e.getMessage());
			logger.info("[ERROR] procMSTINFOCRT::" + e);
			ret=-1;
		} finally {
			// 모든 trasaction을 종료하고 리소스를 반납합니다.
			end();
		}
		
		return ret;
	}
	
	/**
     * 마스터 생성 배치 프로시저 
     * @return Result (결과코드)
     * @exception exception Description of Exception(예외사항설명)
     */
	public int procMSTMERGEAT2ST() throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		int i=0;
		int ret=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

			logger.info("[DEBUG] [procMSTMERGEAT2ST] Begin");
			proc.put("SP_MSTMERGEAT2ST", 2);
			proc.registerOutParameter(++i, DataTypes.INTEGER);
			proc.registerOutParameter(++i, DataTypes.VARCHAR);

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			ret = prs.getInt(1);
			String retMsg = prs.getString(2);
			logger.info("[DEBUG] [procMSTMERGEAT2ST] ResultMsg:" + retMsg);
			logger.info("[DEBUG] [procMSTMERGEAT2ST] End");
		} catch (Exception e) {
			rollback();
			System.out.println(e.getMessage());
			logger.info("[ERROR] procMSTMERGEAT2ST::" + e);
			ret=-1;
		} finally {
			// 모든 trasaction을 종료하고 리소스를 반납합니다.
			end();
		}
		
		return ret;
	}

	/**
     * 배치 프로시저 
     * @return Result (결과코드)
     * @exception exception Description of Exception(예외사항설명)
     */
	public int procBATCHSCHEDULE() throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		int i=0;
		int ret=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			begin();

			logger.info("[DEBUG] [procBATCHSCHEDULE] Begin");
			proc.put("SP_BATCH_SCHEDULE", 2);
			proc.registerOutParameter(++i, DataTypes.INTEGER);
			proc.registerOutParameter(++i, DataTypes.VARCHAR);

			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			ret = prs.getInt(1);
			String retMsg = prs.getString(2);
			logger.info("[DEBUG] [procBATCHSCHEDULE] ResultMsg:" + retMsg);
			logger.info("[DEBUG] [procBATCHSCHEDULE] End");
		} catch (Exception e) {
			rollback();
			System.out.println(e.getMessage());
			logger.info("[ERROR] procBATCHSCHEDULE::" + e);
			ret=-1;
		} finally {
			// 모든 trasaction을 종료하고 리소스를 반납합니다.
			end();
		}
		
		return ret;
	}
	
	
	
	/**
	 * 배신완료 마스터 예약
	 * @return : 예약건수
	 */
	public int updMASTERTARGETSEL(String trans_seq, String strOTPVal, String PROC_ID, String localNo, String trans_id) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		int rows=-1;
		int sequence = 0;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			

			i = 0;
			sql.clearParameter();
						
			sql.put(findQuery("stsys-sql", "UPD_MASTERTARGETSEL"));
			sql.setString(++i, PROC_ID);
			sql.setString(++i, localNo);
			sql.setString(++i, trans_seq);
			sql.setString(++i, trans_id);
			rows = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	/**
	 * 예약된 배신완료 조회
	 * @return : 조회목록
	 * @throws Exception 
	 */
	public List<Object> selTARGETMASTERLIST(String strOTPVal, String localNo,String trans_seq) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("stsys-sql", "SEL_TARGETMASTERLIST"));
			//sql.setString(++i, strOTPVal);			
			sql.setString(++i, trans_seq);
			sql.setString(++i, localNo);
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("sql.debug()"+ sql.debug());
			logger.info("[ERROR]selTARGETMASTERLIST::" + e);
		}finally{
			end();
		}
		
		return list;
	}

	
	
	public List<Object> selURGENTMSGLIST(Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("stsys-sql", "SEL_URGENTMSGLIST"));
			sql.setString(++i, (String)map.get("TRANS_YMD"));
			sql.setString(++i, (String)map.get("STORE_CD"));
			sql.setString(++i, (String)map.get("POS_NO"));
			sql.setString(++i, (String)map.get("TRANS_ID"));
			sql.setInt(++i, Integer.parseInt((String)map.get("TRANS_SEQ")));
			//sql.setString(++i, (String)map.get("TRANS_SEQ"));
			sql.setString(++i, (String)map.get("COM_CD"));
			
			list = executeQuery(sql);
			//logger.info("selURGENTMSG::" + sql.debug());
		}catch(Exception e) {
			
			logger.info("[ERROR]selURGENTMSGLIST::" + e);
		}finally{
			end();
		}
		
		return list;
	}
	

	/**
	 * 3회 재전송 후에도 배신실패한 마스터에 대해 PROC_ID = 4 로 업데이트 함 
	 * @return : 예약건수
	 */
	public int updMASTERNEWDEPLOYEND(String strOTPVal, String localNo , String trans_seq) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		int rows=-1;
		int sequence = 0;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			

			i = 0;
			sql.clearParameter();
						
			sql.put(findQuery("stsys-sql", "UPD_MASTERNEWDEPLOYEND"));
			sql.setString(++i, strOTPVal);
			sql.setString(++i, localNo);
			sql.setString(++i, trans_seq);
			rows = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	
	// PROC_ID = "0":미송신, "1":송신중, "2":송신완료, "3":송신에러, "4":전송 3회 모두 송신실패 , "5": POS IP 없음
	public int updTARGETMASTERLIST(Map<String, String> map, String PROC_ID) {
		SqlWrapper sql = new SqlWrapper();
		int i=0;
		int rows=-1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("stsys-sql", "UPD_TARGETMASTERLIST"));
			sql.setString(++i, PROC_ID);
			sql.setString(++i, (String)map.get("TRANS_YMD"));
			sql.setString(++i, (String)map.get("STORE_CD"));
			sql.setString(++i, (String)map.get("POS_NO"));
			sql.setString(++i, (String)map.get("TRANS_ID"));
			sql.setInt(++i, Integer.parseInt((String)map.get("TRANS_SEQ")));
			//sql.setString(++i, (String)map.get("TRANS_SEQ"));
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]updTARGETMASTERLIST::" + e);
		}finally {
			end();
		}
		
		return rows;
	}
	
	
	/**
     * Search stores to create master data file(PUSH MSG 전송할 POS 조회)
     * @return List Store List(POS목록)
     * @exception exception Description of Exception(예외사항설명)
     */
	public List selSTBDA100ATOri(String transYmd, String com, String store, String local_no) {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		int i=0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_STBDA100AT_ORI"));
			sql.setString(++i, transYmd);	// trans_ymd
			sql.setString(++i, com);	// com_cd
			sql.setString(++i, store);	// store_cd
			sql.setString(++i, local_no);	// store_cd
			list = executeQuery(sql);
			logger.info("[DEBUG]" + sql.debug());
		} catch (Exception e) {
//			System.out.println(e.getMessage());
			logger.info("[ERROR]" + e);
		} 
		
		return list;
	}
	
	//selSendPushPosLIST(local_no,(String)map.get("TRANS_SEQ"),(String)map.get("STORE_CD"));
	/**
	 *  마스터 생성직후 push msg pos list 조회
	 * @return : pos list
	 * @throws Exception 
	 */
	public List<Object> selSendPushPosLIST(String trans_ymd , String localNo,String trans_seq, String store_cd,String trans_id) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("stsys-sql", "SEL_SENDPUSHPOSLIST"));
			sql.setString(++i, trans_ymd);
			sql.setString(++i, trans_seq);
			sql.setString(++i, localNo);
			sql.setString(++i, store_cd);
			sql.setString(++i, trans_id);
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("sql.debug()"+ sql.debug());
			logger.info("[ERROR]selTARGETMASTERLIST::" + e);
		}finally{
			end();
		}
		
		return list;
	}
	
	//selSendPushPosLIST(local_no,(String)map.get("TRANS_SEQ"),(String)map.get("STORE_CD"));
	/**
	 *  마스터 생성직후 push msg pos list 조회
	 * @return : pos list
	 * @throws Exception 
	 */
	public List<Object> selSendPushPosLISTPGM(String trans_ymd , String localNo,String trans_seq, String store_cd,String trans_id) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i=0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("stsys-sql", "SEL_SENDPUSHPOSLISTPGM"));
			sql.setString(++i, trans_ymd);
			sql.setString(++i, trans_seq);
			sql.setString(++i, localNo);
			sql.setString(++i, store_cd);
			sql.setString(++i, trans_id);
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("sql.debug()"+ sql.debug());
			logger.info("[ERROR]SEL_SENDPUSHPOSLISTPGM::" + e);
		}finally{
			end();
		}
		
		return list;
	}
	
	
	// PROC_ID = "0":미송신, "1":송신중, "2":송신완료, "3":송신에러, "4":전송 3회 모두 송신실패 , "5": POS IP 없음
	public int updOPERIDFLAG3FAIL(Map<String, String> map) {
		SqlWrapper sql = new SqlWrapper();
		int i=0;
		int rows=-1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("stsys-sql", "UPD_OPERIDFLAG3FAIL"));
			sql.setString(++i, (String)map.get("TRANS_YMD"));
			sql.setString(++i, (String)map.get("TRANS_ID"));
			sql.setInt(++i, Integer.parseInt((String)map.get("TRANS_SEQ")));
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]updOPERIDFLAG::" + e);
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int selCNTINDEPLOYPROGRESS(String trans_ymd, String localNo) {
		List<Object> result = null;
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = 0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_INPROGRESS"));
			sql.setString(++i, trans_ymd);
			sql.setString(++i, localNo);
			result = executeQuery(sql);
			
			rows = result.size();
			if (rows>1){
				logger.info("[SEL_INPROGRESS]"+ sql.debug());
			}
		}catch(Exception e) {
			logger.info("[ERROR]selCNTINPROGRESS::" + e.getMessage());
		}
		finally{
			end();
		}
		
		return rows;
	}
	
}
