package biz.cms_MCBSender;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

public class MCBSenderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(MCBSenderPollingAction.class);
	
	public static void main(String args[]) throws Exception {
		MCBSenderPollingAction action = new MCBSenderPollingAction();
		
		try {
			if (args == null || args.length < 1) {
				logger.info("------ master main args null");
			}
			System.out.println("[DEBUG] [args[0]]=" + args[0] );
			System.out.println("[DEBUG] [args[0]]=" + args[1] );
			
			String path          = nvl(args[0].replaceFirst("-path:"  ,""));
			String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));
			
			DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
			
			if( cmd.length() != 2 ) return;
			
			if( cmd.charAt(0) == '1' ) {
				logger.info("start create file");
				System.out.println("creating MCB Payment tran file.");
				action.createMCBPAYTranFile();
			}
			
			
			if( cmd.charAt(1) == '1' ) {
				System.out.println("transfering MCB tran files.");
				(new MCBSenderFileTransfer()).transferMST();
			}
		}catch(Exception e) {
			logger.info("[ERROR] " + e.getMessage());
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		MCBSenderDAO dao = new MCBSenderDAO();
		List<Object> list = null;
		int totalCnt = 0;
		
		try {
			int ret = -1;
			
			if( actionMode != "1" ) return;
			// actionMode : 0-POLLING_PERIOD에 주기적으로 무조건 수행, 1-ACTION_TIME에 한 번 수행
			logger.info("actionMode[" + actionMode + "]");
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String stdYmd = sdf.format(new Date());
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			
			//(금일 대사파일 생성 유무 조회)
			list = dao.selSVCFILEDAILY(stdYmd, "MCB", "01", com_cd); // MCB로 송신 내역 있는지 확인 MCB는 생성해줘야 함.
			totalCnt = list.size();
			
//				System.out.println("totalCnt[" + totalCnt + "]" );	
			
			//금일 대사파일 생성 row가 없으면 생성
			if( totalCnt <= 0 ) {
				HashMap<String, String> hm = new HashMap<String, String>();
				hm.put("COM_CD", com_cd);
				hm.put("STD_YMD", stdYmd);
				hm.put("SVC_ID", "MCB");
				hm.put("CMD_TY", "00"); 
				// 신규 송신 내역을 만들어줌. 송신내역을 생성한 내역만 만들어서 STBDA200AT에 등록함.
				ret = dao.insSVCFILEINFO(hm);
				
				System.out.println("ret[" + ret + "]" );	
					
				if( ret > 0 ) {
					// 신규 송신 내역에 등록된 건이 있으면 파일 생성해줌.
					// 파일 생성 및 파일 내용 생성.
					createMCBPAYTranFile();
					Thread.sleep(50);
					
					try {
						// 파일 생성 되었으면 파일 송신해줌. 파일 송신 방법은 좀더 볼것.
						(new MCBSenderFileTransfer()).transferMST();
					}catch(Exception e) {
						System.out.println("[ERROR]" + e.getMessage() );	
						logger.info("[ERROR]" + e.getMessage());
					}
					hm.put("CMD_TY", "01");
					// 던지기 완료 했으면 01로 업데이트 침.
					ret = dao.updSVCFILEINFO(hm);
				}
			}

		}catch(Exception e) {
			logger.info("[ERROR]" + e.getMessage());
			System.out.println("[ERROR]" + e.getMessage() );	
		}
	}
	/* createMCBPAYTranFile
	 * 전송하기 위한 파일을 생성해 줌
	 */
	public boolean createMCBPAYTranFile() {
		boolean bIsCreatedFile = false;
		
		try {
			StringBuffer sbFile = new StringBuffer();
			List<Object> list = null;
			// 일자 조회
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			MCBSenderDAO dao = new MCBSenderDAO(); // 
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			calendar.setTime(new Date());
			String curDate = sdf.format(calendar.getTime());
			// APP_ROOT = "/home/withme/CMBO"
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			// /home/withme/CMBO/files/up/MCB/ 에 위치함 
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "MCB";
			// 1058692454 이건 이마트24가맹번호
			//String withme_corp_no = PropertyUtil.findProperty("service-property", "WITHME_CORP_NO");
			// 파일명 : WMPT+일자.txt
			String JOB_TP = "EMART24_";
			String strTRANFileNM = JOB_TP + curDate.substring(0,8) + ".txt"; //#### 확인
			
			list = null;
			// 점포 여신 일집계 내역 조회 해서 해당 내역이 있으면 
			list = dao.selMCBPAYTRAN();
			int iPayCnt = list.size();
			//logger.info("list[" + list + "]");
			System.out.println(" list : " + list);

			// 데이터 생성 
			// 만들 데이터는 
			// 1. 헤더 
			// 2. DATA
			// 3. TAIL
			// 취소 
			int cnclCnt=0 ,cnclAmt=0 ;
			// 승인
			int apprCnt=0 ,apprAmt=0 ;
			String recodeTp = "";
			
			for(int i = 0;i < iPayCnt;i++) {
				HashMap<String, String> hmData = new HashMap<String, String>();
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				// 조회 된 데이터가 있는 경우 파일에 등록할 전문 생성.
				
				if (i == 0){
					// 헤더 등록
					// 처음에 등록할때는 헤더 등록.
					// 0 레코드 구분
					// 1. 생성일
					// 2. 전송일

					hmData.put("RECODE_TP_H", "H"); // 헤더
					hmData.put("CRT_YMD", map.get("TRAN_YMD"));// 생성일
					hmData.put("SEL_YMD", map.get("TRAN_YMD"));// 거래일
					//logger.info("hmData " + i + " [" + hmData + "]");
					System.out.println(" hmData : " + hmData);
					sbFile.append(makeDataOfMCBFileHeader(hmData));
					sbFile.append("\r\n");					
				}

				// 2. 데이터 파일 등록
				recodeTp = map.get("RECODE_TP_D");
				hmData.put("RECODE_TP_D"	, recodeTp					 );
				hmData.put("STORE_CD"		, map.get("STORE_CD"		));
				hmData.put("POS_NO"			, map.get("POS_NO"			));
				hmData.put("CUL_TRACE_NO"	, map.get("CUL_TRACE_NO"	));
				hmData.put("TRACE_NO"		, map.get("TRACE_NO"		)); //영업일자8+점포코드5+pos번호4+거래번호4+시분초6 + 난수 2자리
				hmData.put("RESP_DY"		, map.get("RESP_DY"			));
				hmData.put("RESP_TM"		, map.get("RESP_TM"			));
				hmData.put("PIN_TRADE_AMT"	, map.get("PIN_TRADE_AMT"	));
				//로그 찍기
				System.out.println("hmData " + i + " [" + hmData + "]" );	
				
				//logger.info("hmData " + i + " [" + hmData + "]");
				sbFile.append(makeDataOfMCBFileData(hmData));
				sbFile.append("\r\n");
				
				// 3. TAIL 부분 등록용
				if (recodeTp.equals("C"))//취소
				{
					// 취소 건수/금액
					cnclCnt++;
					cnclAmt = cnclAmt + Integer.parseInt(map.get("PIN_TRADE_AMT"));
					System.out.println("cnclCnt  ["  + cnclCnt + "]["+cnclAmt+"]" );
					
				}else if(recodeTp.equals("A"))//승인
				{
					//승인인 경우
					apprCnt++;
					apprAmt = apprAmt + Integer.parseInt(map.get("PIN_TRADE_AMT"));
					System.out.println("apprCnt  ["  + apprCnt + "]["+apprAmt+"]" );
				}
					
				//TAIL 부분 만들기.
				if (i == (iPayCnt-1) ){
					// 끝부분에 수량 금액 등록
					hmData.put("RECODE_TP_T", "T"); // 끝
					hmData.put("TOT_CNT", map.get("CRT_YMD"));// 생성일
					hmData.put("TOT_CNT", StringUtil.lPad(String.valueOf(Integer.toString(iPayCnt)),8,"0"));
					hmData.put("APPR_CNT", StringUtil.lPad(String.valueOf(Integer.toString(apprCnt)),8,"0"));
					hmData.put("APPR_AMT", StringUtil.lPad(String.valueOf(Integer.toString(apprAmt)),10,"0"));
					hmData.put("CNCL_CNT", StringUtil.lPad(String.valueOf(Integer.toString(cnclCnt)),8,"0"));
					hmData.put("CNCL_AMT", StringUtil.lPad(String.valueOf(Integer.toString(cnclAmt)),10,"0"));
					logger.info("hmData " + i + " [" + hmData + "]");
					sbFile.append(makeDataOfMCBFileTail(hmData));
					sbFile.append("\r\n");
				}
			}
			
			
			// 거래내역 파일 생성                                                         
			bIsCreatedFile = ZipUtil.createFile(sbFile, destPath, strTRANFileNM);
			
			// 거래내역파일이 생성되었다면 일괄로 업데이트 STTRP375DT에 처리 ID를 '1' 파일 생성 으로 업데이트
			// 파일 생성 시 처리상태구분코드 Update
			if( bIsCreatedFile ) {
				logger.info(" >>>>>>>>>>>>> Created File " + strTRANFileNM);
				for(int i = 0;i < iPayCnt ;i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					dao.updMCBTRAN("1"
							      , (String)map.get("COM_CD")
							      , (String)map.get("TRAN_YMD")
							      , (String)map.get("STORE_CD")
							      , (String)map.get("POS_NO")
							      , (String)map.get("TRAN_NO") 
							      , (String)map.get("ITEM_SEQ") 
							      );
				}
			}
		}catch(Exception e) {
			System.out.println("[ERROR]" + e);	
			logger.info("[ERROR]" + e);
		}
		
		return bIsCreatedFile;
	}
	// 파일에 헤더를 쓸수 있도록 변환 하여 리턴
	private String makeDataOfMCBFileHeader(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1,8,8};
		String strHeaders[] = {   "RECODE_TP_H"
								, "CRT_YMD"
								, "SEL_YMD"
								};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info(i+":"+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		System.out.println(sb.toString());
		logger.info(sb.toString());
		return sb.toString();
	}
	
	private String makeDataOfMCBFileData(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		/* 레코드 구분 : A.승인 / C취소 :  를 조회해서 등록 필요 . DECODE( TRAN_TP , '0','A' , '1' , 'C' , ' ') RECODE_TP 
		 * 점포코드 : 6             	STORE_CD
		 * POS번호 : 4             	POS_NO
		 * 모바일쿠폰번호 : 16        	PIN_NO
		 * 컬처랜드 거래번호 : 25      	CUL_TRACE_NO
		 * TRACE_NO : 50         	영업일자8+점포코드5+pos번호4+거래번호4+시분초6
		 * 승인일자 : 8             	RESP_DY
		 * 승인시간 : 6             	RESP_TM
		 * 승인금액 : 9       			PIN_TRADE_AMT ??? 이금액이 뭔지 확인 필요
		 * 
		 * 총 155 bytes  
		 * */
		int nlens[] = {  1, 6, 4 
				      ,25,50
				      ,  8, 6, 9};
		String strHeaders[] = 	{ "RECODE_TP_D"
								, "STORE_CD"
								, "POS_NO"
								
								, "CUL_TRACE_NO"
								, "TRACE_NO"
								
								, "RESP_DY"
								, "RESP_TM"
								, "PIN_TRADE_AMT"
								};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info(i+":"+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		System.out.println(sb.toString());
		logger.info(sb.toString());
		return sb.toString();
	}
	
	
	private String makeDataOfMCBFileTail(HashMap<String, String> hm) {
		//TAIL 부분 만들기.
		/*
		 * 1.레코드구분 : 1
		 * 2. 전송건수 : 총 수량 등록
		 * 3. 승인건수 : 승인인 건에 대한 수량 ++ 
		 * 4. 승인금액 : 승인인 건에 대한 승인금액 추가
		 * 5. 취소건수 : 취소건에 대한 수량++
		 * 6. 취소금액 : 취소건에 대한 금액
		 * 45bytes
		 */
		StringBuffer sb = new StringBuffer();
		int nlens[] = {1, 8, 8, 10, 8, 10 };
		String strHeaders[] =   { "RECODE_TP_T"
								, "TOT_CNT"
								, "APPR_CNT"
								, "APPR_AMT"
								, "CNCL_CNT"
								, "CNCL_AMT"
								, "FILLER"
								};
		
		for( int i = 0;i < nlens.length;i++ ) {
//			logger.info(i+":"+(String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		System.out.println(sb.toString());
		logger.info(sb.toString());
		return sb.toString();
	}
}
