/*
 * MasterDAO.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */

package biz.cms_SysDeployMonitor;


import java.util.List;


import org.apache.log4j.Logger;



import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;


/** 
 * MasterAgentDAO
 * A class that has inherited GenericDAO(GenericDAO를 상속받은 클래스)
 * It is responsible for functions to access DB to retrieve respective information(DB에 접속하여 해당 정보를 조회해 오거나)
 * or update DB information(DB정보를 업데이트 하는 기능을 담당한다).
 * @created  on 1.0,  11/03/17
 * @created  khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok 
 * @caused   by  
 */ 


public class SysDeployMonitorDAO extends GenericDAO{	
	private static Logger logger = Logger.getLogger(SysDeployMonitorPollingAction.class);


	/**
	 * 배신완료 후 1시간 이상 pos 단에서 배신 진행 없을경우 
	 * @return list size
	 * @throws Exception 
	 * @exception exception Description of Exception
	 */
	public int selStopPROGRESS(String transYMD_1, String transYMD_2, String localNo) throws Exception {
		List<Object> result = null;
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = 0;
		//DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("stsys-sql", "SEL_STOP_PROGRESS"));
			sql.setString(++i, transYMD_1);
			sql.setString(++i, transYMD_2);
			sql.setString(++i, localNo);
			result = executeQuery(sql);
			//logger.info("[info]SEL_STOP_PROGRESS::" + sql.debug());
			rows = result.size();
		}catch(Exception e) {
			logger.info("[ERROR]SEL_STOP_PROGRESS::" + e.getMessage());
			logger.info("[info]SEL_STOP_PROGRESS::" + sql.debug());
		}
		
		return rows;
	}
	
	
	
	/**
	 * 배신완료 후 1시간 이상 pos 단에서 배신 진행 없을경우 
	 * 마스터 배신 절차 배신완료 에서 더이상 진행 없을때 준비완료로 oper_id update 함 
	 */
	public int updOPERID(String transYMD_1, String transYMD_2, String localNo) {
		List<Object> result = null;
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = 0;
		try {	
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");
			 
			sql.clearParameter();
			sql.put(findQuery("stsys-sql", "UPD_OPERID"));
			sql.setString(++i, transYMD_1);
			sql.setString(++i, transYMD_2);
			sql.setString(++i, localNo);
			//logger.info("[info]updOPERID::" + sql.debug());
			rows = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]updOPERID::" + e.getMessage());
		}finally {
			end();
			logger.info("[info]applied::rows->" + rows);
		}
		
		return rows;
	}	
	
	
	
	
}
