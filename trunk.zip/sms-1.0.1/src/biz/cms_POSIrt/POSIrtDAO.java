package biz.cms_POSIrt;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;

import biz.comm.COMMLog;

public class POSIrtDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(POSIrtAction.class);
	
	public String getStrStockNowForCigar(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
		
		String dataMsg = "";		
		String ret = "00";
		
		try {
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("pos-sql", "SEL_STRSTOCKNOW_CIGAR"));
			sql.setString(++i, "A16" + (String)hmComm.get("STORE_CD"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			sql.setString(++i, "A16" + (String)hmComm.get("STORE_CD"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			
			list = executeQuery(sql);
			if( list.size() > 0 ) {
				map = (Map)list.get(0);
				
				hm.put("NSTCK_QTY1", (String)map.get("NSTCK_QTY1"));
				hm.put("NSTCK_QTY2", (String)map.get("NSTCK_QTY2"));
			}else {
				hm.put("NSTCK_QTY1", "0");
				hm.put("NSTCK_QTY2", "0");
			}
			
			hm.put("FILLER", " ");
		}catch(SQLException e) {
			ret = "20";
		}catch(Exception e) {
			ret = "29";
			df.CommLogger("[ERROR] errMsg::["+e.getMessage()+"]");
			df.CommLogger("[ERROR] errMsg::["+e.getCause()+"]");
			throw e;
		}finally {
			dataMsg = ret + makeSendDataStrStockNow(hm, df);
		}
		
		return dataMsg;
	}
	
	public String getStrStockNowForItem(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
	
		String dataMsg = "";		
		String ret = "00";
		
		try {
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("pos-sql", "SEL_STRSTOCKNOW_ITEM"));
			sql.setString(++i, "A16" + (String)hmComm.get("STORE_CD"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("ITEM_CD"));
			
//			df.CommLogger("sql : " + sql.debug());
			list = executeQuery(sql);
			if (list.size() > 0) {
				map = (Map) list.get(0);
				
				hm.put("NSTCK_QTY1", (String)map.get("NSTCK_QTY1"));
			}else {
				hm.put("NSTCK_QTY1", "0");
			}
			
			hm.put("NSTCK_QTY2", "0");
			hm.put("FILLER", " ");
			
		}catch(SQLException e) {
			ret = "20";
		}catch(Exception e) {
			ret = "29";
			df.CommLogger("[ERROR] errMsg::["+e.getMessage()+"]");
			df.CommLogger("[ERROR] errMsg::["+e.getCause()+"]");
			throw e;
		}finally {
			dataMsg = ret + makeSendDataStrStockNow(hm, df);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataStrStockNow(HashMap<String, String> hm, COMMLog df) throws Exception {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 30, 1, 10, 10, 100 };
		String strHeaders[] = {
				"INQ_TYPE",
				"ITEM_CD",
				"OPTION",
				"NSTCK_QTY1",
				"NSTCK_QTY2",
				"FILLER"
		};

		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	public String setDeliveryCheck(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
//		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		
		String dataMsg = "";
		String ret = "00";
		String res_cd = "00";
		String retMsg = "";
		
		try{
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			//df.CommLogger("[DEBUG] [SP_ST_STRDVYSTRARR_TRN] Begin");
			proc.put("SP_ST_STRDVYSTRARR_TRN", 8);
			proc.setString(++i, (String)hmComm.get("COM_CD"));
			proc.setString(++i, (String)hm.get("STORE_CD"));
			proc.setString(++i, (String)hm.get("POS_NO"));
			proc.setString(++i, (String)hm.get("INVOICE_NUMBER"));
			proc.setString(++i, (String)hm.get("REG_YMD"));
			proc.setString(++i, (String)hm.get("REG_HMS"));
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE
			
			ProcedureResultSet prs = super.executeUpdateProcedure(proc);
			res_cd = String.format("%02d", prs.getInt(7));
			retMsg = prs.getString(8);
			
			if( prs.getInt(7) != 0 ) {
				res_cd = "99";
			}
			hm.put("RES_CD", res_cd);
			hm.put("RES_MSG", retMsg);
		}catch(Exception e) {
			rollback();
			ret = "29";
			df.CommLogger("[ERROR] errMsg::["+e.getMessage()+"]");
			df.CommLogger("[ERROR] errMsg::["+e.getCause()+"]");
			throw e;
		}finally {
			dataMsg = ret + makeSendDataDeliveryCheck(hm, df);
			end();
		}
		
		return dataMsg;
	}
	
	private String makeSendDataDeliveryCheck(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2};
		String strHeaders[] = {
			"INQ_TYPE",
			"RES_CD"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	public String getRecptPromCoupon(String COM_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
		int i = 0;
		int ret = 0;
		StringBuffer sb = new StringBuffer();
		String strCouponNo = "";
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			begin();
			
			proc.put("SP_ST_PROMOTIONCOUPON_GET", 7);
			proc.setString(++i, COM_CD);
			proc.setString(++i, (String)hm.get("STORE_CD"));
			proc.setString(++i, (String)hm.get("POS_NO"));
			proc.setString(++i, (String)hm.get("TRAN_YMD"));
			proc.setString(++i, (String)hm.get("TRAN_NO"));
			proc.registerOutParameter(++i, DataTypes.INTEGER);
			proc.registerOutParameter(++i, DataTypes.VARCHAR);
			
			ProcedureResultSet prs = super.executeUpdateProcedure(proc);
			
			ret = prs.getInt(6);
			strCouponNo = prs.getString(7);
			
			if( strCouponNo.equals("NG") ) {
				strCouponNo = " ";
			}
			
		}catch(Exception e) {
			rollback();
			ret = 5;
			throw e;
		}finally {
			end();
			StringUtil.appendSpace(sb, "00", 2);
			StringUtil.appendSpace(sb, (String) hm.get("INQ_TYPE"), 2);
			StringUtil.appendSpace(sb, String.format("%02d", ret), 2);
			StringUtil.appendSpace(sb, strCouponNo, 30);
		}
		
		return sb.toString();
	}
	
	public String getPosSettInfo(String COM_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
		
		StringBuffer sb = new StringBuffer();
		String dataMsg = "";
		String retMsg = "NG";
		String ret = "00";
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("pos-sql", "SEL_POSSETT_INFO"));
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD"));
			sql.setString(++i, (String)hm.get("POS_NO"));
			sql.setString(++i, COM_CD);
			
			list = executeQuery(sql);
			
			hm.put("FILLER1", " ");
			hm.put("FILLER2", " ");
			hm.put("FILLER3", " ");
			hm.put("FILLER4", " ");
			if( list.size() > 0 ) {
				map = (Map) list.get(0);
				hm.put("RESULT_CD", "00");
				hm.put("VAN_ID", (String)map.get("VAN_ID"));
				hm.put("VAN_TID", (String)map.get("VAN_TID"));
				hm.put("TM_FCSTR_ID", (String)map.get("TM_FCSTR_ID"));
				hm.put("TM_TID", (String)map.get("TM_TID"));
			}else {
				hm.put("RESULT_CD", "99");
				hm.put("VAN_ID", " ");
				hm.put("VAN_TID", " ");
				hm.put("TM_FCSTR_ID", " ");
				hm.put("TM_TID", " ");
			}
		}catch(Exception e) {
			rollback();
			ret = "29";
			df.CommLogger("[ERROR] errMsg::["+e.getMessage()+"]");
			df.CommLogger("[ERROR] errMsg::["+e.getCause()+"]");
			throw e;
		}finally {
			end();
			dataMsg = ret + makePosSettInfo(hm, df);
		}
		
		return dataMsg;
	}
	
	private String makePosSettInfo(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2,  2, 10, 10, 10,
					   10, 20, 20, 20, 20 };
		String strHeaders[] = {
			"INQ_TYPE" 		,
			"RESULT_CD"		,
			"VAN_ID"		,
			"VAN_TID"		,
			"TM_FCSTR_ID"	,
			"TM_TID"		,
			"FILLER1"		,
			"FILLER2"		,
			"FILLER3"		,
			"FILLER4"
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger(strHeaders[i].toString() + "=" + (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	public String setParcelServiceCpl(String COM_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
		int nRows = 0;
		
		String dataMsg = "";
		String inqType = "";
		String ret = "00";
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			for(int n = 0;n < Integer.parseInt((String)hm.get("PARCEL_CNT").trim());n++) {
				i = 0;
				if( n > 0 ) sql.clearParameter();
				sql.put(findQuery("pos-sql", "UPD_PARCELSVC_CPL"));
				sql.setString(++i, (String)hm.get("STORE_CD"));
				sql.setString(++i, (String)hm.get("PARCEL_CD"+Integer.toString(n)));
				sql.setString(++i, COM_CD);
				
				executeUpdate(sql);
				sql.close();
			}
		}catch(Exception e) {
			rollback();
			ret = "29";
			logger.info("[ERROR] PARCEL CPL ERR : "+e.getMessage());
			throw e;
		}finally {
			end();
			if("C1".equals((String)hm.get("INQ_TYPE"))){ //20170816 KSN 한진택배서비스 영수증 집계 완료 응답
				inqType = "C2";
			}else{
				inqType = (String)hm.get("INQ_TYPE");
			}
			dataMsg = ret + inqType + ret;
		}
		
		return dataMsg;
	}
	
	public String getParcelCDCheck(String COM_CD, String STORE_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql1 = new SqlWrapper();
		List<Object> chklist = null;
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
		int nRows = 0;
		
		String dataMsg = "";
		String ret = "00";
		String PARCEL_CMP_TP = "01";
		String chkMsg = "";
		
		try {
			connect("CMGNS");	// DB Connection(DB 접속)
			String parcelCd = (String)hm.get("PARCEL_CD").trim();
			
			//20180316 KSN 정상발번 운송장번호여부 체크 추가
			if(parcelCd.startsWith("772")){
				sql1.put(findQuery("pos-sql", "SEL_LABEL_PARCEL_CHK"));
				sql1.setString(++i, parcelCd);
				
				chklist = executeQuery(sql1);
				
				if(chklist.size() < 1){
					chkMsg = "EM";
				}
			}
			
			if(!"EM".equals(chkMsg)){
				i = 0;
				if(parcelCd.startsWith("771") || parcelCd.startsWith("772")){ //한진택배
					if(!"EM".equals(chkMsg)){
						PARCEL_CMP_TP = "02";
						
						sql.put(findQuery("pos-sql", "SEL_HJPARCELCD_CHK"));
						sql.setString(++i, parcelCd);
						sql.setString(++i, COM_CD);
						sql.setString(++i, PARCEL_CMP_TP); //20170809 KSN 한진택배서비스
					}
				}else{ //cj대한통운
					PARCEL_CMP_TP = "01";
					sql.put(findQuery("pos-sql", "SEL_PARCELCD_CHK"));
					sql.setString(++i, STORE_CD);
					sql.setString(++i, parcelCd);
					sql.setString(++i, COM_CD);
					sql.setString(++i, PARCEL_CMP_TP); //20170809 KSN 한진택배서비스
				}
				
				list = executeQuery(sql);
				if(list.size() == 0){
					chkMsg = "OK";
				}else{
					chkMsg = "NG";
				}
			}
			
			//nRows = list.size();
		}catch(Exception e) {
			ret = "29";
			logger.info("[ERROR]PARCEL_NO_CHK ERR : "+e.getMessage());
			logger.info("[ERROR]PARCEL_NO_CHK ERR : "+sql1.debug());
			logger.info("[ERROR]PARCEL_NO_CHK ERR : "+sql.debug());
			throw e;
		}finally {
			dataMsg = ret + (String)hm.get("INQ_TYPE") + chkMsg; 
			logger.info("[INFO]dataMsg::["+dataMsg+"]");
		}
		
		return dataMsg;
	}
	
	
	public String getParcelServiceList(String COM_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
		int nRows = 0;
		
		String dataMsg = "";
		String ret = "00";
		
		try {
			begin();
			connect("CMGNS");	// DB Connection(DB 접속)
			
			sql.put(findQuery("pos-sql", "SEL_PARCELSVC_LIST"));
			sql.setString(++i, (String)hm.get("STORE_CD"));
			sql.setString(++i, COM_CD);
			sql.setString(++i, "01");
			
			list = executeQuery(sql);
			
			nRows = list.size();
			
			if( nRows > 0 ) {
				hm.put("PARCEL_CNT", Integer.toString(nRows));													// 거래건수
				for(int n = 0;n < nRows;n++) {												
					map = (Map<String, String>)list.get(n);
					hm.put("PARCEL_CD" + Integer.toString(n), (String)map.get("PARCEL_CD"));					// 운송장번호
					hm.put("PARCEL_PAY_TP" + Integer.toString(n), (String)map.get("PAYMENT_TP"));				// 선/착불 구분
					hm.put("PARCEL_BASE_AMT" + Integer.toString(n), (String)map.get("BASE_AMT"));				// 기본운임
					hm.put("PARCEL_PERRY_RTS_AMT" + Integer.toString(n), (String)map.get("PERRY_RTS_AMT"));		// 도선료
				}
			}else {
				hm.put("PARCEL_CNT", "0");				// 거래건수
				hm.put("PARCEL_CD0", " ");				// 운송장번호
				hm.put("PARCEL_PAY_TP0", " ");			// 선/착불 구분
				hm.put("PARCEL_BASE_AMT0", " "); 		// 기본운임
				hm.put("PARCEL_PERRY_RTS_AMT0", " ");	// 도선료
			}
		}catch(Exception e) {
			rollback();
			ret = "29";
			throw e;
		}finally {
			end();
			dataMsg = ret + makeParcelServiceList(nRows, hm, df);
		}
		
		return dataMsg;
	}
	
	
	public String getHJParcelServiceList(String COM_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
		int nRows = 0;
		
		String dataMsg = "";
		String ret = "00";
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("pos-sql", "SEL_HJ_PARCELSVC_LIST"));
			sql.setString(++i, (String)hm.get("STORE_CD"));
			sql.setString(++i, COM_CD);
			sql.setString(++i, "02");
			
			list = executeQuery(sql);
			
			nRows = list.size();
			
			if( nRows > 0 ) {
				hm.put("PARCEL_CNT", Integer.toString(nRows));															// 거래건수
				for(int n = 0;n < nRows;n++) {												
					map = (Map<String, String>)list.get(n);
					
					hm.put("PARCEL_CD" + Integer.toString(n), (String)map.get("PARCEL_CD"));							// 운송장번호
					hm.put("PARCEL_PAY_TP" + Integer.toString(n), (String)map.get("PAYMENT_TP").replaceAll("0", ""));	// 선/착불 구분
					hm.put("PARCEL_BASE_AMT" + Integer.toString(n), (String)map.get("BASE_AMT"));						// 기본운임
					hm.put("PARCEL_PERRY_RTS_AMT" + Integer.toString(n), (String)map.get("PERRY_RTS_AMT"));				// 도선료
					hm.put("PARCEL_ITEM_EXT_AMT" + Integer.toString(n), (String)map.get("ITEM_EXT_AMT"));				// 할증료
				}
			}else {
				hm.put("PARCEL_CNT", "0");				// 거래건수
				hm.put("PARCEL_CD0", " ");				// 운송장번호
				hm.put("PARCEL_PAY_TP0", " ");			// 선/착불 구분
				hm.put("PARCEL_BASE_AMT0", " "); 		// 기본운임
				hm.put("PARCEL_PERRY_RTS_AMT0", " ");	// 도선료
				hm.put("PARCEL_ITEM_EXT_AMT0", " ");	// 할증료
			}
		}catch(Exception e) {
			rollback();
			ret = "29";
			logger.info("[ERROR] HJ PARCEL LIST ERR : "+e.getMessage());
			throw e;
		}finally {
			end();
			dataMsg = ret + makeHJParcelServiceList(nRows, hm, df);
		}
		
		return dataMsg;
	}
	
	
	private String makeParcelServiceList(int nRows, HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		Map<String, String> map = null;
		int nLoop = 0;
		int nlens[] = { 2, 3, 20, 1, 10,
					   10 };
		String strHeaders[] = {
			"INQ_TYPE" 				,
			"PARCEL_CNT"			,
			"PARCEL_CD"				,
			"PARCEL_PAY_TP"			,
			"PARCEL_BASE_AMT"		,
			"PARCEL_PERRY_RTS_AMT"
		};
		
		StringUtil.appendSpace(sb, (String)hm.get(strHeaders[0]), nlens[0]);			// INQ_TYPE
		StringUtil.appendSpace(sb, (String)hm.get(strHeaders[1]), nlens[1]);			// PARCEL_CNT
		do {
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[2]+Integer.toString(nLoop)), nlens[2]);	// PARCEL_CD
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[3]+Integer.toString(nLoop)), nlens[3]);	// PARCEL_PAY_TP
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[4]+Integer.toString(nLoop)), nlens[4]);	// PARCEL_BASE_AMT
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[5]+Integer.toString(nLoop)), nlens[5]);	// PARCEL_PERRY_RTS_AMT
			nLoop++;
		}while(nLoop < nRows);
		
		return sb.toString();
	}
	
	private String makeHJParcelServiceList(int nRows, HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		Map<String, String> map = null;
		int nLoop = 0;
		int nlens[] = { 2, 3, 20, 1, 10,
					   10, 10 };
		String strHeaders[] = {
			"INQ_TYPE" 				,
			"PARCEL_CNT"			,
			"PARCEL_CD"				,
			"PARCEL_PAY_TP"			,
			"PARCEL_BASE_AMT"		,
			"PARCEL_PERRY_RTS_AMT"	,
			"PARCEL_ITEM_EXT_AMT"
		};
		
		StringUtil.appendSpace(sb, "C0", nlens[0]);										// INQ_TYPE
		StringUtil.appendSpace(sb, (String)hm.get(strHeaders[1]), nlens[1]);			// PARCEL_CNT
		do {
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[2]+Integer.toString(nLoop)), nlens[2]);	// PARCEL_CD
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[3]+Integer.toString(nLoop)), nlens[3]);	// PARCEL_PAY_TP
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[4]+Integer.toString(nLoop)), nlens[4]);	// PARCEL_BASE_AMT
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[5]+Integer.toString(nLoop)), nlens[5]);	// PARCEL_PERRY_RTS_AMT
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[6]+Integer.toString(nLoop)), nlens[6]);	// PARCEL_ITEM_EXT_AMT
			nLoop++;
		}while(nLoop < nRows);
		
		return sb.toString();
	}
	
	public String setCheckPDATranExist(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		StringBuffer sb = new StringBuffer();
		String dataMsg = "";
		String ret = "00";
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("pos-sql", "SEL_PDAEMERGTRN_HDR"));
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			
			list = executeQuery(sql);
			if( list.size() < 1 ) {
				ret = "09";
			}
		}catch(Exception e) {
			rollback();
			ret = "29";
			df.CommLogger("[ERROR] errMsg::["+e.getMessage()+"]");
			df.CommLogger("[ERROR] errMsg::["+e.getCause()+"]");
			throw e;
		}finally {
			end();
			sb.append(ret);
			sb.append((String)hm.get("INQ_TYPE"));
			sb.append(ret);
			
			dataMsg = sb.toString();
		}
		
		return dataMsg;
	}
	
	public String setPDAEmergencyTran(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		List<Object> listDtl = null;
		Map<String, String> map = null;
		Map<String, String> mapDtl = null;
		int i = 0;
		
		StringBuffer sb = new StringBuffer();
		
		String dataMsg = "";
		String ret = "00";
		
		int nlensHdr[] = {2, 5, 4};
		String strHdr[] = {
			"INQ_TYPE",
			"STORE_CD",
			"TRAN_CNT"
		};
		
		int nlensDtl[] = {8, 4, 4, 8};
		String strDtl[] = {
			"TRAN_DT",
			"PDA_NO",
			"TRAN_NO",
			"TOT_SALE_AMT"
		};
		
		int nlensItem[] = {1, 30, 2};
		String strItem[] = {
			"ITEM_SEQ",
			"PLU_CD",
			"ITEM_QTY"
		};
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			// 정전 시 PDA 판매 TRAN Header 조회
			sql.put(findQuery("pos-sql", "SEL_PDAEMERGTRN_HDR"));
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			
//			df.CommLogger(sql.debug());
			list = executeQuery(sql);
			sql.close();
			
			int iTranRows = list.size();
			
			hm.put("INQ_TYPE", (String)hm.get("INQ_TYPE"));
			hm.put("STORE_CD", (String)hm.get("STORE_CD"));
			hm.put("TRAN_CNT", Integer.toString(iTranRows));
			for (int j = 0; j < nlensHdr.length; j++) {
				StringUtil.appendSpace(sb, (String) hm.get(strHdr[j].toString()), nlensHdr[j]);
			}
			
			if( iTranRows > 0 ) {
				for( int nTranCnt = 0;nTranCnt < iTranRows;nTranCnt++ ) {
					map = (Map)list.get(nTranCnt);
					
					hm.put("TRAN_DT", (String)map.get("TRAN_DT"));
					hm.put("PDA_NO", (String)map.get("PDA_NO"));
					hm.put("TRAN_NO", (String)map.get("TRAN_NO"));
					hm.put("TOT_SALE_AMT", (String)map.get("TOT_SALE_AMT"));
					for (int j = 0; j < nlensDtl.length; j++) {
						StringUtil.appendSpace(sb, (String) hm.get(strDtl[j].toString()), nlensDtl[j]);
					}
					
					i = 0;
					sql.clearParameter();
					// 정전 시 PDA 판매 TRAN Detail 조회
					sql.put(findQuery("pos-sql", "SEL_PDAEMERGTRN_DTL"));
					sql.setString(++i, (String)map.get("TRAN_DT"));
					sql.setString(++i, "A16" + (String)hmComm.get("STORE_CD"));
					sql.setString(++i, (String)map.get("PDA_NO"));
					sql.setString(++i, (String)map.get("TRAN_NO"));
					sql.setString(++i, (String)hmComm.get("COM_CD"));
					
//					df.CommLogger(sql.debug());
					listDtl = executeQuery(sql);
					sql.close();
					if( listDtl.size() > 0 ) {
						int nRows = listDtl.size();
						for(int nItems = 0;nItems < 5;nItems++) {
							if( nItems < nRows ) {
								mapDtl = (Map)listDtl.get(nItems);
								hm.put("ITEM_SEQ", (String)mapDtl.get("ITEM_SEQ"));
								hm.put("PLU_CD", (String)mapDtl.get("PLU_CD"));
								hm.put("ITEM_QTY", (String)mapDtl.get("SALE_QTY"));
							}else {
								hm.put("ITEM_SEQ", " ");
								hm.put("PLU_CD", " ");
								hm.put("ITEM_QTY", " ");
							}
							for (int j = 0; j < nlensItem.length; j++) {
								StringUtil.appendSpace(sb, (String) hm.get(strItem[j].toString()), nlensItem[j]);
							}
						}
					}else {
						hm.put("ITEM_SEQ", " ");
						hm.put("PLU_CD", " ");
						hm.put("ITEM_QTY", " ");
						for(int nItems = 0;nItems < 5;nItems++) {
							StringUtil.appendSpace(sb, (String)hm.get("ITEM_SEQ"), nlensItem[0]);
							StringUtil.appendSpace(sb, (String)hm.get("PLU_CD"), nlensItem[1]);
							StringUtil.appendSpace(sb, (String)hm.get("ITEM_QTY"), nlensItem[2]);
						}
					}
				}
				i = 0;
				sql.clearParameter();
				// 정전 시 PDA 판매 TRAN Header 갱신
				sql.put(findQuery("pos-sql", "UPD_PDAEMERGTRN_HDR"));
				sql.setString(++i, "A16" + (String)hm.get("STORE_CD"));
				sql.setString(++i, (String)hmComm.get("COM_CD"));

				executeUpdate(sql);
				sql.close();
			}else {
				ret = "09";
				
				hm.put("TRAN_DT", " ");
				hm.put("PDA_NO", " ");
				hm.put("TRAN_NO", " ");
				hm.put("TOT_SALE_AMT", " ");
				for (int j = 0; j < nlensDtl.length; j++) {
					StringUtil.appendSpace(sb, (String) hm.get(strDtl[j].toString()), nlensDtl[j]);
				}
				
				hm.put("ITEM_SEQ", " ");
				hm.put("PLU_CD", " ");
				hm.put("ITEM_QTY", " ");
				for(int nItems = 0;nItems < 5;nItems++) {
					StringUtil.appendSpace(sb, (String)hm.get("ITEM_SEQ"), nlensItem[0]);
					StringUtil.appendSpace(sb, (String)hm.get("PLU_CD"), nlensItem[1]);
					StringUtil.appendSpace(sb, (String)hm.get("ITEM_QTY"), nlensItem[2]);
				}
			}
		}catch(Exception e) {
			rollback();
			ret = "29";
			df.CommLogger("[ERROR] errMsg::["+e.getMessage()+"]");
			df.CommLogger("[ERROR] errMsg::["+e.getCause()+"]");
			throw e;
		}finally {
			end();
			dataMsg = ret + sb.toString();
		}
		
		return dataMsg;
	}
	
	public String setSVCheck(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		ProcedureWrapper proc = new ProcedureWrapper();
//		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		
		String dataMsg = "";
		String ret = "00";
		String res_cd = "00";
		String retMsg = "";
		
		try{
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			//df.CommLogger("[DEBUG] [SP_HQ_SVSTRARR_TRN] Begin");
			proc.put("SP_HQ_SVSTRARR_TRN", 9);
			proc.setString(++i, (String)hmComm.get("COM_CD"));
			proc.setString(++i, (String)hm.get("STORE_CD"));
			proc.setString(++i, (String)hm.get("POS_NO"));
			proc.setString(++i, (String)hm.get("SV_ID"));
			proc.setString(++i, (String)hm.get("SV_FLG"));
			proc.setString(++i, (String)hm.get("REG_YMD"));
			proc.setString(++i, (String)hm.get("REG_HMS"));
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// RES_CD
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// MESSAGE
			
			ProcedureResultSet prs = super.executeUpdateProcedure(proc);
			res_cd = String.format("%02d", prs.getInt(8));
			retMsg = prs.getString(9);
			//df.CommLogger("[DEBUG] [SP_HQ_SVSTRARR_TRN] ResultMsg:" + retMsg);
			//df.CommLogger("[DEBUG] [SP_HQ_SVSTRARR_TRN] End");
			
			if( prs.getInt(8) != 0 ) {
				res_cd = "99";
			}
			
			 hm.put("RES_CD", res_cd);
			 hm.put("RES_MSG", retMsg);
		}catch(Exception e) {
			rollback();
			ret = "29";
			df.CommLogger("[ERROR] errMsg::["+e.getMessage()+"]");
			df.CommLogger("[ERROR] errMsg::["+e.getCause()+"]");
			throw e;
		}finally {
			dataMsg = ret + makeSendDataSVCheck(hm, df);
			end();
		}
		
		return dataMsg;
	}
	
	private String makeSendDataSVCheck(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,2};
		String strHeaders[] = {
			"INQ_TYPE",
			"RES_CD"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	public String procCashRcptInq(HashMap<String, String> hm, COMMLog df) {
		ProcedureWrapper proc = new ProcedureWrapper();
		int i = 0;
		
		String dataMsg  = "ERROR";
		String ret = "00";
		String res_cd = "0";
		try {
			String strID = ((String)hm.get("IDENTI_INFO")).trim();
			
			if( strID.length() >= 10 && strID.length() <= 19  ) {
				begin();
				// DB Connection(DB 접속)
				connect("CMGNS");
				
				proc.put("SP_CASHRCPT_APPRNO_EXT", 2);
				proc.registerOutParameter(++i, DataTypes.INTEGER);		// ERROR CODE
				proc.registerOutParameter(++i, DataTypes.VARCHAR);		// RETURN VALUE
				
	//			df.CommLogger(proc.debug());
				
				ProcedureResultSet prs = super.executeUpdateProcedure(proc);
				
				dataMsg = prs.getString(2);
			} else {
				res_cd = "8";
				dataMsg = "ERROR";
			}
		}catch(Exception e) {
			rollback();
			ret = "29";
			res_cd = "9";
			df.CommLogger("[ERROR] errMsg::["+e.getMessage()+"]");
			df.CommLogger("[ERROR] errMsg::["+e.getCause()+"]");
		}finally {
			end();
			dataMsg = ret + makeSendDataCashRcptInq(hm, dataMsg, res_cd, df);
		}
		
		return dataMsg;
	}
	
	public String procISPCheck(HashMap<String, String> hmComm, HashMap<String, String> hmData, COMMLog df) {
		ProcedureWrapper proc = new ProcedureWrapper();
		int i = 0;
		
		String dataMsg = "ERROR";
		String ret = "00";
		int iErrCD = 9;
		try {
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			begin();
			
			proc.put("SP_ST_STRDVYISPARR_TRN", 7);
			proc.setString(++i, (String)hmComm.get("COM_CD"));					// 1.회사코드
			proc.setString(++i, (String)hmData.get("STORE_CD"));				// 2.점포코드
			proc.setString(++i, ((String)hmData.get("ISPITEM_CD")).trim());		// 3.전표번호
			proc.setString(++i, (String)hmData.get("REG_YMD"));					// 4.등록일자
			proc.setString(++i, (String)hmData.get("REG_HMS"));					// 5.등록시간			
			
			proc.registerOutParameter(++i, DataTypes.INTEGER);		// ERROR CODE
			proc.registerOutParameter(++i, DataTypes.VARCHAR);		// RETURN VALUE
			
			ProcedureResultSet prs = super.executeUpdateProcedure(proc);
			
			iErrCD = prs.getInt(6);
		}catch(Exception e) {
			rollback();
			ret = "29";
			df.CommLogger("[ERROR] errMsg::["+e.getMessage()+"]");
			df.CommLogger("[ERROR] errMsg::["+e.getCause()+"]");
		}finally {
			end();
			dataMsg = ret + makeSendDataISPCheck(hmData, iErrCD, df);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataISPCheck(HashMap<String, String> hm, int iErrCD, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		
		StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE"), 2);						// INQ종별
		StringUtil.appendSpace(sb, String.format("%02d", iErrCD), 2);					// 결과코드
		
		return sb.toString();
	}
	
	private String makeSendDataCashRcptInq(HashMap<String, String> hm, String dataMsg, String res_cd, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		
		StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE"), 2);						// INQ종별
		StringUtil.appendSpace(sb, res_cd, 1);											// 응답코드
		StringUtil.appendSpace(sb, (String)hm.get("IDENTI_INFO"), 20);					// 현금영수증식별정보
		StringUtil.appendSpace(sb, dataMsg, 23);										// 승인번호(9) + 승인일시(14)
		
		return sb.toString();
	}
	
	public String getCreditCustInq2(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
	
		String dataMsg = "";		
		String ret = "00";
		
		try {
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("pos-sql", "SEL_SALEONCREDIT_MLTCUST_INQ"));
			sql.setString(++i, "A16" + (String)hm.get("STORE_CODE"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("INQ_FLAG"));
			sql.setString(++i, (String)hm.get("INQ_VALUE"));
			sql.setString(++i, "A16" + (String)hm.get("STORE_CODE"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("INQ_FLAG"));
			sql.setString(++i, (String)hm.get("INQ_VALUE"));
			sql.setString(++i, "A16" + (String)hm.get("STORE_CODE"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("INQ_FLAG"));
			sql.setString(++i, (String)hm.get("INQ_VALUE"));
			
//			df.CommLogger("sql : " + sql.debug());
			list = executeQuery(sql);
		}catch(SQLException e) {
			ret = "20";
		}catch(Exception e) {
			ret = "29";
			df.CommLogger("[ERROR] errMsg::["+e.getMessage()+"]");
			df.CommLogger("[ERROR] errMsg::["+e.getCause()+"]");
			throw e;
		}finally {
			dataMsg = ret + makeSendDataCreditCustInq2(hm, list, df);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataCreditCustInq2(HashMap<String, String> hm, List<Object> list, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		
		if( list.size() > 0 ) {
			StringUtil.appendSpace(sb, (String)hm.get("INQ_TYPE"), 2);						// INQ종별
			StringUtil.appendSpace(sb, (String)hm.get("STORE_CODE"), 5);					// 점포코드
			StringUtil.appendSpace(sb, Integer.toString(list.size()), 4);					// 조회건수
			for( int i = 0;i < list.size();i++ ) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				StringUtil.appendSpace(sb, (String)map.get("CREDIT_CUST_IDNT_NO"), 30);		// 외상고객식별번호
				StringUtil.appendSpace(sb, (String)map.get("CREDIT_CUST_TP"), 1);			// 외상고객형태
				StringUtil.appendSpace(sb, (String)map.get("CREDIT_CUST_SEQ_NO"), 19);		// 외상고객일련번호
				StringUtil.appendSpace(sb, (String)map.get("CREDIT_CUST_INFO"), 400);		// 외상고객정보
				StringUtil.appendSpace(sb, (String)map.get("CREDIT_REM_AMT"), 20);			// 총외상잔액
			}
		}else {
			StringUtil.appendSpace(sb, "0", 4);			// 조회건수
			StringUtil.appendSpace(sb, " ", 1);			// 외상고객형태
			StringUtil.appendSpace(sb, " ", 19);		// 외상고객일련번호
			StringUtil.appendSpace(sb, " ", 400);		// 외상고객정보
			StringUtil.appendSpace(sb, " ", 20);			// 총외상잔액
		}

		return sb.toString();
	}
	
	public String getCreditCustInq(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		Map<String, String> map = null;
		int i = 0;
	
		String dataMsg = "";		
		String ret = "00";
		
		// DB Connection(DB 접속)
		connect("CMGNS");
		try {
			sql.put(findQuery("pos-sql", "SEL_CREDITCUSTINFO"));
			sql.setString(++i, (String)hmComm.get("COM_CD"));
			sql.setString(++i, "A16" + (String)hmComm.get("STORE_CD"));
			sql.setString(++i, (String)hm.get("CUSTOMER_ID").trim());
			list = executeQuery(sql);
//			logger.info("[DEBUG]" + sql.debug());
			if( list.size() > 0 ) {
				map = (Map<String, String>)list.get(0);
				hm.put("CUSTOMER_TY", (String)map.get("CREDIT_CUST_TP").trim());
				hm.put("CUSTOMER_SEQ_NO", (String)map.get("CREDIT_CUST_SEQ_NO").trim());
				hm.put("CUSTOMER_NM", (String)map.get("CREDIT_CUST_INFO").trim());
				hm.put("SALEONCREDIT_TOT_AMT", (String)map.get("CREDIT_REM_AMT"));
				hm.put("RES_CD", "00");
			}else {
				hm.put("CUSTOMER_TY", " ");
				hm.put("CUSTOMER_SEQ_NO", " ");
				hm.put("CUSTOMER_NM", " ");
				hm.put("SALEONCREDIT_TOT_AMT", "0");
				hm.put("RES_CD", "01");
			}
		}catch(SQLException e) {
			ret = "20";
			logger.info("[SQLERROR]" + e.getMessage());
		}catch(Exception e) {
			ret = "29";
			df.CommLogger("[ERROR] errMsg::["+e.getMessage()+"]");
			df.CommLogger("[ERROR] errMsg::["+e.getCause()+"]");
			throw e;
		}finally {
			dataMsg = ret + makeSendDataCreditCustInq(hm,df);
//			df.CommLogger("★ make: " + dataMsg);
//			end();
		}
		
		return dataMsg;
	}
	
	private String makeSendDataCreditCustInq(HashMap<String, String> hm, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,5,30,1,19
					  ,400,20,2};
		String strHeaders[] = {
			"INQ_TYPE",					// INQ 종별
			"STORE_CODE",				// 점포 코드
			"CUSTOMER_ID",				// 외상고객 식별번호
			"CUSTOMER_TY",				// 고객 형태
			"CUSTOMER_SEQ_NO",			// 고객 일련번호
			
			"CUSTOMER_NM",				// 고객 정보
			"SALEONCREDIT_TOT_AMT",		// 총 외상 잔액
			"RES_CD"					// 응답코드
		};
		
		for(int i = 0;i < nlens.length;i++) {
//			df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public int upScAgentSend(HashMap<String, String> hm, COMMLog df) {
		SqlWrapper sql = new SqlWrapper();
		int updateYn = 0;
		int i = 0;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");

			sql.clearParameter();
			sql.put(findQuery("acagent-sql", "UP_SCAGENTSEND"));
			sql.setString(++i, (String)hm.get("PROC_ID"));
			sql.setString(++i, (String)hm.get("SC_DT"));
			sql.setString(++i, (String)hm.get("STORE_CD"));
			sql.setString(++i, (String)hm.get("SC_SEQ"));

			updateYn = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]UP_SCAGENTSEND::" + e);
		}finally {
			end();
		}
		
		return updateYn;
	}

	public int upScAgentIp(HashMap<String, String> hm, COMMLog df) {
		SqlWrapper sql = new SqlWrapper();
		int updateYn = 0;
		int i = 0;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");

			sql.clearParameter();
			sql.put(findQuery("acagent-sql", "UP_SCAGENTIP"));
			sql.setString(++i, (String)hm.get("STORE_CD"));
			sql.setString(++i, (String)hm.get("STORE_IP"));

			updateYn = executeUpdate(sql);
			sql.close();
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]UP_SCAGENTIP:" + e);
		}finally {
			end();
		}
		
		return updateYn;
	}
	
	
	public HashMap getStoreInfo(String storeCd){
		List<Object> list = null;
		HashMap<String, String> map = new HashMap();
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		
		try{
			begin();
			connect("CMGNS");
			
			sql.clearParameter();
			sql.put(findQuery("acagent-sql", "SEL_STORE_DTL_INFO"));
			sql.setString(++i, storeCd);
			
			list = executeQuery(sql);
			
			if(list.size() > 0){
				map = (HashMap<String, String>)list.get(0);
			}
		}catch(Exception e){
			logger.info("[ERROR]SEL_STORE_DTL_INFO:" + e);
			logger.info("[ERROR]ERR_MSG:" + e.getMessage());
		}finally{
			end();
		}
		
		return map;
	}
	
	//20170905 KSN 한진택배 환불가능여부 추가
	public String getHJParcelRefundYnCheck(String COM_CD, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		int nRows = 0;
		
		String dataMsg = "";
		String ret = "00";
		
		try {
			connect("CMGNS");	// DB Connection(DB 접속)
			
			sql.put(findQuery("pos-sql", "SEL_PARCEL_RFNDYN_CHK"));
			sql.setString(++i, COM_CD);
			sql.setString(++i, (String)hm.get("STORE_CD").trim());
			sql.setString(++i, (String)hm.get("TRAN_NO").trim());
			sql.setString(++i, (String)hm.get("WBL_NUM").trim());
			
			list = executeQuery(sql);
			
			//20180316 KSN 택배 집하 후 환불가능하도록 처리 (생활서비스팀 김재홍파트너 요청)
			/*nRows = list.size();
			if(nRows == 0){
				hm.put("RESULT_CODE", "OK");
			}else{
				hm.put("RESULT_CODE", "NG");
			}*/
			
			hm.put("RESULT_CODE", "OK"); //20180316 KSN 택배 집하 후 환불가능하도록 처리 (생활서비스팀 김재홍파트너 요청)
			
		}catch(Exception e) {
			ret = "29";
			logger.info("[ERROR]HJ REFUND_YN ERR :" +e.getMessage());
			throw e;
		}finally {
			dataMsg = ret + makeSendDataHJParcelRefundYnCheck(hm);
		}
		
		return dataMsg;
	}
	
	private String makeSendDataHJParcelRefundYnCheck(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 5, 4, 15, 2 };
		String strHeaders[] = {
			"INQ_TYPE",       // INQ 종별    
			"STORE_CD",       // 원점포코드   
			"TRAN_NO",        // 원거래번호   
			"WBL_NUM",        // 운송장번호    
			"RESULT_CODE"     // 처리결과
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}

	/**
	 * 한진 무인택배 송장번호 발행요청/응답 응답BODY작성
	 * @param hm
	 * @param df
	 * @return 첫 두자리 : 처리결과코드, 나머지 : 응답전문 BODY 
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public String getIQParcelCdReq(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql1 = new SqlWrapper();		// 운송장번호 PREFIX 조회
		SqlWrapper sql2 = new SqlWrapper();		// 발번 운송장번호 보존
		List<Object> list = null;
		Map<String, String> mapResult = null;
		int i = 0;
		int nRows = 0;

		String dataMsg = "";
		String ret = "00";

		try {
			// 파라미터 수집 및 정제
			String strParcelCdPrefix = "772";
			String strRetParcelCd = "";
			String strNewParcelCd = "";
			long longNewParcelSeq = 0;

			// 송장번호 발번취득을 위한 데이터베이스 접속
			begin();
			connect("CMGNS");	// DB Connection(DB 접속)

			// 최종 운송장번호 발행정보 취득
			sql1.put(findQuery("pos-sql", "SEL_IQ_PARCEL_CD_REQ_LAST_PARCEL_CD"));

			list = executeQuery(sql1);			// 쿼리조회
			nRows = list.size();

			if (nRows > 0) {
				mapResult = (Map<String, String>)list.get(0);

				strRetParcelCd = (String)mapResult.get("PARCEL_CD");									// 최종 운송장번호

				// 조회된 최종 운송장번호로부터 신규 운송장번호 채번
				strNewParcelCd = strRetParcelCd.substring(0, strRetParcelCd.length() - 1);				// CHECK DIGIT 제거
				strNewParcelCd = strNewParcelCd.substring(3);											// PREFIX 제거

				longNewParcelSeq = Long.parseLong(strNewParcelCd) + 1;									// SEQ 증가

				strNewParcelCd = String.format("%08d", longNewParcelSeq);								// 증가된 SEQ번호 포멧화(8자리)
				strNewParcelCd = strParcelCdPrefix + strNewParcelCd;									// PREFIX 추가
				strNewParcelCd = strNewParcelCd + String.valueOf(Long.parseLong(strNewParcelCd) % 7);	// CHECK DIGIT 추가
			} else {
				strRetParcelCd = strParcelCdPrefix + "00000000";
				strRetParcelCd = strRetParcelCd + String.valueOf(Long.parseLong(strRetParcelCd) % 7);

				strNewParcelCd = strRetParcelCd;	// DEFAULT 운송장번호
			}

			if (longNewParcelSeq > 99999999) {
				// 더 이상 채번가능한 번호없음 
				hm.put("PARCEL_CD", "");
				hm.put("RESP_CD", "99");
				hm.put("RESP_MSG", "채번가능한 운송장번호가 존재하지 않습니다.");
			} else {
				// 발번 운송장번호 보존 (단건 commit이므로 TRANSACTION 미사용)
				sql2.put(findQuery("pos-sql", "INS_IQ_PARCEL_CD_REQ"));
				sql2.setString(++i, strNewParcelCd.trim());
				sql2.setString(++i, (String)hmComm.get("TRAN_YMD"));
				sql2.setString(++i, (String)hmComm.get("STORE_CD"));
				sql2.setString(++i, (String)hmComm.get("POS_NO"));
				sql2.setString(++i, (String)hmComm.get("TRAN_NO"));

				int insCnt = executeUpdate(sql2);		// 쿼리 실행

				if (insCnt > 0) {
					hm.put("PARCEL_CD", strNewParcelCd);
					hm.put("RESP_CD", "00");
					hm.put("RESP_MSG", "정상");
				} else {
					hm.put("PARCEL_CD", "");
					hm.put("RESP_CD", "99");
					hm.put("RESP_MSG", "운송장번호 기록에 실패하였습니다.");					
				}
			}
		} catch (Exception e) {
			ret = "29";
			hm.put("RESP_CD", "99");
			hm.put("RESP_MSG", "오류가 발생하였습니다.");

			rollback();

			df.CommLogger("[ERROR]IQ_PARCEL_CD_REQ ERR :" + e.getMessage());
			throw e;
		} finally {
			dataMsg = ret + this.makeSendDataIQParcelCdReq(hm);

			end();		// commit 포함
		}
		
		return dataMsg;
	}

	/**
	 * 한진 무인택배 송장번호 발행요청/응답 전문BODY 작성
	 * @param hm
	 * @return
	 */
	private String makeSendDataIQParcelCdReq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 20, 2, 64 };
		String strHeaders[] = { 
			"INQ_TYPE",		// INQ_TYPE(INQ 종별)
			"PARCEL_CD",	// 송장번호
			"RESP_CD",		// 응답코드
			"RESP_MSG"		// 응답메시지
		};

		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	/**
	 * 한진 무인택배 송장번호 발행완료 요청/응답 응답BODY작성
	 * @param hmComm
	 * @param hm
	 * @param df
	 * @return 첫 두자리 : 처리결과코드, 나머지 : 응답전문 BODY 
	 * @throws Exception
	 */
	public String getIQParcelCdFin(HashMap<String, String> hmComm, HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql1 = new SqlWrapper();
		int i = 0;

		String dataMsg = "";
		String ret = "00";

		try {
			begin();
			connect("CMGNS");	// DB Connection(DB 접속)

			// 파라미터 수집 및 정제
			String strTranYmd = hmComm.get("TRAN_YMD");
			String strStoreCd = hmComm.get("STORE_CD");
			String strPosNo   = hmComm.get("POS_NO");
			String strTranNo  = hmComm.get("TRAN_NO");
			String strParcelCd = hm.get("PARCEL_CD");

			sql1.put(findQuery("pos-sql", "UPD_IQ_PARCEL_CD_FIN"));

			sql1.setString(++i, strTranYmd.trim());
			sql1.setString(++i, strStoreCd.trim());
			sql1.setString(++i, strPosNo.trim());
			sql1.setString(++i, strTranNo.trim());
			sql1.setString(++i, strParcelCd.trim());

			int insCnt = executeUpdate(sql1); // 쿼리 실행

			if (insCnt > 0) {
				hm.put("RESP_CD", "00");
				hm.put("RESP_MSG", "정상");
			} else {
				hm.put("RESP_CD", "99");
				hm.put("RESP_MSG", "갱신할 운송장번호가 존재하지 않습니다.");
			}
		} catch (Exception e) {
			ret = "29";
			hm.put("RESP_CD", "99");
			hm.put("RESP_MSG", "오류가 발생하였습니다.");

			rollback();

			df.CommLogger("[ERROR]IQ_PARCEL_CD_FIN ERR :" + e.getMessage());
			throw e;
		} finally {
			dataMsg = ret + this.makeSendDataIQParcelCdFin(hm);

			end();		// commit 포함
		}

		return dataMsg;
	}

	/**
	 * 한진 무인택배 송장번호 발행완료 요청/응답 전문BODY 작성
	 * @param hm
	 * @return
	 */
	private String makeSendDataIQParcelCdFin(HashMap<String, String> hm) {
		return this.makeSendDataIQParcelCdReq(hm);		// 기본적으로 발행요청시의 전문포멧과 동일
	}

	/**
	 * 한진 무인택배 택배 터미널 ID 취득 요청/응답 응답BODY작성
	 * @param hm
	 * @param df
	 * @return 첫 두자리 : 처리결과코드, 나머지 : 응답전문 BODY 
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public String getIQPTerminalReq(HashMap<String, String> hm, COMMLog df) throws Exception {
		SqlWrapper sql1 = new SqlWrapper();		// 운송장번호 PREFIX 조회
		List<Object> list = null;
		Map<String, String> mapResult = null;
		int i = 0;
		int nRows = 0;

		String dataMsg = "";
		String ret = "00";

		try {
			// 파라미터 수집 및 정제
			String strSndPostNo = hm.get("SND_POST_NO");
			String strRcvPostNo = hm.get("RCV_POST_NO");

			connect("CMGNS");	// DB Connection(DB 접속)

			// 택배 터미널 ID 취득
			sql1.put(findQuery("pos-sql", "SEL_IQ_P_TERMINAL_REQ"));

			sql1.setString(++i, strSndPostNo.trim());
			sql1.setString(++i, strRcvPostNo.trim());

			list = executeQuery(sql1);			// 쿼리조회
			nRows = list.size();

			if (nRows > 0) {
				mapResult = (Map<String, String>)list.get(0);

				String strDivisionTp    = (String)mapResult.get("DIVISION_TP");
				String strQuickYn       = (String)mapResult.get("QUICK_YN");
				String strParcelTotAmt  = (String)mapResult.get("PARCEL_TOT_AMT");
				String strSndTerminalId = (String)mapResult.get("SND_TERMINAL_ID");
				String strSndTerminalNm = (String)mapResult.get("SND_TERMINAL_NM");
				String strRcvTerminalId = (String)mapResult.get("RCV_TERMINAL_ID");
				String strRcvTerminalNm = (String)mapResult.get("RCV_TERMINAL_NM");
				String strRcvHubCd      = (String)mapResult.get("RCV_HUB_CD");
				String strRcvMidCd      = (String)mapResult.get("RCV_MID_CD");
				String strRcvSubCd      = (String)mapResult.get("RCV_SUB_CD");
				String strRcvSaleCd     = (String)mapResult.get("RCV_SALE_CD");
				String strRcvSaleNm     = (String)mapResult.get("RCV_SALE_NM");
				String strEsName        = (String)mapResult.get("ES_NAME");
				String strRcvColAreaNm  = (String)mapResult.get("RCV_COL_AREA_NM");

				// 한글필드(SND_TERMINAL_NM, RCV_TERMINAL_NM, RCV_SALE_NM, ES_NAME, RCV_COL_AREA_NM)

				hm.put("DIVISION_TP"     , strDivisionTp.trim());		// 권역구분(도착지, 7 : 제주, 9 : 도서)
				hm.put("QUICK_YN"        , strQuickYn.trim());			// 퀵지역구분
				hm.put("PARCEL_TOT_AMT"  , strParcelTotAmt.trim());		// 택배운임그액(한진택배측 쿼리 활용)
				hm.put("SND_TERMINAL_ID" , strSndTerminalId.trim());	// 송하인 터미널ID
				hm.put("SND_TERMINAL_NM" , strSndTerminalNm.trim());	// 송하인 터미널명
				hm.put("RCV_TERMINAL_ID" , strRcvTerminalId.trim());	// 수하인 터미널ID
				hm.put("RCV_TERMINAL_NM" , strRcvTerminalNm.trim());	// 수하인 터미널명
				hm.put("RCV_HUB_CD"      , strRcvHubCd.trim());			// 도착지 대분류코드
				hm.put("RCV_MID_CD"      , strRcvMidCd.trim());			// 도착지 중분류코드
				hm.put("RCV_SUB_CD"      , strRcvSubCd.trim());			// 도착지 소분류코드
				hm.put("RCV_SALE_CD"     , strRcvSaleCd.trim());		// 도착지 영업소코드
				hm.put("RCV_SALE_NM"     , strRcvSaleNm.trim());		// 도착지 영업소명
				hm.put("ES_NAME"         , strEsName.trim());			// 배송원명
				hm.put("RCV_COL_AREA_NM" , strRcvColAreaNm.trim());		// 도착지 집배구역명

				hm.put("RESP_CD", "00");
				hm.put("RESP_MSG", "정상");
			} else {
				hm.put("RESP_CD", "99");
				hm.put("RESP_MSG", "터미널 ID가 존재하지 않습니다.");
			}
		} catch (Exception e) {
			ret = "29";
			hm.put("RESP_CD", "99");
			hm.put("RESP_MSG", "오류가 발생하였습니다.");

			df.CommLogger("[ERROR]IQ_PARCEL_CD_REQ ERR :" + e.getMessage());
			throw e;
		} finally {
			dataMsg = ret + this.makeSendDataIQPTerminalReq(hm);
		}
		
		return dataMsg;
	}
	
	/**
	 * 한진 무인택배 택배 터미널 ID 취득 요청/응답 전문BODY 작성
	 * @param hm
	 * @return
	 */
	private String makeSendDataIQPTerminalReq(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2, 2, 64, 4, 1, 12, 6, 10, 30, 6, 10, 30, 2, 2, 2, 10, 30, 30, 30};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ_TYPE(INQ 종별)
			"RESP_CD",			// 응답코드
			"RESP_MSG",			// 응답메시지
			"DIVISION_TP",		// 권역구분(도착지, 7 : 제주, 9 : 도서)
			"QUICK_YN",			// 퀵지역구분
			"PARCEL_TOT_AMT",	// 택배운임그액(한진택배측 쿼리 활용)
			"SND_POST_NO",		// 송하인 우편번호
			"SND_TERMINAL_ID",	// 송하인 터미널ID
			"SND_TERMINAL_NM",	// 송하인 터미널명
			"RCV_POST_NO",		// 수하인 우편번호
			"RCV_TERMINAL_ID",	// 수하인 터미널ID
			"RCV_TERMINAL_NM",	// 수하인 터미널명
			"RCV_HUB_CD",		// 도착지 대분류코드
			"RCV_MID_CD",		// 도착지 중분류코드
			"RCV_SUB_CD",		// 도착지 소분류코드
			"RCV_SALE_CD",		// 도착지 영업소코드
			"RCV_SALE_NM",		// 도착지 영업소명
			"ES_NAME",			// 배송원명
			"RCV_COL_AREA_NM",	// 도착지 집배구역명
		};

		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	/**
	 * 택배 전문의 개인정보 보강을 위한 운송장 정보 취득
	 * @param hm
	 * @param df
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public HashMap getParcelPrivateInfo(HashMap<String, String> hm, COMMLog df){
		List<Object> list = null;
		HashMap<String, String> map = new HashMap();
		SqlWrapper sql = new SqlWrapper();
		int i = 0;

		try {
			connect("CMGNS");

			sql.clearParameter();

			logger.info("parclNo::["+(String)hm.get("WBL_NUM")+"]");
			sql.put(findQuery("pos-sql", "SEL_PARCEL_PRIVATE_INFO"));
			sql.setString(++i, (String)hm.get("WBL_NUM").trim());		// PARCEL_CD

			list = executeQuery(sql);

			if (list.size() > 0) {
				map = (HashMap<String, String>) list.get(0);
				logger.info("PrivateINFO["+map+"]");
			}
		} catch (Exception e) {
			logger.info("[ERROR]SEL_PARCEL_PRIVATE_INFO:" + e);
			logger.info("[ERROR]ERR_MSG:" + e.getMessage());
		} finally {
			end();
		}
		
		return map;
	}

	/**
	 * 택배 전문의 개인정보 보강을 위한 운송장 정보 취득시 조회(진행) 플래그 갱신
	 * @param hm
	 * @param df 
	 * @return
	 */
	public int updParcelPrivateInfoFlag(HashMap<String, String> hm, COMMLog df) {
		SqlWrapper sql = new SqlWrapper();
		int updateYn = 0;
		int i = 0;
		
		try {
			begin();
			// DB Connection(DB 접속)
			connect("CMGNS");

			sql.clearParameter();
			sql.put(findQuery("pos-sql", "UPD_PARCEL_PRIVATE_INFO_FLAG"));
			sql.setString(++i, (String)hm.get("WBL_NUM"));		// PARCEL_CD

			updateYn = executeUpdate(sql);

			sql.close();
		} catch (Exception e) {
			rollback();

			logger.info("[ERROR]UPD_PARCEL_PRIVATE_INFO_FLAG :" + e.getMessage());
		} finally {
			end();
		}
		
		return updateYn;
	}
}