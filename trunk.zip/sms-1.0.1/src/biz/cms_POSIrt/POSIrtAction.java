package biz.cms_POSIrt;

import java.net.Socket;
import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

public class POSIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(POSIrtAction.class);
	
	private String server_ip = "";
	private int server_port = 0;
	
	/**
	 * Receive data from SC through 9001 PORT(SC로부터 데이타를 9001 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(ActionSocket actionSocket) throws Exception {
		// TODO Auto-generated method stub
		int ret = 0;
		int inq_type = 0;
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		String sendMsg = "";
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		POSIrtDAO dao = new POSIrtDAO();
		POSIrtProtocol protocol = new POSIrtProtocol();
		COMMLog df = new COMMLog();
		
		Socket extClntSock = null;
		POSIrtConveyer conveyer = null;
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress()
					.getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,
					"POSIRT");
			
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {	// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 비교한다).
				return;
			}
			
			// TRAN Date(TRAN일자)
			String tranYmd = COMMBiz.getCommTranYMD(hmCommon);
			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			inq_type = protocol.getRcvPOSIrtDATA(rcvDataBuf);
			
			switch( inq_type ) {
				case 11:	// 11: 외상고객조회
					df.execute("INQ_CREDITCUSTOMER");
					hmData = protocol.getParseCreditCustInq(rcvDataBuf);
					dataMsg = dao.getCreditCustInq(hmCommon, hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				
				case 12:	// 12: 외상고객조회2
					df.execute("INQ_CREDITCUSTOMER_NEW");
					hmData = protocol.getParseCreditCustInq2(rcvDataBuf);
					dataMsg = dao.getCreditCustInq2(hmCommon, hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				
				case 13:	// 13: 현금영수증
					df.execute("INQ_CASHRCPT");
					hmData = protocol.getParseCashRcptInq(rcvDataBuf);
					dataMsg = dao.procCashRcptInq(hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				
				case 31:	// 31: 배송점착
					df.execute("CHK_DELIVERY_ARRIVAL");
					hmData = protocol.getParseDeliveryCheck(rcvDataBuf);
					dataMsg = dao.setDeliveryCheck(hmCommon, hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				
				case 32:	// 32: SV점착
					df.execute("CHK_SV_ARRIVAL");
					hmData = protocol.getParseSVCheck(rcvDataBuf);
					dataMsg = dao.setSVCheck(hmCommon, hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				
				case 37:	// 37: 점포상품 현재고 조회
					df.execute("INQ_STRSTOCKNOW");
					hmData = protocol.getParseStrStockNowInq(rcvDataBuf);
					// 조회옵션 '상품'이라면
					if( ((String)hmData.get("OPTION")).equals("0") ) {
						dataMsg = dao.getStrStockNowForItem(hmCommon, hmData, df);
					}else {
						dataMsg = dao.getStrStockNowForCigar(hmCommon, hmData, df);
					}
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				
				case 38:	// 38: ISP 배송점착
					df.execute("INQ_ISP_ARRIVAL");
					hmData = protocol.getParseISPCheck(rcvDataBuf);
					dataMsg = dao.procISPCheck(hmCommon, hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				
				case 53:	// 53: 정전시 PDA 판매 거래정보 요청
					df.execute("REQ_PDAEMERGENCY_TRAN");
					hmData = protocol.getParsePDAEmergencyTran(rcvDataBuf);
					dataMsg = dao.setPDAEmergencyTran(hmCommon, hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				case 54:
					df.execute("REQ_PDATRANEXIST");
					hmData = protocol.getParseCheckPDATranExist(rcvDataBuf);
					dataMsg = dao.setCheckPDATranExist(hmCommon, hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				case 56:	// 56: 택배서비스 영수증 집계 요청
					df.execute("REQ_PARCELSVC_LIST");
					df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					df.CommLogger("▶ 01: Receive Data: " + rcvBuf);
					hmData = protocol.getParseParcelServiceList(rcvDataBuf);
					dataMsg = dao.getParcelServiceList((String)hmCommon.get("COM_CD"), hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				case 2103:  // B9: 한진 택배서비스 영수증 집계 요청 
					df.execute("REQ_HJ_PARCELSVC_LIST");
					df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					df.CommLogger("▶ 01: Receive Data: " + rcvBuf);
					hmData = protocol.getParseParcelServiceList(rcvDataBuf);
					dataMsg = dao.getHJParcelServiceList((String)hmCommon.get("COM_CD"), hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				case 57:   // 57: 택배서비스 영수증 집계 완료 요청
				case 2126: // C1: 20170816 KSN 한진택배서비스 영수증 집계 완료 요청
					df.execute("REQ_PARCELSVC_CPL");
					df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					df.CommLogger("▶ 01: Receive Data: " + rcvBuf);
					hmData = protocol.getParseParcelServiceCpl(rcvDataBuf);
					dataMsg = dao.setParcelServiceCpl((String)hmCommon.get("COM_CD"), hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 58: POS설정업무 정보수신 요청
				case 58:
					df.execute("REQ_POSSETTINFO");
					hmData = protocol.getParsePosSettInfo(rcvDataBuf);
					dataMsg = dao.getPosSettInfo((String)hmCommon.get("COM_CD"), hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 59: 응모번호(영수증행사) 요청
				case 59:
					df.execute("REQ_RECEIPT_PROMOTION_COUPON");
					hmData = protocol.getParseRecptPromCoupon(rcvDataBuf);
					dataMsg = dao.getRecptPromCoupon((String)hmCommon.get("COM_CD"), hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				case 60:	// 60: 택배 운송장 중복확인 요청
					df.execute("REQ_PARCELCD_CHK");
					df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					df.CommLogger("▶ 01: Receive Data: " + rcvBuf);
					hmData = protocol.getParseParcelCDCheck(rcvDataBuf);
					dataMsg = dao.getParcelCDCheck((String)hmCommon.get("COM_CD"), (String)hmCommon.get("STORE_CD"), hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					
					break;
				case 2102:	// 2102: 한진택배 운송장 중복확인 요청
					df.execute("REQ_HJ_PARCELCD_CHK");
					df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					df.CommLogger("▶ 01: Receive Data: " + rcvBuf);
					hmData = protocol.getParseHJParcelCDCheck(rcvDataBuf);
					dataMsg = dao.getParcelCDCheck((String)hmCommon.get("COM_CD"), (String)hmCommon.get("STORE_CD"), hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				case 90:	// 90: scAgent 실행결과전송
					df.execute("REQ_SCAGENT_RESULT");
					hmData = protocol.getParseScAgentReq(rcvDataBuf);
					ret = dao.upScAgentSend(hmData, df);
					dataMsg = dataMsg.substring(2);
					break;
				case 91:	// 91: scAgent IP등록
					df.execute("REQ_SCAGENT_IP");
					hmData = protocol.getParseScAgentIpReq(rcvDataBuf);
					ret = dao.upScAgentIp(hmData, df);
					dataMsg = dataMsg.substring(2);
					break;
				case 79:	// 79: 사원증 인증(사원증 SV 점착 인증)
					hmData = protocol.getParseStaffCheck(rcvDataBuf);
					this.server_ip = PropertyUtil.findProperty("communication-property", "STAFFCHK_COMM_IP");
					this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "STAFFCHK_COMM_PORT"));			
					extClntSock = new Socket(server_ip, server_port);					
					conveyer = new POSIrtConveyer(extClntSock, df);							
					dataMsg = conveyer.getStaffCheck(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				case 2129:	// C4: 한진 택배서비스 주문/반품정보 요청/응답
					df.execute("CHK_HJ_PARCEL_ORDER_REQ_RSP");
					df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					df.CommLogger("▶ 01: Receive Data: " + rcvBuf);
					hmData = protocol.getParseHJParcelServiceReq(rcvDataBuf);
					this.server_ip = PropertyUtil.findProperty("communication-property", "HANJIN_COMM_IP");
					this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "HANJIN_COMM_PORT"));	
					extClntSock = new Socket(this.server_ip, server_port);	
					conveyer = new POSIrtConveyer(extClntSock, df);							
					dataMsg = conveyer.getHJParcelServiceCheck(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				case 2133:	// C8: 한진 택배서비스 환불가능여부 요청/응답
					df.execute("REQ_HJ_PARCEL_RFND_YN_CHK");
					df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					df.CommLogger("▶ 01: Receive Data: " + rcvBuf);
					hmData = protocol.getParseHJParcelRefundYnCheck(rcvDataBuf);
					dataMsg = dao.getHJParcelRefundYnCheck((String)hmCommon.get("COM_CD"), hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				case 2164:	// D8: 한진 무인택배(SCO) // 택배 운송장번호 발행요청/응답
					df.execute("IQ_PARCEL_CD_REQ");
					df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					df.CommLogger("▶ 01: Receive Data: " + rcvBuf);
					hmData = protocol.getIQParcelCdReq(rcvDataBuf);
					dataMsg = dao.getIQParcelCdReq(hmCommon, hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				case 2188:	// E1: 한진 무인택배(SCO) // 택배 운송장번호 발행완료 요청/응답
					df.execute("IQ_PARCEL_CD_FIN");
					df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					df.CommLogger("▶ 01: Receive Data: " + rcvBuf);
					hmData = protocol.getIQParcelCdFin(rcvDataBuf);
					dataMsg = dao.getIQParcelCdFin(hmCommon, hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				case 2165:	// D9: 한진 무인택배(SCO) // 택배 터미널 ID 취득 요청/응답
					df.execute("IQ_P_TERMINAL_REQ");
					df.CommLogger("[pos>sms] SEND[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
					df.CommLogger("▶ 01: Receive Data: " + rcvBuf);
					hmData = protocol.getIQPTerminalReq(rcvDataBuf);
					dataMsg = dao.getIQPTerminalReq(hmData, df);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				default:
					df.CommLogger("▶ INQ Type Code(INQ 종별 코드):   [" + inq_type + "]" + rcvBuf.length());
					ret = 99;
					break;
			}
		}catch(Exception e) {
			// 029=HOST APPL ERR
			ret = 29;
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기) 
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			df.CommLogger("[sms>pos] SEND[" + (sendMsg+dataMsg).getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + (sendMsg+dataMsg) + "]");
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(sendMsg + dataMsg)) {
				df.CommLogger("[sms>pos] SEND[" + (sendMsg+dataMsg).getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>pos] SEND[" + (sendMsg+dataMsg).getBytes().length + "] ERROR");
			}
		}catch(Exception e) {
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("POSIRT", retValue);
		}
	}
}