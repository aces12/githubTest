package biz.cms_POSIrt;

import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import biz.cms_POSIrt.POSIrtDAO;
import biz.cms_POSIrt.POSIrtProtocol;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.BasicStringFilter;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

public class POSIrtConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;

	COMMLog df = null;

	public POSIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}

	public String getStaffCheck(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {

		POSIrtProtocol protocol = new POSIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		HashMap<String, String> hmReq = new HashMap<String, String>();
		
		String sendMsg = "";	// 캐시비로 보낼 송신 전문
		String recvBuf = "";	// 캐시비에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.STAFFCHECK_FILTER)));

			hmReq.put("DEAL_LEN",        "0700");    // 전문길이         0700:고정값  
			hmReq.put("DEAL_TYPE",       "AUTH0201");    // 전문ID     AUTH0301:이마트   
			hmReq.put("CO_CD",           "AE0       ");    // 회사코드           
			hmReq.put("REQ_GUBUN",       "SEND");    // 요청구분           SEND:고정    
			hmReq.put("OPER_DATE",       (String)hm.get("REG_YMD"));    // 영업일자           
			hmReq.put("OPER_TIME",       (String)hm.get("REG_HMS"));    // 영업시간           
			hmReq.put("STORE_CD",        "   " + (String)hm.get("STORE_CODE").substring(0, 1));    // 점코드            
			hmReq.put("STORE_CD2",       (String)hm.get("STORE_CODE").substring(1, 5));    // 점포서버번호         
			hmReq.put("POS_NO",          (String)hm.get("POS_NO"));    // 포스번호           
			hmReq.put("CASHER_NO",       "          ");    // CASHER번호       
			hmReq.put("TRAN_NO",         "    ");    // 거래번호           
			hmReq.put("COM_TRAN_NO",     (String)hm.get("REG_YMD") + (String)hm.get("POS_NO") + (String)hm.get("REG_HMS") + "  ");    // 회사별거래번호        
			hmReq.put("COM_ADD_INFO",    "                    ");    // 회사별추가정보        
			hmReq.put("TRAN_SEND_DATE",  (String)hm.get("REG_YMD"));    // 전문전송일자         
			hmReq.put("TRAN_SEND_TIME",  (String)hm.get("REG_HMS"));    // 전문전송시간         
			hmReq.put("TRAN_TYPE",       "05");    // 거래TYPE    조회:05      
			hmReq.put("CONF_GUBUN",      (String)hm.get("CONF_GUBUN"));    // 인증방법구분      전자사원증:1,  카드:2
			hmReq.put("ELEC_STAFF",      (String)hm.get("ELEC_STAFF"));    // 전자사원증          
			hmReq.put("CARD_INFO",       (String)hm.get("CARD_NO"));    // 신용카드           
			hmReq.put("KEY_IN_YN",       (String)hm.get("KEY_IN"));    // KEY_IN 유무      
			hmReq.put("TOTAL_AMT",       "000000000000");    // 총매출금액           
			hmReq.put("AMT",             "000000000000");    // 순매출금액          
			hmReq.put("SALE_AMT",        "000000000000");    // 직원할인금액         
			hmReq.put("GDS_CNT",         "0000");    // 구매물품수          
			hmReq.put("GDS_CD",          "                                                  ");    // 구매물품대표코드       
			hmReq.put("GDS_NM",          "                                                                                                    ");    // 구매물품명          
			hmReq.put("FILLER",          "                                                                                                                                                                                                                                                                                                        ");   // FILLER 
			
			sendMsg = makeSendDataStaffCheck(hmReq);
			
			df.CommLogger("[sms>StaffCheck SEND[" + sendMsg.getBytes().length + "]:[" + sendMsg + "]");
			
			// Socket 통신 시작
			if( actSock.send(sendMsg) ) { // 요청 송신
				df.CommLogger("[sms>StaffCheck] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>StaffCheck] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("StaffCheck server is no response");
			}
			
			recvBuf = ((String)actSock.receive()); // 요청 수신
			hmRecv = makeSendDataStaffCheckRsp(new String(recvBuf.getBytes("EUC-KR"),"ISO8859_1"));
			
		}catch(Exception e) { 
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			// Socket 통신 종료
			actSock.close(); 
			dataMsg = ret 
	          		 + (String)hm.get("INQ_TYPE")        // INQ종별  
				     + "00"                              // 결과코드 00:정상 01~99 :실패   
				     + (String)hmRecv.get("RETURN_CD")   // 응답코드   
				     + (String)hmRecv.get("EMPLOYEE_YN") // 직원유무   
				     + (String)hmRecv.get("EMPLOYEE_ID") // 사번     
				     + (String)hmRecv.get("COMP_CD")     // 소속사코드  
					 + (String)hmRecv.get("COMP_NM")     // 소속사명   
					 + (String)hmRecv.get("EMPLOYEE_NM") // 이름     
					 + (String)hmRecv.get("RANK_CD")     // 직급코드   
					 + (String)hmRecv.get("RANK_NM")     // 직급명    
					 + (String)hmRecv.get("RSP_MESSAGE") // 응답메시지  
			        ;
			df.CommLogger("★ make(to POS): " + dataMsg);
		}
		
		return dataMsg;
	}
	
	
	private String makeSendDataStaffCheck(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4, 8, 10, 4, 8, 6, 4, 4, 4, 10, 4, 20, 20, 8, 6, 2, 1, 10, 80, 1, 12, 12, 12, 4, 50, 100, 296};
		String strHeaders[] = {
			"DEAL_LEN",       // 전문길이    
			"DEAL_TYPE",      // 전문ID    
			"CO_CD",          // 회사코드    
			"REQ_GUBUN",      // 요청구분    
			"OPER_DATE",      // 영업일자    
			"OPER_TIME",      // 영업시간    
			"STORE_CD",       // 점코드     
			"STORE_CD2",      // 점포서버번호  
			"POS_NO",         // 포스번호    
			"CASHER_NO",      // CASHER번호
			"TRAN_NO",        // 거래번호    
			"COM_TRAN_NO",    // 회사별거래번호 
			"COM_ADD_INFO",   // 회사별추가정보 
			"TRAN_SEND_DATE", // 전문전송일자  
			"TRAN_SEND_TIME", // 전문전송시간  
			"TRAN_TYPE",      // 거래TYPE
			"CONF_GUBUN",     // 인증방법구분
			"ELEC_STAFF",     // 전자사원증
			"CARD_INFO",      // 신용카드
			"KEY_IN_YN",      // KEY_IN 유무
			"TOTAL_AMT",      // 총매출금액
			"AMT",            // 순매출금액
			"SALE_AMT",       // 직원할인금액
			"GDS_CNT",        // 구매물품수
			"GDS_CD",         // 구매물품대표코드
			"GDS_NM",         // 구매물품명
			"FILLER"          // FILLER
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public HashMap<String, String> makeSendDataStaffCheckRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		//int nlens[] = {4, 8, 10, 4, 8, 6, 4, 4, 4, 10, 4, 20, 20, 8, 6, 2, 4, 20, 2, 12, 1, 10, 80, 1, 12, 12, 12, 10, 10};
		int nlens[] = {4, 8, 10, 4, 8, 6, 4, 4, 4, 10, 4, 20, 20, 8, 6, 2, 4, 20, 2, 12, 1, 10, 80, 1, 12, 12, 12, 10, 10, 50, 50, 10, 50, 60, 172};
		String strHeaders[] = {
				"DEAL_LEN",       // 전문길이
				"DEAL_TYPE",      // 전문ID
				"CO_CD",          // 회사코드
				"REQ_GUBUN",      // 요청구분
				"OPER_DATE",      // 영업일자
				"OPER_TIME",      // 영업시간
				"STORE_CD",       // 점코드
				"STORE_CD2",      // 점포서버번호
				"POS_NO",         // 포스번호
				"CASHER_NO",      // CASHER번호
				"TRAN_NO",        // 거래번호
				"COM_TRAN_NO",    // 회사별거래번호
				"COM_ADD_INFO",   // 회사별추가정보
				"TRAN_SEND_DATE", // 전문전송일자
				"TRAN_SEND_TIME", // 전문전송시간
				"SERVICE_CD",     // 서비스코드
				"RETURN_CD",      // 응답코드
				"CONF_NO",        // 승인번호
				"EMPLOYEE_YN",    // 직원유무
				"REST_AMT",       // 잔여한도금액
				"ELEC_STAFF_YN",  // 전자사원증유무
				"ELEC_STAFF",     // 전자사원증
				"CARD_INFO",      // 신용카드
				"KEY_IN_YN",      // KEY_IN 유무
				"TOTAL_AMT",      // 총매출금액
				"AMT",            // 순매출금액
				"SALE_AMT",       // 직원할인금액
				"EMPLOYEE_ID",    // 사번
				"COMP_CD",        // 소속사코드
				"COMP_NM",        // 소속사명
				"EMPLOYEE_NM",    // 이름       
				"RANK_CD",        // 직급코드     
				"RANK_NM",        // 직급명      
				"RSP_MESSAGE",    // 응답메시지    
				"FILLER"          // FILLER   
		};

		int bInx=0;
		int eInx=0;	
		HashMap hm_sub = new HashMap();

		eInx = nlens[0];
		
		for(int i=0; i<nlens.length; i++ ){
			
			try {
				hm_sub.put(strHeaders[i].toString(), new String(rcvBuf.substring(bInx, eInx).getBytes("ISO8859_1"),"EUC-KR"));
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			if (i<nlens.length-1){
				bInx = eInx;
				eInx = eInx+nlens[i+1];
			}
		}
		
		return hm_sub;
	}
	
	
	public String getHJParcelServiceCheck(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {

		POSIrtProtocol protocol = new POSIrtProtocol();
		POSIrtDAO dao = new POSIrtDAO();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		HashMap<String, String> hmReq = new HashMap<String, String>();
		
		String sendMsg = "";	// 한진택배로 보낼 송신 전문
		String recvBuf = "";	// 한진택배에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.HANJIN_FILTER)));
			
			//20171109 KSN 택배 거래일자 POS영업일자 -> 시스템일자 기준으로 변경처리 (대사이슈로인한 개선처리)
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			String tranDt = sdf.format(calendar.getTime());

			HashMap storeInfo = (HashMap)dao.getStoreInfo((String)hmComm.get("STORE_CD"));
			String strInvcType = (String)hm.get("INVC_TYPE");	// 20180221 한진무인택배(SCO)로 인한 자동송장의 경우 파라미터 추가를 위한 변수추가
			String parcelNo = (String)hm.get("WBL_NUM");
			
			df.CommLogger("parcelNo::["+parcelNo+"]");

			if(storeInfo.isEmpty()){ 
				df.CommLogger("getStoreInfo >>> fail. errMsg: abnormal Store. Store Info is not exist.");
			}else{
				String msgType = "01"; //취소/환불
				String payCon = "CD";  //지불구분 (20180423 KSN 한진요청으로 현금선불 PP -> CD로 변경)
				String paymentTp = "01"; //결제수단구분
				String tranId = tranDt+(String)hmComm.get("STORE_CD")+(String)hmComm.get("POS_NO")+(String)hmComm.get("TRAN_NO"); //20171109 KSN 택배 거래일자 POS영업일자 -> 시스템일자 기준으로 변경처리 (대사이슈로인한 개선처리)
				df.CommLogger("[INFO] SYS_YMD::["+tranDt+"]::TRAN_YMD::["+(String)hmComm.get("TRAN_YMD")+"]::TRAN_ID::["+tranId+"]");

				// 20180221 한진무인택배(SCO)로 인한 자동송장의 경우 파라미터 추가를 위한 변수추가
				String strSndZip  = "";
				String strSndAdd1 = "";
				String strSndAdd2 = "";
				String strSndName = "";
				String strSndTel  = "";
				String strSndHph  = "";
				String strRcvZip  = "";
				String strRcvAdd1 = "";
				String strRcvAdd2 = "";
				String strRcvName = "";
				String strRcvTel  = "";
				String strRcvHph  = "";

				// 20180221 한진무인택배(SCO)
				if (parcelNo.startsWith("772")) {
					// 업무구분=2 자동송장인 경우
					// 택배 주문접수 정보 테이블(CP_PARCEL_RCV_INFO)로부터 개인정보 파라미터 완성
					HashMap mapParcelPrivateInfo = dao.getParcelPrivateInfo(hm, df);

					df.CommLogger("[INFO] mapParcelPrivateInfo::["+mapParcelPrivateInfo+"]");
					
					strSndZip  = (String)mapParcelPrivateInfo.get("SND_ZIP");
					strSndAdd1 = (String)mapParcelPrivateInfo.get("SND_ADD1");
					strSndAdd2 = (String)mapParcelPrivateInfo.get("SND_ADD2");
					strSndName = (String)mapParcelPrivateInfo.get("SND_NAME");
					strSndTel  = (String)mapParcelPrivateInfo.get("SND_TEL");
					strSndHph  = (String)mapParcelPrivateInfo.get("SND_HPH");
					strRcvZip  = (String)mapParcelPrivateInfo.get("RCV_ZIP");
					strRcvAdd1 = (String)mapParcelPrivateInfo.get("RCV_ADD1");
					strRcvAdd2 = (String)mapParcelPrivateInfo.get("RCV_ADD2");
					strRcvName = (String)mapParcelPrivateInfo.get("RCV_NAME");
					strRcvTel  = (String)mapParcelPrivateInfo.get("RCV_TEL");
					strRcvHph  = (String)mapParcelPrivateInfo.get("RCV_HPH");
					
					strInvcType = "2";
				}
				
				if("R".equals((String)hm.get("DLV_TYPE")) || "C".equals((String)hm.get("DLV_TYPE"))){
					msgType = "02";
				}
				
				if("1".equals((String)hm.get("PAY_DIV"))){
					payCon = "CD";
					paymentTp = "01";
				}else if("2".equals((String)hm.get("PAY_DIV"))){
					payCon = "CC";
					paymentTp = "01";
				}else if("3".equals((String)hm.get("PAY_DIV"))){
					payCon = "CA";
					paymentTp = "02";
				}
				
				hmReq.put("MSG_TYPE",       msgType);    					  		// 전문구분 (01:주문정보전문, 02:반품정보전문)
				hmReq.put("MSG_LEN",        "001719");   					  		// 전문길이
				hmReq.put("COMPANY_CD",     "1002");     				     		// 회사코드
				hmReq.put("ERR_CD",         "");         					  		// 에러코드
				hmReq.put("DEAL_TYPE",      strInvcType); 							// 거래구분
				hmReq.put("TRAN_ID",        tranId);     					  		// 거래고유번호
				hmReq.put("SND_ZIP",   		strSndZip); 					  		// 송하인 우편번호
				hmReq.put("SND_ADD1",	    strSndAdd1); 					  		// 송하인 동이상 주소
				hmReq.put("SND_ADD2", 	    strSndAdd2); 					  		// 송하인 동미만 주소
				hmReq.put("SND_NAME",	    strSndName); 					  		// 송하인명
				hmReq.put("SND_TEL",   		strSndTel); 					  		// 송하인 전화번호1
				hmReq.put("SND_HPH",	    strSndHph); 					  		// 송하인 전화번호2
				hmReq.put("RCV_ZIP",   		strRcvZip); 					  		// 수하인 우편번호
				hmReq.put("RCV_ADD1",	    strRcvAdd1); 					  		// 수하인 동이상 주소
				hmReq.put("RCV_ADD2", 	    strRcvAdd2); 					  		// 수하인 동미만 주소
				hmReq.put("RCV_NAME",	    strRcvName); 					  		// 수하인명
				hmReq.put("RCV_TEL",   		strRcvTel); 					  		// 수하인 전화번호1
				hmReq.put("RCV_HPH",	    strRcvHph); 					  		// 수하인 전화번호2
				hmReq.put("ENP_DIV",        (String)hm.get("ENP_DIV"));       		// 택배구분
				hmReq.put("DLV_TYP",        (String)hm.get("DLV_TYPE"));     		// 배송구분
				hmReq.put("WBL_NUM",        (String)hm.get("WBL_NUM"));      		// 운송장번호
				hmReq.put("STORE_CD",       (String)hmComm.get("STORE_CD"));  		// 점포코드
				hmReq.put("POS_NO",         (String)hmComm.get("POS_NO"));    		// 포스번호
				hmReq.put("TRAN_NO",        (String)hmComm.get("TRAN_NO"));   		// 거래번호
				hmReq.put("STORE_NAME",     (String)storeInfo.get("STORE_NAME"));   // 점포명
				hmReq.put("ZIP_CD",     	"");   									// 점포우편번호
				hmReq.put("STORE_ADDR",     (String)storeInfo.get("STORE_ADDR"));   // 점포주소
				hmReq.put("STORE_TEL_NO",   (String)storeInfo.get("STORE_TEL_NO")); // 점포전화번호
				hmReq.put("TRAN_YMD",       tranDt); 	    						// 거래일자(20171109 KSN 택배 거래일자 POS영업일자 -> 시스템일자 기준으로 변경처리 (대사이슈로인한 개선처리))
				hmReq.put("PAYMENT_TP",     paymentTp); 	    					// 결제수단구분
				hmReq.put("TRN_FEE",     	(String)hm.get("TRN_FEE")); 	    	// 기본운임
				hmReq.put("ETC_FEE",     	(String)hm.get("ETC_FEE")); 	    	// 항공료,도선료,착불대행수수료
				hmReq.put("EXT_FEE",     	(String)hm.get("EXT_FEE")); 	    	// 할증료
				hmReq.put("SAL_FEE",     	(String)hm.get("SAL_FEE")); 	    	// 할인액
				hmReq.put("PAY_CON",     	payCon); 	    						// 지불구분
				hmReq.put("RCV_DATETIME",   ""); 	    							// 접수일시
				hmReq.put("SMT_IST",   		"N"); 	    							// 스마트박스 유무
				
				if("01".equals(msgType)){
					hmReq.put("RSV_WBL",   		""); 	    						// 원 운송장번호
					hmReq.put("CSR_NUM",   		""); 	    						// 반품접수건의 고객사 신용번호
					hmReq.put("RTN_NUM",   		"");								// 반품확인번호
				}else{
					hmReq.put("RSV_WBL",   		(String)hm.get("WBL_NUM")); 	    // 원 운송장번호
					hmReq.put("CSR_NUM",   		""); 	    						// 반품접수건의 고객사 신용번호
					hmReq.put("RTN_NUM",   		""); 	    						// 반품확인번호
				}
				
				hmReq.put("RCV_TAG",   		""); 	    							// 처리결과
				hmReq.put("ERR_MSG",  		""); 	    							// 에러메세지
			}
			
			sendMsg = makeSendDataHJParcelServiceCheck(hmReq);
			df.CommLogger("[sms>HJParcel SEND[" + sendMsg.getBytes().length + "]:[" + sendMsg + "]");
			
			//Socket 통신 시작 
			if( actSock.send(sendMsg) ) { // 요청 송신
				df.CommLogger("[sms>HJParcel] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[sms>HJParcel] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("HJParcel server is no response");
			}
			
			df.CommLogger("<<< START RECEIVE DATA FROM HANJIN >>>");
			recvBuf = ((String)actSock.receive()); // 요청 수신
			df.CommLogger("[sms<HJParcel RCV[" + recvBuf.getBytes().length + "]:[" + recvBuf + "]");
			
			hmRecv = makeRcvDataHJParcelCheckRsp(recvBuf);
			df.CommLogger("[sms<HJParcel RCV hmRecv[" + hmRecv + "]");

			// 20180221 한진무인택배(SCO)
			if ("2".equals(strInvcType)) {
				// 업무구분=2 자동송장인 경우
				// 택배 주문접수 정보 테이블(CP_PARCEL_RCV_INFO)에 진행 상태 플래그 PROC_ID의 갱신
				dao.updParcelPrivateInfoFlag(hm, df);
			}

		}catch(Exception e) { 
			df.CommLogger("▶ [ERROR]1: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close(); // Socket 통신 종료 
			
			if("00".equals((String)hmRecv.get("ERR_CD"))){
				hmRecv.put("RESULT_CODE", "Y");
			}else{
				hmRecv.put("RESULT_CODE", "E");
			}
			
			dataMsg = ret + makeSendDataHJParcelChkRslt(hmRecv);
			df.CommLogger("finally >>>>> dataMsg[" + dataMsg + "]");
		}
		
		return dataMsg;
	}
	
	
	private String makeSendDataHJParcelServiceCheck(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {
			2, 6, 4, 2, 1, 
			21, 1, 1, 15, 5, 
			4, 4, 30, 6, 250, 
			12, 8, 2, 9, 9, 
			9, 9, 2, 8, 200, 
			200, 100, 30, 30, 8,
			200, 200, 100, 30, 30,
			14, 1, 15, 10, 30,
			1, 100
		};
		String strHeaders[] = {
			"MSG_TYPE",       // 전문구분    
			"MSG_LEN",        // 전문길이    
			"COMPANY_CD",     // 회사코드 (한진측에서정하는 이마트24 회사코드)   
			"ERR_CD",         // 응답코드    
			"DEAL_TYPE",      // 거래구분 (1:수기송장, 2:자동송장)
			
			"TRAN_ID",        // 거래고유번호    
			"ENP_DIV",        // 택배구분     
			"DLV_TYP",        // 배송구분  
			"WBL_NUM",        // 운송장번호    
			"STORE_CD",       // 점포코드
			
			"POS_NO",         // 포스번호
			"TRAN_NO",        // 거래번호
			"STORE_NAME",     // 점포명
			"ZIP_CD",	      // 점포우편번호 
			"STORE_ADDR",     // 점포주소 
			
			"STORE_TEL_NO",   // 점포전화번호  
			"TRAN_YMD", 	  // 거래일자  
			"PAYMENT_TP",     // 결제수단구분
			"TRN_FEE",        // 기본운임
			"ETC_FEE",	      // 항공료,도선료,착불대행수수료
			
			"EXT_FEE",	      // 할증료
			"SAL_FEE",	      // 할인액
			"PAY_CON",        // 지불구분
			"SND_ZIP",        // 송하인 우편번호
			"SND_ADD1",       // 송하인 동이상주소
			
			"SND_ADD2",       // 송하인 동미만주소
			"SND_NAME",       // 송하인명
			"SND_TEL",        // 송하인전화번호1
			"SND_HPH",        // 송하인전화번호2
			"RCV_ZIP",        // 수하인 우편번호
			
			"RCV_ADD1",       // 수하인 동이상주소
			"RCV_ADD2",       // 수하인 동미만주소
			"RCV_NAME",       // 수하인명
			"RCV_TEL",        // 수하인전화번호1
			"RCV_HPH",        // 수하인전화번호2
			
			"RCV_DATETIME",	  // 접수일시
			"SMT_IST",		  // 스마트박스 유무
			"RSV_WBL",		  // 원 운송장번호
			"CSR_NUM",		  // 신용번호
			"RTN_NUM",	      // 반품번호
			
			"RCV_TAG",	      // 처리결과 
			"ERR_MSG"		  // 에러메세지
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	private String makeRecvDataHJParcelServiceCheck(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {
			2, 6, 4, 2, 1, 
			21, 1, 1, 15, 5, 
			4, 4, 30, 6, 250, 
			12, 8, 2, 9, 9, 
			9, 9, 2, 8, 200, 
			200, 100, 30, 30, 8,
			200, 200, 100, 30, 30,
			14, 1, 15, 10, 30,
			1, 100
		};
		String strHeaders[] = {
			"MSG_TYPE",       // 전문구분    
			"MSG_LEN",        // 전문길이    
			"COMPANY_CD",     // 회사코드 (한진측에서정하는 이마트24 회사코드)   
			"ERR_CD",         // 응답코드    
			"DEAL_TYPE",      // 거래구분 (1:수기송장, 2:자동송장)
			
			"TRAN_ID",        // 거래고유번호    
			"ENP_DIV",        // 택배구분     
			"DLV_TYP",        // 배송구분  
			"WBL_NUM",        // 운송장번호    
			"STORE_CD",       // 점포코드
			
			"POS_NO",         // 포스번호
			"TRAN_NO",        // 거래번호
			"STORE_NAME",     // 점포명
			"ZIP_CD",	      // 점포우편번호 
			"STORE_ADDR",     // 점포주소 
			
			"STORE_TEL_NO",   // 점포전화번호  
			"TRAN_YMD", 	  // 거래일자  
			"PAYMENT_TP",     // 결제수단구분
			"TRN_FEE",        // 기본운임
			"ETC_FEE",	      // 항공료,도선료,착불대행수수료
			
			"EXT_FEE",	      // 할증료
			"SAL_FEE",	      // 할인액
			"PAY_CON",        // 지불구분
			"SND_ZIP",        // 송하인 우편번호
			"SND_ADD1",       // 송하인 동이상주소
			
			"SND_ADD2",       // 송하인 동미만주소
			"SND_NAME",       // 송하인명
			"SND_TEL",        // 송하인전화번호1
			"SND_HPH",        // 송하인전화번호2
			"RCV_ZIP",        // 수하인 우편번호
			
			"RCV_ADD1",       // 수하인 동이상주소
			"RCV_ADD2",       // 수하인 동미만주소
			"RCV_NAME",       // 수하인명
			"RCV_TEL",        // 수하인전화번호1
			"RCV_HPH",        // 수하인전화번호2
			
			"RCV_DATETIME",	  // 접수일시
			"SMT_IST",		  // 스마트박스 유무
			"RSV_WBL",		  // 원 운송장번호
			"CSR_NUM",		  // 신용번호
			"RTN_NUM",	      // 반품번호
			
			"RCV_TAG",	      // 처리결과 
			"ERR_MSG"		  // 에러메세지
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	public HashMap<String, String> makeRcvDataHJParcelCheckRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {
				2, 6, 4, 2, 1, 
				21, 1, 1, 15, 5, 
				4, 4, 30, 6, 250, 
				12, 8, 2, 9, 9, 
				9, 9, 2, 8, 200, 
				200, 100, 30, 30, 8,
				200, 200, 100, 30, 30,
				14, 1, 15, 10, 30,
				1, 100
		};
		String strHeaders[] = {
				"MSG_TYPE",       // 전문구분    
				"MSG_LEN",        // 전문길이    
				"COMPANY_CD",     // 회사코드 (한진측에서정하는 이마트24 회사코드)   
				"ERR_CD",         // 응답코드    
				"DEAL_TYPE",      // 거래구분 (1:수기송장, 2:자동송장)
				
				"TRAN_ID",        // 거래고유번호    
				"ENP_DIV",        // 택배구분     
				"DLV_TYP",        // 배송구분  
				"WBL_NUM",        // 운송장번호    
				"STORE_CD",       // 점포코드
				
				"POS_NO",         // 포스번호
				"TRAN_NO",        // 거래번호
				"STORE_NAME",     // 점포명
				"ZIP_CD",	      // 점포우편번호 
				"STORE_ADDR",     // 점포주소 
				
				"STORE_TEL_NO",   // 점포전화번호  
				"TRAN_YMD", 	  // 거래일자  
				"PAYMENT_TP",     // 결제수단구분
				"TRN_FEE",        // 기본운임
				"ETC_FEE",	      // 항공료,도선료,착불대행수수료
				
				"EXT_FEE",	      // 할증료
				"SAL_FEE",	      // 할인액
				"PAY_CON",        // 지불구분
				"SND_ZIP",        // 송하인 우편번호
				"SND_ADD1",       // 송하인 동이상주소
				
				"SND_ADD2",       // 송하인 동미만주소
				"SND_NAME",       // 송하인명
				"SND_TEL",        // 송하인전화번호1
				"SND_HPH",        // 송하인전화번호2
				"RCV_ZIP",        // 수하인 우편번호
				
				"RCV_ADD1",       // 수하인 동이상주소
				"RCV_ADD2",       // 수하인 동미만주소
				"RCV_NAME",       // 수하인명
				"RCV_TEL",        // 수하인전화번호1
				"RCV_HPH",        // 수하인전화번호2
				
				"RCV_DATETIME",	  // 접수일시
				"SMT_IST",		  // 스마트박스 유무
				"RSV_WBL",		  // 원 운송장번호
				"CSR_NUM",		  // 신용번호
				"RTN_NUM",	      // 반품번호
				
				"RCV_TAG",	      // 처리결과 
				"ERR_MSG"		  // 에러메세지
		};

		int bInx=0;
		int eInx=0;	
		HashMap hm_sub = new HashMap();

		eInx = nlens[0];
		for(int i=0; i<nlens.length; i++ ){
			try {
				hm_sub.put(strHeaders[i].toString(), new String(rcvBuf.getBytes(), bInx, eInx));
			} catch (Exception e) {
				e.printStackTrace();	// TODO Auto-generated catch block
			}	
			if (i<nlens.length-1){
				bInx = bInx + eInx;
				eInx = nlens[i+1];
			}
		}
		return hm_sub;
	}
	
	
	private String makeSendDataHJParcelChkRslt(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 1, 100 };
		String strHeaders[] = {
			"RESULT_CODE",    // 처리결과
			"ERR_MSG"         // 에러메세지
		};
		
		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String)hm.get(strHeaders[i].toString()), nlens[i]);
		}
		System.out.println(sb.toString());
		return sb.toString();
	}

}