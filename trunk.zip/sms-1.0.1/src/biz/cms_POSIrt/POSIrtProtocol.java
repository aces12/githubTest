package biz.cms_POSIrt;

import java.util.HashMap;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class POSIrtProtocol {
	private static Logger logger = Logger.getLogger(POSIrtAction.class);
	public int getRcvPOSIrtDATA(String rcvBuf) {
		HashMap hm = new HashMap();
		int ret = 0;
		int nlens[]= {2};	/* Common to Message Data Part(전문 데이터부 공통) */
		
		String strHeaders[] = {
			"INQ_TYPE"	// INQ Type(INQ 종별)
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if( Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE")) ) {
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}else{
			ret = ((String)hm.get("INQ_TYPE")).hashCode();
		}
		return ret;
	}

	public HashMap<String, String> getParseStrStockNowInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 30, 1};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ TYPE(INQ 종별)
			"ITEM_CD",			// 상품코드
			"OPTION"			// 조회옵션
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseParcelServiceCpl(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 5, 3};
		int nCnt = 0;
		int bInx = 0;
		int eInx = 0;
		String strHeaders[] = {
			"INQ_TYPE",			// INQ_TYPE(INQ 종별)
			"STORE_CD",			// 점포코드
			"PARCEL_CNT"		// 운송장 처리 카운트
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		nCnt = Integer.parseInt((String)hm.get("PARCEL_CNT").trim());
		
		bInx = 10;
		eInx = 10 + 20;
		for(int i = 0;i < nCnt;i++) {
			hm.put("PARCEL_CD"+Integer.toString(i), rcvBuf.substring(bInx, eInx).trim());
			bInx = eInx;
			eInx = bInx + 20;
		}
		
		return hm;
	}
	
	public HashMap<String, String> getParseParcelServiceList(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 5};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ_TYPE(INQ 종별)
			"STORE_CD"			// 점포코드
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseParcelCDCheck(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 20};
		String strHeaders[] = {
			"INQ_TYPE",
			"PARCEL_CD"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	public HashMap<String, String> getParseHJParcelCDCheck(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 15};
		String strHeaders[] = {
			"INQ_TYPE",
			"PARCEL_CD"
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	public HashMap<String, String> getParseRecptPromCoupon(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 5, 4, 8, 4};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ_TYPE(INQ 종별
			"STORE_CD",			// 점포코드
			"POS_NO",			// 포스번호
			"TRAN_YMD",			// 영업일자
			"TRAN_NO"			// 거래번호
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParsePosSettInfo(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 5, 4};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ_TYPE(INQ 종별)
			"STORE_CD",			// 점포코드
			"POS_NO"			// 포스번호
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseCheckPDATranExist(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 5};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ TYPE(INQ 종별)
			"STORE_CD"			// 점포코드
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParsePDAEmergencyTran(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 5};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ TYPE(INQ 종별)
			"STORE_CD"			// 점포코드
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseCreditCustInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,5,30};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ TYPE(INQ 종별)
			"STORE_CODE",		// 점포 코드
			"CUSTOMER_ID"		// 외상고객 식별번호
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseCashRcptInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,1,20,9,14};
		String strHeaders[] = {
			"INQ_TYPE",
			"RES_CD",
			"IDENTI_INFO",
			"APPROVAL_NO",
			"APPROVAL_YMDHMS"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseCreditCustInq2(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,5,1,60};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ TYPE(INQ 종별)
			"STORE_CODE",		// 점포코드
			"INQ_FLAG",			// 조회구분
			"INQ_VALUE"			// 조회값
		};
		
//		logger.info("▶ getParseCreditCustInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseDeliveryCheck(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,5,4,20,8
					  ,6};
		String strHeaders[] = {
			"INQ_TYPE",
			"STORE_CD",
			"POS_NO",
			"INVOICE_NUMBER",
			"REG_YMD",
			
			"REG_HMS"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSVCheck(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,5,4,13,1
					  ,8,6};
		String strHeaders[] = {
			"INQ_TYPE",
			"STORE_CD",
			"POS_NO",
			"SV_ID",
			"SV_FLG",
			
			"REG_YMD",
			"REG_HMS"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseISPCheck(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,5,4,20,8
					  ,6};
		String strHeaders[] = {
			"INQ_TYPE",
			"STORE_CD",
			"POS_NO",
			"ISPITEM_CD",
			"REG_YMD",
			
			"REG_HMS"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseStaffCheck(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 5, 4, 1, 10, 80, 1, 8, 6};
		String strHeaders[] = {
			"INQ_TYPE",       // INQ종별
			"STORE_CODE",     // 점포코드
			"POS_NO",         // POS번호
			"CONF_GUBUN",     // 인증방법구분
			"ELEC_STAFF",     // 전자사원증
			"CARD_NO",        // 신용카드
			"KEY_IN",         // KEY_IN 유무
			"REG_YMD",        // 등록일자
			"REG_HMS"         // 등록시간
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseStaffCheckRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 2, 4, 2, 10, 10, 50, 50, 10, 50, 60};
		String strHeaders[] = {
			"INQ_TYPE",      // INQ종별
			"RES_CD",        // 결과코드
			"RETURN_CD",     // 응답코드
			"EMPLOYEE_YN",   // 직원유무
			"EMPLOYEE_ID",   // 사번
			"COMP_CD",       // 소속사코드
			"COMP_NM",       // 소속사명
			"EMPLOYEE_NM",   // 이름
			"RANK_CD",       // 직급코드
			"RANK_NM",       // 직급명
			"RSP_MESSAGE"    // 응답메시지
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCnclFailRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseScAgentReq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 8, 5, 5, 1};
		String strHeaders[] = {
			"INQ_TYPE",      // INQ종별
			"SC_DT",			// 일자
			"STORE_CD",			// 점포코드
			"SC_SEQ",			// 순번
			"PROC_ID"			// 상태코드
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseScAgentIpReq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 8, 5, 5, 1, 15};

		String strHeaders[] = {
			"INQ_TYPE",      // INQ종별
			"SC_DT",			// 일자
			"STORE_CD",			// 점포코드
			"SC_SEQ",			// 순번
			"PROC_ID",			// 상태코드
			"STORE_IP"			// 점포IP
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseHJParcelServiceReq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 1, 1, 1, 15, 9, 9, 9, 9, 1};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ_TYPE(INQ 종별)
			"INVC_TYPE",		// 택배업무구분
			"ENP_DIV",			// 택배구분
			"DLV_TYPE",			// 배송구분
			"WBL_NUM",			// 운송장번호
			"TRN_FEE",			// 기본운임
			"ETC_FEE",			// 도선료
			"EXT_FEE",			// 할증료
			"SAL_FEE",			// 할인액
			"PAY_DIV"			// 지불구분
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	
	//20170905 KSN 한진택배 환불가능여부 요청/응답 추가
	public HashMap<String, String> getParseHJParcelRefundYnCheck(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 5, 4, 15, 2};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ_TYPE(INQ 종별)
			"STORE_CD",			// 원 점포코드
			"TRAN_NO",			// 원 거래번호
			"WBL_NUM",			// 운송장번호
			"RESULT_CODE"		// 처리결과
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		return hm;
	}

	/**
	 * 한진 무인택배 송장번호 발행요청/응답 BODY정보 파싱
	 * 주) 요청이므로 INQ_TYPE이외에는 공백 또는 무의미한 정보
	 * @param rcvBuf
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public HashMap<String, String> getIQParcelCdReq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 20, 2, 64};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ_TYPE(INQ 종별)
			"PARCEL_CD",		// 송장번호
			"RESP_CD",			// 응답코드
			"RESP_MSG"			// 응답메시지
		};

		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);

		return hm;
	}

	/**
	 * 한진 무인택배 송장번호 발행완료/응답 BODY정보 파싱
	 * @param rcvBuf
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public HashMap<String, String> getIQParcelCdFin(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 20, 2, 64};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ_TYPE(INQ 종별)
			"PARCEL_CD",		// 송장번호
			"RESP_CD",			// 응답코드
			"RESP_MSG"			// 응답메시지
		};

		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);

		return hm;
	}

	/**
	 * 한진 무인택배 택배 터미널 ID 취득 요청/응답 BODY정보 파싱
	 * @param rcvBuf
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public HashMap<String, String> getIQPTerminalReq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2, 2, 64, 4, 1, 12, 6, 10, 30, 6, 10, 30, 2, 2, 2, 10, 30, 30, 30};
		String strHeaders[] = {
			"INQ_TYPE",			// INQ_TYPE(INQ 종별)
			"RESP_CD",			// 응답코드
			"RESP_MSG",			// 응답메시지
			"DIVISION_TP",		// 권역구분(도착지, 7 : 제주, 9 : 도서)
			"QUICK_YN",			// 퀵지역구분
			"PARCEL_TOT_AMT",	// 택배운임그액(한진택배측 쿼리 활용)
			"SND_POST_NO",		// 송하인 우편번호
			"SND_TERMINAL_ID",	// 송하인 터미널ID
			"SND_TERMINAL_NM",	// 송하인 터미널명
			"RCV_POST_NO",		// 수하인 우편번호
			"RCV_TERMINAL_ID",	// 수하인 터미널ID
			"RCV_TERMINAL_NM",	// 수하인 터미널명
			"RCV_HUB_CD",		// 도착지 대분류코드
			"RCV_MID_CD",		// 도착지 중분류코드
			"RCV_SUB_CD",		// 도착지 소분류코드
			"RCV_SALE_CD",		// 도착지 영업소코드
			"RCV_SALE_NM",		// 도착지 영업소명
			"ES_NAME",			// 배송원명
			"RCV_COL_AREA_NM",	// 도착지 집배구역명
		};

		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);

		return hm;
	}
}