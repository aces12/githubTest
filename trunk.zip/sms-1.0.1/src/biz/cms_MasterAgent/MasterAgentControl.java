package biz.cms_MasterAgent;

public class MasterAgentControl {
	public synchronized void useThread() throws InterruptedException {
		//System.out.println( "lend :" + MasterCrtClientAction.getJobThread());
		if (MasterAgentPOSOperator.getJobThread() <= 0) {
			//System.out.println(t.getName() + ": wating...");
			this.wait();
			//System.out.println(t.getName() + ": return...");
		}
		MasterAgentPOSOperator.decrement();
	}
	
	public synchronized void returnThread() {
		MasterAgentPOSOperator.increment();
		this.notify();
	}
}
