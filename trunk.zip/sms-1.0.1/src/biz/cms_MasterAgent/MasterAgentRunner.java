package biz.cms_MasterAgent;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;

public class MasterAgentRunner extends Thread {
	private static Logger logger = Logger.getLogger(MasterAgentPollingAction.class);
	private final int POS_PORT = 9029;
	//private final int MAX_TARGET_NUM = 100;
	private int curWork = 0;
	private int curRetryCnt = 0;
	public MasterAgentPOSOperator operator = null;
	private Map<String, String> map = null;
	
	public MasterAgentRunner(int curRetryCnt , MasterAgentPOSOperator operator) {
		this.curRetryCnt = curRetryCnt;
		this.operator = operator;
	}
	
	public void setMap(Map<String, String> map) {
		this.map = map;
	}

	public void run() {
		try {
		
			//operator.msControl.useThread();
		
			//logger.info("The number of running threads : " + Integer.toString(operator.getMaxThread() - operator.getJobThread()) + ", " + (String)map.get("POS_IP"));
			sendOrderToPOS(map);
			
			//operator.workIncrement();
			this.curWork = operator.getWork();
			operator.msControl.returnThread();
			
			logger.info("★"+operator.action.getCurMaprCnt()+"getTotalWork :"+ operator.getTotalCount() 
					+ "★getWork:" +operator.getWork() 
					+ "★curWork:" +this.curWork );                                      
			
			if(operator.getThreadEnd(curWork)){//if (operator.getStatus()) {	
				operator.setWorkInit();
				logger.info("★★ _"+operator.action.getCurMaprCnt()+"_nd make and sendOrder END★★★★");
								
				if(operator.action.getCurMaprCnt() == 2){

					sleep(9000);
					logger.info("★★★★★★★★ LAST RETRY START★★★★★★★★★");					
					operator.action.setMaprMap(3,map);
					operator.action.startThread(3);		//logger.info("★ retryCnt:"  +3 +"startThread★" );					
					operator.action.releaseThread(2);	//logger.info("★ retryCnt:"  +2 +"releaseThread★" );					

				}else if(operator.action.getCurMaprCnt() == 3){
					operator.action.releaseThread(3);	//logger.info("★ retryCnt:"  +3 +"releaseThread★" );						
					operator.action.setCurMaprCnt(0); 
					
					sleep(9000);
					logger.info("★★ ★★ ★★ ★★WHOLE RETRY ROUTINE is END ★★ ★★ ★★ ★★ ★★ ★★ ★★ ★★ ★★ ");
					updFlag3Fail(map);

				} 
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
	}
	private void updFlag3Fail(Map<String, String> map){
		MasterAgentDAO dao = new MasterAgentDAO();
		
		dao.updOPERIDFLAG3FAIL(map);
		
	}
	private void sendOrderToPOS(Map<String, String> map) {
		MasterAgentDAO dao = new MasterAgentDAO();
		Socket sock = null;
		ActionSocket actSock = null;
		String sendData = "";
		String recvData = "";
		boolean bIsOK = false;
//		logger.info("★★ 2nd sendOrderToPOS★★  "
//				+"★STORE_CD:" +(String)map.get("STORE_CD")
//				+"★POS_NO:" +(String)map.get("POS_NO")
//				+"★POS_IP:" +(String)map.get("POS_IP")
//				+"★NEW_DEPLOY_YN:" +(String)map.get("NEW_DEPLOY_YN")				
//		);		
		
		
		// PROC_ID = "0":미송신, "1":송신중, "2":송신완료, "3":송신에러, "4":전송 3회 모두 송신실패 , "5": POS IP 없음  
		try {
			
			//sock = new Socket((String)map.get("POS_IP"), POS_PORT);
			sock = new Socket();
			SocketAddress serverAddress = new InetSocketAddress((String)map.get("POS_IP"), POS_PORT);
			sock.connect(serverAddress, 3000);
			
			actSock = new ActionSocket(sock, (Filter)(new COMMConveyerFilter(COMMBiz.MASTER_EXT_FILTER)));
			
			actSock.getSocket().setSoTimeout(3000);
						
			sendData = makeMasterOrderMessage(map);
			logger.info("[sms>pos] STORE_CD["+ (String)map.get("STORE_CD")
					+"]POS_NO["+ (String)map.get("POS_NO")
					+"]TRANS_SEQ["+ (String)map.get("TRANS_SEQ")
					+"]IP:"+ (String)map.get("POS_IP")
					+"length[" + sendData.length() + "]::[" + sendData + "]"
					);
			
			if( actSock.send(sendData) ) {
//				logger.info("[sms>pos] STORE_CD["+ (String)map.get("STORE_CD")
//						+"]TRANS_SEQ["+ (String)map.get("TRANS_SEQ")
//						+"]IP:"+ (String)map.get("POS_IP")						
//						+"[sms>pos] SEND["+ sendData.length() + "] OK");
			}
			
			recvData = (String)actSock.receive();
			//logger.info("[sms<pos] RECV[" + recvData.length() + "]:[JOB_CODE:]:[" + recvData + "]");
			
			if( recvData.trim().equals("OK") ) {
				bIsOK = true;
				dao.updTARGETMASTERLIST(map, "2");
				logger.info("[★RECV OK★] [IP: "+ (String)map.get("POS_IP") +"]POS_NO["+ (String)map.get("POS_NO")+ "] [STORE_CD:"+(String)map.get("STORE_CD")+ "]:[recvData][" + recvData + "]");
			}else {
				dao.updTARGETMASTERLIST(map, "3");
				logger.info("[recv OK FAIL ] [IP: "+ (String)map.get("POS_IP") + "] [STORE_CD:"+(String)map.get("STORE_CD")+"]");
			}
		}catch(SocketTimeoutException ste) {		
			dao.updTARGETMASTERLIST(map, "3");
			logger.info("["+curRetryCnt+"rd][ERROR:TimeOut][STORE_CD:"+(String)map.get("STORE_CD")+"]POS_NO["+ (String)map.get("POS_NO")+"][IP: "+ (String)map.get("POS_IP") + "]" + ste.getMessage());
		}catch(Exception e) {						 
			dao.updTARGETMASTERLIST(map, "3");
			logger.info("["+curRetryCnt+"rd]Exception ERROR][STORE_CD:"+(String)map.get("STORE_CD")+"]POS_NO["+ (String)map.get("POS_NO")+ "][IP: "+ (String)map.get("POS_IP") + "]" + e.getMessage());
		}finally {
			if(actSock != null) actSock.close();
		}
	}
	
	public String getLocalIP() {
		InetAddress iAddress;
		String currentIp = "";
		try {
			iAddress= InetAddress.getLocalHost();
			currentIp = iAddress.getHostAddress();
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return currentIp;
	}
	
	public String makeMasterOrderMessage(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		
		try {
			String transId = (String)map.get("TRANS_ID");
			String fileDir = (String)map.get("TRANS_FILE_DIR");						
			
			StringUtil.appendSpace(sb, "04", 2);	// 01.INQ_종별("04":파일전송의뢰)
					
			if( transId.equals("PGM") ) {
				transId = "01";
			}else if( transId.equals("MST") ) {
				transId = "02";
			}else if( transId.equals("CUSTDSP") ) {
				transId = "03";
			}else if( transId.equals("FFIMG") ) {
				transId = "04";
			}else if( transId.equals("POSDLL") ) {
				transId = "05";
			}else if( transId.equals("MSG") ) {
				transId = "06";
			}else {
				transId = "%";
			}
			
			// 긴급 메세지의 경우 전문 형태가 다르다. 
			if( transId.equals("06") ) {
				MasterAgentDAO dao = new MasterAgentDAO();
				List<Object> list = dao.selURGENTMSGLIST(map);
				if( list.size() > 0 ) {
					Map<String, String> m = (Map<String, String>)list.get(0);
					
					StringUtil.appendSpace(sb, transId, 2);						// 01.상세종별(01:프로그램,02:마스터,03:객면컨텐츠,04:상품이미지,05:POSDLL,06:긴급메세지)
					StringUtil.appendSpace(sb, (String)m.get("TRANS_VER"), 10);	// 02.메시지번호
					StringUtil.appendSpace(sb, (String)m.get("URGENT_YN"), 1);	// 03.메시지구분
					StringUtil.appendSpace(sb, (String)m.get("POS_SYMDHMS"),12);// 04.게시시작일시
					StringUtil.appendSpace(sb, (String)m.get("POS_EYMDHMS"),12);// 05.게시종료일시
					StringUtil.appendSpace(sb, (String)m.get("MSG_TITLE"), 100);// 06.메시지(타이틀)
					StringUtil.appendSpace(sb, (String)m.get("MSG_CONT"), 1000);// 07.메시지					
				}
				
			}else {
				StringUtil.appendSpace(sb, transId, 2);							// 01.상세종별(01:프로그램,02:마스터,03:객면컨텐츠,04:상품이미지,05:POSDLL,06:긴급메세지)
				StringUtil.appendSpace(sb, (String)map.get("URGENT_YN"), 1);	// 02.적용구분(0:일반배신,1:즉시적용,2:긴급적용)
				StringUtil.appendSpace(sb, (String)map.get("TRANS_YMD"), 14);	// 03.적용일시
				StringUtil.appendSpace(sb, getLocalIP(), 15);					// 04.서버IP
				int dot = fileDir.lastIndexOf("/");
				StringUtil.appendSpace(sb, fileDir.substring(0, dot), 100);		// 05.파일경로
				StringUtil.appendSpace(sb, fileDir.substring(dot+1), 20);		// 06.파일명
				StringUtil.appendSpace(sb, (String)map.get("TRANS_VER"), 30);	// 07.파일버전
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return sb.toString();
	}
	
	
	
	
	
}
