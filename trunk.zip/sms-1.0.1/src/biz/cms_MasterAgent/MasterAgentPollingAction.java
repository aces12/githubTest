/*
 * MasterCrtAgentPollingAction.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_MasterAgent;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.CurrentContext;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.node.EngineContainer;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.DaemonContainer;
import kr.fujitsu.com.ffw.daemon.net.polling.ActionPollingContainer;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.cms_CashBeeSender.CashBeeSenderDAO;
import biz.cms_DeployReq.DeployReqClientAction;
import biz.cms_MasterAgent.MasterAgentPOSOperator;
import biz.cms_MasterCrt.MasterCrtClientAction;


/** 
 * MasterAgentPollingAction
 * Divide sale transaction data(매출 Tran 데이터 분리) 
 * @created  on 1.0,  11/03/17
 * @created  by khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by 
 */ 
public class MasterAgentPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(MasterAgentPollingAction.class);

	//private final int MAX_TARGET_NUM = 100;

	private String TRANS_ID = "";
	
	public void execute(String actionMode) {

		try {
			MasterAgentDAO dao   = new MasterAgentDAO();
			List list = null;
			int totalCount=0;
			int ret = -1;
		
//			Date date = new Date();
//			SimpleDateFormat sdf = null;
//			sdf = new SimpleDateFormat("yyyyMMdd");
//			String tran_ymd = sdf.format(date);
			
			// 정기배신 마스터 생성이 오후 11시 30분에 생성되는 것으로 변경되면서
			// 마스터 생성 기준일이 현재일자 + 1 로 변경됨(마스터파일 버전과 관련이 있음)
			// 20140321/조충연
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			String today = sdf.format(calendar.getTime());
			
			calendar.add(Calendar.DATE, 1);
			String tran_ymd = sdf.format(calendar.getTime());
			
			String local_no = PropertyUtil.findProperty("communication-property", "LOCAL_SERVER_NO");

			/**
			 * 현재 배신생성중(OPER_ID=1)인 ROW 조회. 생성 중이라면 다른 Thread를 생성하지 않음
			 */
			int in_progress_cnt = dao.selCNTINPROGRESS(today, tran_ymd,local_no);
			
			if( in_progress_cnt > 0 ) {
				logger.info("[INFO] Don't create master because of creating master now.(cnt=" + in_progress_cnt + ")");
			}
			else {
				//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
				if (actionMode == "1")
				{
					//마스터 생성 정보 생성
					Map map = new HashMap();
					map.put("tran_ymd", tran_ymd);//정기 배신이므로 +1
					map.put("com_cd", "%");
					map.put("store_cd", "%");
					map.put("create_ty", "ALL");
					map.put("server_no", local_no);  //1 : 1번서버, 2 : 2번서버, 3 : 3번서버 
	
					logger.info("[ACTION_TIME] procMSTINFOCRT:" + tran_ymd);
					ret = dao.procMSTINFOCRT(map);
					
					if (ret == 0) {
						//마스터 생성 프로세스 구동
						MasterCrtClientAction master = new MasterCrtClientAction();
						
						//daemon-config 경로
						String basePath = PropertyUtil.findProperty("stsys-property", "SMS_ROOT");
						//basePath = basePath + "\\xml\\daemon-config.xml";
						basePath = basePath + File.separator + "xml" + File.separator + "daemon-config.xml";
		
						master.setOutTransSeq(1);
						master.setMaxThread(10);
						master.setTransYmd(tran_ymd);
						master.setCom("%");
						master.setStore("%");
						master.setPath(basePath);
						master.setDeploy(false);
						master.setTransid("MST");
						logger.info("[regular time] MasterCrtClientAction:" + tran_ymd);
						master.execute();
					}
				}
				
				else if (actionMode == "0")
				{ 
					//(금일 수동배신 마스터 정보 유무 조회)
					list = dao.selMASTERAGENTMANUAL(today);
					totalCount = list.size();
					if  (totalCount > 0) {this.TRANS_ID = "MST";}
		
					if (totalCount == 0){
						//logger.info("selPGMMANUAL");
						list = null;
						list = dao.selPGMMANUAL(today);
						totalCount = list.size();
						if  (totalCount > 0) {this.TRANS_ID = "PGM";}
					} 
					if (totalCount == 0){
						//logger.info("selMSGMANUAL");
						list = null;
						list = dao.selMSGMANUAL(today);
						totalCount = list.size();
						if  (totalCount > 0) {this.TRANS_ID = "MSG";}
					} 
										
					// If there is no subjective store, print log(금일 정기마스터 생성로그가 없으면 생성)
					if (totalCount > 0) {
						logger.info("[DEBUG]Manual Master list totalCount:" + totalCount + ":::this.TRANS_ID:"+this.TRANS_ID );
						Map<String, String> map = (Map<String, String>)list.get(0);
						
						//마스터 생성 프로세스 구동
						MasterCrtClientAction master = new MasterCrtClientAction();
						
						//daemon-config 경로
						String basePath = PropertyUtil.findProperty("stsys-property", "SMS_ROOT");
						//basePath = basePath + "\\xml\\daemon-config.xml";
						basePath = basePath + File.separator + "xml" + File.separator + "daemon-config.xml";
		
						master.setOutTransSeq(Integer.parseInt((String)map.get("trans_seq")));
						master.setMaxThread(10);
						master.setTransYmd(today);
						master.setCom("%");
						master.setStore("%");
						master.setPath(basePath);
						master.setDeploy(false);
						master.setTransid((String)map.get("trans_id"));
	//					logger.info("[DEBUG] MasterCrtClientAction:" + today);
						master.execute();
						//logger.info("master.execute()end");
 					}
				}								
			}			 
			// 쓰레드 Sleep
			//Thread.sleep(3000);			
		} catch (Exception e) {
			logger.info("", e);
		}
	}	
}
