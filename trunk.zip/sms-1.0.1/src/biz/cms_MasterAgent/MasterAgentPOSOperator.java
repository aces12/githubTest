package biz.cms_MasterAgent;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.cms_MasterCrt.MasterCrtClientAction;

public class MasterAgentPOSOperator {
	private static Logger logger = Logger.getLogger(MasterAgentPollingAction.class);
	public static MasterAgentControl msControl = new MasterAgentControl();
	private final int POS_PORT = 9029;
	
	private static int jobThread=0;
	private static int maxThread=0;	
	private static int work=0;
	private static int totalCount=0;
	public MasterCrtClientAction action = null;
	private int curRetryCnt=0;
	
	MasterAgentPOSOperator (int curRetryCnt, MasterCrtClientAction action){
		this.curRetryCnt = curRetryCnt;
		this.action = action; 

	}
	public static void increment(){
		jobThread++;
	}

	public static void decrement(){
		jobThread--;
	}
	
	public static int getJobThread(){
		return jobThread;
	}
	
	public static int getMaxThread(){
		return maxThread;
	}
	
	public void setMaxThread(int maxThread){
		if( getMaxThread() == 0 ) {
			this.maxThread = maxThread;
			this.jobThread = maxThread;
		}
	}
	
	public static void workIncrement(){
		++work;
	}
	
	public static void setWorkInit(){
		work = 0;
	}
	public int getWork(){
		return work;
	}
	
	public int getTotalCount(){
		return totalCount;
	}
	
	public static boolean getStatus(){
		if (work==totalCount) return true;
		return false;
	}	
	
	public static boolean getThreadEnd(int curWork){
		if (curWork==totalCount) return true;
		return false;
	}
	
	
	public void pushRequest(List<Object> list) {
		MasterAgentDAO dao = new MasterAgentDAO();
		Map<String, String> map = null;
		
		try {
			totalCount = list.size();
			setWorkInit(); 
			logger.info("★★★_"+curRetryCnt+"_ MasterAgentRunner start★★★totalCount=>" + totalCount+"★★★");
			for(int i = 0;i < totalCount;i++) {
				map = (Map<String, String>)list.get(i);
				
				if( ((String)map.get("POS_IP")).length() == 0 ) {
					// PROC_ID = "0":미송신, "1":송신중, "2":송신완료, "3":송신에러, "4":전송 3회 모두 송신실패 , "5": POS IP 없음
					dao.updTARGETMASTERLIST(map, "5");
					continue;
				}
				//logger.info("IP:"+(String)map.get("POS_IP")+" PORT:"+Integer.toString(POS_PORT));
				//for test
				/*if( ((String)map.get("POS_IP")).equals("10.149.206.188") )
					map.put("POS_IP", "10.100.116.180");
				if( ((String)map.get("POS_IP")).equals("10.149.206.178") )
					map.put("POS_IP", "10.100.116.181");
				if( ((String)map.get("POS_IP")).equals("10.149.206.179") )
					map.put("POS_IP", "10.100.116.182");
				if( ((String)map.get("POS_IP")).equals("10.149.206.180") )
					map.put("POS_IP", "10.100.116.183");*/
				msControl.useThread();
				
				workIncrement();
				// create thread object				
				MasterAgentRunner runner = new MasterAgentRunner(curRetryCnt , this);
				
				// set map object
				runner.setMap(map);
				// execute thread
				runner.start();				
//				logger.info("★_"+curRetryCnt+"_ Thread Count:[" + i + "], totalcount:[" + totalCount+ "], work:[" + getWork()+"]");		
			}
			logger.info("★★★_"+curRetryCnt+"_ MasterAgentRunner thread routine end★★★totalCount=>" + totalCount+"★★★");
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		System.gc();
	}
}
