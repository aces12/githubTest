package biz.comm;

import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import org.apache.log4j.Logger;


import biz.cms_CashBackIrt.CashBackData;

import kr.fujitsu.com.ffw.daemon.net.filter.Filter;

public class COMMConveyerFilter implements Filter {
	private static Logger logger = Logger.getLogger(COMMBiz.class);
	
	private int iWhoAmI = 0;
	
	public COMMConveyerFilter() {
		this.iWhoAmI = 0;
	}
	
	public COMMConveyerFilter(int iWhoAmI) {
		this.iWhoAmI = iWhoAmI;
	}
	
	public Object receive(InputStream in) throws Exception {
		StringBuilder ret = new StringBuilder();
		String getData = "";
		
		try {
			if( iWhoAmI == COMMBiz.CASHBEE_FILTER || iWhoAmI == COMMBiz.SSGPOINT_FILTER || iWhoAmI == COMMBiz.SSGPAY_FILTER ) {
				byte[] byteLength = readData(in, 4);
				String strLength = new String(byteLength);
				ret.append(strLength);
				
				int len = Integer.parseInt(strLength);
				byte[] data = readData(in, len - 4);
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.TMONEY_FILTER || iWhoAmI == COMMBiz.CASHBEE_MST_FILTER ) {
				byte[] byteCmdType = readData(in, 2);
				String cmdType = new String(byteCmdType);
				ret.append(cmdType);
				
				byte[] byteLength = readData(in, 2);
				ret.append(new String(byteLength));
				
				int len = Integer.parseInt(COMMBiz.bytesToHex(byteLength), 16);
				
				byte[] data = readData(in, len);
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.TMONEY_EXT_FILTER || iWhoAmI == COMMBiz.CASHBEE_EXT_FILTER || iWhoAmI == COMMBiz.HANPAY_ADJ_FILTER || iWhoAmI == COMMBiz.RAILPLUS_ADJ_FILTER ) {
				byte[] byteLength = readData(in, 4);
				String strLength = new String(byteLength);
				ret.append(strLength);
				
				int len = Integer.parseInt(strLength);
				byte[] data = readData(in, len);
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.DGB_ADJ_FILTER ) {
				byte[] byteLength = readData(in, 4);
				String strLength = new String(byteLength);
				ret.append(strLength);
				
				int len = Integer.parseInt(strLength)-4;
				byte[] data = readData(in, len);
				ret.append(new String(data));
			}
			
			else if( iWhoAmI == COMMBiz.CJPARCEL_FILTER ) {
				byte[] data = readData(in, 20);
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.MASTER_EXT_FILTER ) {
				byte[] data = readData(in, 10);
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.CASHRCPT_FILTER ) {
				byte[] data = readData(in, 160);
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.CASHRCPT_EXT_FILTER ) {
				byte[] data = readData(in, 160 + 128);
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.HANPAY_RT_FILTER ) {
				byte[] byteHeader = readData(in, 28);
				String strHeader = new String(byteHeader);
				ret.append(strHeader);
				
				byte[] byteDataLength = readData(in, 8);
				ret.append(new String(byteDataLength));
				
				int len = Integer.parseInt((new String(byteDataLength)));
				
				byte[] data = readData(in, len);
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.RAILPLUS_RT_FILTER ) {
				byte[] byteTaskType = readData(in, 2);
				String TaskType = new String(byteTaskType);
				ret.append(TaskType);
				
				byte[] byteLength = readData(in, 2);
				ret.append(new String(byteLength));
				
				int len = Integer.parseInt(COMMBiz.bytesToHex(byteLength), 16);
				
				byte[] data = readData(in, len);
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.GTF_FILTER ) {			
				byte[] byteLength = readData(in, 5);
				String strLength = new String(byteLength);
				ret.append(strLength);

				int len = Integer.parseInt(strLength) -5;
				byte[] data = readData(in, len);
				ret.append(new String(data));

			}else if( iWhoAmI == COMMBiz.TELECOM_FILTER ) {	
				byte[] data = readData(in, 240);
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.CASHBACK_FILTER ) {	

				byte[] byteLength = readData(in,10);
				String strLength = new String(byteLength);
				ret.append(strLength);
							
				int len = Integer.parseInt(strLength.substring(5,10)) -10;
				byte[] data = readData(in, len);
				ret.append(new String(data));
						
				
				int jobType = Integer.parseInt(ret.substring(14,18)); 
				int tmp =0;
				switch(jobType)
				{
				case 4310:
				case 4370:	
					tmp = len +10 -CashBackData.COMMONHFIX - CashBackData.PGREQ95FIX;
					CashBackData.setEncLen(Integer.parseInt(strLength.substring(5,10)) -CashBackData.COMMONHFIX - CashBackData.PGREQ95FIX );
					break;
				case 4320:					
					tmp = len +10 -CashBackData.COMMONHFIX - CashBackData.PGREQ96FIX  ;
					CashBackData.setEncLen(Integer.parseInt(strLength.substring(5,10)) -CashBackData.COMMONHFIX - CashBackData.PGREQ96FIX  );
					break;
				case 7210:
					tmp = len +10 -CashBackData.COMMONHFIX - CashBackData.PGREQ97FIX  ;
					CashBackData.setEncLen(Integer.parseInt(strLength.substring(5,10)) -CashBackData.COMMONHFIX - CashBackData.PGREQ97FIX  );
					break;
				case 2190:					
					tmp = len +10 -CashBackData.COMMONHFIX - CashBackData.PGREQ98FIX  ;
					CashBackData.setEncLen(Integer.parseInt(strLength.substring(5,10)) -CashBackData.COMMONHFIX - CashBackData.PGREQ98FIX  );
					break;					
				}
			}else if( iWhoAmI == COMMBiz.CASHBACK_FILTER_COMMON ) {	//neo0531 cashback ???
				logger.info("iWhoAmI=====:" + iWhoAmI);
				byte[] byteLength = readData(in,10);
				String strLength = new String(byteLength);
				logger.info("strLength=====:" + strLength);
				ret.append(strLength); //version+fsize
				logger.info("ret=====:" + ret);
				int len = Integer.parseInt(strLength.substring(5,10)) -10;
				logger.info("len=====:" + len);
				byte[] data = readData(in, len);
				ret.append(new String(data));
				logger.info("ret=====:" + ret);
		
				
				

			}else if( iWhoAmI == COMMBiz.MFC_WEBCASH_FILTER ) {					
				byte[] byteLength = readData(in, 4);		
				String strLength = new String(byteLength);	
				ret.append(strLength);						
				
				int len = Integer.parseInt(strLength) -4;	
				byte[] data = readData(in, len);			
				ret.append(new String(data));				
			}else if( iWhoAmI == COMMBiz.MFC_PURMEE_FILTER ) {					
				byte[] byteLength = readData(in, 4);		
				String strLength = new String(byteLength);	
				ret.append(strLength);						
				
				int len = Integer.parseInt(strLength);		
				byte[] data = readData(in, len);			
				ret.append(new String(data));				
				
			}else if( iWhoAmI == COMMBiz.DGB_FILTER ) {		
				byte[] byteLength = readData(in, 5);
				String strLength = new String(byteLength);	
				ret.append(strLength);	
				
				int len = Integer.parseInt(strLength.substring(1, 5)) +1;	
				byte[] data = readData(in, len);
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.HANJIN_FILTER ) {
				byte[] byteLength = readData(in, 1719);
				String strLength = new String(byteLength);
				ret.append(strLength);
			}else if( iWhoAmI == COMMBiz.ALIPAY_FILTER ) {
				byte[] data = readData(in, 345);
				ret.append(new String(data,"ISO-8859-1"));
			}else if(iWhoAmI == COMMBiz.SSGCON_FILTER) { //20171204 KSN SSGCON 결제수단추가
				//logger.info("SSGCON::iWhoAmI::["+iWhoAmI+"]");
				byte[] byteLength = readData(in, 5);
				String strLength = new String(byteLength);
				
				//logger.info("SSGCON::byteLength::["+byteLength+"]::strLength::["+strLength+"]");
				ret.append(strLength);
				
				int len = Integer.parseInt(strLength.substring(1, 5));
				byte[] data = readData(in, len - 5); 
				ret.append(new String(data));
				//logger.info("SSGCON::len::["+len+"]::ret::["+ret+"]"); 
				//logger.info("SSGCON::Data::["+ret.toString()+"]"); 
			}else if( iWhoAmI == COMMBiz.MCB_FILTER ) {	
				
				byte[] data = readData(in, 551); 
				ret.append(new String(data));
			}else if( iWhoAmI == COMMBiz.ONEBARCODE_FILTER ) {		// onebarcode
				byte[] byteLength = readData(in, 88);		
				String strLength = new String(byteLength);
				ret.append(strLength);
			}
			
			if (ret.length()>0){
				getData=(String)ret.toString();
			}
		}catch(Exception e) {
			throw e;
		}
		
		return getData;
	}
	
	public boolean send(OutputStream out, Object obj) throws Exception {
		PrintWriter pw = null;
		boolean ok = false;
		
		try {
			if( pw == null ) {
				pw = new PrintWriter(out);
			}
			pw.write((String)obj);
			pw.flush();
			if (!pw.checkError()) ok = true;
			else {
				throw new Exception("java.net.SocketException: " +
						"Connection reset by peer: socket write error");
			}
		}catch (Exception e) {
			throw e;
		}
		
		return ok;
	}
	
	public void close() {
		
	}
	
	public byte[] readData(InputStream in, int off, int len) throws Exception{
		int /*bcount = 0,*/ n = 0;
		byte buf[] = new byte[len];
		
		while (true) {
			n = in.read(buf, off, len - off);
			
			off += n;
			
			if( off == len ) {
				break;
			}
		}

		return buf;
		
	}
	public byte[] readData(InputStream in, int len) throws Exception {
		int bcount = 0, n = 0;
		byte buf[] = new byte[len];
		
		while (true) {
			n = in.read(buf, bcount, len - bcount);
			
			bcount += n;
			
			if( bcount == len ) {
				break;
			}
		}

		return buf;
	}

	public Object receive(InputStream arg0, int arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public Object receive(InputStream arg0, int arg1, int arg2)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean send(OutputStream out, int len, Object obj)
			throws Exception {
		// TODO Auto-generated method stub
		DataOutputStream dOut = null;
		boolean ok = false;
		
		try {
			if( dOut == null ) {
				dOut = new DataOutputStream(out);
				
				if( len > 0 ) {
					dOut.write((byte[])obj, 0, len);
					dOut.flush();
					ok = true;
				}
			}
		}catch(Exception e) {
			throw e;
		}
		
		return ok;
	}

	public boolean send(OutputStream arg0, int arg1, int arg2, Object arg3)
			throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
}