/*
 * COMMBiz_PDA.java	2014. 01. 21
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */

package biz.comm;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.daemon.core.config.repository.telegram.TelegramUtil;
import kr.fujitsu.com.ffw.util.StringUtil;


/** 
 * COMMBiz_PDA
 *  
 * @created  on 1.0,  14/01/21
 * @created  by jy.p(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */ 
public class COMMBiz_PDA {
	private static Logger logger = Logger.getLogger(COMMBiz_PDA.class);
 
	public static int TR_LENS = 185;
	// PDA HEADER
	public static int CM_LENS_PDA = 54; // HEADER SIZE
	public static int MSG_LEN_PDA = 8;
	public static String CM_HEADER_PDA    = "CM_HEADER_PDA";
	
	public static String CM_HEADER    = "CM_HEADER";
	public static String TR_HEADER    = "TR_HEADER";
	public static String SYSINQ_DATA  = "SYSINQ_DATA";
	public static String JOURNAL_DATA = "JOURNAL_DATA";
										 
	//MSG_TYPE	
	public static int TRAN    = 1;
	public static int JOURNAL = 2;
	public static int SYSINQ  = 6;
	public static int PDA	  = 7;
	public static int ERR     = 99;
	//TRAN
	public static String XML_TRAN_SQL         = "tran-sql";
	public static String TB_INS_STTRP010DT    = "INS_STTRP010DT";      
	public static String TB_INS_STTRP020DT    = "INS_STTRP020DT";
	public static String TB_INS_STTRP040DT    = "INS_STTRP040DT";
	public static String TB_INS_STTRP030DT    = "INS_STTRP030DT";
	public static String TB_INS_STTRP000ZT    = "INS_STTRP000ZT";
	public static String TB_MER_STBDA090AT    = "MER_STBDA090AT";
	//JOURNAL
	public static String XML_JOURNAL_SQL      = "journal-sql";
	public static String TB_INS_STTRP050DT    = "INS_STTRP050DT";
	                 
	//SYSINQ   
	public static String XML_SYSINQ_SQL       = "sysinq-sql";
	//STSYS   
	public static String XML_STSYS_SQL        = "stsys-sql";
	//SystemTime
	public static String TB_SEL_STTRP110DT    = "SEL_STTRP110DT";
	//DeployStatus
	public static String TB_UPD_STBDA100AT0   = "UPD_STBDA100AT0"; //마스터생성중 플래그세팅
	public static String TB_UPD_STBDA100AT1   = "UPD_STBDA100AT1"; //마스터생성완료 플래그세팅
	public static String TB_UPD_STBDA100AT2   = "UPD_STBDA100AT2"; //배신결과 플래그세팅(SC용)
	public static String TB_MER_STBDA101AT    = "MER_STBDA101AT";
	//OrderCheck
	public static String TB_SEL_STBDA100AT_1  = "SEL_STBDA100AT_1";
	public static String TB_SEL_STBDA100AT_2  = "SEL_STBDA100AT_2";
	public static String TB_SEL_STBDA100AT_3  = "SEL_STBDA100AT_3";
	public static String TB_SEL_STBDA100AT_01 = "SEL_STBDA100AT_01"; //외식 미사용
	public static String TB_SEL_STBDA100AT_02 = "SEL_STBDA100AT_02"; //외식 미사용
	public static String TB_SEL_STBDA100AT_03 = "SEL_STBDA100AT_03"; //외식 미사용
	public static String TB_UPD_STBDA100AT_0  = "UPD_STBDA100AT_0"; //배신결과POS전송 플래그세팅
	public static String TB_UPD_STBDA100AT_1  = "UPD_STBDA100AT_1"; //다운완료POS전송 플래그세팅
	public static String TB_UPD_STBDA100AT_2  = "UPD_STBDA100AT_2"; //적용완료POS전송 플래그세팅
	//Device
	public static String TB_DEL_STBDA111AT     = "DEL_STBDA111AT";
	public static String TB_DEL_STBDA110AT     = "DEL_STBDA110AT";
	public static String TB_INS_STBDA110AT     = "INS_STBDA110AT";
	public static String TB_INS_STBDA111AT     = "INS_STBDA111AT";
	//TranCall
	public static String TB_SEL_STTRP010DT     = "SEL_STTRP010DT";
	//PDAINQ
	public static String PDA_SQL   = "pda-sql";
	//신물류 PDA 로그인
	public static String SEL_WMS_USER_INFO = "SEL_WMS_USER_INFO";
	public static String SEL_WMS_USER_NM = "SEL_WMS_USER_NM";
	//신물류 입하등록
	public static String INSERT_INPUR_INFO = "INSERT_INPUR_INFO";
	// SEL_PDA_MESSAGE
	public static String GET_PDA_MESSAGE = "SEL_PDA_MESSAGE";
	// Version
	public static String GET_APP_VERSION = "GET_APP_VERSION";
	// PDA버전관리
	public static String INS_PDAVERSION_MGR = "INS_PDAVERSION_MGR";
	public static String SEL_PDAVERSION_MGR = "SEL_PDAVERSION_MGR";
	// 정전시PDA판매
	public static String INS_PDAEMERGTRN_HDR = "INS_PDAEMERGTRN_HDR";
	public static String INS_PDAEMERGTRN_DTL = "INS_PDAEMERGTRN_DTL";
	//상품 판매 가능여부 체크 
	public static String TB_SEL_ST_STRGDS_MST = "SEL_ST_STRGDS_MST";
	//점포 위해 상품 여부 조회
	public static String SEL_NOX_INFO = "SEL_NOX_INFO";
	// 사용자 확인
	public static String TB_USER_INFO = "SEL_USER_INFO";
	public static String TB_LOGISTIC_USER_INFO = "SEL_LOGISTIC_USER_INFO";
	//XCOSMOS ID 조회
	public static String TB_LOGISTIC_USER_INFO2 = "SEL_LOGISTIC_USER_INFO2";
	//XCOSMOS PW 조회
	public static String TB_LOGISTIC_USER_INFO3 = "SEL_LOGISTIC_USER_INFO3";
	//물류 ID 조회
	public static String TB_LOGISTIC_USER_INFO4 = "SEL_LOGISTIC_USER_INFO4";
	// 진열대 리스트
	public static String TB_MASTER_STAND_LIST = "SEL_MASTER_STAND_LIST";
	public static String TB_SCAN_PLUINFO = "SEL_SCANPLUINFO";
	public static String SEL_STAND_PLU_INFO_YS = "SEL_STAND_PLU_INFO_YS";
	// 점포발주
	public static String SEL_ITEM_SEARCH = "SEL_ITEM_SEARCH"; //점상품 조회
	public static String SEL_PLU_INFO_YS_AMT_DVY = "SEL_PLU_INFO_YS_AMT_DVY";//점상품조회 -발주가능금액, 상품대제외 배송처
	public static String SEL_STAND_PLU_INFO_YS2 = "SEL_STAND_PLU_INFO_YS2";//점상품조회 - 진열대 ,발주가능금액, 상품대제외 배송처

	public static String SEL_PLU_INFO_YS_AMT_DVY2 = "SEL_PLU_INFO_YS_AMT_DVY2"; //이익율,행사,반품구분 등 추가 I.G
	public static String SEL_PLU_INFO_YS_AMT_DVY3 = "SEL_PLU_INFO_YS_AMT_DVY3"; //두 줄 출력 제거(PLU,소박스,이너박스) I.G
	public static String SEL_PLU_INFO_YS_AMT_DVY4 = "SEL_PLU_INFO_YS_AMT_DVY4"; //5대행사 체크부분 추가 I.G
	public static String SEL_PLU_INFO_RECORD = "SEL_PLU_INFO_RECORD";           //매입,판매,폐기 실적 I.G
	//public static String SEL_STAND_PLU_INFO_YS3 = "SEL_STAND_PLU_INFO_YS3";     //점상품조회 - 이익율,행사,반품구분 등 추가 I.G
	//public static String SEL_STAND_PLU_INFO_YS4 = "SEL_STAND_PLU_INFO_YS4";     //신상품조회 I.G
	public static String SEL_ORDER_PLU_INFO = "SEL_ORDER_PLU_INFO";             //발주정보조회 I.G
	public static String SEL_EXCEPT_SEARCH = "SEL_EXCEPT_SEARCH";               //발주제외조회 I.G
	public static String SEL_STOCK_CHG_LIST = "SEL_STOCK_CHG_LIST";             //재고조정이력조회 I.G
	public static String TB_PRODUCT_UPDATE = "UPD_REQ_ORDER";
	
	public static String SEL_PLU_INFO_YS_MSTCHK4 = "SEL_PLU_INFO_YS_MSTCHK4";   //[점포발주] 스캔(조회) : FF발주 선마감 반영  I.G
	public static String SEL_PLU_INFO_YS_MSTCHK5 = "SEL_PLU_INFO_YS_MSTCHK5";   //[점포발주] 스캔(조회) : 발주불가 체크 추가  I.G
	public static String SEL_STAND_PLU_INFO_YS5 = "SEL_STAND_PLU_INFO_YS5";     //[점포발주] 진열대(조회) : FF발주 선마감 반영  I.G
	public static String SEL_STAND_PLU_INFO_YS6 = "SEL_STAND_PLU_INFO_YS6";     //[점포발주] 신상품(조회) : FF발주 선마감 반영  I.G
	public static String TB_PRODUCT_UPDATE2 = "UPD_REQ_ORDER2";                 //[점포발주] 발주(스캔/진열대/신상품/수정)(저장) : FF발주 선마감 반영  I.G
	public static String TB_NEW_ORDER_UPDATE = "UPD_REQ_NEW_OREDER";            //[점포발주] 신발주 저장 I.G
	
	public static String SEL_LIMIT_RTN_DATE = "SEL_LIMIT_RTN_DATE";             //[반품등록] 한도반품 일자/한도 조회
	public static String SEL_LIMIT_RTN_INFO = "SEL_LIMIT_RTN_INFO";             //[반품등록] 한도반품 조회
	public static String SEL_RTN_GDS_INFO = "SEL_RTN_GDS_INFO";                 //[반품등록] 한도반품 상품 조회
	public static String UPD_RTN_MGR = "UPD_RTN_MGR";                           //[반품등록] 반품등록 저장
	
	public static String SEL_FIRST_RTN_DATE = "SEL_FIRST_RTN_DATE";             //[반품등록] 초도반품 일자/한도 조회
	public static String SEL_FIRST_RTN_INFO = "SEL_FIRST_RTN_INFO";             //[반품등록] 초도반품 조회
		
	public static String SEL_RECALL_RTN_DATE = "SEL_RECALL_RTN_DATE";           //[반품등록] 리콜반품 일자/한도 조회
	public static String SEL_RECALL_RTN_INFO = "SEL_RECALL_RTN_INFO";           //[반품등록] 리콜반품 조회
	
	public static String GET_SYSTEM_DATE = "GET_SYSTEM_DATE";                   //시스템시간 동기화(DB시간)
		
	public static String SEL_PLU_INFO_YS = "SEL_PLU_INFO_YS";
	public static String SEL_PLU_INFO_YS_MSTCHK = "SEL_PLU_INFO_YS_MSTCHK";
	public static String SEL_PLU_INFO_YS_MSTCHK2 = "SEL_PLU_INFO_YS_MSTCHK2";
	public static String SEL_PLU_INFO_YS_MSTCHK3 = "SEL_PLU_INFO_YS_MSTCHK3";
	public static String SEL_PLU_INFO_CHK = "SEL_PLU_INFO_CHK";                 //PLU번호 13자리 체크로직 추가 I.G 
	public static String CALL_PR_HQ_STRLOAN_INFO = "CALL_PR_HQ_STRLOAN_INFO";
	public static String CALL_PR_ST_STRINVTRYBAL_HIS = "CALL_PR_ST_STRINVTRYBAL_HIS";  //재고조정 프로시저 호출I.G
	public static String UPD_ST_STRCALENDAR_MGR = "UPD_ST_STRCALENDAR_MGR";
	public static String GET_STORELOAN = "GET_STORELOAN";
	public static String INS_PRINT_MST = "INS_PRINT_MST";
	public static String DEL_IQ_PRINT_MST = "DEL_IQ_PRINT_MST";
	public static String INS_EXCEPT_ORD = "INS_EXCEPT_ORD";
	// 물류 센터코드 조회
	public static String TB_SEL_CENTER_INFO = "SEL_CENTER_INFO";
	// 신물류 입고상품 조회
	public static String SEL_IN_ORD_ITEM = "SEL_IN_ORD_ITEM";
	// 진열대 리스트
	public static String TB_STAND_LIST = "SEL_STAND_LIST";
	// 분류별 리스트 I.G
	public static String TB_STAND_LIST2 = "SEL_STAND_LIST2";
	// 진열대 별 상품 리스트
	public static String TB_STAND_PRODUCT = "SEL_STAND_PRODUCT";
	// 입고상품 정보 
	public static String TB_INCOM_PRODUCT = "SEL_INCOM_INFO";
	public static String SEL_INCOM_CHK = "SEL_INCOM_CHK";
	// 입고상품 정보 수정
	public static String TB_INCOM_DETAIL_UPDATE = "UPD_INCOM_DETAIL";
	public static String TB_INCOM_MASTER_UPDATE = "UPD_INCOM_MASTER";
	public static String CALL_PR_ST_SLIP_CONF = "UPD_INCOM_INV";
	// 발주 시간 및 금액 확인
	public static String CALL_CLOSE_TM = "SEL_CLOSE_TM";
	public static String CALL_CLOSE_TM_OLD = "SEL_CLOSE_TM_OLD";  // FF발주 선마감(기존)
	public static String CALL_CLOSE_TM2 = "SEL_CLOSE_TM2";  // FF발주 선마감 포함
	public static String CALL_CLOSE_TM3 = "SEL_CLOSE_TM3";  // 이중발주 방지 포함
	public static String CALL_FF_CLOSE_TM = "SEL_FF_CLOSE_TM"; // FF발주 선마감 체크
	//신발주 점포 체크 I.G 180309
	public static String CALL_NEW_ORDER_STORE = "SEL_NEW_ORDER_STORE";  // 신발주 대상점포 조회
	//재고조정 정보
	public static String TB_INVENTORY_PLUINFO = "SEL_INVENTORY_INFO";
	public static String SEL_IQ_INV_NSTCK_QTY = "SEL_IQ_INV_NSTCK_QTY";
	// 재고조정 수량 수정
	public static String UPD_INVENTORY_QTY_LOG = "UPD_INVENTORY_QTY_LOG";
	public static String UPD_INVENTORY_QTY_LOG2 = "UPD_INVENTORY_QTY_LOG2";
	public static String UPD_INVENTORY_QTY_MGR = "UPD_INVENTORY_QTY_MGR";
	// 재고조정 수정<헤더>
	public static String UPD_INVENTORY_MST = "UPD_INVENTORY_MST";
	// 재고조정  수정<상세>
	public static String UPD_INVENTORY_DTL = "UPD_INVENTORY_DTL";
	// 매입 입고 등록 ( NEW )
	public static String TB_LOGISTICS_PURCHASE_NEW_REQ = "SEL_LOGISTICS_PURCHASE_NEW";
	
	public static String TB_LOGISTICS_PURCHASE_NEW_REQ3 = "SEL_LOGISTICS_PURCHASE_NEW3";
	// 물류 매입 등록 ( 상품정보 요청 )
	public static String TB_LOGISTICS_PURCHASE_REQ = "SEL_LOGISTICS_PURCHASE";
	// 물류 매입 등록 ( 이력조회 )
	public static String TB_LOGISTICS_PURCHASE_HIST_REQ = "SEL_LOGISTICS_PURCHASE_HIST";
	// 물류 매입 등록 ( 상품정보 수정 요청 )
	public static String TB_LOGISTICS_PURCHASE_UPDATE = "UPD_LOGISTICS_PURCHASE";
	// 물류매출조회
	public static String TB_LOGISTICS_SALSE_REQ = "SEL_LOGISTICS_SALSE_REQ";
	// 물류 출고조회2
	public static String TB_LOGISTICS_SALSE_REQ2 = "SEL_LOGISTICS_SALSE_REQ2";
	// 물류 상품조회
	public static String TB_PLU_INFO = "SEL_PLU_INFO";
	
	public static String TB_PLU_INFO2 = "SEL_PLU_INFO2";
	// 물류(매입 ) 마감 시간 확인
	public static String PR_ORDERTIME_CHECK = "WM_ORDERTIME_CHECK";
	// 물류 재고조정 정보
	public static String TB_LOGISTICS_INVENTORY = "SEL_LOGISTICS_INVENTORY";
	// 물류 상품 가용재고 조회
	public static String TB_LOGISTICS_INVENTORY_NOW = "SEL_LOGISTICS_INVENTORY_NOW";
	// 물류 재고조정 정보 상세 수정
	public static String PR_LOGISTICS_INVENTORY_DTL = "UPDATE_LOGISTICS_INVENTORY_DTL";
	// 물류 재고조정 정보 헤더 수정
	public static String PR_LOGISTICS_INVENTORY_HD = "UPDATE_LOGISTICS_INVENTORY_HD";
	// 물류 재고조정 전표번호
	public static String GET_LOGISTICS_INVENTORY_SEQ = "SEL_LOGISTICS_INVENTORY_SEQ";
	// 물류 재고조정 전펴번호2
	public static String GET_LOGISTICS_INVENTORY_SEQ2 = "SEL_LOGISTICS_INVENTORY_SEQ2";
	// 물류 점포리스트
	public static String GET_LOGISTICS_STORE_LIST = "SEL_LOGISTICS_STORE_LIST";
	// 물류 점포 반품
	public static String GET_LOGISTICS_IN_RETURN = "SEL_LOGISTICS_IN_RETURN";
	// 물류 점포 반품 헤더 
	public static String GET_LOGISTICS_IN_RETURN_HD = "SEL_LOGISTICS_IN_RETURN_HD";
	// 물류 점포 반품 상세
	public static String GET_LOGISTICS_IN_RETURN_DTL = "SEL_LOGISTICS_IN_RETURN_TDL";
	// 물류 점포 반품 수정
	public static String PR_LOGISTICS_IN_RETURN = "UPDATE_LOGISTICS_IN_RETURN";
	// 물류반품 [점포]  수정
	public static String UPDATE_LOGISTICS_IN_RETURN_DTL = "UPDATE_LOGISTICS_IN_RETURN_DTL";
	// 물류 반품[점포]  확정
	public static String UPDATE_LOGISTICS_IN_RETURN_HD = "UPDATE_LOGISTICS_IN_RETURN_HD";
	// 물류반품-출고==>거래처반품
	public static String SEL_LOGISTICS_OUT_RETURN = "SEL_LOGISTICS_OUT_RETURN";
	// 물류반품-출고==>거래처반품 수정
	public static String PR_LOGISTICS_OUT_RETURN = "UPDATE_LOGISTICS_OUT_RETURN";
	// 물류  거래처 반품  가능시간 : 따로 사용하지 않는단다.
	public static String SEL_LOGISTICS_OUT_RETURN_TIME = "SEL_LOGISTICS_OUT_RETURN_TIME";
	// 물류폐기  입고==>점포폐기 [센터파손폐기] : IQ_LOGISTICS_DROP_IN_REQ
	public static String GET_LOGISTICS_IN_DROP = "SEL_LOGISTICS_IN_DROP";
	// 물류폐기  입고==>점포폐기 [센터파손폐기] 수정 : IQ_LOGISTICS_DROP_IN_UPDATE_REQ
	public static String PR_LOGISTICS_IN_DROP = "UPDATE_LOGISTICS_IN_DROP";
	// 물류폐기  입고==>점포폐기 [센터파손폐기] 확정 : IQ_LOGISTICS_DROP_IN_UPDATE_REQ
	public static String PR_LOGISTICS_IN_DROP_PASS = "UPDATE_LOGISTICS_IN_DROP_PASS";
	// 물류 재고조사 정보 수정
	public static String PR_LOGISTICS_INVENTORY2_ITEM = "UPDATE_LOGISTICS_INVENTORY2_ITEM";
	// 물류 재고조사 전표 생성
	public static String PR_LOGISTICS_INVENTORY2_STATEMENT = "UPDATE_LOGISTICS_INVENTORY2_STATEMENT";
	// PLU_TEMP
	public static String TB_PLU_TEMP = "TB_PLU_TEMP";
	/***
	 * getDatas
	 * Parse rcvData as msgFormName type and return(rcvData를 msgFormName의 타입으로 파싱한뒤 리턴한다).
	 * @param rcvData
	 * @param msgFormName In case of CM_HEADER, return 42Byte(CM_HEADER인경우 42Byte 리턴) 
	 * @return Receive Message(Receive 메세지) 
	 * @throws Exception
	 */
	public static  HashMap getData(String rcvData, String msgFormName) throws Exception{
		
		String telegram=rcvData;
		
		// If msgFormName is a header, take the designated header length 42Byte only(msgFormName이 헤더 인경우에는 지정헤더길이 42byte값만 취한다). 
		if (msgFormName.equals(CM_HEADER_PDA)){
			telegram = rcvData.substring(0,CM_LENS_PDA);
		} else if (msgFormName.equals(TR_HEADER)){
			telegram = rcvData.substring(CM_LENS_PDA,CM_LENS_PDA+TR_LENS);
		} else {
			telegram = toData(rcvData);
		}

		//HashMap hm = (HashMap)TelegramUtil.bind(telegram, msgFormName);
		//String comCd = (String)hm.get("COM_CD");
		//hm.put("COM_CD", comCd.trim());
		return (HashMap)TelegramUtil.bind(telegram, msgFormName);		
	}
	
	/***
	 * toData : Data part message(데이타부 메세지)
	 * @param msg
	 * @return : Data Part (Message value excluding front header 42 bytes out of received data)(데이타부(수신받은 데이타중 앞부분헤더 42바이트를 제외한 메세지값))
	 */
	private static String toData(String msg){
		return msg.substring(COMMBiz_PDA.CM_LENS_PDA, msg.length());
	}
	
	/***
	 * getCommMsgType 
	 * If MSG_TYPE is not matched with the parameter type, return FALSE(이 파라미터 type과 일지하는 지 확인하여 일치하지 않으면 FALSE리턴)  
	 * @param hm : MSG_TYPE Data(MSG_TYPE데이타) 
	 * @param type
	 * @return TRUE:Matched(일치), False:Not Matched(불일치) 
	 */
	public static boolean getCommMsgType(HashMap hm, int type) {	
		int ret = toInteger((String)hm.get("MSG_TYPE"), 99);	
		
		if (ret != 99) {
			if (type == ret) return true;			
		}
				
		return false;
	}
	
	/***
	 * getCommTranYMD
	 * Return TRAN_YMD value(TRAN_YMD값을 리턴) 
	 * @param hm
	 * @return TRANYMD
	 */
	public static String getCommTranYMD(HashMap hm) {		
		return (String)hm.get("TRAN_YMD");	
	}
	
	/***
	 * getCommStoreCode
	 * Return STORE_CD value(점포코드) 
	 * @param hm
	 * @return TRANYMD
	 */
	public static String getCommStoreCode(HashMap hmCommon) {
		return (String)hmCommon.get("STORE_CD");
	}
	
	/***
	 * getTranType
	 * @param hm
	 * @return TRAN_TYPE
	 */
	public static int getTranType(HashMap hm) {
		return toInteger((String)hm.get("TRAN_TYPE"), ERR);
	}

	/***
	 * toInteger
	 * @param value
	 * @param errRet If not number, return value(숫자가 아닐경우 return value)
	 * @return
	 */
	public static int toInteger(String value, int errRet){
		int ret=0;
		
		try {			
			ret = Integer.parseInt(value);
		} catch (NumberFormatException e ){
			ret = errRet;
		}
		
		return ret;		
	}

	/***
	 * isNumber
	 * @param data
	 * @return
	 */
	public static boolean isNumber(String data){
		Pattern p = Pattern.compile("[0-9.-+]"); 
		Matcher m = p.matcher(data); 
		boolean b = m.matches();
		
		return b;
	}
	
	/***
	 * Parse getParseData rcvBuf as long as nMens length(getParseData rcvBuf를 nLens길이만큼 Parse)
	 * @param nlens
	 * @param strHeaders
	 * @param rcvBuf
	 * @return
	 */
	public static HashMap getParseData(int nlens[], String strHeaders[], String rcvBuf) {		
		int bInx=0;
		int eInx=0;	
		HashMap hm = new HashMap();
		
		eInx = nlens[0];
		for(int i=0; i<nlens.length; i++ ){
			
			hm.put(strHeaders[i].toString(), rcvBuf.substring(bInx, eInx));	
		logger.info( strHeaders[i].toString() + "==>(" + bInx +","+ eInx + ")" + rcvBuf.substring(bInx, eInx));	
			if (i<nlens.length-1){
				bInx = eInx;
				eInx = eInx+nlens[i+1];
			}
		}
		return hm;
	}	
	
	
	/***
	 * Parse getParseDataMultibyte rcvBuf as long as nMens length(getParseDataMultibyte rcvBuf를 멀티바이트 감안해 nLens길이만큼 Parse)
	 * @param nlens
	 * @param strHeaders
	 * @param rcvBuf
	 * @return
	 */
	public static HashMap getParseDataMultibyte(int nlens[], String strHeaders[], String rcvBuf) {		
		int bInx=0;
		int eInx=0;	
		HashMap hm = new HashMap();
		
		eInx = nlens[0];
		for(int i=0; i<nlens.length; i++ ){
			
			hm.put(strHeaders[i].toString(), new String(rcvBuf.getBytes(), bInx, eInx - bInx));	
			logger.info( strHeaders[i].toString() + "==>(" + bInx +","+ eInx + ")" + new String(rcvBuf.getBytes(), bInx, eInx - bInx));	
			if (i<nlens.length-1){
				bInx = eInx;
				eInx = eInx+nlens[i+1];
			}
		}
		return hm;
	}
	
	/***
	 * Parse getParseDataMultibyte rcvBuf as long as nMens length(getParseDataMultibyte rcvBuf를 멀티바이트 감안해 nLens길이만큼 Parse)
	 * @param nlens
	 * @param strHeaders
	 * @param rcvBuf
	 * @return
	 * @throws Exception
	 */
	public static String getConvertUTF16LE2UTF8(String strOrg) throws Exception {		
		byte[] byteOrg = strOrg.getBytes();
		InputStream is = new ByteArrayInputStream( byteOrg );
	    InputStreamReader isr = new InputStreamReader( is, Charset.forName("UTF-16LE") );
	    BufferedReader br = new BufferedReader( isr );
	    String strConv = br.readLine();

	    return strConv;
	}
	
	/***
	 * Parse getParseDataMultibyte rcvBuf as long as nMens length(getParseDataMultibyte rcvBuf를 멀티바이트 감안해 nLens길이만큼 Parse)
	 * @param nlens
	 * @param strHeaders
	 * @param rcvBuf
	 * @return
	 */
	public static HashMap getParseDataMultibyte2(int nlens[], String strHeaders[], String rcvBuf) {		
		int bInx=0;
		int eInx=0;	
		HashMap hm = new HashMap();
		
		eInx = nlens[0];
		for(int i=0; i<nlens.length; i++ ){
			
			hm.put(strHeaders[i].toString(), subStringMultibyte(rcvBuf, bInx, eInx, '+'));	
			//hm.put(strHeaders[i].toString(), rcvBuf.substring(bInx, eInx));	
		logger.info( strHeaders[i].toString() + "==>" + subStringMultibyte(rcvBuf, bInx, eInx, '+'));	
			if (i<nlens.length-1){
				bInx = eInx;
				eInx = eInx+nlens[i+1];
			}
		}
		return hm;
	}	
	
	
	/***
	 * Parse subStringMultibyte rcvBuf as long as nMens length(subStringMultibyte 멀티바이트를 감안해 시작위치, 끝위치 길이만큼 Parse)
	 * @param str
	 * @param bInx
	 * @param eInx
	 * @param type ('+' or '-')
	 * @return
	 */
	public static String subStringMultibyte(String str, int bInx, int eInx ,char type) {
		byte[] bytes = str.getBytes();
		int len = bytes.length;
		int length = eInx - bInx;
		int counter = 0;
		// 자를 길이가 시작위치보다 작으면 뒤에 스페이스를 붙여서 리턴
//		if (length >= len) {
//			StringBuffer sb = new StringBuffer();
//			sb.append(str);
//		
//			for(int i=0;i<length-len;i++){
//				sb.append(' ');
//			}
//			return sb.toString();
//		}

		for (int i = length - 1; i >= bInx; i--) {
			if (((int)bytes[i] & 0x80) != 0)
				counter++;
		}
		String f_str = null;
		if(type == '+'){
			f_str = new String(bytes, bInx, length + (counter % 2));
		}else if(type == '-'){
			f_str = new String(bytes, bInx, length - (counter % 2));
		}else{
			f_str = new String(bytes, bInx, length - (counter % 2));
		}
	
		return f_str;
	}
	
	/***
	 * Making makeSendData Response Message Header Data (makeSendData 응답 전문헤더데이타 작성하기) 
	 * @param hm Message Data(전문 데이타) 
	 * @param cmLens Message Length(전문길이) 
	 * @param ret Response Value(응답값) 
	 * @return String Message Data(전문데이타)
	 */
	public static String makeSendData_PDA(HashMap hmCommon, int cmLens, int ret){
		StringBuffer sb = new StringBuffer();
		int nlens[]= {8,2,7,4,4,8,8,6,3,4};  
		
		String strHeaders[] = {
				"MSG_LEN",  	
				"MSG_TYPE", 	
				"STORE_CD",
				"POS_NO",  
				"TRAN_NO", 
				"TRAN_YMD",
				"SYS_YMD",
				"SYS_HMS", 
				"ERR_CD",   
				"COM_CD"   
			};	 
		
		hmCommon.put("MSG_LEN", StringUtil.lPad(String.valueOf(cmLens),8,"0")) ;
		hmCommon.put("SYS_YMD", (new SimpleDateFormat("yyyyMMdd")).format( new Date() )) ;
		hmCommon.put("SYS_HMS", (new SimpleDateFormat("HHmmss")).format( new Date() )) ;
		hmCommon.put("ERR_CD",   StringUtil.lPad(String.valueOf(ret),3,"0")) ;	
		
		for (int i=0; i < nlens.length ; i++) {
			StringUtil.appendSpace(sb, (String)hmCommon.get(strHeaders[i].toString()), nlens[i]);   
		}

	    //sb.append("\n");
		//sb.append("\r\n");
		return sb.toString();
	}


}

