/*
 * COMMDefine.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.comm;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

/** 
 * COMMLog
 *  
 * @created  on 1.0,  11/03/17
 * @created  by oki(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */  
public class COMMLog {
	
	//private static Logger logger = Logger.getLogger(COMMLog.class);
	private Logger logger = null;
	private String ConnectionInfo = "";
	private long startTime=0;
	private long endTime=0;

	/**
	 * Leave Log(로그 남기기) 
	 * @param log
	 */
	public void CommLogger(String log){
		logger.info("["+logger.getName()+"]" + "[* "+ConnectionInfo+"]"+log);
	}
	
	/**
	 * Leave start of the work on Log(해당업무의 시작을 로그에 남긴다).
	 * @param job Work(업)
	 */
	public void execute(String job) {
		CommLogger( "--------< "+job+" EXECUTE >--------\n");	
	}	
	/**
	 * Leave end of the work on Log(해당업무의 종료를 로그에 남긴다).
	 * @param job Work(업무)
	 * @param ret Result Value(결과값) 
	 */
	public void close(String job, String ret) {
		CommLogger( "--------< "+job+" CLOSE >--------\n");	

		setEndTime();
		CalcTime();
	}
	/**
	 * Leave connection information and start of the work on Log(커넥션 정보와 해당 업무의 시작을 로그에 남긴다).
	 * @param ip Connection IP(접속 IP)
	 * @param port Connection PORT(접속 PORT)
	 * @param logger1 Work Log(업무로그)
	 * @param job Work(업무) 
	 */
	public void setConnectionInfo(String ip, String port, Logger logger1, String job){
		//ConnectionInfo = info;
		//xxx.xxx.xxx.xxx(xxxx)   21
		setbizLogger(logger1);
		
		//Align 15 digits(15자리수를 맞춰준다).
		if (ip.length() < 15) {
	    	for (int i=0; i < 15-ip.length() ; i++){    
	    		ip += " ";   
	    	}			
		}
		ConnectionInfo = ip+"("+port+")";
		execute(job);
	}
	public void setConnectionInfo(String ip, String port, String job){
		if(this.logger == null) return;

		//Align 15 digits(15자리수를 맞춰준다).
		if (ip.length() < 15) {
	    	for (int i=0; i < 15-ip.length() ; i++){    
	    		ip += " ";   
	    	}			
		}
		ConnectionInfo = ip+"("+port+")";
		execute(job);
	}
	
	/**
	 * Set start time of work in startTime(업무의 시작시간을 startTime에 설정한다).
	 *
	 */
	public void setStartTime(){
		startTime = System.currentTimeMillis();
	}
	/**
	 * Set end time of work in endTime(업무의 종료시간을 endTime 설정한다).
	 *
	 */
	private void setEndTime(){
		endTime = System.currentTimeMillis();
	}
	
	/**
	 * Calculate time taken for work and leave it on Log(업무의 소요시간을 계산하여 로그에 남긴다).
	 * @param ret : Result value of work(업무의 결과값). Success/Fail
	 */
	private void CalcTime(){
		CommLogger(
				   "-Client:" + ConnectionInfo +
				   "-Start:"  + formatTime(startTime)  +
		           "-End:"    + formatTime(endTime)    +	
		           "==>"      + ((endTime-startTime)/1000.0f));	
	}
	/**
	 * Return the current time to be fit in the format(현재시간을 포맷에 맞춰 반환한다).
	 * @param lTime : On Setup(설정시)
	 * @return
	 */
	private String formatTime(long lTime){
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS"); 		
		return sdf.format(new Date(lTime));
	}	
	/**
	 * Set logger of each work on Comm(각업무의 logger를 Comm에 설정한다).
	 * @param log
	 */
	public void setbizLogger(Logger log){
		logger = log;
	}
	
}
