package biz.cms_KISDTLDownloader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;
import biz.comm.SFTPManager;


/** 
 * CGDTLDownloaderPollingAction
 * KISDTLDownloaderPollingAction
 * KIS 일별거래내역, 입반송내역 수신
 * @created  on 1.0,  17/02/06
 * @created  by 이승호
 *  
 * @modified on 
 * @modified by ok
 * @caused   by 
 */ 
public class KISDTLDownloaderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(KISDTLDownloaderPollingAction.class);
	
	private String kis_ftp_ip = "";
	private int kis_ftp_port = 0;
	private String kis_ftp_id = "";
	private String kis_ftp_pwd = "";
	private String kis_ftp_root = "";
	String curActionMode = "T";
	static String curActionDate = "-1";
	
	public static void main(String args[]) throws Exception {
		KISDTLDownloaderPollingAction action = new KISDTLDownloaderPollingAction();
		if (args == null || args.length < 1) {
			logger.info("------ master main args null");
		}
		System.out.println("[DEBUG] [args[0]]=" + args[0] );
		System.out.println("[DEBUG] [args[1]]=" + args[1] );
		
		String path          = nvl(args[0].replaceFirst("-path:",""));
		String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));		
		String date = ""; 
		if(args.length ==3 ){
			date = nvl(args[2].replaceFirst("-date:" , ""));
			curActionDate = date;
			System.out.println("args.length ==3  and  date::" + date);
		}
		

		System.out.println("[DEBUG] [cmd.charAt(0)]=" + cmd.charAt(0) );
		System.out.println("[DEBUG] [cmd.charAt(1)]=" + cmd.charAt(1) );			
		System.out.println("[DEBUG] [args.length]=" + args.length);		
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		
		System.out.println("locator=true"  );
		
		if( cmd.length() != 2 ) return;
		
		System.out.println("cmd.length() is 2"  );
		
		if( cmd.charAt(0) == '1' ) {
			System.out.println("downloading file + inserting DB" );
			action.execute("1");
		}
		if( cmd.charAt(1) == '1' ) {
			System.out.println("inserting DB" );
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "CREDITCARD";//"";
			KISDTLDownloaderInst dailyInsert = new KISDTLDownloaderInst(destPath);
			dailyInsert.start();
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(String actionMode) {
		SFTPManager sFtpMgr = null;
		
		KISDTLDownloaderDAO dao = new KISDTLDownloaderDAO();
	    Map<String, String> map = new HashMap<String, String>();
		
		BufferedOutputStream bos_KIS_TLF = null;
		BufferedOutputStream bos_KICC_TLF = null;
		BufferedOutputStream bos_NICE_TLF = null;
		
		BufferedOutputStream bos_KIS_REP = null;
		BufferedOutputStream bos_KICC_REP = null;
		BufferedOutputStream bos_NICE_REP = null;
		
		BufferedOutputStream bos_KIS_TLF_INF = null;
		BufferedOutputStream bos_KICC_TLF_INF = null;
		BufferedOutputStream bos_NICE_TLF_INF = null;
		
		BufferedOutputStream bos_KIS_REP_INF = null;
		BufferedOutputStream bos_KICC_REP_INF = null;
		BufferedOutputStream bos_NICE_REP_INF = null;
		
		
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK_KIS_TLF   = false;
		boolean isDownOK_KICC_TLF  = false;
		boolean isDownOK_NICE_TLF  = false;
		boolean isDownOK_KIS_REP   = false;
		boolean isDownOK_KICC_REP  = false;
		boolean isDownOK_NICE_REP  = false;
		boolean isDownOK_KIS_TLF_INF   = false;
		boolean isDownOK_KICC_TLF_INF  = false;
		boolean isDownOK_NICE_TLF_INF  = false;
		boolean isDownOK_KIS_REP_INF   = false;
		boolean isDownOK_KICC_REP_INF  = false;
		boolean isDownOK_NICE_REP_INF  = false;
		
		String FileNm_KIS_TLF  = ""; //FileNm = targetFileNm;
		String FileNm_KICC_TLF = "";
		String FileNm_NICE_TLF = "";		
		String FileNm_KIS_REP  = "";
		String FileNm_KICC_REP = "";
		String FileNm_NICE_REP = "";
		       
		String FileNm_KIS_TLF_inf  = ""; //FileNm = targetFileNm;
		String FileNm_KICC_TLF_inf = "";
		String FileNm_NICE_TLF_inf = "";		
		String FileNm_KIS_REP_inf  = "";
		String FileNm_KICC_REP_inf = "";
		String FileNm_NICE_REP_inf = "";		
		
		//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
		if( actionMode != "1" ) {
			System.out.println("actionmode !=1"  );
			return;
			}
		System.out.println("actionmode==1"  );

		try{			
			
			this.kis_ftp_ip = PropertyUtil.findProperty("communication-property", "KIS_FTP_SERVER_IP");
			this.kis_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "KIS_FTP_SERVER_PORT"));
			this.kis_ftp_id = PropertyUtil.findProperty("communication-property", "KIS_FTP_SERVER_ID");
			this.kis_ftp_pwd = PropertyUtil.findProperty("communication-property", "KIS_FTP_SERVER_PWD");	
			this.kis_ftp_root = PropertyUtil.findProperty("communication-property", "KIS_FTP_ROOT1");
			
			sFtpMgr = new SFTPManager(kis_ftp_ip, kis_ftp_port, kis_ftp_id, kis_ftp_pwd);
			System.out.println("TRY Connected to " + kis_ftp_ip + ":" + kis_ftp_port);
			logger.info("TRY Connected to " + kis_ftp_ip + ":" + kis_ftp_port);
		}catch(Exception e){
			System.out.println("exception occur "+e.getMessage());
			System.out.println("SFTP Connect "+ kis_ftp_ip + "/"+kis_ftp_port+" ...");
			logger.info("exception occur "+e.getMessage());
			logger.info("SFTP Connect "+kis_ftp_ip+"/"+kis_ftp_port+" ..."); 
			logger.info(" SFTP Connect fail exception occur ");
			//return;
		}					
		logger.info(" SFTP Connection is Success ");						
		System.out.println(" SFTP Connection is Success ");
		try {
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");
		} catch (Exception e) {
			logger.info(" SFTP Connect fail exception occur ");			
		}	// 파일 생성 루트
		destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "CREDITCARD";//"";
		System.out.println("destPath=>"+destPath);
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdir();
			logger.info("[DEBUG] Try to make dir" );
		}
		//isDownOK = false;

		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		calendar.setTime(new Date());
		calendar.add(Calendar.DATE, -1); 
		String stdDate = sdf.format(calendar.getTime());
		
		String targetFileNm_KIS_TLF  ="";
		String targetFileNm_KICC_TLF ="";
		String targetFileNm_NICE_TLF ="";		
		String targetFileNm_KIS_REP  ="";
		String targetFileNm_KICC_REP ="";
		String targetFileNm_NICE_REP ="";

		String infFileNm_KIS_TLF  ="";
		String infFileNm_KICC_TLF ="";
		String infFileNm_NICE_TLF ="";		
		String infFileNm_KIS_REP  ="";
		String infFileNm_KICC_REP ="";
		String infFileNm_NICE_REP ="";
					
		String fNm_KIS_TLF  ="";
		String fNm_KICC_TLF ="";
		String fNm_NICE_TLF ="";		
		String fNm_KIS_REP  ="";
		String fNm_KICC_REP ="";
		String fNm_NICE_REP ="";				
		
		if(curActionDate != "-1") {
			targetFileNm_KIS_TLF  = "KIS_TLF."  + curActionDate + ".gz";
			targetFileNm_KICC_TLF = "KICC_TLF." + curActionDate + ".gz";	
			targetFileNm_NICE_TLF = "NICE_TLF." + curActionDate + ".gz";			
			targetFileNm_KIS_REP  = "KIS_REP."  + curActionDate + ".gz";
			targetFileNm_KICC_REP = "KICC_REP." + curActionDate + ".gz";	
			targetFileNm_NICE_REP = "NICE_REP." + curActionDate + ".gz";

			infFileNm_KIS_TLF  =    "KIS_TLF."  + curActionDate + ".INF";
			infFileNm_KICC_TLF =    "KICC_TLF." + curActionDate + ".INF";	
			infFileNm_NICE_TLF =    "NICE_TLF." + curActionDate + ".INF";			
			infFileNm_KIS_REP  =    "KIS_REP."  + curActionDate + ".INF";
			infFileNm_KICC_REP =    "KICC_REP." + curActionDate + ".INF";	
			infFileNm_NICE_REP =    "NICE_REP." + curActionDate + ".INF";
			
			fNm_KIS_TLF  = "KIS_TLF."  + curActionDate ;
			fNm_KICC_TLF = "KICC_TLF." + curActionDate ;
			fNm_NICE_TLF = "NICE_TLF." + curActionDate ;	
			fNm_KIS_REP  = "KIS_REP."  + curActionDate ;
			fNm_KICC_REP = "KICC_REP." + curActionDate ;
			fNm_NICE_REP = "NICE_REP." + curActionDate ;
			
		}
		else{	//stdDate
			targetFileNm_KIS_TLF  = "KIS_TLF."  + stdDate + ".gz";  
			targetFileNm_KICC_TLF = "KICC_TLF." + stdDate + ".gz";				
			targetFileNm_NICE_TLF = "NICE_TLF." + stdDate + ".gz"; 						                                                              
			targetFileNm_KIS_REP  = "KIS_REP."  + stdDate + ".gz";  
			targetFileNm_KICC_REP = "KICC_REP." + stdDate + ".gz";				
			targetFileNm_NICE_REP = "NICE_REP." + stdDate + ".gz";
			
			infFileNm_KIS_TLF  =    "KIS_TLF."  + stdDate + ".INF";  
			infFileNm_KICC_TLF =    "KICC_TLF." + stdDate + ".INF";				
			infFileNm_NICE_TLF =    "NICE_TLF." + stdDate + ".INF"; 						                                                              
			infFileNm_KIS_REP  =    "KIS_REP."  + stdDate + ".INF";  
			infFileNm_KICC_REP =    "KICC_REP." + stdDate + ".INF";				
			infFileNm_NICE_REP =    "NICE_REP." + stdDate + ".INF"; 
			
			fNm_KIS_TLF  = "KIS_TLF."  + stdDate ;
			fNm_KICC_TLF = "KICC_TLF." + stdDate ;
			fNm_NICE_TLF = "NICE_TLF." + stdDate ;		
			fNm_KIS_REP  = "KIS_REP."  + stdDate ;
			fNm_KICC_REP = "KICC_REP." + stdDate ;
			fNm_NICE_REP = "NICE_REP." + stdDate ;
			
		}

		
		//FileNm = targetFileNm; //exception 발생시 FileNm변수 활용
		FileNm_KIS_TLF  = targetFileNm_KIS_TLF  ; 					
		FileNm_KICC_TLF = targetFileNm_KICC_TLF ;
		FileNm_NICE_TLF = targetFileNm_NICE_TLF ;
               
		FileNm_KIS_REP   = targetFileNm_KIS_REP ;
		FileNm_KICC_REP = targetFileNm_KICC_REP ;
		FileNm_NICE_REP = targetFileNm_NICE_REP ;
		
		System.out.println("initialize end");

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//KIS_TLF , KIS_INF 		
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
		try {		
			bos_KIS_TLF  = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + targetFileNm_KIS_TLF ));
			iRetry = 0;			
			System.out.println("bos_KIS_TLF for::" + targetFileNm_KIS_TLF);
			System.out.println("sFtpMgr.pwd() =>" + sFtpMgr.pwd());
			System.out.println("kis_ftp_root =>" + kis_ftp_root);

			sFtpMgr.cd(sFtpMgr.pwd() + File.separator + kis_ftp_root); // 경로변경(현재경로+kis_ftp_root)

			while( iRetry < 2 ) {
				System.out.println("Try to sFtpMgr.get =>targetFileNm_KIS_TLF");
				if( isDownOK_KIS_TLF = sFtpMgr.get(targetFileNm_KIS_TLF, bos_KIS_TLF)) {
					
					break;
				}
				iRetry++;
			}
			System.out.println("isDownOK_KIS_TLF =>" + isDownOK_KIS_TLF);
			bos_KIS_TLF.flush();
			bos_KIS_TLF.close();
			bos_KIS_TLF = null;
			System.gc();
			
			bos_KIS_TLF_INF  = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + infFileNm_KIS_TLF ));
			iRetry = 0;			
			System.out.println("bos_KIS_TLF for::" + infFileNm_KIS_TLF);
			
			//sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "datashare"); // 경로변경(현재경로+datashare폴더)
			while( iRetry < 2 ) {	
				System.out.println("Try to sFtpMgr.get =>infFileNm_KIS_TLF");				
				if( isDownOK_KIS_TLF_INF = sFtpMgr.get(infFileNm_KIS_TLF, bos_KIS_TLF_INF)) {		
					break;
				}
				iRetry++;
			}
			System.out.println("isDownOK_KIS_TLF_INF =>" + isDownOK_KIS_TLF_INF);
			bos_KIS_TLF_INF.flush();
			bos_KIS_TLF_INF.close();
			bos_KIS_TLF_INF = null;
			System.gc();
			
			
			if( (isDownOK_KIS_TLF )&&(isDownOK_KIS_TLF_INF)) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm_KIS_TLF + "] and ["+infFileNm_KIS_TLF+"]");			
				System.out.println(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm_KIS_TLF + "] and ["+infFileNm_KIS_TLF+"]");
				//압축 풀고  log data 생성 	and  파일 읽어서 DB Insert 

				KISDTLExtractLogging extractLog = new KISDTLExtractLogging (destPath,targetFileNm_KIS_TLF, infFileNm_KIS_TLF); 
				extractLog.execute();
				logger.info("KISDTLExtractLogging is end but maybe insert thread is trying to insert");
				
			}else {
				logger.info("[ERROR4] Can't get " + targetFileNm_KIS_TLF + " from FTP server");

		    	map.put("FILE_NM", fNm_KIS_TLF );
		    	map.put("ERR_INFO", "Can't get " + fNm_KIS_TLF + " from FTP server" );	    	
		    	dao.insLoggingErr(map);				
								
				File file = new File(destPath + File.separator + targetFileNm_KIS_TLF);
				if( !file.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm_KIS_TLF + "]");
				}
				File file2 = new File(destPath + File.separator + infFileNm_KIS_TLF);
				if( !file2.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm_KIS_TLF + "]");
				}	
				logger.info("[ERROR2] Can't get file on FTP server");
				System.out.println("[ERROR2] Can't get file on FTP server");
				if( bos_KIS_TLF != null ) {
					bos_KIS_TLF.close();
					bos_KIS_TLF = null;					
				}
				//return;
			}	

		}catch(Exception e) {
			logger.info(FileNm_KIS_TLF+"=>"+e.getMessage());
			System.out.println("exception occured => "+ e.getMessage());
			
	    	map.put("FILE_NM", fNm_KIS_TLF );
	    	map.put("ERR_INFO", "exception occured => "+fNm_KIS_TLF+ e.getMessage() );	    	
	    	try {
				dao.insLoggingErr(map);
			} catch (Exception e2) {
				e2.printStackTrace();
			}		
	    	
			if(!isDownOK_KIS_TLF)
			{
				File file = new File(destPath + File.separator + FileNm_KIS_TLF);
				if( !file.delete() ) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm_KIS_TLF + "]"); 
				}	
				File file2 = new File(destPath + File.separator + FileNm_KIS_TLF_inf);
				if( !file2.delete() ) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm_KIS_TLF_inf + "]");
				}					
				logger.info("[ERROR] Exception, delete file: "+FileNm_KIS_TLF);
				if( bos_KIS_TLF != null ) {
					try {
						bos_KIS_TLF.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					bos_KIS_TLF = null;					
				}
				//return;
			}
		}finally {
			if( bos_KIS_TLF != null ) {
				try {
					bos_KIS_TLF.close();
					bos_KIS_TLF = null;
				}catch(Exception e) {}
				
			}

		}//End of KIS_TLF , KIS_INF 	
		
		
	 
// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// KIS_REP , KIS_INF			///입반송 내역
// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 


		try {
			bos_KIS_REP = new BufferedOutputStream(new FileOutputStream(destDir	+ File.separator + targetFileNm_KIS_REP));
			iRetry = 0;

			//sFtpMgr.cd(sFtpMgr.pwd() + File.separator + kis_ftp_root); // 경로변경(현재경로+kis_ftp_root)
			while (iRetry < 2) {
				if (isDownOK_KIS_REP = sFtpMgr.get(targetFileNm_KIS_REP, bos_KIS_REP)) {
					break;
				}
				iRetry++;
			}
			bos_KIS_REP.flush();
			bos_KIS_REP.close();
			bos_KIS_REP = null;
			System.gc();

			bos_KIS_REP_INF = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + infFileNm_KIS_REP));
			iRetry = 0;

			// sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "datashare"); // 경로변경(현재경로+datashare폴더)
			while (iRetry < 2) {
				if (isDownOK_KIS_REP_INF = sFtpMgr.get(infFileNm_KIS_REP, bos_KIS_REP_INF)) {
					break;
				}
				iRetry++;
			}
			bos_KIS_REP_INF.flush();
			bos_KIS_REP_INF.close();
			bos_KIS_REP_INF = null;
			System.gc();

			if ((isDownOK_KIS_REP) && (isDownOK_KIS_REP_INF)) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm_KIS_REP + "] and ["+infFileNm_KIS_REP+"]");			

				// 압축 풀고 log data 생성 and 파일 읽어서 DB Insert
				KISDTLExtractLogging extractLog = new KISDTLExtractLogging(	destPath, targetFileNm_KIS_REP, infFileNm_KIS_REP);
				extractLog.execute();
				
				logger.info("KISDTLExtractLogging is end but maybe insert thread is trying to insert");
				
			} else {
				logger.info("[ERROR4] Can't get " + targetFileNm_KIS_REP + " from FTP server");

		    	map.put("FILE_NM", fNm_KIS_REP );
		    	map.put("ERR_INFO", "Can't get " + fNm_KIS_REP + " from FTP server" );	    	
		    	dao.insLoggingErr(map);
		    	
		    	
				File file = new File(destPath + File.separator + targetFileNm_KIS_REP);
				if (!file.delete()) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm_KIS_REP + "]");
				}
				File file2 = new File(destPath + File.separator + infFileNm_KIS_REP);
				if (!file2.delete()) {
					logger.info("[ERROR4-1] Failed to delete empty file ["	+ targetFileNm_KIS_REP + "]");
				}
				logger.info("[ERROR2] Can't get file on FTP server");
				if( bos_KIS_REP != null ) {
					bos_KIS_REP.close();
					bos_KIS_REP = null;					
				}
				//return;
			}

		} catch (Exception e) {
			logger.info(FileNm_KIS_TLF+"=>"+e.getMessage());

	    	map.put("FILE_NM", fNm_KIS_REP );
	    	map.put("ERR_INFO", fNm_KIS_REP +"=>" +e.getMessage() );	    	
	    	try {
				dao.insLoggingErr(map);
			} catch (Exception e2) {

				e2.printStackTrace();
			}
	    	
			if (!isDownOK_KIS_REP)// 예외 발생시 !isDownOK삭제(ACTION_TIME 다중 발생시 생성되는 0byte파일 삭제)
			{
				File file = new File(destPath + File.separator + FileNm_KIS_REP);
				if (!file.delete()) {
					logger.info("[ERROR] Failed to delete empty file ["	+ FileNm_KIS_REP + "]");
				}
				File file2 = new File(destPath + File.separator + FileNm_KIS_REP_inf);
				if (!file2.delete()) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm_KIS_REP_inf + "]");
				}
				logger.info("[ERROR] Exception, delete file: " + FileNm_KIS_REP);
				if( bos_KIS_REP != null ) {
					try {
						bos_KIS_REP.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					bos_KIS_REP = null;					
				}
				//return;
			}
		} finally {
			if (bos_KIS_REP != null) {
				try {
					bos_KIS_REP.close();
					bos_KIS_REP = null;
				} catch (Exception e) {
				}
			}

		}//end of KIS_REP , KIS_INF			///입반송 내역
				
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//NICE_TLF , NICE_INF 		
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
		try {		
			bos_NICE_TLF  = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + targetFileNm_NICE_TLF ));
			iRetry = 0;			

			//sFtpMgr.cd(sFtpMgr.pwd() + File.separator + nice_ftp_root); // 경로변경(현재경로+nice_ftp_root)

			while( iRetry < 2 ) {
				System.out.println("Try to sFtpMgr.get =>targetFileNm_NICE_TLF");
				if( isDownOK_NICE_TLF = sFtpMgr.get(targetFileNm_NICE_TLF, bos_NICE_TLF)) {
					
					break;
				}
				iRetry++;
			}
			System.out.println("isDownOK_NICE_TLF =>" + isDownOK_NICE_TLF);
			bos_NICE_TLF.flush();
			bos_NICE_TLF.close();
			bos_NICE_TLF = null;
			System.gc();
			
			bos_NICE_TLF_INF  = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + infFileNm_NICE_TLF ));
			iRetry = 0;			
			System.out.println("bos_NICE_TLF for::" + infFileNm_NICE_TLF);
			
			//sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "datashare"); // 경로변경(현재경로+datashare폴더)
			while( iRetry < 2 ) {	
				System.out.println("Try to sFtpMgr.get =>infFileNm_NICE_TLF");				
				if( isDownOK_NICE_TLF_INF = sFtpMgr.get(infFileNm_NICE_TLF, bos_NICE_TLF_INF)) {		
					break;
				}
				iRetry++;
			}
			System.out.println("isDownOK_NICE_TLF_INF =>" + isDownOK_NICE_TLF_INF);
			bos_NICE_TLF_INF.flush();
			bos_NICE_TLF_INF.close();
			bos_NICE_TLF_INF = null;
			System.gc();
			
			
			if( (isDownOK_NICE_TLF )&&(isDownOK_NICE_TLF_INF)) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm_NICE_TLF + "] and ["+infFileNm_NICE_TLF+"]");			
				System.out.println(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm_NICE_TLF + "] and ["+infFileNm_NICE_TLF+"]");
				//압축 풀고  log data 생성 	and  파일 읽어서 DB Insert 

				KISDTLExtractLogging extractLog = new KISDTLExtractLogging (destPath,targetFileNm_NICE_TLF, infFileNm_NICE_TLF); 
				extractLog.execute();
				logger.info("NICEDTLExtractLogging is end but maybe insert thread is trying to insert");
				
			}else {
				logger.info("[ERROR4] Can't get " + targetFileNm_NICE_TLF + " from FTP server");
						
		    	map.put("FILE_NM", fNm_NICE_TLF );
		    	map.put("ERR_INFO", "Can't get " + fNm_NICE_TLF + " from FTP server" );	    	
		    	dao.insLoggingErr(map);
				
				File file = new File(destPath + File.separator + targetFileNm_NICE_TLF);
				if( !file.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm_NICE_TLF + "]");
				}
				File file2 = new File(destPath + File.separator + infFileNm_NICE_TLF);
				if( !file2.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm_NICE_TLF + "]");
				}	
				logger.info("[ERROR2] Can't get file on FTP server");
				System.out.println("[ERROR2] Can't get file on FTP server");
				if( bos_NICE_TLF != null ) {
					bos_NICE_TLF.close();
					bos_NICE_TLF = null;					
				}
				//return;
			}	

		}catch(Exception e) {
			logger.info(FileNm_NICE_TLF+"=>"+e.getMessage());
			System.out.println("exception occured => "+ e.getMessage());
			
	    	map.put("FILE_NM", fNm_NICE_TLF );
	    	map.put("ERR_INFO", "exception occured => "+ fNm_NICE_TLF + "==>" + e.getMessage());	    	
	    	try {
				dao.insLoggingErr(map);
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
	    	
	    	
			if(!isDownOK_NICE_TLF)//예외 발생시 !isDownOK삭제(ACTION_TIME 다중 발생시 생성되는 0byte파일 삭제)
			{
				File file = new File(destPath + File.separator + FileNm_NICE_TLF);
				if( !file.delete() ) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm_NICE_TLF + "]"); 
				}	
				File file2 = new File(destPath + File.separator + FileNm_NICE_TLF_inf);
				if( !file2.delete() ) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm_NICE_TLF_inf + "]");
				}					
				logger.info("[ERROR] Exception, delete file: "+FileNm_NICE_TLF);
				if( bos_NICE_TLF != null ) {
					try {
						bos_NICE_TLF.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					bos_NICE_TLF = null;					
				}
				//return;
			}
		}finally {
			if( bos_NICE_TLF != null ) {
				try {
					bos_NICE_TLF.close();
					bos_NICE_TLF = null;
				}catch(Exception e) {}
				
			}

		}//End of NICE_TLF , NICE_INF 
				

// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// NICE_REP , NICE_INF
// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		try {
			bos_NICE_REP = new BufferedOutputStream(new FileOutputStream(destDir	+ File.separator + targetFileNm_NICE_REP));
			iRetry = 0;

			//sFtpMgr.cd(sFtpMgr.pwd() + File.separator + nice_ftp_root); // 경로변경(현재경로+nice_ftp_root)
			while (iRetry < 2) {
				System.out.println("Try to sFtpMgr.get =>targetFileNm_NICE_TLF");
				if (isDownOK_NICE_REP = sFtpMgr.get(targetFileNm_NICE_REP, bos_NICE_REP)) {
					break;
				}
				iRetry++;
			}
			System.out.println("isDownOK_NICE_TLF =>" + isDownOK_NICE_TLF);
			bos_NICE_REP.flush();
			bos_NICE_REP.close();
			bos_NICE_REP = null;
			System.gc();

			bos_NICE_REP_INF = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + infFileNm_NICE_REP));
			iRetry = 0;
			System.out.println("bos_NICE_TLF for::" + infFileNm_NICE_TLF);
			// sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "datashare"); // 경로변경(현재경로+datashare폴더)
			while (iRetry < 2) {
				System.out.println("Try to sFtpMgr.get =>infFileNm_NICE_TLF");				
				if (isDownOK_NICE_REP_INF = sFtpMgr.get(infFileNm_NICE_REP, bos_NICE_REP_INF)) {
					break;
				}
				iRetry++;
			}
			System.out.println("isDownOK_NICE_TLF_INF =>" + isDownOK_NICE_TLF_INF);
			bos_NICE_REP_INF.flush();
			bos_NICE_REP_INF.close();
			bos_NICE_REP_INF = null;
			System.gc();

			if ((isDownOK_NICE_REP) && (isDownOK_NICE_REP_INF)) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm_NICE_REP + "] and ["+infFileNm_NICE_REP+"]");			
				System.out.println(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm_NICE_TLF + "] and ["+infFileNm_NICE_TLF+"]");
				// 압축 풀고 log data 생성 and 파일 읽어서 DB Insert
				KISDTLExtractLogging extractLog = new KISDTLExtractLogging(	destPath, targetFileNm_NICE_REP, infFileNm_NICE_REP);
				extractLog.execute();
				
				logger.info("NICEDTLExtractLogging is end but maybe insert thread is trying to insert");
				
			} else {
				logger.info("[ERROR4] Can't get " + targetFileNm_NICE_REP + " from FTP server");
				
		    	map.put("FILE_NM", fNm_NICE_REP );
		    	map.put("ERR_INFO", "Can't get " + fNm_NICE_REP + " from FTP server" );	    	
		    	dao.insLoggingErr(map);		    	
		    	
				File file = new File(destPath + File.separator + targetFileNm_NICE_REP);
				if (!file.delete()) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm_NICE_REP + "]");
				}
				File file2 = new File(destPath + File.separator + infFileNm_NICE_REP);
				if (!file2.delete()) {
					logger.info("[ERROR4-1] Failed to delete empty file ["	+ targetFileNm_NICE_REP + "]");
				}
				logger.info("[ERROR2] Can't get file on FTP server");
				System.out.println("[ERROR2] Can't get file on FTP server");
				if( bos_NICE_REP != null ) {
					bos_NICE_REP.close();
					bos_NICE_REP = null;					
				}
				//return;
			}

		} catch (Exception e) {
			logger.info(FileNm_NICE_REP+"=>"+e.getMessage());
			System.out.println("exception occured => "+ e.getMessage());
			
	    	map.put("FILE_NM", fNm_NICE_REP );
	    	map.put("ERR_INFO", "exception occured => "+fNm_NICE_REP+"=>"+ e.getMessage() );	    	
	    	try {
				dao.insLoggingErr(map);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
	    	
	    	
			if (!isDownOK_NICE_REP)// 예외 발생시 !isDownOK삭제(ACTION_TIME 다중 발생시 생성되는 0byte파일 삭제)
			{
				File file = new File(destPath + File.separator + FileNm_NICE_REP);
				if (!file.delete()) {
					logger.info("[ERROR] Failed to delete empty file ["	+ FileNm_NICE_REP + "]");
				}
				File file2 = new File(destPath + File.separator + FileNm_NICE_REP_inf);
				if (!file2.delete()) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm_NICE_REP_inf + "]");
				}
				logger.info("[ERROR] Exception, delete file: " + FileNm_NICE_REP);
				if( bos_NICE_REP != null ) {
					try {
						bos_NICE_REP.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					bos_NICE_REP = null;					
				}
				//return;
			}
		} finally {
			if (bos_NICE_REP != null) {
				try {
					bos_NICE_REP.close();
					bos_NICE_REP = null;
				} catch (Exception e) {
				}
			}

		}//end of NICE_REP , NICE_INF			///입반송 내역		
		

	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//KICC_TLF , KICC_INF 		
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
		try {		
			bos_KICC_TLF  = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + targetFileNm_KICC_TLF ));
			iRetry = 0;			

			//sFtpMgr.cd(sFtpMgr.pwd() + File.separator + kicc_ftp_root); // 경로변경(현재경로+kicc_ftp_root)

			while( iRetry < 2 ) {
				System.out.println("Try to sFtpMgr.get =>targetFileNm_KICC_TLF");
				if( isDownOK_KICC_TLF = sFtpMgr.get(targetFileNm_KICC_TLF, bos_KICC_TLF)) {
					
					break;
				}
				iRetry++;
			}
			System.out.println("isDownOK_KICC_TLF =>" + isDownOK_KICC_TLF);
			bos_KICC_TLF.flush();
			bos_KICC_TLF.close();
			bos_KICC_TLF = null;
			System.gc();
			
			bos_KICC_TLF_INF  = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + infFileNm_KICC_TLF ));
			iRetry = 0;			
			System.out.println("bos_KICC_TLF for::" + infFileNm_KICC_TLF);
			
			//sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "datashare"); // 경로변경(현재경로+datashare폴더)
			while( iRetry < 2 ) {	
				System.out.println("Try to sFtpMgr.get =>infFileNm_KICC_TLF");				
				if( isDownOK_KICC_TLF_INF = sFtpMgr.get(infFileNm_KICC_TLF, bos_KICC_TLF_INF)) {		
					break;
				}
				iRetry++;
			}
			System.out.println("isDownOK_KICC_TLF_INF =>" + isDownOK_KICC_TLF_INF);
			bos_KICC_TLF_INF.flush();
			bos_KICC_TLF_INF.close();
			bos_KICC_TLF_INF = null;
			System.gc();
			
			
			if( (isDownOK_KICC_TLF )&&(isDownOK_KICC_TLF_INF)) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm_KICC_TLF + "] and ["+infFileNm_KICC_TLF+"]");			
				System.out.println(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm_KICC_TLF + "] and ["+infFileNm_KICC_TLF+"]");
				//압축 풀고  log data 생성 	and  파일 읽어서 DB Insert 

				KISDTLExtractLogging extractLog = new KISDTLExtractLogging (destPath,targetFileNm_KICC_TLF, infFileNm_KICC_TLF); 
				extractLog.execute();
				logger.info("KICCDTLExtractLogging is end but maybe insert thread is trying to insert");
				
			}else {
				logger.info("[ERROR4] Can't get " + targetFileNm_KICC_TLF + " from FTP server");
						
		    	map.put("FILE_NM", fNm_KICC_TLF );
		    	map.put("ERR_INFO", "Can't get " + fNm_KICC_TLF + " from FTP server" );	    	
		    	dao.insLoggingErr(map);
		    	
				File file = new File(destPath + File.separator + targetFileNm_KICC_TLF);
				if( !file.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm_KICC_TLF + "]");
				}
				File file2 = new File(destPath + File.separator + infFileNm_KICC_TLF);
				if( !file2.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm_KICC_TLF + "]");
				}	
				logger.info("[ERROR2] Can't get file on FTP server");
				System.out.println("[ERROR2] Can't get file on FTP server");
				if( bos_KICC_TLF != null ) {
					bos_KICC_TLF.close();
					bos_KICC_TLF = null;					
				}
				//return;
			}	

		}catch(Exception e) {
			logger.info(FileNm_KICC_TLF+"=>"+e.getMessage());
			System.out.println("exception occured => "+ e.getMessage());
			
	    	map.put("FILE_NM", fNm_KICC_TLF );
	    	map.put("ERR_INFO","exception occured => "+ fNm_KICC_TLF+"=>"+ e.getMessage() );	    	
	    	try {
				dao.insLoggingErr(map);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
	    	
	    	
			if(!isDownOK_KICC_TLF)//예외 발생시 !isDownOK삭제(ACTION_TIME 다중 발생시 생성되는 0byte파일 삭제)
			{
				File file = new File(destPath + File.separator + FileNm_KICC_TLF);
				if( !file.delete() ) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm_KICC_TLF + "]"); 
				}	
				File file2 = new File(destPath + File.separator + FileNm_KICC_TLF_inf);
				if( !file2.delete() ) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm_KICC_TLF_inf + "]");
				}					
				logger.info("[ERROR] Exception, delete file: "+FileNm_KICC_TLF);
				if( bos_KICC_TLF != null ) {
					try {
						bos_KICC_TLF.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					bos_KICC_TLF = null;					
				}
				//return;
			}
		}finally {
			if( bos_KICC_TLF != null ) {
				try {
					bos_KICC_TLF.close();
					bos_KICC_TLF = null;
				}catch(Exception e) {}
				
			}

		}//End of KICC_TLF , KICC_INF 

		

// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// KICC_REP , KICC_INF
// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		try {
			bos_KICC_REP = new BufferedOutputStream(new FileOutputStream(destDir	+ File.separator + targetFileNm_KICC_REP));
			iRetry = 0;

			//sFtpMgr.cd(sFtpMgr.pwd() + File.separator + kicc_ftp_root); // 경로변경(현재경로+kicc_ftp_root)
			while (iRetry < 2) {
				System.out.println("Try to sFtpMgr.get =>targetFileNm_KICC_TLF");
				if (isDownOK_KICC_REP = sFtpMgr.get(targetFileNm_KICC_REP, bos_KICC_REP)) {
					break;
				}
				iRetry++;
			}
			System.out.println("isDownOK_KICC_TLF =>" + isDownOK_KICC_TLF);
			bos_KICC_REP.flush();
			bos_KICC_REP.close();
			bos_KICC_REP = null;
			System.gc();

			bos_KICC_REP_INF = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + infFileNm_KICC_REP));
			iRetry = 0;
			System.out.println("bos_KICC_TLF for::" + infFileNm_KICC_TLF);
			// sFtpMgr.cd(sFtpMgr.pwd() + File.separator + "datashare"); // 경로변경(현재경로+datashare폴더)
			while (iRetry < 2) {
				System.out.println("Try to sFtpMgr.get =>infFileNm_KICC_TLF");				
				if (isDownOK_KICC_REP_INF = sFtpMgr.get(infFileNm_KICC_REP, bos_KICC_REP_INF)) {
					break;
				}
				iRetry++;
			}
			System.out.println("isDownOK_KICC_TLF_INF =>" + isDownOK_KICC_TLF_INF);
			bos_KICC_REP_INF.flush();
			bos_KICC_REP_INF.close();
			bos_KICC_REP_INF = null;
			System.gc();

			if ((isDownOK_KICC_REP) && (isDownOK_KICC_REP_INF)) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm_KICC_REP + "] and ["+infFileNm_KICC_REP+"]");			
				System.out.println(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm_KICC_TLF + "] and ["+infFileNm_KICC_TLF+"]");
				// 압축 풀고 log data 생성 and 파일 읽어서 DB Insert
				KISDTLExtractLogging extractLog = new KISDTLExtractLogging(	destPath, targetFileNm_KICC_REP, infFileNm_KICC_REP);
				extractLog.execute();
				
				logger.info("KICCDTLExtractLogging is end but maybe insert thread is trying to insert");
				
			} else {
				logger.info("[ERROR4] Can't get " + targetFileNm_KICC_REP + " from FTP server");
				
		    	map.put("FILE_NM", fNm_KICC_REP );
		    	map.put("ERR_INFO", "Can't get " + fNm_KICC_REP + " from FTP server" );	    	
		    	dao.insLoggingErr(map);
				
				File file = new File(destPath + File.separator + targetFileNm_KICC_REP);
				if (!file.delete()) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm_KICC_REP + "]");
				}
				File file2 = new File(destPath + File.separator + infFileNm_KICC_REP);
				if (!file2.delete()) {
					logger.info("[ERROR4-1] Failed to delete empty file ["	+ targetFileNm_KICC_REP + "]");
				}
				logger.info("[ERROR2] Can't get file on FTP server");
				System.out.println("[ERROR2] Can't get file on FTP server");
				if( bos_KICC_REP != null ) {
					bos_KICC_REP.close();
					bos_KICC_REP = null;					
				}
				//return;
			}

		} catch (Exception e) {
			logger.info(FileNm_KICC_REP+"=>"+e.getMessage());
			System.out.println("exception occured => "+ e.getMessage());
			
	    	map.put("FILE_NM", fNm_KICC_REP );
	    	map.put("ERR_INFO","exception occured => "+fNm_KICC_REP+"=>"+ e.getMessage());	    	
	    	try {
				dao.insLoggingErr(map);
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
	    	
	    	
			if (!isDownOK_KICC_REP)// 예외 발생시 !isDownOK삭제(ACTION_TIME 다중 발생시 생성되는 0byte파일 삭제)
			{
				File file = new File(destPath + File.separator + FileNm_KICC_REP);
				if (!file.delete()) {
					logger.info("[ERROR] Failed to delete empty file ["	+ FileNm_KICC_REP + "]");
				}
				File file2 = new File(destPath + File.separator + FileNm_KICC_REP_inf);
				if (!file2.delete()) {
					logger.info("[ERROR] Failed to delete empty file [" + FileNm_KICC_REP_inf + "]");
				}
				logger.info("[ERROR] Exception, delete file: " + FileNm_KICC_REP);
				if( bos_KICC_REP != null ) {
					try {
						bos_KICC_REP.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					bos_KICC_REP = null;					
				}
				//return;
			}
		} finally {
			if (bos_KICC_REP != null) {
				try {
					bos_KICC_REP.close();
					bos_KICC_REP = null;
				} catch (Exception e) {
				}
			}

		}//end of KICC_REP , KICC_INF			///입반송 내역

	
		
		
	}//end of excute()
	
	
	
	
	

	
	
	
	
	
}