package biz.cms_KISDTLDownloader;

public class KISDTLData {
	
	static final int POSREQ_A4 = 2067; //inq_type A4, HashCode
	static final int POSREQ_A5 = 2068; //inq_type A5, HashCode

	
	static int nlensLog[]= {12,12};   //로그 
	static final String strHeadersLog[] = {     				
			"ZIP_SIZE"			//압축파일 사이즈
			,"ORI_SIZE"		//원래 파일 사이즈 				
		};	
	

	static int nlensTLF_H[]= {
			1,3,10,8,138		
		};   
	static final String strHeadersTLF_H[] = {     				
			"RECORD_TP"			//RECORD 구분 H
			,"SERVICE_TP"		//서비스 구분
			,"FC_BIZCO_NO"		//업체사업자등록번호
			,"FILE_MK_DT"		//파일작성일
			,"FILLER"		    //공백

		};
	
	static int nlensTLF_D[]= {
		1,13,2,8,6
		,20,2,19,8,10
		,12,9,9,2,1
		,4,4,15,10,1
		,1,1,2
	};   
	static final String strHeadersTLF_D[] = {     				
			"RECORD_TP"			//RECORD 구분 H
			,"TID"				//터미널 아이디
			,"VAN_TP"			//van 구분 05 kis , 03 KICC, 04:NICE
			,"AUTH_DT"			//YYYYMMDD, 매출일자
			,"AUTH_TM"			//HHMMSS 매출시간
			
			,"TRN_UNIQ_SEQ"		//거래고유번호 (매출일자 + 거래일련번호 )
			,"TRN_TP"			//AC:승인 RR 취소
			,"CARD_DATA"		//111122******4444555
			,"ORG_AUTH_DT"		//원거래일자YYYYMMDD 취소일경우 -원거래승인일자, 승인일경우 -00000000
			,"AUTH_NO"			//승인번호
			
			,"AUTH_AMT"			//거래금액
			,"VLT_AMT"			//봉사료
			,"VAT_AMT"			//세액
			,"INST_TERM"		//할부기간
			,"INPUT_TP"			//key in, swipe 구분
			
			,"VAN_ISS_CORP_CD"	//발급사코드
			,"VAN_BUY_CORP_CD"	//매입사코드
			,"FC_NO"			//가맹점번호
			,"FC_BIZCO_NO"		//가맹점 사업자번호
			,"TERM_TP"			//거래종류구분
			
			,"FRN_CARD_YN"		//해외발급카드여부
			,"CHK_CARD_YN"		//체크카드여부
			,"FILLER"			//FILLER
		};
	
	static int nlensTLF_T[]= {1,6,153};   
	static final String strHeadersTLF_T[] = {     				
			"RECORD_TP"		//RECORD구분
			,"TOT_CNT"		//총건수
			,"FILLER"		//FILLER
		};
	

	static int nlensREP_S[]= {
		2,6,10,10,122		
	};    
	static final String strHeadersREP_S[] = {     						
		"RECORD_TP"		//RECORD 구분<D441>
		,"FILE_MK_DT"	//파일 작성일
		,"FC_BIZCO_NO"	//업체 사업자등록번호(가맹점 사업자등록번호 OR 가맹점 기관코드)
		,"VAN_BIZCO_NO"	//VAN 사업자등록번호
		,"FILLER"		//
	};
	
	
	
	
	static int nlensREP_H[]= {
		2,6,10,10,6
		,6,6,15,3,3
		,6,6,6,4,61		
	};   
	static final String strHeadersREP_H[] = {     				
		 "RECORD_TP"		//RECORD 구분<D441>
		,"FILE_MK_DT"		//파일작성일
		,"CARD_BIZCO_NO"	//카드사사업자등록번호
		,"FC_BIZCO_NO"		//가맹점사업자번호
		,"RECPT_DT_FR"		//접수기간FROM
		
		,"RECPT_DT_TO"		//접수기간TO
		,"DPST_DT"			//지급일자
		,"FC_NO"			//가맹점번호
		,"CURCY_CD"		//통화코드(410: 원화, 840:US$)
		,"VAN_SVC_TP"		//서비스구분('DDC')
		
		,"SALE_DT_FR"		//매출일자FROM
		,"SALE_DT_TO"		//매출일자TO
		,"REQ_DT"			//청구일자
		,"VAN_BUY_CORP_CD"	//VAN사매입사코드
		,"FILLER"		    //공백
	};
	
	
	
	/*
	"CO_CD"				//회사코드
	"VAN_CD"			//VAN코드(KIS,NICE,KICC)
	"FILE_DT"			//파일명일자
	"HT_SEQ"			//순번(HQ_CARDREP_HDR.HT_SEQ)
	"SEQ"				//순번(CMBO.HQ_CARDREP_SEQ)
	"RECORD_TP"			//RECORD 구분<D441>
	"CURCY_CD"			//통화코드
	"CURCY_IDX"			//통화지수
	"AUTH_DT"			//매출(취소)일자
	"RECPT_DT"			//접수일자
	"CARD_DATA"			//카드번호
	"INST_TERM"			//할부기간
	"AUTH_AMT"			//신용판매금액
	"CARD_RTN_CD"		//반송사유 코드
	"VAN_RTN_CD"		//반송사유 코드
	"NOT_USED"			//주민등록번호
	"CARD_FEE"			//수수료금액
	"RTN_MSG"			//반송사유
	"TRN_UNIQ_SEQ"		//거래고유번호(입금반송 내역과 Mapping. 공백(BC카드)인경우 TID+CARD_DATA+AUTH_DT+AUTH_NO+AUTH_AMT)
	"TID"				//단말기번호
	"AUTH_NO"			//승인번호
	"VAN_TP"			//VAN 구분
	"TLF_VAN_CD"		//거래내역 VAN코드(KIS,NICE,KICC)
	"TLF_FILE_DT"		//거래내역 파일명일자
	"TLF_SEQ"			//거래내역 순번(CMBO.HQ_CARDTLF_SEQ)
	"TLF_MAP_YN"		//	거래내역 Mapping 여부<C312>
	"REG_DTM"			//등록일시
	"REG_EMP_ID"		//등록자ID
	"MOD_DTM"			//수정일시
	"MOD_EMP_ID"		//수정자ID
	*/
	
	static int nlensREP_D[]= {
		2,3,1,6,6
		,19,2,10,4,2
		,13,10,20,20,20
		,10,2		
	};   
	static final String strHeadersREP_D[] = {     				

		"RECORD_TP"			//RECORD 구분<D441>
		,"CURCY_CD"			//통화코드
		,"CURCY_IDX"		//통화지수
		,"AUTH_DT"			//매출(취소)일자
		,"RECPT_DT"			//접수일자
		
		,"CARD_DATA"		//카드번호
		,"INST_TERM"		//할부기간
		,"AUTH_AMT"			//신용판매금액
		,"CARD_RTN_CD"		//반송사유 코드
		,"VAN_RTN_CD"		//반송사유 코드
		
		,"NOT_USED"			//주민등록번호
		,"CARD_FEE"			//수수료금액
		,"RTN_MSG"			//반송사유
		,"TRN_UNIQ_SEQ"		//거래고유번호(입금반송 내역과 Mapping. 공백(BC카드)인경우 TID+CARD_DATA+AUTH_DT+AUTH_NO+AUTH_AMT)
		,"TID"				//단말기번호
		
		,"AUTH_NO"			//승인번호
		,"VAN_TP"			//VAN 구분

	};
	

	
	static int nlensREP_T[]= {
		2,6,12,6,12
		,6,12,6,12,6
		,12,12,12,20,14		
	};   
	static final String strHeadersREP_T[] = {     				
		"RECORD_TP"			//RECORD 구분<D441>
		,"RECPT_CNT"		//접수건수(A1) - 청구(매출,취소)된 건수 합계
		,"RECPT_AMT"		//접수금액(B1)  - 청구(매출,취소)된 금액 합계
		,"RTN_CNT"			//반송총건수(A2) - 반송(매출,취소)된 건수 합계
		,"RTN_AMT"			//반송총금액(B2) - 반송(매출,취소)된 금액 합계
		
		,"HOLD_CNT"			//보류총건수(A3) - 보류(매출,취소)된 건수 합계
		,"HOLD_AMT"			//보류총금액(B3) - 보류(매출,취소)된 금액 합계
		,"HOLD_OFF_CNT"		//보류해제총건수(A4) - 보류해제(기청구분)된 건수 합계
		,"HOLD_OFF_AMT"		//보류해제총금액(B4) - 보류해제(기청구분)된 금액 합계
		,"TOT_CNT"			//합계건수(A5) - A5=A1+A4
		
		,"TOT_AMT"			//합계금액(B5) - B5=B1-B2-B3+B4
		,"TOT_FEE"			//수수료합계(E)
		,"DPST_AMT"			//입금액(F) - F=B5-E
		,"ACCT_NO"			//결제계좌번호
		,"FILLER"			//FILLER
	};
	
	
	
	
	/*
	"CO_CD"			//회사코드
	"VAN_CD"		//VAN코드(KIS,NICE,KICC)
	"FILE_DT"		//파일명일자
	"RECORD_TP"		//RECORD 구분<D441>
	"TOT_CNT"		//총 RECORD 개수
	"REG_DTM"		//등록일시
	"REG_EMP_ID"	//등록자ID
	"MOD_DTM"		//수정일시
	"MOD_EMP_ID"	//수정자ID
	*/
	
	
	
	
	
	static int nlensREP_E[]= {
		2,6,142		
	};   
	static final String strHeadersREP_E[] = {     				
		"RECORD_TP"		//RECORD 구분<D441>
		,"TOT_CNT"		//총 RECORD 개수
		,"FILLER"

	};
	
}