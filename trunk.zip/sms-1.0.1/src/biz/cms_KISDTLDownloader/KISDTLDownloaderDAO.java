package biz.cms_KISDTLDownloader;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class KISDTLDownloaderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(KISDTLDownloaderPollingAction.class);
	
	
	public int  insLoggingData    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			
			
			sql.put(findQuery("service-sql", "INS_KISLOGGING_DATA"));			
		
			sql.setString(++i, (String)map.get("FILE_NM"));
			sql.setString(++i, (String)map.get("ZIP_FILE_SIZE_INF"));
			sql.setString(++i, (String)map.get("ZIP_FILE_SIZE"));
			sql.setString(++i, (String)map.get("ORG_FILE_SIZE_INF"));
			sql.setString(++i, (String)map.get("ORG_FILE_SIZE"));
					
			
			//logger.info("[SQL1][INS_KISLOGGING_DATA]" + sql.debug() );
			//System.out.println("[SQL1][INS_KISLOGGING_DATA]" + sql.debug());					
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISLOGGING_DATA]" + sql.debug() );
		}finally {
			//transaction 종료
			end();
		}
		
		return rows;
	}

	public int  insLoggingErr    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			
			
			sql.put(findQuery("service-sql", "INS_KISLOGGING_ERR"));			
		
			sql.setString(++i, (String)map.get("FILE_NM"));
			sql.setString(++i, (String)map.get("ERR_INFO"));
					
			
			//logger.info("[SQL1][INS_KISLOGGING_DATA]" + sql.debug() );
			//System.out.println("[SQL1][INS_KISLOGGING_DATA]" + sql.debug());					
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISLOGGING_DATA]" + sql.debug() );
		}finally {
			//transaction 종료
			end();
		}
		
		return rows;
	}
	
	public int  updLogStat    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			
			
			sql.put(findQuery("service-sql", "UPD_KISLOGGING_DATA_STAT"));			
		
			sql.setString(++i, (String)map.get("PROC_STAT"));
			sql.setString(++i, (String)map.get("FILE_NM"));
											
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISLOGGING_DATA]" + sql.debug() );
		}finally {
			//transaction 종료
			end();
		}
		
		return rows;
	}
	
	public int  updLogOK    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			
			
			sql.put(findQuery("service-sql", "UPD_KISLOGGING_DATA_OK"));			
		
			sql.setString(++i, (String)map.get("FILE_NM"));
											
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISLOGGING_DATA]" + sql.debug() );
		}finally {
			//transaction 종료
			end();
		}
		
		return rows;
	}
	
	public int  updLogError    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			
			
			sql.put(findQuery("service-sql", "UPD_KISLOGGING_DATA_ERROR"));			
		
			sql.setString(++i, (String)map.get("ERR"));
			sql.setString(++i, (String)map.get("FILE_NM"));
											
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][UPD_KISLOGGING_DATA_ERROR]" + sql.debug() );
		}finally {
			//transaction 종료
			end();
		}
		
		return rows;
	}
	
	public int  insKISDailyDTL_TLF_H    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			
			sql.put(findQuery("service-sql", "INS_KISDAILYDTL_TLF_H"));			
			
			logger.info("33van_cd=>"+ (String)map.get("VAN_CD"));
			logger.info("33FILE_DT=>"+ (String)map.get("FILE_DT"));
			
			
			sql.setString(++i, (String)map.get("VAN_CD"));
			sql.setString(++i, (String)map.get("FILE_DT"));
			sql.setString(++i, (String)map.get("RECORD_TP"));
			sql.setString(++i, (String)map.get("SERVICE_TP"));		
			sql.setString(++i, (String)map.get("FC_BIZCO_NO"));
			sql.setString(++i, (String)map.get("FILE_MK_DT"));
									
			//System.out.println(	"[SQL1][INS_KISDAILYDTL_TLF_H]" + sql.debug() );
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISDAILYDTL_REP_S]" + sql.debug() );
			map.put("ERR_INFO", e.getMessage());
			sql.close();
			sql.clearParameter();									
		}finally {
			//transaction 종료
			end();
		}		
		return rows;
	}
	
	
	public int  insKISDailyDTL_TLF_D    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			

			sql.put(findQuery("service-sql", "INS_KISDAILYDTL_TLF_D"));			
                             
			sql.setString(++i, (String)map.get("VAN_CD"));		          //--//VAN코드(KIS,NICE,KICC)                 
			sql.setString(++i, (String)map.get("FILE_DT"));               //--//파일명일자                                		
			sql.setString(++i, (String)map.get("RECORD_TP"));             //--//RECORD 구분('D' : Data 레코드)       		
			sql.setString(++i, (String)map.get("TID"));		              //--//단말기 번호                               
			sql.setString(++i, (String)map.get("VAN_TP"));                //--//VAN구분<VNAK>
			
			sql.setString(++i, (String)map.get("AUTH_DT"));               //--//승인일자                                 
			sql.setString(++i, (String)map.get("AUTH_TM"));               //--//승인시간                                 
			sql.setString(++i, (String)map.get("TRN_UNIQ_SEQ"));		  //--//거래고유번호(입금반송 내역과 Mapping. 공백(BC카드		
			sql.setString(++i, (String)map.get("TRN_TP"));                //--//승인/취소 구분(AC:승인, RR:취소)               
			sql.setString(++i, (String)map.get("CARD_DATA"));             //--//카드번호
			
			sql.setString(++i, (String)map.get("ORG_AUTH_DT"));           //--//원거래일자                                
			sql.setString(++i, (String)map.get("AUTH_NO"));		          //--//승인번호                                 
			sql.setString(++i, (String)map.get("AUTH_AMT"));              //--//거래금액                            		
			sql.setString(++i, (String)map.get("VLT_AMT"));               //--//봉사료                                  
			sql.setString(++i, (String)map.get("VAT_AMT"));               //--//세액
			
			sql.setString(++i, (String)map.get("INST_TERM"));		      //--//할부기간                                 
			sql.setString(++i, (String)map.get("INPUT_TP"));              //--//Keyin/Swipe구분(S:SWIPE, K:KEYIN)      
			sql.setString(++i, (String)map.get("VAN_ISS_CORP_CD"));       //--//발급사코드                           		
			sql.setString(++i, (String)map.get("VAN_BUY_CORP_CD"));       //--//매입사코드                                
			sql.setString(++i, (String)map.get("FC_NO"));		          //--//가맹점번호(카드사)
			
			sql.setString(++i, (String)map.get("FC_BIZCO_NO"));           //--//가맹점 사업자번호                            
			sql.setString(++i, (String)map.get("TERM_TP"));               //--//거래종류구분(C:단말기,T:전화승인등록,P:온라인PG거래)     
			sql.setString(++i, (String)map.get("FRN_CARD_YN"));           //--//해외발급카드여부(Y:해외발급카드,N:국내카드)       		
			sql.setString(++i, (String)map.get("CHK_CARD_YN"));           //--//체크카드여부(Y:체크카드,N:일반신용카드)              

			
			//System.out.println("[SQL1][INS_KISDAILYDTL_TLF_D]" + sql.debug() );		
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISDAILYDTL_REP_S]" + sql.debug() );
			map.put("ERR_INFO", e.getMessage());
			sql.close();
			sql.clearParameter();	
			
		}finally {
			//transaction 종료
			end();
		}		
		return rows;
	}
	
	public int  insKISDailyDTL_TLF_T    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			

			sql.put(findQuery("service-sql", "INS_KISDAILYDTL_TLF_T"));			
                    
			sql.setString(++i, (String)map.get("VAN_CD"));		  //VAN코드(KIS,NICE,KICC)          
			sql.setString(++i, (String)map.get("FILE_DT"));        //파일명일자                         
			sql.setString(++i, (String)map.get("RECORD_TP"));        //RECORD 구분('T' : Trailer 레코드)  
			sql.setString(++i, (String)map.get("TOT_CNT"));        //총건수(DATA 레코드 총건수)             
			
			//logger.info("[SQL1][INS_KISVENDAILY_TRN]" + sql.debug() );
			//System.out.println(	"[SQL1][INS_KISVENDAILY_TRN]" + sql.debug() );
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISDAILYDTL_REP_S]" + sql.debug() );
			map.put("ERR_INFO", e.getMessage());
			sql.close();
			sql.clearParameter();	

			//System.out.println("[ERROR1] " + e.getMessage());
		}finally {
			//transaction 종료
			end();
		}		
		return rows;
	}

	
	
	
	
	
	
	
	public String selKISDAILYDTL_REP_HT_SEQ () throws Exception{
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		int rows = -1;
		String sequence = "";
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			

			sql.put(findQuery("service-sql", "SEL_KIS_REP_HT_SEQ"));			
                    
			list = executeQuery(sql);
			sql.close();
			if( list.size() > 0 ) sequence = (String)((Map<String, String>)list.get(0)).get("SEQ");
									
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][SEL_KIS_REP_HT_SEQ]" + sql.debug() );
		}finally {
			//transaction 종료
			end();
		}		
		return sequence;
	}
	
	
	
	
	public int  insKISDailyDTL_REP_S    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			

                    
			sql.put(findQuery("service-sql", "INS_KISDAILYDTL_REP_S"));			
			sql.setString(++i, (String)map.get("VAN_CD"));		  //VAN코드(KIS,NICE,KICC)          		  
			sql.setString(++i, (String)map.get("FILE_DT"));		  
			sql.setString(++i, (String)map.get("RECORD_TP"));		  
			sql.setString(++i, (String)map.get("FILE_MK_DT"));
			sql.setString(++i, (String)map.get("FC_BIZCO_NO"));		  
			sql.setString(++i, (String)map.get("VAN_BIZCO_NO"));		  
			
			
									
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISDAILYDTL_REP_S]" + sql.debug() );
			map.put("ERR_INFO", e.getMessage());
			sql.close();
			sql.clearParameter();			
		}finally {
			//transaction 종료
			end();
		}		
		return rows;
	}


	public int  insKISDailyDTL_REP_H    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			

			sql.put(findQuery("service-sql", "INS_KISDAILYDTL_REP_H"));			
                    
			sql.setString(++i, (String)map.get("VAN_CD"));		  //VAN코드(KIS,NICE,KICC)          		  
			sql.setString(++i, (String)map.get("FILE_DT"));	
			sql.setString(++i, (String)map.get("HT_SEQ"));			  
			sql.setString(++i, (String)map.get("RECORD_TP"));	
			
			sql.setString(++i, (String)map.get("FILE_MK_DT"));
			sql.setString(++i, (String)map.get("CARD_BIZCO_NO"));		  
			sql.setString(++i, (String)map.get("FC_BIZCO_NO"));	         
			sql.setString(++i, (String)map.get("RECPT_DT_FR"));	 
			sql.setString(++i, (String)map.get("RECPT_DT_TO"));
			
			sql.setString(++i, (String)map.get("DPST_DT"));
			sql.setString(++i, (String)map.get("FC_NO"));
			sql.setString(++i, (String)map.get("CURCY_CD"));
			sql.setString(++i, (String)map.get("VAN_SVC_TP"));
			sql.setString(++i, (String)map.get("SALE_DT_FR"));
			
			sql.setString(++i, (String)map.get("SALE_DT_TO"));
			sql.setString(++i, (String)map.get("REQ_DT"));
			sql.setString(++i, (String)map.get("VAN_BUY_CORP_CD"));					
									
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISDAILYDTL_REP_S]" + sql.debug() );
			map.put("ERR_INFO", e.getMessage());
			sql.close();
			sql.clearParameter();	
			
		}finally {
			//transaction 종료
			end();
		}		
		return rows;
	}
	

	public int  insKISDailyDTL_REP_D    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;						
		
		if ( (map.get("RECORD_TP").equals("60"))||(map.get("RECORD_TP").equals("61"))||
				(map.get("RECORD_TP").equals("62"))||(map.get("RECORD_TP").equals("63"))){
			map.put("TRN_TP", "AC") ; 
		}
		else if( (map.get("RECORD_TP").equals("64"))||(map.get("RECORD_TP").equals("65"))||
				(map.get("RECORD_TP").equals("66"))||(map.get("RECORD_TP").equals("67"))){
			map.put("TRN_TP", "RR") ; 
		}
		
		String zeroPad = "0000000000";
		String auth_amt = zeroPad.substring(map.get("AUTH_AMT").length()) + map.get("AUTH_AMT");
		
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속) padding
			connect("CMGNS");			

			sql.put(findQuery("service-sql", "INS_KISDAILYDTL_REP_D"));			
                    
			sql.setString(++i, (String)map.get("VAN_CD"));		  //VAN코드(KIS,NICE,KICC)          		  
			sql.setString(++i, (String)map.get("FILE_DT"));
			sql.setString(++i, (String)map.get("HT_SEQ"));
			sql.setString(++i, (String)map.get("RECORD_TP"));		  
			sql.setString(++i, (String)map.get("CURCY_CD"));
			sql.setString(++i, (String)map.get("CURCY_IDX"));		  
			sql.setString(++i, (String)map.get("AUTH_DT"));	         
			sql.setString(++i, (String)map.get("RECPT_DT"));	 
			sql.setString(++i, (String)map.get("CARD_DATA"));
			sql.setString(++i, (String)map.get("INST_TERM"));
			sql.setString(++i, (String)map.get("AUTH_AMT"));
			sql.setString(++i, (String)map.get("CARD_RTN_CD"));
			sql.setString(++i, (String)map.get("VAN_RTN_CD"));
			sql.setString(++i, (String)map.get("NOT_USED"));
			sql.setString(++i, (String)map.get("CARD_FEE"));
			sql.setString(++i, (String)map.get("RTN_MSG"));
			//logger.info("[TRN_UNIQ_SEQ]=[" + map.get("TRN_UNIQ_SEQ") + "]");
			if ((map.get("TRN_UNIQ_SEQ").equals("            "))){
				//공백(BC카드)인경우 TID+CARD_DATA+TRN_TP+AUTH_DT+AUTH_NO+AUTH_AMT) 
				//주의: TRN_TP는 RECORD_TP CASE별로 TLF값(AC/RR)
				sql.setString(++i,(String)map.get("TID") + (String)map.get("CARD_DATA") 
								+ (String)map.get("TRN_TP")+(String)map.get("AUTH_DT") 
								+(String)map.get("AUTH_NO")	+auth_amt );
								logger.info("[BC TRN_UNIQ_SEQ]=[" + (String)map.get("TID") + (String)map.get("CARD_DATA") 
										+ (String)map.get("TRN_TP")+(String)map.get("AUTH_DT") 
										+(String)map.get("AUTH_NO")	+auth_amt  + "]");
			}else {
				sql.setString(++i, (String)map.get("TRN_UNIQ_SEQ"));				
			}
         
			sql.setString(++i, (String)map.get("TID"));
			sql.setString(++i, (String)map.get("AUTH_NO"));
			sql.setString(++i, (String)map.get("VAN_TP"));			
									
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISDAILYDTL_REP_S]" + sql.debug() );
			map.put("ERR_INFO", e.getMessage());
			sql.close();
			sql.clearParameter();	
			
		}finally {
			//transaction 종료
			end();
		}		
		return rows;
	}
	

	public int  insKISDailyDTL_REP_T    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			

			sql.put(findQuery("service-sql", "INS_KISDAILYDTL_REP_T"));			
                    
			sql.setString(++i, (String)map.get("VAN_CD"));		  //VAN코드(KIS,NICE,KICC)          		  
			sql.setString(++i, (String)map.get("FILE_DT"));
			sql.setString(++i, (String)map.get("HT_SEQ"));
			sql.setString(++i, (String)map.get("RECORD_TP"));		  
			sql.setString(++i, (String)map.get("RECPT_CNT"));
			sql.setString(++i, (String)map.get("RECPT_AMT"));		  
			sql.setString(++i, (String)map.get("RTN_CNT"));	         
			sql.setString(++i, (String)map.get("RTN_AMT"));	 
			sql.setString(++i, (String)map.get("HOLD_CNT"));
			sql.setString(++i, (String)map.get("HOLD_AMT"));
			sql.setString(++i, (String)map.get("HOLD_OFF_CNT"));
			sql.setString(++i, (String)map.get("HOLD_OFF_AMT"));
			sql.setString(++i, (String)map.get("TOT_CNT"));
			sql.setString(++i, (String)map.get("TOT_AMT"));
			sql.setString(++i, (String)map.get("TOT_FEE"));
			sql.setString(++i, (String)map.get("DPST_AMT"));
			sql.setString(++i, (String)map.get("ACCT_NO"));         
									
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISDAILYDTL_REP_S]" + sql.debug() );
			map.put("ERR_INFO", e.getMessage());
			sql.close();
			sql.clearParameter();	
			
		}finally {
			//transaction 종료
			end();
		}		
		return rows;
	}
	

	public int  insKISDailyDTL_REP_E    (Map<String, String> map) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			//transaction 발생
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");			

			sql.put(findQuery("service-sql", "INS_KISDAILYDTL_REP_E"));			
                    
			sql.setString(++i, (String)map.get("VAN_CD"));		  //VAN코드(KIS,NICE,KICC)          		  
			sql.setString(++i, (String)map.get("FILE_DT"));		  
			sql.setString(++i, (String)map.get("RECORD_TP"));		  
			sql.setString(++i, (String)map.get("TOT_CNT"));
									
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			logger.info("[SQL1][INS_KISDAILYDTL_REP_S]" + sql.debug() );
			map.put("ERR_INFO", e.getMessage());
			sql.close();
			sql.clearParameter();	
		}finally {
			//transaction 종료
			end();
		}		
		return rows;
	}
	
	
	
	/***************************************************************************
	 * procCardTLFDatMap(신용카드 거래내역 데이터 매핑) 
	 * 					PR_HQ_CARDTLF_DAT_MAP
	 * @param map
	 * @param df
	 * @return ret
	 * @throws Exception
	 */
	public int procCardTLFDatMap(Map<String, String> map) throws Exception {
   		ProcedureWrapper proc = new ProcedureWrapper();
		int i = 0;
		int ret = 0;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");

			proc.put("CMBO.PR_HQ_CARDTLF_DAT_MAP", 6);
			proc.setString(++i, "1002");	// 회사코드
			proc.setString(++i, (String)map.get("VAN_CD"));	// van_cd
			proc.setString(++i, (String)map.get("FILE_DT"));	// file_dt
			proc.setString(++i, "cms_KISDTLDownloader");	// file_dt
			proc.registerOutParameter(++i, DataTypes.VARCHAR);	// 오류코드(0:정상, ~9:오류)
			proc.registerOutParameter(++i, DataTypes.VARCHAR);	// 처리결과 메시지
			
			ProcedureResultSet prs = super.executeUpdateProcedure(proc);

			String retCd = prs.getString(5);
			String retMsg = prs.getString(5);
			logger.info("[DEBUG] [procCardTLFDatMap] ResultMsg:" + retMsg);
			logger.info("[DEBUG] [procCardTLFDatMap] End");
		}catch(Exception e) {
			rollback();
			logger.info("procCardTLFDatMap exception"+ e.getMessage());
			ret = -1;
			SqlWrapper sql = new SqlWrapper();
			i = 0;						
			sql.put(findQuery("service-sql", "UPD_KISLOGGING_DATA_ERROR"));
			sql.setString(++i, e.getMessage());
			sql.setString(++i, (String)map.get("FILE_NM"));
			executeUpdate(sql);
			logger.info("[SQL1][UPD_KISLOGGING_DATA_ERROR]" + sql.debug() );
		}finally {
			end();
		}
		
		return ret;
	}
	
	
	
	
	
	/***************************************************************************
	 * procCardREPDatMap(신용카드 입반송내역 데이터 매핑) 
	 * 					PR_HQ_CARDTLF_DAT_MAP
	 * @param map
	 * @param df
	 * @return ret
	 * @throws Exception
	 */
	public int procCardREPDatMap(Map<String, String> map) throws Exception {
   		ProcedureWrapper proc = new ProcedureWrapper();
		int i = 0;
		int ret = 0;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			proc.put("CMBO.PR_HQ_CARDREP_DAT_MAP", 6);
			proc.setString(++i, "1002");	// 회사코드
			proc.setString(++i, (String)map.get("VAN_CD"));	// van_cd
			proc.setString(++i, (String)map.get("FILE_DT"));	// file_dt
			proc.setString(++i, "cms_KISDTLDownloader");	// file_dt
			proc.registerOutParameter(++i, DataTypes.VARCHAR);	// 오류코드(0:정상, ~9:오류)
			proc.registerOutParameter(++i, DataTypes.VARCHAR);	// 처리결과 메시지
			
			ProcedureResultSet prs = super.executeUpdateProcedure(proc);
			
			String retCd = prs.getString(5);
			String retMsg = prs.getString(5);
			logger.info("[DEBUG] [procCardREPDatMap] ResultMsg:" + retMsg);
			logger.info("[DEBUG] [procCardREPDatMap] End");
		}catch(Exception e) {
			rollback();
			logger.info("procCardREPDatMap exception"+ e.getMessage());
			ret = -1;
			SqlWrapper sql = new SqlWrapper();
			i = 0;		
			sql.put(findQuery("service-sql", "UPD_KISLOGGING_DATA_ERROR"));
			sql.setString(++i, e.getMessage());
			sql.setString(++i, (String)map.get("FILE_NM"));
			executeUpdate(sql);
			logger.info("[SQL1][UPD_KISLOGGING_DATA_ERROR]" + sql.debug() );
			
		}finally {
			end();
		}
		
		return ret;
	}
	
	
	/***************************************************************************
	 * procKACAOTLFDatMap(카카오페이 거래내역 데이터 이관 및 삭제 ) 
	 * 					PR_HQ_CARDTLF_DAT_MAP
	 * @param map
	 * @param df
	 * @return ret
	 * @throws Exception
	 */
	public int procKAKAOPAYTLFDatMap(Map<String, String> map) throws Exception {
   		
		// 이걸 호출 할때는 이미 카카오페이 거래 내역이 등록 된 상황에서 실행해야 함.
		// 한번만 처리 하면 끝. 그 이후에는 조회되지 않음으로 처리 안됨.
		ProcedureWrapper proc = new ProcedureWrapper();
   		
		int i = 0;
		int ret = 0;
		String vanCd = (String)map.get("VAN_CD");
		// KICC가 아닌경우에도 실행 해야 함. 그래서 로그를 확인해서 처리 해야 할듯.
		// 현재 KIS 인 경우가 최종으로 처리 되기 때문에 이때에 실행하도록 함.
		// 처리 로그 확인 뒤에 처리 하도록 변경 필요. 최종 작업 완료 후에 처리 하도록.
		if ( vanCd.equals("KIS") )
		{
			try {
		
				begin();
				
				//DB Connection(DB 접속)
				connect("CMGNS");
	
				proc.put("CMPS.PR_HQ_KAKAOREP_DAT_MAP", 6);
				proc.setString(++i, "1002");	// 회사코드
				proc.setString(++i, "KICC");	
				proc.setString(++i, (String)map.get("FILE_DT"));	// file_dt
				proc.setString(++i, "cms_KISDTLDownloader");	
				proc.registerOutParameter(++i, DataTypes.VARCHAR);	// 오류코드(0:정상, ~9:오류)
				proc.registerOutParameter(++i, DataTypes.VARCHAR);	// 처리결과 메시지
	
				ProcedureResultSet prs = super.executeUpdateProcedure(proc);
				
				String retCd = prs.getString(5);
				String retMsg = prs.getString(400);
				ret = 0;
				logger.info("[DEBUG] [procKAKAOPAYTLFDatMap] ResultMsg:" + retMsg);
				logger.info("[DEBUG] [procKAKAOPAYTLFDatMap] End");
				
			}catch(Exception e) {
				rollback();
				logger.info("procKAKAOPAYTLFDatMap exception"+ e.getMessage());
			}finally {
				end();
			}
		}
		
		return ret;
	}
	
}