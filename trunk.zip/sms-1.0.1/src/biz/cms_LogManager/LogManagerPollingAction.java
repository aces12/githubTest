package biz.cms_LogManager;

import java.util.Calendar;
import java.util.Locale;
import java.io.File;
import java.lang.Math;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.daemon.core.CurrentContext;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;

public class LogManagerPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(LogManagerPollingAction.class);
	private static DaemonConfigLocator locator = null;
	private static boolean bProcessing = false;
	
	@Override
	public void execute(String actionMode) {
		// TODO Auto-generated method stub
		try {
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if (actionMode == "1") {
				
				if( bProcessing ) {
					return;
				}
				bProcessing = true;
				
				LogManagerPollingAction action = new LogManagerPollingAction();
				
				String logPath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");
				String xmlPath = PropertyUtil.findProperty("stsys-property", "SMS_ROOT");
				//logPath = logPath + "\\workspace\\logs\\sms";
				logPath = logPath + File.separator + "logs" + File.separator + "sms";
				//xmlPath = xmlPath + "\\xml\\daemon-config.xml";
				xmlPath = xmlPath + File.separator + "xml" + File.separator + "daemon-config.xml";
				
				File f = new File(logPath);
				File[] files = f.listFiles();
				
				String fileCreatedDate;
				
				if( locator == null ) {
					locator = DaemonConfigLocator.getInstance("xml", xmlPath);
					locator.setCurrentContext(new CurrentContext(locator.getDaemonConfig()
							.getNode().getEngineContainer("cms_LogManager")));
				}
				
				int iKeepForDays;
				
				try {
					iKeepForDays = Integer.parseInt(locator.getCurrentContext().getContext().getEngineAttribute().getAttribute("KeepForDays").getValue());
				}catch( NumberFormatException e ) {
					logger.info("NumberFormatException : System set default value(10days).");
					iKeepForDays = 10;
				}
				
				iKeepForDays = (iKeepForDays == 0 ? 1 : iKeepForDays);
				
				String stdDate = getFormattedDateAgoDays(iKeepForDays);
				int beginIdx = 0;
				int endIdx = 0;
				
				logger.info("Standard Date : [" + stdDate + "]");
				
				for(int i = 0;i < files.length;i++) {
					if( !files[i].isDirectory() ) {
						beginIdx = (files[i].getName()).indexOf(".") + 1;
						endIdx = (files[i].getName()).lastIndexOf(".");
						if( beginIdx >= endIdx )
						{
							continue;
						}
						fileCreatedDate = (files[i].getName()).substring(beginIdx, endIdx);
						if( fileCreatedDate.compareTo(stdDate) < 0 ) {
							logger.info("Deleted File : " + files[i].getName());
							files[i].delete();
						}
					}
				}
			}			
		}catch(Exception e) {
			logger.info("Log Manager Exception : " + e.getMessage());
		}finally {
			bProcessing = false;
		}
	}
	
	private String getFormattedDateAgoDays(int days) {

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1 * Math.abs(days));
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
		String formattedDate = sdf.format(cal.getTime());

		return formattedDate;
	}

}
