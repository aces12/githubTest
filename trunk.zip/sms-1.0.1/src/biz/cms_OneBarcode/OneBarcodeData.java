package biz.cms_OneBarcode;

public class OneBarcodeData {
	static String INQ_TYPE_REQ = "G3";		// G3 쿠폰발행 요청전문
	static final int nlens[] = {5, 2, 64, 16, 1};
	static final String strHeaders[] = {
		    "LEN",						// 받는 전문 길이
			"RESP_CD",					// 응답코드   "00":정상, "99":에러
			"RESP_MSG",					// 응답메세지(에러메세지)
			"KT_MEMBER_NO",				// KT 카드 번호
			"KT_MEMBER_YN"				// KT 카드 번호 사용 여부  "Y":사용, "N":미사용
		};
	
}
