/*
 * DeployClientActionSocket.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_DeployReq;

import java.util.Map;

import kr.fujitsu.com.ffw.daemon.net.client.ClientActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;

import org.apache.log4j.Logger;
import biz.comm.COMMBiz;

/** 
 * DeployClientActionSocket
 * A class that has inherited ClientActionSocket(ClientActionSocket을 상속받은 클래스)
 * A class responsible for actual deployment(실제 배신을 담당하는 클래스)
 * Send deployment message to the stores with generated socket, and get responses to update the response status data on DB(생성된 소켓으로 점포에 배신전문을 내려주고, 응답을 받아 응답상태값을 DB에 업데이트 한다).
 * @created  on 1.0,  11/03/17
 * @created  by khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by 
 */ 
public class DeployReqClientActionSocket  extends ClientActionSocket {
	private static Logger logger = Logger.getLogger(DeployReqClientActionSocket.class);
	
	/**
	 * DeployClientActionSocket - Deployment(배신)
	 * @param ip : Store IP(점포 IP)
	 * @param port : Communication port(통신 port)
	 * @param filter : Message filter(전문 filter)
	 * @throws Exception
	 */
	public DeployReqClientActionSocket(String ip, int port, Filter filter) 
			throws Exception {	
		
		super(ip, port, filter);
	}
	
	/**
	 * Communication Module(통신 모듈)
	 * Access the store server to send/receive message(점포 서버와 접속해서 메시지를 주고 받는다)
	 */
	public void justDoIt() {
		// Get map generated in DeployClientAction(DeployClientAction에서 생성했던 map 불러오기)
		Map map = getUserMap();	
		DeployReqDAO dao   = new DeployReqDAO();
		int ret = 0;
		// Print store code, IP, port and message to be deployed(배신할 점포코드, IP, PORT 메시지 로그찍기)
		logger.info((String)map.get("com_cd")+":::"+(String)map.get("store_cd")+":::"+getIp()+"::::"+getPort()+"::::"+(String)map.get("message"));
		
		try {
			if (isConnectionException() != null) {
				// Be sure to handle with communication error(통신 접속 에러 처리 할 것)
				map.put("oper_id", "C");	// C : connection-error code
				// DB Update - Correct Deployment status value(DB 업데이트 - 배신 상태값 수정)
				ret = dao.updSTBDA100AT(map);
				// Print message send error(메시지 전송 에러 로그찍기)
				logger.info("ERROR(sendDeploy) : " + isConnectionException());
			} else {
				// 통신 접속이 되면 메시지 전송
				logger.info( "★★★★★ send==============>");
				logger.info( "★★★★★ send==============>"+(String) map.get("message"));
				// When communication is connected, send message(통신 접속이 되면 메시지 전송)
				System.out.println("[DEBUG][send]::["+(String)map.get("message")+"]");
				send((String) map.get("message"));
				// Receive Message(메시지 수신)
				System.out.println("[DEBUG][recv]::[waiting...]");
				String receiveMessage = (String)receive();
				// Print receive message(수신 메시지 로그찍기)
				System.out.println("[DEBUG][recv]::["+receiveMessage+"]");
				logger.info( "★★★★★  Recveive==============>"+receiveMessage);
				// Print message sending success(메시지 전송 성공 로그찍기)
				logger.info( "Recveive successful(" + receiveMessage + ")");
				
				// Header length check.
				// If header length of the received message is 50byte or less, print error log(수신받은 전문의 헤더길이가50Byte이하이면 에러처리 로그찍기)
				if(receiveMessage.length() < COMMBiz.CM_LENS) {
					// DB Update - Correct Deployment status value(DB 업데이트 - 배신 상태값 수정)
					map.put("oper_id", "C");	// C : connection-error code
					logger.info( "[ERROR] (sendDeploy) : recveive failed(" + Integer.toString(receiveMessage.length()) + ")");
				} else {
					map.put("oper_id", "D");	// D : deploy successful
					ret = dao.updSTBDA100AT(map);
				}
				// Add receive message to map generated in DeployClientAction(DeployClientAction에서 생성했던  map에 수신 메시지 담기)
				map.put("receiveMessage", receiveMessage);
			}
		} catch (Exception e) {
			logger.info("[ERROR]"+e);
			map.put("oper_id", "C");	// C : connection-error code
			ret = dao.updSTBDA100AT(map);
		}
	}
}
