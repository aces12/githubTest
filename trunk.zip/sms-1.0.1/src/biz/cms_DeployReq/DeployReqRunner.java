/*
 * MasterRunner.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_DeployReq;

import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.node.EngineContainer;
import kr.fujitsu.com.ffw.daemon.net.client.ClientActionSocket;

import org.apache.log4j.Logger;

import biz.comm.COMMHeaderFilter;

/** 
 * MasterRunner
 * Identify method to generate file according to deliminator of the master file(마스터 파일의 구분자에 따라 파일 생성하는 방식을 구분한다).
 * Call MasterExcutor(MasterExcutor를 호출)
 * @created  on 1.0,  11/03/17
 * @created  ok(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by  
 */ 
public class DeployReqRunner extends Thread {
	private static Logger logger = Logger.getLogger(DeployReqRunner.class);
	
	private DeployReqClientAction action = null;
	private Map map = null;
	
	/**
	 * Create MasterRunner(MasterRunner 생성)
	 * @param action
	 */
	public DeployReqRunner(DeployReqClientAction action) {
		this.action = action;
	}

	/**
	 * Set Map value transferred from MasterAction(MasterClientAction에서 넘어온 Map 값 셋팅) 
	 * @param map
	 */
	public void setMap(Map map) {
		this.map = map;
	}	
	

	/**
	 * Execute Generation of Deployment File(배신 파일 생성 실행)
	 */
	public void run(){
		try {
			// TODO Auto-generated method stub
			int ret = -1;
			ClientActionSocket uca = null;
			
			// thread +
			action.msControl.useThread();
			
			// Create socket per store(점포별 소켓 생성) 
			logger.info("<<-1 store_ip: " + (String)map.get("store_ip"));
			logger.info("<<-2 port: " + action.getPort());
						
			uca = new DeployReqClientActionSocket((String)map.get("store_ip"), action.getPort(), new COMMHeaderFilter());

			// Add date to be used to Map(사용할 데이터 맵에 담기)
			uca.setUserMap("trans_ymd", (String)map.get("trans_ymd"));
			uca.setUserMap("store_cd" , (String)map.get("store_cd"));
			uca.setUserMap("trans_id" , (String)map.get("trans_id"));
			uca.setUserMap("trans_seq", (String)map.get("trans_seq"));
			uca.setUserMap("message"  , (String)map.get("message"));
			// Define works to be carried out after sending data(데이터 전송 후 수행할 작업 정의)
			uca.justDoIt();
			// Add socket(소캣 담기)
			
			//EngineContainer context = action.getLocator().getDaemonConfig().getNode().getEngineContainer("cms_DeployReq");

			//action.setContext(context);
			action.addClientActionSocket(uca);
			
			action.dispatch();
			action.msControl.returnThread();
			action.workIncrement();	
			
			
			if (action.getDelay() > 0)
				sleep(action.getDelay());
			
			//System.out.println("________________WORK: " +  action.getWork());
			
			if (action.getStatus()) {
				logger.info("**************************   The end" );
			}
			
		} catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
	}
	
}
