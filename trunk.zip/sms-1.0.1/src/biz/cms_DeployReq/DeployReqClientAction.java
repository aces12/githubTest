/*
 * DeployClientAction.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_DeployReq;

import java.util.Date;
import java.util.List;
import java.util.Map;

import kr.fujitsu.com.ffw.daemon.core.CurrentContext;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.node.EngineContainer;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.DaemonContainer;
import kr.fujitsu.com.ffw.daemon.net.client.ActionClientContainer;
import kr.fujitsu.com.ffw.daemon.net.client.ClientAction;
import kr.fujitsu.com.ffw.daemon.net.client.ClientActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ActionServerContainer;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.cms_MasterCrt.MasterCrtClientAction;
import biz.cms_MasterCrt.MasterCrtControl;
import biz.cms_MasterCrt.MasterCrtRunner;
import biz.comm.COMMHeaderFilter;

/** 
 * DeployClientAction
 * A class that has inherited ClientAction(ClientAction을 상속받은 클래스)
 * Search stores to be subject to deployment to generate socket and make a message to be deployed(배신대상 점포를 조회하여 소켓을 생성하고, 배신할 전문을 만든다). 
 * @created  on 1.0,  11/03/17
 * @created  by khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by 
 */ 
public class DeployReqClientAction extends ClientAction {
	private static Logger logger = Logger.getLogger(DeployReqClientAction.class);
	protected String ftp_server_ip = null;
	private int port = 8001;
	
	public static DeployReqControl msControl = new DeployReqControl();
	private static int totalCount=0;
	private static int jobThread=0;
	private static int work=0;
	private int maxThread=0;
	private String transYmd="";
	private String transID="";
	private String comcd="";
	private String store="";
	private static DaemonConfigLocator locator=null;
	private int delay=0;
	private String path="";
	
	public void setLocator(DaemonConfigLocator locator){
		this.locator = locator;
	}
	
	public DaemonConfigLocator getLocator(){
		return this.locator;
	}
	public static void increment(){
		jobThread++;
	}

	public static void decrement(){
		jobThread--;
	}	

	public static void workIncrement(){
		++work;
	}
	
	public static int getJobThread(){
		return jobThread;
	}

	public static boolean getStatus(){
		if (work==totalCount) return true;
		return false;
	}
	
	public int getPort(){
		return port;
	}
	public int getDelay(){
		return delay;
	}
	
	public void setDelay(int delay){
		this.delay = delay;
	}

	public void setMaxThread(int maxThread){
		this.maxThread = maxThread;
		this.jobThread = maxThread;
	}
	public String getTransYmd(){
		return transYmd;
	}
	public void setTransYmd(String ymd){
		this.transYmd = ymd;
	}
	public String getTransID(){
		return transID;
	}
	public void setTransID(String transID){
		this.transID = transID;
	}
	public String getComcd(){
		return comcd;
	}
	public void setComcd(String comcd){
		this.comcd = comcd;
	}
	public String getStore(){
		return store;
	}
	public void setStore(String store){
		this.store = store;
	}
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	public String getPath(){
		return path;
	}
	public void setPath(String path){
		this.path = path;
	}
	
	public static void main(String args[]) throws Exception {
		DeployReqClientAction da = new DeployReqClientAction();
		
		logger.info("[ Deploy main ]--------------------------------------");
		if (args == null || args.length < 1) {
			logger.info("------ deploy main args null");
		}
		
		String containerName = nvl(args[0]);
		String thread_max    = nvl(args[1].replaceFirst("-tm:"   ,""));
		String trans_ymd     = nvl(args[2].replaceFirst("-ty:"   ,""));
		String comcd         = nvl(args[3].replaceFirst("-com"   ,""));
		String store         = nvl(args[4].replaceFirst("-store:",""));
		String trans_id      = nvl(args[5].replaceFirst("-id:"   ,""));
		String delay_tm      = nvl(args[6].replaceFirst("-delay:",""));
		String path          = nvl(args[7].replaceFirst("-path:" ,""));	
		
		//jobthread ==> thread_Max
		if (thread_max.equals("")) thread_max = "1";
		da.setMaxThread(Integer.parseInt(thread_max));
		
		//delay time
		if (delay_tm.equals("")) delay_tm = "0";
		da.setDelay(Integer.parseInt(delay_tm));
		
		//comcd
		if (comcd.equals("")) comcd = "%";
		da.setComcd(comcd);
		
		//store
		if (store.equals("")) store = "%";
		da.setStore(store);
		
		//transID
		if (trans_id.equals("")) {
			System.out.println("error trans_ID[" + trans_id + "]");
			logger.error("error trans_ID[" + trans_id + "]");
			return;
		}
		da.setTransID(trans_id);
		
		//trans_ymd
		if (trans_ymd.equals("")) {
			Date now = new Date();
			trans_ymd = StringUtil.getDataFormat(now, "yyyyMMdd");
		}
		da.setTransYmd(trans_ymd);
		da.setPath(path);
		System.out.println(containerName);
		
		
		locator = DaemonConfigLocator.getInstance("xml",da.getPath());
		locator.setCurrentContext(new CurrentContext(locator.getDaemonConfig()
				.getNode().getEngineContainer("cms_DeployReq")));
		
		//DaemonContainer container = new ActionClientContainer(locator.getCurrentContext().getContext());
		//Thread t = new Thread(container);
		//t.start();      
		da.execute();
		
	}
	
	
	public void execute() {
		DeployReqDAO dao = null;
		List list = null;

		try {
			logger.info("--deploy execute--");
			
			if (locator == null) {
				locator = DaemonConfigLocator.getInstance("xml",getPath());
				locator.setCurrentContext(new CurrentContext(locator.getDaemonConfig()
						.getNode().getEngineContainer("cms_DeployReq")));
			}
			EngineContainer context = getLocator().getDaemonConfig().getNode().getEngineContainer("cms_DeployReq");
			setContext(context);
			
			logger.info("thread_max:" + getJobThread());
			logger.info("trans_ymd:"  + getTransYmd());
			logger.info("comcd:"      + getComcd());
			logger.info("store:"      + getStore());
			logger.info("trans_id:"   + getTransID());
			logger.info("delay_time:" + getDelay());
			
			dao  =  new DeployReqDAO();
			list = dao.selSTBDA100AT(getTransYmd(), getComcd(), getStore(), getTransID());
			
			logger.info("list count: " + list.size());
			
			// Get deployment port from setup file(배신 포트를 설정파일에서 가져옴)
			if(!PropertyUtil.findProperty("stsys-property", "DEPLOY_PORT").equals("") || PropertyUtil.findProperty("stsys-property", "DEPLOY_PORT") != null) {
				this.port = Integer.parseInt(PropertyUtil.findProperty("stsys-property", "DEPLOY_PORT"));
			}

			// Get FTP Server IP fro setup file(FTP Server IP를 설정파일에서 가져옴)
			this.ftp_server_ip = PropertyUtil.findProperty("stsys-property", "FTP_SERVER_IP");

			// If there is no subjective store, print log(대상 점포가 없으면 로그찍기)
			if(list.size() < 1) {
				logger.info("There is no data.");
			}

			// Search subjects to deployment(배신대상 조회)
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
				// Execut Deployment(배신 실행)
				deploy(map);
				
				// Create thread(쓰레드 생성)
				DeployReqRunner ms = new DeployReqRunner(this);
				// Transfer map(map을 넘겨 줌)
				ms.setMap(map);
				// Execute thread(쓰레드 실행)
				ms.start();				
			}
		
			
		} catch (Exception e) {
			//logger.error("",e);
			logger.info("[ERROR]"+ e);
		}
	}
	
	// Execute Deployment(배신 실행)
	private void deploy(Map map) {
		String transId = (String)map.get("trans_id");	//Identify subject to deployment(배신 대상 구분)
		if(transId.equals("MSG")) {
			// In case of a message to be deployed, start Message Deploy Thread(배신 대상이 메시지일 경우  Message Deploy Thread 기동)
			map.put("message", deployMSG(map));
		} else {
			// In case of not a message to be deployed, start (PGM, MST, CUSTDSP, POSDLL, FFIMG) File Deploy Thread(배신 대상이 메시지가 아닐경우 (PGM, MST, POSDLL, FFIMG) File Deploy Thread 기동)
			map.put("message", deployFILE(map));
		}
	}
	
	/**
	 * deployMSG - Message Basic Processing(메시지 배신 처리)
	 * @param map
	 * @return String
	 */
	private String deployMSG(Map map) {
		// Print Message deployment start log(메시지 배신 시작 로그찍기)
		logger.info( "Store(" + (String)map.get("store_cd") + ") : Deploy message ... ");
		StringBuffer hbuf = new StringBuffer();		// Message Header(전문 헤더)
		StringBuffer sbuf = new StringBuffer();		// Message Text(전문본문)
		Date 	now       = new Date();
		DeployReqDAO dao  = new DeployReqDAO();

		try {
			// Message List Search(메시지 리스트 조회)
			List list = dao.selDeployMSG(map);
			
			// If there is no message list, print error log(메시지 리스트가 없으면 에러로그 찍기)
			if(list.size() < 1) {
				logger.info("[ERROR] : Message dosen't exists. send_id(" 
						+ (String)map.get("send_id")+ ") msg_cd(" + (String)map.get("msg_cd")+ ")");
				return "0";
			}
			
			// Generate Message Text(for seding message)(전문  본문 생성 ( 메시지전송용 ))
			Map ret = (Map) list.get(0);
			int len = Integer.parseInt((String)ret.get("msg_len"));		// Message Length(메시지 길이)
			StringUtil.appendSpace(sbuf, "05"                                      ,  2);				// inq_type
			StringUtil.appendSpace(sbuf, StringUtil.getDataFormat(now, "yyyyMMdd") ,  8);				// req_ymd
			StringUtil.appendSpace(sbuf, StringUtil.getDataFormat(now, "HHmmss")   ,  6);				// req_hms			
			StringUtil.appendSpace(sbuf, (String)map.get("store_cd")               ,  5);				// store_cd			
			StringUtil.appendSpace(sbuf, "0000"                                    ,  4);				// pos_no
			StringUtil.appendSpace(sbuf, (String)ret.get("msg_cd")                 , 10);				// msg_cd
			StringUtil.appendSpace(sbuf, (String)ret.get("urgent_yn")              ,  1);				// file_app_ty
			StringUtil.appendSpace(sbuf, (String)ret.get("pos_symdhms")            , 12);				// msg_post_symd
			StringUtil.appendSpace(sbuf, (String)ret.get("pos_eymdhms")            , 12);				// msg_post_eymd
			StringUtil.appendSpace(sbuf, StringUtil.getDataFormat(len, "000")      ,  3);				// msg_len
			StringUtil.appendSpace(sbuf, (String)ret.get("msg_title")              , len);				// msg_title
			
			// Print Message/message content(메시지 길이, 메시지 내용 로그찍기)
			logger.info("LEN===========>"+ sbuf.length() + "-----" 
					+ ret.get("msg_title").toString() + ":"+ ret.get("msg_title").toString().length());
			
			// Generate Message Header(전문헤더 생성)
		    hbuf = setHeader( sbuf.length(), 0, (String)map.get("store_cd"), "0000");
		    
		    // Message Header(전문 헤더) + Message Text(전문 본문)
		    hbuf.append(sbuf);
		    
		} catch (Exception e) {
			//logger.error("",e);
			logger.info("[ERROR]"+e);
		} 	
		// Return Message(전문리턴)
		return hbuf.toString();
	}
	
	/**
	 * deployFILE- File Deployment Locations (PGM, MST, POSDLL, FFIMG)(파일 배신 (PGM, MST, POSDLL, FFIMG) 처)
	 * @param map
	 * @return String
	 */
	private String deployFILE(Map map) {
		// Print Message deployment start log(메시지 배신 시작 로그찍기)
		logger.info( "Store(" + (String)map.get("store_cd") + ") : Deploy file ... "
				+ (String)map.get("trans_id") + ":" + (String)map.get("trans_file_dir"));
		
		StringBuffer hbuf = new StringBuffer();		// Message Header(전문 헤더)
		StringBuffer sbuf = new StringBuffer();		// Message Text(전문 본문)
		Date 	now = new Date();
		
		try {
		
			String fileDir  = (String)map.get("trans_file_dir");
			int dot         = fileDir.lastIndexOf("/");
			String fildKind = getFileCode((String)map.get("trans_id"));		// Get Deployment File Identifier Code(배신 파일 구분 코드 가져오기)
			
			// Generate Message Text(전문 본문 생성) (PGM, MST, POSDLL, FFIMG)
			StringUtil.appendSpace(sbuf, "03"                                      ,  2);				// inq_type
			StringUtil.appendSpace(sbuf, StringUtil.getDataFormat(now, "yyyyMMdd") ,  8);				// req_ymd
			StringUtil.appendSpace(sbuf, StringUtil.getDataFormat(now, "HHmmss")   ,  6);				// req_hms
			StringUtil.appendSpace(sbuf, (String)map.get("store_cd")               ,  5);				// store_cd
			StringUtil.appendSpace(sbuf, "0000"                                    ,  4);				// pos_no
			StringUtil.appendSpace(sbuf, fildKind                                  ,  2);				// file_kind
			StringUtil.appendSpace(sbuf, (String)map.get("urgent_yn")              ,  1);				// file_app_ty
			StringUtil.appendSpace(sbuf, (String)map.get("appl_ymdhms")            , 14);				// file_app_ymd
			StringUtil.appendSpace(sbuf, this.ftp_server_ip                        , 15);				// file_hq_ip
		    StringUtil.appendSpace(sbuf, fileDir.substring( 0, dot)                ,100);				// file_path
		    StringUtil.appendSpace(sbuf, fileDir.substring( dot+1)                 , 20);				// file_nm
		    StringUtil.appendSpace(sbuf, (String)map.get("trans_ver")              , 30);				// file_ver
			
		    System.out.println("LEN===========>"+ sbuf.length() + "-----" + (String)map.get("trans_ver") + "-----");

			// Generate Message Header(전문 헤더 생성)
		    hbuf = setHeader( sbuf.length(), 0, (String)map.get("store_cd"), "0000");
		    System.out.println(">>>>>>>>[HEADER]::[" + hbuf + "]");
		    System.out.println(">>>>>>>>[BODY]::[" + sbuf + "]");

		    // Message Header(전문 헤더) + Message Text(전문 본문)
		    hbuf.append(sbuf);
		    
		} catch (Exception e) {
			//logger.error("",e);
			logger.info("[ERROR]"+ e);
		} 
		// Return message(전문 리턴)
		return hbuf.toString();
	}
	
	/**
	 * getFileCode - Get File Code from Trans ID
	 * Get code value allocated to deployment file(배신 파일에 할당된 코드 값을 취득 한다).
	 * Be sure to manage it so as to be kept as same as the code mapping defined in sysinq module(sysinq 모듈에서 정의하고 있는 코드 매핑과 동일하게 유지될 수 있게 관리 할 것).
	 * @param trans_id
	 * @return
	 */
	protected String getFileCode( String trans_id) {

		String code;
		
		if ( trans_id.equals("PGM") ) {
			code = "01";
		} else if ( trans_id.equals("MST") ) {
			code = "02";
		} else if ( trans_id.equals("CUSTDSP") ) {
			code = "03";
		} else if ( trans_id.equals("FFIMG") ) {
			code = "04";
		} else if ( trans_id.equals("POSDLL") ) {
			code = "05";
		} else {
			logger.info("ERROR(getFileCode) : Trans ID(" + trans_id + ":" + trans_id.equals("CUSTDSP") + ")");
			code = "";
		}

		return code;
	}
	
	/**
	 * setHeader - Message Header Setting(전문헤더 셋팅)
	 * @param len : Length of Message Text(전문본문 길이)
	 * @param ret : 
	 * @param storeCd : Store Code(점포코드)
	 * @param posNo : POS Code(포스번호)
	 * @return StringBuffer : Message Header(전문헤더)
	 */
	protected StringBuffer setHeader( int len, int ret, String storeCd, String posNo) {
		StringBuffer sb = new StringBuffer();
		Date 	now = new Date();
		// Data Length Log(데이터 길이 로그)
		logger.info("*************LEN================>>>>>  "+len);
		StringUtil.appendSpace(sb, StringUtil.getDataFormat(len, "00000")    ,  5);				// datalen
		StringUtil.appendSpace(sb, "05"                                      ,  2);				// code
		StringUtil.appendSpace(sb, storeCd                                   ,  5);				// scno
		StringUtil.appendSpace(sb, posNo                                     ,  4);				// posno
		StringUtil.appendSpace(sb, "0000"                                    ,  4);				// tranno
		StringUtil.appendSpace(sb, StringUtil.getDataFormat(now, "yyyyMMdd") ,  8);				// saledt
		StringUtil.appendSpace(sb, StringUtil.getDataFormat(now, "yyyyMMdd") ,  8);				// date
	    StringUtil.appendSpace(sb, StringUtil.getDataFormat(now, "HHmmss")   ,  6);				// time
	    StringUtil.appendSpace(sb, StringUtil.getDataFormat(ret, "000")      ,  3);				// ret
	    
		return sb;
	}
}
