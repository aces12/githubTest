package biz.cms_CashBeeIrt;

import java.net.Socket;
import java.util.HashMap;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;

public class CashBeeIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(CashBeeIrtAction.class);
	
	private String server_ip = "";
	private int server_port = 0;
	
	/**
	 * Receive data from SC through 9015 PORT(SC로부터 데이타를 9015 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(ActionSocket actionSocket) throws Exception {
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		CashBeeIrtProtocol protocol = new CashBeeIrtProtocol();
		COMMLog df = new COMMLog();
		
		Socket extClntSock = null;
		CashBeeIrtConveyer conveyer = null;
		this.server_ip = PropertyUtil.findProperty("communication-property", "CASHBEE_COMM_IP");
		this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "CASHBEE_COMM_PORT"));
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress()
					.getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,
					"CashBeeIRT");
			
			df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지
			// 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}
			
			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			inq_type = protocol.getRcvCashBeeIrtDATA(rcvDataBuf);
			switch( inq_type ) {
				// 캐시비 단말기 설치 요청 전문
				case 43:
					df.execute("CashBeeIrt-TMNLINSTALL");
					hmData = protocol.getParseCashBeeTMNLINSTALLInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new CashBeeIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getCashBeeTMNLINSTALLInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 캐시비 실시간 지불데이터 송신 전문
				case 44:
					df.execute("CashBeeIrt-RTPaymentSnd");
					hmData = protocol.getParseCashBeeRTPaymentSnd(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new CashBeeIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getCashBeeRTPaymentSnd(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 캐시비 충전/지불취소/환불 요청 전문
				case 45:
					df.execute("CashBeeIrt-CHRGInq");
					hmData = protocol.getParseCashBeeCHRGInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new CashBeeIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getCashBeeCHRGInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 캐시비 충전/지불취소 완료 요청 전문(결과/실패)
				case 46:
					df.execute("CashBeeIrt-CHRGCompletedInq");
					hmData = protocol.getParseCashBeeCHRGCompletedInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new CashBeeIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getCashBeeCHRGCompletedInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				
				// 캐시비 환불 완료 요청 전문
				case 47:
					df.execute("CashBeeIrt-RFNDCompletedInq");
					hmData = protocol.getParseCashBeeRFNDCompletedInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new CashBeeIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getCashBeeRFNDCompletedInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 캐시비 충전취소 요청
				case 48:
					df.execute("CashBeeIrt-CHRGCancelInq");
					hmData = protocol.getParseCashBeeCHRGCancelInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new CashBeeIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getCashBeeCHRGCancelInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
				// 캐시비 충전취소 완료 요청
				case 49:
					df.execute("CashBeeIrt-CHRGCnclCompltedInq");
					hmData = protocol.getParseCashBeeCHRGCnclCompltedInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new CashBeeIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getCashBeeCHRGCnclCompletedInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
					// 캐시비 예치금 확인 요청 전문
				case 50:
					df.execute("CashBeeIrt-CHKPPAMT");
					hmData = protocol.getParseCashBeeCHKPPAMTInq(rcvDataBuf);
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new CashBeeIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getCashBeeCHKPPAMTInq(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
			}
		}catch(Exception e) {
			ret = 29;
			retValue = "[ERROR]2:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			if( extClntSock != null ) {
				extClntSock.close();
			}
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + totalMsg + "]");
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(totalMsg)) {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		}catch(Exception e) {
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("CashBeeIRT", retValue);
		}
	}
}