package biz.cms_CashBeeIrt;

import java.util.HashMap;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;

public class CashBeeIrtProtocol {
	private static Logger logger = Logger.getLogger(CashBeeIrtAction.class);
	
	public int getRcvCashBeeIrtDATA(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int ret = 0;
		int nlens[] = {2};
		
		String strHeaders[] = {
			"INQ_TYPE"		// INQ Type(INQ 종별)
		};
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if( Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE")) ) {
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		
		return ret;
	}
	
	// 캐시비에서 보낸 충전취소 결과 전송 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGCnclResultRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,2,2,10,10,10
					  ,16,8,16,8,6
					  ,10,8,23};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
								
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
								
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDEP",
			"NTEP",
			
			"IDCENTER",
			"ALGEP",
			"MLDA",
			"BALEP",
			"NT_CARDLSAM",
			
			"IDLSAM",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"SIGN2_VAL",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCnclResultRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// 캐시비에서 보낸 충전취소 실패 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGCnclFailRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,8,10,16,8,6
					  ,10,1,70};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
									
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
									
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
				
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDLSAM",
			"NT_CARDLSAM",
			
			"SIGN2_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"DEAL_RESULT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCnclFailRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 충전취소 완료 요청 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGCnclCompltedInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,8,6
					  ,10,8,20,10,10
					  ,10,1,10,4,16
					  ,10,2,2,10,10
					  ,16,10,10,8,16
					  ,8,6,10,8,6
					  ,1};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"ADJT_YMD",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDEP",
			
			"NTEP",
			"IDCENTER",
			"ALGEP",
			"MLDA",
			"NT_CARDLSAM",
			
			"IDLSAM",
			"NTSAM",
			"BALEP",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			"DEAL_SNO",
			"SIGN2_VAL",
			"EVT_CHRG_AMT",
			
			"DEAL_RESULT"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCnclCompltedInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// 캐시비에서 보낸 충전취소 요청 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGCancelRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
				  	  ,1,10,4,16,10
				  	  ,8,10,16,8,6
				  	  ,10,6,65};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
							
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
							
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDSAM",
			"NT_CARDLSAM",
			
			"SIGN2",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"EVT_CHRG_AMT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCancelRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 충전취소 요청 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGCancelInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,8,6
					  ,10,8,20,10,10
					  ,10,1,10,4,2
					  ,10,2,16,10,16
					  ,16,10,10,8,8
					  ,16,14,8};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"ADJT_YMD",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"ALGEP",
			
			"BALEP",
			"IDCENTER",
			"IDEP",
			"NTEP",
			"REP",
			
			"BEF_IDSAM",
			"BEF_MLDA",
			"BEF_NTEP",
			"SIGN1_VAL",
			"RFU",
			
			"L_MEMBER_NO",
			"ODEAL_CHRG_YMDHMS",
			"ODEAL_CHRG_SIGN2"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCancelInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 실시간 지불데이터 송신 전문 파싱
	public HashMap<String, String> getParseCashBeeRTPaymentSnd(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,10,2
					  ,16,20,10,3,14
					  ,10,10,10,10,10
					  ,2,1,4,16,1
					  ,3,4,10,10,10
					  ,2,2,10,10,14
					  ,7,16,5,5,10
					  ,2,10,10,10,8
					  ,1,1,2};
		String strHeaders[] = {
			"INQ_TYPE",
			"COMMAND_TY",
			"MEMBER_ID",
			"SNO",
			"SAM_FLAG",
			
			"SAM_ID",
			"CARD_NO",
			"CARD_TRAN_SNO",
			"WORK_FLAG",
			"PAY_YMDHMS",
			
			"PAY_BEF_RAMT",
			"PAY_REQ_AMT",
			"PAY_AFT_RAMT",
			"PAY_BEF_SAM_RAMT",
			"PAY_AFT_SAM_RAMT",
			
			"CARD_FLAG",
			"PAY_FLAG",
			"MEMCARD_EXP_DATE",
			"MEMCARD_NO",
			"FIRST_CHRG_FLAG",
			
			"RFU",
			"PAY_FEE_RATE",
			"PAY_FEE_AMT",
			"SAM_DEAL_SNO",
			"SAM_DEAL_CNT",
			
			"SAM_ALGM_ID",
			"SAM_KEYSET_VER",
			"CARD_DEPOSIT",
			"PENALTY_AMT",
			"CHRG_APPROVAL_NO",
			
			"CARD_PUB_ID",
			"SIGN",
			"NCSAM",
			"NISAM",
			"TOTSAM",
			
			"IDCENTER",
			"MPSAM",
			"MAXIDCENTER",
			"BALIDCENTER",
			"FRU",
			
			"RESEND_FLAG",
			"RESULT",
			"ERR_CD"
		};
		
		//logger.info( "▶ getParseCashBeeRTPaymentSnd-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseCashBeeRTPaymentRcvRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,2,16
					  ,20,14,2,16,14
					  ,2};
		String strHeaders[] = {
			"COMMAND_TY",
			"LENGTH",
			"MEMBER_ID",
			"SAM_FLAG",
			"SAM_ID",
			
			"CARD_NO",
			"CARD_DEAL_YMDHMS",
			"RES_CD",
			"RES_MSG",
			"RES_YMDHMS",
			
			"PUBCO_INFOCHNG_YN"
		};
		
		//logger.info( "▶ getParseCashBeeRTPaymentRcvRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 환불 완료 요청 전문 파싱
	public HashMap<String, String> getParseCashBeeRFNDCompletedInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,8,6
					  ,10,8,20,10,10
					  ,10,1,10,4,16
					  ,10,2,2,10,10
					  ,10,16,8,10,16
					  ,8,6,10,8,1};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"ADJT_YMD",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
			"RFND_FEE_AMT",
			"RFND_FEE_RATE",
			"IDEP",
			
			"NTEP",
			"IDCENTER",
			"ALGEP",
			"BALEP_OLD",
			"BALEP",
			
			"NT_CARDLSAM",
			"IDLSAM",
			"SIGN3_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			"DEAL_SNO",
			"SIGN2_VAL",
			"DEAL_RESULT"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCompletedInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// 캐시비에서 보낸 환불 결과 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeRFNDResultRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,2,2,10,10,10
					  ,16,8,16,8,6
					  ,10,8,23};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
						
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
						
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"RFND_FEE_AMT",
			"RFND_FEE_RATE",
			"IDEP",
			"NTEP",
			
			"IDCENTER",
			"ALGEP",
			"BALEP_OLD",
			"BALEP",
			"NT_CARDLSAM",
			
			"IDLSAM",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"SIGN2_VAL",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeRFNDResultRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// 캐시비에서 보낸 환불 실패 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeRFNDFailRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,8,10,16,8,6
					  ,10,1,70};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
							
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
							
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
				
			"PAY_FLAG",
			"RFND_FEE_AMT",
			"RFND_FEE_RATE",
			"IDLSAM",
			"NT_CARDLSAM",
			
			"SIGN2_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"DEAL_RESULT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeRFNDFailRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 충전/지불취소 요청 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,8,6
					  ,10,8,20,10,10
					  ,10,1,10,4,2
					  ,10,2,16,10,16
					  ,8,8,10,16,14
					  ,8,10};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"ADJT_YMD",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"ALGEP",
			
			"BALEP",
			"IDCENTER",
			"IDEP",
			"NTEP",
			"REP",
			
			"SIGN1_VAL",
			"RFU",
			"MLDA",
			"L_MEMBER_NO",
			"ORG_TRAN_YMDHMS",
			
			"ORG_SIGN",
			"ORG_SAM_DEAL_SNO"
		};
		
		//logger.info( "▶ getParseCashBeeTMNLINSTALLInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);		
		
		return hm;
	}
	
	// 캐시비에서 보낸 충전/지불취소 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,8,10,16,8,6
					  ,10,6,65};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
				
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
				
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
			
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDSAM",
			"NT_CARDLSAM",
			
			"SIGN2_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"EVT_CHRG_AMT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHKPPAMTRsp-" + rcvBuf );
		//hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
				
		return hm;
	}

	
	// POS에서 보낸 단말기 설치 요청 전문 파싱
	public HashMap<String, String> getParseCashBeeTMNLINSTALLInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,1,16
					  ,16,40,20,6,100
					  ,8,2,16};
		String strHeaders[] = {
			"INQ_TYPE",
			"COMMAND_TY",
			"MEMBER_ID",
			"DATA_FLAG",
			"LSAM_ID",
			
			"NEW_LSAM_ID",
			"MEMBER_NM",
			"TEL_NO",
			"POST_CD",
			"ADDRESS",
			
			"SETUP_YMDHMS",
			"ERR_CD",
			"ERR_MSG"
		};
		
		//logger.info( "▶ getParseCashBeeTMNLINSTALLInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);		
		
		return hm;
	}
	
	// 캐시비에서 보낸 단말기 설치 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeTMNLINSTALLRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,1,16
					  ,16,40,20,6,100
					  ,8,2,16,10,7};
		String strHeaders[] = {
			"COMMAND_TY",
			"LENGTH",
			"MEMBER_ID",
			"DATA_FLAG",
			"LSAM_ID",
			
			"NEW_LSAM_ID",
			"MEMBER_NM",
			"TEL_NO",
			"POST_CD",
			"ADDRESS",
			
			"SETUP_YMDHMS",
			"ERR_CD",
			"ERR_MSG",
			"BIZCO_NO",
			"FILLER"	
		};
		
		//logger.info("▶ getParseCashBeeTMNLINSTALLRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 예치금 확인 요청 전문 파싱
	public HashMap<String, String> getParseCashBeeCHKPPAMTInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,10,8,6,10
					  ,4,16,8,10,10
					  ,2};
		String strHeaders[] = {
			"INQ_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			"DEAL_SNO",
			
			"RES_CD",
			"RES_MSG",
			"ADJT_YMD",
			"BRANCH_NO",
			"RECHRGABLE_AMT",
			
			"RESULT"
		};
		
		//logger.info( "▶ getParseCashBeeCHKPPAMTInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseCashBeeCHKPPAMTRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,10,10,2,198};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_GB_CD",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
			
			"FILLER",
			"BRANCH_NO",
			"RECHRGABLE_AMT",
			"RESULT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHKPPAMTRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// POS에서 보낸 충전/지불취소 완료 요청 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGCompletedInq(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,2,10,8,6
					  ,10,8,20,10,10
					  ,10,1,10,4,16
					  ,10,2,2,10,10
					  ,16,10,10,8,16
					  ,8,6,10,8,6
					  ,1};
		String strHeaders[] = {
			"INQ_TYPE",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
			
			"DEAL_SNO",
			"ADJT_YMD",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			
			"DEAL_AFT_RAMT",
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDEP",
			
			"NTEP",
			"IDCENTER",
			"ALGEP",
			"MLDA",
			"NT_CARDLSAM",
			
			"IDLSAM",
			"NTSAM",
			"BALEP",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			"DEAL_SNO",
			"SIGN2_VAL",
			"EVT_CHRG_AMT",
			
			"DEAL_RESULT"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGCompletedInq-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// 캐시비에서 보낸 충전/지불취소 결과 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGResultRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,2,2,10,10,16
					  ,10,10,8,16,8
					  ,6,10,8,10,3};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
					
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
					
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
				
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDEP",
			"NTEP",
			
			"IDCENTER",
			"ALGEP",
			"MLDA",
			"NT_CARDLSAM",
			"IDLSAM",
			
			"NTSAM",
			"BALEP",
			"SIGN3_VAL",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			
			"DEAL_REQ_TIME",
			"DEAL_SNO",
			"SIGN2_VAL",
			"TODAY_CHRGSUCCESS_TOT_AMT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGResultRsp-" + rcvBuf );
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	// 캐시비에서 보낸 충전/지불취소 실패 응답 전문 파싱
	public HashMap<String, String> getParseCashBeeCHRGFailRsp(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {4,2,10,8,6
					  ,10,4,16,2,8
					  ,10,20,10,10,10
					  ,1,10,4,16,10
					  ,8,10,16,8,6
					  ,10,6,1,64};
		String strHeaders[] = {
			"DATA_LEN",
			"DEAL_TYPE",
			"MEMBER_ID",
			"DEAL_REQ_YMD",
			"DEAL_REQ_HMS",
						
			"DEAL_SNO",
			"RES_CD",
			"RES_MSG",
			"PUBCO_INFOCHNG_YN",
			"ADJT_YMD",
						
			"FILLER",
			"CARD_NO",
			"DEAL_BEF_RAMT",
			"DEAL_REQ_AMT",
			"DEAL_AFT_RAMT",
					
			"PAY_FLAG",
			"CHRG_FEE_AMT",
			"CHRG_FEE_RATE",
			"IDLSAM",
			"NT_CARDLSAM",
			
			"SIGN2_VAL",
			"NTSAM",
			"SVR_APPROVAL_NO",
			"DEAL_REQ_DATE",
			"DEAL_REQ_TIME",
			
			"DEAL_SNO",
			"EVT_CHRG_AMT",
			"DEAL_RESULT",
			"FILLER"
		};
		
		//logger.info( "▶ getParseCashBeeCHRGFailRsp-" + rcvBuf );
		//hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
}