package biz.cms_CJPclDTLDownloader;

import java.util.HashMap;
import java.util.List;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class CJPclDTLDownloaderDAO extends GenericDAO {
	public List<Object> selSVCFILEDAILY(String stdYmd, String svcID, String cmdTp, String comCD) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SVCCRTDAILY"));
			sql.setString(++i, stdYmd);
			sql.setString(++i, svcID);
			sql.setString(++i, cmdTp);
			sql.setString(++i, comCD);
			
			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		} 
		
		return list;
	}
	
	public int insSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insHQPARCELADJT_TRN(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_PARCELADJT_TRN"));
			sql.setString(++i, (String)hm.get("CO_CD").trim());				// 1. 회사코드
			sql.setString(++i, (String)hm.get("TRAN_YMD").trim());			// 2. TRAN일자
			sql.setString(++i, (String)hm.get("STORE_CD").trim());			// 3. 점포코드
			sql.setString(++i, (String)hm.get("POS_NO").trim());			// 4. POS번호
			sql.setString(++i, (String)hm.get("TRAN_NO").trim());			// 5. TRAN번호
			sql.setString(++i, (String)hm.get("PARCEL_CD").trim());			// 6. 운송장번호
			sql.setString(++i, (String)hm.get("ADJT_DT").trim());			// 7. 정산일자
			sql.setString(++i, (String)hm.get("PARCEL_CMP_TP").trim());		// 8. 택배회사구분
			sql.setString(++i, (String)hm.get("PAYMENT_TP").trim());		// 9. 결제구분
			sql.setString(++i, (String)hm.get("PARCEL_STS_TP").trim());		// 10.택배상태구분
			sql.setString(++i, (String)hm.get("PARCEL_IN_QTY").trim());		// 11.택배접수수량
			sql.setString(++i, (String)hm.get("BASE_COST_TP").trim());		// 12.택배기본운임구분
			sql.setString(++i, (String)hm.get("TOT_AMT").trim());			// 13.택배총금액
			sql.setString(++i, (String)hm.get("BASE_AMT").trim());			// 14.기본운임
			sql.setString(++i, (String)hm.get("PERRY_RTS_AMT").trim());		// 15.도선비금액
			sql.setString(++i, (String)hm.get("ITEM_EXT_AMT").trim());		// 16.물품가할증금액
			sql.setString(++i, (String)hm.get("DC_AMT").trim());			// 17.택배할인금액
			sql.setString(++i, (String)hm.get("FEE_AMT").trim());			// 18.수수료
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int updPARCELTRN(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_PARCELTRN"));
			sql.setString(++i, ((String)hm.get("TRAN_YMD")).trim());
			sql.setString(++i, ((String)hm.get("STORE_CD")).trim());
			sql.setString(++i, ((String)hm.get("PARCEL_CD")).trim());
			sql.setString(++i, ((String)hm.get("CO_CD")).trim());
			sql.setString(++i, ((String)hm.get("PARCEL_TP")).trim());
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
}
