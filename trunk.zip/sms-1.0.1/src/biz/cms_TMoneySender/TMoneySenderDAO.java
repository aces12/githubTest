package biz.cms_TMoneySender;


import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class TMoneySenderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(TMoneySenderPollingAction.class);
	
	public int spSMSSEND(String strMsg, String strSender) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int ret = -1;
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("sysinq-sql", "PR_SMSSEND"));
			sql.setString(++i, strMsg);
			sql.setString(++i, strSender);
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]" + e);
		}finally {
			end();
		}
		
		return ret;
	}
	
	public List<Object> selSVCFILEDAILY(String stdYmd, String svcID, String cmdTp, String comCD) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_SVCCRTDAILY"));
			sql.setString(++i, stdYmd);
			sql.setString(++i, svcID);
			sql.setString(++i, cmdTp);
			sql.setString(++i, comCD);
			
			list = executeQuery(sql);
		} catch (Exception e) {
			throw e;
		} 
		
		return list;
	}
	
	public int updSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			//df.CommLogger("▶ SEL Error : " + e);
			//df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			rollback();	
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int insSVCFILEINFO(HashMap<String, String> hm) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_SVCFILEINFO"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			sql.setString(++i, (String)hm.get("STD_YMD"));
			sql.setString(++i, (String)hm.get("SVC_ID"));
			sql.setString(++i, (String)hm.get("CMD_TY"));
			
			rows = executeUpdate(sql);
			
		}catch(Exception e) {
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public int updTMONEYPAYMENTTRAN(String proc_id, String tran_id, String com_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");
		
			sql.put(findQuery("service-sql", "UPD_TMONEYPAYMENTTRAN"));
			sql.setString(++i, proc_id);		// proc_id 0:미송신 1:파일생성 2:송신완료 3:반송
			sql.setString(++i, tran_id);
			sql.setString(++i, com_cd);
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			//df.CommLogger("▶ SEL Error : " + e);
			//df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			rollback();	
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
	public List selTMONEYPAYMENTTRAN(String com_cd, String card_key, String double_card_key) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_TMONEYPAYMENTTRAN"));
			sql.setString(++i, card_key);
			sql.setString(++i, double_card_key);
			sql.setString(++i, com_cd);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	
	public List selTMONEYTMLSAMIDMST(String com_cd) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;		
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "SEL_TMONEYTMNALSAMIDMST"));
			sql.setString(++i, com_cd);
			
//			logger.info(" >>>>>>>>>>>>>>>>> sql : " + sql.debug());
			
			list = executeQuery(sql);
			
		}catch(Exception e) {
			throw e;
		}
		
		return list;
	}
	
	public int updTMONEYTMLSAMIDMST(String sndYN, String com_cd, String member_id, String tmnal_id, String sam_id) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "UPD_TMONEYTMNALSAMIDMST"));
			sql.setString(++i, sndYN);	
			sql.setString(++i, com_cd);	
			sql.setString(++i, member_id);	
			sql.setString(++i, tmnal_id);
			sql.setString(++i, sam_id);
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			//df.CommLogger("▶ SEL Error : " + e);
			//df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			rollback();	
			throw e;
		}finally {
			end();
		}
		
		return rows;
	}
	
}


