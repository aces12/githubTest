package biz.cms_TMoneySender;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

public class TMoneySenderFileTransfer {
	private static Logger logger = Logger.getLogger(TMoneySenderFileTransfer.class);
	
	private String server_ip = "";
	private int server_port = 0;
	
	private Socket sock = null;
	private ActionSocket actSock = null;

	
	public List<File> getDirFileList(String dirPath) {
		List<File> dirFileList = new ArrayList<File>();
		List<File> tmpList = null;
		
		File dir = new File(dirPath);
		if( dir.exists() ) {
			File[] files = dir.listFiles();

			tmpList = Arrays.asList(files);
			for( int i = 0;i < tmpList.size();i++ ) {
				if( tmpList.get(i).isFile() ) {
					dirFileList.add(tmpList.get(i));
				}
			}
		}
		
		return dirFileList;
	}
	
	public void moveFile(String orgPath, String fileNM, String destPath, COMMLog df) {
		File destDir = new File(destPath);
		
		if( !destDir.exists() ) {
			destDir.mkdir();
		}
		
		File orgFile = new File(orgPath + File.separator + fileNM);
		File destFile = new File(destPath + File.separator + fileNM);
		
		logger.info("orgFile = " + orgPath + File.separator + fileNM);
		logger.info("destFile = " + destPath + File.separator + fileNM);
		
		if( destFile.exists() ) {
			if( orgFile.delete() ) {
				logger.info("[DEBUG] File(" + orgFile.getPath() + " / "+ orgFile.getName() + ") Deleted");
			}else {
				logger.info("[DEBUG] Fail to remove file(" + orgFile.getPath() + " / "+ orgFile.getName() + ")");
			}
		}else {
			for(int i = 0;i < 20;i++) {
				if( orgFile.renameTo(destFile) ) {
					logger.info(">> MOVE OK : " + destFile.getName());
					break;
				}
				System.gc();
				try {
					Thread.sleep(50);
				}catch(InterruptedException ie) {
					df.CommLogger("▶ [ERROR] " + ie.getMessage());
				}
			}
		}
	}
	
	public void transfer() {
		String sendData = "";
		String recvData = "";
		boolean bIsMore = true;
		try {
			
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "up" + File.separator + "tmoney";
			
			COMMLog df = new COMMLog();
			TMoneySenderProtocol protocol = new TMoneySenderProtocol();
				
			this.server_ip = PropertyUtil.findProperty("communication-property", "TMONEY_BATCH_IP");
			this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "TMONEY_BATCH_PORT"));
				
			sock = new Socket(server_ip, server_port);
				
			actSock = new ActionSocket(this.sock, (Filter)(new COMMConveyerFilter(COMMBiz.TMONEY_EXT_FILTER)));
				
			// read-time-out 60초 설정(티머니 권고 시간)
			actSock.getSocket().setSoTimeout(60000);
				
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			df.setConnectionInfo(actSock.getSocket().getInetAddress()
					.getHostAddress().toString(), 
					String.valueOf(actSock.getSocket().getPort()), logger,
					"TMoneySender-Transfer");

			HashMap<String, String> hmCommon = new HashMap<String, String>();
				
			hmCommon.put("WORK_CD", "FTP");				// 업무 구분 코드
			hmCommon.put("COMPANY_CD", "60000099");		// 
			hmCommon.put("TLGM_CD", "0600");
			hmCommon.put("DEAL_TP", "R");
			hmCommon.put("SNDRCV_FG", "E");
			hmCommon.put("FILE_NM", " ");
			hmCommon.put("RES_CD", "000");
			// "001":업무개시요청, "002":파일송신완료요청and추가전송파일존재, "003":파일송신완료요청and추가전송파일없음
			// "004":업무종료요청
			sendData = makeSendData0600(makeSendDataCommon(hmCommon), "001");
			df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "]:[JOB_CODE:0600/001]:[" + sendData + "]");
			
			byte sendBytes[] = sendData.getBytes();
				
			int iReTry = 0;
			// 업무 개시 요청(KSC <- 위드미)
			// 3회 재반복
			while( iReTry < 3 ) {
				if( actSock.send(sendBytes, sendBytes.length) ) {
					df.CommLogger("[sms>tmoney] SEND[" + sendBytes.length + "] OK");
					try {
						// 업무 개시 응답(KSC -> 위드미)
						recvData = (String)(actSock.receive());
						df.CommLogger("[sms<tmoney] RECV[" + recvData.getBytes().length + "]:[JOB_CODE:0610]:[" + recvData + "]");
					}catch(SocketTimeoutException e) {
						iReTry++;
						df.CommLogger("▶ [ERROR] TimeOut after sending 0600/001. Retry..." + Integer.toString(iReTry));
						continue;
					}
						
					// 응답코드가 '정상'이면 계속 진행
					if( protocol.get0610WhetherNormality(recvData, "001") ) {
						String strMgrCd = "";
						List<File> upFolder = getDirFileList(destPath);
						
						if( upFolder.size() <= 0 ) {
							df.CommLogger("▶ [ERROR] No sending file exists");
							// 업무 종료 처리
							this.processEnding(hmCommon, actSock, df);
							iReTry = 99;
							continue;
						}
						
						boolean bEnd = false;
						for(int i = 0;i < upFolder.size();i++) {
							if( !upFolder.get(i).isFile() ) {
								continue;
							}
							String targetFileNM = upFolder.get(i).getName();
							if( i + 1 == upFolder.size() ) {
								bIsMore = false;
								strMgrCd = "003";
							}else {
								strMgrCd = "002";
							}									
							
							hmCommon.put("TLGM_CD", "0630");
							hmCommon.put("DEAL_TP", "R");
							hmCommon.put("SNDRCV_FG", "E");
							hmCommon.put("FILE_NM", targetFileNM);
							hmCommon.put("RES_CD", "000");
							sendData = makeSendData0630(makeSendDataCommon(hmCommon), upFolder.get(i), upFolder.get(i).getName());
							df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "]:[JOB_CODE:0630]:[" + sendData + "]");
								
							// 파일정보 수신 요청(KSC <- 위드미)
							int iReTry1 = 0;
							while( iReTry1 < 3 ) {
								if( actSock.send(sendData) ) {
									df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "] OK");
									try {
										// 파일정보 수신 응답(KSC -> 위드미)
										recvData = (String)(actSock.receive());
										df.CommLogger("[sms<tmoney] RECV[" + recvData.getBytes().length + "]:[JOB_CODE:0640]:[" + recvData + "]");
									}catch(SocketTimeoutException e) {
										iReTry1++;
										df.CommLogger("▶ [ERROR] TimeOut after sending 0630. Retry..." + Integer.toString(iReTry1));
										continue;
									}
									long fileSize = Long.parseLong(protocol.getRecvData0640(recvData, "FILE_SIZE"));

									df.CommLogger("protocol.getResCD(recvData) [" + protocol.getResCD(recvData) + "]");
									if( (protocol.getResCD(recvData)).equals("630") ) {		// 해당 파일정보 수신 완료 시
//										if( fileSize == upFolder.get(i).length() ) {
											hmCommon.put("TLGM_CD", "0600");
											// "001":업무개시요청, "002":파일송신완료요청and추가전송파일존재, "003":파일송신완료요청and추가전송파일없음
											// "004":업무종료요청
											sendData = makeSendData0600(makeSendDataCommon(hmCommon), strMgrCd);
											df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "]:[JOB_CODE:0600/" + strMgrCd + "]:[" + sendData + "]");		
											// 파일 송신 완료 요청(KSC <- 위드미)
											int iReTry2 = 0;
											while( iReTry2 < 3 ) {
												if( actSock.send(sendData) ) {
													try {
														df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "] OK");
														// 파일 송신 완료 응답(KSC -> 위드미)
														recvData = (String)(actSock.receive());
														df.CommLogger("[sms<tmoney] RECV[" + recvData.getBytes().length + "]:[JOB_CODE:0610]:[" + recvData + "]");
													}catch(SocketTimeoutException e) {
														iReTry2++;
														df.CommLogger("▶ [ERROR] TimeOut after sending 0600/"+strMgrCd+". Retry..." + Integer.toString(iReTry2));
														continue;
													}
													// 정상 응답이라면
													if( protocol.get0610WhetherNormality(recvData, strMgrCd) ) {
														// 파일 옮기기...
														this.moveFile(destPath, targetFileNM, destPath + File.separator + "backup", df);
														
														if( bIsMore ) {
															iReTry1 = 99;
															iReTry2 = 99;
															continue;
														}else {
															// 업무 종료 처리
															this.processEnding(hmCommon, actSock, df);
															iReTry = 99;
															iReTry1 = 99;
															iReTry2 = 99;
															bEnd = true;
															break;
														}
													}else {
														iReTry2++;
														continue;
													}
												}else {
													iReTry2++;
													df.CommLogger("▶ [ERROR] TimeOut after sending 0600. Retry..." + Integer.toString(iReTry));
													continue;
												}
											}
//										}else {
//											iReTry++;
//											df.CommLogger("▶ [ERROR] Check file size. Retry..." + Integer.toString(iReTry));
//											continue;
//										}
									}else if( (protocol.getResCD(recvData)).equals("000") ) {	// 해당 파일정보 미 완료 시(파일 이어받기) or 해당 파일정보 최초 수신(파일 수신)
										df.CommLogger("upFolder.get(i) [" + upFolder.get(i) + "]");
										if( fileSize < upFolder.get(i).length() ) {		// 파일 이어받기
											HashMap<String, Integer> hm = new HashMap<String, Integer>();
											hm = getBLCKSEQ(fileSize);
												
											// 파일 전송 처리
											this.processSendingFile(hmCommon, actSock, (File)upFolder.get(i), targetFileNM, (int)hm.get("BLOCK"), (int)hm.get("SEQUENCE"), df);
										}else if( fileSize == 0 ) {	// 파일 최초 수신
											hmCommon.put("TLGM_CD", "0320");
											hmCommon.put("FILE_NM", targetFileNM);
											hmCommon.put("RES_CD", "000");
												
											// 파일 전송 처리
											this.processSendingFile(hmCommon, actSock, (File)upFolder.get(i), targetFileNM, 1, 1, df);
										}else {
											
										}
											
										hmCommon.put("TLGM_CD", "0600");
										// "001":업무개시요청, "002":파일송신완료요청and추가전송파일존재, "003":파일송신완료요청and추가전송파일없음
										// "004":업무종료요청
										sendData = makeSendData0600(makeSendDataCommon(hmCommon), strMgrCd);
										df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "]:[JOB_CODE:0600/" + strMgrCd + "]:[" + sendData + "]");	
											
										// 파일 송신 완료 요청(KSC <- 위드미)
										int iReTry2 = 0;
										while( iReTry2 < 3 ) {
											if( actSock.send(sendData) ) {
												df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "] OK");
												try {
													// 파일 송신 완료 응답(KSC -> 위드미)
													recvData = (String)(actSock.receive());
													df.CommLogger("[sms<tmoney] RECV[" + recvData.getBytes().length + "]:[JOB_CODE:0610]:[" + recvData + "]");
												}catch(SocketTimeoutException e) {
													iReTry2++;
													df.CommLogger("▶ [ERROR] TimeOut after sending 0600/"+strMgrCd+". Retry..." + Integer.toString(iReTry2));
													continue;
												}
												// 정상 응답이라면
												if( protocol.get0610WhetherNormality(recvData, strMgrCd) ) {
													// 파일 옮기기...
													this.moveFile(destPath, targetFileNM, destPath + File.separator + "backup", df);
													
													if( bIsMore ) {
														iReTry1 = 99;
														iReTry2 = 99;
														bEnd = false;
														continue;
													}else {
														// 업무 종료 처리
														this.processEnding(hmCommon, actSock, df);
														iReTry = 99;
														iReTry1 = 99;
														iReTry2 = 99;
														bEnd = true;
														break;
													}
												}else {
													iReTry2++;
													continue;
												}
											}else {
												iReTry2++;
												df.CommLogger("▶ [ERROR] TimeOut after sending 0600. Retry..." + Integer.toString(iReTry2));
												continue;
											}
										}
									}else {		// 파일정보 수신 응답 오류일 경우
										throw new Exception("Response Code Error for 0630.");
									}
								}else {
									iReTry1++;
									df.CommLogger("▶ [ERROR]1: 0630 Retry..." + Integer.toString(iReTry1));
									continue;
								}
							}
							if( bEnd ) {
								break;
							}
						}	// end of for
					}else {
						iReTry++;
						df.CommLogger("▶ [ERROR] 0600/001 Retry..." + Integer.toString(iReTry));
					}
					break;
				}else {
					iReTry++;
					df.CommLogger("▶ [ERROR]0: 0600/001 Retry..." + Integer.toString(iReTry));
					continue;
				}
			}
		}catch(SocketException e) {
			logger.info("[ERROR] " + stackTraceToString(e));
			//(new TMoneySenderDAO()).spSMSSEND("티머니 파일송신 오류(SocketException)", "cms_TMoneySender");
		}catch(SocketTimeoutException e) {
			logger.info("[ERROR] " + stackTraceToString(e));
			//(new TMoneySenderDAO()).spSMSSEND("티머니 파일송신 오류(SocketTimeoutException)", "cms_TMoneySender");
		}catch(InterruptedException e) {
			logger.info("[ERROR] " + stackTraceToString(e));
			//(new TMoneySenderDAO()).spSMSSEND("티머니 파일송신 오류(InterruptedException)", "cms_TMoneySender");
		}catch(UnknownHostException e) {
			logger.info("[ERROR] " + stackTraceToString(e));
			//(new TMoneySenderDAO()).spSMSSEND("티머니 파일송신 오류(UnknownHostException)", "cms_TMoneySender");
		}catch(IOException e) {
			logger.info("[ERROR] " + stackTraceToString(e));
			//(new TMoneySenderDAO()).spSMSSEND("티머니 파일송신 오류(IOException)", "cms_TMoneySender");
		}catch(Exception e) {
			logger.info("[ERROR] " + stackTraceToString(e));
			//(new TMoneySenderDAO()).spSMSSEND("티머니 파일송신 오류(Exception)", "cms_TMoneySender");
		}finally {
			actSock.close();
		}
	}
	
	public String stackTraceToString(Throwable e) {
		StringBuilder sb = new StringBuilder();
		for(StackTraceElement element : e.getStackTrace()) {
			sb.append(element.toString());
			sb.append("\n");
		}
		return sb.toString();
	}
	
	public void processSendingFile(HashMap<String, String> hmCommon, ActionSocket actSock, File file, String fileNM, int block, int sequence, COMMLog df) throws Exception {
		InputStream is = null;
		
		try {
			int len = 0;
//			int iReTry = 0;
			int blkNo = 1;
			int seqNo = 0;
			boolean bContinue = false;			

			is = new FileInputStream(file);
			StringBuffer backUpMsg[] = new StringBuffer[100];
			String sendData = "";
			String recvData = "";
			TMoneySenderProtocol protocol = new TMoneySenderProtocol();
			
			long lFileSize = file.length();
			byte buf[] = new byte[TMoneySenderProtocol.LENGTH_BY_SEQUENCE];
			int totLen = 0;

			while( (len = is.read(buf, 0, buf.length)) > 0  ) {
				
				seqNo++;
				totLen += len;
				logger.info(" >>>>>>>>>>>>>>> sequence : " + Integer.toString(sequence) + ", block : " + Integer.toString(block));
				logger.info(" >>>>>>>>>>>>>>> seqNo : " + Integer.toString(seqNo) + ", blkNo : " + Integer.toString(blkNo));
				
				if(blkNo == block && seqNo != sequence){
					//20171109 KSN 누락되는 경우를 대비하여 동일 block부터 backupmsg 배열에 sb 담기.
					StringBuffer sb = new StringBuffer();
					sb.append(String.format("%04d", blkNo));
					sb.append(String.format("%03d", seqNo));
					sb.append(String.format("%04d", len));
					sb.append(new String(buf, 0, len));
					backUpMsg[seqNo - 1] = sb;
					logger.info("[INFO] retry put backUpMsg["+  (seqNo - 1) + "]["+ backUpMsg[seqNo - 1].toString() + "]");
				}
				
				// Block Number 와 Sequence Number 가 같은 파일 데이터 부터 계속 전송
				if( blkNo == block && seqNo == sequence ) {
					bContinue = true;
				}
				if( bContinue ) {
					// DATA 송신(KSC <- 위드미)
					int iReTry = 0;
					while( true ) {
						hmCommon.put("TLGM_CD", "0320");
						hmCommon.put("FILE_NM", fileNM);
						hmCommon.put("RES_CD", "000");
						
						StringBuffer sb = new StringBuffer();
						sb.append(String.format("%04d", blkNo));
						sb.append(String.format("%03d", seqNo));
						sb.append(String.format("%04d", len));
						sb.append(new String(buf, 0, len));
						sendData = makeSendData0320(makeSendDataCommon(hmCommon), sb);
						df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "]:[JOB_CODE:0320]:[" + sendData + "]");
						// 결번 DATA 송신을 위한 전문메시지 백업
						backUpMsg[seqNo - 1] = sb;
					    logger.info("[INFO] backUpMsg["+  (seqNo - 1) + "]["+ backUpMsg[seqNo - 1].toString() + "]");
//					// DATA 송신(KSC <- 위드미)
//					iReTry = 0;
//					while( true ) {
						if( actSock.send(sendData) ) {
							df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "] OK");
							Thread.sleep(50);
							if( seqNo == 100 ) {
								hmCommon.put("TLGM_CD", "0620");
								sendData = makeSendData0620(makeSendDataCommon(hmCommon), String.format("%04d%03d", blkNo, seqNo));
								df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "]:[JOB_CODE:0620]:[" + sendData + "]");
								// 결번 확인 요청(KSC <- 위드미)
								int iReTry1 = 0;
								while( iReTry1 < 3 ) {
									if( actSock.send(sendData) ) {
										df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "] OK_01");
										try {
											// 결번 확인 응답(KSC -> 위드미)
											recvData = (String)(actSock.receive());
											df.CommLogger("[sms<tmoney] RECV[" + recvData.getBytes().length + "]:[JOB_CODE:0300]:[" + recvData + "]");
										}catch(SocketTimeoutException e) {
											iReTry1++;
											df.CommLogger("▶ [ERROR] TimeOut after sending 0620. Retry..." + Integer.toString(iReTry1));
											continue;
										}
										iReTry1 = 99;
										List<Integer> array = protocol.getRecvData0300(recvData);
										
										for(int i = 0;i < array.size();i++) {
											hmCommon.put("TLGM_CD", "0310");
											sendData = makeSendData0320(makeSendDataCommon(hmCommon), backUpMsg[array.get(i)]);
											df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "]:[JOB_CODE:0310]:[" + sendData + "]");
											// 결번 DATA 송신(KSC <- 위드미)
											int iReTry2 = 0;
											while( iReTry2 < 3 ) {
												if( actSock.send(sendData) ) {
													df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "] OK");
													iReTry2 = 99;
													Thread.sleep(50);
												}else {
													iReTry2++;
													df.CommLogger("▶ [ERROR] TimeOut after sending 0310. Retry..." + Integer.toString(iReTry2));
													continue;
												}
											}
										}
										
										seqNo = 0;
										blkNo++;
									}else {
										iReTry1++;
										df.CommLogger("▶ [ERROR] TimeOut after sending 0620. Retry..." + Integer.toString(iReTry1));
									}
								}															
							}
							break;
						}else {
							iReTry++;
							df.CommLogger("▶ [ERROR] TimeOut after sending 0320. Retry..." + Integer.toString(iReTry));
						}
					}
				}else {
					if( seqNo == 100 ) {
						seqNo = 0;
						blkNo++;
					}
				}
				if( totLen >= lFileSize ) {
					break;
				}
			}
			// 파일 전송 후 결번확인요청 전문 송신
			if( seqNo != 0 ) {
				hmCommon.put("TLGM_CD", "0620");
				sendData = makeSendData0620(makeSendDataCommon(hmCommon), String.format("%04d%03d", blkNo, seqNo));
				df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "]:[JOB_CODE:0620]:[" + sendData + "]");
				// 결번 확인 요청(KSC <- 위드미)
				int iReTry3 = 0;
				while( iReTry3 < 3 ) {
					if( actSock.send(sendData) ) {
						try {
							df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "] OK_02");
							// 결번 확인 응답(KSC -> 위드미)
							recvData = (String)(actSock.receive());
							df.CommLogger("[sms<tmoney] RECV[" + recvData.getBytes().length + "]:[JOB_CODE:0300]:[" + recvData + "]");
						}catch(SocketTimeoutException e) {
							iReTry3++;
							df.CommLogger("▶ [ERROR] TimeOut after sending 0620. Retry..." + Integer.toString(iReTry3));
							if( iReTry3 == 2 )
								throw e;
							continue;
						}
						
						iReTry3 = 99;
						List<Integer> array = protocol.getRecvData0300(recvData);
						
						for(int i = 0;i < array.size();i++) {
							hmCommon.put("TLGM_CD", "0310");
							sendData = makeSendData0320(makeSendDataCommon(hmCommon), backUpMsg[array.get(i)]);
							df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "]:[JOB_CODE:0310]:[" + sendData + "]");
							// 결번 DATA 송신(KSC <- 위드미)
							int iReTry4 = 0;
							while( iReTry4 < 3 ) {
								if( actSock.send(sendData) ) {
									df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "] OK");
									iReTry4 = 99;
									Thread.sleep(50);
								}else {
									iReTry4++;
									df.CommLogger("▶ [ERROR] TimeOut after sending 0310. Retry..." + Integer.toString(iReTry4));
									continue;
								}
							}
						}
						
						seqNo = 0;
						blkNo++;
						iReTry3 = 99;
					}else {
						iReTry3++;
						df.CommLogger("▶ [ERROR] TimeOut after sending 0620. Retry..." + Integer.toString(iReTry3));
					}
				}
			}
		}catch(Exception e) {
			throw e;
		}finally {
			is.close();
		}
	}
	
	public boolean processEnding(HashMap<String, String> hmCommon, ActionSocket actSock, COMMLog df) throws Exception {
		int iReTry = 0;
		boolean bRtn = false;
		String sendData = "";
		String recvData = "";
		TMoneySenderProtocol protocol = new TMoneySenderProtocol();
		try {
			hmCommon.put("TLGM_CD", "0600");
			hmCommon.put("FILE_NM", " ");
						
			// "001":업무개시요청, "002":파일송신완료요청and추가전송파일존재, "003":파일송신완료요청and추가전송파일없음
			// "004":업무종료요청
			sendData = makeSendData0600(makeSendDataCommon(hmCommon), "004");
			df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "]:[JOB_CODE:0600/004]:[" + sendData + "]");			
			// 업무 종료 요청(KSC <- 위드미)
			iReTry = 0;
			while( iReTry < 3 ) {
				if( actSock.send(sendData) ) {
					try {
						df.CommLogger("[sms>tmoney] SEND[" + sendData.getBytes().length + "] OK");
						// 업무 종료 응답(KSC -> 위드미)
						recvData = (String)(actSock.receive());
						df.CommLogger("[sms<tmoney] RECV[" + recvData.getBytes().length + "]:[JOB_CODE:0610]:[" + recvData + "]");
					}catch(SocketTimeoutException e) {
						iReTry++;
						df.CommLogger("▶ [ERROR] TimeOut after sending 0600/004. Retry..." + Integer.toString(iReTry));
						continue;
					}
					
					bRtn = true;
					iReTry = 99;
				}else {
					iReTry++;
					df.CommLogger("▶ [ERROR] TimeOut after sending 0600/004. Retry..." + Integer.toString(iReTry));
				}
			}
		}catch(Exception e) {
			throw e;
		}
		
		return bRtn;
	}
	
	public String makeSendDataCommon(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {3,8,4,1,1
					  ,8,3};
		
		String strHeaders[] = {
			"WORK_CD",
			"COMPANY_CD",
			"TLGM_CD",
			"DEAL_TP",
			"SNDRCV_FG",
			
			"FILE_NM",
			"RES_CD"
		};
		
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}

	public String makeSendData0600(String strCommon, String strMgrCd) {
		HashMap<String, String> hm = new HashMap<String, String>();
		StringBuffer sb = new StringBuffer();
		int nlens[] = {10,3,20,16};
		String strHeaders[] = {
			"TRANS_TIME",
			"MANAGE_INFO",
			"SENDER_NM",
			"SENDER_PW"
		};
		
		Calendar cal = new GregorianCalendar(Locale.KOREA);
		SimpleDateFormat sdf = new SimpleDateFormat("MMddkkmmss");
		
		hm.put("TRANS_TIME", sdf.format(cal.getTime())) ;
		hm.put("MANAGE_INFO", strMgrCd);
		hm.put("SENDER_NM", "WITHME");
		hm.put("SENDER_PW", "withme");
		
		// TCP/IP 송신 바이트 수 설정
		sb.append(String.format("%04d", (int)77));
		// 공통부분 설정
		sb.append(strCommon);
		// 0600전문 설정
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String makeSendData0630(String strCommon, File file, String fileNM) {
		HashMap<String, String> hm = new HashMap<String, String>();
		StringBuffer sb = new StringBuffer();
		int nlens[] = {8,12,4};
		String strHeaders[] = {
			"FILE_NAME",
			"FILE_SIZE",
			"TLGM_BYTE_NUM"
		};
		
		long lFileSize = file.length();
		
		hm.put("FILE_NAME", fileNM);
		hm.put("FILE_SIZE", String.format("%012d", lFileSize));
		hm.put("TLGM_BYTE_NUM", String.format("%04d", (int)939));
		
		// TCP/IP 송신 바이트 수 설정
		sb.append(String.format("%04d", (int)52));
		// 공통부분 설정
		sb.append(strCommon);
		// 0630 설정
		for( int i = 0;i < nlens.length;i++ ) {
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	public String makeSendData0320(String strCommon, StringBuffer sbData) {
		StringBuffer sb = new StringBuffer();
		
		// TCP/IP 송신 바이트 수 설정
		sb.append(String.format("%04d", (strCommon.getBytes()).length + ((sbData.toString()).getBytes()).length));
		// 공통부분 설정
		sb.append(strCommon);
		// BLOCK-NO + SEQUENCE-NO + 실DATA BYTE 수 + 파일 내역
		sb.append(sbData);
		
		return sb.toString();
	}
	
	public String makeSendData0620(String strCommon, String strData) {
		StringBuffer sb = new StringBuffer();
		
		// TCP/IP 송신 바이트 수 설정
		sb.append(String.format("%04d", (int)35));
		// 공통부분 설정
		sb.append(strCommon);
		// BLOCK-NO + 최종SEQUENCE-NO
		sb.append(strData);
		
		return sb.toString();
	}
	
	public HashMap<String, Integer> getBLCKSEQ(long fileSize) {
		int block = 0;
		int sequence = 0;
		HashMap<String, Integer> hm = new HashMap<String, Integer>();
		//int temp1 = (int)(fileSize / (long)(TMoneyReceiverProtocol.LENGTH_BY_RECORD));
		//int temp2 = (int)(TMoneySenderProtocol.LENGTH_BY_SEQUENCE / TMoneyReceiverProtocol.LENGTH_BY_RECORD);
		int quotient = (int)(fileSize / (long)(TMoneySenderProtocol.LENGTH_BY_SEQUENCE));
		int rest = (int)(fileSize % (long)(TMoneySenderProtocol.LENGTH_BY_SEQUENCE));
		//int quotient = temp1 / temp2;
		//int rest = temp1 % temp2;
		
		sequence = quotient;
		
		if( rest > 0 ) {
			sequence++;
		}
		
		block = sequence / 100;
		sequence = sequence % 100;
		
		if( sequence > 0 ) {
			block++;
		}else if( sequence == 0 ) {
			sequence = 100;
		}
		block = (block == 0 ? 1 : block);
		
		// 여기까지 구해진 sequence가 마지막 받은 sequence 이므로 요청할 데이터는 한 시퀀스 앞이다.
		sequence = (sequence + 1) % 100;
		block = block + ((sequence + 1) / 100);

		hm.put("BLOCK", block);
		hm.put("SEQUENCE", sequence);
		
		return hm;
	}
}