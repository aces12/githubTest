/*
 * MasterExecutor.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_MasterCrt;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.util.StringUtil;
import kr.fujitsu.com.ffw.util.ZipUtil;

import org.apache.log4j.Logger;

import biz.cms_MasterCrtEx.MasterCrtExDAO;

/** 
 * MasterExecutor
 * A class to actually generate files(실제로 파일을 생성하는 클래스)
 * It generates master files (TBL), and compresses the generated files(Zip) to make a Zip file on FTP File Serve Path(마스터 파일(TBL)을 만들고, 만든 파일을 압축(ZIP)하여 FTP파일 서버 경로에 압축파일을 만든다).  
 * @created  on 1.0,  11/03/17
 * @created  khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by  
 */ 
public class MasterCrtExecutor {
	private static Logger logger = Logger.getLogger(MasterCrtClientAction.class);
	private List list170G = null;//180423 leeseungho 170at 생성방식 변경 
	
	
	public void setList170G(List list) {//180423 leeseungho 170at 생성방식 변경 
		this.list170G = list;
	}
	
	/**
	 * runMst - Generate Master File(마스터 파일 생성)
	 * @param m : Values to Generate Master File(마스터파일을 생성하기 위한 값)
	 * m[0] = trans_ymd
	 * m[1] = store_cd
	 * m[2] = trans_id
	 * m[3] = trans_seq
	 * m[4] = urgent_yn
	 * @return String : Directory in which master file has been generated(마스터파일이 생성된 디렉토리)
	 * @throws Exception
	 */
	public String runMst(Map map) throws Exception {
		// 마스터 배포 방식 변경 시작(20131125/조충연)
		/*
		String basePath = PropertyUtil.findProperty("stsys-property", "FILECRT_ROOT");	// 파일 생성 루트 
		String addPath  = ((String)map.get("urgent_yn")).equals("0") ? "deploy" : "urgent";
		String destPath = basePath+"/"+(String)map.get("trans_id")+"/"+(String)map.get("trans_ymd")+"/"+addPath;	// Path to which zipFile will be generated(zipFile을 만들 경로)
		String tempPath = basePath+"/"+(String)map.get("trans_id")+"/"+(String)map.get("trans_ymd")+"/"+addPath+"/"+(String)map.get("com_cd")+"_"+(String)map.get("store_cd");	// Path to which temporary tblFile will be generated(임시 tblFile을 만들 경로)
		String zipName = (String)map.get("com_cd")+"_"+(String)map.get("store_cd")+".zip";	// POS Code(점코드)
		System.out.println("[DEBUG] [tempPath]=" + tempPath);
		logger.info("[DEBUG] [tempPath]=" + tempPath);
		*/
		String basePath = PropertyUtil.findProperty("stsys-property", "FILECRT_ROOT");	// 파일 생성 루트
		String addPath = "";
		if(((String)map.get("urgent_yn")).equals("0")) {
			addPath = "deploy";
		}else if(((String)map.get("urgent_yn")).equals("1")) {
			addPath = "urgent1";
		}else if(((String)map.get("urgent_yn")).equals("2")) {
			addPath = "urgent2";
		}
		String rootPath = basePath+File.separator+(String)map.get("trans_id")+File.separator+(String)map.get("com_cd")+"_"+(String)map.get("store_cd");
		String destPath = rootPath+File.separator+addPath;	// Path to which zipFile will be generated(zipFile을 만들 경로)
		String tblPath = basePath+File.separator+(String)map.get("trans_id")+File.separator+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+File.separator+addPath+File.separator+"TBL";
		
		String pdaDestPath = basePath+File.separator+"PDA"+File.separator+"MST"+File.separator+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+File.separator+"deploy";
		String pdaPath = basePath+File.separator+"PDA"+File.separator+"MST"+File.separator+(String)map.get("com_cd")+"_"+(String)map.get("store_cd")+File.separator+"deploy"+File.separator+"TBL";
		String zipName = (String)map.get("com_cd")+"_"+(String)map.get("store_cd")+".zip";	// POS Code(점코드)
		MasterCrtDAO dao   = new MasterCrtDAO();
		List list = null;
		String conditionTP;
		String useYN;
		String today;
		boolean bSrcDelete = false;
		String rtnData = "ERROR";
		
		// 마스터 배포 방식 변경 끝(20131125/조충연)
		try {
			// 정기마스터/긴급마스터 구분
			String flag = (String)map.get("urgent_yn");
			
//			logger.info("★☆★11111★☆★");
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			today = Integer.toString(calendar.get(Calendar.YEAR)) + Integer.toString(calendar.get(Calendar.MONTH)) + Integer.toString(calendar.get(Calendar.DAY_OF_MONTH));
//			logger.info("★☆★22222★☆★");
			// 마스터 배포 방식 변경 시작(20131125/조충연)
			/*
			if(flag.equals("0")) {
				// 정기마스터

				// 대기계 마스터를 운영계 마스터로 통합 처리
				//generateMSTMERGE_ST2AT(); //MasterCrtClientAction 에서 처리되게 변경
	
				// TBLFILE 생성
				generateSTBDM170AT(map, tempPath);  // Store Master(점포마스터)
				generateSTBDM130AT(map, tempPath);  // Store PLU Master(점포PLU마스터)
				generateSTBDM270AT(map, tempPath);  // Store Receipt Master(점포영수증마스터)
				generateSTBDM271AT(map, tempPath);  // Receipt Format Group Master(영수증유형그룹마스터) 2013-08-16추가
				generateSTBDM272AT(map, tempPath);  // Receipt Format Master(영수증유형마스터) 2013-08-16추가
				generateSTBDM273AT(map, tempPath);  // KPS Format Group Master(주방프린터유형그룹마스터) 2013-08-16추가
				generateSTBDM274AT(map, tempPath);  // KPS Format Master(주방프린터유형마스터) 2013-08-16추가
				generateSTBDM275AT(map, tempPath);  // Account Slip Format Group Master(정산지인쇄유형그룹마스터) 2013-08-16추가
				generateSTBDM276AT(map, tempPath);  // Account Slip Format Master(정산지인쇄유형마스터) 2013-08-16추가
				generateSTBDM011AT(map, tempPath);  // Subtitute PLU Master(대체상품마스터) 2013-08-16추가
				generateSTBDM020AT(map, tempPath);  // Brand Master(브랜드마스터)

				generateSTBDM051AT(map, tempPath);  // Category 1st Master(카테고리대분류마스터)
				generateSTBDM052AT(map, tempPath);  // Category 2nd Master(카테고리중분류마스터)
				generateSTBDM053AT(map, tempPath);  // Category 3rd Master(카테고리소분류마스터)
	
				//행사관련
				generateSTBDM102AT(map, tempPath);  // Promotion Master(판촉행사마스터)
				generateSTBDM103AT(map, tempPath);  // Promotion Item Master(판촉행사상품마스터)
				generateSTBDM110AT(map, tempPath);  // Receipt Promotion Master(영수증행사마스터)
				generateSTBDM111AT(map, tempPath);  // Receipt Promotion Item Master(영수증행사상품마스터)
	
				//FFPLU
				//generateSTBDM140AT(map, tempPath);  // FF-Category(FF-카테고리)
				//generateSTBDM141AT(map, tempPath);  // FF-PLU

				generateSTBDM300AT(map, tempPath);  // Store Staff Master(점포사원마스터)
				generateSTBDM311AT(map, tempPath);  // Store Staff Auth Group Master(직원권한그룹마스터) 2013-08-16추가
				generateSTBDM312AT(map, tempPath);  // Store Staff Auth Master(직원권한마스터) 2013-08-16추가
				generateSTBDM350AT(map, tempPath);  // Common Code Master(공통코드마스터:본부)

				//generateSTBDM921AT(map, tempPath);  // Common Code Master(공통코드마스터:POS)
				generateSTBDM910AT(map, tempPath);  // Message Master(메시지마스터)
				generateSTBDM920AT(map, tempPath);  // Culture Master(문화마스터)
				generateSTBDM930AT(map, tempPath);  // Tax Master(세금마스터)
				generateSTBDM931AT(map, tempPath);  // Tax PLU Master(세금상품마스터)
				
				//멤버쉽관련
				generateSTMBS120AT(map, tempPath);  // Point Brand/PLU Master(포인트브랜드/상품마스터)
				generateSTMBS130AT(map, tempPath);  // Point Sale Amount Master(포인트소계마스터)
				generateSTMBS140AT(map, tempPath);  // Point Payment Master(포인트결제수단마스터)
				generateSTMBS170AT(map, tempPath);  // Point Priarity Master(포인트우선순위마스터)

				generateSTBDM640AT(map, tempPath);  // POS Master(POS마스터)
				generateSTBDM650AT(map, tempPath);  // POS Option Master(POS옵션마스터)
				generateSTBDM660AT(map, tempPath);  // POS Setting Master(POS설정정보마스터)
				generateSTBDM661AT(map, tempPath);  // Preset Master(단축키마스터)
				generateSTBDM662AT(map, tempPath);  // Reason Master(사유마스터)

				//POS설정관련
				generateSTBDM150AT(map, tempPath);  // Menu Header Master(메뉴헤더마스터)
				generateSTBDM151AT(map, tempPath);  // Menu Button Master(메뉴버튼마스터)

				generateSTBDM152AT(map, tempPath);  // Select Modifier Master(선택수정자마스터)
				generateSTBDM153AT(map, tempPath);  // Forced Modifier Master(강제수정자마스터)
				generateSTBDM154AT(map, tempPath);  // Combo Master(콤보마스터)
				
				generateSTBDM156AT(map, tempPath);  // Op. Button Group Master(조작버튼그룹마스터) 2013-08-16추가
				generateSTBDM157AT(map, tempPath);  // Op. Button Setup Master(조작버튼설정마스터) 2013-08-16추가
				generateSTBDM158AT(map, tempPath);  // SFKC Key Master(SFKC키마스터) 2013-08-16추가
				generateSTBDM159AT(map, tempPath);  // Cash Drawer Device Master(돈통마스터) 2013-08-16추가

				generateSTBDM160AT(map, tempPath);  // Floor Master(층마스터)
				generateSTBDM161AT(map, tempPath);  // Table Master(테이블마스터)
				generateSTBDM162AT(map, tempPath);  // Kitchen System Device Master(주방디바이스마스터) 2013-08-16추가
				generateSTBDM163AT(map, tempPath);  // PLU Kitchen System Device Master(상품주방디바이스마스터) 2013-08-16추가
				generateSTBDM164AT(map, tempPath);  // Order Slip Device Master(주문표디바이스마스터) 2013-08-16추가
				generateSTBDM165AT(map, tempPath);  // Order Slip Table Device Master(주문표테이블디바이스마스터) 2013-08-16추가

				//generateSTBDM310AT(map, tempPath);  // Store Staff Master(점포사원마스터)
				//generateSTBDM470AT(map, tempPath);  // Credit Card Master(신용카드마스터)
				//generateSTBDM620AT(map, tempPath);  // Coupon Master(쿠폰마스터)
				//generateSTBDM630AT(map, tempPath);  // Gift Card Master(상품권마스터)
				//generateSTBDM650AT(map, tempPath);  // Option Master(옵션마스터)
				//generateSTBDM911AT(map, tempPath);  // Form Info Master(폼정보마스터)
				//generateSTBDM921AT(map, tempPath);  // Culture Money Master(금종마스터)
			} else if(flag.equals("1")) {
				// 긴급마스터
				generateSTBDM130ST(map, tempPath);  // Good Master(상품마스터)
			}
			*/
/////////////////////////////////////////////////////////////////			
			if(flag.equals("0")) {	// 정기 배신
				bSrcDelete = false;
//				logger.info("★☆★33333★☆★");								
//				// 긴급배신(전체), 긴급배신(변경분) 폴더 파일 삭제처리
//				ZipUtil.deleteDir(rootPath+File.separator+"urgent1");
//				ZipUtil.deleteDir(rootPath+File.separator+"urgent2");
				
				// 마스터그룹코드 목록 조회
				List<Object> listMSTGRPSETT = null;
				Map<String, String> mapMSTGRPLIST = null;
				Map<String, String> mapMSTGRPSETT = null;
				list = dao.selMSTGRPLIST((String)map.get("COM_CD"));
				if (list ==null) {					
					logger.info("=======================================================");
					logger.info("selMSTGRPLIST null" + (String)map.get("store_cd")+"/"+(String)map.get("trans_seq")); //neo0531
					logger.info("=======================================================");
				}
				for(int i = 0;i < list.size();i++) {					
					mapMSTGRPLIST = (Map<String, String>)list.get(i);
					
//					logger.info("★☆★Master Group Code : " + (String)mapMSTGRPLIST.get("MST_GRP_CD") + "★☆★");
					
					// 해당 마스터그룹코드의 배포 옵션 조회 //CONDITION_TP , USE_YN
					listMSTGRPSETT = dao.selMSTGRPSETT((String)map.get("COM_CD"), (String)mapMSTGRPLIST.get("MST_GRP_CD"));
					if (listMSTGRPSETT ==null) {
						logger.info("=======================================================");
						logger.info("selMSTGRPSETT null" + (String)map.get("store_cd")+"/"+(String)map.get("trans_seq")); //neo0531
						logger.info("=======================================================");
					}
					mapMSTGRPSETT = (Map<String, String>)listMSTGRPSETT.get(0);		 //CONDITION_TP , USE_YN			
					
					conditionTP = (String)mapMSTGRPSETT.get("CONDITION_TP");
					useYN = (String)mapMSTGRPSETT.get("USE_YN");
					
					// 마스터그룹에 속한 테이블들의 이름을 가져와서  ArrayList에 Method 타입으로 추가한다.
					List<Object> listMSTGRPTBL = null;
					Map<String, String> mapMSTGRPTBL = null;
					listMSTGRPTBL = dao.selTBLBELONGTOMSTGRP(
							(String)map.get("COM_CD")
							, (String)mapMSTGRPLIST.get("MST_GRP_CD"));
					if (listMSTGRPTBL ==null) {
						logger.info("=======================================================");
						logger.info(" selTBLBELONGTOMSTGRP"+ (String)map.get("store_cd")+"/"+(String)map.get("trans_seq")); //neo0531
						logger.info("=======================================================");
					}
					List<Method> methodArray = new ArrayList<Method>();
					for(int j = 0;j < listMSTGRPTBL.size();j++) {
						mapMSTGRPTBL = (Map)listMSTGRPTBL.get(j);
						methodArray.add(((Object)this).getClass()
								.getDeclaredMethod("generate"+(String)mapMSTGRPTBL.get("TBL_NM")
										, Map.class, String.class));
//						logger.info("★☆★Table - " + "generate"+(String)mapMSTGRPTBL.get("TBL_NM") + "★☆★");
					}
					
					// 사용여부가 '사용'(useYN=1)이고 배신생성조건구분이 '미생성'(conditionTP=2)이 아니라면
					if( useYN.equals("1") ) {		
						if( conditionTP.equals("0") ) {			// 전체 생성(변경이 되었든 안되었든 무조건 생성)
//							logger.info("Master Group Code(" + (String)mapMSTGRPLIST.get("MST_GRP_CD") + ") must be created unconditionally ");
							for(int k = 0;k < methodArray.size();k++) {
								((Method)(methodArray.get(k))).invoke((Object)this, map, tblPath);		
//								logger.info("★☆★Called " + "generate"+(String)mapMSTGRPTBL.get("TBL_NM") + "★☆★");
							}
						}else if( conditionTP.equals("1") ) {	// 변경분 생성(변경 되었을 경우 생성)
//							logger.info("Master Group Code(" + (String)mapMSTGRPLIST.get("MST_GRP_CD") + ") is created when data is changed ");
							List<Object> chgList = dao.selMSTGRPCHG((String)map.get("COM_CD")
									, (String)map.get("STORE_CD")
									, (String)mapMSTGRPLIST.get("MST_GRP_CD"));
							
							if( chgList.size() > 0 ) {
								Map<String, String> chgMap = (Map<String, String>)chgList.get(0);
								String chgDT = (String)chgMap.get("CHG_DT");
								// 어제 이후로 변경된 건이라면 마스터 생성
								if( IsMSTGRPChanged(chgDT, -1) ) {
									for(int k = 0;k < methodArray.size();k++) {
										((Method)(methodArray.get(k))).invoke((Object)this, map, tblPath);
//										logger.info("★☆★Called " + "generate"+(String)mapMSTGRPTBL.get("TBL_NM") + "★☆★");
									}
								}
							}else {
								logger.info("Master Group Code(" + (String)mapMSTGRPLIST.get("MST_GRP_CD") + ") was not changed");
							}
						}
					}
				}
				// PDA 마스터 생성
				generateSTBDM130AT_PDA(map, pdaPath);
				ZipUtil.createZip(pdaDestPath, pdaPath, zipName, true);
			}else if(flag.equals("1")) {	// 긴급  전체(마스터그룹 전체)
				bSrcDelete = true;
				//logger.info("★☆★44444★☆★");	
				list = dao.selUGTMSTGRPALL((String)map.get("COM_CD"), (String)map.get("TRANS_YMD"), (String)map.get("STORE_CD"), flag, (String)map.get("TRANS_VER"));
				if (list ==null) {				
					logger.info("=======================================================");
					logger.info("selUGTMSTGRPALL null" + (String)map.get("store_cd")+"/"+(String)map.get("trans_seq")); //neo0531
					logger.info("=======================================================");
				}
				for(int i = 0;i < list.size();i++) {
					Map<String, String> m = (Map<String, String>)list.get(i);
					String tblNM = (String)m.get("TBL_NM");
					
					Object obj = this;
					Method method = obj.getClass().getDeclaredMethod("generate"+tblNM, Map.class, String.class);
					//logger.info("Called Method ["+(String)map.get("STORE_CD")+"]["+(String)map.get("TRANS_SEQ")+ "]"+"generate"+tblNM+")]");
					if (map == null){ 
						logger.info("=======================================================");
						logger.info("map == null============>1111");
						logger.info("=======================================================");
					}
					method.invoke(obj, map, tblPath);
					
				}
				
			}else if(flag.equals("2")) {	// 긴급 변경(변경된 row)
				bSrcDelete = true;
//				logger.info("★☆★55555★☆★");	
				list = dao.selUGTMSTGRPALL((String)map.get("COM_CD"), (String)map.get("TRANS_YMD"), (String)map.get("STORE_CD"), flag, (String)map.get("TRANS_VER"));
				if (list ==null) {		
					logger.info("=======================================================");
					logger.info("selUGTMSTGRPALL null" + (String)map.get("store_cd")+"/"+(String)map.get("trans_seq")); //neo0531
					logger.info("=======================================================");	
				}
				for(int i = 0;i < list.size();i++) {
					// 상품 마스터 그룹은 변경된row만 생성, 나머지 마스터 그룹은 긴급 전체와 똑같이 생성함
					Map<String, String> m = (Map<String, String>)list.get(i);
					String tblNM = (String)m.get("TBL_NM");
						
					Object obj = this;
					Method method = obj.getClass().getDeclaredMethod("generate"+tblNM, Map.class, String.class);
					//logger.info("Called Method [generate"+tblNM+"()]");
					if (map == null){ 
						logger.info("=======================================================");
						logger.info("map == null============>2222");
						logger.info("=======================================================");
					}
					method.invoke(obj, map, tblPath);
				}
			}
			// 마스터 배포 방식 변경 끝(20131125/조충연)
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			// 마스터 배포 방식 변경 시작(20131204/조충연)
			// Generate ZIPFILE(ZIPFILE 생성)
			//ZipUtil.createZip(destPath, tblPath, zipName);
			ZipUtil.createZip(destPath, tblPath, zipName, bSrcDelete);
			// 마스터 배포 방식 변경 끝(20131204/조충연)
			logger.info("["+(String)map.get("store_cd")+"/"+(String)map.get("trans_seq")+"] ZIP Filename : "+zipName+" is created.*");
			
			rtnData = destPath+File.separator+zipName;
		} catch (Exception e) {
			//  [ERROR]java.lang.reflect.InvocationTargetException** MSG:null
			logger.info("[ERROR]" + e +"** MSG:"+e.getMessage());
//			ByteArrayOutputStream out = new ByteArrayOutputStream();
//			PrintStream printStream = new PrintStream(out); 
//			logger.info("[ERROR]" + e +"** MSG:"+ printStream);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			PrintWriter pw1 = new PrintWriter(new File("exception.log"));
			e.printStackTrace(pw1);
			pw1.close();
		}
		return rtnData;
	}
	
	private boolean IsMSTGRPChanged(String chgDT, int day) {
		boolean bRtn = false;
		try {
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			
			String toDay = sdf.format(calendar.getTime());
			
			calendar.add(Calendar.DATE, day);
			String stdDate = sdf.format(calendar.getTime());
			
			// 변경 날짜가 어제 이후라면 생성
			if( stdDate.compareTo(chgDT) <= 0 ) {
				bRtn = true;
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return bRtn;
	}
	
    /**
     * runFFImg - Generate FF-PLU Image Compression File(FF-PLU이미지 압축파일 생성)
	 * @param m : Values to Generate FF-PLU Image Compression File(FF-PLU 이미지 압축파일을 생성하기 위한 값)
	 * m[0] = trans_ymd
	 * m[1] = store_cd
	 * m[2] = trans_id
	 * m[3] = trans_seq
	 * m[4] = urgent_yn
	 * @return String : 이미지 압축파일이 생성된 디렉토리
	 * @throws Exception
     */
	public String runFFImg(Map map) throws Exception {
		String basePath = PropertyUtil.findProperty("stsys-property", "FILECRT_ROOT");	// 파일 생성 루트 
		String imgPath  = PropertyUtil.findProperty("stsys-property", "FFIMG_DIR");	// Path of FF-PLU Image File(FF-PLU 이미지파일 경로)
		String path     = basePath+File.separator+(String)map.get("trans_id")+File.separator+(String)map.get("trans_ymd");
		String zipName  = "ffplu."+(String)map.get("store_cd")+".zip";	// POS Code(점코드)
		String rtnData = "ERROR";
		
		try {
			// FF-PLU 이미지파일리스트 생성
			MasterCrtDAO dao   = new MasterCrtDAO();
			List fileList = dao.selectFFImg(map, imgPath);

			// ZIPFILE 생성
			if(fileList.size() > 0) {
				ZipUtil.createImgZip(path, fileList, zipName);
				logger.info("[storecd : "+(String)map.get("store_cd")+"/seq"+(String)map.get("trans_seq")+"] FFIMG ZIP Filename : "+zipName+" done");
			} else {
				logger.info("[storecd : "+(String)map.get("store_cd")+"/seq"+(String)map.get("trans_seq")+"] FFIMG ZIP Filename : "+zipName+" is not created. There are no FF-PLU ImageFiles.");
			}
			
			rtnData = path+"/"+zipName;
			
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
		}
		return rtnData;
	}

	/**
	 * 1. generateSTBDM170AT - Generate Store Master Inquirty Results as TBL File(점포마스터 조회 결과를 TBL파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateMSTMERGE_ST2AT() throws Exception {
		try {
		MasterCrtDAO dao   = new MasterCrtDAO();
		int max = 0;

			String retMsg = dao.executeMasterProcedure("SP_MSTMERGE_ST2AT");
			logger.info("[DEBUG] [SP_MSTMERGE_ST2AT]result=" + retMsg);
			System.out.println("[DEBUG] [SP_MSTMERGE_ST2AT]result=" + retMsg);
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 1. generateSTBDM170AT - Generate Store Master Inquirty Results as TBL File(점포마스터 조회 결과를 TBL파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */  
	private int generateSTBDM170AT(Map m, String path) throws Exception {
		try {
			StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM170AT.tbl";
		int max = 0;

			// 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("STORE\r\n");
			sb.append("STORE|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			//180423 leeseungho 170at 생성방식 변경	//List list = dao.selectGlobalMaster(m, "SEL_STBDM170AT", max);			
			List list = null;
			if( ("0".equals((String)m.get("urgent_yn")))
				&& ("1".equals((String)m.get("trans_seq")))
				&& (this.list170G.size() != 0) ){
				list = list170G;
				logger.info("["+(String)m.get("store_cd")+"/"+(String)m.get("trans_seq")+"] read list170G");
			}else{
				list = dao.selectGlobalMaster(m, "SEL_STBDM170AT", max);
			}
			System.out.println("[DEBUG] list count:" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("store_cd") + "|" );
				sb.append( (String)map.get("store_owner") + "|" );
				sb.append( (String)map.get("store_nm") + "|" );
				sb.append( (String)map.get("store_addr") + "|" );
				sb.append( (String)map.get("store_biz_no") + "|" );
				sb.append( (String)map.get("store_tel") + "|" );
				sb.append( (String)map.get("store_pos_qty") + "|" );
				sb.append( (String)map.get("hq_send_ip") + "|" );
				sb.append( (String)map.get("hq_recv_ip") + "|" );
				sb.append( (String)map.get("BRAND_TP") + "|" );			//20170721 리브랜딩 점포구분값 추가 ksn
				sb.append( (String)map.get("ZIP_CD") + "|" );			//20180404 점포 우편번호 추가 ksn
				sb.append( (String)map.get("PROP_VAL") + "\r\n" );		//20180607 점포 카드VAN 가맹점번호 추가 ksn (도서/문화비 추가공제 대응)
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/"+(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/"+(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	private int generateSTBDM130AT_PDA(Map m, String path) throws Exception {
		
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao = new MasterCrtDAO();
		String fileName = "STBDM130AT.tbl";
		boolean flag = true;
		int max = 0;
		
			while(flag) {
				List<Object> list = null;
				
				list = dao.selectMaster(m, "SEL_STBDM130AT_PDA", max);
				if(list.size() > 0) {
					if(max > 0)
						sb.setLength(0);
					
					for(int i = 0;i < list.size();i++) {
						Map<String, String> map = (Map<String, String>)list.get(i);
						sb.append( (String)map.get("plu_cd") + "|" );
						sb.append( (String)map.get("plu_snm") + "|" );
						sb.append( (String)map.get("item_price") + "|");
						sb.append( (String)map.get("sal_enbl_yn") + "\r\n" );
					}
					if (max == 0)
					{
						// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
						if(sb.length()>0) {
							ZipUtil.createFileUTF16(sb, path, fileName, false);
							logger.info("["+(String)m.get("store_cd")+"/"+(String)m.get("trans_seq")+"] "+fileName+" done");
						} else {
							ZipUtil.createFileUTF16(sb, path, fileName, false);
							logger.info("["+(String)m.get("store_cd")+"/"+(String)m.get("trans_seq")+"] "+fileName+" has no data.");
						}
					}
					else
					{
						// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 추가)
						ZipUtil.createFileUTF16(sb, path, fileName, true);
//						logger.info("["+(String)m.get("store_cd")+"] "+fileName+" is appended.");
					}					

					max++;
				}else {
					if( max == 0 ) {
						ZipUtil.createFileUTF16(sb, path, fileName, false);
//						logger.info("["+(String)m.get("store_cd")+"] "+fileName+" is appended.");
					}
					
					flag = false;
				}
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 4. generateSTBDM130AT - Generate Good Master Inquiry Results as File(상품마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM130AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM130AT.tbl";
		boolean flag = true;
//		throw new  Exception("999");
		int max = 0;			
			//throw new  Exception("");
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PLU\r\n");
			sb.append("PLU|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
						
			while(flag) {
//				List<Object> list = dao.selectMaster(m, "SEL_STBDM130AT", max);
				List<Object> list = null;
				if( ((String)m.get("URGENT_YN")).equals("2") ) {
					list = dao.selectMaster(m, "SEL_STBDM130AT2", max);
				}else {
					list = dao.selectMaster(m, "SEL_STBDM130AT", max);
				}
				
				System.out.println("[DEBUG] list count:" + list.size());
				if(list.size() > 0 ) {
					if (max > 0)
						sb.setLength(0);
					
					for (int i=0; i < list.size(); i++) {
						Map<String, String> map = (Map<String, String>)list.get(i);
						sb.append( (String)map.get("plu_cd") + "|" );
						sb.append( (String)map.get("cate_id") + "|" );
						sb.append( (String)map.get("grp_id") + "|" );
						sb.append( (String)map.get("sgrp_id") + "|" );
						sb.append( (String)map.get("brand_id") + "|" );
						sb.append( (String)map.get("plu_snm") + "|" );
						sb.append( (String)map.get("plu_nm") + "|" );
						sb.append( (String)map.get("item_price") + "|" );
						sb.append( (String)map.get("item_price") + "|" );
						sb.append( (String)map.get("item_ty") + "|" );
						sb.append( (String)map.get("item_tax_id") + "|" );
						sb.append( (String)map.get("btl_plu_cd") + "|" );
						sb.append( (String)map.get("item_oprc") + "|" );
						sb.append( (String)map.get("sale_stop_yn") + "|" );
						sb.append( (String)map.get("sale_unit_qty") + "|" );
						sb.append( (String)map.get("dc_yn") + "|" );
						sb.append( (String)map.get("save_yn") + "|" );
						sb.append( (String)map.get("prc_chg_yn") + "|" );
						sb.append( (String)map.get("service_yn") + "|" );
						sb.append( (String)map.get("pack_yn") + "|" );
						sb.append( (String)map.get("ks_yn") + "|" );
						sb.append( (String)map.get("delivery_yn") + "|" );
						//sb.append( (String)map.get("svcchg_yn") + "|\r\n" );
						sb.append( (String)map.get("svcchg_yn") + "|" );
						//상품마스터 신규 추가 컬럼
						sb.append( (String)map.get("buy_yn") + "|" );
						sb.append( (String)map.get("youth_sale_yn") + "|" );
						sb.append( (String)map.get("sales_type") + "|" );
						sb.append( (String)map.get("pay_type") + "|" );
						sb.append( (String)map.get("ffplu_yn") + "|" );
						sb.append( (String)map.get("timebarcode_ty") + "|" );
						sb.append( (String)map.get("service_item_ty") + "|" );
						sb.append( (String)map.get("medicine_yn") + "|" );
						sb.append( (String)map.get("item_cd") + "|" );
						sb.append( (String)map.get("cash_rec_yn") + "|" );
						sb.append( (String)map.get("repr_ven_cd") + "|" ); 
						sb.append( (String)map.get("bot_exist") + "|" );
						sb.append( (String)map.get("bot_guaranty") + "|\r\n" ); 
					}
					if (max == 0)
					{
						// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
						if(sb.length()>0) {
							ZipUtil.createFileUTF16(sb, path, fileName, false);
							logger.info("["+(String)m.get("store_cd")+"/"+(String)m.get("trans_seq")+"] "+fileName+" done");
						} else {
							ZipUtil.createFileUTF16(sb, path, fileName, false);
							logger.info("["+(String)m.get("store_cd")+"/"+(String)m.get("trans_seq")+"] "+fileName+" has no data.");
						}
					}
					else
					{
						// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 추가)
						ZipUtil.createFileUTF16(sb, path, fileName, true);
//						logger.info("["+(String)m.get("store_cd")+"] "+fileName+" is appended.");
					}					

					max++;
				} else {
					if( max == 0 ) {
						ZipUtil.createFileUTF16(sb, path, fileName, false);
//						logger.info("["+(String)m.get("store_cd")+"] "+fileName+" is appended.");
					}
					
					flag = false;
				}
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e +"** MSG:"+e.getMessage());
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

    /**
     * 4. generateSTBDM130ST - Generate Good Master Inquirty Results as File(상품마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM130ST(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM130AT.tbl";
		int max = 0;

		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PLU\r\n");
			sb.append("PLU|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectMaster(m, "SEL_STBDM130AT", max);
			System.out.println("[DEBUG] list count:" + list.size());
			if(list.size() > 0 ) {
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("plu_cd") + "|" );
					sb.append( (String)map.get("cate_id") + "|" );
					sb.append( (String)map.get("grp_id") + "|" );
					sb.append( (String)map.get("sgrp_id") + "|" );
					sb.append( (String)map.get("brand_id") + "|" );
					sb.append( (String)map.get("plu_snm") + "|" );
					sb.append( (String)map.get("plu_nm") + "|" );
					sb.append( (String)map.get("item_price") + "|" );
					sb.append( (String)map.get("item_price") + "|" );
					sb.append( (String)map.get("item_ty") + "|" );
					sb.append( (String)map.get("item_tax_id") + "|" );
					sb.append( (String)map.get("btl_plu_cd") + "|" );
					sb.append( (String)map.get("item_oprc") + "|" );
					sb.append( (String)map.get("sale_stop_yn") + "|" );
					sb.append( (String)map.get("sale_unit_qty") + "|" );
					sb.append( (String)map.get("dc_yn") + "|" );
					sb.append( (String)map.get("save_yn") + "|" );
					sb.append( (String)map.get("prc_chg_yn") + "|" );
					sb.append( (String)map.get("service_yn") + "|" );
					sb.append( (String)map.get("pack_yn") + "|" );
					sb.append( (String)map.get("ks_yn") + "|" );
					sb.append( (String)map.get("delivery_yn") + "|" );
					//sb.append( (String)map.get("svcchg_yn") + "|\r\n" );
					sb.append( (String)map.get("svcchg_yn") + "|" );
					//상품마스터 신규 추가 컬럼
					sb.append( (String)map.get("buy_yn") + "|" );
					sb.append( (String)map.get("youth_sale_yn") + "|" );
					sb.append( (String)map.get("sales_type") + "|" );
					sb.append( (String)map.get("pay_type") + "|" );
					sb.append( (String)map.get("ffplu_yn") + "|" );
					sb.append( (String)map.get("timebarcode_ty") + "|" );
					sb.append( (String)map.get("service_item_ty") + "|" );
					sb.append( (String)map.get("medicine_yn") + "|" );
					sb.append( (String)map.get("item_cd") + "|" );
					sb.append( (String)map.get("cash_rec_yn") + "|\r\n" );
				}
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(sb.length()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/"+(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false); //생성 건수가 없어도 압축파일생성을 위해 0바이트 파일 생성
				logger.info("["+(String)m.get("store_cd")+"/"+(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM020AT - Generate Brand Master Inquirty Results as File(브랜드마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM020AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM020AT.tbl";
		boolean flag = true;
		int max = 0;
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("BRAND_MST\r\n");
			sb.append("BRAND_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM020AT", max);
			System.out.println("[DEBUG] list count:" + list.size());
			if(list.size() > 0 ) {
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("brand_id") + "|" );
					sb.append( (String)map.get("brand_nm") + "|\r\n" );
				}
			}
	
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(sb.length()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/"+(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/"+(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 4. generateSTBDM051AT - Generate Category Level1 Master Inquirty Results as File(카테고리대분류마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM051AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM051AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("LARGE_CLASS_MST\r\n");
			sb.append("LARGE_CLASS_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
		    
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM051AT", max);
			System.out.println("[DEBUG] list count:" + list.size());
			if(list.size() > 0 ) {
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("cate_id") + "|" );
					sb.append( (String)map.get("cate_name") + "|\r\n" );
				}
			}
	
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(sb.length()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 4. generateSTBDM052AT - Generate Category Level2 Master Inquirty Results as File(카테고리중분류마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM052AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM052AT.tbl";
		//boolean flag = true;
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("MID_CLASS_MST\r\n");
			sb.append("MID_CLASS_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
		    
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM052AT", max);
			System.out.println("[DEBUG] list count:" + list.size());
			if(list.size() > 0 ) {
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("grp_id") + "|" );
					sb.append( (String)map.get("cate_id") + "|" );
					sb.append( (String)map.get("grp_name") + "|\r\n" );
				}
			}
	
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(sb.length()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 4. generateSTBDM052AT - Generate Category Level3 Master Inquirty Results as File(카테고리소분류마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM053AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM053AT.tbl";
		//boolean flag = true;
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("SMALL_CLASS_MST\r\n");
			sb.append("SMALL_CLASS_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
		    
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM053AT", max);
			System.out.println("[DEBUG] list count:" + list.size());
			if(list.size() > 0 ) {
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("sgrp_id") + "|" );
					sb.append( (String)map.get("cate_id") + "|" );
					sb.append( (String)map.get("grp_id") + "|" );
					sb.append( (String)map.get("sgrp_name") + "|\r\n" );
				}
			}
	
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(sb.length()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	     * 5. generateSTBDM270AT - Generate Store Receipt Master Inquirty Results as File(점포영수증마스터 조회 결과를 파일로 생성)
		 * @param m 
		 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
		 * @return
		 * @throws Exception
		 */
		private int generateSTBDM270AT(Map m, String path) throws Exception {
			try {
			StringBuffer sb = new StringBuffer();
			MasterCrtDAO dao   = new MasterCrtDAO();
			String fileName = "STBDM270AT.tbl";
			int max = 0;
			
			    // 마스터 배포 방식 변경 시작(20131202/조충연)
			    //sb.append("PRTMSG\r\n");
				sb.append("PRTMSG|" + (String)m.get("trans_ver") + "\r\n");
				// 마스터 배포 방식 변경 끝(20131202/조충연)
			    
				List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM270AT", max);
				System.out.println("[DEBUG] SEL_STBDM270AT list=" + list.size());
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)m.get("store_cd") + "|" );
					sb.append( (String)map.get("pos_no") + "|" );
					sb.append( (String)map.get("use_id") + "|" );
					sb.append( (String)map.get("prt_seq") + "|" );
					sb.append( (String)map.get("prt_id") + "|" );
					sb.append( (String)map.get("enlarge_id") + "|" );
					sb.append( (String)map.get("char_string") + "|\r\n" );
				}
				// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
				if(list.size()>0) {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
				} else {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
				}
			} catch (Exception e) {
				logger.info("[ERROR]" + e);
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				String sStackTrace =sw.toString();
				logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
				throw e;
			}
			return 0;
		}

		/**
	     * 5. generateSTBDM271AT - Generate Receipt Format Group Master Inquirty Results as File(영수증유형그룹마스터 조회 결과를 파일로 생성)
		 * @param m 
		 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
		 * @return
		 * @throws Exception
		 */
		private int generateSTBDM271AT(Map m, String path) throws Exception {
			try {
			StringBuffer sb = new StringBuffer();
			MasterCrtDAO dao   = new MasterCrtDAO();
			String fileName = "STBDM271AT.tbl";
			int max = 0;
			
			    // 마스터 배포 방식 변경 시작(20131202/조충연)
			    //sb.append("RECEIPT_FORMAT_GROUP\r\n");
				sb.append("RECEIPT_FORMAT_GROUP|" + (String)m.get("trans_ver") + "\r\n");
				// 마스터 배포 방식 변경 끝(20131202/조충연)			    
				List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM271AT", max);
				System.out.println("[DEBUG] SEL_STBDM271AT list=" + list.size());
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("receipt_format_group") + "|" );
					sb.append( (String)map.get("receipt_format_group_nm") + "|\r\n" );
				}
				// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
				if(list.size()>0) {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
				} else {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
				}
			} catch (Exception e) {
				logger.info("[ERROR]" + e);
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				String sStackTrace =sw.toString();
				logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
				throw e;
			}
			return 0;
		}

		/**
	     * 5. generateSTBDM272AT - Generate Receipt Format Master Inquirty Results as File(영수증유형마스터 조회 결과를 파일로 생성)
		 * @param m 
		 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
		 * @return
		 * @throws Exception
		 */
		private int generateSTBDM272AT(Map m, String path) throws Exception {
			try {
			StringBuffer sb = new StringBuffer();
			MasterCrtDAO dao   = new MasterCrtDAO();
			String fileName = "STBDM272AT.tbl";
			int max = 0;
			
			    // 마스터 배포 방식 변경 시작(20131202/조충연)
			    //sb.append("RECEIPT_FORMAT\r\n");
				sb.append("RECEIPT_FORMAT|" + (String)m.get("trans_ver") + "\r\n");
				// 마스터 배포 방식 변경 끝(20131202/조충연)			    
			    
				List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM272AT", max);
				System.out.println("[DEBUG] SEL_STBDM272AT list=" + list.size());
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("receipt_format_group") + "|" );
					sb.append( (String)map.get("receipt_format_flag") + "|" );
					sb.append( (String)map.get("seq_no") + "|" );
					sb.append( (String)map.get("align_flag") + "|" );
					sb.append( (String)map.get("size_flag") + "|" );
					sb.append( (String)map.get("receipt_format_tag") + "|\r\n" );
				}
				// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
				if(list.size()>0) {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
				} else {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
				}
			} catch (Exception e) {
				logger.info("[ERROR]" + e);
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				String sStackTrace =sw.toString();
				logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
				throw e;
			}
			return 0;
		}

		/**
	     * 5. generateSTBDM273AT - Generate KPS Format Group Master Inquirty Results as File(주방프린터유형그룹마스터 조회 결과를 파일로 생성)
		 * @param m 
		 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
		 * @return
		 * @throws Exception
		 */
		private int generateSTBDM273AT(Map m, String path) throws Exception {
			try {
			StringBuffer sb = new StringBuffer();
			MasterCrtDAO dao   = new MasterCrtDAO();
			String fileName = "STBDM273AT.tbl";
			int max = 0;
			
			    // 마스터 배포 방식 변경 시작(20131202/조충연)
			    //sb.append("KPS_FORMAT_GROUP\r\n");
				sb.append("KPS_FORMAT_GROUP|" + (String)m.get("trans_ver") + "\r\n");
				// 마스터 배포 방식 변경 끝(20131202/조충연)
				List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM273AT", max);
				System.out.println("[DEBUG] SEL_STBDM273AT list=" + list.size());
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("kps_format_group") + "|" );
					sb.append( (String)map.get("kps_format_group_nm") + "|\r\n" );
				}
				// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
				if(list.size()>0) {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
				} else {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
				}
			} catch (Exception e) {
				logger.info("[ERROR]" + e);
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				String sStackTrace =sw.toString();
				logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
				throw e;
			}
			return 0;
		}

		/**
	     * 5. generateSTBDM274AT - Generate KPS Format Master Inquirty Results as File(주방프린터유형마스터 조회 결과를 파일로 생성)
		 * @param m 
		 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
		 * @return
		 * @throws Exception
		 */
		private int generateSTBDM274AT(Map m, String path) throws Exception {
			try {
				StringBuffer sb = new StringBuffer();
			
			MasterCrtDAO dao   = new MasterCrtDAO();
			String fileName = "STBDM274AT.tbl";
			int max = 0;
			
			    // 마스터 배포 방식 변경 시작(20131202/조충연)
			    //sb.append("KPS_FORMAT\r\n");
				sb.append("KPS_FORMAT|" + (String)m.get("trans_ver") + "\r\n");
				// 마스터 배포 방식 변경 끝(20131202/조충연)
				List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM274AT", max);
				System.out.println("[DEBUG] SEL_STBDM274AT list=" + list.size());
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("kps_format_group") + "|" );
					sb.append( (String)map.get("kps_format_flag") + "|" );
					sb.append( (String)map.get("seq_no") + "|" );
					sb.append( (String)map.get("align_flag") + "|" );
					sb.append( (String)map.get("size_flag") + "|" );
					sb.append( (String)map.get("kps_format_tag") + "|\r\n" );
				}
				// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
				if(list.size()>0) {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
				} else {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
				}
			} catch (Exception e) {
				logger.info("[ERROR]" + e);
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				String sStackTrace =sw.toString();
				logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
				throw e;
			}
			return 0;
		}

		/**
	     * 5. generateSTBDM275AT - Generate Account Slip Format Group Master Inquirty Results as File(정산지인쇄유형그룹마스터 조회 결과를 파일로 생성)
		 * @param m 
		 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
		 * @return
		 * @throws Exception
		 */
		private int generateSTBDM275AT(Map m, String path) throws Exception {
			try {
			StringBuffer sb = new StringBuffer();
			MasterCrtDAO dao   = new MasterCrtDAO();
			String fileName = "STBDM275AT.tbl";
			int max = 0;
			
			    // 마스터 배포 방식 변경 시작(20131202/조충연)
			    //sb.append("ACCOUNT_SLIP_FORMAT_GROUP\r\n");
				sb.append("ACCOUNT_SLIP_FORMAT_GROUP|" + (String)m.get("trans_ver") + "\r\n");
				// 마스터 배포 방식 변경 끝(20131202/조충연)
				List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM275AT", max);
				System.out.println("[DEBUG] SEL_STBDM275AT list=" + list.size());
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("account_slip_format_group") + "|" );
					sb.append( (String)map.get("account_slip_format_group_nm") + "|\r\n" );
				}
				// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
				if(list.size()>0) {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
				} else {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
				}
			} catch (Exception e) {
				logger.info("[ERROR]" + e);
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				String sStackTrace =sw.toString();
				logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
				throw e;
			}
			return 0;
		}

		/**
	     * 5. generateSTBDM276AT - Generate Account Slip Format Master Inquirty Results as File(정산지인쇄유형마스터 조회 결과를 파일로 생성)
		 * @param m 
		 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
		 * @return
		 * @throws Exception
		 */
		private int generateSTBDM276AT(Map m, String path) throws Exception {
			try {
			StringBuffer sb = new StringBuffer();
			MasterCrtDAO dao   = new MasterCrtDAO();
			String fileName = "STBDM276AT.tbl";
			int max = 0;
			
			    // 마스터 배포 방식 변경 시작(20131202/조충연)
			    //sb.append("ACCOUNT_SLIP_FORMAT\r\n");
				sb.append("ACCOUNT_SLIP_FORMAT" + "|" + (String)m.get("trans_ver") + "\r\n");
				// 마스터 배포 방식 변경 끝(20131202/조충연)
				List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM276AT", max);
				System.out.println("[DEBUG] SEL_STBDM276AT list=" + list.size());
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("account_slip_format_group") + "|" );
					sb.append( (String)map.get("account_slip_type") + "|" );
					sb.append( (String)map.get("seq_no") + "|" );
					sb.append( (String)map.get("account_code") + "|" );
					sb.append( (String)map.get("print_flag") + "|\r\n" );
				}
				// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
				if(list.size()>0) {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
				} else {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
				}
			} catch (Exception e) {
				logger.info("[ERROR]" + e);
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				String sStackTrace =sw.toString();
				logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
				throw e;
			}
			return 0;
		}

		/**
	     * 5. generateSTBDM011AT - Generate Substitution PLU Master Inquirty Results as File(대체상품마스터 조회 결과를 파일로 생성)
		 * @param m 
		 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
		 * @return
		 * @throws Exception
		 */
		private int generateSTBDM011AT(Map m, String path) throws Exception {
			try {
			StringBuffer sb = new StringBuffer();
			MasterCrtDAO dao   = new MasterCrtDAO();
			String fileName = "STBDM011AT.tbl";
			int max = 0;
			
			    // 마스터 배포 방식 변경 시작(20131202/조충연)
			    //sb.append("SUBSTITUTION_PLU\r\n");
				sb.append("SUBSTITUTION_PLU|" + (String)m.get("trans_ver") + "\r\n");
				// 마스터 배포 방식 변경 끝(20131202/조충연)
				List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM011AT", max);
				System.out.println("[DEBUG] SEL_STBDM011AT list=" + list.size());
				for (int i=0; i < list.size(); i++) {
					Map<String, String> map = (Map<String, String>)list.get(i);
					sb.append( (String)map.get("plu_cd") + "|" );
					sb.append( (String)map.get("substitution_plu_cd") + "|" );
					sb.append( (String)map.get("combo_up_charge_amt") + "|\r\n" );
				}
				// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
				if(list.size()>0) {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
				} else {
					ZipUtil.createFileUTF16(sb, path, fileName, false);
					logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
				}
			} catch (Exception e) {
				logger.info("[ERROR]" + e);
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				String sStackTrace =sw.toString();
				logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
				throw e;
			}
			return 0;
		}

	/**
	 * 4. generateSTBDM102AT - Generate Promotion Master Inquirty Results as File(행사마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM102AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM102AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PROMH\r\n");
			sb.append("PROMH|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM102AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("prom_evt_cd") + "|" );
				sb.append( (String)map.get("prom_evt_nm") + "|" );
				sb.append( (String)map.get("prom_evt_symd") + "|" );
				sb.append( (String)map.get("prom_evt_eymd") + "|" );
				sb.append( (String)map.get("prom_evt_shh") + "|" );
				sb.append( (String)map.get("prom_evt_ehh") + "|" );
				sb.append( (String)map.get("prom_evt_aday_yn") + "|" );
				sb.append( (String)map.get("prom_evt_seq") + "|" );
				sb.append( (String)map.get("prom_evt_ty") + "|" );
				sb.append( (String)map.get("prom_evt_cnd") + "|" );
				sb.append( (String)map.get("prom_evt_coupon") + "|" );
				sb.append( (String)map.get("prom_evt_org_id") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg1_ty") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg1_amt") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg1_dc") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg2_ty") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg2_amt") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg2_dc") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg3_ty") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg3_amt") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg3_dc") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg4_ty") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg4_amt") + "|" );
				sb.append( (String)map.get("prom_evt_org_cg4_dc") + "|" );
				sb.append( (String)map.get("prom_evt_desc") + "|" );
				sb.append( (String)map.get("prom_evt_dc_div") + "|" );
				sb.append( (String)map.get("prom_evt_amt") + "|" );
				sb.append( (String)map.get("filler1") + "|" );
				sb.append( (String)map.get("filler2") + "|" );
				sb.append( (String)map.get("filler3") + "|" );
				sb.append( (String)map.get("filler4") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 4. generateSTBDM103AT - Generate Promotion PLU Master Inquirty Results as File(행사상품마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM103AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM103AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PROMD\r\n");
			sb.append("PROMD|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM103AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("plu_cd") + "|" );
				sb.append( (String)map.get("prom_evt_cd") + "|" );
				sb.append( (String)map.get("item_org_grp") + "|" );
				sb.append( (String)map.get("dc_price") + "|" );
				sb.append( (String)map.get("prom_evt_ty") + "|" );
				sb.append( (String)map.get("prom_evt_div") + "|" );
				sb.append( (String)map.get("obj_reg_ty") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM104AT - Generate Promotion Card Master Inquirty Results as File(행사카드마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM104AT(Map<String, String> m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao = new MasterCrtDAO();
		String fileName = "STBDM104AT.tbl";
		int max = 0;
		
			sb.append("PROMCARD|" + (String)m.get("trans_ver") + "\r\n");
			
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM104AT", max);
			for(int i = 0;i < list.size();i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("prom_evt_cd") + "|" );		// 행사코드
				sb.append( (String)map.get("prefix_st_no") + "|" );		// 카드BIN시작
				sb.append( (String)map.get("prefix_end_no") + "|" );	// 카드BIN끝
				sb.append( "|" );										// FILLER1
				sb.append( "|" );										// FILLER2
				sb.append( "|" );										// FILLER3
				sb.append( "|" );										// FILLER4
				sb.append( "|\r\n" );									// FILLER5
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		
		return 0;
	}

	/**
	 * 4. generateSTBDM110AT - Generate Receipt Promotion Master Inquirty Results as File(영수증행사마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM110AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM110AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PRTPROMH\r\n");
			sb.append("PRTPROMH|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM110AT", max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("rect_evt_cd") + "|" );
				sb.append( (String)map.get("rect_evt_nm") + "|" );
				sb.append( (String)map.get("rect_evt_symd") + "|" );
				sb.append( (String)map.get("rect_evt_eymd") + "|" );
				sb.append( (String)map.get("rect_evt_shh") + "|" );
				sb.append( (String)map.get("rect_evt_ehh") + "|" );
				sb.append( (String)map.get("rect_evt_aday_yn") + "|" );
				sb.append( (String)map.get("rect_evt_ty") + "|" );
				sb.append( (String)map.get("rect_evt_amt") + "|" );
				sb.append( (String)map.get("rect_evt_kind") + "|" );
				sb.append( (String)map.get("rect_prt_msg1") + "|" );
				sb.append( (String)map.get("rect_prt_msg2") + "|" );
				sb.append( (String)map.get("rect_prt_msg3") + "|" );
				sb.append( (String)map.get("rect_prt_msg4") + "|" );
				sb.append( (String)map.get("rect_prt_msg5") + "|" );
				sb.append( (String)map.get("rect_prt_msg6") + "|" );
				sb.append( (String)map.get("rect_prt_msg7") + "|" );
				sb.append( (String)map.get("rect_prt_msg8") + "|" );
				sb.append( (String)map.get("rect_prt_msg9") + "|" );
				sb.append( (String)map.get("rect_prt_msg10") + "|" );
				sb.append( (String)map.get("filler1") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 4. generateSTBDM110AT - Generate Receipt Promotion PLU Master Inquirty Results as File(영수증행사상품마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM111AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM111AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PRTPROMD\r\n");
			sb.append("PRTPROMD|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM111AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
				sb.append( (String)map.get("plu_cd") + "|" );
				sb.append( (String)map.get("rect_evt_cd") + "|" );
				sb.append( (String)map.get("obj_reg_ty") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 4. generateSTBDM112AT - Generate Receipt Promotion PLU Master Inquirty Results as File(영수증행사카드마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM112AT(Map<String, String> m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM112AT.tbl";
		int max = 0;
		
			sb.append("PRTPROMCARD|" + (String)m.get("trans_ver") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM112AT",max);
			for(int i = 0;i < list.size();i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("prom_evt_cd") + "|" );		// 행사코드
				sb.append( (String)map.get("prefix_st_no") + "|" );		// 카드BIN시작
				sb.append( (String)map.get("prefix_end_no") + "|" );	// 카드BIN끝
				sb.append( "|" );										// FILLER1
				sb.append( "|" );										// FILLER2
				sb.append( "|" );										// FILLER3
				sb.append( "|" );										// FILLER4
				sb.append( "|\r\n" );									// FILLER5
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 2. generateSTBDM140AT - Generate FF-Category Inquirty Results as File(FF-카테고리 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM140AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM140AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("FFGROUP\r\n");
			sb.append("FFGROUP|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM140AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("ffplu_cat") + "|" );
			    sb.append( (String)map.get("ffplu_cat_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

    /**
     * 3. generateSTBDM141AT - Generate FF-PLU Inquirty Results as File(FF-PLU 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM141AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM141AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("FFPLU\r\n");
			sb.append("FFPLU|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM141AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);

			    sb.append( (String)map.get("ffplu_cat") + "|" );
			    sb.append( (String)map.get("ffplu_seq") + "|" );
			    sb.append( (String)map.get("plu_cd") + "|" );
			    sb.append( (String)map.get("ffplu_asgn_yn") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

    /**
	 * 5. generateSTBDM300AT - Generate Staff Master Inquirty Results as File(직원마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM300AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM300AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("STAFF\r\n");
			sb.append("STAFF|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM300AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
				sb.append( (String)map.get("user_id") + "|" );
				sb.append( (String)map.get("user_ty") + "|" );
				sb.append( (String)map.get("user_nm") + "|" );
				sb.append( (String)map.get("user_pw") + "|" );
				sb.append( (String)map.get("user_auth_grp_cd") + "|" );
				sb.append( (String)map.get("user_card_no") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

    /**
	 * 5. generateSTBDM311AT - Generate Staff Auth Group Master Inquirty Results as File(직원권한그룹마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM311AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM311AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("STAFF_AUTH_GROUP\r\n");
			sb.append("STAFF_AUTH_GROUP|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM311AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
				sb.append( (String)map.get("staff_auth_group") + "|" );
				sb.append( (String)map.get("staff_auth_group_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

    /**
	 * 5. generateSTBDM312AT - Generate Staff Auth Master Inquirty Results as File(직원권한마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM312AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM312AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("STAFF_AUTH\r\n");
			sb.append("STAFF_AUTH|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM312AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
				sb.append( (String)map.get("staff_auth_group") + "|" );
				sb.append( (String)map.get("sfkc_key") + "|" );
				sb.append( (String)map.get("manager_auth_check") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
     * 5. generateSTBDM350AT - Generate Common Code Master Inquirty Results as File(공통코드마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM350AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM350AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("COMMONMSG\r\n");
			sb.append("COMMONMSG|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM350AT",max);
			String strData;
			int strLen;
			byte[] utf8 = null;
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);

//				strData = (String)map.get("comm_cd_cat");
//				strLen = strData.codePointCount(0, strData.length());
//				StringUtil.appendSpace(sb, Integer.toString(strData.length())          ,  0);
//				StringUtil.appendSpace(sb, (String)map.get("comm_cd_cat")    ,  5-strLen);
//				StringUtil.appendSpace(sb, "/"          ,  0);
//				
//				strData = (String)map.get("comm_cd");
//				strLen = strData.codePointCount(0, strData.length());
//				StringUtil.appendSpace(sb, Integer.toString(strLen)          ,  0);
//				StringUtil.appendSpace(sb, (String)map.get("comm_cd")        , 10-strLen);
//				StringUtil.appendSpace(sb, "/"          ,  0);
				
//				strData = (String)map.get("comm_cd_cont");
//				strLen = strData.codePointCount(0, strData.length());
//				StringUtil.appendSpace(sb, Integer.toString(strLen)          ,  0);
//				StringUtil.appendSpace(sb, (String)map.get("comm_cd_cont")   , 50);
//				StringUtil.appendSpace(sb, "/"          ,  0);
//				
//				strData = (String)map.get("comm_cd_cont");
//				utf8 = strData.getBytes("UTF-8");
//				strLen = utf8.length;
//				StringUtil.appendSpace(sb, Integer.toString(strLen)          ,  0);
//				StringUtil.appendSpace(sb, (String)map.get("comm_cd_cont")   , 50);
//				StringUtil.appendSpace(sb, "/"          ,  0);
//				
//				strData = (String)map.get("comm_cd_cont");
//				utf8 = strData.getBytes("UTF-16LE");
//				strLen = utf8.length;
//				StringUtil.appendSpace(sb, Integer.toString(strLen)          ,  0);
//				StringUtil.appendSpace(sb, (String)map.get("comm_cd_cont")   , 50);
//				StringUtil.appendSpace(sb, "/"          ,  0);
//				
//				strData = (String)map.get("remarks1");
//				strLen = strData.codePointCount(0, strData.length());
//				StringUtil.appendSpace(sb, Integer.toString(strData.length())          ,  0);
//				StringUtil.appendSpace(sb, (String)map.get("remarks1")       ,500-strLen);
				
//				StringUtil.appendSpace(sb, (String)map.get("country_cd")     , 10);
//				StringUtil.appendSpace(sb, (String)map.get("comm_cd_cat")    , 10);
//				StringUtil.appendSpace(sb, (String)map.get("comm_cd")        , 10);
//				StringUtil.appendSpace(sb, (String)map.get("prt_order")      ,  2);
//				StringUtil.appendSpaceUnicode(sb, (String)map.get("comm_cd_cont")   , 50);
//				StringUtil.appendSpaceUnicode(sb, (String)map.get("value")          , 10);
//			    sb.append("\r\n");

			    sb.append( (String)map.get("country_cd") + "|" );
				sb.append( (String)map.get("comm_cd_cat") + "|" );
				sb.append( (String)map.get("comm_cd") + "|" );
				sb.append( (String)map.get("prt_order") + "|" );
				sb.append( (String)map.get("comm_cd_cont") + "|" );
				sb.append( (String)map.get("value") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
     * 9. generateSTBDM921AT - Generate Money Kind Master Inquirty Results as File(금종마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM921AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM921AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("COMMONMSG\r\n");
			sb.append("COMMONMSG|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM921AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
				sb.append( (String)map.get("culture_id") + "|" );
				sb.append( (String)map.get("cgbn") + "|" );
				sb.append( (String)map.get("ccode") + "|" );
				sb.append( (String)map.get("seq") + "|" );
				sb.append( (String)map.get("money_dscp") + "|" );
				sb.append( (String)map.get("money") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}	
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 5. generateSTBDM920AT - Generate Culture Master Inquirty Results as File(문화마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM920AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM920AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("GCULTMST\r\n");
			sb.append("GCULTMST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM920AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("culture_id") + "|" );
				sb.append( (String)map.get("culture_nm") + "|" );
				sb.append( (String)map.get("date_pattern") + "|" );
				sb.append( (String)map.get("currency_symbol") + "|" );
				sb.append( (String)map.get("currency_nm") + "|" );
				sb.append( (String)map.get("decimal_digits") + "|" );
				sb.append( (String)map.get("decimal_symbol") + "|" );
				sb.append( (String)map.get("grouping_digits") + "|" );
				sb.append( (String)map.get("grouping_symbol") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

    /**
	 * 5. generateSTBDM910AT - Generate Message Master Inquirty Results as File(메시지마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM910AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM910AT.tbl";
		int max = 0;
		String strMessage;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("MESSAGEMST\r\n");
			sb.append("MESSAGEMST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM910AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("country_cd") + "|" );
			    sb.append( (String)map.get("msg_id") + "|" );
			    sb.append( (String)map.get("msg_type_id") + "|" );
				//메시지마스터 메시지내용은 CR,LF 존재하므로 POS단의 행별 라인단위 read의 일관화를 위해 <br>로 치환
				strMessage = (String)map.get("message");
				strMessage = strMessage.replaceAll("\r\n", "<br>");
				strMessage = strMessage.replaceAll("\n", "<br>");
				sb.append( strMessage + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

    /**
	 * 5. generateSTBDM930AT - Generate Tax Master Inquirty Results as File(세금마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM930AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM930AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("GTAXMST\r\n");
			sb.append("GTAXMST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM930AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("country_cd") + "|" );
			    sb.append( (String)map.get("tax_id") + "|" );
			    sb.append( (String)map.get("tax_nm") + "|" );
			    sb.append( (String)map.get("flag") + "|" );
			    sb.append( (String)map.get("amt_or_perc") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

    /**
	 * 5. generateSTBDM931AT - Generate Tax PLU Master Inquirty Results as File(세금상품마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM931AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM931AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("GTAXPLUMST\r\n");
			sb.append("GTAXPLUMST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM931AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("country_cd") + "|" );
			    sb.append( (String)map.get("plu_cd") + "|" );
			    sb.append( (String)map.get("tax_id") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

    /**
	 * 5. generateSTMBS120AT - Generate Point PLU Master Inquirty Results as File(포인트상품마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTMBS120AT(Map m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STMBS120AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("POINTITEM\r\n");
			sb.append("POINTITEM|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STMBS120AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("plu_cd") + "|" );
			    sb.append( (String)map.get("point_apply_flag") + "|" );
			    sb.append( (String)map.get("point_apply_value") + "|" );
			    sb.append( (String)map.get("base_apply_flag") + "|" );
			    sb.append( (String)map.get("bonus_point") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

    /**
	 * 5. generateSTMBS130AT - Generate Point Sale Master Inquirty Results as File(포인트소계마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTMBS130AT(Map m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STMBS130AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("POINTSALEAMT\r\n");
			sb.append("POINTSALEAMT|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STMBS130AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("sale_amt_from") + "|" );
			    sb.append( (String)map.get("sale_amt_to") + "|" );
			    sb.append( (String)map.get("point_apply_flag") + "|" );
			    sb.append( (String)map.get("point_apply_value") + "|" );
			    sb.append( (String)map.get("base_apply_flag") + "|" );
			    sb.append( (String)map.get("bonus_point") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		//System.gc();
		return 0;
	}

    /**
	 * 5. generateSTMBS140AT - Generate Point Payment Master Inquirty Results as File(포인트결제수단마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTMBS140AT(Map m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STMBS140AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("POINTPAYMENT\r\n");
			sb.append("POINTPAYMENT|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STMBS140AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("pay_flag") + "|" );
			    sb.append( (String)map.get("point_apply_flag") + "|" );
			    sb.append( (String)map.get("point_apply_value") + "|" );
			    sb.append( (String)map.get("base_apply_flag") + "|" );
			    sb.append( (String)map.get("bonus_point") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

    /**
	 * 5. generateSTMBS170AT - Generate Point Order Master Inquirty Results as File(포인트우선순위마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTMBS170AT(Map m, String path) throws Exception {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STMBS170AT.tbl";
		int max = 0;
		try {
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("POINTORDER\r\n");
			sb.append("POINTORDER|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STMBS170AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("order_no") + "|" );
			    sb.append( (String)map.get("bonus_point_flag") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 5. generateSTBDM640AT - Generate POS Master Inquirty Results as File(POS마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM640AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM640AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("POS_MST\r\n");
			sb.append("POS_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM640AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("store_cd") + "|" );
			    sb.append( (String)map.get("pos_no") + "|" );
			    sb.append( (String)map.get("pos_nm") + "|" );
			    sb.append( (String)map.get("pos_option") + "|" );
			    sb.append( (String)map.get("pos_hw_id") + "|" );
			    sb.append( (String)map.get("op_button_group") + "|" );
			    sb.append( (String)map.get("receipt_format_group") + "|" );
			    sb.append( (String)map.get("kps_format_group") + "|" );
			    sb.append( (String)map.get("account_slip_format_group") + "|" );
			    sb.append( (String)map.get("pos_key_group") + "|||||" );
			    sb.append( ((String)m.get("trans_ver")).substring(0, 8) + "^" + (String)map.get("cashrcpt_apprno") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 9. generateSTBDM650AT - Generate Option Master Inquirty Results as File(옵션마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM650AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM650AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("OPTIONMST\r\n");
			sb.append("OPTIONMST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM650AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("pos_no") + "|" );
			    sb.append( (String)map.get("option_cd") + "|" );
			    sb.append( (String)map.get("option_val") + "|" );
			    sb.append( (String)map.get("option_nm") + "|" );
			    sb.append( (String)map.get("option_desc") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 9. generateSTBDM660AT - Generate POS Setting Master Inquirty Results as File(POS설정마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM660AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM660AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("POSSETTING_MST\r\n");
			sb.append("POSSETTING_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM660AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("pos_no") + "|" );
			    sb.append( (String)map.get("setting_item_class_type") + "|" );
			    sb.append( (String)map.get("setting_item_cd") + "|" );
			    sb.append( (String)map.get("setting_item_val") + "|" );
			    sb.append( (String)map.get("setting_item_nm") + "|" );
			    sb.append( (String)map.get("setting_input_type") + "|" );
			    sb.append( (String)map.get("com_group_cd") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 9. generateSTBDM661AT - Generate Preset Master Inquirty Results as File(단축키마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM661AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM661AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PRESET_MST\r\n");
			sb.append("PRESET_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM661AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("preset_key") + "|" );
			    sb.append( (String)map.get("plu_cd") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 9. generateSTBDM662AT - Generate Reason Master Inquirty Results as File(사유마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM662AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM662AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("REASON_MST\r\n");
			sb.append("REASON_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM662AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("country_id") + "|" );
			    sb.append( (String)map.get("reason_ty") + "|" );
			    sb.append( (String)map.get("reason_cd") + "|" );
			    sb.append( (String)map.get("reason_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 2. generateSTBDM159AT - Generate Cash Drawer Device Master Inquirty Results as File(돈통마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM159AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM159AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("DRAWER_DEVICE_MST\r\n");
			sb.append("DRAWER_DEVICE_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM159AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("pos_no") + "|" );
			    sb.append( (String)map.get("drawer_cd") + "|" );
			    sb.append( (String)map.get("drawer_nm") + "|" );
			    sb.append( (String)map.get("drawer_use_flag") + "|" );
			    sb.append( (String)map.get("com_port") + "|" );
			    sb.append( (String)map.get("com_baudrate") + "|" );
			    sb.append( (String)map.get("opos_nm") + "|" );
			    sb.append( (String)map.get("password") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 2. generateSTBDM160AT - Generate Floor Master Inquirty Results as File(층마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM160AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM160AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("FLOOR_MST\r\n");
			sb.append("FLOOR_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM160AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("floor_cd") + "|" );
			    sb.append( (String)map.get("floor_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 2. generateSTBDM161AT - Generate Table Master Inquirty Results as File(테이블마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM161AT(Map m, String path) throws Exception {
		try {
			StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM161AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("TABLE_MST\r\n");
			sb.append("TABLE_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM161AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("floor_cd") + "|" );
			    sb.append( (String)map.get("table_no") + "|" );
			    sb.append( (String)map.get("table_nm") + "|" );
			    sb.append( (String)map.get("table_type") + "|" );
			    sb.append( (String)map.get("table_disp_type") + "|" );
			    sb.append( (String)map.get("back_color") + "|" );
			    sb.append( (String)map.get("back_image") + "|" );
			    sb.append( (String)map.get("font_color") + "|" );
			    sb.append( (String)map.get("font_nm") + "|" );
			    sb.append( (String)map.get("font_size") + "|" );
			    sb.append( (String)map.get("x_point") + "|" );
			    sb.append( (String)map.get("y_point") + "|" );
			    sb.append( (String)map.get("width") + "|" );
			    sb.append( (String)map.get("height") + "|" );
			    sb.append( (String)map.get("table_disp_flag") + "|" );
			    sb.append( (String)map.get("seat_count") + "|" );
			    sb.append( (String)map.get("seat_disp_flag") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 2. generateSTBDM162AT - Generate Kitchen System Device Master Inquirty Results as File(주방디바이스마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM162AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM162AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("KS_DEVICE_MST\r\n");
			sb.append("KS_DEVICE_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM162AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("ks_cd") + "|" );
			    sb.append( (String)map.get("ks_nm") + "|" );
			    sb.append( (String)map.get("ks_flag") + "|" );
			    sb.append( (String)map.get("ks_use_flag") + "|" );
			    sb.append( (String)map.get("kps_com_port") + "|" );
			    sb.append( (String)map.get("kps_com_baudrate") + "|" );
			    sb.append( (String)map.get("kps_opos_nm") + "|" );
			    sb.append( (String)map.get("kvs_ip") + "|" );
			    sb.append( (String)map.get("kvs_port") + "|" );
			    sb.append( (String)map.get("kvs_db_nm") + "|" );
			    sb.append( (String)map.get("kvs_db_id") + "|" );
			    sb.append( (String)map.get("kvs_db_pwd") + "|" );
			    sb.append( (String)map.get("kps_cd_backup1") + "|" );
			    sb.append( (String)map.get("kps_cd_backup2") + "|" );
			    sb.append( (String)map.get("kps_cd_backup3") + "|" );
			    sb.append( (String)map.get("kps_cd_backup4") + "|" );
			    sb.append( (String)map.get("kps_cd_backup5") + "|" );
			    sb.append( (String)map.get("kps_cd_backup6") + "|" );
			    sb.append( (String)map.get("err_stat") + "|" );
			    sb.append( (String)map.get("kps_print_gbn") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 2. generateSTBDM163AT - Generate PLU Kitchen System Device Master Inquirty Results as File(상품주방디바이스마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM163AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM163AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("KS_PLU_MST\r\n");
			sb.append("KS_PLU_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM163AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("ks_cd") + "|" );
			    sb.append( (String)map.get("floor_cd") + "|" );
			    sb.append( (String)map.get("plu_cd") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 2. generateSTBDM164AT - Generate Order Slip Device Master Inquirty Results as File(주문표디바이스마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM164AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM164AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("ORDER_SLIP_DEVICE_MST\r\n");
			sb.append("ORDER_SLIP_DEVICE_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM164AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("device_cd") + "|" );
			    sb.append( (String)map.get("device_nm") + "|" );
			    sb.append( (String)map.get("device_use_flag") + "|" );
			    sb.append( (String)map.get("device_com_port") + "|" );
			    sb.append( (String)map.get("device_com_baudrate") + "|" );
			    sb.append( (String)map.get("device_opos_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 2. generateSTBDM165AT - Generate Order Slip Table Device Master Inquirty Results as File(주문표테이블디바이스마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM165AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM165AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("ORDER_SLIP_TABLE_DEVICE_MST\r\n");
			sb.append("ORDER_SLIP_TABLE_DEVICE_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM165AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
			    sb.append( (String)map.get("device_cd") + "|" );
			    sb.append( (String)map.get("floor_cd") + "|" );
			    sb.append( (String)map.get("table_no") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 3. generateSTBDM150AT - Generate Menu Header Master Results as File(메뉴헤더마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM150AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM150AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("MENU_HEADER\r\n");
			sb.append("MENU_HEADER|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM150AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);

				System.out.println("[DEBUG] [menu_cd]=" + (String)map.get("menu_cd"));
			    sb.append( (String)map.get("menu_cd") + "|" );
			    sb.append( (String)map.get("menu_nm") + "|" );
			    sb.append( (String)map.get("back_color") + "|" );
			    sb.append( (String)map.get("font_color") + "|" );
			    sb.append( (String)map.get("font_size") + "|" );
			    sb.append( (String)map.get("font_nm") + "|" );
			    sb.append( (String)map.get("use_flag") + "|" );
			    sb.append( (String)map.get("display_seq") + "|" );
			    sb.append( (String)map.get("sale_type") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 3. generateSTBDM151AT - Generate Menu Button Master Results as File(메뉴버튼마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM151AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM151AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("MENU_BUTTON\r\n");
			sb.append("MENU_BUTTON|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM151AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);

			    sb.append( (String)map.get("menu_cd") + "|" );
			    sb.append( (String)map.get("seq_no") + "|" );
			    sb.append( (String)map.get("menu_type") + "|" );
			    sb.append( (String)map.get("type_cd") + "|" );
			    sb.append( (String)map.get("key_cd") + "|" );
			    sb.append( (String)map.get("text_nm") + "|" );
			    sb.append( (String)map.get("up_back_color") + "|" );
			    sb.append( (String)map.get("down_back_color") + "|" );
			    sb.append( (String)map.get("up_back_image") + "|" );
			    sb.append( (String)map.get("down_back_image") + "|" );
			    sb.append( (String)map.get("font_color") + "|" );
			    sb.append( (String)map.get("font_nm") + "|" );
			    sb.append( (String)map.get("font_size") + "|" );
			    sb.append( (String)map.get("x_point") + "|" );
			    sb.append( (String)map.get("y_point") + "|" );
			    sb.append( (String)map.get("width") + "|" );
			    sb.append( (String)map.get("height") + "|" );
			    sb.append( (String)map.get("disp_flag") + "|" );
			    sb.append( (String)map.get("disp_type") + "|" );
			    sb.append( (String)map.get("use_flag") + "|" );
			    sb.append( (String)map.get("base_gds_yn") + "|" );
			    sb.append( (String)map.get("change_enable_yn") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 3. generateSTBDM152AT - Generate Select Modifier Master Results as File(선택수정자마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM152AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM152AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("OPTION_MODIFIER_MST\r\n");
			sb.append("OPTION_MODIFIER_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM152AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
	
			    sb.append( (String)map.get("modifier_cd") + "|" );
			    sb.append( (String)map.get("seq_no") + "|" );
			    sb.append( (String)map.get("modifier_nm") + "|" );
			    sb.append( (String)map.get("modifier_type") + "|" );
			    sb.append( (String)map.get("type_cd") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 3. generateSTBDM153AT - Generate Forced Modifier Master Results as File(강제수정자마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM153AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM153AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("FORCED_MODIFIER_MST\r\n");
			sb.append("FORCED_MODIFIER_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM153AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
	
			    sb.append( (String)map.get("plu_cd") + "|" );
			    sb.append( (String)map.get("seq_no") + "|" );
			    sb.append( (String)map.get("modifier_flag") + "|" );
			    sb.append( (String)map.get("modifier_cd") + "|" );
			    sb.append( (String)map.get("min_qty") + "|" );
			    sb.append( (String)map.get("max_qty") + "|" );
			    sb.append( (String)map.get("use_flag") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 3. generateSTBDM154AT - Generate Combo Master Results as File(콤보마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM154AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM154AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("COMBO_MST\r\n");
			sb.append("COMBO_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM154AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
	
			    sb.append( (String)map.get("plu_cd") + "|" );
			    sb.append( (String)map.get("seq_no") + "|" );
			    sb.append( (String)map.get("combo_type") + "|" );
			    sb.append( (String)map.get("child_plu_cd") + "|" );
			    sb.append( (String)map.get("child_menu_cd") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 3. generateSTBDM155AT - Generate PLU Select Modifier Master Results as File(상품선택수정자마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM155AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM155AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("PLU_OPTION_MODIFIER\r\n");
			sb.append("PLU_OPTION_MODIFIER|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM155AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
	
			    sb.append( (String)map.get("plu_cd") + "|" );
			    sb.append( (String)map.get("modifier_cd") + "|" );
			    sb.append( (String)map.get("use_flag") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 3. generateSTBDM156AT - Generate Op. Button Group Master Results as File(조작버튼그룹마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM156AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM156AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("OP_BUTTON_GROUP\r\n");
			sb.append("OP_BUTTON_GROUP|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM156AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
	
			    sb.append( (String)map.get("op_button_group") + "|" );
			    sb.append( (String)map.get("op_button_group_nm") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 3. generateSTBDM157AT - Generate Op. Button Setup Master Results as File(조작버튼설정마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM157AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM157AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("OP_BUTTON_SETUP\r\n");
			sb.append("OP_BUTTON_SETUP|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM157AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
	
			    sb.append( (String)map.get("op_button_group") + "|" );
			    sb.append( (String)map.get("op_button_flag") + "|" );
			    sb.append( (String)map.get("seq_no") + "|" );
			    sb.append( (String)map.get("sfkc_key") + "|" );
			    sb.append( (String)map.get("sfkc_key_nm") + "|" );
			    sb.append( (String)map.get("back_image") + "|" );
			    sb.append( (String)map.get("font_color") + "|" );
			    sb.append( (String)map.get("font_nm") + "|" );
			    sb.append( (String)map.get("font_size") + "|" );
			    sb.append( (String)map.get("option1") + "|" );
			    sb.append( (String)map.get("option2") + "|" );
			    sb.append( (String)map.get("option3") + "|" );
			    sb.append( (String)map.get("option4") + "|" );
			    sb.append( (String)map.get("option5") + "|" );
			    sb.append( (String)map.get("option6") + "|" );
			    sb.append( (String)map.get("option7") + "|" );
			    sb.append( (String)map.get("option8") + "|" );
			    sb.append( (String)map.get("option9") + "|" );
			    sb.append( (String)map.get("option10") + "|" );
			    sb.append( (String)map.get("option11") + "|" );
			    sb.append( (String)map.get("option12") + "|" );
			    sb.append( (String)map.get("option13") + "|" );
			    sb.append( (String)map.get("option14") + "|" );
			    sb.append( (String)map.get("option15") + "|" );
			    sb.append( (String)map.get("option16") + "|" );
			    sb.append( (String)map.get("option17") + "|" );
			    sb.append( (String)map.get("option18") + "|" );
			    sb.append( (String)map.get("option19") + "|" );
			    sb.append( (String)map.get("option20") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
	 * 3. generateSTBDM158AT - SFKC Key Master Results as File(SFKC키마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM158AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM158AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("SFKC_MST\r\n");
			sb.append("SFKC_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List list = dao.selectGlobalMaster(m, "SEL_STBDM158AT", max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
	
			    sb.append( (String)map.get("country_cd") + "|" );
			    sb.append( (String)map.get("sfkc_key") + "|" );
			    sb.append( (String)map.get("sfkc_key_nm") + "|" );
			    sb.append( (String)map.get("sfkc_key_type") + "|" );
			    sb.append( (String)map.get("sale_wait_flag") + "|" );
			    sb.append( (String)map.get("saling_flag") + "|" );
			    sb.append( (String)map.get("pay_wait_flag") + "|" );
			    sb.append( (String)map.get("paying_flag") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM670AT - CASHBEE PUBCO INFO Master Results as File(캐시비발행사정보 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM670AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM670AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("SFKC_MST\r\n");
			sb.append("TRANS_CB_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM670AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("PBCO_ID") + "|" );
				sb.append( (String)map.get("PBCO_NM") + "|" );
				sb.append( (String)map.get("PBCO_KEY_VER") + "|" );
				sb.append( (String)map.get("PBCO_KEY_VAL") + "|" );
				sb.append( (String)map.get("RECHG_FEE_RT") + "|" );
				sb.append( (String)map.get("BUY_FEE_RT") + "|" );
				sb.append( (String)map.get("RFU_VAL") + "|" );
				sb.append( (String)map.get("REPAY_FEE") + "|" );
				sb.append( (String)map.get("PENAL_AMT") + "|" );
				sb.append( (String)map.get("SAM_TP") + "|" );
				sb.append( (String)map.get("RECHG_ENBL_YN") + "|" );
				sb.append( (String)map.get("BUY_ENBL_YN") + "|" );
				sb.append( (String)map.get("REPAY_ENBL_YN") + "|" );
				sb.append( (String)map.get("ROBB_LOST_SEAH_YN") + "|" );
				sb.append( (String)map.get("REPAY_MAX_AMT") + "|" );
				sb.append( (String)map.get("ELE_MONYCO_ID") + "|" );
				sb.append( (String)map.get("CARD_MAX_RECHG_AMT") + "|" );
				sb.append( (String)map.get("ONCE_MAX_RECHG_AMT") + "|\r\n" );
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM671AT - HANPAY PUBCO INFO Master Results as File(한페이발행사정보 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM671AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM671AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("SFKC_MST\r\n");
			sb.append("TRANS_HP_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM671AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("PBCO_CD") + "|" );
				sb.append( (String)map.get("TMNAL_ID") + "|\r\n" );
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM680AT - TMONEY PUBCO INFO Master Results as File(티머니발행사제어정보 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM680AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM680AT.tbl";
		int max = 0;
		
		    // 마스터 배포 방식 변경 시작(20131202/조충연)
		    //sb.append("SFKC_MST\r\n");
			sb.append("TRANS_TM_MST|" + (String)m.get("trans_ver") + "\r\n");
			// 마스터 배포 방식 변경 끝(20131202/조충연)
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM680AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("PBCO_ID") + "|" );
				sb.append( (String)map.get("PBCO_FNC_DEFINE_VAL") + "|\r\n" );
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM480AT - CARD BIN Master Results as File(카드BIN마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM480AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM480AT.tbl";
		int max = 0;
		
			sb.append("CCARD|" + (String)m.get("trans_ver") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM480AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("PREFIX_ST_NO") + "|" );			// 카드BIN시작
				sb.append( (String)map.get("PREFIX_END_NO") + "|" );		// 카드BIN끝
				sb.append( (String)map.get("PREFIX_TP") + "|" );			// 카드BIN유형
				sb.append( "00|" );											// DIGIT COUNT
				sb.append( (String)map.get("CARD_ISUCO_TP") + "|" );		// 카드사코드
				sb.append( "|" );											// 카드사명
				sb.append( (String)map.get("CARD_PAY_TP") + "|" );			// 결제구분코드
				sb.append( (String)map.get("CARD_TP_TP") + "|\r\n" );		// 카드유형코드
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM490AT - HARM PLU Master Results as File(위해상품 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM490AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM490AT.tbl";
		int max = 0;
		
			sb.append("HARM_MST|" + (String)m.get("trans_ver") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM490AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("HARM_PLU") + "|" );				// 상품바코드
				sb.append( (String)map.get("MAKE_CMP") + "|" );				// 제조업체
				sb.append( (String)map.get("MAKE_DT") + "|" );				// 제조일자
				sb.append( (String)map.get("EXP_DT") + "|" );				// 유통기한
				sb.append( (String)map.get("HARM_REASON") + "|" );			// 위해사유
				sb.append( (String)map.get("NOTI_PL") + "|" );				// 고시처
				sb.append( (String)map.get("NOTI_DT") + "|" );				// 고시일시
				sb.append( "|\r\n" );										// 설명
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM280AT - POS KEY GROUP Master Results as File(POSKEY그룹마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM280AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM280AT.tbl";
		int max = 0;
		
			sb.append("POS_KEY_GROUP|" + (String)m.get("trans_ver") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM280AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("POS_KEY_GRP_CD") + "|" );			// POSKEY그룹코드
				sb.append( (String)map.get("POS_KEY_GRP_NM") + "|" );			// POSKEY그룹명
				sb.append( (String)map.get("POS_KEYBD_EQUIP_CD") + "|\r\n" );	// POSKEY종류
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 3. generateSTBDM281AT - POS Key Master Results as File(POSKEY마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM281AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM281AT.tbl";
		int max = 0;
		
			sb.append("POS_KEY|" + (String)m.get("trans_ver") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM281AT", max);
			
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				
				sb.append( (String)map.get("POS_KEY_GRP_CD") + "|" );		// POSKEY그룹코드
				sb.append( (String)map.get("SCAN_KEY_VAL") + "|" );			// POS 스캔키
				sb.append( (String)map.get("HNDL_KEY_VAL") + "|\r\n" );		// 조작키
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}





























    /**
     * 5. generateSTBDM310AT - Generate Store Staff Master Inquirty Results as File(점포사원마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM310AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM310AT.tbl";
		int max = 0;
		
			List list = dao.selectGlobalMaster(m, "SEL_STBDM310AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
				StringUtil.appendSpace(sb, (String)map.get("user_id")        , 13);
				StringUtil.appendSpace(sb, (String)map.get("store_cd")       ,  5);
			    sb.append("\r\n");
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[storecd : "+(String)m.get("store_cd")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[storecd : "+(String)m.get("store_cd")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
     * 9. generateSTBDM470AT - Generate Credit Card Master Inquirty Results as File(신용카드마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM470AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM470AT.tbl";
		int max = 0;
	
			List list = dao.selectGlobalMaster(m, "SEL_STBDM470AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
				StringUtil.appendSpace(sb, (String)map.get("bin_sno")        ,  6);
				StringUtil.appendSpace(sb, (String)map.get("bin_eno")        ,  6);
				StringUtil.appendSpace(sb, (String)map.get("digit_cnt")      ,  2);
				StringUtil.appendSpace(sb, (String)map.get("card_corp_cd")   ,  3);
				StringUtil.appendSpace(sb, (String)map.get("card_corp_nm")   , 20);
			    sb.append("\r\n");
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[storecd : "+(String)m.get("store_cd")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[storecd : "+(String)m.get("store_cd")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
     * 9. generateSTBDM620AT - Generate Coupon Master Inquirty Results as File(쿠폰마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM620AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM620AT.tbl";
		int max = 0;
		
			List list = dao.selectGlobalMaster(m, "SEL_STBDM620AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
				StringUtil.appendSpace(sb, (String)map.get("cpn_id")         , 12);
				StringUtil.appendSpace(sb, (String)map.get("cpn_nm")         , 30);
				StringUtil.appendSpace(sb, (String)map.get("cpn_ty")         ,  1);
				StringUtil.appendSpace(sb, (String)map.get("cpn_amt")        , 20);
				StringUtil.appendSpace(sb, (String)map.get("use_st_dt")      ,  8);
				StringUtil.appendSpace(sb, (String)map.get("use_en_dt")      ,  8);
				StringUtil.appendSpace(sb, (String)map.get("cpn_disc")       , 60);
			    sb.append("\r\n");
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[storecd : "+(String)m.get("store_cd")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[storecd : "+(String)m.get("store_cd")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
     * 9. generateSTBDM630AT - Generate Gift Card Master Inquirty Results as File(상품권마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM630AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM630AT.tbl";
		int max = 0;
	
			List list = dao.selectGlobalMaster(m, "SEL_STBDM630AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
				StringUtil.appendSpace(sb, (String)map.get("gift_cd")        ,  2);
				StringUtil.appendSpace(sb, (String)map.get("gift_ty")        ,  1);
				StringUtil.appendSpace(sb, (String)map.get("gift_flag")      ,  2);
				StringUtil.appendSpace(sb, (String)map.get("gift_nm")        , 40);
				StringUtil.appendSpace(sb, (String)map.get("gift_prefix")    , 13);
				StringUtil.appendSpace(sb, (String)map.get("gift_amt")       , 20);
				StringUtil.appendSpace(sb, (String)map.get("valid_dt")       ,  8);
				StringUtil.appendSpace(sb, (String)map.get("cust_cd")        , 10);
				StringUtil.appendSpace(sb, (String)map.get("possible_rate")  , 20);
			    sb.append("\r\n");
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[storecd : "+(String)m.get("store_cd")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[storecd : "+(String)m.get("store_cd")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}

	/**
     * 9. generateSTBDM911AT - Generate Form Master Inquirty Results as File(폼마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(Path to generate TBL File(TBL파일 생성할 경로))
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM911AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM911AT.tbl";
		int max = 0;
		String strFormInfo;
		
			List list = dao.selectGlobalMaster(m, "SEL_STBDM911AT",max);
			for (int i=0; i < list.size(); i++) {
				Map map = (Map)list.get(i);
				StringUtil.appendSpace(sb, (String)map.get("country_cd")     , 10);
				StringUtil.appendSpace(sb, (String)map.get("form_pattern")   ,  2);
				StringUtil.appendSpace(sb, (String)map.get("form_id")        ,  5);
				StringUtil.appendSpace(sb, (String)map.get("form_type")      ,  2);
				StringUtil.appendSpace(sb, (String)map.get("form_nm")        , 30);
				//폼정보마스터 xml은 CR,LF 존재하므로 POS단의 행별 라인단위 read의 일관화를 위해 ||로 치환
				strFormInfo = (String)map.get("form_info");
				strFormInfo = strFormInfo.replaceAll("\r\n", "||");
				strFormInfo = strFormInfo.replaceAll("\n", "||");
				StringUtil.appendSpace(sb, strFormInfo                       ,5000);
			    sb.append("\r\n");
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[storecd : "+(String)m.get("store_cd")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("[storecd : "+(String)m.get("store_cd")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	

	
	//아동급식 //===============================================================	
	/**
	 * 10. generateSTBDM690AT - Generate MEAl FOR CHILDREN  Master Inquirty Results as File(아동급식 지역코드 마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM690AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM690AT.tbl";
		
		int max = 0;
					
			sb.append("FEEDING_CARD|" + (String)m.get("trans_ver") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM690AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("MEALPREFIX_CD") + "|" );
				sb.append( (String)map.get("DEPOTVEN_CD") + "|" );
				sb.append( (String)map.get("ORG_CD") + "|" );
				sb.append( (String)map.get("VAN_YN") + "|" );
				sb.append( (String)map.get("ST_DT") + "|" );
				sb.append( (String)map.get("ED_DT") + "|\r\n" );

			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			logger.info("[[[[[[[[[[[[[generateSTBDM690AT]]]]]]]]]]]]");
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
				

	/**
	 * 10. generateSTBDM691AT - Generate MEAl FOR CHILDREN  Master Inquirty Results as File(아동급식 상품 코드 마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM691AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM691AT.tbl";
		
		int max = 0;
		
			sb.append("FEEDING_PLU|" + (String)m.get("trans_ver") + "\r\n");
//			logger.info(" selectGlobalMaster  SEL_STBDM691AT.tbl");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM691AT",max);
//			logger.info(" AFTER selectGlobalMaster  SEL_STBDM691AT.tbl");
			
//			logger.info(" list.size()" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("DEPOTVEN_CD") + "|" );
				sb.append( (String)map.get("ORG_CD") + "|" );
				sb.append( (String)map.get("TARGET_TP") + "|" );
				sb.append( (String)map.get("TARGET_CD") + "|" );
				sb.append( (String)map.get("ST_DT") + "|" );	
				sb.append( (String)map.get("ED_DT") + "|\r\n" );
			}
		
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			logger.info("[[[[[[[[[[[[[generateSTBDM691AT]]]]]]]]]]]]");
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	

	
	/**
	 * 10. generateSTBDM700AT - Generate MEAl FOR CHILDREN  Master Inquirty Results as File(관계사 식대 마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM700AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM700AT.tbl";
		
		int max = 0;
		
			sb.append("MEAL_BIN_CD|" + (String)m.get("trans_ver") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM700AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("REAL_CD")   + "|" );
				sb.append( (String)map.get("SEQ")  + "|" );
				sb.append( (String)map.get("CLASS_CD")  + "|" );
				sb.append( (String)map.get("DIVISION_TY")+ "|" );
				sb.append( (String)map.get("USE_YN")  + "|" );
				sb.append( (String)map.get("START_DATE")+ "|" );
				sb.append( (String)map.get("END_DATE")  + "|" );
				sb.append( (String)map.get("START_TIME")+ "|" );
				sb.append( (String)map.get("END_TIME")  + "|" );
				sb.append( (String)map.get("REAL_NM")   + "|" );
				sb.append( (String)map.get("MAX_AMT")   + "|" );
				sb.append( (String)map.get("FILLER1")   + "|" );
				sb.append( (String)map.get("FILLER2")   + "|" );
				sb.append( (String)map.get("FILLER3")   + "|" );
				sb.append( (String)map.get("FILLER4")   + "|" );
				sb.append( (String)map.get("FILLER5")    + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			logger.info("[[[[[[[[[[[[[generSTBDM700AT]]]]]]]]]]]]");
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 10. generateSTBDM710AT - Generate STAFF DISCOUNT Master Inquirty Results as File(임직원 할인 마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM710AT(Map m, String path) throws Exception { //이거하고 stsys-sql.xml 하고 매칭
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM710AT.tbl";
		
		int max = 0;
	
			sb.append("STAFFDC_MST|" + (String)m.get("trans_ver") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM710AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("CLASS_CD")   + "|" );
				sb.append( (String)map.get("USE_YN")  + "|" );
				sb.append( (String)map.get("DC_PER")  + "|" );
				sb.append( (String)map.get("FILLER1")   + "|" );
				sb.append( (String)map.get("FILLER2")   + "|" );
				sb.append( (String)map.get("FILLER3")   + "|" );
				sb.append( (String)map.get("FILLER4")   + "|" );
				sb.append( (String)map.get("FILLER5")    + "|\r\n" );
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			logger.info("[[[[[[[[[[[[[geneeSTBDM710AT]]]]]]]]]]]]");
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/**
	 * 10. generateSTBDM711AT - Generate STAFF DISCOUNT Master Inquirty Results as File(SSGPAY 할인 마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM711AT(Map m, String path) throws Exception { //이거하고 stsys-sql.xml 하고 매칭
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM711AT.tbl";
		
		int max = 0;
	
			sb.append("SSGPAYDC_MST|" + (String)m.get("trans_ver") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM711AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("CLASS_CD")   + "|" );
				sb.append( (String)map.get("USE_YN")  + "|" );
				sb.append( (String)map.get("DC_PER")  + "|" );
				sb.append( (String)map.get("FILLER1")   + "|" );
				sb.append( (String)map.get("FILLER2")   + "|" );
				sb.append( (String)map.get("FILLER3")   + "|" );
				sb.append( (String)map.get("FILLER4")   + "|" );
				sb.append( (String)map.get("FILLER5")    + "|\r\n" );
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			logger.info("[[[[[[[[[[[[[generateSTBDM710AT]]]]]]]]]]]]");
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/** 20170323 DGB
	 * 10. generateSTBDM720AT - Generate DGB DISCOUNT Master Inquirty Results as File(DGB 카드 발행사 마스터 조회 결과를 파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM720AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM720AT.tbl";
		
		int max = 0;
	
			sb.append("TRANS_DGB_MST|" + (String)m.get("trans_ver") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM720AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("CARD_CMP")   + "|" );
				sb.append( (String)map.get("PUBCO_CD")  + "|" );
				sb.append( (String)map.get("USED_YN")  + "|" );
				sb.append( (String)map.get("APPLY_DT")   + "|" );
				sb.append( (String)map.get("TERMINAL_ID")   + "|\r\n" );
//				sb.append( (String)map.get("FILLER1")   + "|" );
//				sb.append( (String)map.get("FILLER2")   + "|" );
//				sb.append( (String)map.get("FILLER3")   + "|" );
//				sb.append( (String)map.get("FILLER4")   + "|" );
//				sb.append( (String)map.get("FILLER5")    + "|\r\n" );
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			logger.info("[[[[[[[[[[[[[generateSTBDM720AT]]]]]]]]]]]]");
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	/** 20170411 즉석 도시락 주문 마스터
	 * 10. generateSTBDM730AT
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */
	private int generateSTBDM730AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb = new StringBuffer();
		MasterCrtDAO dao   = new MasterCrtDAO();
		String fileName = "STBDM730AT.tbl";
		
		int max = 0;
	
			sb.append("GOOD_LOC_MST|" + (String)m.get("trans_ver") + "\r\n");
			List<Object> list = dao.selectGlobalMaster(m, "SEL_STBDM730AT",max);
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("CLASS_CD")   + "|" ); // 카테고리
				sb.append( (String)map.get("PLU_CD")  + "|" );    // PLU코드
				sb.append( (String)map.get("PAGE_NO")  + "|" );   // 페이지NO
				sb.append( (String)map.get("LOC_SEQ1")   + "|" ); // 위치1(X)
				sb.append( (String)map.get("LOC_SEQ2")   + "|\r\n" ); // 위치2(Y)
			}

			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			logger.info("[[[[[[[[[[[[[generateSTBDM730AT]]]]]]]]]]]]");
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	
	/** 20170825 한진택배 운임요금 마스터
	 * 1. generateSTBDM180AT - Generate Store Master Inquirty Results as TBL File(점포마스터 조회 결과를 TBL파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */  
	private int generateSTBDM180AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb  = new StringBuffer();
		MasterCrtDAO dao = new MasterCrtDAO();
		String fileName  = "STBDM180AT.tbl";
		int max = 0;
		
			sb.append("PARCEL_MST|" + (String)m.get("trans_ver") + "\r\n");
			List list = dao.selectGlobalMaster(m, "SEL_STBDM180AT", max);
			System.out.println("[DEBUG] list count:" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("ITEM_CODE") + "|" );
				sb.append( (String)map.get("ITEM_NAME") + "|" );
				sb.append( (String)map.get("PROM_USE_YN") + "|" );
				sb.append( (String)map.get("PROM_SDT") + "|" );
				sb.append( (String)map.get("PROM_EDT") + "|" );
				sb.append( (String)map.get("PARCEL_AMT") + "|" );
				sb.append( (String)map.get("PROM_AMT") + "|" );
				sb.append( (String)map.get("FILLER1") + "|" );
				sb.append( (String)map.get("FILLER2") + "|" );
				sb.append( (String)map.get("FILLER3") + "|" );
				sb.append( (String)map.get("FILLER4") + "|" );
				sb.append( (String)map.get("FILLER5") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	
	/** 20180207 이마트24 자체쿠폰 행사 마스터
	 * 1. generateSTBDM940AT - Generate Store Master Inquirty Results as TBL File(점포마스터 조회 결과를 TBL파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */  
	private int generateSTBDM940AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb  = new StringBuffer();
		MasterCrtDAO dao = new MasterCrtDAO();
		String fileName  = "STBDM940AT.tbl";
		int max = 0;
		
			sb.append("PRTECONPROMH|" + (String)m.get("trans_ver") + "\r\n");
			List list = dao.selectGlobalMaster(m, "SEL_STBDM940AT", max);
			System.out.println("[DEBUG] list count:" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("RECT_EVT_CD") + "|" );
				sb.append( (String)map.get("RECT_EVT_NM") + "|" );
				sb.append( (String)map.get("RECT_EVT_SYMD") + "|" );
				sb.append( (String)map.get("RECT_EVT_EYMD") + "|" );
				sb.append( (String)map.get("RECT_EVT_SHH") + "|" );
				sb.append( (String)map.get("RECT_EVT_EHH") + "|" );
				sb.append( (String)map.get("RECT_EVT_ADAY_YN") + "|" );
				sb.append( (String)map.get("RECT_EVT_TY") + "|" );
				sb.append( (String)map.get("RECT_EVT_AMT") + "|" );
				sb.append( (String)map.get("RECT_EVT_KIND") + "|" );
				sb.append( (String)map.get("RECT_PRT_MSG1") + "|" );
				sb.append( (String)map.get("RECT_PRT_MSG2") + "|" );
				sb.append( (String)map.get("RECT_PRT_MSG3") + "|" );
				sb.append( (String)map.get("RECT_PRT_MSG4") + "|" );
				sb.append( (String)map.get("RECT_PRT_MSG5") + "|" );
				sb.append( (String)map.get("RECT_PRT_MSG6") + "|" );
				sb.append( (String)map.get("RECT_PRT_MSG7") + "|" );
				sb.append( (String)map.get("RECT_PRT_MSG8") + "|" );
				sb.append( (String)map.get("RECT_PRT_MSG9") + "|" );
				sb.append( (String)map.get("RECT_PRT_MSG10") + "|" );
				sb.append( (String)map.get("COUPON_TP") + "|" );
				sb.append( (String)map.get("COUPON_AMT_TP") + "|" );
				sb.append( (String)map.get("COUPON_AMT") + "|" );
				sb.append( (String)map.get("OTH_STR_ENBL_YN") + "|" );
				sb.append( (String)map.get("EXPR_DT") + "|" );
				sb.append( (String)map.get("USE_ENBL_AMT") + "|" );
				sb.append( (String)map.get("LMT_USE_QTY") + "|" );
				sb.append( (String)map.get("CPN_USE_EXPR_AMT") + "|" );
				sb.append( (String)map.get("FILLER1") + "|" );
				sb.append( (String)map.get("FILLER2") + "|" );
				sb.append( (String)map.get("FILLER3") + "|" );
				sb.append( (String)map.get("FILLER4") + "|" );
				sb.append( (String)map.get("FILLER5") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	
	/** 20180207 이마트24 자체쿠폰 행사 마스터
	 * 1. generateSTBDM941AT - Generate Store Master Inquirty Results as TBL File(점포마스터 조회 결과를 TBL파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */  
	private int generateSTBDM941AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb  = new StringBuffer();
		MasterCrtDAO dao = new MasterCrtDAO();
		String fileName  = "STBDM941AT.tbl";
		int max = 0;
		
			sb.append("PRTECONPROMD|" + (String)m.get("trans_ver") + "\r\n");
			List list = dao.selectGlobalMaster(m, "SEL_STBDM941AT", max);
			System.out.println("[DEBUG] list count:" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("PLU_CD") + "|" );
				sb.append( (String)map.get("RECT_EVT_CD") + "|" );
				sb.append( (String)map.get("FILLER1") + "|" );
				sb.append( (String)map.get("FILLER2") + "|" );
				sb.append( (String)map.get("FILLER3") + "|" );
				sb.append( (String)map.get("FILLER4") + "|" );
				sb.append( (String)map.get("FILLER5") + "|" );
				sb.append( (String)map.get("FILLER6") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	
	/** 20180207 이마트24 자체쿠폰 행사 마스터
	 * 1. generateSTBDM942AT - Generate Store Master Inquirty Results as TBL File(점포마스터 조회 결과를 TBL파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */  
	private int generateSTBDM942AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb  = new StringBuffer();
		MasterCrtDAO dao = new MasterCrtDAO();
		String fileName  = "STBDM942AT.tbl";
		int max = 0;
		
			sb.append("PRTECONPROMD|" + (String)m.get("trans_ver") + "\r\n");
			List list = dao.selectGlobalMaster(m, "SEL_STBDM942AT", max);
			System.out.println("[DEBUG] list count:" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("PROM_EVT_CD") + "|" );
				sb.append( (String)map.get("CARD_NO_FROM") + "|" );
				sb.append( (String)map.get("CARD_NO_TO") + "|" );
				sb.append( (String)map.get("FILLER1") + "|" );
				sb.append( (String)map.get("FILLER2") + "|" );
				sb.append( (String)map.get("FILLER3") + "|" );
				sb.append( (String)map.get("FILLER4") + "|" );
				sb.append( (String)map.get("FILLER5") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
	
	
	
	/** 20180314 수기환불 등록 마스터
	 * 1. generateSTBDM190AT - Generate Store Master Inquirty Results as TBL File(점포마스터 조회 결과를 TBL파일로 생성)
	 * @param m 
	 * @param path : Path to generate TBL File(TBL파일 생성할 경로)
	 * @return
	 * @throws Exception
	 */  
	private int generateSTBDM190AT(Map m, String path) throws Exception {
		try {
		StringBuffer sb  = new StringBuffer();
		MasterCrtDAO dao = new MasterCrtDAO();
		String fileName  = "STBDM190AT.tbl";
		int max = 0;
		
			sb.append("MANUALRETH|" + (String)m.get("trans_ver") + "\r\n");
			List list = dao.selectGlobalMaster(m, "SEL_STBDM190AT", max);
			System.out.println("[DEBUG] list count:" + list.size());
			for (int i=0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				sb.append( (String)map.get("ST_DT") + "|" );
				sb.append( (String)map.get("ED_DT") + "|" );
				sb.append( (String)map.get("FILLER1") + "|" );
				sb.append( (String)map.get("FILLER2") + "|" );
				sb.append( (String)map.get("FILLER3") + "|" );
				sb.append( (String)map.get("FILLER4") + "|" );
				sb.append( (String)map.get("FILLER5") + "|\r\n" );
			}
			// If there is result of inquiry, generate a file(조회된 결과가 있으면 파일 생성)
			if(list.size()>0) {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" done");
			} else {
				ZipUtil.createFileUTF16(sb, path, fileName, false);
				logger.info("["+(String)m.get("store_cd")+"/" +(String)m.get("trans_seq")+"] "+fileName+" has no data.");
			}
		} catch (Exception e) {
			logger.info("[ERROR]" + e);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace =sw.toString();
			logger.info("[ERROR]" + e +"** MSG:"+ sStackTrace);
			throw e;
		}
		return 0;
	}
}
