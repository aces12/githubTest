/*
 * MasterClientAction.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_MasterCrt;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.util.StringUtil;

import org.apache.log4j.Logger;

import biz.cms_MasterAgent.MasterAgentPollingAction;
import biz.cms_MasterAgent.MasterAgentPushRetry;

/** 
 * MasterClientAction
 * Search list to generate master file and create thread(마스터 파일을 생성할 목록을 조회해서 쓰레드 생성) 
 * @created  on 1.0,  11/03/17
 * @created  by khk(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by 
 */ 
public class MasterCrtClientAction {
	private static Logger logger = Logger.getLogger(MasterCrtClientAction.class);
	public static MasterCrtControl msControl = new MasterCrtControl();
	private static int totalCount=0;
	private static int jobThread=0;
	private static int work=0;
	private int maxThread=0;
	private String Com = "";
	private String Store = "";
	private String transYmd = "";
	private boolean deploy = false;
	private String transid = "";
	private String path = "";
	private ExecutorService executor = Executors.newFixedThreadPool(10);//creating a pool of 10 threads	
	private static int curMaprCnt=0;
	public static boolean isUpdOperId = false;
	//public static int updTransSeq = -1;
	private static List list170G = null;
	private static int cnt170G =0;
	
	public void setCurMaprCnt(int n){
		curMaprCnt = n;
	}
	public int getCurMaprCnt(){
		return curMaprCnt;
	}
	private static MasterAgentPushRetry mapr2nd =null;
	private static MasterAgentPushRetry mapr3rd =null;
	private int outTransSeq = 0;
	
	public void setOutTransSeq(int outTransSeq) {
		this.outTransSeq = outTransSeq;
	}
	
	public int getOutTransSeq() {
		return this.outTransSeq;
	}

	public void setCom(String com) {
		this.Com = com;
	}
	public String getCom() {
		return this.Com;
	}
	
	public void setStore(String store) {
		this.Store = store;
	}
	public String getStore() {
		return this.Store;
	}
	
	public static void increment(){
		jobThread++;
	}

	public static void decrement(){
		jobThread--;
	}
	
	public static void workIncrement(){
		++work;
	}
	
	public int getWork(){
		return work;
	}
	public static void setWorkInit(){
		work = 0;
	}
	public static int getJobThread(){
		return jobThread;
	}
	
	public static int getTotalCount(){
		return totalCount;
	}
	
	public static boolean getStatus(){
		if (work==totalCount) return true;
		return false;
	}
	public static boolean getThreadEnd(int curWork){
		if (curWork==totalCount) return true;
		return false;
	}
	
	public int getMaxThread(){
		return maxThread;
	}
	
	public void setMaxThread(int maxThread){
		this.maxThread = maxThread;
		this.jobThread = maxThread;
	}
	
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}

	public String getTransYmd(){
		return transYmd;
	}
	public void setTransYmd(String ymd){
		this.transYmd = ymd;
	}
	

	public boolean getDeploy(){
		return deploy;
	}
	public String getTransid(){
		return transid;
	}
	public void setDeploy(boolean deploy){
		this.deploy = deploy;
	}
	public void setTransid(String transid){
		this.transid = transid;
	}
	
	
	public String getPath(){
		return path;
	}
	public void setPath(String path){
		this.path = path;
	}
	
	//thread_max, delay_time, tran_ymd, tran_id, store_cd
	public static void main(String args[]) throws Exception {
		MasterCrtClientAction master = new MasterCrtClientAction();
		
		if (args == null || args.length < 1) {
			logger.info("------ master main args null");
		}
		
		//System.out.println("[DEBUG] [path]=" + path);
		//System.out.println("[DEBUG] [fileName]=" + fileName);
		System.out.println("[DEBUG] [args[0]]=" + args[0] );
		System.out.println("[DEBUG] [args[1]]=" + args[1] );
		System.out.println("[DEBUG] [args[2]]=" + args[2] );
		System.out.println("[DEBUG] [args[3]]=" + args[3] );
		System.out.println("[DEBUG] [args[4]]=" + args[4] );
		System.out.println("[DEBUG] [args[5]]=" + args[5] );
		
		String thread_max    = nvl(args[0].replaceFirst("-tm:"    ,""));
		String trans_ymd     = nvl(args[1].replaceFirst("-ty:"    ,""));
		String com           = nvl(args[2].replaceFirst("-com:" ,""));
		String store         = nvl(args[3].replaceFirst("-store:" ,""));
		String path          = nvl(args[4].replaceFirst("-path:"  ,""));
		String deploy        = nvl(args[5].replaceFirst("-deploy:"  ,""));
		
		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		//default_thread_max
		if (thread_max.equals("")) thread_max = "10"; 
		master.setMaxThread(Integer.parseInt(thread_max));
		//default trans_ymd = now
		if (trans_ymd.length()!=8) {
			Date now = new Date();
			trans_ymd = StringUtil.getDataFormat(now, "yyyyMMdd");
		}
		master.setTransYmd(trans_ymd);
		//com_cd
		if (com.equals("")) com = "%";
		master.setCom(com);
		//store_cd
		if (store.equals("")) store = "%";
		master.setStore(store);
		
		master.setPath(path);
		
		master.setDeploy(false);
		
		logger.info("thread_max : " + thread_max);	
		logger.info("trans_ymd  : " + trans_ymd);	
		logger.info("com        : " + com);	
		logger.info("store      : " + store);	
		logger.info("path       : " + path);		
		logger.info("deploy     : " + deploy);	
		
		master.execute();
		
	}
	
	public void waitThread(int retryCnt ) throws InterruptedException{
			if(retryCnt==2){
				mapr2nd.waitThread();
			}else if(retryCnt==3){
				mapr3rd.waitThread();
			}		
	}
	public void wakeThread(int retryCnt  ){
		if(retryCnt==2){
			mapr2nd.wakeThread();
		}else if(retryCnt==3){
			mapr3rd.wakeThread();
		}		
	}
	
	public String ThreadState(int retryCnt  ){
		String threadStat = "";
		if(retryCnt==2){
			//logger.info("mapr2nd.getState()=>"+ mapr2nd.getState());
			if (mapr2nd.getState() == Thread.State.BLOCKED)
				threadStat = "BLOCKED";
			else if (mapr2nd.getState() == Thread.State.NEW)
				threadStat = "NEW";
			else if (mapr2nd.getState() == Thread.State.RUNNABLE)
				threadStat = "RUNNABLE";
			else if (mapr2nd.getState() == Thread.State.TERMINATED)
				threadStat = "TERMINATED";
			else if (mapr2nd.getState() == Thread.State.TIMED_WAITING)
				threadStat = "TIMED_WAITING";
			else if (mapr2nd.getState() == Thread.State.WAITING)
				threadStat = "WAITING";
			
		}else if(retryCnt==3){
			//logger.info("mapr3rd.getState()=>"+ mapr3rd.getState());
			if (mapr3rd.getState() == Thread.State.BLOCKED)
				threadStat = "BLOCKED";
			else if (mapr3rd.getState() == Thread.State.NEW)
				threadStat = "NEW";
			else if (mapr3rd.getState() == Thread.State.RUNNABLE)
				threadStat = "RUNNABLE";
			else if (mapr3rd.getState() == Thread.State.TERMINATED)
				threadStat = "TERMINATED";
			else if (mapr3rd.getState() == Thread.State.TIMED_WAITING)
				threadStat = "TIMED_WAITING";
			else if (mapr3rd.getState() == Thread.State.WAITING)
				threadStat = "WAITING";
			
		}	
		
		
		return threadStat;
	}	
		//logger.info("★ retryCnt:"  +retryCnt +"startThread★" );
	public void startThread(int retryCnt  ){
		if(retryCnt==2){
			mapr2nd.start();	
			setCurMaprCnt(2);
		}else if(retryCnt==3){
			mapr3rd.start();
			setCurMaprCnt(3);
		}		
	}
	public void releaseThread(int retryCnt  ){
		//logger.info("★ retryCnt:"  +retryCnt +"releaseThread★" );
		if(retryCnt==2){		
			mapr2nd.stopThread();
		}else if(retryCnt==3){
			mapr3rd.stopThread();
		}		
	}	
	public boolean isAlive(int retryCnt  ){
		boolean ret = false;
		if(retryCnt==2){		
			ret = mapr2nd.isAlive();
			//logger.info("★ mapr2nd.isAlive:"  +mapr2nd.isAlive() );
			
		}else if(retryCnt==3){
			//logger.info("★ mapr3rd.isAlive:"  +mapr3rd.isAlive() );
			ret = mapr3rd.isAlive();
		}		
		return ret;
	}	
	public void setMaprMap(int retryCnt , Map map ){
		if(retryCnt==2){
			mapr2nd.setMap(map);
		}else if(retryCnt==3){
			mapr3rd.setMap(map);
		}		
	}	
	
	
	
	public void execute() {
		// use ThreadPool //
		//System.gc();
		//ExecutorService executor = Executors.newFixedThreadPool(10);//creating a pool of 10 threads  		
		try {
//			logger.info("trans_ymd:"  + getTransYmd());
//			logger.info("com:"        + getCom());
//			logger.info("store:"      + getStore());
			
			MasterCrtDAO dao   = new MasterCrtDAO();
			List<Object> list = null;			
			String local_no = PropertyUtil.findProperty("communication-property", "LOCAL_SERVER_NO");
			// Search stors to make master data file(마스터데이터 파일을 만들 점포 조회)
			if((this.transid).equals("MST")){
				list = dao.selSTBDA100AT(getTransYmd(), getCom(), getStore(), local_no);	
				logger.info("this.transid: " + this.transid);
			}else if((this.transid).equals("PGM")){
				list = dao.selSTBDA100ATPGM(getTransYmd(), getCom(), getStore(), local_no);	
				logger.info("this.transid: " + this.transid);
			}else if((this.transid).equals("MSG")){
				list = dao.selSTBDA100ATMSG(getTransYmd(), getCom(), getStore(), local_no);	
			}
			
			
			totalCount = list.size();
			logger.info("MASTER CREATE total store Count : " + totalCount);

			// If there is no subjective store, print log(대상 점포가 없으면 로그찍기)
			if(totalCount < 1) {
				logger.info("[ERROR] There is no data.");
				return;
			}


			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.setTime(new Date());
			String today = sdf.format(calendar.getTime());			
			calendar.add(Calendar.DATE, 1);  
			String tran_ymd = sdf.format(calendar.getTime());
			
			/**  현재 배신생성중(OPER_ID=1)인 ROW 조회. 생성 중이라면 다른 Thread를 생성하지 않음	 */
			int in_progress_cnt = dao.selCNTINPROGRESS(today, tran_ymd,local_no);			
			if( in_progress_cnt > 0 ) {
				logger.info("++critical problem prevent(cnt=" + in_progress_cnt + ")"+" seq:"+ this.outTransSeq);
				return;
			}						

			int ret = 0;
			if((this.transid).equals("MST")){
				if (this.isUpdOperId == true){ 
					logger.info("++oper_id was updating.. so current request was ignored "); 
					return;
				}

				if (updOperId(dao , list)<=0){
					logger.info("++updSTBDA100AT0ALL update FAIL ! dont have to create Thread ret=>" + ret+" seq:"+ this.outTransSeq);
					return;
				}

			}else if((this.transid).equals("PGM") || (this.transid).equals("MSG")){
				ret = dao.updSTBDA100AT0ALLPGMMSG(list);
				return;
			}
			
			//180423 leeseungho 170at 생성방식 변경
			Map<String, String> tmpMap = (Map<String, String>)list.get(0);			
			
			if (("1".equals((String)tmpMap.get("TRANS_SEQ"))) 
				&& ((this.transid).equals("MST")) 
				&& (((String)tmpMap.get("urgent_yn")).equals("0"))){
				
				//정기마스터 생성일때에만 <trans_seq=1 , urgent_yn=0 ,trans_id="MST">
				//1. 170at 한번만 생성하여 static list170G 에 저장함 
				//2. gent170at 에서 쿼리 수행하지 않고 cnt170G 의 값이 0 이 아닌 경우 list170G 의 값을 읽어 들임
				//   0 이면 기존 대로 생성함 
				//3. 정기마스터 생성 완료후 list170G 삭제 및 cnt170G 삭제 
				list170G = dao.selectGlobalMaster(tmpMap, "SEL_STBDM170AT", 0);	
				logger.info("+ read list170G once applied");
				
			}				
			
			for(int j=0; j<list.size(); j++) {

				Map<String, String> map = (Map<String, String>)list.get(j);	
				
				MasterCrtRunner ms = new MasterCrtRunner(this);  		
				ms.setMap(map);
				
				//180423 leeseungho 170at 생성방식 변경
				if (("1".equals((String)tmpMap.get("TRANS_SEQ"))) && ((this.transid).equals("MST")) && (((String)tmpMap.get("urgent_yn")).equals("0"))){			
					ms.setList170G(list170G);	
					
				}
				executor.execute(ms);													 								
																	//MasterCrtRunner ms = new MasterCrtRunner(this);	//ms.setMap(map);	//ms.start(); // original routine
			}

	        executor.shutdown();  
	        while (!executor.isTerminated()) {   }  

	        logger.info("++Finished all threads++");  	        
			
		} catch (Exception e) {
			logger.info("", e);
			executor.shutdown();
		} finally{
			System.gc();
			//180423 leeseungho 170at 생성방식 변경
			list170G = null;

		}
		
	}
	synchronized int updOperId(MasterCrtDAO dao ,List<Object> list){
		int ret = 0;
		this.isUpdOperId = true;
		logger.info("Start updSTBDA100AT0ALL tran_seq=" + this.outTransSeq);
		ret = dao.updSTBDA100AT0ALL(list);
		this.isUpdOperId = false;				

		logger.info("End   updSTBDA100AT0ALL tran_seq=" + this.outTransSeq +"/ ret = "+ ret+" seq:"+ this.outTransSeq);

		return ret;
	}
}
