package biz.cms_MCBIrt_back;

import java.net.Socket;
import java.util.HashMap;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;

public class MCBIrtAction extends ServerAction {
	private static Logger logger = Logger.getLogger(MCBIrtAction.class);
	
	private String server_ip = "";
	private int server_port = 0;
	
	/**
	 * Receive data from SC through 9015 PORT(SC로부터 데이타를 9015 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(ActionSocket actionSocket) throws Exception {		
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		HashMap<String, String> hmCommon = new HashMap<String, String>();
		HashMap<String, String> hmData = new HashMap<String, String>();
		MCBIrtProtocol protocol = new MCBIrtProtocol();
		COMMLog df = new COMMLog();
		
		Socket extClntSock = null;
		MCBIrtConveyer conveyer = null;
		
		this.server_ip = PropertyUtil.findProperty("communication-property", "MCB_COMM_IP");
		this.server_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "MCB_COMM_PORT"));
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			df.setConnectionInfo( actionSocket.getSocket().getInetAddress().getHostAddress().toString()
								, String.valueOf(actionSocket.getSocket().getPort())
								, logger
								, "MCBIRT"
								);
			
			df.CommLogger("[pos>sms] RECV[" + rcvBuf.getBytes().length + "]:[INQ_TYPE:" + rcvBuf.substring(50, 52) + "]:[" + rcvBuf + "]");
			// Check MsgType(MsgType 확인)
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);

			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}

			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			inq_type = protocol.getRcvMCBIrtDATA(rcvDataBuf);// F7:2225 F8:2226 F9:2227
			df.CommLogger("inq_type[" + inq_type + "]"+"["+rcvDataBuf+"]");
			
			switch( inq_type ) { //F7:잔액조회 	F8:사용요청 	F9:사용취소
			
				// 잔액조회
				case 2225:
					// 로그 찍음
					df.execute("MCBIrt-BalanceMCBInq");
					hmData = protocol.getParseBalanceMCBInq(rcvDataBuf);
					//전송할 포멧으로 변경
					df.CommLogger("server_ip[" + server_ip + "]");
					df.CommLogger("server_port[" + server_port + "]");
					
					extClntSock = new Socket(server_ip, server_port);
					conveyer = new MCBIrtConveyer(extClntSock, df);
					// 잔액 조회 응답
					dataMsg = conveyer.getMCBBalanceSnd(hmCommon, hmData);
					
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
					
				// 사용 요청
				case 2226:
					df.execute("MCBIrt-UseMCBInq");
					hmData = protocol.getParseUseMCBInq(rcvDataBuf);

					extClntSock = new Socket(server_ip, server_port);
					conveyer = new MCBIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getMCBUseSnd(hmCommon, hmData);
					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99); // 정상 코드가 오든지 아니면 99에러 코드를 응답하든지.
					dataMsg = dataMsg.substring(2);
					break;
				
					//사용 취소
				case 2227:
					df.execute("MCBIrt-CancelMCBInq");
					hmData = protocol.getParseCancelMCBInq(rcvDataBuf);

					extClntSock = new Socket(server_ip, server_port);
					conveyer = new MCBIrtConveyer(extClntSock, df);
					
					dataMsg = conveyer.getMCBCancelSnd(hmCommon, hmData);

					ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
					dataMsg = dataMsg.substring(2);
					break;
			}
		}catch(Exception e) {
			ret = 29;
			retValue = "[ERROR]2:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			if( extClntSock != null ) {
				extClntSock.close();
			}
		}
		
		try {
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			String totalMsg = sendMsg + dataMsg;
			df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "]:[INQ_TYPE:" + dataMsg.substring(0, 2) + "]:[" + totalMsg + "]");
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(totalMsg)) {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] OK");
			} else {
				df.CommLogger("[sms>pos] SEND[" + totalMsg.getBytes().length + "] ERROR");
			}
		}catch(Exception e) {
			retValue = "[ERROR] " + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("MCBIRT", retValue);
		}
	}
}