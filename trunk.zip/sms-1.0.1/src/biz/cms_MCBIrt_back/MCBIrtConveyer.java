package biz.cms_MCBIrt_back;

import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import biz.comm.AES;
import biz.comm.COMMBiz;
import biz.comm.COMMConveyerFilter;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.filter.BasicStringFilter;
import kr.fujitsu.com.ffw.daemon.net.filter.Filter;
import kr.fujitsu.com.ffw.util.StringUtil;

public class MCBIrtConveyer {
	private Socket svrSock = null;
	private ActionSocket actSock = null;

	COMMLog df = null;
	
	public MCBIrtConveyer(Socket svrSock, COMMLog df) {
		this.svrSock = svrSock;
		this.df = df;
	}
	
	// ==================================== 모바일 문화 상품권 잔액 조회 START ================================================
	// 모바일 문화 상품권 잔액 조회 ( 서버 -> 문화진흥원 )
	// 인자 : 공통코드(50bytes) ,  보낼 데이터 셋 ( POS에서 보낸 실시간 데이터 송신 전문 파싱 )
	// 공통코드와 pos에서 받은 데이터를 가지고 문화진흥원에 보낼 데이터를 만들어 넣음
	// 만들어 낼 데이터대로만 만들어주면 됨
	public String getMCBBalanceSnd(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		MCBIrtProtocol protocol = new MCBIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 문화진흥원로 보낼 송신 전문
		String recvBuf = "";	// 문화진흥원에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		try {
			//actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.MCB_FILTER)));
//HEADER	
			hm.put("HEADNO"			, "9110"); 								//4  : 전문번호
			hm.put("MESSAGELENGTH"	, "0392");								//4  : membercode 부터 끝가지 400 - 8
//DATA
			hm.put("MEMBERCODE"		, "EMART24");							//7  : 컬처랜드에서 제공 받아야 함 "EMART24"
			
			//전송할 포멧으로 변경
			sendMsg = makeSendDataMCBBalanceSnd(hm);
			df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "]:[COMMAND_TYPE: [" + sendMsg + "]");
			
			// 전송할 메시지를 byte 배열로 변환
			//byte sendBytes[] = sendMsg.getBytes();
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[server>mcb] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[server>mcb] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("MCB server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[server<mcb] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			df.CommLogger("chk");
			
			//받아온 데이터를 파싱해서 json 식으로 등록해주고
			hmRecv = protocol.getParseBalanceMCBRcv(recvBuf);
			hmRecv.put("INQ_TYPE", "F7"); // 잔액조회 응답
			
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			// JSON 식으로 되어있는 데이터를 보내준다. POS로
			dataMsg = ret + makeSendDataMCBBalanceRcvRsp(hmRecv);
			df.CommLogger("★ make(to POS): " + dataMsg);
		}	
		return dataMsg;
	}
	
	// 문화 진흥원에 전송용 데이터로 설정 (SERVER -> 문화진흥원)
	private String makeSendDataMCBBalanceSnd(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,4,7
				 	,20,10,40,4,16
				 	,8,6,1,15,265
				 	};
		String strHeaders[] = {
				//HEADER				
				"HEADNO",
				"MESSAGELENGTH",
				//BODY
				"MEMBERCODE",
				
				"STORECODE",
				"SUBMEMBERCODE",
				"SUBMEMBERNAME",
				"POSCODE",
				"PINSCRACHNO",
				
				"REQUESTDATE",
				"REQUESTTIME",
				"INPUTTYPE",
				"MEMBERIP",
				"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ makeSendDataMCBBalanceSnd : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//POS 에 내리기 위한 문자열 전문 생성 ( pos <- 서버 )
	private String makeSendDataMCBBalanceRcvRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,20,10,40,4
	               ,4,16,9,9,8
	               ,6,60,199};
		String strHeaders[] = {
			  "INQ_TYPE"
			, "STORECODE"
			, "SUBMEMBERCODE"
			, "SUBMEMBERNAME"
			, "POSCODE"
			
			, "RESULTCODE"
			, "PINSCRACHNO"
			, "PINFACEVALUE"
			, "PINBALANCE"
			, "RESPONSEDATE"
			
			, "RESPONSETIME"
			, "ERRORMESSAGE"
			, "FILLER"
		};
	
		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ makeSendDataMCBBalanceRcvRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// ==================================== 모바일 문화 상품권 잔액 조회 END ================================================
	

	// ==================================== 모바일 문화 상품권 사용요청 START ================================================
	// 모바일 문화 상품권 잔액 조회 ( 서버 -> 문화진흥원 )
	// 인자 : 공통코드(50bytes) ,  보낼 데이터 셋 ( POS에서 보낸 실시간 데이터 송신 전문 파싱 )
	// 공통코드와 pos에서 받은 데이터를 가지고 문화진흥원에 보낼 데이터를 만들어 넣음
	// 만들어 낼 데이터대로만 만들어주면 됨
	public String getMCBUseSnd(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		MCBIrtProtocol protocol = new MCBIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 문화진흥원로 보낼 송신 전문
		String recvBuf = "";	// 문화진흥원에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.MCB_FILTER)));
//HEADER	
			hm.put("HEADNO"			, "9210"); 								//4  : 전문번호
			hm.put("MESSAGELENGTH"	, "0392");								//4  : membercode 부터 끝가지 400 - 8
//DATA
			hm.put("MEMBERCODE"		, "EMART24");							//7  : 컬처랜드에서 제공 받아야 함 "EMART24"
			
			//전송할 포멧으로 변경
			sendMsg = makeSendDataMCBUseSnd(hm);
			
			df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "]:[COMMAND_TYPE: [" + sendMsg + "]");
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[server>mcb] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[server>mcb] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("MCB server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[server<mcb] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			df.CommLogger("chk");
			
			//받아온 데이터를 파싱해서 json 식으로 등록해주고
			hmRecv = protocol.getParseUseMCBRcv(recvBuf);
			hmRecv.put("INQ_TYPE", "F8"); // 잔액조회 응답
			
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			// JSON 식으로 되어있는 데이터를 보내준다. POS로
			dataMsg = ret + makeSendDataMCBUseRcvRsp(hmRecv);
			df.CommLogger("★ make(to POS): " + dataMsg);
		}	
		return dataMsg;
	}
	
	// 문화 진흥원에 전송용 데이터로 설정 (사용) (SERVER -> 문화진흥원)
	private String makeSendDataMCBUseSnd(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,4,7,20,10,40,4
				    ,16,9,50,8,6
				    ,1,50,15,156
				 	};
		String strHeaders[] = {
				//HEADER				
				"HEADNO",
				"MESSAGELENGTH",
				//BODY
				"MEMBERCODE",
				
				"STORECODE",
				"SUBMEMBERCODE",
				"SUBMEMBERNAME",
				"POSCODE",
				
				"PINSCRACHNO",
				"REQUESTAMOUNT",
				"MEMBERCONTROLCODE",
				"REQUESTDATE",
				"REQUESTTIME",
				
				"INPUTTYPE",
				"PRODUCTNAME",
				"MEMBERIP",
				"FILLER"
		};
		
		for (int i = 0; i < nlens.length; i++) {
//			df.CommLogger("★ makeSendDataMCBUseSnd : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	
	
	//POS 에 내리기 위한 문자열 전문 생성 ( pos <- 서버 )
	private String makeSendDataMCBUseRcvRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {2,20,10,40,4
	               ,4,16,25,50,8
	               ,6,9,9,9,60,115
	               };
		String strHeaders[] = {
			  "INQ_TYPE"     // F8 모바일문화상품권 사용요청
			, "STORECODE"    // 사용처
			, "SUBMEMBERCODE"// 사용처 점포코드
			, "SUBMEMBERNAME"// 사용처 점포명
			, "POSCODE"      // POS 코드
			
			, "RESULTCODE"   // 응답코드 0000 정상 / XXXX ERROR CODE
			, "PINSCRACHNO"  // 문화상품권 번호
			, "CONTROLCODE"  // 컬쳐랜드 거래번호
			, "MEMBERCONTROLCODE" // 사용처 거래번호
			, "RESPONSEDATE"  //사용일자
			
			, "RESPONSETIME" // 사용시간
			, "PINFACEVALUE" // 모바일문화상품권 금액(액면)
			, "LEVYAMOUNT"   // 모바일문화상품권 사용금액
			, "PINBALANCE"   // 모바일문화상품권 잔액
			, "ERRORMESSAGE" // 응답메시지
			, "FILLER"       // SPACE
		};
	
	
		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ makeSendDataMCBUseRcvRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// ==================================== 모바일 문화 상품권 사용요청 END ================================================
	
	// ==================================== 모바일 문화 상품권 사용취소 START ================================================
	// 모바일 문화 상품권 잔액 조회 ( 서버 -> 문화진흥원 )
	// 인자 : 공통코드(50bytes) ,  보낼 데이터 셋 ( POS에서 보낸 실시간 데이터 송신 전문 파싱 )
	// 공통코드와 pos에서 받은 데이터를 가지고 문화진흥원에 보낼 데이터를 만들어 넣음
	// 만들어 낼 데이터대로만 만들어주면 됨
	public String getMCBCancelSnd(HashMap<String, String> hmComm, HashMap<String, String> hm) throws Exception {
		MCBIrtProtocol protocol = new MCBIrtProtocol();
		HashMap<String, String> hmRecv = new HashMap<String, String>();
		
		String sendMsg = "";	// 문화진흥원로 보낼 송신 전문
		String recvBuf = "";	// 문화진흥원에서 받을 응답 전문
		String dataMsg = "";	// POS로 보낼 응답 전문
		String ret = "00";
		
		try {
			actSock = new ActionSocket(this.svrSock, (Filter)(new COMMConveyerFilter(COMMBiz.MCB_FILTER)));
//HEADER	
			hm.put("HEADNO"			, "9310"); 								//4  : 전문번호
			hm.put("MESSAGELENGTH"	, "0392");								//4  : membercode 부터 끝가지 400 - 8
//DATA
			hm.put("MEMBERCODE"		, "EMART24");							//7  : 컬처랜드에서 제공 받아야 함 "EMART24"
			
			//전송할 포멧으로 변경
			sendMsg = makeSendDataMCBCancelSnd(hm);
			
			df.CommLogger("[sms>dgbupay] SEND[" + sendMsg.getBytes().length + "]:[COMMAND_TYPE: [" + sendMsg + "]");
			
			// 전송할 메시지를 byte 배열로 변환
			byte sendBytes[] = sendMsg.getBytes();
			
			if( actSock.send(sendMsg) ) {
				df.CommLogger("[server>mcb] SEND[" + sendMsg.getBytes().length + "] OK");
			}else {
				df.CommLogger("[server>mcb] SEND[" + sendMsg.getBytes().length + "] ERROR");
				throw new Exception("MCB server is no response");
			}
			
			recvBuf = ((String)actSock.receive());
			df.CommLogger("[server<mcb] RECV[" + recvBuf.getBytes().length + "]:[JOB_CODE:]:[" + recvBuf + "]");
			df.CommLogger("chk");
			
			//받아온 데이터를 파싱해서 json 식으로 등록해주고
			hmRecv = protocol.getParseCancelMCBRcv(recvBuf);
			hmRecv.put("INQ_TYPE", "F9"); // 사용요청 취소
			
		}catch(Exception e) {
			df.CommLogger("▶ [ERROR]: " + e.getMessage());
			ret = "29";
			throw e;
		}finally {
			actSock.close();
			// JSON 식으로 되어있는 데이터를 보내준다. POS로
			dataMsg = ret + makeSendDataMCBCancelRcvRsp(hmRecv);
			df.CommLogger("★ make(to POS): " + dataMsg);
		}	
		return dataMsg;
	}
	
	// 문화 진흥원에 전송용 데이터로 설정 (SERVER -> 문화진흥원)
	private String makeSendDataMCBCancelSnd(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = {4,4
				    ,7,20,10,40,4
				 	,2,16,25,50,50
				 	,9,8,6,1,15
				 	,129
				 	};
		String strHeaders[] = {
				//HEADER				
				"HEADNO"
				,"MESSAGELENGTH"
				//BODY
				,"MEMBERCODE"
				, "STORECODE"
				, "SUBMEMBERCODE"
				, "SUBMEMBERNAME"
				, "POSCODE"
				
				, "CANCLETYPE"
				, "PINSCRACHNO"
				, "CONTROLCODE"
				, "MEMBERCONTROLCODE"
				, "MEMBERCANCELCODE"
				
				, "CANCELAMOUNT"
				, "REQUESTDATE"
				, "REQUESTTIME"
				, "INPUTTYPE"
				, "MEMBERIP"
				
				, "FILLER"      // SPACE
		};
		
		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ makeSendDataMCBCancelSnd : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		return sb.toString();
	}
	
	
	//POS 에 내리기 위한 문자열 전문 생성 ( pos <- 서버 )
	private String makeSendDataMCBCancelRcvRsp(HashMap<String, String> hm) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2,20,10,40,4
					  , 4,16,25,25
					  , 50,50,8
	                  , 6,9,9,9,60,40
	                  };
		String strHeaders[] = {
			  "INQ_TYPE"     // F9 모바일문화상품권 사용요청 취소
			, "STORECODE"    // 사용처
			, "SUBMEMBERCODE"// 사용처 점포코드
			, "SUBMEMBERNAME"// 사용처 점포명
			, "POSCODE"      // POS 코드
			
			, "RESULTCODE"   // 응답코드 0000 정상 / XXXX ERROR CODE
			, "PINSCRACHNO"  // 문화상품권 번호
			, "CANCELCONTROLCODE"  // 컬쳐랜드 취소거래번호
			, "CONTROLCODE"  // 컬쳐랜드 거래번호
			
			, "MEMBERCONTROLCODE" // 사용처 거래번호
			, "MEMBERCANCELCONTROL" // 사용처 취소거래번호
			, "RESPONSEDATE"  //사용일자
			
			, "RESPONSETIME" // 사용시간
			, "PINFACEVALUE" // 모바일문화상품권 금액(액면)
			, "LEVYAMOUNT"   // 모바일문화상품권 사용금액
			, "PINBALANCE"   // 모바일문화상품권 잔액
			, "ERRORMESSAGE" // 응답메시지
			, "FILLER"       // SPACE
		};
	
	
		for (int i = 0; i < nlens.length; i++) {
			df.CommLogger("★ makeSendDataMCBCancelRcvRsp : ["+strHeaders[i]+"]"+ (String) hm.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hm.get(strHeaders[i].toString()), nlens[i]);
		}
		
		return sb.toString();
	}
	// ==================================== 모바일 문화 상품권 사용취소 END ================================================
	
	public String rspMsgParsing(String rspCode){
		String rspMsg = "";
		if (rspCode.equals("00")){rspMsg = "정상";		
		}else if (rspCode.equals("01")){	rspMsg = "오류데이터(데이트 포멧 이상)";
		}else if (rspCode.equals("03")){	rspMsg = "SIGN 값 오류";
		}else if (rspCode.equals("04")){	rspMsg = "미발행 카드(선불카드 ID 미등록)";	//권종변경응답코드
		}else if (rspCode.equals("05")){	rspMsg = "LSAM ID 미등록";
		}else if (rspCode.equals("06")){	rspMsg = "선불카드 ID 미등록";
		}else if (rspCode.equals("07")){	rspMsg = "데이터 레코드내 중복데이터 존재";
		}else if (rspCode.equals("09")){	rspMsg = "권종불일치 (생년월일 비교)";		//권종변경응답코드
		}else if (rspCode.equals("10")){	rspMsg = "교통카드 발행사 ID 미등록";
		}else if (rspCode.equals("12")){	rspMsg = "환불불가 오류";
		}else if (rspCode.equals("51")){	rspMsg = "가맹점 ID 오류";
		}else if (rspCode.equals("52")){	rspMsg = "1회 최대 충전한도 초과";
		}else if (rspCode.equals("53")){	rspMsg = "반품기관 초과";
		}else if (rspCode.equals("54")){	rspMsg = "처리불가 거래유형 오류";
		}else if (rspCode.equals("55")){	rspMsg = "반품충전 금액 오류";
		}else if (rspCode.equals("56")){	rspMsg = "지불내역 미존재 오류";
		}else if (rspCode.equals("91")){	rspMsg = "기처리 오류";
		}else if (rspCode.equals("92")){	rspMsg = "대경 잔액";
		}else if (rspCode.equals("99")){	rspMsg = "기타 처리 불가";
		}else if (rspCode.equals("FF")){	rspMsg = "서명값 불일치";					//권종변경응답코드
		}else{	rspMsg = "알수 없는 응답코드 ";
		}
		return rspMsg;
	} 
}