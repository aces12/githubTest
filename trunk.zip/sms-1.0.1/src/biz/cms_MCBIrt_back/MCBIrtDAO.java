package biz.cms_MCBIrt_back;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class MCBIrtDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(MCBIrtDAO.class);
	
	public List<Object> getBizCoNo(String co_cd, String store_cd) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			logger.info("co_cd[" + co_cd + "]");
			//DB Connection(DB 접속)
			connect("CMGNS");

			logger.info("store_cd[" + store_cd + "]");
			sql.put(findQuery("service-sql", "SEL_HQBIZLOCMST")); //★★★★★★★쿼리추가

			sql.setString(++i, co_cd);
			sql.setString(++i, store_cd);
			logger.info("getBizCoNo");

			logger.info("sql[" + sql.debug() + "]");
			list = executeQuery(sql);
			logger.info("getBizCoNo list[" + list + "]");
		}catch(Exception e) {
			logger.info("[ERROR]" + e);
		}
		
		return list;
	}
	
	public int insTMNALINSTALL(HashMap<String, String> hm, COMMLog df) {
		SqlWrapper sql = new SqlWrapper();
		int i = 0;
		int rows = -1;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("service-sql", "INS_TMNALINSTALL"));
			sql.setString(++i, (String)hm.get("COM_CD"));
			sql.setString(++i, "A16" + (String)hm.get("STORE_CD"));
			sql.setString(++i, (String)hm.get("POS_NO"));
			sql.setString(++i, (String)hm.get("MEMBER_ID"));
			sql.setString(++i, (String)hm.get("LSAM_ID"));
			sql.setString(++i, (String)hm.get("MEMBER_NM"));
			
			rows = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]" + e);
		}finally {
			end();
		}
		
		return rows;
	}
}