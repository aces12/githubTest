package biz.cms_DaemonMonitor;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class DaemonMonitorDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(DaemonMonitorPollingAction.class);
	
	public List<Object> selBlockedTran(int srchCycle) {
		SqlWrapper sql = new SqlWrapper();
		List<Object> list = null;
		int i = 0;
		
		try {
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("tran-sql", "SEL_TRANCHECK"));
			sql.setInt(++i, srchCycle);
			
			list = executeQuery(sql);
		}catch(Exception e) {
			logger.info("[ERROR]selBlockedTran::" + e);
		}
		
		return list;
	}
	
	public int updBlockedTran(Map<String, String> map) {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery("tran-sql", "UPD_BLCKDTRAN"));
			sql.setString(++i, (String)map.get("TRAN_YMD"));
			sql.setString(++i, (String)map.get("STORE_CD"));
			sql.setString(++i, (String)map.get("POS_NO"));
			sql.setString(++i, (String)map.get("TRAN_NO"));
			sql.setString(++i, (String)map.get("COM_CD"));
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			rollback();
			logger.info("[ERROR]updBlockedTran::" + e);
		}finally {
			end();
		}
		
		return ret;
	}
}
