/*
 * SysInqAction.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */

package biz.cms_SysInfoRcv;

import java.util.HashMap;

import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.log.Appender;
import kr.fujitsu.com.ffw.daemon.core.config.log.Log;
import kr.fujitsu.com.ffw.daemon.net.ActionSocket;
import kr.fujitsu.com.ffw.daemon.net.server.ServerAction;
import kr.fujitsu.com.ffw.util.DatedFileAppender;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

/**
 * SysInqAction
 * 
 * A class that has inherited ServerAction(ServerAction을 상속받은 클래스) It processes
 * device status, system time inquiry and deployment result IRT(디바이스상태, 시스템일시
 * 조회, 배신파일결과 IRT를 처리한다).
 * 
 * @created on 1.0, 11/03/17
 * @created by oki(FUJITSU KOREA LTD.)
 * 
 * @modified on
 * @modified by
 * @caused by
 */
public class SysInfoRcvAction extends ServerAction {

	private static Logger logger = Logger.getLogger(SysInfoRcvAction.class);

	/**
	 * Receive data from SC through 9001 PORT(SC로부터 데이타를 9001 PORT로 받음).
	 * 
	 * @param ActionSocket
	 * @return
	 * @throws Exception
	 */
	public void execute(ActionSocket actionSocket) throws Exception {
		// TODO Auto-generated method stub
		int ret = 0;
		int inq_type = 0;
		String sendMsg = "";
		String dataMsg = "";
		String rcvBuf = "";
		String rcvDataBuf = "";
		String retValue = "OK!";
		HashMap hmCommon = new HashMap();
		HashMap hmData = new HashMap();
		SysInfoRcvDAO dao = new SysInfoRcvDAO();
		SysInfoRcvProtocol protocol = new SysInfoRcvProtocol();
		COMMLog df = new COMMLog();
		
		try {
			// Data received from SC(SC로부터 받은 데이타)
			rcvBuf = ((String) actionSocket.receive());
			
			if( rcvBuf.length() < COMMBiz.CM_LENS + 2 ) return;
			
			// Set Work Start Time(업무시작시간설정)
			df.setStartTime();
			df.setConnectionInfo(actionSocket.getSocket().getInetAddress()
					.getHostAddress().toString(),
					String.valueOf(actionSocket.getSocket().getPort()), logger,
					"SYSINQ");
			
			// edf.CommLogger(rcvBuf);
			// Check MsgType(MsgType 확인)
			//df.CommLogger("▶ 0: Receive Data: " + rcvBuf);
			hmCommon = COMMBiz.getData(rcvBuf, COMMBiz.CM_HEADER);
			//df.CommLogger ("comCD==>" + (String)hmCommon.get("COM_CD") + "!!");	
			// Compare to see if MsgType message type value is IRT(전문구분값이 IRT인지
			// 비교한다).
			if (!(COMMBiz.getCommMsgType(hmCommon, COMMBiz.SYSINQ))) {
				return;
			}
			// TRAN Date(TRAN일자)
			String tranYmd = COMMBiz.getCommTranYMD(hmCommon);
			
			rcvDataBuf = rcvBuf.substring(COMMBiz.CM_LENS);
			inq_type = protocol.getRcvSysInqDATA(rcvDataBuf);
			
			df.CommLogger("[INFO] SysInfoRcvAction::inq_type::["+inq_type+"]::rcvDataBuf::["+rcvDataBuf+"]");
			switch (inq_type) {
			// 1: Send Device Status(디바이스 상태 전송) :
			case 1:
				df.execute("DEVICE");
				hmData = protocol.getParseDeviceStatus(rcvDataBuf);
				// Save to Store POS Status Table, Store POS Device Status
				// Table(점포POS상태테이블, 점포POS디바이스상태 테이블에 저장).
				ret = dao.setDeviceStatus(hmCommon, hmData, df);
				break;
			// 2: Inquire System Time(최종TRAN번호/시스템일시 조회)
			case 2:
				df.execute("SYSYMD");
				hmData = protocol.getParseSystemTime(rcvDataBuf);
				dataMsg = dao.selSystemTime(hmCommon, hmData, df);
				// System Time Inquiry Response Data Part(최종TRAN번호/시스템일시조회 응답데이타부)
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			// 3: (통신/명령체크 요청)
			case 3:
				df.CommLogger("▶ 1: Receive Data: " + rcvBuf);
				df.execute("BAESINREQ");
				hmData = protocol.getParseBaesinReq(rcvDataBuf);
//				dao.procPosStatus(hmCommon, df);
				dataMsg = dao.getBaesinReq(hmCommon, hmData, df);
				// Baesin Req Inquiry Response Data Part(배신정보확인 응답데이타부)
				ret = COMMBiz.toInteger(dataMsg.substring(0, 2), 99);
				dataMsg = dataMsg.substring(2);
				break;
			// 6: (파일변경완료 요청)
			case 6:
				df.execute("BAESINRES");
				hmData = protocol.getParseBaesinRes(rcvDataBuf);
				ret = dao.setBaesinRes(hmCommon, hmData, df);
				dataMsg = "";
				break;
			// 33: (시스템정보 전송 요청)
			case 33:
				
				if( rcvDataBuf.getBytes().length <= 445 ) {
					hmData = protocol.getParseSystemInfo(rcvDataBuf);
					ret = dao.setSystemInfo(hmCommon, hmData, df);					
				} else if( rcvDataBuf.getBytes().length <= 477) {
					hmData = protocol.getParseSystemInfoExt(rcvDataBuf);
					ret = dao.setSystemInfoExt(hmCommon, hmData, df);					
				} else if( rcvDataBuf.getBytes().length == 549 ) {
					hmData = protocol.getParseSystemInfoExt3(rcvDataBuf);
					ret = dao.setSystemInfoExt3(hmCommon, hmData, df);					
				} else {
					hmData = protocol.getParseSystemInfoExt2(rcvDataBuf);
					ret = dao.setSystemInfoExt2(hmCommon, hmData, df);
						 				
				}
				
				dataMsg = Integer.toString(ret);
				break;

			default:
				df.CommLogger("▶ INQ Type Code(INQ 종별 코드):   [" + inq_type
						+ "]" + rcvBuf.length());
				ret = 99;
				break;
			}
		} catch (Exception e) {
			// 029=HOST APPL ERR
			ret = 29;
			retValue = "[ERROR]2:" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		}

		try {
			//df.CommLogger("--- makeSendData:(" + dataMsg.getBytes().length + ")" + dataMsg);
			// Make Response Message Data(응답 전문데이타 만들기)
			sendMsg = COMMBiz.makeSendData(hmCommon, dataMsg.getBytes().length, ret);
			// Send Response Data(응답 데이타 전송)
			if (actionSocket.send(sendMsg + dataMsg)) {
				//df.CommLogger("▶ 2: SEND MSG: " + sendMsg + "/"
				//		+ sendMsg.getBytes().length);
				//df.CommLogger("▶ 3: DATA MSG: " + dataMsg + "/"
				//		+ dataMsg.getBytes().length);

				// 배신정보 전송 결과 업데이트(전송건수가 있을때)
				if (inq_type == 3 && dataMsg.length() > 0) {
					dao.setBaesinReqStatus(hmCommon, hmData, df);
				}
			} else {
				df.CommLogger("▶ [ERROR]5: " + sendMsg + " ==>LEN: "
						+ sendMsg.getBytes().length);
			}
		} catch (Exception e) {
			retValue = "[ERROR]4" + e.getMessage();
			df.CommLogger("▶ " + retValue);
		} finally {
			// IRT Work Finish Log(IRT 업무 종료 로그)
			df.close("SYSINQ", retValue);
		}
	}

}
