/*
 * SysInqDAO.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_SysInfoRcv;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.COMMLog;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.model.DataTypes;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.ProcedureResultSet;
import kr.fujitsu.com.ffw.model.ProcedureWrapper;
import kr.fujitsu.com.ffw.model.SqlWrapper;
import kr.fujitsu.com.ffw.util.StringUtil;

/**
 * SysInqDAO
 * A class that has inherited GenericDAO(GenericDAO를 상속받은 클래스)
 * It is responsible for functions to access DB to retrieve respective information(DB에 접속하여 해당 정보를 조회해 오거나)
 * or update DB information(DB정보를 업데이트 하는 기능을 담당한다).
 * @created on 1.0, 11/03/17
 * @created by oki(FUJITSU KOREA LTD.)
 * 
 * @modified on
 * @modified by
 * @caused by
 */
public class SysInfoRcvDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(SysInfoRcvAction.class);
	/***************************************************************************
	 * selSystemTime Search System Date(최종TRAN번호/시스템일자 조회) 
	 * 
	 * @param tranYmd
	 * @param hm
	 * @return datamsg
	 * @throws Exception
	 */
	public String selSystemTime(HashMap hmCommon, HashMap hmData, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		SqlWrapper sql2 = new SqlWrapper();
		List list = null;
		boolean isNewDeploy = false;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		boolean bSucc = false;
		// DB Connection(DB 접속)
		connect("CMGNS");

		try {
			sql.clearParameter();
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, "SEL_NEW_DEPLOY_ST"));
			sql.setString(++i, (String) hmCommon.get("STORE_CD"));
			sql.setString(++i, (String) hmCommon.get("COM_CD"));
			list = executeQuery(sql);
			if (list.size() > 0) {

				Map<String, String> m = (Map<String, String>)list.get(0);
				if( ((String)m.get("NEWDEPLOY_YN")).equals("Y") ) {
					isNewDeploy = true;
//					df.CommLogger("NEWDEPLOY_YN=>" + (String)m.get("NEWDEPLOY_YN")); //` test
				}
			}
		} catch(SQLException e){ 
			logger.info("1111sql==>"+ sql.debug());
			
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴)
			ret = "20";
		} catch (Exception e) {
			logger.info("2222sql==>"+ sql.debug());
			df.CommLogger("▶ SEL Error : " + e);
			ret = "29";
			throw e;
		} 
		df.CommLogger("0-1 ret=>" + ret);
		//df.CommLogger("0-2 neo0531");	
		try {
			sql2.clearParameter();
			i=0;
			list.clear();
			list = null;
			//df.CommLogger("0-3 neo0531");
			sql2.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_SEL_STTRP110DT));
			sql2.setString(++i, (String) hmCommon.get("TRAN_YMD"));
			sql2.setString(++i, (String) hmCommon.get("COM_CD"));
			sql2.setString(++i, (String) hmCommon.get("STORE_CD"));
			sql2.setString(++i, (String) hmCommon.get("POS_NO"));
			//df.CommLogger("121212sql==>"+ sql2.debug());
			//logger.info("121212sql==>"+ sql2.debug());
			
			list = executeQuery(sql2);
			
			df.CommLogger( "TRAN_YMD▶"+ (String) hmCommon.get("TRAN_YMD")
					+ "COM_CD▶"+ (String) hmCommon.get("COM_CD")
					+ "STORE_CD▶"+ (String) hmCommon.get("STORE_CD")
					+ "POS_NO▶"+ (String) hmCommon.get("POS_NO")
					+ "SYS_YMDHMS▶"+ (String) hmCommon.get("SYS_YMDHMS")
					+ "LIST_SIZE▶"+ list.size()
					);			
			if (list.size() > 0) {
				map = (Map) list.get(0);
				String sysYMDHMS = (String) map.get("SYS_YMDHMS");
				if (sysYMDHMS.length() > 1) {
					map.put("SYS_YMD", (String) map.get("SYS_YMD"));
					map.put("SYS_HMS", (String) map.get("SYS_HMS"));
					bSucc = true;
				}
			}
			if (!bSucc) {
				map.put("TRAN_NO", " ");
				map.put("SYS_YMDHMS", " ");
				map.put("SYS_YMD", " ");
				map.put("SYS_HMS", " ");
				ret = "29";
			}

			hmData.put("INQ_TYPE", "02");
			logger.info("2-11");
			if(isNewDeploy){
				logger.info("2-12");
				if (ret.equals("00")){
					hmData.put("RES_CD", "S1");
				}else{
					hmData.put("RES_CD", "F1");	
				}				
			}else{
				df.CommLogger("2-1 ret=>" + ret);				
				logger.info("2-13");
				hmData.put("RES_CD", ret);				
			}
			logger.info("2-14");
			hmData.put("TRAN_NO", (String) map.get("TRAN_NO"));
			hmData.put("SYS_YMDHMS", (String) map.get("SYS_YMDHMS"));

		} catch(SQLException e){ 
			logger.info("3333sql==>"+ sql2.debug());
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴)
			ret = "20";
		} catch (Exception e) {
			logger.info("4444sql==>"+ sql2.debug());
			df.CommLogger("▶ SEL Error : " + e);
			ret = "29";
			throw e;
		} finally {
			dataMsg = ret + makeSysTimeSendData(hmData);
			df.CommLogger("★ make: " + dataMsg);
		}
		df.CommLogger("0-1 neo0531");
		return dataMsg;
	}

	
	public String selSystemTime2(HashMap hmCommon, HashMap hmData, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String dataMsg = "";
		String ret = "00";
		boolean bSucc = false;
		// DB Connection(DB 접속)
		connect("CMGNS");
		
		
		
		try {			
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_SEL_STTRP110DT));
			sql.setString(++i, (String) hmCommon.get("TRAN_YMD"));
			sql.setString(++i, (String) hmCommon.get("COM_CD"));
			sql.setString(++i, (String) hmCommon.get("STORE_CD"));
			sql.setString(++i, (String) hmCommon.get("POS_NO"));

			list = executeQuery(sql);
			if (list.size() > 0) {
				map = (Map) list.get(0);
				String sysYMDHMS = (String) map.get("SYS_YMDHMS");
				if (sysYMDHMS.length() > 1) {
					map.put("SYS_YMD", (String) map.get("SYS_YMD"));
					map.put("SYS_HMS", (String) map.get("SYS_HMS"));
					bSucc = true;
				}
			}
			if (!bSucc) {
				map.put("TRAN_NO", " ");
				map.put("SYS_YMDHMS", " ");
				map.put("SYS_YMD", " ");
				map.put("SYS_HMS", " ");
				ret = "29";
			}

			hmData.put("INQ_TYPE", "02");
			hmData.put("RES_CD", ret);
			hmData.put("TRAN_NO", (String) map.get("TRAN_NO"));
			hmData.put("SYS_YMDHMS", (String) map.get("SYS_YMDHMS"));

		} catch(SQLException e){ 	
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getErrorCode());
			//  Return 20 DB ERROR(20 DB ERROR 리턴)
			ret = "20";
		} catch (Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			ret = "29";
			throw e;
		} finally {
			dataMsg = ret + makeSysTimeSendData(hmData);
			//df.CommLogger("★ make: " + dataMsg);
		}

		return dataMsg;
	}

	/***************************************************************************
	 * makeSysTimeSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeSysTimeSendData(HashMap hmData) {
		StringBuffer sb = new StringBuffer();
		int nlens[] = { 2, 2, 4, 14 };
		String strHeaders[] = {
				"INQ_TYPE",   // "02": Search System Time(시스템 일시 조회)
				"RES_CD",    // Result Code(결과코드) 00:Normal(정상), 01:Incorrect Store Code(점코드틀림), 99:Others(그외 기타)
				"TRAN_NO",   // TRAN No. (TRAN 번호)
				"SYS_YMDHMS" // System Time HHHHMMDDHHMMSS(시스템 일시 HHHHMMDDHHMMSS)
		};

		for (int i = 0; i < nlens.length; i++) {
			StringUtil.appendSpace(sb, (String) hmData.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}

	/***************************************************************************
	 * getTranID
	 * 
	 * @param code
	 * @return String Tran ID
	 */
	private String getTranID(String code) {
		String[] tranID = {"ERR", "PGM", "MST", "CUSTDSP", "FFIMG", "POSDLL", "", "",
				"PDADLL", "UNKNOWN" };

		String ret;
		try {
			ret = (String) tranID[COMMBiz.toInteger((String) code, -1)];
		} catch (Exception e) {
			ret = "";
		}

		return ret;
	}

	/***************************************************************************
	 * Deployment-Device Status(배신-디바이스 상태)
	 * 
	 * @param hm
	 * @return
	 * @throws Exception
	 */
	public int setDeviceStatus(HashMap hmCommon, HashMap hmData, COMMLog df) throws Exception {
		int i = 0, j = 0;
		int cnt = 0;
		int bIndex = 0;
		int eIndex = 0;
		int ret = 0;
		int row = 0;
		SqlWrapper sql = new SqlWrapper();
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			logger.info("AA");
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_DEL_STBDA111AT));
			sql.setString(++i, (String) hmCommon.get("TRAN_YMD"));
			sql.setString(++i, (String) hmCommon.get("COM_CD"));
			sql.setString(++i, (String) hmCommon.get("STORE_CD"));
			sql.setString(++i, (String) hmCommon.get("POS_NO"));
			row = executeUpdate(sql);
//			df.CommLogger("▶ DEL_STBDS111AT : " + row);
//			df.CommLogger("▶  AGREE_REQ_YMD:" + (String) hmCommon.get("TRAN_YMD"));
//			df.CommLogger("▶  COM_CD:" + (String) hmCommon.get("COM_CD"));
//			df.CommLogger("▶  STORE_CD:" + (String) hmCommon.get("STORE_CD"));
//			df.CommLogger("▶  POS_NO:" + (String) hmCommon.get("POS_NO"));
			logger.info("BB");
			i = 0;
			sql = new SqlWrapper();
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_DEL_STBDA110AT));
			sql.setString(++i, (String) hmCommon.get("TRAN_YMD"));
			sql.setString(++i, (String) hmCommon.get("COM_CD"));
			sql.setString(++i, (String) hmCommon.get("STORE_CD"));
			sql.setString(++i, (String) hmCommon.get("POS_NO"));
			row = executeUpdate(sql);
//			df.CommLogger("▶ DEL_STBDS110AT : " + row);
//			df.CommLogger("▶  AGREE_REQ_YMD:" + (String) hmCommon.get("TRAN_YMD"));
//			df.CommLogger("▶  COM_CD:" + (String) hmCommon.get("COM_CD"));
//			df.CommLogger("▶  STORE_CD:" + (String) hmCommon.get("STORE_CD"));
//			df.CommLogger("▶  POS_NO:" + (String) hmCommon.get("POS_NO"));

			logger.info("CC");
			i = 0;
			sql = new SqlWrapper();
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_INS_STBDA110AT));
			sql.setString(++i, (String) hmCommon.get("TRAN_YMD"));
			sql.setString(++i, (String) hmCommon.get("COM_CD"));
			sql.setString(++i, (String) hmCommon.get("STORE_CD"));
			sql.setString(++i, (String) hmCommon.get("POS_NO"));
			sql.setString(++i, (String) hmData.get("POSPGM_VER"));
			sql.setString(++i, (String) hmData.get("POSMST_VER"));
			sql.setString(++i, (String) hmData.get("POS_TY"));
			sql.setString(++i, (String) hmData.get("DEVICE_CNT"));
			row = executeUpdate(sql);
//			df.CommLogger("▶ INS_STBDS110AT : " + row);
//			df.CommLogger("▶  AGREE_REQ_YMD:" + (String) hmCommon.get("TRAN_YMD"));
//			df.CommLogger("▶  COM_CD:" + (String) hmCommon.get("COM_CD"));
//			df.CommLogger("▶  STORE_CD:" + (String) hmCommon.get("STORE_CD"));
//			df.CommLogger("▶  POS_NO:" + (String) hmCommon.get("POS_NO"));
//			df.CommLogger("▶  POSPGM_VER:" + (String) hmData.get("POSPGM_VER"));
//			df.CommLogger("▶  POSMST_VER:" + (String) hmData.get("POSMST_VER"));
//			df.CommLogger("▶  POS_TY:" + (String) hmData.get("POS_TY"));
//			df.CommLogger("▶  DEVICE_CNT:" + (String) hmData.get("DEVICE_CNT"));

			logger.info("DD");
			cnt = Integer.parseInt((String) hmData.get("DEVICE_CNT"));
			String Device_Status = (String) hmData.get("DEVICE_INFO");

			bIndex = 0;
			eIndex = 2;
			for (j = 0; j < cnt; j++) {
				i = 0;
				sql = new SqlWrapper();
				sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_INS_STBDA111AT));
				sql.setString(++i, (String) hmCommon.get("TRAN_YMD"));
				sql.setString(++i, (String) hmCommon.get("COM_CD"));
				sql.setString(++i, (String) hmCommon.get("STORE_CD"));
				sql.setString(++i, (String) hmCommon.get("POS_NO"));

//				df.CommLogger("▶ INS_STBDS111AT (" + j + "):" + row);
//				df.CommLogger("▶  AGREE_REQ_YMD:" + (String) hmCommon.get("TRAN_YMD"));
//				df.CommLogger("▶  COM_CD:" + (String) hmCommon.get("COM_CD"));
//				df.CommLogger("▶  STORE_CD:" + (String) hmCommon.get("STORE_CD"));
//				df.CommLogger("▶  POS_NO:" + (String) hmCommon.get("POS_NO"));

				sql.setString(++i, Device_Status.substring(bIndex, eIndex));
//				df.CommLogger("▶  device_cd:"
//						+ Device_Status.substring(bIndex, eIndex));
				bIndex = eIndex;
				eIndex = eIndex + 1;
				sql.setString(++i, Device_Status.substring(bIndex, eIndex));
//				df.CommLogger("▶  device_stat:"
//						+ Device_Status.substring(bIndex, eIndex));
				bIndex = eIndex;
				eIndex = eIndex + 2;
				logger.info(sql.debug());
				row = executeUpdate(sql);
			}

		} catch (Exception e) {
			ret = 99;
			rollback();
			df.CommLogger("▶[ERROR]1: " + e.getMessage());
			throw e;
		} finally {
			end();
		}

		return ret;
	}

	/***************************************************************************
	 * makeManualReqSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeManualReqSendData(HashMap hmData, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		int nlens[]= {2,2,1,14,15,100,20,30};
		String strHeaders[] = {
				"INQ_TYPE"			, // INQ Type(INQ 종별 : 07)    
				"FILE_KIND"			, // Detail Kind(상세종별) 
				"FILE_APP_TY"		, // Application Type(적용 구분 0:일반배신, 1:즉시적용)
				"FILE_APP_YMD"		, // Application Date(적용일자 YYYYMMDD)
				"FILE_HQ_IP"		, // Application Server IP(FTP Server IP)
				"FILE_PATH"			, // Application Path(FTP Server File Path)
				"FILE_NM"			, // Application Filename(FTP Server Filename)
				"FILE_VER"			  // File Version(파일버전)
			};

		for (int i = 0; i < nlens.length; i++) {
			//df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hmData.get(strHeaders[i].toString()));
			StringUtil.appendSpace(sb, (String) hmData.get(strHeaders[i].toString()), nlens[i]);
		}

		return sb.toString();
	}
	
	/***************************************************************************
	 * procPosStatus(POS Alive여부 Update) 
	 * 
	 * @param hmCommon
	 * @param df
	 * @return ret
	 * @throws Exception
	 */
	public int procPosStatus(HashMap<String, String> hmCommon, COMMLog df) throws Exception {
   		ProcedureWrapper proc = new ProcedureWrapper();
		int i = 0;
		int ret = 0;
		
		try {
			begin();
			
			//DB Connection(DB 접속)
			connect("CMGNS");
			
			//df.CommLogger("[DEBUG] [procPosStatus] Begin");
			proc.put("SP_PS_POSSTATERCV_TRN", 5);
			proc.setString(++i, (String)hmCommon.get("COM_CD"));	// 회사코드
			proc.setString(++i, (String)hmCommon.get("STORE_CD"));	// 점포코드
			proc.setString(++i, (String)hmCommon.get("POS_NO"));	// POS번호
			proc.registerOutParameter(++i, DataTypes.INTEGER);	// 오류코드(0:정상, ~9:오류)
			proc.registerOutParameter(++i, DataTypes.VARCHAR);	// 처리결과 메시지
			
			ProcedureResultSet prs = super.executeUpdateProcedure(proc);
			
			ret = prs.getInt(4);
			String retMsg = prs.getString(5);
			//df.CommLogger("[DEBUG] [procPosStatus] ResultMsg:" + retMsg);
			//df.CommLogger("[DEBUG] [procPosStatus] End");
		}catch(Exception e) {
			rollback();
			df.CommLogger("[ERROR] procPosStatus::" + e);
			ret = -1;
		}finally {
			end();
		}
		
		return ret;
	}


	/***************************************************************************
	 * getBaesinReq Search System Date(배신정보확인 조회) 
	 * 
	 * @param tranYmd
	 * @param hm
	 * @return datamsg
	 * @throws Exception
	 */
	public String getBaesinReq(HashMap hmCommon, HashMap hmData, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		List list = null;
		Map map = new HashMap();
		int i = 0;
		String fileAppTy = "";
		String fileKind = "";
		String urgent_yn = "";
		String dataMsg = "";
		String ret = "00";
		boolean bSucc = false;	
		boolean bNewDeployYN = false;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			// NEW_배포방식여부 조회
			//sql.clearParameter();
/*			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, "SEL_NEW_DEPLOY_ST"));
			sql.setString(++i, (String) hmCommon.get("STORE_CD"));
			sql.setString(++i, (String) hmCommon.get("COM_CD"));
			//logger.info("neo0531"); //neo0531 test
			list = executeQuery(sql);
			//logger.info("neo0531 - sql.debug()" + sql.debug()); //neo0531 test
			sql.close();
			if (list.size() > 0) {

				Map<String, String> m = (Map<String, String>)list.get(0);
				if( ((String)m.get("NEWDEPLOY_YN")).equals("Y") ) {
					bNewDeployYN = true;					
				}else {
					bNewDeployYN = false;
				}
				//logger.info("NEWDEPLOY_YN=>" + (String)m.get("NEWDEPLOY_YN")); //neo0531 test
				//logger.info("bNewDeployYN=>" + bNewDeployYN); //neo0531 test
			}*/
			
//			OLD routine
//			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, "SEL_NEWDEPLOY_YN"));
//			sql.setString(++i, "A16" + (String)hmCommon.get("STORE_CD"));
//			sql.setString(++i, (String)hmCommon.get("POS_NO"));
//			sql.setString(++i, (String)hmCommon.get("COM_CD"));
//			list = executeQuery(sql);
//			sql.close();
//			
//			Map<String, String> m = (Map<String, String>)list.get(0);
//			if( ((String)m.get("NEWDEPLOY_YN")).equals("Y") ) {
//				bNewDeployYN = true;
//			}else {
//				bNewDeployYN = false;
//			}
			
			i = 0;
			sql.clearParameter();
			list = null;
			
			
			fileAppTy = (String) hmData.get("FILE_APP_TY");
			if (fileAppTy.equals("0"))
				urgent_yn = "0";
			else
				urgent_yn = "1";

			
			fileKind = (String) hmData.get("FILE_KIND");
			if (fileKind.equals("00"))
				fileKind = "%";
			else if (fileKind.equals("01"))
				fileKind = "PGM";
			else if (fileKind.equals("02"))
				fileKind = "MST";
			else if (fileKind.equals("03"))
				fileKind = "CUSTDSP";
			else if (fileKind.equals("04"))
				fileKind = "FFIMG";
			else if (fileKind.equals("05"))
				fileKind = "POSDLL";
			else
				fileKind = "%";

			//0:정기요청(해당일자:미전송분), 2:긴급요청(해당일자:미전송분), 3:수동요청(일자무시:기전송분포함)
//			if (fileAppTy.equals("0") || fileAppTy.equals("2")) {
//				sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_SEL_STBDA100AT_1));
//				sql.setString(++i, (String) hmCommon.get("TRAN_YMD"));
//				sql.setString(++i, (String) hmCommon.get("COM_CD"));
//				sql.setString(++i, (String) hmCommon.get("STORE_CD"));
//				sql.setString(++i, (String) hmCommon.get("POS_NO"));
//				sql.setString(++i, fileKind);
//				sql.setString(++i, urgent_yn);
			if (fileAppTy.equals("0")) {		// 정기요청
				
				//20180110 ksn 경영주 업무개선 적용 (PGM인경우, 조회기준 7일전 미적용 프로그램파일 있는경우 조회되도록)
				if("PGM".equals(fileKind)){
					sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_SEL_STBDA100AT_4));
					//sql.setString(++i, (String) hmCommon.get("TRAN_YMD"));
					//sql.setString(++i, (String) hmCommon.get("TRAN_YMD"));
					sql.setString(++i, (String) hmCommon.get("COM_CD"));
					sql.setString(++i, (String) hmCommon.get("STORE_CD"));
					sql.setString(++i, (String) hmCommon.get("POS_NO"));
					sql.setString(++i, fileKind);
					sql.setString(++i, "0");
					sql.setString(++i, "0");
				}else{
//				if( bNewDeployYN ) {
//					sql.put(findQuery("master-sql", "SEL_STBDA120AT_1"));
//				}else {
//					sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_SEL_STBDA100AT_1));
//				}
					sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_SEL_STBDA100AT_1));
					
					sql.setString(++i, (String) hmCommon.get("TRAN_YMD"));
					sql.setString(++i, (String) hmCommon.get("COM_CD"));
					sql.setString(++i, (String) hmCommon.get("STORE_CD"));
					sql.setString(++i, (String) hmCommon.get("POS_NO"));
					sql.setString(++i, fileKind);
					sql.setString(++i, "0");
					sql.setString(++i, "0");
				}
				df.CommLogger("★ make send SQL: SEL_STBDA120AT_1  "+ sql.debug());
			} else if(fileAppTy.equals("2")) {	// 긴급요청
//				if( bNewDeployYN ) {
//				sql.put(findQuery("master-sql", "SEL_STBDA120AT_1"));
//			}else {
				sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_SEL_STBDA100AT_1));
//			}
			sql.setString(++i, (String) hmCommon.get("TRAN_YMD"));
			sql.setString(++i, (String) hmCommon.get("COM_CD"));
			sql.setString(++i, (String) hmCommon.get("STORE_CD"));
			sql.setString(++i, (String) hmCommon.get("POS_NO"));
			sql.setString(++i, fileKind);
			sql.setString(++i, "1");
			sql.setString(++i, "2");
		} else if(fileAppTy.equals("5")) {	// 신규배신 2017.04.28  by OHT
			String inPutDay = (String) hmCommon.get("TRAN_YMD"); 
			String outPutDay = "";
			
	        Calendar calendar = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	        calendar.setTime(sdf.parse(inPutDay));
	        calendar.add(Calendar.DATE, +1);

	        outPutDay = sdf.format(calendar.getTime());
	        
//				if( bNewDeployYN ) {
//				sql.put(findQuery("master-sql", "SEL_STBDA120AT_1"));
//			}else {
				sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_SEL_STBDA100AT_1));
//			}
			sql.setString(++i, outPutDay);
			sql.setString(++i, (String) hmCommon.get("COM_CD"));
			sql.setString(++i, (String) hmCommon.get("STORE_CD"));
			sql.setString(++i, (String) hmCommon.get("POS_NO"));
			sql.setString(++i, fileKind);
			sql.setString(++i, "0");
			sql.setString(++i, "0");
			df.CommLogger("★ make send SQL: new SEL_STBDA120AT_1  "+ sql.debug());
		} else {							// 수동요청
//				if( bNewDeployYN ) {
//					sql.put(findQuery("master-sql", "SEL_STBDA120AT_2"));
//				}else {
					sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_SEL_STBDA100AT_2));
//				}
				sql.setString(++i, "%");
				sql.setString(++i, (String) hmCommon.get("COM_CD"));
				sql.setString(++i, (String) hmCommon.get("STORE_CD"));
				sql.setString(++i, (String) hmCommon.get("POS_NO"));
				sql.setString(++i, fileKind);
			}

			list = executeQuery(sql);
			
			//3:수동요청의 최종마스터가 긴급마스터일 경우 전송하지 않음
			if(fileAppTy.equals("3")) {
				if(list.size() > 0) {
					map = (Map<String, String>)list.get(0);
					if(map.get("URGENT_YN").equals("1")) {
						list.clear();
						df.CommLogger("▶ Last time Master is URGENT");
					}
				}
			}
			
			if (list.size() > 0) {
				map = (Map) list.get(0);
				String fileDir  = (String) map.get("TRANS_FILE_DIR");
				if (fileDir.length() > 1) {
					int dot         = fileDir.lastIndexOf("/");

					// 응답전문용 데이터를 입력해 둔다.
					hmData.put("INQ_TYPE", "04");
					if (map.get("TRANS_ID").equals("PGM"))
						hmData.put("FILE_KIND", (String) "01");
					else if (map.get("TRANS_ID").equals("MST"))
						hmData.put("FILE_KIND", (String) "02");
					else if (map.get("TRANS_ID").equals("CUSTDSP"))
						hmData.put("FILE_KIND", (String) "03");
					else if (map.get("TRANS_ID").equals("FFIMG"))
						hmData.put("FILE_KIND", (String) "04");
					else if (map.get("TRANS_ID").equals("POSDLL"))
						hmData.put("FILE_KIND", (String) "05");
					hmData.put("FILE_APP_TY", (String) map.get("URGENT_YN"));
					hmData.put("FILE_APP_YMD", (String) map.get("TRANS_YMD"));
					hmData.put("FILE_HQ_IP", (String) PropertyUtil.findProperty("stsys-property", "FTP_SERVER_IP"));
					hmData.put("FILE_HQ_PORT", (String) " ");
					hmData.put("FILE_PATH", (String) fileDir.substring( 0, dot));
					hmData.put("FILE_NM", (String) fileDir.substring( dot+1));
					hmData.put("FILE_VER", (String) map.get("TRANS_VER"));
					hmData.put("RES_CD", ret);
					bSucc = true;
				}
			}
			if (!bSucc) {
				//긴급배신 요청(MSG)
				i = 0;
				sql.close();
				sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_SEL_STBDA100AT_3));
				sql.setString(++i, (String) hmCommon.get("COM_CD"));
				sql.setString(++i, (String) hmCommon.get("STORE_CD"));
				sql.setString(++i, (String) hmCommon.get("POS_NO"));

				//df.CommLogger("★ make send SQL: "+ sql.debug());
				
				list.clear();
				list = null;
				list = executeQuery(sql);
				
				if (list.size() > 0) {
					map = (Map) list.get(0);
					String fileDir  = (String) map.get("TRANS_FILE_DIR");
					if (fileDir.length() > 1) { //TRANS_FILE_DIR 에 제목이 들어가 있음.
						// 응답전문용 데이터를 입력해 둔다.
						hmData.put("INQ_TYPE", "05");
						hmData.put("FILE_KIND", (String) "07");	// 긴급메시지 구분코드 07
						hmData.put("MSG_NO", (String) map.get("TRANS_VER"));
						hmData.put("URGENT_YN", (String) map.get("URGENT_YN"));
						hmData.put("MSG_POST_SYMD", (String) map.get("POS_SYMDHMS"));
						hmData.put("MSG_POST_EYMD", (String) map.get("POS_EYMDHMS"));
						hmData.put("MSG_TITLE", (String) map.get("MSG_TITLE"));
						hmData.put("MESSAGE", (String) map.get("MSG_CONT"));
						bSucc = true;
					}
				}
			}

		} catch(SQLException e){
			df.CommLogger( "▶ SQLException  Rollback=====>"+ e.getMessage());
			df.CommLogger( "▶ SQLException  SQL=====>"+ sql.debug());
			//  Return 20 DB ERROR(20 DB ERROR 리턴) 
			ret = "20";
			rollback();
		} catch (Exception e) {
			df.CommLogger("▶ SEL Error : " + e);
			df.CommLogger("▶ SEL Error SQL : " + sql.debug());
			ret = "29";
			rollback();
			throw e;
		} finally {
			if (!bSucc)
				if (ret == "00")
					ret = "39"; //조회된 내용이 없을시
			dataMsg = ret + makeBaesinReqSendData(hmData, df);
			//df.CommLogger("★ make: " + dataMsg);
			end();
		}

		return dataMsg;
	}

	/***************************************************************************
	 * makeBaesinReqSendData : Make Data Part Sending Data(데이타부 전송데이타를 만듬).
	 * 
	 * @param hm
	 * @return 전송메세지
	 */
	private String makeBaesinReqSendData(HashMap hmData, COMMLog df) {
		StringBuffer sb = new StringBuffer();
		
		if ((String) hmData.get("INQ_TYPE") == "31") {
			int nlens[]= {2,10,2,1,14,20,5,100,40,60,2};
			String strHeaders[] = {
					"INQ_TYPE"			, // INQ Type(INQ 종별 : 31)    
					"MSG_NO"			, // Msg No(메시지번호) 
					"BAESIN_GB"			, // Baesin Kind(배신구분) 
					"MSG_TYPE"			, // Application Type(적용 구분 0:일반배신, 1:즉시적용)
					"FILE_APP_YMD"		, // Application Date(적용일자 YYYYMMDD)
					"FILE_HQ_IP"		, // Application Server IP(FTP Server IP)
					"FILE_HQ_PORT"		, // Application Server Port(FTP Server Port)
					"FILE_PATH"			, // Application Path(FTP Server File Path)
					"FILE_NM"			, // Application Filename(FTP Server Filename)
					"FILE_VER"			, // File Version(파일버전)
					"RES_CD"			  // Result Code(응답코드)
				};

			for (int i = 0; i < nlens.length; i++) {
				//df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hmData.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) hmData.get(strHeaders[i].toString()), nlens[i]);
			}
		}
		if ((String) hmData.get("INQ_TYPE") == "04") {
			int nlens[]= {2,2,1,14,15,100,20,30};
			String strHeaders[] = {
					"INQ_TYPE"			, // INQ Type(INQ 종별 : 04)    
					"FILE_KIND"			, // File Kind(상세구분) 
					"FILE_APP_TY"		, // File App Type(적용 구분 0:일반배신, 1:즉시적용)
					"FILE_APP_YMD"		, // Application Date(적용일자 YYYYMMDD)
					"FILE_HQ_IP"		, // Application Server IP(FTP Server IP)
					"FILE_PATH"			, // Application Path(FTP Server File Path)
					"FILE_NM"			, // Application Filename(FTP Server Filename)
					"FILE_VER"			, // File Version(파일버전)
				};

			for (int i = 0; i < nlens.length; i++) {
				//df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hmData.get(strHeaders[i].toString()));
				StringUtil.appendSpace(sb, (String) hmData.get(strHeaders[i].toString()), nlens[i]);
			}
		}
		if ((String) hmData.get("INQ_TYPE") == "05") {
			int nlens[]= {2,10,1,12,12,100,1000};
			String strHeaders[] = {
					"INQ_TYPE"			, // INQ Type(INQ 종별 : 05)    
					"MSG_NO"			, // Msg No(메시지번호) 
					"URGENT_YN"			, // Application Type(적용 구분 0:일반배신, 1:즉시적용)
					"MSG_POST_SYMD"		, // POS Display Start Date(POS 표시 시작일)
					"MSG_POST_EYMD"		, // POS Display End Date(POS 표시 종료일)
					"MSG_TITLE"			, // Message Title(메시지 제목)
					"MESSAGE"			  // Message Contents(메시지 내용)
				};

			for (int i = 0; i < nlens.length; i++) {
				StringUtil.appendSpace(sb, (String) hmData.get(strHeaders[i].toString()), nlens[i]);
				//df.CommLogger("★ make send strHeaders : Len:"+sb.toString().getBytes().length +" ["+sb.toString()+"]");
			}
		}
		if ((String) hmData.get("INQ_TYPE") == "30") {
			int nlens[]= {2,2};
			String strHeaders[] = {
					"INQ_TYPE"			, // INQ Type(INQ 종별 : 05)    
					"RES_CD"			  // Result Code(응답코드)
				};

			for (int i = 0; i < nlens.length; i++) {
				df.CommLogger("★ make send strHeaders : ["+strHeaders[i]+"]"+ (String) hmData.get(strHeaders[i].toString()));
				//StringUtil.appendSpace(sb, (String) hmData.get(strHeaders[i].toString()), nlens[i]);
			}
		}

		return sb.toString();
	}

	/***************************************************************************
	 * setBaesinReqStatus : Result of Deployment Order Check Reflection(배신확인정보처리결과)
	 * 
	 * @param hm
	 * @return Return Error Code(리턴 에러코드)
	 * @throws Exception
	 */
	public int setBaesinReqStatus(HashMap hmCommon, HashMap hmData, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		String fileVer = "";
		String fileKind = "";
		df.CommLogger("▶setBaesinReqStatus Begin");
		
		if (hmData.get("INQ_TYPE").equals("04"))
			fileVer = ((String) hmData.get("FILE_VER")).trim();
		else if (hmData.get("INQ_TYPE").equals("05"))
			fileVer = ((String) hmData.get("MSG_NO")).trim();
		fileKind = ((String) hmData.get("FILE_KIND")).trim();
		if (fileKind.equals("01"))
			fileKind = "PGM";
		else if (fileKind.equals("02"))
			fileKind = "MST";
		else if (fileKind.equals("03"))
			fileKind = "CUSTDSP";
		else if (fileKind.equals("04"))
			fileKind = "FFIMG";
		else if (fileKind.equals("05"))
			fileKind = "POSDLL";
		else if (fileKind.equals("07"))
			fileKind = "MSG";
		else {
			df.CommLogger( "▶ Unknown Trans ID  Error :[fileKind]"+ (String) hmData.get("BAESIN_GB"));
			ret = 30;
			return ret;
		}
		
		df.CommLogger("File_Ver==>" +fileVer+"\n" +
				      "fileKind==>" + fileKind);
		try {
			// Record Result of File Reflection(배신정보전송결과기록)
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");

			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA100AT_0));
			//0:배신준비중,1:배신생성중,2:배신준비완료,3:배신완료,4:다운완료,5:적용완료,6:다운실패,7:적용실패,D:배포성공(SC),C:접속실패(SC)
			sql.setString(++i, (String) "3");
			sql.setString(++i, fileVer.substring(0, 8));
			sql.setString(++i, (String) hmCommon.get("COM_CD"));
			sql.setString(++i, (String) hmCommon.get("STORE_CD"));
			sql.setString(++i, (String) hmCommon.get("POS_NO"));
			sql.setString(++i, fileKind);
			sql.setString(++i, fileVer);

			ret = executeUpdate(sql);

		} catch (Exception e) {
			ret = 99;
			rollback();
			df.CommLogger("▶setBaesinReqStatus Error : " + e.getMessage());
			throw e;
		} finally {
			end();
			df.CommLogger("▶setBaesinReqStatus End");
		}

		return ret;
	}

	/***************************************************************************
	 * setBaesinRes : Result of Deployment Order Check Reflection(배신정보처리결과)
	 * 
	 * @param hm
	 * @return Return Error Code(리턴 에러코드)
	 * @throws Exception
	 */
	public int setBaesinRes(HashMap hmCommon, HashMap hmData, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		String fileVer = "";
		String fileKind = "";
		String fileAppType = "";
		//df.CommLogger("▶setBaesinRes Begin");
		List<Object> list = null;
		boolean bNewDeployYN = false;
		
		
		
		fileVer = ((String) hmData.get("FILE_VER")).trim();
		fileKind = ((String) hmData.get("FILE_KIND")).trim();
		fileAppType = ((String) hmData.get("FILE_APP_TY")).trim();
		if (fileKind.equals("01"))
			fileKind = "PGM";
		else if (fileKind.equals("02"))
			fileKind = "MST";
		else if (fileKind.equals("03"))
			fileKind = "CUSTDSP";
		else if (fileKind.equals("04"))
			fileKind = "FFIMG";
		else if (fileKind.equals("05"))
			fileKind = "POSDLL";
		else if (fileKind.equals("50"))
			fileKind = "MSG";
		else {
			df.CommLogger( "▶ Unknown Baesin Gubun  Error :[FILE_KIND]"+ (String) hmData.get("FILE_KIND"));
			ret = 30;
			return ret;
		}

		df.CommLogger("File_Ver==>" +fileVer+"\n" +
			      "FILE_KIND==>" + fileKind + "\n" +
			      "FILE_APP_TY==>" + hmData.get("FILE_APP_TY") + "\n");
		try {
			// Record Result of File Reflection(배신정보전송결과기록)
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
/*
			// 0:배신준비중,1:배신생성중,2:배신준비완료,3:배신완료,4:다운완료,5:적용완료,6:다운실패,7:적용실패,D:배포성공(SC),C:접속실패(SC)
			if (fileAppType.equals("1")) { //POS다운완료시 업데이트
				sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA100AT_1));
				sql.setString(++i, "4");
				sql.setString(++i, fileVer.substring(0, 8));
				sql.setString(++i, (String) hmCommon.get("COM_CD"));
				sql.setString(++i, (String) hmCommon.get("STORE_CD"));
				sql.setString(++i, (String) hmCommon.get("POS_NO"));
				sql.setString(++i, fileKind);
				sql.setString(++i, fileVer);
//				df.CommLogger("★ make send SQL: "+ sql.debug());
				ret = executeUpdate(sql);
			} else if (fileAppType.equals("2")) { //POS적용완료시 업데이트
				sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA100AT_2));
				sql.setString(++i, "5");
				sql.setString(++i, fileVer.substring(0, 8));
				sql.setString(++i, (String) hmCommon.get("COM_CD"));
				sql.setString(++i, (String) hmCommon.get("STORE_CD"));
				sql.setString(++i, (String) hmCommon.get("POS_NO"));
				sql.setString(++i, fileKind);
				sql.setString(++i, fileVer);
//				df.CommLogger("★ make send SQL: "+ sql.debug());
				ret = executeUpdate(sql);
			}
*/			
			// NEW_배포방식여부 조회
			
			sql.clearParameter();
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, "SEL_NEW_DEPLOY_ST"));
			sql.setString(++i, (String) hmCommon.get("STORE_CD"));
			sql.setString(++i, (String) hmCommon.get("COM_CD"));
			list = executeQuery(sql);
			sql.close();
			if (list.size() > 0) {

				Map<String, String> map = (Map<String, String>)list.get(0);
				if( ((String)map.get("NEWDEPLOY_YN")).equals("Y") ) {
					bNewDeployYN = true;
					//df.CommLogger("NEWDEPLOY_YN=>" + (String)m.get("NEWDEPLOY_YN")); //neo0531 test
				}else {
					bNewDeployYN = false;
					}
			}
			
//			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, "SEL_NEWDEPLOY_YN"));
//			sql.setString(++i, "A16" + (String)hmCommon.get("STORE_CD"));
//			sql.setString(++i, (String)hmCommon.get("POS_NO"));
//			sql.setString(++i, (String)hmCommon.get("COM_CD"));
//			list = executeQuery(sql);
//			sql.close();
//			
//			Map<String, String> map = (Map<String, String>)list.get(0);
//			if( ((String)map.get("NEWDEPLOY_YN")).equals("Y") ) {
//				bNewDeployYN = true;
//			}else {
//				bNewDeployYN = false;
//			}
			
			i = 0;
			sql.clearParameter();
			
			// 0:배신준비중,1:배신생성중,2:배신준비완료,3:배신완료,4:다운완료,5:적용완료,6:다운실패,7:적용실패,D:배포성공(SC),C:접속실패(SC)
			if(fileAppType.equals("1")) {			// POS 다운완료 시 업데이트
//				if( bNewDeployYN ) 
//					sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA120AT_1));
//				else 
					sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA100AT_1));
				
				sql.setString(++i, "4");
			}else if(fileAppType.equals("2")) {		// POS 적용완료 시 업데이트
//				if( bNewDeployYN ) 
//					sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA120AT_2));
//				else
					sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA100AT_2));
				
				sql.setString(++i, "5");
			}else if(fileAppType.equals("F")) {		// POS 다운실패 시 업데이트
//				if( bNewDeployYN )
//					sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA120AT_2));
//				else
				sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA100AT_2));
				//20180110 KSN "F"로 IRT 전송 시, 프로그램,마스터 재 다운로드 요청 가능하도록 상태값 "배포준비완료(2)"로 변경.
				if("PGM".equals(fileKind) || "MST".equals(fileKind)){
					sql.setString(++i, "2");
				}else{
					sql.setString(++i, "6");
				}
			}else if(fileAppType.equals("E")) {		// POS 적용실패 시 업데이트
//				if( bNewDeployYN )
//					sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA120AT_2));
//				else
					sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, COMMBiz.TB_UPD_STBDA100AT_2));
				
				sql.setString(++i, "7");
			}
			sql.setString(++i, fileVer.substring(0, 8));
			sql.setString(++i, (String)hmCommon.get("COM_CD"));
			sql.setString(++i, (String)hmCommon.get("STORE_CD"));
			sql.setString(++i, (String)hmCommon.get("POS_NO"));
			sql.setString(++i, fileKind);
			sql.setString(++i, fileVer);
//			df.CommLogger("★ make send SQL: "+ sql.debug());
			ret = executeUpdate(sql);
		} catch (Exception e) {
			ret = 99;
			rollback();
			df.CommLogger("▶setBaesinRes Error : " + e.getMessage());
			throw e;
		} finally {
			end();
			df.CommLogger("▶setBaesinRes End");
		}

		return ret;
	}
	
	public int setSystemInfo(HashMap<String, String> hmCommon, HashMap<String, String> hmData, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, "INS_SYSINFO"));
			sql.setString(++i, (String)hmCommon.get("COM_CD"));
			sql.setString(++i, "A16" + (String)hmData.get("STORE_CD"));
			sql.setString(++i, (String)hmData.get("POS_NO"));
			sql.setString(++i, ((String)hmData.get("OS_VER")).trim());
			sql.setString(++i, ((String)hmData.get("CPU_INFO")).trim());
			sql.setString(++i, ((String)hmData.get("GRAPHIC_CARD")).trim());
			sql.setString(++i, ((String)hmData.get("MEMORY_INFO")).trim());
			sql.setString(++i, ((String)hmData.get("PG_VER")).trim());
			sql.setString(++i, ((String)hmData.get("IP_ADDRESS")).trim());
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			sql.debug();
			ret = 99;
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int setSystemInfoExt(HashMap<String, String> hmCommon, HashMap<String, String> hmData, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, "INS_SYSINFOEXT"));
			sql.setString(++i, (String)hmCommon.get("COM_CD"));
			sql.setString(++i, "A16" + (String)hmData.get("STORE_CD"));
			sql.setString(++i, (String)hmData.get("POS_NO"));
			sql.setString(++i, ((String)hmData.get("OS_VER")).trim());
			sql.setString(++i, ((String)hmData.get("CPU_INFO")).trim());
			sql.setString(++i, ((String)hmData.get("GRAPHIC_CARD")).trim());
			sql.setString(++i, ((String)hmData.get("MEMORY_INFO")).trim());
			sql.setString(++i, ((String)hmData.get("PG_VER")).trim());
			sql.setString(++i, ((String)hmData.get("IP_ADDRESS")).trim());
			sql.setString(++i, ((String)hmData.get("VAN_ID")).trim());
			sql.setString(++i, ((String)hmData.get("DONGLE_MODEL")).trim());
			sql.setString(++i, ((String)hmData.get("DONGLE_FW_VER")).trim());
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			sql.debug();
			ret = 99;
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return ret;
	}
	
	public int setSystemInfoExt2(HashMap<String, String> hmCommon, HashMap<String, String> hmData, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, "INS_SYSINFOEXT2"));
			sql.setString(++i, (String)hmCommon.get("COM_CD"));
			sql.setString(++i, "A16" + (String)hmData.get("STORE_CD"));
			sql.setString(++i, (String)hmData.get("POS_NO"));
			sql.setString(++i, ((String)hmData.get("OS_VER")).trim());
			sql.setString(++i, ((String)hmData.get("CPU_INFO")).trim());
			sql.setString(++i, ((String)hmData.get("GRAPHIC_CARD")).trim());
			sql.setString(++i, ((String)hmData.get("MEMORY_INFO")).trim());
			sql.setString(++i, ((String)hmData.get("PG_VER")).trim());
			sql.setString(++i, ((String)hmData.get("IP_ADDRESS")).trim());
			sql.setString(++i, ((String)hmData.get("VAN_ID")).trim());
			sql.setString(++i, ((String)hmData.get("DONGLE_MODEL")).trim());
			sql.setString(++i, ((String)hmData.get("DONGLE_FW_VER")).trim());
			sql.setString(++i, ((String)hmData.get("FILLER1")).trim());
			sql.setString(++i, ((String)hmData.get("FILLER2")).trim());
			sql.setString(++i, ((String)hmData.get("FILLER3")).trim());
			
			ret = executeUpdate(sql);
		}catch(Exception e) {
			sql.debug();
			ret = 99;
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return ret;
	}	
	public int setSystemInfoExt3(HashMap<String, String> hmCommon, HashMap<String, String> hmData, COMMLog df) throws Exception {
		SqlWrapper sql = new SqlWrapper();
		int ret = 0;
		int i = 0;
		
		try {
			begin();
			
			// DB Connection(DB 접속)
			connect("CMGNS");
			
			sql.put(findQuery(COMMBiz.XML_SYSINQ_SQL, "INS_SYSINFOEXT3"));
			sql.setString(++i, (String)hmCommon.get("COM_CD"));
			sql.setString(++i, "A16" + (String)hmData.get("STORE_CD"));
			sql.setString(++i, (String)hmData.get("POS_NO"));
			sql.setString(++i, ((String)hmData.get("OS_VER")).trim());
			sql.setString(++i, ((String)hmData.get("CPU_INFO")).trim());
			sql.setString(++i, ((String)hmData.get("GRAPHIC_CARD")).trim());
			sql.setString(++i, ((String)hmData.get("MEMORY_INFO")).trim());
			sql.setString(++i, ((String)hmData.get("PG_VER")).trim());
			sql.setString(++i, ((String)hmData.get("IP_ADDRESS")).trim());
			sql.setString(++i, ((String)hmData.get("VAN_ID")).trim());
			sql.setString(++i, ((String)hmData.get("DONGLE_MODEL")).trim());
			sql.setString(++i, ((String)hmData.get("DONGLE_FW_VER")).trim());
			sql.setString(++i, ((String)hmData.get("FILLER1")).trim());
			sql.setString(++i, ((String)hmData.get("FILLER2")).trim());
			sql.setString(++i, ((String)hmData.get("FILLER3")).trim());
			//20180803 JMH SCO사용유무(Y:1/N:0) 1byte, 택배사용유무(Y:1/N:0) 등록 추가
			sql.setString(++i, ((String)hmData.get("SELF_YN")).trim());
			sql.setString(++i, ((String)hmData.get("PS_YN")).trim());
			 
			ret = executeUpdate(sql);

		}catch(Exception e) {
			sql.debug();
			ret = 99;
			rollback();
			throw e;
		}finally {
			end();
		}
		
		return ret;
	}	
}


