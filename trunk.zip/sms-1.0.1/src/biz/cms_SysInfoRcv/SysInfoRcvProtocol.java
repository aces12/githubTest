/*
 * SysInfoRcvProtocol.java	2011. 03. 17
 *
 * Copyright 2011 FUJITSU KOREA LTD. All rights reserved.
 * FUJITSU KOREA LTD PROPRIETARY/CONFIDENTIAL. 
 * Use is subject to license terms.
 */
package biz.cms_SysInfoRcv;

import java.util.HashMap;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;

import biz.comm.COMMBiz;


/** 
 * SysInfoRcvProtocol
 *  
 * @created  on 1.0,  11/03/17
 * @created  by oki(FUJITSU KOREA LTD.) 
 *  
 * @modified on 
 * @modified by 
 * @caused   by  
 */ 
public class SysInfoRcvProtocol {

	private static Logger logger = Logger.getLogger(SysInfoRcvProtocol.class);
	
	/***
	 * getRcvSysInqDATA
	 * @param rcvBuf
	 * @return INQ TYPE
	 */	
	public int getRcvSysInqDATA(String rcvBuf){		
		HashMap hm = new HashMap();
		int ret=0;
		
		/* Common to Message Data Part(전문 데이터부 공통) */
		int nlens[]= {2};   
	
		String strHeaders[] = {      				
				"INQ_TYPE"		   // INQ Type(INQ 종별)
			};		
		
//		logger.info("▶ Receive Data" + rcvBuf );
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		
		if (Pattern.matches("[0-9]+", (String)hm.get("INQ_TYPE"))){
			ret = Integer.parseInt((String)hm.get("INQ_TYPE"));
		}
		return ret;
	}	
	

	/***
	 * getParseSystemTime
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseSystemTime(String rcvBuf){		
		HashMap hm = new HashMap();
		int nlens[]= {2,2,4,14};   
	
		String strHeaders[] = {      				
				"INQ_TYPE"			,  	// "02": Enquire System Time(시스템 일시 조회)
				"RES_CD"        	,  	// Result Code(결과코드)           00:Normal(정상), 01:Incorrect Store Code(점코드틀림), 99:Others(그외 기타)
				"TRAN_NO"       	,	// TRAN No.(TRAN 번호)
				"SYS_YMDHMS"         	// System Time         HHHHMMDDHHMMSS(시스템 일시       HHHHMMDDHHMMSS)
			};		
		
		hm = COMMBiz.getParseData(nlens, strHeaders,rcvBuf);
		
		return hm;
	}
	
	/***
	 * getParseDeviceStatus: Device Status Data(디바이스상태 데이타) 
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseDeviceStatus(String rcvBuf){		
		HashMap hm = new HashMap();				
		int nlens[]= {2,30,30,1,2};   
		String strHeaders[] = {      				
				"INQ_TYPE"		,	//INQ Type(INQ 종별)
				"POSPGM_VER"	,	//POS Program Version(POS프로그램 버전)
				"POSMST_VER"	,	//POS Master Version(POS마스터 버전)
				"POS_TY"		,	//POS Type(POS 형태)	   1:TP2K-S, 2:TP2K-C, 3:TP3K,9:PDA		 
				"DEVICE_CNT"		//Device Count(디바이스 건수)
			};		
		
		hm = COMMBiz.getParseData(nlens, strHeaders, rcvBuf);
		//Indicate Device Status(디바이스 상태 표시)  cd, stat
		hm.put("DEVICE_INFO", rcvBuf.substring(65));

//		logger.info("▶ DEVICE_INFO--->" + (String)hm.get("DEVICE_INFO"));
		return hm;
	}	
	
	/***
	 * getParseBaesinReq: Save deployment request to hm hashmap according to message layout(배신요청을 전문레이아웃에 맞춰 hm hashmap에 저장한다).
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseBaesinReq(String rcvBuf){		
		HashMap hm = new HashMap();
		int nlens[]= {2,2,1};   
		String strHeaders[] = {      				                                                                        
				"INQ_TYPE"			, // INQ Type(INQ 종별)    
				"FILE_KIND"			, // Detail Kind(상세종별 00:전체, 01:프로그램, 02:마스터, 03:객면컨텐츠, 04:상품이미지) 
				"FILE_APP_TY"		  // Application Type(적용 구분 0:정기요청, 2:긴급요청, 3:수동요청, 5:신규배포)
			};
		
		logger.info("▶ getParseBaesinReq-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders,rcvBuf);
		
		return hm;
	}	
	
	/***
	 * getParseBaesinRes: Save deployment request to hm hashmap according to message layout(배신요청을 전문레이아웃에 맞춰 hm hashmap에 저장한다).
	 * @param rcvBuf Receive MSG
	 * @return HashMap : rcvBuf->HashMap 
	 */
	public HashMap getParseBaesinRes(String rcvBuf){		
		HashMap hm = new HashMap();
		int nlens[]= {2,2,1,20,30};
		String strHeaders[] = {      				                                                                        
				"INQ_TYPE"			, // INQ Type(INQ 종별)    
				"FILE_KIND"			, // File Kind(상세종별 01:프로그램, 02:마스터, 03:객면컨텐츠, 04:상품이미지, 50:공지메시지)
				"FILE_APP_TY"		, // File App Type(적용구분 1:다운완료, 2:적용완료, F:다운실패, E:적용실패)
				"FILE_NM"			, // File Name or Message No.(파일명 또는 메시지번호)
				"FILE_VER"			  // File Ver. (파일버전)
			};
		
//		logger.info("▶ getParseBaesinRes-" + rcvBuf );
		hm = COMMBiz.getParseData(nlens, strHeaders,rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSystemInfo(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,5,4,128,128,128,10,20,20};
		String strHeaders[] = {
			"INQ_TYPE",
			"STORE_CD",
			"POS_NO",
			"OS_VER",
			"CPU_INFO",
			"GRAPHIC_CARD",
			"MEMORY_INFO",
			"PG_VER",
			"IP_ADDRESS"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSystemInfoExt(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,5,4,128,128,128,10,20,20,2,20,10};
		String strHeaders[] = {
			"INQ_TYPE",
			"STORE_CD",
			"POS_NO",
			"OS_VER",
			"CPU_INFO",
			"GRAPHIC_CARD",
			"MEMORY_INFO",
			"PG_VER",
			"IP_ADDRESS",
			"VAN_ID",
			"DONGLE_MODEL",
			"DONGLE_FW_VER"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}

	public HashMap<String, String> getParseSystemInfoExt2(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		int nlens[] = {2,5,4,128,128,128,10,20,20,2,20,10,20,20,30};
		String strHeaders[] = {
			"INQ_TYPE",
			"STORE_CD",
			"POS_NO",
			"OS_VER",
			"CPU_INFO",
			"GRAPHIC_CARD",
			"MEMORY_INFO",
			"PG_VER",
			"IP_ADDRESS",
			"VAN_ID",
			"DONGLE_MODEL",
			"DONGLE_FW_VER",
			"FILLER1",
			"FILLER2",
			"FILLER3"
		};
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
	
	public HashMap<String, String> getParseSystemInfoExt3(String rcvBuf) {
		HashMap<String, String> hm = new HashMap<String, String>();
		//20180803 JMH SCO사용유무(Y:1/N:0) 1byte, 택배사용유무(Y:1/N:0) 등록 추가
		// SELF_YN 셀프POS여부
		// PS_YN 택배사용여부
		int nlens[] = {2,5,4,128,128,128,10,20,20,2,20,10,20,20,30, 1,1};
		String strHeaders[] = {
			"INQ_TYPE",
			"STORE_CD",
			"POS_NO",
			"OS_VER",
			"CPU_INFO",
			"GRAPHIC_CARD",
			"MEMORY_INFO",
			"PG_VER",
			"IP_ADDRESS",
			"VAN_ID",
			"DONGLE_MODEL",
			"DONGLE_FW_VER",
			"FILLER1",
			"FILLER2",
			"FILLER3",
 			"SELF_YN",
			"PS_YN"
		}; 
		
		logger.info("▶ getParseSystemInfoExt3:[" + rcvBuf+"]" );
		
		hm = COMMBiz.getParseDataMultibyte(nlens, strHeaders, rcvBuf);
		
		return hm;
	}
};


	
