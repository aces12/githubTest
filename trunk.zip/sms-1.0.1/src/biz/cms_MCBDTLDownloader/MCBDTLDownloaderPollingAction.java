
///////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////SFTP 일경우////////////////////////////////////////////// 
///////////////////////////////////////////////////////////////////////////////////////////////////////
package biz.cms_MCBDTLDownloader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import kr.fujitsu.com.ffw.daemon.net.polling.PollingAction;
import kr.fujitsu.com.ffw.daemon.core.DaemonConfigLocator;
import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;

import org.apache.log4j.Logger;

import biz.comm.COMMBiz;
import biz.comm.SFTPManager;

/*
 * to do  
 * 1.  FTP 다운로드 루틴 확인 할것 
 * 2 . 파싱 후 db저장 정상 확인 OK 
 * */
/** 
 * MCBDTLDownloaderPollingAction
 * MCB 모바일 문화 상품권 수신 및 DB 저장 작업
 * @created  on 1.0,  20180705 
 * @created  by JMH 
 *  
 * @modified on 
 * @modified by ok
 * @caused   by 
 */ 
public class MCBDTLDownloaderPollingAction extends PollingAction {
	private static Logger logger = Logger.getLogger(MCBDTLDownloaderPollingAction.class);
	
	private String MCB_ftp_ip = "";
	private int MCB_ftp_port = 0;
	private String MCB_ftp_id = "";
	private String MCB_ftp_pwd = "";
	
	public static void main(String args[]) throws Exception {	
		MCBDTLDownloaderPollingAction action = new MCBDTLDownloaderPollingAction();
		if (args == null || args.length < 1) {
			logger.info("------ master main args null");
		}
		logger.info("[DEBUG] [args[0]]=" + args[0] );
		
		String path          = nvl(args[0].replaceFirst("-path:"  ,""));
		String cmd			 = nvl(args[1].replaceFirst("-cmd:" , ""));

		DaemonConfigLocator locator = DaemonConfigLocator.getInstance("xml",path);
		
		if( cmd.length() != 2 ) return;
		
		if( cmd.charAt(0) == '1' ) {
			System.out.println("downloading file + inserting DB" );
			action.execute("1");
		}
		if( cmd.charAt(1) == '1' ) {
			System.out.println("inserting DB" );
			String basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			String destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "MCB";
			MCBDTLDownloaderInst dailyInsert = new MCBDTLDownloaderInst(destPath);
			dailyInsert.start();
		}
	}
	
	private static String nvl(String param) {
		return param != null ? param: "";
	}
	
	public void execute(String actionMode) {
		SFTPManager sFtpMgr = null;
		
		BufferedOutputStream bos = null;
		String basePath = "";
		String destPath = "";
		int iRetry = 0;
		boolean isDownOK = false;
		
		try {
			//actionMode:: 0:POLLING_PERIOD에 주기적으로 무조건 수행, 1:ACTION_TIME에 한번 수행
			if( actionMode != "1" ) return;
			logger.info("actionMode[" + actionMode + "]");
			
			this.MCB_ftp_ip = PropertyUtil.findProperty("communication-property", "MCB_FTP_SERVER_IP");
			this.MCB_ftp_port = Integer.parseInt(PropertyUtil.findProperty("communication-property", "MCB_FTP_SERVER_PORT"));
			this.MCB_ftp_id = PropertyUtil.findProperty("communication-property", "MCB_FTP_SERVER_ID");
			this.MCB_ftp_pwd = PropertyUtil.findProperty("communication-property", "MCB_FTP_SERVER_PWD");	
			
			try{				
				logger.info("TRY Connected to " + MCB_ftp_ip + ":" + MCB_ftp_port);
				sFtpMgr = new SFTPManager(MCB_ftp_ip, MCB_ftp_port, MCB_ftp_id, MCB_ftp_pwd);	 
			}catch(Exception e){
				logger.info("exception occur"+e.getMessage());
				logger.info(" SFTP Connect fail exception occur ");
				return;
			}					
			logger.info(" SFTP Connection is Success ");						
			
			basePath = PropertyUtil.findProperty("stsys-property", "APP_ROOT");	// 파일 생성 루트
			
			destPath = basePath + File.separator + "files" + File.separator + "down" + File.separator + "MCB";
			
			File destDir = new File(destPath);
			
			if( !destDir.exists() ) {
				destDir.mkdir();
				logger.info("[DEBUG] Try to make dir" );
			}
			isDownOK = false;
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

			calendar.setTime(new Date());

			String stdDate = sdf.format(calendar.getTime());
			
			String targetFileNm = "EMART24_" + stdDate +"_R.txt";
									
			iRetry = 0;			
			bos = new BufferedOutputStream(new FileOutputStream(destDir + File.separator + targetFileNm));
			
			while( iRetry < 2 ) {				
				if( isDownOK = sFtpMgr.get(targetFileNm, bos)) {		
					break;
				}
				iRetry++;
			}
			bos.flush();
			bos.close();
			bos = null;
			System.gc();
			
			if( isDownOK ) {
				logger.info(" >>>>>>>>>>>>> successfully downloaded file [" + targetFileNm + "]");

				if( sFtpMgr.rename(targetFileNm, targetFileNm.concat(".ok")) ) {
					logger.info("[DEBUG] Succeeded to rename.");
				}else {
					logger.info("[DEBUG] Failed to rename.");	
				}
			}else {
				logger.info("[ERROR4] Can't get " + targetFileNm + " from FTP server");
									
				File file = new File(destPath + File.separator + targetFileNm);
				if( !file.delete() ) {
					logger.info("[ERROR4-1] Failed to delete empty file [" + targetFileNm + "]");
				}				
				logger.info("[ERROR2] Can't get file on FTP server");
			}
			
			System.out.println("File created!! ");
			System.out.println("db insert start!! ");
			MCBDTLDownloaderInst dailyInsert = new MCBDTLDownloaderInst(destPath);
			dailyInsert.start();				
			System.out.println("db insert complete!! ");
			
		}catch(Exception e) {
			logger.info(e.getMessage());					
		}finally {
			if( bos != null ) {
				try {
					bos.close();
					bos = null;
				}catch(Exception e) {}
			}
			try {
				if( !sFtpMgr.isClosed() ) 
					sFtpMgr.logout();
			}catch(Exception e) {
			}
		}
	}
	
	
}









