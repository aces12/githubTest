package biz.cms_MCBDTLDownloader;

import java.util.HashMap;

import org.apache.log4j.Logger;

import kr.fujitsu.com.ffw.daemon.core.config.repository.property.PropertyUtil;
import kr.fujitsu.com.ffw.model.GenericDAO;
import kr.fujitsu.com.ffw.model.SqlWrapper;

public class MCBDTLDownloaderDAO extends GenericDAO {
	private static Logger logger = Logger.getLogger(MCBDTLDownloaderPollingAction.class);
	
	
	public int insMCBDTL(HashMap<String, String> map) {
		SqlWrapper sql = new SqlWrapper();
		String sqlDbg = "";
		int i = 0;
		int rows = -1;
		
		try {
			String com_cd = PropertyUtil.findProperty("stsys-property", "COM_CD");
			//transaction 발생
			begin();			
			//DB Connection(DB 접속)
			connect("CMGNS"); 

			sql.put(findQuery("service-sql", "INS_MCB_RCV_TRN"));

			sql.setString(++i, com_cd );   // COM_CD        --VARCHAR2(4) PK6 회사코드(위드미:1002)                  
			sql.setString(++i, map.get("TRAN_YMD"		));   // TRAN_YMD      --  VARCHAR2(8) PK1 거래날짜(위드미 전문상데이터)        
			sql.setString(++i, map.get("TRAN_STRCD"		));   // STORE_CD      --  VARCHAR2(5) PK2 점포코드(위드미 전문상데이터)        
			sql.setString(++i, map.get("TRAN_POSNO"		));   // POS_NO        --  VARCHAR2(4) PK3 포스번호(위드미 전문상데이터)        
			sql.setString(++i, map.get("TRAN_NO"		));   // TRAN_NO       -- VARCHAR2(4) PK4 거래번호(위드미 전문상데이터)         
			sql.setString(++i, map.get("RECODE_TP_D"	));   // TRAN_TP       -- VARCHAR2(1) 거래타입 0 승인 1 취소                    
			sql.setString(++i, map.get("CUL_TRACE_NO"	));   // CUL_TRACE_NO  --  VARCHAR2(25)    컬처랜드거래번호                     
			sql.setString(++i, map.get("TRAN_YMD"		)
					           +map.get("TRAN_STRCD"	)
					           +map.get("TRAN_POSNO"	)
					           +map.get("TRAN_NO"		)
					           +map.get("TRAN_HH24MMDD"	)
					           +map.get("TRAN_FILLER"	));   // TRACE_NO      --  VARCHAR2(50)    사용처거래번호                       
			sql.setString(++i, map.get("RESP_DY"		));   // RESP_DY       -- VARCHAR2(8)   승인날짜(정산기준)                      
			sql.setString(++i, map.get("RESP_TM"		));   // RESP_TM       -- VARCHAR2(6)   승인시간                                
			sql.setString(++i, map.get("PIN_TRADE_AMT"	));   // PIN_TRADE_AMT -- NUMBER(22,3)    거래금액
			sql.setString(++i, "MCBDTLDownloader"		 );   // 등록자
			sql.setString(++i, "MCBDTLDownloader"		 );   // 수정자
			

			sqlDbg = sql.debug();						
			rows = executeUpdate(sql);
			
			
			
		}catch(Exception e) {
			//logger.info("[SQL1][INS_MCB_RCV_TRN]" + sqlDbg );
			System.out.println("[SQL1][INS_MCB_RCV_TRN]" + sqlDbg );
			
			rollback();
			logger.info("[ERROR1] " + e.getMessage());
			System.out.println("[ERROR1] " + e.getMessage());
		}finally {
			//transaction 종료
			end();
			logger.info("[Data Insert well done]");
		}
		
		return rows;
	}
	
}