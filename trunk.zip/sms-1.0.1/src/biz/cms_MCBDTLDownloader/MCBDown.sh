#!/bin/bash

echo "--start MCBPollingAction"

cd $SMS_HOME/bin

java biz.cms_MCBDTLDownloader.MCBDTLDownloaderPollingAction -path:$CONFIG_FILE -cmd:01

cd $APP_HOME/batch

