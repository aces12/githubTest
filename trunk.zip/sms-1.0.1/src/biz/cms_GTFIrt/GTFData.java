package biz.cms_GTFIrt;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import biz.cms_TranDivide.TranDivide_Define;
import java.util.Map;

public class GTFData {

	static final int INQ101 = 88;
	static final int INQ301 = 89;
	static final int INQ901 = 87;
	
	static final int REQ101 = 101;
	static final int REQ201 = 201;
	static final int REQ301 = 301;
	static final int REQ401 = 401;
	static final int REQ901 = 901;
	
	static final int RSP100 = 100;
	static final int RSP200 = 200;
	static final int RSP300 = 300;
	static final int RSP400 = 400;
	static final int RSP900 = 900;
	
	static final int len_REQ101 = 101;
	static final int len_REQ301 = 301;	
	static final int len_REQ901 = 901;
	
	static final int len_REQ201 = 201;	
	static final int len_REQ401 = 401;
	
	
	static int reCnt = 0;
	
	public static final int nlensT[] = { 5, 2, 3, 2, 10, 3, 20, 
			1, 10, 10, 10, 14,
			4, 9, 8, 1, 21,
			1, 13, 1, 40, 24,
			3, 1, 6, 6, 3,
			60, 40, 4, 8, 30,
			1, 9, 30, 10, 100, 20};
	
	public static final String strHeadersT[] = { 
		"ITEM_LEN",
		"TR_ITEM_ID", 
		"TR_ITEM_SEQ", 		
		"EDI", // 업무 구분	2
		"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))			10
		"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)			3
		"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID +
				// 난수(5)+연도(2)+시퀀스넘버(6)
		
		"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
		"TRADE_APPROVAL_NUM", // 거래승인번호
		"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
		"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
		"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)
		
		"SELL_SUM_TOTAL", // 판매총수량
		"SELL_SUM_MONEY", // 판매총금액
		"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
		"PAYMENT_TYPE", // 결제유형(신용1, 현금2)
		"CREDIT_CARD_NUM", // 결제신용카드번호
		
		"KOR_DOMESTIC_CITIZEN", // 내국인환급대상여부 (한국여권Y, 아니면 N)
		"KOR_IDENTITY", // 주민번호
		"PASSPORT_ENC_YN", // 여권암호화여부 (N:비암호화, D:DES , T:3DES)
		"PASSPORT_NAME", // 여권영문이름(즉시환급 필수)
		"PASSPORT_NUM", // 여권번호(즉시환급필수 암호화시 TripleDES)
		
		"PASSPORT_NATION", // 여권국가코드 (즉시환급 필수)
		"PASSPORT_SEX", // 여권성별(즉시환급 필수)
		"PASSPORT_BIRTH", // 여권생일(즉시환급 필수)
		"PASSPORT_EXPIRE", // 여권만료일(즉시환급 필수)
		"RESPONSE_CD", // 응답코드(100정상 , 200 통신장애 , 300 정보오류 , 400 재전송
		
		"RESPONSE_MESSAGE", // 응답메시지
		"SHOP_NAME", // 매장명
		"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
		"EXPORT_EXPIRY_DATE", // 반출유효기간(YYYYMMDD)
		"RCT_NO", // 영수증번호
		
		"BEFORE_REFUND_YN", // 즉시환급여부 (즉시환급Y , 사후 환급 N)
		"PAYMENT_AMOUNT", // 결제금액
		"EXPORT_APPROVAL_NUM", // 반출승인번호(즉시환급일경우 반출 승인 번호 리턴한다)
		"BEFORE_LIMIT_AMOUNT", // 즉시환급한도액(즉시환급조회 할경우 한도액 리턴한다. )
		"EXTRA",// 비고
		"UNIQUE_NUM"
	};
	
	public static final int nlensGT[] = { 20,3, 1, 2, 50, 4,
				9, 9, 8, 8, 8,
				8, 16 };
	
	public static final String strHeadersGT[] = { // 물품부
		"UNIQUE_NUM",
		"COMMODITY_NUM", // 물품일련번호
		"SCT_DIV", // 개별소비세구분
		"COMMODITY_CD", // 물품코드
		"COMMODITY_CONT", // 물품내용
		"VOLUME", // 수량
		
		"UNIT_PRICE", // 단가
		"SELL_PRICE", // 판매가격
		"VAT", // 부가가치세
		"SCT", // 개별소비세
		"ET", // 교육세
		
		"FFVST", // 농어촌특별세
		"EXTRA", // 비고
	};	

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//FAULT DATA /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	static final int nlensGTFFault[] = { 5, 2, 10, 3, 20, 
									1, 10, 10, 10, 14,
									4, 9, 8, 1, 21,
									1, 13, 1, 40, 24,
									3, 1, 6, 6, 3,
									60/*, 40, 4, 8, 30,
									1, 9, 30, 10, 100, 
									3, 1, 2, 50, 4,
									9, 9, 8, 8, 8,
									8, 16*/			};

	static final String strHeadersGTFFault[] = { 
			"LENGTH", // 전문 길이
			"EDI", // 업무 구분
			"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
			"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID +
								// 난수(5)+연도(2)+시퀀스넘버(6)

			"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
			"TRADE_APPROVAL_NUM", // 거래승인번호
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)

			"SELL_SUM_TOTAL", // 판매총수량
			"SELL_SUM_MONEY", // 판매총금액
			"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
			"PAYMENT_TYPE", // 결제유형(신용1, 현금2)
			"CREDIT_CARD_NUM", // 결제신용카드번호

			"KOR_DOMESTIC_CITIZEN", // 내국인환급대상여부 (한국여권Y, 아니면 N)
			"KOR_IDENTITY", // 주민번호
			"PASSPORT_ENC_YN", // 여권암호화여부 (N:비암호화, D:DES , T:3DES)
			"PASSPORT_NAME", // 여권영문이름(즉시환급 필수)
			"PASSPORT_NUM", // 여권번호(즉시환급필수 암호화시 TripleDES)

			"PASSPORT_NATION", // 여권국가코드 (즉시환급 필수)
			"PASSPORT_SEX", // 여권성별(즉시환급 필수)
			"PASSPORT_BIRTH", // 여권생일(즉시환급 필수)
			"PASSPORT_EXPIRE", // 여권만료일(즉시환급 필수)
			"RESPONSE_CD", // 응답코드(100정상 , 200 통신장애 , 300 정보오류 , 400 재전송

			"RESPONSE_MESSAGE", // 응답메시지
			
			
//			"SHOP_NAME", // 매장명
//			"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
//			"EXPORT_EXPIRY_DATE", // 반출유효기간(YYYYMMDD)
//			"RCT_NO", // 영수증번호
//
//			"BEFORE_REFUND_YN", // 즉시환급여부 (즉시환급Y , 사후 환급 N)
//			"PAYMENT_AMOUNT", // 결제금액
//			"EXPORT_APPROVAL_NUM", // 반출승인번호(즉시환급일경우 반출 승인 번호 리턴한다)
//			"BEFORE_LIMIT_AMOUNT", // 즉시환급한도액(즉시환급조회 할경우 한도액 리턴한다. )
//			"MCH_SEND_UNIQ_NO",// 비고
//			
//			"COMMODITY_NUM", // 물품일련번호
//			"SCT_DIV", // 개별소비세구분
//			"COMMODITY_CD", // 물품코드
//			"COMMODITY_CONT", // 물품내용
//			"VOLUME", // 수량
//			
//			"UNIT_PRICE", // 단가
//			"SELL_PRICE", // 판매가격
//			"VAT", // 부가가치세
//			"SCT", // 개별소비세
//			"ET", // 교육세
//			
//			"FFVST", // 농어촌특별세
//			"EXTRA", // 비고
	};

	

	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//ALL /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	static final int nlensGTF[] = { 5, 2, 10, 3, 20, 
									1, 10, 10, 10, 14,
									4, 9, 8, 1, 21,
									1, 13, 1, 40, 24,
									3, 1, 6, 6, 3,
									60, 40, 4, 8, 30,
									1, 9, 30, 10, 100, 
									3, 1, 2, 50, 4,
									9, 9, 8, 8, 8,
									8, 16			};

	static final String strHeadersGTF[] = { 
			"LENGTH", // 전문 길이
			"EDI", // 업무 구분
			"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
			"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID +
								// 난수(5)+연도(2)+시퀀스넘버(6)

			"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
			"TRADE_APPROVAL_NUM", // 거래승인번호
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)

			"SELL_SUM_TOTAL", // 판매총수량
			"SELL_SUM_MONEY", // 판매총금액
			"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
			"PAYMENT_TYPE", // 결제유형(신용1, 현금2)
			"CREDIT_CARD_NUM", // 결제신용카드번호

			"KOR_DOMESTIC_CITIZEN", // 내국인환급대상여부 (한국여권Y, 아니면 N)
			"KOR_IDENTITY", // 주민번호
			"PASSPORT_ENC_YN", // 여권암호화여부 (N:비암호화, D:DES , T:3DES)
			"PASSPORT_NAME", // 여권영문이름(즉시환급 필수)
			"PASSPORT_NUM", // 여권번호(즉시환급필수 암호화시 TripleDES)

			"PASSPORT_NATION", // 여권국가코드 (즉시환급 필수)
			"PASSPORT_SEX", // 여권성별(즉시환급 필수)
			"PASSPORT_BIRTH", // 여권생일(즉시환급 필수)
			"PASSPORT_EXPIRE", // 여권만료일(즉시환급 필수)
			"RESPONSE_CD", // 응답코드(100정상 , 200 통신장애 , 300 정보오류 , 400 재전송

			"RESPONSE_MESSAGE", // 응답메시지
			"SHOP_NAME", // 매장명
			"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
			"EXPORT_EXPIRY_DATE", // 반출유효기간(YYYYMMDD)
			"RCT_NO", // 영수증번호

			"BEFORE_REFUND_YN", // 즉시환급여부 (즉시환급Y , 사후 환급 N)
			"PAYMENT_AMOUNT", // 결제금액
			"EXPORT_APPROVAL_NUM", // 반출승인번호(즉시환급일경우 반출 승인 번호 리턴한다)
			"BEFORE_LIMIT_AMOUNT", // 즉시환급한도액(즉시환급조회 할경우 한도액 리턴한다. )
			"MCH_SEND_UNIQ_NO",// 비고
			
			"COMMODITY_NUM", // 물품일련번호
			"SCT_DIV", // 개별소비세구분
			"COMMODITY_CD", // 물품코드
			"COMMODITY_CONT", // 물품내용
			"VOLUME", // 수량
			
			"UNIT_PRICE", // 단가
			"SELL_PRICE", // 판매가격
			"VAT", // 부가가치세
			"SCT", // 개별소비세
			"ET", // 교육세
			
			"FFVST", // 농어촌특별세
			"EXTRA", // 비고
	};

	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//ALL /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	static final int nlensA[] = { 5, 2, 10, 3, 20, 
									1, 10, 10, 10, 14,
									4, 9, 8, 1, 21,
									1, 13, 1, 40, 24,
									3, 1, 6, 6, 3,
									60, 40, 4, 8, 30,
									1, 9, 30, 10, 100, };

	static final String strHeadersA[] = { 
			"LENGTH", // 전문 길이
			"EDI", // 업무 구분
			"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
			"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID +
								// 난수(5)+연도(2)+시퀀스넘버(6)

			"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
			"TRADE_APPROVAL_NUM", // 거래승인번호
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)

			"SELL_SUM_TOTAL", // 판매총수량
			"SELL_SUM_MONEY", // 판매총금액
			"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
			"PAYMENT_TYPE", // 결제유형(신용1, 현금2)
			"CREDIT_CARD_NUM", // 결제신용카드번호

			"KOR_DOMESTIC_CITIZEN", // 내국인환급대상여부 (한국여권Y, 아니면 N)
			"KOR_IDENTITY", // 주민번호
			"PASSPORT_ENC_YN", // 여권암호화여부 (N:비암호화, D:DES , T:3DES)
			"PASSPORT_NAME", // 여권영문이름(즉시환급 필수)
			"PASSPORT_NUM", // 여권번호(즉시환급필수 암호화시 TripleDES)

			"PASSPORT_NATION", // 여권국가코드 (즉시환급 필수)
			"PASSPORT_SEX", // 여권성별(즉시환급 필수)
			"PASSPORT_BIRTH", // 여권생일(즉시환급 필수)
			"PASSPORT_EXPIRE", // 여권만료일(즉시환급 필수)
			"RESPONSE_CD", // 응답코드(100정상 , 200 통신장애 , 300 정보오류 , 400 재전송

			"RESPONSE_MESSAGE", // 응답메시지
			"SHOP_NAME", // 매장명
			"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
			"EXPORT_EXPIRY_DATE", // 반출유효기간(YYYYMMDD)
			"RCT_NO", // 영수증번호

			"BEFORE_REFUND_YN", // 즉시환급여부 (즉시환급Y , 사후 환급 N)
			"PAYMENT_AMOUNT", // 결제금액
			"EXPORT_APPROVAL_NUM", // 반출승인번호(즉시환급일경우 반출 승인 번호 리턴한다)
			"BEFORE_LIMIT_AMOUNT", // 즉시환급한도액(즉시환급조회 할경우 한도액 리턴한다. )
			"EXTRA"// 비고
	};

	static final int nlensGA[] = { 3, 1, 2, 50, 4,
									9, 9, 8, 8, 8,
									8, 16 };

	static final String strHeadersGA[] = { // 물품부
			"COMMODITY_NUM", // 물품일련번호
			"SCT_DIV", // 개별소비세구분
			"COMMODITY_CD", // 물품코드
			"COMMODITY_CONT", // 물품내용
			"VOLUME", // 수량
			
			"UNIT_PRICE", // 단가
			"SELL_PRICE", // 판매가격
			"VAT", // 부가가치세
			"SCT", // 개별소비세
			"ET", // 교육세
			
			"FFVST", // 농어촌특별세
			"EXTRA", // 비고
	};	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//승인 101 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlens101GTF[] = { 5, 2, 10, 3, 20, 
			1, 10, 10, 10, 14,
			4, 9, 8, 1, 21,
			1, 40, 24, 3, 1,
			6, 6, 4, 30, 1 ,21,
			3, 1, 2, 50, 4,	
			9, 9, 8
			};//330
	

	static final String strHeaders101GTF[] = { 
			"LENGTH", // 전문 길이
			"EDI", // 업무 구분
			"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
			"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID + 난수(5)+연도(2)+시퀀스넘버(6)
			
			"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
			"TRADE_APPROVAL_NUM", // 거래승인번호
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)
			
			"SELL_SUM_TOTAL", // 판매총수량
			"SELL_SUM_MONEY", // 판매총금액
			"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
			"PAYMENT_TYPE", // 결제유형(신용1, 현금2)
			"CREDIT_CARD_NUM", // 결제신용카드번호
			

			"PASSPORT_ENC_YN", // 여권암호화여부 (N:비암호화, D:DES , T:3DES)
			"PASSPORT_NAME", // 여권영문이름(즉시환급 필수)
			"PASSPORT_NUM", // 여권번호(즉시환급필수 암호화시 TripleDES)			
			"PASSPORT_NATION", // 여권국가코드 (즉시환급 필수)
			"PASSPORT_SEX", // 여권성별(즉시환급 필수)
			
			"PASSPORT_BIRTH", // 여권생일(즉시환급 필수)
			"PASSPORT_EXPIRE", // 여권만료일(즉시환급 필수)
			"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding		
			"RCT_NO", // 영수증번호		
			"BEFORE_REFUND_YN", // 즉시환급여부 (즉시환급Y , 사후 환급 N)
			"MCH_SEND_UNIQ_NO", //전송고유번호	////물품부			
			"COMMODITY_NUM", // 물품일련번호
			"SCT_DIV", // 개별소비세구분
			"COMMODITY_CD", // 물품코드
			"COMMODITY_CONT", // 물품내용
			"VOLUME", // 수량
			
			"UNIT_PRICE", // 단가
			"SELL_PRICE", // 판매가격
			"VAT" // 부가가치세

			};
	
	static final int nlens101[] = { 2, 3, 20, 1, 10,
			10, 10, 14,	4, 9,
			8, 1,  1, 40, 24, 
			3, 1, 6, 6, 4, 
			30, 1 ,21, 3, 1,
			2, 50, 4, 9, 9,
			8
			};
	

	static final String strHeaders101[] = { 
			"INQ_TYPE",
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
			"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID + 난수(5)+연도(2)+시퀀스넘버(6)			
			"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
			"TRADE_APPROVAL_NUM", // 거래승인번호
			
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)			
			"SELL_SUM_TOTAL", // 판매총수량
			"SELL_SUM_MONEY", // 판매총금액
			
			"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
			"PAYMENT_TYPE", // 결제유형(신용1, 현금2)
			"PASSPORT_ENC_YN", // 여권암호화여부 (N:비암호화, D:DES , T:3DES)
			"PASSPORT_NAME", // 여권영문이름(즉시환급 필수)
			"PASSPORT_NUM", // 여권번호(즉시환급필수 암호화시 TripleDES)			
			
			"PASSPORT_NATION", // 여권국가코드 (즉시환급 필수)
			"PASSPORT_SEX", // 여권성별(즉시환급 필수)			
			"PASSPORT_BIRTH", // 여권생일(즉시환급 필수)
			"PASSPORT_EXPIRE", // 여권만료일(즉시환급 필수)
			"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
			
			"RCT_NO", // 영수증번호		
			"BEFORE_REFUND_YN", // 즉시환급여부 (즉시환급Y , 사후 환급 N)
			"MCH_SEND_UNIQ_NO", //전송고유번호		
			"COMMODITY_NUM", // 물품일련번호
			"SCT_DIV", // 개별소비세구분
			
			"COMMODITY_CD", // 물품코드
			"COMMODITY_CONT", // 물품내용
			"VOLUME", // 수량			
			"UNIT_PRICE", // 단가
			"SELL_PRICE", // 판매가격
			
			"VAT" // 부가가치세

			};
	
	static final int nlens101_enc[] = { 2, 3, 20, 1, 10,
		10, 10, 14,	4, 9,
		8, 1,  1, 40, 128, 
		3, 1, 6, 6, 4, 
		30, 1 ,21, 3, 1,
		2, 50, 4, 9, 9,
		8
		};


	static final String strHeaders101_enc[] = { 
		"INQ_TYPE",
		"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
		"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID + 난수(5)+연도(2)+시퀀스넘버(6)			
		"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
		"TRADE_APPROVAL_NUM", // 거래승인번호
		
		"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
		"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
		"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)			
		"SELL_SUM_TOTAL", // 판매총수량
		"SELL_SUM_MONEY", // 판매총금액
		
		"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
		"PAYMENT_TYPE", // 결제유형(신용1, 현금2)
		"PASSPORT_ENC_YN", // 여권암호화여부 (N:비암호화, D:DES , T:3DES)
		"PASSPORT_NAME", // 여권영문이름(즉시환급 필수)
		"PASSPORT_NUM", // 여권번호(즉시환급필수 암호화시 TripleDES)			
		
		"PASSPORT_NATION", // 여권국가코드 (즉시환급 필수)
		"PASSPORT_SEX", // 여권성별(즉시환급 필수)			
		"PASSPORT_BIRTH", // 여권생일(즉시환급 필수)
		"PASSPORT_EXPIRE", // 여권만료일(즉시환급 필수)
		"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
		
		"RCT_NO", // 영수증번호		
		"BEFORE_REFUND_YN", // 즉시환급여부 (즉시환급Y , 사후 환급 N)
		"MCH_SEND_UNIQ_NO", //전송고유번호		
		"COMMODITY_NUM", // 물품일련번호
		"SCT_DIV", // 개별소비세구분
		
		"COMMODITY_CD", // 물품코드
		"COMMODITY_CONT", // 물품내용
		"VOLUME", // 수량			
		"UNIT_PRICE", // 단가
		"SELL_PRICE", // 판매가격
		
		"VAT" // 부가가치세

		};

	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//승인응답 100GTF /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlens100GTF[] = { 5, 2, 10, 3, 20, 
			1,  10, 10, 10, 14,
			4,  9,  8,  1,  21,
			1,  40, 24, 3,  1, 
			6,  6,  3,  60, 40,
			4,  8,  30, 1,  9,
			30, 10,	21,	 3, 1,
			2,	50, 4,  9, 9, 
			8,	8,  8,  8  };

	static final String strHeaders100GTF[] = { 
			"LENGTH", // 전문 길이
			"EDI", // 업무 구분
			"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
			"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID +
					// 난수(5)+연도(2)+시퀀스넘버(6)
			
			"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
			"TRADE_APPROVAL_NUM", // 거래승인번호
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)
			
			"SELL_SUM_TOTAL", // 판매총수량
			"SELL_SUM_MONEY", // 판매총금액
			"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
			"PAYMENT_TYPE", // 결제유형(신용1, 현금2)
			"CREDIT_CARD_NUM", // 결제신용카드번호
			
			"PASSPORT_ENC_YN", // 여권암호화여부 (N:비암호화, D:DES , T:3DES)
			"PASSPORT_NAME", // 여권영문이름(즉시환급 필수)
			"PASSPORT_NUM", // 여권번호(즉시환급필수 암호화시 TripleDES)			
			"PASSPORT_NATION", // 여권국가코드 (즉시환급 필수)
			"PASSPORT_SEX", // 여권성별(즉시환급 필수)
			
			"PASSPORT_BIRTH", // 여권생일(즉시환급 필수)
			"PASSPORT_EXPIRE", // 여권만료일(즉시환급 필수)
			"RESPONSE_CD", // 응답코드(100정상 , 200 통신장애 , 300 정보오류 , 400 재전송		
			"RESPONSE_MESSAGE", // 응답메시지
			"SHOP_NAME", // 매장명
			
			"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
			"EXPORT_EXPIRY_DATE", // 반출유효기간(YYYYMMDD)
			"RCT_NO", // 영수증번호			
			"BEFORE_REFUND_YN", // 즉시환급여부 (즉시환급Y , 사후 환급 N)
			"PAYMENT_AMOUNT", // 결제금액
			
			"EXPORT_APPROVAL_NUM", // 반출승인번호(즉시환급일경우 반출 승인 번호 리턴한다)
			"BEFORE_LIMIT_AMOUNT", // 즉시환급한도액(즉시환급조회 할경우 한도액 리턴한다. )
			"MCH_SEND_UNIQ_NO",//전송고유번호 
			"COMMODITY_NUM", // 물품일련번호
			"SCT_DIV", // 개별소비세구분
			
			"COMMODITY_CD", // 물품코드			
			"COMMODITY_CONT", // 물품내용
			"VOLUME", // 수량			
			"UNIT_PRICE", // 단가
			"SELL_PRICE", // 판매가격
			
			"VAT", // 부가가치세			
			"SCT", // 개별소비세
			"ET", // 교육세		
			"FFVST" // 농어촌특별세			
			};
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//승인응답 100 POS IRT /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlens100[] = { 
			2,  3,  20, 1,  10,
			10, 10, 14,	4,  9,
			8,  1,	1,  40, 24,
			3,  1,	6,  6,  3,
			60, 40,	4,  8,  30,
			1,  9,	30, 10, 21,
			3,	1,  2,	50, 4,  
			9,	9,  8,	8,  8,  
			8  };//535

	static final String strHeaders100[] = { 
			"INQ_TYPE", 
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
			"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID +// 난수(5)+연도(2)+시퀀스넘버(6)								
			"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
			"TRADE_APPROVAL_NUM", // 거래승인번호
			
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)			
			"SELL_SUM_TOTAL", // 판매총수량
			"SELL_SUM_MONEY", // 판매총금액
			
			"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
			"PAYMENT_TYPE", // 결제유형(신용1, 현금2)
			"PASSPORT_ENC_YN", // 여권암호화여부 (N:비암호화, D:DES , T:3DES)
			"PASSPORT_NAME", // 여권영문이름(즉시환급 필수)
			"PASSPORT_NUM", // 여권번호(즉시환급필수 암호화시 TripleDES)			
			
			"PASSPORT_NATION", // 여권국가코드 (즉시환급 필수)
			"PASSPORT_SEX", // 여권성별(즉시환급 필수)			
			"PASSPORT_BIRTH", // 여권생일(즉시환급 필수)
			"PASSPORT_EXPIRE", // 여권만료일(즉시환급 필수)
			"RESPONSE_CD", // 응답코드(100정상 , 200 통신장애 , 300 정보오류 , 400 재전송		
			
			"RESPONSE_MESSAGE", // 응답메시지
			"SHOP_NAME", // 매장명			
			"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
			"EXPORT_EXPIRY_DATE", // 반출유효기간(YYYYMMDD)
			"RCT_NO", // 영수증번호
			
			"BEFORE_REFUND_YN", // 즉시환급여부 (즉시환급Y , 사후 환급 N)
			"PAYMENT_AMOUNT", // 결제금액			
			"EXPORT_APPROVAL_NUM", // 반출승인번호(즉시환급일경우 반출 승인 번호 리턴한다)
			"BEFORE_LIMIT_AMOUNT", // 즉시환급한도액(즉시환급조회 할경우 한도액 리턴한다. )
			"MCH_SEND_UNIQ_NO", //전송고유번호
			
			"COMMODITY_NUM", // 물품일련번호
			"SCT_DIV", // 개별소비세구분
			"COMMODITY_CD", // 물품코드			
			"COMMODITY_CONT", // 물품내용
			"VOLUME", // 수량			
			
			"UNIT_PRICE", // 단가
			"SELL_PRICE", // 판매가격
			"VAT", // 부가가치세			
			"SCT", // 개별소비세
			"ET", // 교육세		
			
			"FFVST" // 농어촌특별세			
			};
	

	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//취소 301GTF /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	static final int nlens301GTF[] = { 5, 2, 10, 3, 20, 
			1,  10, 10, 10, 14,
			4,  9,  8,  1,  21,
			4,  21, 3,  1,  2,
			50,	4,  9,  9,  8 	};

	static final String strHeaders301GTF[] = { 		
			"LENGTH", // 전문 길이
			"EDI", // 업무 구분
			"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
			"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID +난수(5)+연도(2)+시퀀스넘버(6)
			
			"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
			"TRADE_APPROVAL_NUM", // 거래승인번호
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)
			
			"SELL_SUM_TOTAL", // 판매총수량
			"SELL_SUM_MONEY", // 판매총금액
			"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
			"PAYMENT_TYPE", // 결제유형(신용1, 현금2)
			"CREDIT_CARD_NUM", // 결제신용카드번호
						
			"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
			"MCH_SEND_UNIQ_NO", //전송고유번호	
			"COMMODITY_NUM", // 물품일련번호
			"SCT_DIV", // 개별소비세구분
			"COMMODITY_CD", // 물품코드
			
			"COMMODITY_CONT", // 물품내용			
			"VOLUME", // 수량			
			"UNIT_PRICE", // 단가
			"SELL_PRICE", // 판매가격
			"VAT" // 부가가치세			
			};	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//취소 301 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlens301[] = { 2, 3, 20, 1, 10,
			10, 10, 14,	4, 9,
			8,  1,  4,  21,3,
			1,  2,  50, 4, 9, 
			9, 8 	};

	static final String strHeaders301[] = { 
			"INQ_TYPE",//"LENGTH", // 전문 길이
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
			"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID +난수(5)+연도(2)+시퀀스넘버(6)			
			"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
			"TRADE_APPROVAL_NUM", // 거래승인번호
			
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)			
			"SELL_SUM_TOTAL", // 판매총수량
			"SELL_SUM_MONEY", // 판매총금액
			
			"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
			"PAYMENT_TYPE", // 결제유형(신용1, 현금2)						
			"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
			"MCH_SEND_UNIQ_NO", //전송고유번호		
			"COMMODITY_NUM", // 물품일련번호
			
			"SCT_DIV", // 개별소비세구분
			"COMMODITY_CD", // 물품코드
			"COMMODITY_CONT", // 물품내용			
			"VOLUME", // 수량			
			"UNIT_PRICE", // 단가
			
			"SELL_PRICE", // 판매가격
			"VAT" // 부가가치세			
			};
	


	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//취소응답 300GTF /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlens300GTF[] = { 5, 2, 10, 3, 20, 
			1, 10, 10, 10, 14,
			4, 9,  8,  1,  21,
			1, 40, 24, 3,  1,
			6, 6,  3,  60, 40,
			4, 8,  1,  21, 3,
			1, 2,  50, 4,  9,
			9, 8,  8,  8,  8 };

	static final String strHeaders300GTF[] = { 
			"LENGTH", // 전문 길이
			"EDI", // 업무 구분
			"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
			"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID + 난수(5)+연도(2)+시퀀스넘버(6)
			
			"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
			"TRADE_APPROVAL_NUM", // 거래승인번호
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)
			
			"SELL_SUM_TOTAL", // 판매총수량
			"SELL_SUM_MONEY", // 판매총금액
			"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
			"PAYMENT_TYPE", // 결제유형(신용1, 현금2)
			"CREDIT_CARD_NUM", // 결제신용카드번호			

			"PASSPORT_ENC_YN", // 여권암호화여부 (N:비암호화, D:DES , T:3DES)
			"PASSPORT_NAME", // 여권영문이름(즉시환급 필수)
			"PASSPORT_NUM", // 여권번호(즉시환급필수 암호화시 TripleDES)			
			"PASSPORT_NATION", // 여권국가코드 (즉시환급 필수)
			"PASSPORT_SEX", // 여권성별(즉시환급 필수)
			
			"PASSPORT_BIRTH", // 여권생일(즉시환급 필수)
			"PASSPORT_EXPIRE", // 여권만료일(즉시환급 필수)
			"RESPONSE_CD", // 응답코드(100정상 , 200 통신장애 , 300 정보오류 , 400 재전송			
			"RESPONSE_MESSAGE", // 응답메시지
			"SHOP_NAME", // 매장명
			
			"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
			"EXPORT_EXPIRY_DATE", // 반출유효기간(YYYYMMDD)			
			"BEFORE_REFUND_YN", // 즉시환급여부 (즉시환급Y , 사후 환급 N)
			"MCH_SEND_UNIQ_NO", //전송고유번호	
			"COMMODITY_NUM", // 물품일련번호
			
			"SCT_DIV", // 개별소비세구분			
			"COMMODITY_CD", // 물품코드
			"COMMODITY_CONT", // 물품내용
			"VOLUME", // 수량			
			"UNIT_PRICE", // 단가
			
			"SELL_PRICE", // 판매가격			
			"VAT", // 부가가치세
			"SCT", // 개별소비세
			"ET", // 교육세		
			"FFVST" // 농어촌특별세
			};	
	

	
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//취소응답 300 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlens300[] = { 2, 3, 20, 1, 10, 
			10, 10, 14,	4,  9,
			8,  1,	1,  40, 24,
			3,  1,	6,  6,  3,
			60, 40,	4,  8,  1,
			21, 3,  1,  2,  50,
			4,  9,  9,	8,  8,
			8,  8 };

	static final String strHeaders300[] = { 
			"INQ_TYPE",//"LENGTH", // 전문 길이
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
			"BUY_SERIAL_NUM", // 구매일련번호(환급창구사업자코드(2) +매장ID + 난수(5)+연도(2)+시퀀스넘버(6)			
			"BUYER_CANCLE_CHECK", // 구매취소여부(Y,N)
			"TRADE_APPROVAL_NUM", // 거래승인번호
			
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)			
			"SELL_SUM_TOTAL", // 판매총수량
			"SELL_SUM_MONEY", // 판매총금액
			
			"REFUND_AMOUNT", // 환급총액(승인, 즉시환급조회시에는 총부가세세팅 취소시 0padding)
			"PAYMENT_TYPE", // 결제유형(신용1, 현금2)			
			"PASSPORT_ENC_YN", // 여권암호화여부 (N:비암호화, D:DES , T:3DES)
			"PASSPORT_NAME", // 여권영문이름(즉시환급 필수)
			"PASSPORT_NUM", // 여권번호(즉시환급필수 암호화시 TripleDES)
			
			"PASSPORT_NATION", // 여권국가코드 (즉시환급 필수)
			"PASSPORT_SEX", // 여권성별(즉시환급 필수)			
			"PASSPORT_BIRTH", // 여권생일(즉시환급 필수)
			"PASSPORT_EXPIRE", // 여권만료일(즉시환급 필수)
			"RESPONSE_CD", // 응답코드(100정상 , 200 통신장애 , 300 정보오류 , 400 재전송
			
			"RESPONSE_MESSAGE", // 응답메시지
			"SHOP_NAME", // 매장명			
			"SEQUENCE_COUNT", // 물품부반복회수 조회시 0000padding
			"EXPORT_EXPIRY_DATE", // 반출유효기간(YYYYMMDD)			
			"BEFORE_REFUND_YN", // 즉시환급여부 (즉시환급Y , 사후 환급 N)
			
			"MCH_SEND_UNIQ_NO", //전송고유번호	
			"COMMODITY_NUM", // 물품일련번호
			"SCT_DIV", // 개별소비세구분			
			"COMMODITY_CD", // 물품코드
			"COMMODITY_CONT", // 물품내용
			
			"VOLUME", // 수량			
			"UNIT_PRICE", // 단가
			"SELL_PRICE", // 판매가격			
			"VAT", // 부가가치세
			"SCT", // 개별소비세
			
			"ET", // 교육세		
			"FFVST" // 농어촌특별세
			};

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//개시 901GTF /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	static final int nlens901GTF[] = { 5, 2, 10, 3,  10, 10, 14,3,60,40};

	static final String strHeaders901GTF[] = { 
			"LENGTH", // 전문 길이
			"EDI", // 업무 구분
			"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)			
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)		
			"RESPONSE_CD",
			"RESPONSE_MESSAGE",
			"SHOP_NAME"
			};
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//개시 901 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlens901[] = { 2, 3,  10, 10, 14,};

	static final String strHeaders901[] = { 
			"INQ_TYPE",
			"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)			
			"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
			"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
			"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)			
			};
	

	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//개시응답 900GTF /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlens900GTF[] = { 5, 2, 10, 3, 10, 	10, 14, 3,	60, 40 };
	
	static final String strHeaders900GTF[] = { 
		"LENGTH", // 전문 길이
		"EDI", // 업무 구분
		"VERSION", // 전문버전(업무구분(2)+YYMMDD(6)+순번(2))
		"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
		"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호
		
		"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
		"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)			
		"RESPONSE_CD", // 응답코드(100정상 , 200 통신장애 , 300 정보오류 , 400 재전송			
		"RESPONSE_MESSAGE", // 응답메시지
		"SHOP_NAME", // 매장명
		};		
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//개시응답 900 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static final int nlens900[] = { 2, 3, 10, 10, 14,	 3,	60, 40 };

	static final String strHeaders900[] = { 
		"INQ_TYPE", 
		"DOCUMENT_CD", // 문서코드 (승인101 , 조회201, 취소301, 개시901)
		"SELLER_BUSI_REGIST_NUM", // 판매자 사업자등록번호		
		"TERMINAL_ID", // 단말기 ID (개시응답시 세팅 , 개시시에는 시리얼 넘버 )
		"SELL_TIME", // 판매연월시분초(YYYYMMDDHHMMSS)		
		
		"RESPONSE_CD", // 응답코드(100정상 , 200 통신장애 , 300 정보오류 , 400 재전송			
		"RESPONSE_MESSAGE", // 응답메시지
		"SHOP_NAME", // 매장명
		};		

	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	



	

	
	


	public static HashMap getParseDataGTF(int nlens[], String strHeaders[], String rcvBuf) {
		int bInx = 0;
		int eInx = 0;
		HashMap hm = new HashMap();

		eInx = nlens[0];
		for (int i = 0; i < nlens.length; i++) {

			hm.put(strHeaders[i].toString(), rcvBuf.substring(bInx, eInx));
			// logger.info( strHeaders[i].toString() + "==>(" + bInx +","+ eInx + ")" + rcvBuf.substring(bInx, eInx));
			if (i < nlens.length-1) {
				bInx = eInx;
				eInx = eInx + nlens[i + 1];
			}
		}

		return hm;
	}
	
	
	public static HashMap getParseDataGTF(int nlens[], String strHeaders[], String rcvBuf, int nlensGood[], String strHeadersGood[]) {
		int bInx = 0;
		int eInx = 0;
		HashMap hm = new HashMap();

		eInx = nlens[0];
		for (int i = 0; i < nlens.length; i++) {

			hm.put(strHeaders[i].toString(), rcvBuf.substring(bInx, eInx));
			// logger.info( strHeaders[i].toString() + "==>(" + bInx +","+ eInx + ")" + rcvBuf.substring(bInx, eInx));
			if (i < nlens.length) {
				if (i == nlens.length - 1) {
					bInx = eInx;
					eInx = eInx + nlensGood[0];
				} else {
					bInx = eInx;
					eInx = eInx + nlens[i + 1];
				}
			}
		}
		 int reCnt = Integer.parseInt((String)hm.get("SEQUENCE_COUNT"));
		for (int j = 0; j < reCnt ; j++) {
			// eInx = nlensGood[0];
			for (int k = 0; k < nlensGood.length; k++) {
				hm.put(makeGHKey(strHeadersGood[k].toString(), j), rcvBuf.substring(bInx, eInx));
				// logger.info( strHeadersGood[k].toString() + "==>(" + bInx +","+ eInx + ")" + rcvBuf.substring(bInx, eInx));
				if (k < nlensGood.length) {
					if (k == nlensGood.length - 1) {
						bInx = eInx;
						eInx = eInx + nlensGood[0];
					} else {
						bInx = eInx;
						eInx = eInx + nlensGood[k + 1];
					}
				}
			}
		}
		return hm;
	}
	


	
	public static HashMap getParseDataGTFMultibyte(int nlens[], String strHeaders[], String rcvBuf) {
		int bInx = 0;
		int eInx = 0;
		HashMap hm = new HashMap();

		eInx = nlens[0];
		for (int i = 0; i < nlens.length; i++) {

			hm.put(strHeaders[i].toString(), new String(rcvBuf.getBytes(), bInx, eInx - bInx));
			// logger.info( strHeaders[i].toString() + "==>(" + bInx +","+ eInx + ")" + new String(rcvBuf.getBytes(), bInx, eInx - bInx));
			if (i < nlens.length-1) {
				bInx = eInx;
				eInx = eInx + nlens[i + 1];
			}
		}

		return hm;
		
	}
	
	public static HashMap getParseDataGTFMultibyte(int nlens[], String strHeaders[], String rcvBuf, int nlensGood[], String strHeadersGood[]) {
		int bInx = 0;
		int eInx = 0;
		HashMap hm = new HashMap();

		eInx = nlens[0];
		for (int i = 0; i < nlens.length; i++) {

			hm.put(strHeaders[i].toString(), new String(rcvBuf.getBytes(), bInx, eInx - bInx));
			// logger.info( strHeaders[i].toString() + "==>(" + bInx +","+ eInx + ")" + new String(rcvBuf.getBytes(), bInx, eInx - bInx));
			if (i < nlens.length) {
				if (i == nlens.length - 1) {
					bInx = eInx;
					eInx = eInx + nlensGood[0];
				} else {
					bInx = eInx;
					eInx = eInx + nlens[i + 1];
				}
			}
		}
		 int reCnt = Integer.parseInt((String)hm.get("SEQUENCE_COUNT"));
		for (int j = 0; j < reCnt; j++) {
			// eInx = nlensGood[0];
			for (int k = 0; k < nlensGood.length; k++) {
				hm.put(makeGHKey(strHeadersGood[k].toString(), j), new String(rcvBuf.getBytes(), bInx, eInx - bInx));
				// logger.info( strHeadersGood[k].toString() + "==>(" + bInx +","+ eInx + ")" + new String(rcvBuf.getBytes(), bInx, eInx - bInx));
				if (k < nlensGood.length) {
					if (k == nlensGood.length - 1) {
						bInx = eInx;
						eInx = eInx + nlensGood[0];
					} else {
						bInx = eInx;
						eInx = eInx + nlensGood[k + 1];
					}
				}
			}
		}
		return hm;
	}
	
	
	public static String makeGHKey(String strCol, int nOfGood) {

		return String.format("%s_%d", strCol, nOfGood);

	}
	
	

//	static Map<String, String> getItemDataGTF(String defName1,String defName2, String item) throws Exception {
//
//		Map<String, String> item_data;
//		Object[][] Rules1 = TranDivide_Define.get(defName1);
//		Object[][] Rules2 = TranDivide_Define.get(defName2);
//		if(Rules1 != null) {
//			item_data = new HashMap<String, String>();
//			byte[] b = item.getBytes("MS949");
//			int offset = 0;
//			String key = "";
//			String val = "";
//			
//			int tSum1 = 0;
//			for(Object[] def1 : Rules1){
//				tSum1 += Integer.parseInt(def1[1].toString());
//			}
//			int tSum2 = 0;
//			for(Object[] def2 : Rules2){
//				tSum2 += Integer.parseInt(def2[1].toString());
//			}			
//			
//			for(Object[] def1 : Rules1){
//				key = (String)def1[0];
//				val = new String(b, offset, (Integer)def1[1], "MS949");
//				item_data.put(key, val);
//				offset += (Integer)def1[1];
//			}
//			int reCnt = Integer.parseInt(item_data.get("SEQUENCE_COUNT").toString());
//			for (int i=0 ; i<reCnt ; i++){
//				for(Object[] def2 : Rules2){
//					key = (String)def2[0];
//					val = new String(b, offset, (Integer)def2[1], "MS949");
//					item_data.put(makeGHKey(key,i), val);
//					offset += (Integer)def2[1];
//				} 				
//			}
//			
//			
//			System.out.println("TOTAL LENGTH = ["+ b.length +"]" );
//			System.out.println("tSum1["+tSum1+"] + tSum2["+ tSum2+"]" );
//			System.out.println("History LENGTH = ["+ tSum1 +"]" );
//			System.out.println("Goods repeat Cnt  = ["+ item_data.get("SEQUENCE_COUNT") +"]" );
//			System.out.println("good length = ["+ tSum2 +"]" );
//			System.out.println("Total goods length = ["+ tSum2* Integer.parseInt(item_data.get("SEQUENCE_COUNT")) +"]" );
//			return item_data;
//			
///*			// 길이 오류 체크
//			if(b.length == Integer.parseInt(item_data.get("ITEM_LEN"))) {
//				return item_data;
//			} else {
//				//cLog.CommLogger("[TranDivideUtil / getItemData] : Wrong Item length");
//				return null;
//			}*/
//		} else {
//			//cLog.CommLogger("[TranDivideUtil / getItemData] : Not Define Rules");
//			return null;
//		}
//	
//		
//	}

//	static Map<String, String> getItemDataGTFH(String defName1,String defName2, String item) throws Exception {
//
//		Map<String, String> item_data;
//		Object[][] Rules1 = TranDivide_Define.get(defName1);
//		Object[][] Rules2 = TranDivide_Define.get(defName2);
//		if(Rules1 != null) {
//			item_data = new HashMap<String, String>();
//			byte[] b = item.getBytes("MS949");
//			int offset = 0;
//			String key = "";
//			String val = "";
//			
//			int tSum1 = 0;
//			for(Object[] def1 : Rules1){
//				tSum1 += Integer.parseInt(def1[1].toString());
//			}
//			int tSum2 = 0;
//			for(Object[] def2 : Rules2){
//				tSum2 += Integer.parseInt(def2[1].toString());
//			}			
//			
//			for(Object[] def1 : Rules1){
//				key = (String)def1[0];
//				val = new String(b, offset, (Integer)def1[1], "MS949");
//				item_data.put(key, val);
//				offset += (Integer)def1[1];
//			}
//
//			
//			
//			System.out.println("TOTAL LENGTH = ["+ b.length +"]" );
//			System.out.println("tSum1["+tSum1+"] + tSum2["+ tSum2+"]" );
//			System.out.println("History LENGTH = ["+ tSum1 +"]" );
//			System.out.println("Goods repeat Cnt  = ["+ item_data.get("SEQUENCE_COUNT") +"]" );
//			System.out.println("good length = ["+ tSum2 +"]" );
//			System.out.println("Total goods length = ["+ tSum2* Integer.parseInt(item_data.get("SEQUENCE_COUNT")) +"]" );
//			//return item_data;
//			
//			// 길이 오류 체크
//			int gTot = tSum2* Integer.parseInt(item_data.get("SEQUENCE_COUNT"));
//			if((b.length-gTot) == (Integer.parseInt(item_data.get("ITEM_LEN"))-gTot)) {
//				return item_data;
//			} else {
//				//cLog.CommLogger("[TranDivideUtil / getItemData] : Wrong Item length");
//				return null;
//			}
//		} else {
//			//cLog.CommLogger("[TranDivideUtil / getItemData] : Not Define Rules");
//			return null;
//		}
//	
//		
//	}

	static Map<String, String> getMap(String key, String Val){
		Map<String, String> data  = new HashMap<String, String>();
		data.put(key, Val);
		return data;
		
	}
	
//	static List<Map<String, String>> getItemDataGTFG(String defName1,String defName2, String item) throws Exception {
//
//		Map<String, String> item_data;
//		List<Map<String, String>> itmDataList = new ArrayList<Map<String, String>>();
//		Object[][] Rules1 = TranDivide_Define.get(defName1);
//		Object[][] Rules2 = TranDivide_Define.get(defName2);
//		if(Rules1 != null) {
//			item_data = new HashMap<String, String>();
//			byte[] b = item.getBytes("MS949");
//			int offset = 0;
//			String key = "";
//			String val = "";
//			
//			int tSum1 = 0;
//			for(Object[] def1 : Rules1){
//				tSum1 += Integer.parseInt(def1[1].toString());
//			}
//			int tSum2 = 0;
//			for(Object[] def2 : Rules2){
//				tSum2 += Integer.parseInt(def2[1].toString());
//			}			
//			
//			for(Object[] def1 : Rules1){
//				key = (String)def1[0];
//				val = new String(b, offset, (Integer)def1[1], "MS949");
//				item_data.put(key, val);
//				offset += (Integer)def1[1];
//			}
//			reCnt = Integer.parseInt(item_data.get("SEQUENCE_COUNT").toString());
//			
//			for (int i=0 ; i<reCnt ; i++){
//				for(Object[] def2 : Rules2){
//					key = (String)def2[0];
//					val = new String(b, offset, (Integer)def2[1], "MS949");
//					//item_data.put(makeGHKey(key,i), val);
//					offset += (Integer)def2[1];
//					Thread.sleep(1);
//					itmDataList.add(getMap(makeGHKey(key,i),val));
//				} 		
//
//			}
//			
//			
//			System.out.println("TOTAL LENGTH = ["+ b.length +"]" );
//			System.out.println("tSum1["+tSum1+"] + tSum2["+ tSum2+"]" );
//			System.out.println("History LENGTH = ["+ tSum1 +"]" );
//			System.out.println("Goods repeat Cnt  = ["+ item_data.get("SEQUENCE_COUNT") +"]" );
//			System.out.println("good length = ["+ tSum2 +"]" );
//			System.out.println("Total goods length = ["+ tSum2* Integer.parseInt(item_data.get("SEQUENCE_COUNT")) +"]" );
//			return itmDataList;
//			
//		/*	// 길이 오류 체크
//			if(b.length == Integer.parseInt(item_data.get("ITEM_LEN"))) {
//				return item_data;
//			} else {
//				//cLog.CommLogger("[TranDivideUtil / getItemData] : Wrong Item length");
//				return null;
//			}*/
//		} else {
//			//cLog.CommLogger("[TranDivideUtil / getItemData] : Not Define Rules");
//			return null;
//		}
//	
//		
//	}
	
	static final Object[][] TRANDIVIDE_0097 = {
			{"ITEM_LEN",	5}, 
			{"TR_ITEM_ID",	2},
			{"TR_ITEM_SEQ",	3}, // 명세 순번
			
			{"EDI",						2},
			{"VERSION",					10},
			{"DOCUMENT_CD",				3},
			{"BUY_SERIAL_NUM",			20},
			{"BUYER_CANCLE_CHECK",		1},
			{"TRADE_APPROVAL_NUM",		10},
			{"SELLER_BUSI_REGIST_NUM",	10},
			{"TERMINAL_ID",				10},
			{"SELL_TIME",				14},
			{"SELL_SUM_TOTAL",			4},
			{"SELL_SUM_MONEY",			9},
			{"REFUND_AMOUNT",			8},
			{"PAYMENT_TYPE",			1},
			{"CREDIT_CARD_NUM",			21},
			{"KOR_DOMESTIC_CITIZEN",	1},
			{"KOR_IDENTITY",			13},
			{"PASSPORT_ENC_YN",			1},
			{"PASSPORT_NAME",			40},
			{"PASSPORT_NUM",			24},
			{"PASSPORT_NATION",			3},
			{"PASSPORT_SEX",			1},
			{"PASSPORT_BIRTH",			6},
			{"PASSPORT_EXPIRE",			6},
			{"RESPONSE_CD",				3},
			{"RESPONSE_MESSAGE",		60},
			{"SHOP_NAME",				40},
			{"SEQUENCE_COUNT",			4},
			{"EXPORT_EXPIRY_DATE",		8},
			{"RCT_NO",					30},
			{"BEFORE_REFUND_YN",		1},
			{"PAYMENT_AMOUNT",			9},
			{"EXPORT_APPROVAL_NUM",		30},
			{"BEFORE_LIMIT_AMOUNT",		10},
			{"EXTRA",					100},				
		};
	
	static final Object[][] TRANDIVIDE_0098 = {		
			{"COMMODITY_NUM",	3},
			{"SCT_DIV",			1},
			{"COMMODITY_CD",	2},
			{"COMMODITY_CONT",	50},
			{"VOLUME",			4},
			{"UNIT_PRICE",		9},
			{"SELL_PRICE",		9},
			{"VAT",				8},
			{"SCT",				8},
			{"ET",				8},
			{"FFVST",			8},
			{"EXTRA",			16}	
				
	};
		static int getLength(String defName){
			if("TRANDIVIDE_0098".equals(defName)) {
				return TRANDIVIDE_0098.length;
			}else if("TRANDIVIDE_0097".equals(defName)) {
				return TRANDIVIDE_0097.length;
			}else
				return 0;
		}
	

}





